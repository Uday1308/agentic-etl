# SKILL: MD Plan Generation Agent (4) — addendum to core.domo.skill.md

**Major AI use case.** generate → evaluate → **HITL** → regenerate. Use `build_gen_eval_hitl(hitl=True)`; do not hand-roll the loop.

## Contract
- **In:** standardized JSON **and** original DOMO JSON, plus `prompt_layers["md_plan"]`. Both are folded through `core.contracts.standardized.to_planner_dataflow` before the renderer sees them — the renderer reads `nodes`/`edges`, the documents are id-keyed with tiles under `actions`.
- **Not** the discovery table: that is CD Codegen's (5) input. Discovery (3) and MD Plan (4) both read the standardized JSON independently.
- **Out:** the plan, **versioned by iteration** (a regenerated plan after human feedback is a new version, not an overwrite of the approved prior).
- **HITL:** human reviews/edits; resume with `HumanFeedback`.

## Rules
- `generator` reads **both** JSONs. Roles: `generator` / `evaluator`.
- Human feedback (P1) must override the base prompt on regeneration — assemble via `core.domo.prompts`, accumulate feedback.
- Respect hard constraints via the deterministic post-check.
- A standardized document the fold finds no tiles in **fails loud**. The renderer is total: it would otherwise emit all nine sections with every table empty and a coverage report reading 100%, which no downstream check can distinguish from a real plan.
- The evaluator prompt must carry the plan text and demand JSON. `response_schema` only drives parsing — it never reaches the endpoint as a `response_format`.

## Tests (contracts/)
- generator consumes both JSONs;
- evaluator returns valid `EvalResult`;
- interrupt is resumable; `HumanFeedback` consumed correctly;
- P1 feedback overrides P4 base in regeneration;
- outputs versioned per iteration; `max_iters` respected;
- a mis-shaped or tile-less standardized document raises rather than producing an empty skeleton.
