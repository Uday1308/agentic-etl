# Frontend context — what this app is, what it gets, what it must do

Read this before changing the UI. It is the contract between the platform and the
frontend, written because verbal context did not survive the trip.

Everything named here is a real type in the repo. Where this file and the code disagree,
the code wins — the source of truth for row shapes is
[`core/contracts/telemetry.py`](../../core/contracts/telemetry.py) and for review shapes
[`core/domo/schemas.py`](../../core/domo/schemas.py).

Sample payloads for dataflow **8099** live in [`samples/`](./samples/). The prototype
hardcodes those.

---

## 1. What the product is

A DOMO → Databricks migration platform. Seven agents run in order per dataflow. Five of
them produce an artifact a human is asked to approve or send back.

The central idea: **a human approves the migration *plan*, not the generated code.**
Reviewing 55 statements of "what this step must do" takes fifteen minutes. Reviewing 900
lines of generated SQL takes a day and nobody does it carefully. The frontend's whole job
is to make that plan review fast and to make the pipeline's state legible.

If the UI ever asks a person to read generated SQL to make a decision, the design has
failed.

---

## 2. The pipeline the UI renders

| # | agent | produces | human asked? |
|---|---|---|---|
| 1 | `connection` | raw DOMO JSON on a volume | no |
| 2 | `standardization` | standardized JSON on a volume | no |
| 3 | `discovery` | discovery table (Delta) | no *(see gap #4)* |
| 4 | `md_plan` | `plan_<id>_v<n>.md` — **the review surface** | **yes** |
| 5 | `cd_codegen` | one `.sql` per output target | **yes** |
| 6 | `validation` | parity results (Delta) | **yes**, on failure |
| 7 | `classifier` | bronze/silver/gold split | **yes** |

Order is `AGENT_ORDER` in [`agents/master.py`](../../agents/master.py). Which agents use a
model / get an LLM review / ask a human is `AGENT_DEFAULTS` in the same file — **read it,
do not hardcode the table above**; a run's config can override it per agent.

### Phases — use these, never invent progress text

Each agent reports a fixed phase vocabulary (`AGENT_PHASES`, same file). A `StepRow`
carries `phase`, `phase_index`, `phase_count`. Render the phase string **verbatim**. The
UI must never guess or paraphrase what an agent is doing.

```
connection      Authenticating · Listing datasets · Caching metadata
standardization Reading raw artifacts · Normalizing schema · Deduplicating revisions
discovery       Understanding dataflow · Extracting nodes · Resolving lineage · Writing discovery table
md_plan         Understanding tiles · Context engineering · Translating expressions · Rendering plan · Evaluating
cd_codegen      Reading approved plan · Extracting code · Context engineering · Assembling notebook · Evaluating
validation      Submitting job · Waiting for the pipeline · Running row parity · Comparing schemas · Diagnosing
classifier      Reading node sections · Classifying layers · Splitting code · Launching pipelines
```

Phases are the failure-isolation mechanism. When something breaks, the phase says where —
that is what the UI shows, not a stack trace.

---

## 3. Inputs — what the frontend reads

All of it is rows from the telemetry sink plus artifacts on a volume. **The frontend never
calls an agent directly and never calls a serving endpoint.**

It reads them over HTTP from [`api/`](../../api), which is the enforcement of that rule:
every route either reads telemetry and artifacts or accepts one human's review. Nothing
in it can start, resume or steer a migration.

| route | returns |
|---|---|
| `GET /api/meta` | `AGENT_ORDER` / `AGENT_PHASES` / `AGENT_DEFAULTS`, from `agents/master.py` |
| `GET /api/dataflows` | the catalogue, with coverage per dataflow |
| `GET /api/runs`, `/api/runs/{id}` | `RunSummary` |
| `GET /api/runs/{id}/steps` | `StepRow[]` — also `llm-calls`, `ingestions`, `judges`, `validations`, `decisions` |
| `GET /api/gates?open_only=true` | the gates awaiting a human |
| `GET /api/gates/{gate_id}` | the review payload — the sample shapes in [`samples/`](./samples/) |
| `POST /api/gates/{gate_id}/feedback` | one `HumanFeedback` + one `DecisionRow` per decision |
| `GET /api/dataflows/{id}/artifacts`, `GET /api/artifact?path=` | artifact versions, then one artifact's text |

`GET /api/meta` is why §2 says to read `AGENT_DEFAULTS` rather than hardcode the table:
the API serves `master.py` itself, so a phase renamed there changes the UI with no UI
edit. Live route docs at `http://localhost:8000/docs`.

Two behaviours the client must keep:

* a **502** carries the reason in `detail` — which table or file could not be read. Show
  it. An empty dashboard in this product reads as "the migration did nothing", which is
  a very different thing from "the warehouse is unreachable";
* the feedback receipt returns `binds_generated_code: false`. Do not tell the reviewer
  their fix reached the SQL — per gap #1 below, it has not.

### 3.1 Telemetry rows

Every row carries `run_id`, `ts`, `environment`. Then:

| row | key fields | what the UI does with it |
|---|---|---|
| `StepRow` | `step_id, agent, phase, phase_index, phase_count, iteration, status, duration_ms, detail` | the live progress view; one row per phase transition |
| `LlmCallRow` | `call_id, agent, node, iteration, role, model, pool, tokens_in, tokens_out, tokens_cached, cost_usd, latency_ms, status, error, prompt_hash, attempt` | cost/usage panel; **not** a debugging dump |
| `IngestionRow` | `dataset_id, dataset_name, purpose, target_table, rows_ingested, domo_row_count, batch_id, batch_last_run, status, error, used_domo_api` | which datasets were pulled and whether counts matched DOMO |
| `JudgeRow` | `agent, iteration, rule_id, title, kind, verdict, findings, checked, nodes, note` | deterministic checks — show these **above** any LLM opinion |
| `ValidationRow` | `dataflow_id, target, table, checks_run, checks_passed, blocking_failures, advisory_failures, exact, passed, failure_category, owner_agent, diagnosis` | the parity verdict per target |
| `DecisionRow` | `dataflow_id, agent, iteration, kind, actor, issue_id, node, rationale, constraint` | the audit trail — **written by the UI**, see §5 |
| `RunSummary` | `status, started_ts, ended_ts, llm_calls, tokens_in, tokens_out, cost_usd, steps_run, agents_completed, iterations_total, rows_ingested` | the run header |

`StepStatus` ∈ `started | ok | failed | skipped | interrupted`.
`interrupted` is **not an error** — it means a HITL gate is open and waiting for this user.
Style it as an action, not a failure. This is the single most common thing to get wrong.

### 3.2 Artifacts

Read-only, on a UC Volume, versioned by iteration. A regenerated artifact is a **new
version** — never an overwrite of an approved prior. Always show which version is on
screen and let the user diff against the previous one.

```
<volume>/<dataflow_name>/md/plan_<dataflow_id>_v<iteration>.md      md_plan
<volume>/<dataflow_name>/sql/etl_<dataflow_id>__<target>.sql        cd_codegen
<volume>/<dataflow_name>/sql/debug_<dataflow_id>__<target>.sql      per-CTE row counts
```

### 3.3 The review payload

The thing a HITL gate hands the UI. Shapes from `core/domo/schemas.py`:

```
EvalResult   verdict: pass | revise | fail
             confidence: 0.0–1.0
             issues: Issue[]
             summary: str

Issue        id: str            # required — the decision is keyed on this
             severity: info | warn | error
             message: str       # what and why
             detail: str
             ref: str           # "step:s22" or "node:df_join_data_4_s37" — addresses ONE section
             suggested_fix: str # replacement body, spliced in if accepted
```

`ref` is what lets the UI scroll the artifact to the exact step an issue is about. An issue
without a resolvable `ref` is not renderable — surface it in a separate "unaddressed"
list rather than dropping it silently.

---

## 4. Outputs — what the frontend produces

Exactly one thing, plus its audit rows.

```
HumanFeedback   accepted_issue_ids: list[str]   # per-issue apply
                rejected_issue_ids: list[str]   # per-issue keep-as-is
                freeform: str                   # a note to the regenerator
                hard_constraints: list[str]      # inviolable rules, e.g. "Never rename source columns"
                ts: str
                actor: str
```

**Per-issue apply/keep is the contract, not bulk approve.** The reviewer decides issue by
issue. A single "approve all" button breaks the model the backend implements
(`PlanFeedbackApplier` splices only the accepted ids) and destroys the audit trail.

`hard_constraints` outrank everything on regeneration — they are prompt layer **P1**, above
the run's user prompt (P2), the previous iteration's issues (P3) and the agent's base
prompt (P4). Constraints accumulate across rounds and are never dropped. The UI should
show the standing constraint list on every subsequent review of that dataflow.

---

## 5. What the frontend must do

1. **Run header** — `RunSummary`: dataflow name + id, status, elapsed, cost, iterations.
2. **Stage strip** — seven agents, each with its phase progress from `StepRow`. A stage in
   `interrupted` is the call to action.
3. **The review view** (the important one), for each HITL gate:
   - the artifact, rendered, at the version under review;
   - the issue list beside it, each issue clickable to its `ref` in the artifact;
   - per issue: **Apply** / **Keep as-is**, plus a rationale field;
   - a freeform note box and a "add hard constraint" input;
   - deterministic `JudgeRow` results shown **above** the LLM `EvalResult`, because they
     are facts and it is an opinion. Label the LLM verdict as an opinion and show its
     `confidence`.
4. **Submit** — post one `HumanFeedback`, and write one `DecisionRow` per decision:
   `issue_accepted`, `issue_rejected`, `constraint_added`, `approved`, `regenerated`,
   `override`. The rows are the audit trail; do not batch them into one.
5. **Version history** — every iteration of every artifact, diffable. An approved prior is
   immutable.
6. **Cost panel** — from `LlmCallRow`. Note that a fully deterministic dataflow makes
   **zero** model calls; "0 calls, $0.00" is a success state, not an empty state. 8099 is
   exactly this.
7. **Coverage** — per dataflow: `n/m deterministic, k by model, j unresolved`. An
   **unresolved** step means the generated SQL contains a marked passthrough that does
   nothing. Show it in red and block promotion. A **by model** step is real SQL nobody has
   reviewed — show it amber and mark those sections `origin=ai` in the artifact view.

### What the frontend must not do

- call a serving endpoint, or any agent, directly;
- invent progress text outside `AGENT_PHASES`;
- offer bulk approve in place of per-issue decisions;
- render `interrupted` as an error;
- present an LLM `EvalResult` as authoritative over a `JudgeRow`;
- let a user edit an approved prior version.

---

## 6. Known gaps that affect the UI

From [`../architecture_gaps.md`](../architecture_gaps.md) — build around these, do not
paper over them:

- **Approval does not yet bind the generated code** (gap #1). `HumanFeedback` currently
  reaches only the AI translation path, which on a fully deterministic dataflow never
  runs. Collect the feedback and write the `DecisionRow`s anyway — the audit trail is real
  and the binding is coming. Do **not** tell the user their change was applied to the SQL.
- **`AGENT_DEFAULTS` says `discovery` has a HITL gate**; its own spec says it does not
  (gap #4). Read the flag, but expect it to go away.
- **8099 has no unresolved steps and no model calls**, so the prototype should also carry a
  fixture with one of each to exercise the amber and red states. `samples/` includes both.

---

## 7. The sample payloads

In [`samples/`](./samples/). Every `eval` block validates against the real `EvalResult` /
`Issue` models and every `human_feedback` block against `HumanFeedback` — so the prototype
cannot drift from the backend contract by accident. Numbers are from the actual 8099 run
(71 tiles, 55 steps, 6 targets, 55/55 deterministic, CTE counts per target as generated).

| file | what it exercises |
|---|---|
| `gate_md_plan.json` | the main review view: 4 issues at mixed severity, 4 judge results incl. two failures, no standing constraints yet |
| `gate_cd_codegen.json` | the **all-green** case: 6 targets, all EXPLAIN clean, zero issues, one standing constraint. Make sure this does not look like an empty state |
| `gate_validation.json` | one target failing parity on row count with a `diagnosis`, one passing with an advisory float difference. Note the failure traces back to an issue the reviewer *kept as-is* at plan time — the UI should link them |
| `gate_classifier.json` | bronze/silver/gold split with two layer-assignment issues, `ref` pointing at `node:` rather than `step:` |
| `submission_md_plan.json` | what the frontend POSTs: one `HumanFeedback` plus the six `DecisionRow`s it must write |
| `gate_md_plan_degraded_7412.json` | a second dataflow with **2 by-model and 1 unresolved** step, plus a `provenance` block. 8099 is 100% deterministic and never shows amber or red — build those states against this fixture |

`_8099_facts.json` is the raw figures (tile/step/target counts, per-target CTE counts, risk
steps) if you want to drive the header and coverage widgets from data rather than literals.

### Three details that are easy to get wrong

1. **`status: "interrupted"` is the "your turn" state**, not an error. All six gate samples
   carry it.
2. **`gate_cd_codegen.json` has zero issues and zero model calls.** That is the target
   outcome, not a missing payload. It needs a distinct, confident all-clear treatment.
3. **`ref` is either `step:<id>` or `node:<df_var>`** depending on the agent — plan and
   validation issues address steps, classifier issues address nodes. Handle both.
