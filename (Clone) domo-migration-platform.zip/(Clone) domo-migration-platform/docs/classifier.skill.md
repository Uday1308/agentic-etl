# SKILL: Classifier Agent (7) — addendum to core.domo.skill.md

**AI medallion classification + evaluate → HITL + split code + run layered pipelines.**

## Contract
- **In:** node-keyed CD output + validated results + medallion-rules **config file** (`agents/classifier/config/`) + `prompt_layers["classifier"]`.
- **Out:** bronze/silver/gold layer assignment (Delta) **and** the generated code split into **3 files** (bronze/silver/gold, volume), keyed by `(dataflow_id, iteration)`.
- **HITL:** evaluate → human reviews classification (per-issue apply/keep) → finalize.

## Rules
- Classification is LLM-driven (`role="classifier"`, pool `classification`, cap 2) **but governed by the config file** — orgs differ, so rules come from config, not hardcoded prose.
- Splitting requires CD output to be node-addressable (contract with agent 5). Partition strictly by assigned layer.
- **Jobs-as-a-tool:** run each layer file as a pipeline. Honour the user config for **grouping**: all 3 layers under one job/pipeline, or separate ones with separate schedules. (DLT vs multi-task Job is an open blueprint decision — code to the config abstraction, not a specific runner.)
- Medallion-rules config **format is TBD** by internal teams; code against a loader interface so the format can change without touching node logic.

## Tests (contracts/)
- consumes node-keyed CD output; missing keys fail loud;
- config rules drive layer assignment (swap config → different result);
- per-issue HITL apply/keep;
- code splits cleanly into exactly 3 layer files;
- pipeline-grouping config honoured (one-job vs per-layer);
- versioned per iteration.
