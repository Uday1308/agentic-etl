# SKILL: CD Code Generation Agent (5) — addendum to core.domo.skill.md

**Python mapping + AI translation + evaluator + per-issue HITL.**

## Contract
- **In:** discovery table + standardized JSON + `prompt_layers["cd_codegen"]`.
- **Out:** PySpark code, **node-addressable (keyed per source node/table)** — this is a hard integration constraint (the Classifier partitions by node/table). Versioned by iteration.
- **HITL:** user chooses **which evaluator changes to apply, per issue**, or keeps as-is.

## Rules
- **Known ops** (regex func mapping, agg mapping) are handled in **Python — no LLM call**. Only **unknown ops** go to AI.
- AI translation: **batch multiple lines into a chunk, translate line-by-line, include examples** in the prompt. Fan out over pool `cd_translation` (cap 8); store translations in the reducer collection keyed by **line index** — merge, not overwrite.
- Whole generated code → `evaluator` → `EvalResult` with **per-issue `ref`** (node/line) so HITL can apply/keep individually.
- Use `build_gen_eval_hitl(hitl=True)`.

## Tests (contracts/)
- known ops mapped **without** an LLM call; unknown ops routed to AI;
- translations merge by line index under concurrency;
- output is node-keyed (assert structure);
- evaluator issues carry node/line `ref`; per-issue apply/keep works;
- versioned per iteration.
