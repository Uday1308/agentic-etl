# `core/` Development Guide — Central Point of Truth

**Scope:** the frozen shared layer in `core/`. **Runtime:** Python 3.11, LangGraph. **Companion docs:** the Engineering Blueprint (the *why*) and the skill files (the *what to do*). This guide is the **authoritative reference for building `core/`** — what each file contains, the OOP shape it takes, how the pieces fit, and the development direction for the person writing it. Nothing here introduces new architecture; it maps the blueprint's contracts onto concrete classes.

If you are about to write a `core/` file, this document tells you its public surface, its collaborators, the patterns to use, and the boundaries not to cross. If two files seem to overlap, this document is the tie-breaker.

---

## 0. How to read this guide

Each file gets a section with the same shape:
- **Responsibility** — the one job it owns (from the blueprint).
- **Public API** — the classes/methods other code imports, as OOP skeletons.
- **Collaborators** — what it depends on and what depends on it.
- **OOP shape & patterns** — the design patterns to apply and why.
- **Development direction** — how to implement, do/don't, gotchas.
- **Boundary** — what must *not* leak into this file.
- **Tests** — what its own tests assert.

The skeletons are **direction, not final code** — signatures and shapes are fixed; bodies are yours. Where a decision is unresolved, it is marked **DECISION** — raise it with the team before coding, don't guess.

---

## 1. OOP conventions (apply everywhere in `core/`)

We are deliberately OOP-first. The rules below are non-negotiable across `core/`:

- **Data are value objects.** Every data shape is a `pydantic.BaseModel` (or `@dataclass(frozen=True)` where no validation is needed). Immutable value objects (`Issue`, `HumanFeedback`, `EndpointSpec`) are frozen. Data objects carry validation and small derived properties only — **no I/O, no side effects**.
- **Behaviour lives in service classes.** Anything that *does* something (resolve a model, call an LLM, write a row, checkpoint state) is a class with an explicit constructor. Dependencies are passed **into the constructor** (dependency injection) — never reached through module-level globals or import-time singletons.
- **Pluggable behaviour is an interface.** Where an agent supplies behaviour (generator, evaluator, feedback-applier, observability sink), define an **`abc.ABC` (or `typing.Protocol`)** and program to the interface. This is what makes the shared machinery reusable and the tests mockable.
- **One instance, injected.** Services (`LLMClient`, `ModelRegistry`, `ConcurrencyManager`, `ObservabilityWriter`, `ETLMaster`, checkpointer) are constructed **once at app startup** into a small `CoreServices` container and injected into nodes via LangGraph's `config["configurable"]`. Nodes never construct these themselves.
- **Type-hint everything; docstring every public class/method.** Public signatures are the contract; keep them honest.
- **Fail loud on contract violations.** No silent fallbacks that hide an integration break (this is the class of bug that let a hardcoded discovery-table name slip through earlier).

Patterns you will see recur: **Strategy** (generator/evaluator/feedback-applier), **Template Method** (the `Node` base and the gen-eval-HITL loop), **Registry** (models), **Facade + DI** (the LLM client), **Adapter** (checkpointer to LangGraph's interface), **Repository/DAO** (ETL master, observability), **Context manager** (concurrency pools).

---

## 2. Dependency graph & build order

```
schemas ──▶ prompts ──▶ state
   │                      │
   ├──────────────────────┼──────────────┐
   ▼            ▼          ▼              ▼
 models   concurrency  observability   etl_master        (independent — parallelisable)
   └──────────┬───────────┘
              ▼
            llm  ──▶  checkpoint  ──▶  nodes              (nodes depends on ~everything)
```

Build order: **`schemas` → `prompts` → `state`** first (they root the tree and unblock everyone). Then `models`, `concurrency`, `observability`, `etl_master` in **parallel** (different owners can take one each). Then `llm`, then `checkpoint`, then **`nodes` last**. A `CoreServices` assembly (§13) is written once the services exist.

---

## 3. `schemas.py` — the cross-cutting value objects

**Responsibility.** Define the data shapes every agent and every core service exchanges: evaluation results, issues, human feedback, and the generator's output. Pure shapes, no behaviour beyond validation.

**Public API.**
```python
class Verdict(str, Enum):    PASS = "pass"; REVISE = "revise"; FAIL = "fail"
class Severity(str, Enum):   INFO = "info"; WARN = "warn"; ERROR = "error"

class Issue(BaseModel):
    model_config = ConfigDict(frozen=True)
    id: str
    severity: Severity
    ref: str                      # node / table / line key — MUST be addressable
    message: str
    suggested_fix: str | None = None

class EvalResult(BaseModel):
    verdict: Verdict
    confidence: float             # 0..1, validated
    issues: list[Issue] = []
    summary: str
    @property
    def passed(self) -> bool: ...

class HumanFeedback(BaseModel):
    model_config = ConfigDict(frozen=True)
    accepted_issue_ids: list[str] = []
    rejected_issue_ids: list[str] = []
    freeform: str = ""
    hard_constraints: list[str] = []
    ts: datetime

class GenResult(BaseModel):
    artifact: <type>              # DECISION: the produced content's type
    node_keys: list[str] = []     # DECISION: addressing so Issues can ref nodes/tables/lines
    meta: dict = {}
```

**Collaborators.** Depends on nothing in `core/`. Imported by `prompts`, `state`, `llm`, `nodes`, and every agent.

**OOP shape & patterns.** Pure pydantic value objects. Freeze the immutable ones (`Issue`, `HumanFeedback`). Put `@field_validator`s here (e.g. `confidence` in `[0,1]`). Small derived helpers (`EvalResult.passed`) are fine; nothing else.

**Development direction.** Keep this file dependency-free so it never causes an import cycle. Enums are `str, Enum` so they serialise cleanly through the checkpointer. **DECISION — `GenResult` fields:** the blueprint fixes that it carries the produced artifact plus enough addressing for `Issue.ref` to point into it; pin the exact fields with the team when `nodes.py` is designed, because CD-gen's node-addressability requirement (blueprint §9.5) flows through here.

**Boundary.** No I/O, no LLM, no logic that isn't validation or a trivial property.

**Tests.** Validation rejects out-of-range confidence and missing required fields; frozen models are immutable; round-trips through JSON (checkpoint serialisation) losslessly.

---

## 4. `prompts.py` — prompt-priority assembler + hard-constraint channel

**Responsibility.** Turn the four ordered priority layers into a single deterministic prompt, and enforce human hard-constraints by a deterministic post-check. Owners fill layers; **nobody hand-formats a prompt**.

**Public API.**
```python
class PromptLayers(BaseModel):
    base: str                            # P4 — hardcoded per-agent instruction
    agent_feedback: list[Issue] = []     # P3
    user_prompt: str = ""                # P2 — standing instruction for the run
    human_feedback: list[HumanFeedback] = []  # P1 — accumulated, highest authority
    hard_constraints: list[str] = []     # enforced by the checker below

class PromptAssembler:
    def assemble(self, layers: PromptLayers) -> str: ...   # deterministic; states precedence explicitly

class HardConstraintChecker:
    def check(self, response: str, constraints: list[str]) -> list[str]: ...  # returns violations (empty == ok)
```

**Collaborators.** Depends on `schemas`. Used by `llm` (assembles before the call, checks after) and populated by agents.

**OOP shape & patterns.** Two small stateless service classes so they're trivially unit-testable and swappable. `assemble` must be **pure and deterministic** — same layers in, same string out — and must emit an explicit precedence statement (P1 > P2 > P3 > P4) into the prompt so the model is told which source wins on conflict.

**Development direction.** Priority ordering is the whole point: assemble in P4→P1 order but make P1 authoritative in the wording. `human_feedback` is an **accumulated list** — render the whole correction history, not just the latest. Keep `HardConstraintChecker` deterministic (string/rule checks), not another LLM call — it exists precisely because prose instructions can't be trusted alone.

**Boundary.** No LLM calls, no state access, no I/O. Pure functions of their inputs.

**Tests.** Precedence respected (P1 overrides conflicting P4); assembled output is deterministic; the checker flags a known violation and passes clean text.

---

## 5. `state.py` — the frozen run state + reducers

**Responsibility.** Define `RunState` (the graph's state), its status enum, the reducer functions for accumulation/fan-out, and the per-agent sub-state shapes. The **top-level shape is frozen**; agents populate their own key.

**Public API.**
```python
class RunStatus(str, Enum): RUNNING="running"; AWAITING_HUMAN="awaiting_human"; FAILED="failed"; DONE="done"

def merge_feedback(old, new): ...        # accumulate ordered list per agent
def merge_by_index(old, new): ...        # fan-out: dict[int, X] merge, never last-write-wins

class RunState(TypedDict):
    thread_id: str; dataflow_id: str; dataflow_name: str; environment: str
    current_agent: str; status: RunStatus
    connection: ConnectionState; standardization: StandardizationState; discovery: DiscoveryState
    md_plan: MdPlanState; cd_codegen: CdCodegenState; validation: ValidationState; classifier: ClassifierState
    feedback: Annotated[dict[str, list[HumanFeedback]], merge_feedback]
    prompt_layers: dict[str, PromptLayers]
    obs_run_id: str
# per-agent sub-states are TypedDicts; gen-eval-HITL ones carry `iteration: int`;
# standardization/cd carry Annotated[dict[int, X], merge_by_index] fan-out fields.
```

**Collaborators.** Depends on `schemas` and `prompts` (for `PromptLayers`). It is the type every node reads and returns deltas against; the checkpointer serialises it.

**OOP shape & patterns.** This is the one place we **do not** go full-OOP: LangGraph requires the graph state to be a `TypedDict` (or pydantic model) with **reducer functions** on `Annotated` fields, and reducers are plain functions by LangGraph's contract. Keep state **data-only and serializable** — no methods, no live objects (a service instance must never live on state; those come via `config`). Agents may model their *own* sub-state as a pydantic model internally, but what lands on `RunState` must serialise.

**Development direction.** Freeze the top-level keys — adding/removing one is a blueprint change. `merge_by_index` is what makes async fan-out safe (blueprint §5.1); implement it as index-keyed dict merge and unit-test it under out-of-order arrival. `feedback` accumulates so priority-layering sees history. Sub-state carrying `iteration` is what lets gen-eval-HITL version outputs instead of overwriting an approved artifact.

**Boundary.** No behaviour, no service instances, nothing non-serializable on the state.

**Tests.** `merge_by_index` merges concurrent partials without loss/overwrite; `merge_feedback` preserves order and accumulates; a `RunState` round-trips through the checkpoint serializer.

---

## 6. `models.py` — the role→endpoint registry

**Responsibility.** Resolve a logical **role** to a serving endpoint, per environment. Nodes ask for a role, never a model name (blueprint §5.4).

**Public API.**
```python
class Role(str, Enum): GENERATOR="generator"; EVALUATOR="evaluator"; CLASSIFIER="classifier"

class EndpointSpec(BaseModel):
    model_config = ConfigDict(frozen=True)
    endpoint: str; params: dict = {}

class ModelRegistry:
    def __init__(self, bindings: dict): ...          # loaded from config/
    def resolve(self, role: Role, environment: str) -> EndpointSpec: ...
```

**Collaborators.** Reads bindings from `config/`. Injected into `LLMClient`.

**OOP shape & patterns.** Registry pattern; config-driven. One instance, constructed from parsed config at startup and injected.

**Development direction.** Default binding is `gpt-oss-120B`; dev/eval may bind cheaper models per role independently — all in `config/`, so a model swap is a config edit and never a code change. Fail loud if a role/env has no binding.

**Boundary.** No LLM calls — resolution only.

**Tests.** Resolves each role per environment; unknown role/env raises; a config change changes the resolved endpoint (no hardcoding).

---

## 7. `concurrency.py` — named pools + global ceiling

**Responsibility.** Cap parallel LLM calls per task type and globally, so no task saturates the endpoint (blueprint §5.7).

**Public API.**
```python
class ConcurrencyManager:
    def __init__(self, caps: dict[str, int], global_ceiling: int): ...   # from config/
    def acquire(self, pool: str) -> AbstractAsyncContextManager: ...      # acquires pool + global
```

**Collaborators.** Caps from `config/` (`standardization_chunks`=6, `cd_translation`=8, `evaluation`=4, `classification`=2, global=16). Used **only** inside `LLMClient.complete`.

**OOP shape & patterns.** One manager holding an `asyncio.Semaphore` per pool plus a global semaphore; `acquire()` returns an async context manager that takes the pool **and** the global slot (releasing both on exit). Context-manager pattern.

**Development direction.** `async with cm.acquire("cd_translation"): ...`. Never let a caller bypass this to spawn unbounded tasks. Caps are per-environment overridable. Keep it framework-agnostic (plain asyncio), not tied to LangGraph.

**Boundary.** No LLM logic, no observability — just gating.

**Tests.** Concurrency never exceeds a pool cap or the global ceiling under load; the context manager always releases (even on exception).

---

## 8. `observability.py` — the Delta writers

**Responsibility.** Persist per-call and per-node telemetry to purpose-built Delta tables during runs (blueprint §5.8).

**Public API.**
```python
class LlmCallRow(BaseModel): ...   # obs_run_id, thread_id, dataflow_id, agent, node, role, model,
                                   # pool, prompt_hash, prompt_text?, response_text?, tokens_in/out,
                                   # latency_ms, retries, cost, confidence, iteration, ts
class NodeRow(BaseModel): ...      # obs_run_id, thread_id, agent, node, iteration, status,
                                   # duration_ms, hitl_wait_ms, ts

class ObservabilityWriter(ABC):
    @abstractmethod
    def record_llm_call(self, row: LlmCallRow) -> None: ...
    @abstractmethod
    def record_node(self, row: NodeRow) -> None: ...

class DeltaObservabilityWriter(ObservabilityWriter): ...   # concrete; capture flag from config
```

**Collaborators.** Reads the full-text capture flag from `config/`. Called **only** by `LLMClient` (per-call) and the `Node` harness (per-node).

**OOP shape & patterns.** Interface + concrete implementation (Strategy). The ABC exists so tests inject a `FakeObservabilityWriter` that records in memory — this is how contract tests assert "an LLM call was made through the wrapper."

**Development direction.** `prompt_hash` is always written; full `prompt_text`/`response_text` only when the config flag is on (default-on in dev, hashed-only in prod). Keep writes cheap and non-blocking to the graph where possible. **DECISION (open):** cost source per model/endpoint — leave `cost` populated by a pluggable pricing lookup, `None` until pricing is wired.

**Boundary.** No business logic, no prompt assembly — it records what it's handed.

**Tests.** Rows carry the required fields; capture flag toggles text vs hash; the fake writer captures calls for other components' tests.

---

## 9. `llm.py` — the one sanctioned LLM entry

**Responsibility.** The **only** place that touches a serving endpoint. Everything else calls this (blueprint §5.4). It wires together resolution, concurrency, assembly, the call, parsing, the hard-constraint check, and observability.

**Public API.**
```python
class LlmResult(BaseModel):
    parsed: BaseModel | None            # when response_schema given
    raw_text: str
    tokens_in: int; tokens_out: int; latency_ms: int; confidence: float | None
    hard_constraint_violations: list[str] = []

class LLMClient:
    def __init__(self, registry: ModelRegistry, assembler: PromptAssembler,
                 checker: HardConstraintChecker, concurrency: ConcurrencyManager,
                 observability: ObservabilityWriter): ...
    async def complete(self, role: Role, layered_prompt: PromptLayers, *, pool: str,
                       response_schema: type[BaseModel] | None = None,
                       config: RunnableConfig) -> LlmResult: ...
```

**Collaborators.** Depends on `models`, `prompts`, `concurrency`, `observability`, `schemas`. Wraps the existing Databricks serving-endpoint wrapper. Injected into every node that needs an LLM.

**OOP shape & patterns.** Facade over the whole LLM concern, with all collaborators injected (DI). Inside `complete`: resolve role → `async with concurrency.acquire(pool)` → `assembler.assemble(layers)` → call endpoint (with retry/timeout) → parse to `response_schema` → `checker.check(...)` → `observability.record_llm_call(...)` → return `LlmResult`.

**Development direction.** This is the *only* file allowed to import/call the serving SDK; a raw endpoint call anywhere else is a contract violation caught in review + tests. Reuse the serving wrapper we already have. **DECISION — hard-constraint surfacing:** the blueprint fixes the *behaviour* (a violation forces regeneration/failure) but not the mechanism — decide whether `complete` **raises** a `HardConstraintViolation` (the gen-eval-HITL loop catches → regenerate) or **returns** violations on `LlmResult` for the loop to inspect. Pick one and make it uniform.

**Boundary.** No agent-specific logic; no state mutation; observability is automatic here so no caller logs calls itself.

**Tests.** Goes through registry+concurrency+assembler+observability (assert via fakes); parses structured output; the hard-constraint path behaves per the chosen mechanism; a call is always recorded exactly once.

---

## 10. `checkpoint.py` — Postgres-live + Delta-audit checkpointer

**Responsibility.** Durable graph state: live in the app's Postgres (so `interrupt`/`Command(resume)` work), mirrored to Delta per node for visibility and crash fallback (blueprint §3.4, §5).

**Public API.**
```python
class DeltaAuditedCheckpointer(BaseCheckpointSaver):   # LangGraph interface
    def __init__(self, pg_saver: BaseCheckpointSaver, delta_auditor: "DeltaAuditor"): ...
    # implements put/get/list per LangGraph; appends a Delta audit row at the node boundary

class DeltaAuditor:
    def append(self, thread_id: str, snapshot: dict) -> None: ...

class RunStateReader:                 # UI projection / status reads
    def status(self, thread_id: str) -> RunStatus: ...
    def snapshot(self, thread_id: str) -> dict: ...
```

**Collaborators.** Serialises `RunState` (from `state`). Backed by a Postgres checkpoint saver + Delta. Read by the app's API for the UI.

**OOP shape & patterns.** **Adapter** to LangGraph's `BaseCheckpointSaver`, composed via **decoration**: wrap the Postgres saver and add the Delta append, rather than reimplementing persistence. `RunStateReader` is a thin read-side projection for the UI.

**Development direction.** The Delta append must sit at the **same boundary as the node's durable side effect** — safe to replay because nodes are idempotent (this is *why* idempotency is mandatory; §11 nodes). Key everything by `thread_id`. Don't put business logic here — durability only.

**Boundary.** No agent logic, no LLM, no ETL-master writes (separate store — §12).

**Tests.** put/get round-trips state; a Delta audit row is appended per node; a simulated crash-then-resume replays cleanly (idempotent node → same target); the reader projects status correctly.

---

## 11. `etl_master.py` — ETL master accessors (separate store)

**Responsibility.** Dataflow/file-level dedup and progress for the connection→standardization→discovery cycle. **Distinct from the checkpoint** (blueprint §5.9) — different grain, different lifecycle.

**Public API.**
```python
class Stage(str, Enum): CONNECTION="connection"; STANDARDIZATION="standardization"; DISCOVERY="discovery"
class FileStatus(str, Enum): PENDING="pending"; ACTIVE="active"; DONE="done"

class ETLMaster:                       # repository/DAO over the Delta master table
    def pending_files(self, ...) -> list[...]: ...
    def mark_status(self, dataflow_id: str, stage: Stage, status: FileStatus) -> None: ...  # idempotent
```

**Collaborators.** Backed by the ETL master Delta table. `pending_files` read by Standardization; `mark_status` written **only by the Connection node**.

**OOP shape & patterns.** Repository/DAO — encapsulates all master-table access behind methods so no agent hand-writes queries.

**Development direction.** `mark_status` must be idempotent (re-run must not duplicate rows or double-flip). The module *offers* the write, but the rule that **only Connection calls it** is enforced by convention + a contract test — nothing else touches ETL-master status. Never let checkpoint concerns leak in here and vice versa; the only link is that a run knows its `dataflow_id`.

**Boundary.** No graph state, no LLM, no checkpoint coupling.

**Tests.** `pending_files` returns only unprocessed files; `mark_status` is idempotent; the connection→standardization flip is correct.

---

## 12. `nodes.py` — node contract + reusable machinery

**Responsibility.** Define what a node *is* (signature + idempotency + observability), and provide the **build-once** `generate → evaluate → HITL` loop that four agents reuse (blueprint §4.2, §5.3).

**Public API.**
```python
class Node(ABC):                        # Template Method: base wraps timing/obs/mutation-guard
    agent: str; name: str
    @abstractmethod
    def run(self, state: RunState, config: RunnableConfig) -> dict: ...   # returns a state DELTA
    def __call__(self, state, config) -> dict: ...   # base: time it, emit NodeRow, guard no-mutation

# Strategy interfaces injected into the gen-eval-HITL loop:
class Generator(ABC):
    @abstractmethod
    async def generate(self, state, config) -> GenResult: ...
class Evaluator(ABC):
    @abstractmethod
    async def evaluate(self, result: GenResult, state) -> EvalResult: ...
class FeedbackApplier(ABC):
    @abstractmethod
    def apply(self, result: GenResult, feedback: list[HumanFeedback]) -> GenResult: ...

def build_gen_eval_hitl(*, name: str, generator: Generator, evaluator: Evaluator | None,
                        feedback_applier: FeedbackApplier, hitl: bool, max_iters: int = 3) -> StateGraph: ...
```

**Collaborators.** Depends on `state`, `schemas`, `observability` (the harness emits `NodeRow`), `llm` (generators call it), `prompts`. Every agent builds on this.

**OOP shape & patterns.** **Template Method** in `Node` (base class does the cross-cutting work — timing, the per-node observability row, and the no-in-place-mutation guard — subclass implements `run`). **Strategy** for the three injected behaviours. **Factory/Builder** in `build_gen_eval_hitl`, which assembles a `StateGraph` implementing the loop: generate → (evaluate) → if HITL `interrupt()` with artifact + `EvalResult` → resume with `HumanFeedback` → `feedback_applier.apply` → regenerate with `iteration+1` → stop on accept or `max_iters`. Prompt-priority layering is applied through the generator's `LLMClient.complete` call.

**Development direction.** Nodes are `Node` subclasses (this **refines** the earlier functional sketch in the skills — the harness that was a decorator is now the base class's `__call__`; a thin decorator form may remain for trivial nodes, calling the same harness). The loop is written **once, here** — agents inject their `Generator`/`Evaluator`/`FeedbackApplier` and **never reimplement it**. Every durable write inside a node is keyed `(dataflow_id, node, iteration)`; gen-eval-HITL versions by iteration, connection/discovery overwrite. Update the core skill's node example to the class form so code and skill stay aligned.

**Boundary.** No agent-specific logic; no raw LLM/endpoint access (goes through injected `LLMClient`); the loop lives here and nowhere else.

**Tests.** The harness emits exactly one `NodeRow` and rejects in-place mutation; the loop generates→evaluates→pauses resumably→applies feedback→regenerates and honours `max_iters`; injected strategies are called in order; iteration increments.

---

## 13. Wiring: `CoreServices` (assembly point)

Not a new contract — implementation direction for **how the injected instances are created**. Build all services once at app startup and expose them to nodes via LangGraph `config["configurable"]`; nodes pull what they need, never construct services.

```python
class CoreServices:                     # constructed once at startup from parsed config/
    registry: ModelRegistry
    llm: LLMClient
    checkpointer: DeltaAuditedCheckpointer
    etl_master: ETLMaster
    observability: ObservabilityWriter
    # graph invocation passes these in config["configurable"]; nodes read them there
```

**Direction.** One construction site; everything else receives instances. This keeps the DI rule (§1) enforceable and makes the whole graph testable by swapping in fakes at this one point.

---

## 14. Cross-cutting rules (restated, enforced by review + tests)

- **Frozen core.domo.** Changing a `core/` public signature is a blueprint change (Blueprint §13): reviewed PR, doc + skills updated in the same PR, `CONTRACTS_VERSION` bumped.
- **One LLM entry.** Only `llm.py` touches a serving endpoint.
- **One ETL-master writer.** Only the Connection node calls `mark_status`.
- **Idempotent writes**, keyed `(dataflow_id, node, iteration)`.
- **Fan-out merges**, never last-write-wins.
- **No hardcoded inputs** — verified by divergent-fixture tests (two different inputs → outputs differ accordingly).

---

## 15. Open decisions (ratify before/while coding, do not guess)

1. **`GenResult` fields** (§3) — exact artifact type + node/table/line addressing. Pin with `nodes.py`.
2. **Hard-constraint surfacing** (§9) — `complete` raises vs returns violations. Pick one, apply uniformly.
3. **Cost source** (§8) — pricing lookup per model/endpoint; `cost` stays `None` until wired.
4. **(Carried from blueprint)** medallion-rules config format and DLT-vs-Job for layered pipelines — out of `core/` scope but `models.py`/`config/` will read the former eventually.
