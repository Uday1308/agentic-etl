# SKILL: Connection Agent (1) — addendum to core.domo.skill.md

**No AI.** Pure I/O. Connect to DOMO, fetch the dataflow JSON, write it, stop.

## Contract
- **In:** `dataflow_id`, `environment`.
- **Out:** DOMO dataflow JSON at the dataflow's volume path (pure overwrite — no iteration axis).
- **Side effect (last action):** flip ETL master → connection `done`, standardization `active`. This is the **only** place ETL-master status is written. Do it via `core.domo.etl_master`, idempotently (re-run must not create duplicate rows or double-flip).

## Rules
- No `core.domo.llm` calls at all. No `prompts/` folder.
- No evaluator, no HITL.
- Overwrite the JSON target; the ETL-master flip is your single status write.

## Tests (contracts/)
- writes JSON to the correct volume path;
- flips ETL-master status exactly once, idempotently;
- re-run overwrites JSON and leaves ETL master consistent (no duplicates);
- never calls the LLM wrapper.
