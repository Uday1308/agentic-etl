# DOMO → PySpark Migration — Architecture Blueprint

**Status:** working draft · **Runtime:** Python 3.11, LangGraph · **Host:** Databricks App (in-app orchestration)

This document is the single source of truth for how the migration platform is built. It is **contracts-first**: the shared contracts in [§4](#4-shared-contracts-the-frozen-core) are frozen and owned centrally; each agent owner implements against them. The goal is parallel development with near-zero integration friction — if every component honours the contracts and passes its contract tests, integration is wiring, not rework.

The companion skill files (`skills/`) are the terse, prescriptive version of this document for handing to an AI while writing a component. This document explains *why*; the skills state *what to do*.

---

## 1. Goals & principles

- **AI everywhere except Connection.** Every stage past connection uses LLMs for generation and/or evaluation. Connection is pure I/O.
- **In-app LangGraph orchestration, not Databricks Jobs.** HITLs, loops, and parallel LLM fan-out are first-class in a graph; a multi-task Job is the wrong tool for that. Jobs/DLT remain a *tool* two nodes call to run PySpark on real compute (see [§3.3](#33-jobs-as-a-tool-the-one-exception)).
- **Idempotent nodes.** Every node can be re-run and produce the same durable result. This is the linchpin of crash recovery and HITL resume.
- **Durable, observable state.** Checkpoints live in Postgres at runtime and are mirrored to Delta for visibility and fallback. Rich observability tables are built during runs.
- **Modularity + tests.** Shared core is reused everywhere; the repeated `generate → evaluate → HITL` pattern is a single parameterised subgraph. Every component ships contract tests so integration is safe.
- **The blueprint can evolve.** Contracts are frozen *by convention*, but versioned. If accuracy gaps force architectural change, contracts change deliberately (see [§11](#11-changing-the-contracts)).

---

## 2. Architecture at a glance

Seven agents, each a LangGraph subgraph, wired into one master graph per dataflow run:

| # | Agent | AI? | Evaluator | HITL | Executes PySpark |
|---|-------|-----|-----------|------|------------------|
| 1 | Connection | No | No | No | No |
| 2 | Standardization | Yes | Yes (+ JSON validator) | No | No |
| 3 | Discovery | Mostly No | Structural check only | No | No |
| 4 | MD Plan Gen | Yes | Yes | **Yes** | No |
| 5 | CD Code Gen | Yes (+ Python mapping) | Yes | **Yes** | No |
| 6 | Validation | Yes (troubleshooting) | via checks | Optional | **Yes** (runs generated job) |
| 7 | Classifier (medallion) | Yes | Yes | **Yes** | **Yes** (runs layered pipelines) |

Agents run in the order dataflow-id → connection JSON → standardized JSON → discovery table → md plan → cd code → validated run → medallion-classified layered pipelines. That is the *execution* order, not a chain of hand-offs: Discovery (3) and MD Plan (4) both read the standardized JSON independently, and the discovery table is CD Codegen's (5) input, not MD Plan's. State threads through the whole run; HITL nodes pause the graph until a human resumes it.

```
                         ┌─────────────── master graph (per dataflow run) ───────────────┐
 dataflow_id ─▶ connection ─▶ standardization ─▶ discovery ─▶ md_plan ─▶ cd_codegen ─▶ validation ─▶ classifier ─▶ done
                  │ (ETL master: mark connection done, standardization active)
                  ▼
               ETL master table  (dataflow/file-level dedup + progress — separate store)

 every node ──▶ checkpoint (Postgres live + Delta audit)  and  observability tables (per-call, per-node)
```

---

## 3. Execution model & runtime

### 3.1 Where the graph runs
The Databricks App hosts a **worker** that executes the LangGraph graph. Graph execution does **not** happen inside an HTTP request — requests only *start* a run, *submit* HITL feedback, and *read* state. A run advances as a background task keyed by a stable `thread_id`. This survives request timeouts and app restarts because state is durable (see §3.4).

### 3.2 Async HITL (park-and-return)
HITL nodes call LangGraph `interrupt()` and the run parks. The UI polls run state (from the checkpoint projection) and, when a node is `awaiting_human`, renders the payload. The human's response is submitted and the run resumes via `Command(resume=<HumanFeedback>)` on a background task. Large ETLs may have many parallel LLM calls in flight before a park; parking is per HITL node, not per call.

### 3.3 Jobs as a tool (the one exception)
Orchestration is LangGraph. But **Validation (6)** and **Classifier (7)** must execute PySpark on real compute. Those nodes *launch* a Databricks Job (or DLT pipeline) and **poll to completion**, then read results back. This is a tool call from inside a node, not an orchestration mechanism. The graph owns control flow; the Job owns Spark execution. (DLT vs multi-task Job for the medallion layers is an open call — see [§10](#10-open-items).)

### 3.4 Checkpointing: Postgres live + Delta audit
- **Postgres (app compute)** is the authoritative live checkpoint store while a run is active — fast reads/writes, LangGraph's checkpointer backend.
- **Delta** receives an **append per node** for visibility and as a crash fallback. If the app dies, the last durable Delta state lets a run resume.
- **Commit alignment (critical):** the checkpoint write and the Delta audit append must sit at the **same boundary as the node's durable side effect**. Because nodes are idempotent (§4.2), a resume that re-runs a node whose side effects already landed is safe — it overwrites cleanly. This is why idempotency is non-negotiable: it removes the need for a hard cross-store transaction.
- One node = one idempotent unit = one super-step = one Delta audit row. Keep these in lockstep.

---

## 4. Shared contracts (the frozen core)

Everything in this section lives in `core/` and is owned centrally. Agent owners **use** these; they do not fork them. Changes are blueprint changes ([§11](#11-changing-the-contracts)).

### 4.1 Run State schema
Top-level state is frozen. Agents own only their namespaced sub-state. Fan-out fields use **reducers** (merge, not last-write-wins). Feedback is an **accumulating ordered list** per agent so priority-layering sees full history.

```python
# core/state.py  (pydantic / TypedDict with Annotated reducers)

class RunState(TypedDict):
    thread_id: str                       # stable per run; checkpoint key
    dataflow_id: str                     # == limits_id; links to ETL master
    dataflow_name: str
    environment: str                     # dev | ust | prod
    current_agent: str
    status: RunStatus                    # running | awaiting_human | failed | done

    # per-agent namespaced sub-state; each agent owns its own key only
    connection: ConnectionState
    standardization: StandardizationState
    discovery: DiscoveryState
    md_plan: MdPlanState
    cd_codegen: CdCodegenState
    validation: ValidationState
    classifier: ClassifierState

    # cross-cutting, reducer-backed
    feedback: Annotated[dict[str, list[HumanFeedback]], merge_feedback]   # agent -> ordered feedback
    prompt_layers: dict[str, PromptLayers]                                # agent -> layered prompt inputs
    obs_run_id: str                      # links all observability rows for this run
```

- **Fan-out collections** (e.g. CD-gen translated lines, standardization chunks) are `Annotated[dict[int, X], merge_by_index]` — keyed by chunk/line index, merged concurrently. Never last-write-wins.
- **Iteration**: generate-eval-HITL sub-state carries an `iteration: int`. Regeneration after feedback increments it; outputs are versioned per iteration (§4.2).

### 4.2 Node signature & idempotency
```python
# a node is a pure-ish function: state in, state delta out
def node(state: RunState, config: RunnableConfig) -> dict: ...
```
Rules:
- Returns a **state delta** (partial dict), never mutates in place.
- **Idempotent.** All durable writes are keyed by `(dataflow_id, node, iteration)`. Re-running overwrites the same target.
  - Connection & Discovery: **pure overwrite** (no iteration axis).
  - Generate/eval/HITL nodes (md_plan, cd_codegen, classifier): **versioned by iteration** — a regenerated artifact after human feedback is a *new* version, not an overwrite of the human-approved prior.
- Emits exactly one per-node observability row (via the node harness).
- Must be safe to replay after a crash mid-super-step.

### 4.3 The `generate → evaluate → HITL` subgraph (build once, reuse)
Steps 2, 4, 5, 7 share this shape. It is a single parameterised factory in `core/nodes.py`:

```python
def build_gen_eval_hitl(
    *,
    name: str,
    generator: Callable[[RunState, RunnableConfig], GenResult],
    evaluator: Callable[[GenResult, RunState], EvalResult] | None,
    apply_feedback: Callable[[GenResult, list[HumanFeedback]], GenResult],
    hitl: bool,
    max_iters: int = 3,
) -> StateGraph: ...
```
Loop: generate → (evaluate) → if HITL, `interrupt()` with the artifact + `EvalResult` → resume with `HumanFeedback` → `apply_feedback` → regenerate (iteration+1) until accepted or `max_iters`. Prompt-priority layering (§4.5) is applied inside every generator call automatically.

Owners inject `generator` / `evaluator` / `apply_feedback`; they do not re-implement the loop.

### 4.4 LLM access — one sanctioned entry, role-based
```python
# core/llm.py  — the ONLY place that calls a serving endpoint
def complete(role: str, layered_prompt: PromptLayers, *, pool: str,
             response_schema: type | None = None, config: RunnableConfig) -> LlmResult: ...
```
- Nodes ask for a **role** (`generator`, `evaluator`, `classifier`, …), never a model name.
- `core/models.py` is a **model registry**: role → endpoint name, per environment. Swap models by editing config only.
- Observability is written **inside** the wrapper — no untraced calls are possible.
- Concurrency pool is acquired here by name (§4.7).
- Default endpoint: `gpt-oss-120b`; dev/eval may bind cheaper models per role.

### 4.5 Prompt-priority layering
Four ordered priority layers plus a hard-constraint channel. Assembled deterministically by `core/prompts.py` — owners fill layers, never hand-format the final prompt.

```
Priority 1  Human feedback        (highest — per-HITL corrections, accumulated)
Priority 2  User prompt           (standing instruction for this run)
Priority 3  Agent feedback        (evaluator issues / suggestions)
Priority 4  Base prompt           (hardcoded per-agent instruction)
```
- **Conflict resolution** is stated explicitly in the assembled prompt (higher priority wins).
- **Hard constraints** ("never do X" from human feedback) go to a separate channel enforced by a **deterministic post-check**, not by hoping the model obeys prose. A violated hard constraint fails the node / forces regeneration.
- `PromptLayers` is structured data on state; the assembler is pure and unit-tested.

### 4.6 Shared schemas
```python
# core/schemas.py
class EvalResult(BaseModel):
    verdict: Literal["pass", "revise", "fail"]
    confidence: float                     # 0..1  (persisted to observability)
    issues: list[Issue]                   # each: severity, ref (node/table/line key), message, suggested_fix
    summary: str

class HumanFeedback(BaseModel):
    accepted_issue_ids: list[str]
    rejected_issue_ids: list[str]
    freeform: str
    hard_constraints: list[str] = []      # enforced deterministically
    ts: datetime
```
`Issue.ref` is node/table/line-addressable so CD-gen and Classifier HITLs can show "apply this change / keep as is" **per issue**.

### 4.7 Concurrency — named pools + global ceiling
`core/concurrency.py` exposes named pools; nodes acquire from a pool by name. No sum of in-flight calls exceeds the global ceiling.

| Pool | Default cap | Used by |
|------|-------------|---------|
| `standardization_chunks` | 6 | Standardization |
| `cd_translation` | 8 | CD code gen |
| `evaluation` | 4 | all evaluators |
| `classification` | 2 | Classifier |
| **global ceiling** | **16** | hard cap across all pools |

All caps live in `config/` and are overridable per environment.

### 4.8 Observability tables (purpose-built, not MLflow)
Written by the LLM wrapper (per-call) and the node harness (per-node). Delta tables, queryable during and after runs.

- **`obs_llm_calls`** — one row per LLM call: `obs_run_id, thread_id, dataflow_id, agent, node, role, model, pool, prompt_hash, prompt_text?, response_text?, tokens_in, tokens_out, latency_ms, retries, cost, confidence, iteration, ts`.
- **`obs_nodes`** — one row per node execution: `obs_run_id, thread_id, agent, node, iteration, status, duration_ms, hitl_wait_ms, ts`.
- **Full prompt/response text** is captured behind a **config flag** — **default ON in dev**, hashed-only in prod. `prompt_hash` always present for correlation.

### 4.9 ETL master (separate store — do not confuse with checkpoint)
Different grain and lifecycle from the checkpoint:
- **ETL master** = dataflow/file-level dedup + progress for the connection→standardization→discovery cycle. There can be multiple files under one root folder; the master prevents re-processing the same file across runs.
- **Checkpoint** = per-agent-run graph state, keyed by `thread_id`.
- **One-way link only:** a graph run references its `dataflow_id`; the checkpoint never writes ETL-master status and vice versa. The **Connection node** flips ETL-master to "standardization active" as its last idempotent action — no separate reconciler.

---

## 5. Data model

**Stores**
- Postgres (app): live LangGraph checkpoints.
- Delta: checkpoint audit mirror, observability (`obs_llm_calls`, `obs_nodes`), ETL master, discovery tables, validation results, classifier output.
- UC Volumes: DOMO JSON, standardized JSON, md plans, cd code, layered code files.

**Per-agent durable outputs** (all idempotent, keyed as in §4.2)
| Agent | Output | Location |
|-------|--------|----------|
| Connection | DOMO dataflow JSON | volume |
| Standardization | standardized JSON | volume |
| Discovery | node/edge table per dataflow | Delta (create or overwrite) |
| MD Plan | plan (versioned by iteration) | volume |
| CD Codegen | PySpark code, node-addressable | volume |
| Validation | check results | Delta |
| Classifier | bronze/silver/gold code + layer assignment | volume + Delta |

**CD-gen output must be node-keyed** so the Classifier can partition code into layers cleanly (§4.6, [§9.5](#95-cd-code-generation-agent-5)). This is a hard integration constraint.

---

## 6. Repo / package layout

```
core/                # FROZEN shared contracts — the blueprint in code
  state.py             # RunState, reducers, fan-out collections
  nodes.py             # node signature + build_gen_eval_hitl factory + node harness
  llm.py               # serving-endpoint wrapper (only sanctioned LLM entry; traces here)
  models.py            # model registry: role -> endpoint, per-env
  prompts.py           # prompt-layering assembler + hard-constraint channel
  schemas.py           # EvalResult, HumanFeedback, Issue, GenResult
  checkpoint.py        # Postgres live + Delta audit checkpointer
  observability.py     # obs table writers (per-call, per-node)
  concurrency.py       # named pools + global ceiling
  etl_master.py        # ETL master accessors (dedup / progress)
agents/
  connection/      { graph.py, nodes.py, tests/ }              # no prompts/
  standardization/ { graph.py, nodes.py, prompts/, tests/ }
  discovery/       { graph.py, nodes.py, tests/ }
  md_plan/         { graph.py, nodes.py, prompts/, tests/ }
  cd_codegen/      { graph.py, nodes.py, prompts/, tests/ }
  validation/      { graph.py, nodes.py, prompts/, tests/ }
  classifier/      { graph.py, nodes.py, prompts/, tests/, config/ }
graph.py             # top-level assembly: wires agents into the master graph
config/              # model bindings, concurrency caps, medallion rules, env
tests/
  contracts/         # fast, mocked-LLM conformance tests — GATE CI
  eval/              # slow AI quality sets — DO NOT gate CI
```

Owners work **inside `agents/<name>/`** against a frozen `core/`. Editing `core/` = a blueprint change, reviewed by the whole team.

---

## 7. Testing strategy

Two distinct suites, never conflated:

**Contract tests (`tests/contracts/`) — gate CI, fast, LLM mocked.** Prove a component honours the blueprint:
- Node returns a valid state delta (schema-checked); no in-place mutation.
- Node is idempotent (run twice → same durable target).
- Reads/writes the right table/volume with the right key.
- Uses `core.domo.llm.complete` (never a raw endpoint) — asserted by mocking the wrapper.
- Prompt assembly respects priority order; hard-constraint post-check rejects violations.
- Evaluators return valid `EvalResult`; HITL nodes emit a resumable interrupt and consume `HumanFeedback`.
- Fan-out fields merge (reducer), not overwrite.

**Eval tests (`tests/eval/`) — do NOT gate CI, slow, real/recorded LLM.** Quality of AI output on a curated set (accuracy vs target, translation correctness, classification quality). Run on demand / nightly.

Each agent section ([§9](#9-per-agent-specifications)) has its own test checklist. A component is "done" when its contract tests pass in CI.

---

## 8. Prompt priority — full spec

The four layers plus hard constraints, restated for owners:

1. **Human feedback (P1).** Per-HITL corrections, accumulated across iterations. Highest authority. If a human says "don't split this table," nothing overrides it.
2. **User prompt (P2).** A standing instruction for the whole run (e.g. "target Unity Catalog, no legacy Hive").
3. **Agent feedback (P3).** Evaluator `issues`/`suggested_fix`.
4. **Base prompt (P4).** The hardcoded per-agent instruction.

Assembly rules:
- Higher priority wins on conflict; the assembled prompt says so explicitly.
- Hard constraints from P1 are also enforced by a deterministic post-check; a violation forces regeneration or fails the node.
- Feedback accumulates (ordered list) — the model sees the full correction history, not just the latest.

---

## 9. Per-agent specifications

Each subsection is a **stub the owner completes**, but the I/O contract, idempotency, and test checklist are fixed here.

### 9.1 Connection agent (1)
- **AI:** none. Connect to DOMO, fetch dataflow JSON, write to volume, stop.
- **ETL master:** mark this dataflow's connection **done** and set **standardization active** — as the node's last idempotent action.
- **Idempotency:** pure overwrite of the JSON at the dataflow path.
- **Tests:** writes JSON to correct volume path; flips ETL-master status exactly once; re-run overwrites, no duplicate master rows.

### 9.2 Standardization agent (2)
- **AI:** yes — existing standalone Python + AI chunk-processing architecture is the canonical reference.
- **Flow:** read pending files from ETL master → chunk → standardize (fan-out over chunks, pool `standardization_chunks`) → **evaluator agent + JSON validator** ensure data is intact and in required shape → write standardized JSON to volume.
- **Shape:** id-keyed, tiles under `actions`, edges under `connections` — defined once in `core/contracts/standardized.py` and validated through it, never re-derived per agent. Standardizing is additive: untouched document fields carry through verbatim.
- **Idempotency:** overwrite standardized file per dataflow/file.
- **HITL:** none (evaluator + validator only).
- **Tests:** chunk fan-out merges by index; JSON validator rejects malformed shape; evaluator returns `EvalResult`; standardized output matches schema.

### 9.3 Discovery agent (3)
- **AI:** none for evaluation. Python discovers all nodes/edges, writes the dataflow's own table (create, or overwrite if exists).
- **Check:** structural only — verify all nodes and connections exist in the final table. No AI.
- **Idempotency:** create-or-overwrite the discovery table.
- **Tests:** every source node/edge present in output table; overwrite path works; structural check fails loudly on missing nodes.

### 9.4 MD plan generation agent (4)
- **AI:** major use case. Generate plan from standardized + original JSON → evaluate → **HITL** (human reviews/edits) → regenerate on feedback. Both documents are folded through `core.contracts.standardized.to_planner_dataflow` at the read; a document with no tiles in it **fails loud** rather than rendering an empty skeleton.
- **Input is the standardized JSON, not the discovery table** — the discovery table belongs to CD Codegen (5).
- **Uses `build_gen_eval_hitl`** with `hitl=True`.
- **Idempotency:** plan versioned by iteration.
- **Tests:** generator consumes both JSONs; a mis-shaped or tile-less standardized document raises; evaluator `EvalResult` valid; interrupt is resumable; feedback (P1) overrides base prompt in regeneration; versioned outputs per iteration.

### 9.5 CD code generation agent (5)
- **AI + Python.** Python handles known ops (regex func mapping, agg mapping). Unknown ops → AI translation: **batch multiple lines per chunk, translate line-by-line with examples** (fan-out, pool `cd_translation`). Full code → **evaluator** (suggests changes) → **HITL** where the user picks **which changes to apply per issue**, or keeps as-is.
- **Output contract:** code must be **node-addressable** (keyed per source node/table) so the Classifier can partition into layers. Non-negotiable.
- **Idempotency:** code versioned by iteration.
- **Tests:** known ops mapped without an LLM call; unknown ops routed to AI; translations merge by line index; per-issue apply/keep works; output is node-keyed.

### 9.6 Validation agent (6)
- **Executes PySpark.** Take the generated `.py`, **create a Job and run it**, **wait for the full pipeline to complete** before proceeding. Then run the validations (schema check, row count, column accuracy, statistical profile, reconciliation — all of them) against the original table.
- **AI:** on failures, ask AI for troubleshooting suggestions and likely offending code locations.
- **Idempotency:** validation results keyed by `(dataflow_id, iteration)`; re-run overwrites.
- **HITL:** optional (review failures / accept troubleshooting).
- **Tests:** node blocks until job completion; each check computed correctly on fixtures; failure path produces AI suggestions with code refs; results written to Delta.

### 9.7 Classifier agent (7)
- **AI + executes PySpark.** After validation, an LLM classifies all nodes/tables into **bronze/silver/gold** per medallion rules, driven by **config files** (orgs differ) → **evaluate → HITL** cycle → split generated code into **3 files (bronze/silver/gold)** → run each as pipelines.
- **Config:** medallion-rules config file is mandatory (format TBD by internal teams — [§10](#10-open-items)); users also configure whether all 3 layers run under one job/pipeline or separate ones with separate schedules.
- **Idempotency:** layer assignment + files keyed by `(dataflow_id, iteration)`.
- **Tests:** classification consumes node-keyed CD output; config rules drive assignment; per-issue HITL; code splits cleanly into 3 layer files; pipeline-grouping config honoured.

---

## 10. Open items

- **Medallion-rules config format** — to be designed and reviewed by internal teams; the file *will* exist and drive Classifier assignment. Blueprint reserves the slot (`agents/classifier/config/`).
- **DLT vs multi-task Job** for the final layered pipelines — DLT gives medallion + scheduling knobs but constrains generated code shape. Decide before Classifier execution is built.
- **Cost accounting** in `obs_llm_calls` — pricing source per model/endpoint.

---

## 11. Changing the contracts

`core/` is frozen by convention, not frozen forever. If an accuracy gap between target and current output forces an architectural change:
1. Propose the `core/` change as a reviewed PR (whole-team visibility).
2. Update this document and the affected skill files in the same PR.
3. Bump a `CONTRACTS_VERSION` constant; contract tests assert against it.

The design deliberately isolates volatility: agents depend on `core/` interfaces, so a contract change surfaces as failing contract tests across agents — a feature, not a surprise.
