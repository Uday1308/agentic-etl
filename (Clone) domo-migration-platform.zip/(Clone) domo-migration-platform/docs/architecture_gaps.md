# Architecture gaps — what is missing to complete the flow

Not bugs and not step-count. These are places where the **flow does not yet do what the
design says it does**. Ordered by how much each one costs if left alone.

The pipeline's shape is sound: normalize → build a reviewable *intent* artifact → human
approves the intent → generate code from the approved intent → prove equivalence against
DOMO → organize into layers. Items 1–3c are the parts of that sentence that are not
actually wired.

---

## 1. Human approval does not bind the generated code — BLOCKING

**Today.** `agents/cd_codegen/ports.py:32` states the contract outright:

> Contract (team decision): the plan influences ONLY the AI translation path.
> The deterministic mapping never consults it — the discovery table is the sole
> structural source of truth.

So a reviewer reads 55 steps, approves them, and the generator that produces all 55
outputs never reads that approval. The plan reaches only the AI tail. On 8099 the AI tail
fires **zero times** (55/55 deterministic), so approval currently has *no mechanical
effect on the artifact at all*. Feedback such as "guard the Account Activity fallback with
IFNULL" is layered into a prompt that is never sent.

A gate that does not gate is worse than no gate, because people trust it.

**To complete.** Make the approved plan the *input* to codegen rather than a sibling of
it. Concretely: the plan carries a structured per-step decision block (step id, chosen
translation, hard constraints, accepted issue ids); codegen reads that block and generates
from it, falling back to the tile registry only for steps the plan does not pin. Then
`HumanFeedback.hard_constraints` and `accepted_issue_ids` have a path to the output, and
`DecisionRow` becomes an audit trail of things that actually changed the artifact.

**Also settles** the `source="md"` vs `source="discovery"` split — there is one path.

---

## 2. The plan has two contradictory definitions — BLOCKING

**Today.**

- `agents/md_plan/render.py`: *"Section 5 carries **intent, not code** … CD Codegen then
  generates the artifact from this plan plus the discovery table — it does not extract
  code from here, because there is none."*
- `agents/cd_codegen/md_extract.py`: *"The MD Plan agent now emits fully-formed PySpark per
  step inside the plan document … it extracts the code the plan already contains."*

Both cannot be true. The renderer wins in practice: the real 8099 plan contains **zero**
code fences across 55 step headers. And `md_extract`'s stated producers,
`build_static_sections_v2` / `render_node_from_registry`, **do not exist anywhere in the
repo** — so an entire generation path parses a format nothing produces.

**To complete.** Decide, write it in one place, and delete the loser. If the plan is
intent (recommended — it is what makes a 15-minute review possible), then `md_extract` and
`md_generator` go, and item 1 supplies the binding instead.

---

## 3. The plan carries names but not types — HIGH

**Today.** `output_columns()` returns `list[str]`. The plan states what each step does and
which columns it touches, never what type anything is. Every runtime failure so far has
been a type failure:

| failure | would a typed plan have caught it? |
|---|---|
| `DATATYPE_MISMATCH` on `Invoice_Amount / Oracle_Exchange_Rate` | yes — string operand in arithmetic |
| `coalesce(STRING, INT)` | yes — same |
| `NUM_COLUMNS_MISMATCH` on the 7-branch append | already fixed by name tracing |

The type information exists at ingestion (`Alter Columns` declares casts; source tables
have schemas) and is discarded before the point it is needed.

**To complete.** Carry `name -> type` through the tracer instead of `name`. Two payoffs:
the reviewer approves something machine-checkable, and the coercions currently emitted
defensively (`TRY_CAST` on every arithmetic operand) can be emitted **only where the type
actually requires it**.

---

## 3b. DOMO's export artifact is worked around, never removed — HIGH

**Today.** DOMO's export writes a leading apostrophe on some values (`'-92866.56`).
DOMO's *own output* does not carry it — verified against 8099's `Invoice_Amount`, where
`domo_output` is clean and `migrated_output` is not. So landing the raw export and
reading it as-is produces a migrated table that differs from DOMO on every affected row.

It is worked around in six places and fixed in none of them:

| site | what it does |
|---|---|
| `tiles._CLEAN` | filter comparisons |
| `tiles._CLEAN` | alter-column casts |
| `expr.numeric_operand` | arithmetic operands |
| `expr.numeric_operand` | IFNULL numeric defaults |
| `expr.numeric_operand` | numeric aggregates |
| `adapters.column_stats` | validation profiling |

None of them changes the value written to the output table: a projection carries the
column through untouched and `SELECT *` cannot name it. A per-column strip in the
generated SQL is not possible either — neither the source columns nor the final CTE's
columns are statically traceable (the chain bottoms out at a SOURCE, and only the table
knows its own schema).

**To complete.** Strip it in a **cleaned view** over the raw table, and point
`source_schema` at that view's schema. `source_catalog`/`source_schema` are already
configuration in the generator, the renderer, `local_dryrun` and the notebook, so this is
a config change and not a code change — the transpiler never needs to know a schema, and
the offline dry run keeps working.

```python
from core.contracts.landing import create_clean_views
create_clean_views(spark, "dev_test", "domo_input", "domo_input_clean")
# then generate with source_schema="domo_input_clean"
```

A view, not a cleaned copy, and not a cleanup on the way in: a landed table should stay a
faithful record of what DOMO exported. Bronze is the export as received; mutating it
leaves nowhere to see what actually arrived. The cleanup belongs in the transformation,
which is what a view is. `normalize_landed(df)` remains for a pipeline that would rather
clean on write — the rule is identical either way.

Caveat: a view with an explicit column list does not pick up a new source column, so
`create_clean_views` has to be re-run after a source schema change. It is
`CREATE OR REPLACE`, so re-running is safe.

After that the six workarounds become harmless no-ops rather than the only defence.

**Related, and deliberately not folded in:** `tiles._CLEAN` also strips a trailing
`E-<digits>`. For a string comparison that makes two renderings of one number match;
applied to a value it turns `1.5E-05` into `1.5`. It stays scoped to comparisons.

---

## 3c. Dataset schemas are never pulled, so lineage bottoms out at the sources — HIGH

**Today.** Nothing in the pipeline ever asks DOMO what a dataset's columns are. The raw
export does not carry them: a `LoadFromVault` action holds a `dataSourceId` and an empty
`tables: [{}]`, and the document-level `inputs`/`outputs` hold an id and a name. So
`output_columns()` returns `None` at every SOURCE — correctly, because only the table
knows — and that `None` propagates down the whole chain.

Measured on the two real exports, after the tracer was taught the tile types it was
missing (unpivot, rank, string-calc, dedupe, text, sink):

| dataflow | nodes untraced | derivable but missed | blocked by a source |
|---|---|---|---|
| 8099 | 38 / 71 | 0 | 38 |
| 8774 | 12 / 35 | 0 | 12 |

Every remaining gap is a source. The cost lands in three places:

* **Logic parity** (`core/contracts/logic_parity.py`) reports `unverifiable` rather than
  `pass` on three of nine targets — it cannot check a column reference whose upstream
  column set is unknown, and `unverifiable` is deliberately not counted as a pass.
* **The dynamic unpivot** escalates whenever its value columns trace back to a source
  rather than to a tile that states its own output (`resolve_dynamic_columns`).
* **Nothing knows the target's types**, which is why the alter-columns path emits
  defensive `TRY_CAST` everywhere (item 3) and why a closing cast-to-expected-type
  projection cannot be generated at all.

**To complete.** Pull the schema of each **dataset** — not each tile — during Discovery,
and write it into the discovery table. The scope is small because datasets are few:
8099 is 10 inputs + 6 outputs against 71 tiles; 8774 is 3 + 3 against 35.

Discovery is the right layer: it runs once per dataflow, it is already the estate
catalogue every later agent reads, and `agents/connection/ports.py` already defines the
`DomoClient` seam — this is a third method (`fetch_dataset_schema`) on a port that
exists, not a new integration.

Store it as its own record type (`record_type: "SCHEMA"`) rather than as extra columns on
the NODE rows. A dataset schema is not a property of a tile, and several tiles can
reference one dataset; hanging it off NODE duplicates it and invites the two copies to
disagree.

Three payoffs, in order of value:

1. `output_columns()` seeds sources from the catalogue instead of returning `None`, and
   the tracer runs end to end. Logic parity goes to fully verified.
2. **Output-column parity becomes possible**: DOMO's actual output columns against the
   columns the generated SQL produces — same set, same spelling, same order. That is
   verification of the *result*, computed without running either engine, and it is the
   closest thing to data parity available for free.
3. Types arrive with the names, which is the prerequisite for item 3.

**Watch for.** The schema is a snapshot. A source that gains a column after discovery ran
will disagree with the catalogue, so a run must record which `discovery_run_id` its
schema came from — otherwise a stale schema silently becomes a wrong lineage verdict,
which is worse than the `unverifiable` it replaced.

**Not this.** Deriving the expected column set from the generated SQL's own SELECT lists.
It reads like the same idea and proves nothing: checking the SQL against expectations
derived from that SQL agrees by construction. The signal in logic parity comes from two
*independent* derivations — DOMO's graph says what should exist, the artifact says what
does. Tracking columns through the CTEs is worth doing for display, and worth keeping out
of the verification path.

---

## 4. `AGENT_DEFAULTS` contradicts the agents' own contracts — MEDIUM

**Today.** `agents/master.py`:

```python
"standardization": {"ai_gen": True,  "ai_review": True,  "hitl": False},
"discovery":       {"ai_gen": False, "ai_review": False, "hitl": True},
```

- Standardization has an LLM generator **and** an LLM reviewer on a stage whose entire
  transform is `to_planner_dataflow()`, a pure function. `_one_chunk` awaits a model call
  and returns its input unchanged.
- Discovery has a **HITL gate**, but `docs/discovery.skill.md` says *"no HITL"*. A HITL
  gate is the most expensive thing in a pipeline — it stops for a human.

**To complete.** `standardization: ai_gen False, ai_review False`. `discovery: hitl False`.
Then reconcile whether standardization is a stage at all or a fold at read time.

---

## 5. AI evaluation on deterministic output earns nothing — MEDIUM

**Today.** `cd_codegen` runs an LLM evaluator over generated SQL. Across six real defects
found while testing 8099, the AI evaluator (`verdict: revise, confidence 0.92`) caught
**none**. Four were caught by Spark, two by eye. The deterministic gates — tile-registry
escalation, `SqlAssemblyError`, the judge panel (`STR001`–`POL001`) — caught real things.

**To complete.** Keep the LLM evaluator where output is prose and not checkable
deterministically (the **plan**) and over **AI-written tail steps**. Drop it from
deterministic codegen; put EXPLAIN + parity in its place as the gate.

---

## 6. Three representations of one graph — MEDIUM

**Today.** The dataflow's structure exists as raw DOMO JSON, standardized JSON, and
discovery rows, with four normalizers (`normalize_rows`, `to_dataflow`,
`to_planner_dataflow`, `rows_to_ir`) and two independent column-alias tables
(`core/contracts/discovery.py`, `agents/cd_codegen/ports.py`) that have already drifted.

The discovery **table** now has exactly one consumer — the PySpark codegen path. A plan
built from it and a plan built from the standardized JSON are byte-identical.

**To complete.** Keep the discovery table as a cross-dataflow **inventory** (it is the only
thing that answers "which of my 400 dataflows use tiles we cannot transpile"). Take it off
the codegen critical path. One alias table, in the contract.

---

## 7. Validation cost on large tables — MEDIUM

**Today.** Parity compares migrated output against DOMO's. On real tables a full compare is
the most expensive thing in the pipeline.

**To complete.** Tier it: row count + per-numeric-column sum/min/max + distinct counts on
keys, then sampled row hashes, then full compare only on demand. The `as_of` clamp already
exists to make any of these reproducible.

---

## 8. Smaller, but real

- **`tests/test_domo_tiles.py` is a stale duplicate** of `tests/contracts/test_domo_tiles.py`
  (34 passing). Five of its tests fail and now contradict the passing copy.
- **`scripts/local_dryrun.py` still owns production logic** — `parity_sql`, `report`,
  `normalize` — in a file its own docstring calls deletable. `build_sql` was moved out; the
  rest should follow.
- **CASE branches mixing a bare column with a numeric expression** (two in 8099,
  `GL_Amount` / `CMS_Matrix_Amount`) will hit the same ANSI type resolution as item 3.
  Item 3 fixes this properly; a heuristic would misfire on a CASE that legitimately returns
  text.
- **LLM traces are reportedly unreadable.** `LlmCallRow` carries everything needed
  (`prompt_hash`, `tokens_*`, `cost_usd`, `latency_ms`, `attempt`, `status`, `error`); the
  gap is presentation, not capture.
