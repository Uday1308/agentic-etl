# SKILL: Standardization Agent (2) — addendum to core.domo.skill.md

**AI + Python.** Canonical reference: the existing standalone chunk-processing standardizer. Chunk → standardize (fan-out) → evaluator + JSON validator → write.

## Contract
- **In:** pending files from ETL master (by `dataflow_id`), the raw DOMO JSON.
- **Out:** standardized JSON at the volume path (overwrite per dataflow/file), in the shape below — id-keyed, tiles under `actions`, edges under `connections`.
- **No HITL.** Quality gate = evaluator agent **+** deterministic JSON validator.

## Rules
- Chunk processing fans out over pool `standardization_chunks` (cap 6). Store chunk results in the reducer-backed collection keyed by chunk index — **merge, not overwrite**.
- The shape is **not** re-derived here: validate with `core.contracts.standardized.validate_standardized`, which both this agent and its consumers share.
- Standardizing is **additive**: fields this agent does not rewrite (`inputs`, `outputs`, `name`, ...) are carried through verbatim.
- Evaluator returns `EvalResult`. The **JSON validator is deterministic** (schema/shape/data-intact check) and is separate from the LLM evaluator — both must pass.
- Role for the LLM standardizer: `generator`; role for the evaluator: `evaluator`.
- Idempotent overwrite of the standardized file.

## Tests (contracts/)
- chunk fan-out merges by index (no lost chunks under concurrency);
- deterministic JSON validator rejects malformed / lossy output;
- evaluator returns valid `EvalResult`;
- standardized output conforms to the required schema;
- idempotent re-run;
- untouched document fields survive chunking;
- an empty `actions` list is rejected (it yields a plan with no steps).

## Document shape

Defined once in `core/contracts/standardized.py`; every producer and consumer folds
through that module rather than reading keys by hand.

```json
{"8099": {"id": 8099, "name": "cms", "database_type": "MySQL", "deleted": false,
          "responsible_user_id": 1650988277,
          "inputs":  [{"dataSourceId": "...", "dataSourceName": "..."}],
          "outputs": [{"dataSourceId": "...", "dataSourceName": "..."}],
          "actions": [{"id": "...", "name": "Add Formula 1", "type": "formula",
                       "logic": {"expressions": [...]}}],
          "connections": [{"from": "<action id>", "to": "<action id>"}],
          "disabled_skipped": []}}
```

Keyed by dataflow id — a file may hold more than one. `actions` are the tiles,
`connections` the edges, and `logic` is the tool-specific payload `core.domo.tiles`
interprets per tile type. `to_planner_dataflow()` folds this into the
`{"dataflow_id", "nodes", "edges"}` form the renderer and tile registry read, carrying
`logic` through as `properties` — the mirror of `discovery.to_dataflow()`, which folds
discovery *rows* into the same shape.

