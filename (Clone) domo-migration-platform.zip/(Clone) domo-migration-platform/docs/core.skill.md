# SKILL: DOMO→PySpark Migration — Shared Core

**Read this before writing any component.** It is the mandatory contract every agent obeys. Pair it with the agent-specific skill in `skills/<agent>.skill.md`. Stack: Python 3.11, LangGraph. If a rule here conflicts with your instinct, follow the rule — consistency across the team depends on it.

## Golden rules (do not break)
1. **Never call a serving endpoint directly.** The only LLM entry point is `core.domo.llm.complete(role=..., pool=...)`. Raw HTTP / SDK serving calls are forbidden (they bypass observability + concurrency).
2. **Nodes are idempotent.** Key every durable write by `(dataflow_id, node, iteration)`. Re-running a node overwrites the same target. No appends that duplicate on replay.
3. **Nodes return a state delta**, never mutate `state` in place. `def node(state, config) -> dict`.
4. **Ask for a role, not a model.** `generator | evaluator | classifier | …`. Model binding lives in `core/models.py`.
5. **Never hand-format a prompt.** Fill `PromptLayers`; `core.domo.prompts` assembles it with priority order.
6. **Fan-out fields merge, never overwrite.** Use the reducer-backed collections in `core/state.py`, keyed by chunk/line index.
7. **Acquire a named concurrency pool** for parallel LLM calls; never spawn unbounded tasks.
8. **Don't touch `core/`.** You implement inside `agents/<name>/`. A `core/` change is a blueprint change.
9. **Don't write ETL-master status from anywhere except the Connection node.** Checkpoint and ETL master are separate stores.

## Writing a node
```python
from core.domo.nodes import node_harness   # emits the per-node obs row, times it

@node_harness(agent="cd_codegen", name="translate")
def translate(state: RunState, config: RunnableConfig) -> dict:
    # 1. read only your namespaced sub-state: state["cd_codegen"]
    # 2. do work; all durable writes keyed by (dataflow_id, node, iteration)
    # 3. return a partial dict delta, e.g. {"cd_codegen": {...}}
    ...
```
- Must be safe to replay after a crash mid-step.
- Exactly one durable target per (dataflow_id, node, iteration).
- The harness writes `obs_nodes`; you do nothing extra for per-node observability.

## Calling the LLM
```python
from core.domo.llm import complete
res = complete(
    role="generator",
    layered_prompt=state["prompt_layers"]["md_plan"],
    pool="cd_translation",              # a named pool from core/concurrency.py
    response_schema=EvalResult,         # optional structured output
    config=config,
)
```
- Observability (tokens, latency, cost, prompt hash, confidence) is written inside `complete`. Do not log calls yourself.
- Structured output: pass `response_schema`; you get a parsed object back.

## Prompt-priority layering
Fill the four layers; the assembler enforces precedence. **P1 Human feedback > P2 User prompt > P3 Agent feedback > P4 Base prompt.**
```python
from core.domo.prompts import PromptLayers
layers = PromptLayers(
    base=BASE_PROMPT,                          # P4, your hardcoded instruction
    agent_feedback=eval_result.issues,         # P3
    user_prompt=state[...]["user_prompt"],     # P2
    human_feedback=state["feedback"]["md_plan"],  # P1, accumulated list
    hard_constraints=collect_hard_constraints(state),  # enforced by post-check
)
```
- Hard constraints ("never do X") are enforced **deterministically** after generation — a violation forces regeneration/failure. Do not rely on the model obeying prose alone.
- Human feedback is an **accumulating list**; pass the whole history, not just the latest.

## generate → evaluate → HITL
If your agent is generate/eval/HITL shaped (standardization, md_plan, cd_codegen, classifier), **do not hand-roll the loop** — inject into the factory:
```python
from core.domo.nodes import build_gen_eval_hitl
subgraph = build_gen_eval_hitl(
    name="md_plan",
    generator=generate_plan,        # (state, config) -> GenResult
    evaluator=evaluate_plan,        # (GenResult, state) -> EvalResult  (or None)
    apply_feedback=merge_feedback,  # (GenResult, list[HumanFeedback]) -> GenResult
    hitl=True,
    max_iters=3,
)
```
HITL parks the run via `interrupt()` and resumes via `Command(resume=HumanFeedback(...))`. Iteration increments on regeneration; outputs are versioned per iteration.

## Schemas you must use
- **Return `EvalResult`** from every evaluator: `verdict (pass|revise|fail)`, `confidence 0..1`, `issues[] (severity, ref, message, suggested_fix)`, `summary`. `ref` must be node/table/line-addressable.
- **Consume `HumanFeedback`** on resume: `accepted_issue_ids`, `rejected_issue_ids`, `freeform`, `hard_constraints`, `ts`.

## Concurrency
- Pools: `standardization_chunks` (6), `cd_translation` (8), `evaluation` (4), `classification` (2); global ceiling 16. All in `config/`.
- Acquire by name inside `complete`; never exceed the global ceiling; never start unbounded fan-out.

## Mandatory contract tests (must pass in CI, LLM mocked)
Put in `agents/<name>/tests/` (mirrored into `tests/contracts/`):
- returns a schema-valid state delta; no in-place mutation;
- idempotent: run twice → identical durable target;
- reads/writes the correct table/volume with the correct key;
- uses `core.domo.llm.complete` (assert via mock) — no raw endpoint;
- prompt assembly respects priority; hard-constraint post-check rejects a violation;
- evaluators return valid `EvalResult`; HITL nodes produce a resumable interrupt and consume `HumanFeedback`;
- fan-out fields merge by index.
Quality/accuracy tests go in `tests/eval/` and **do not** gate CI.

## Do / Don't
- ✅ Small, idempotent, single-responsibility nodes.  ❌ God-nodes with hidden side effects.
- ✅ Role-based LLM calls via the wrapper.  ❌ Model names or endpoints in agent code.
- ✅ Reducer merges for parallel work.  ❌ Last-write-wins on fan-out.
- ✅ Structured feedback objects.  ❌ Free-text state you can't test.
- ✅ Fail loud on contract violations.  ❌ Silent fallbacks that hide integration breaks.
