# SKILL: Validation Agent (6) — addendum to core.domo.skill.md

**Executes PySpark via a Job, then validates, then AI-troubleshoots failures.**

## Contract
- **In:** the generated `.py` (node-keyed), original table refs, `(dataflow_id, iteration)`.
- **Out:** validation results in Delta, keyed by `(dataflow_id, iteration)` (overwrite on re-run).
- **HITL:** optional (review failures / accept troubleshooting).

## Rules
- **Jobs-as-a-tool:** create a Databricks Job from the generated code, launch it, and **poll to completion — block until the whole pipeline finishes** before validating. The graph node owns control flow; the Job owns Spark.
- Run **all** validations against the original table: schema check, row count, column accuracy, statistical profile, reconciliation.
- On any failure: call the LLM (`role="evaluator"` or a dedicated troubleshooting role) for suggested fixes **with code-location refs**.
- Idempotent: re-running overwrites the results for that `(dataflow_id, iteration)`; launching the job must not double-run (guard by key).

## Tests (contracts/)
- node blocks until job completion (mock the job runner);
- each check computed correctly on fixtures;
- failure path yields AI suggestions with code refs;
- results written to Delta with the right key; idempotent re-run.
