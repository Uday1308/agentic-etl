import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  Activity, AlertTriangle, ArrowRight, Boxes, Check, ChevronDown, ChevronRight,
  CircleDollarSign, Clock, Code2, Cpu, Database, Eye, FileCode2, Filter,
  GitBranch, Layers, LayoutGrid, Pause, Play, RefreshCw, Search, Settings2,
  SquareStack, Terminal, TrendingUp, UserCheck, X, Zap, Bot, Brain,
  ShieldCheck, CircleSlash, Plus, ListChecks, Radio
} from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis
} from "recharts";

/* ============================================================================
   LatentView · DOMO → Databricks Migration Control Tower
   Brand: #1D57AB Fun Blue · white · #696D6E
   ========================================================================== */

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&family=Inter:wght@400;450;500;600&display=swap');

.lv{
  --abyss:#050B16;--ink:#0A1628;--slate:#101E33;--line:#1B2E4A;--line-2:#254066;
  --brand:#1D57AB;--azure:#3B8FE8;--ice:#7FD4F5;--glow:#9BE4FF;
  --paper:#EAF2FB;--muted:#8397B0;--dim:#5B6E88;
  --pass:#34D399;--warn:#FBBF24;--fail:#FB7185;--ai:#C084FC;
  --d:cubic-bezier(.22,.61,.36,1);
  background:var(--abyss);color:var(--paper);font-family:'Inter',system-ui,sans-serif;
  font-size:14px;line-height:1.5;min-height:100vh;-webkit-font-smoothing:antialiased}
.lv *{box-sizing:border-box}
.lv h1,.lv h2,.lv h3,.lv h4,.lv .disp{font-family:'Space Grotesk',sans-serif;letter-spacing:-.02em;margin:0}
.lv .mono{font-family:'JetBrains Mono',monospace}
.lv button{font-family:inherit}

.lv-bg{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden}
.lv-bg::before{content:'';position:absolute;inset:0;
  background:radial-gradient(1100px 600px at 18% -10%,rgba(29,87,171,.30),transparent 60%),
             radial-gradient(900px 500px at 105% 8%,rgba(59,143,232,.14),transparent 55%),
             radial-gradient(700px 700px at 50% 120%,rgba(127,212,245,.06),transparent 60%)}
.lv-bg::after{content:'';position:absolute;inset:0;opacity:.32;
  background-image:linear-gradient(rgba(37,64,102,.2) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(37,64,102,.2) 1px,transparent 1px);
  background-size:64px 64px;mask-image:radial-gradient(ellipse 80% 60% at 50% 0%,#000 30%,transparent 75%)}

.lv-boot{position:fixed;inset:0;z-index:100;background:var(--abyss);display:flex;
  flex-direction:column;align-items:center;justify-content:center;gap:26px}
.lv-boot.out{animation:bootOut .7s var(--d) forwards}
@keyframes bootOut{to{opacity:0;transform:scale(1.04);visibility:hidden}}
.lv-mark{position:relative;width:88px;height:88px}
.lv-mark svg{position:absolute;inset:0}
.lv-ring{transform-origin:center;animation:spin 3.2s linear infinite}
.lv-ring-2{transform-origin:center;animation:spin 2.1s linear infinite reverse}
@keyframes spin{to{transform:rotate(360deg)}}
.lv-boot-bar{width:330px;height:2px;background:var(--line);border-radius:2px;overflow:hidden}
.lv-boot-fill{height:100%;background:linear-gradient(90deg,var(--brand),var(--ice));animation:fill 2.3s var(--d) forwards}
@keyframes fill{from{width:0}to{width:100%}}
.lv-boot-log{width:330px;height:78px;overflow:hidden}
.lv-fade{display:flex;gap:9px;align-items:center;font-size:11.5px;color:var(--dim);animation:lineIn .45s var(--d) backwards}
@keyframes lineIn{from{opacity:0;transform:translateY(6px)}}

.lv-shell{position:relative;z-index:1;display:flex;min-height:100vh}
.lv-nav{width:212px;flex-shrink:0;border-right:1px solid var(--line);position:sticky;top:0;height:100vh;
  background:linear-gradient(180deg,rgba(10,22,40,.92),rgba(5,11,22,.78));backdrop-filter:blur(12px);
  display:flex;flex-direction:column}
.lv-navitem{display:flex;align-items:center;gap:11px;padding:9px 14px;margin:1px 10px;border-radius:8px;
  color:var(--muted);cursor:pointer;font-size:13px;transition:all .18s var(--d);position:relative;border:1px solid transparent}
.lv-navitem:hover{color:var(--paper);background:rgba(59,143,232,.08)}
.lv-navitem.on{color:var(--paper);background:linear-gradient(90deg,rgba(29,87,171,.34),rgba(29,87,171,.06));border-color:rgba(59,143,232,.28)}
.lv-navitem.on::before{content:'';position:absolute;left:-10px;top:50%;transform:translateY(-50%);
  width:3px;height:17px;border-radius:0 3px 3px 0;background:var(--ice);box-shadow:0 0 12px var(--ice)}
.lv-main{flex:1;min-width:0;display:flex;flex-direction:column}
.lv-top{height:56px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:14px;
  padding:0 20px;background:rgba(5,11,22,.72);backdrop-filter:blur(12px);position:sticky;top:0;z-index:20}
.lv-body{padding:22px;flex:1;animation:viewIn .4s var(--d)}
@keyframes viewIn{from{opacity:0;transform:translateY(9px)}}

.lv-card{background:linear-gradient(160deg,rgba(16,30,51,.86),rgba(10,22,40,.7));border:1px solid var(--line);
  border-radius:13px;position:relative;overflow:hidden;transition:border-color .22s var(--d),transform .22s var(--d),box-shadow .22s var(--d)}
.lv-card.hov:hover{border-color:var(--line-2);transform:translateY(-2px);box-shadow:0 14px 40px -18px rgba(0,0,0,.85)}
.lv-sheen::after{content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,rgba(127,212,245,.5),transparent)}
.lv-chip{display:inline-flex;align-items:center;gap:5px;padding:2.5px 8px;border-radius:5px;font-size:10.5px;
  font-weight:600;letter-spacing:.04em;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border:1px solid}
.lv-btn{display:inline-flex;align-items:center;gap:7px;padding:7px 13px;border-radius:8px;font-size:12.5px;
  font-weight:550;cursor:pointer;border:1px solid var(--line-2);background:rgba(29,87,171,.13);color:var(--paper);
  transition:all .18s var(--d)}
.lv-btn:hover:not(:disabled){background:rgba(59,143,232,.24);border-color:var(--azure);transform:translateY(-1px)}
.lv-btn:disabled{opacity:.4;cursor:not-allowed}
.lv-btn.pri{background:linear-gradient(135deg,var(--brand),#2E74C9);border-color:transparent;box-shadow:0 4px 18px -6px rgba(29,87,171,.9)}
.lv-btn.ghost{background:transparent}
.lv-btn.sm{padding:4px 9px;font-size:11.5px}
.lv-btn:focus-visible,.lv-navitem:focus-visible,.lv-tab:focus-visible{outline:2px solid var(--ice);outline-offset:2px}

.lv-rail{position:relative;padding:24px 6px 10px}
.lv-track{position:absolute;left:0;right:0;top:50px;height:2px;background:var(--line)}
.lv-track-lit{position:absolute;left:0;top:0;height:100%;background:linear-gradient(90deg,var(--brand),var(--ice));
  transition:width 1s var(--d);box-shadow:0 0 14px rgba(127,212,245,.7)}
.lv-packet{position:absolute;top:-3px;width:8px;height:8px;border-radius:50%;background:var(--glow);
  box-shadow:0 0 12px 3px rgba(155,228,255,.85);animation:travel 3.4s linear infinite}
@keyframes travel{0%{left:0;opacity:0}8%{opacity:1}92%{opacity:1}100%{left:100%;opacity:0}}
.lv-stage{position:relative;z-index:2;display:flex;flex-direction:column;align-items:center;gap:8px;flex:1;cursor:pointer}
.lv-node{width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;
  border:1px solid var(--line-2);background:var(--ink);transition:all .3s var(--d);position:relative}
.lv-stage:hover .lv-node{transform:translateY(-3px) scale(1.06)}
.lv-node.done{border-color:rgba(52,211,153,.55);background:rgba(52,211,153,.11);color:var(--pass)}
.lv-node.running{border-color:var(--ice);background:rgba(127,212,245,.13);color:var(--glow);animation:pn 1.9s ease-in-out infinite}
.lv-node.review{border-color:rgba(251,191,36,.6);background:rgba(251,191,36,.12);color:var(--warn);animation:ph 1.4s ease-in-out infinite}
.lv-node.failed{border-color:rgba(251,113,133,.6);background:rgba(251,113,133,.12);color:var(--fail)}
.lv-node.pending{color:var(--dim)}
@keyframes pn{0%,100%{box-shadow:0 0 0 0 rgba(127,212,245,.42)}50%{box-shadow:0 0 0 11px rgba(127,212,245,0)}}
@keyframes ph{0%,100%{box-shadow:0 0 0 0 rgba(251,191,36,.5)}50%{box-shadow:0 0 0 10px rgba(251,191,36,0)}}
.lv-node.running::after{content:'';position:absolute;inset:-5px;border-radius:15px;
  border:1px solid rgba(127,212,245,.3);border-top-color:transparent;animation:spin 1.6s linear infinite}

.lv-hero{display:flex;flex-direction:column;align-items:center;gap:16px;padding:34px 20px}
.lv-orb{position:relative;width:112px;height:112px;display:flex;align-items:center;justify-content:center}
.lv-orb svg.r1{position:absolute;inset:0;animation:spin 5s linear infinite}
.lv-orb svg.r2{position:absolute;inset:12px;animation:spin 3.2s linear infinite reverse}
.lv-orb-core{width:56px;height:56px;border-radius:17px;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(150deg,rgba(59,143,232,.3),rgba(29,87,171,.12));border:1px solid rgba(127,212,245,.4);
  color:var(--glow);animation:breathe 2.6s ease-in-out infinite}
@keyframes breathe{0%,100%{transform:scale(1);box-shadow:0 0 22px -4px rgba(127,212,245,.5)}
  50%{transform:scale(1.06);box-shadow:0 0 40px -2px rgba(127,212,245,.8)}}
.lv-phase{font-size:19px;font-weight:600;font-family:'Space Grotesk',sans-serif;animation:phaseIn .45s var(--d)}
@keyframes phaseIn{from{opacity:0;transform:translateY(7px) scale(.98)}}
.lv-dots::after{content:'';animation:dots 1.4s steps(4,end) infinite}
@keyframes dots{0%{content:''}25%{content:'.'}50%{content:'..'}75%{content:'...'}}
.lv-sub{display:flex;gap:7px;align-items:center;font-size:11.5px;color:var(--dim)}

.lv-row{border-bottom:1px solid rgba(27,46,74,.6);transition:background .16s var(--d);cursor:pointer}
.lv-row:hover{background:rgba(59,143,232,.07)}
.lv-bar-t{height:5px;background:var(--line);border-radius:99px;overflow:hidden}
.lv-bar-f{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--brand),var(--ice));transition:width .7s var(--d)}
.lv-code{background:rgba(5,11,22,.7);border:1px solid var(--line);border-radius:10px;
  font-family:'JetBrains Mono',monospace;font-size:11.5px;line-height:1.75;overflow:auto}
.lv-cell{border-bottom:1px solid rgba(27,46,74,.5)}
.lv-cell-h{display:flex;align-items:center;gap:9px;padding:7px 12px;cursor:pointer;background:rgba(16,30,51,.5);transition:background .16s var(--d)}
.lv-cell-h:hover{background:rgba(59,143,232,.09)}
.lv-in{background:rgba(5,11,22,.6);border:1px solid var(--line-2);border-radius:8px;padding:8px 11px;
  color:var(--paper);font-size:12.5px;width:100%;font-family:inherit;transition:border-color .18s var(--d)}
.lv-in:focus{outline:none;border-color:var(--azure);box-shadow:0 0 0 3px rgba(59,143,232,.14)}
.lv-stagger>*{animation:cardIn .5s var(--d) backwards}
@keyframes cardIn{from{opacity:0;transform:translateY(13px)}}
.lv-dot{width:6px;height:6px;border-radius:50%;background:var(--pass);box-shadow:0 0 8px var(--pass);animation:blink 1.9s ease-in-out infinite}
@keyframes blink{50%{opacity:.35}}
.lv-tab{padding:8px 14px;font-size:12.5px;cursor:pointer;color:var(--muted);border:none;
  border-bottom:2px solid transparent;transition:all .18s var(--d);background:none}
.lv-tab:hover{color:var(--paper)}
.lv-tab.on{color:var(--paper);border-bottom-color:var(--ice)}
.lv-sw{width:34px;height:19px;border-radius:99px;border:1px solid var(--line-2);background:rgba(5,11,22,.7);
  position:relative;cursor:pointer;transition:all .2s var(--d);flex-shrink:0}
.lv-sw.on{background:rgba(29,87,171,.55);border-color:var(--azure)}
.lv-sw::after{content:'';position:absolute;top:2px;left:2px;width:13px;height:13px;border-radius:50%;
  background:var(--muted);transition:all .2s var(--d)}
.lv-sw.on::after{left:17px;background:var(--glow);box-shadow:0 0 8px var(--glow)}
.lv-step{display:flex;align-items:center;gap:9px;font-size:12.5px;color:var(--dim)}
.lv-step.on{color:var(--paper)}
.lv-stepn{width:23px;height:23px;border-radius:50%;border:1px solid var(--line-2);display:flex;
  align-items:center;justify-content:center;font-size:11px;font-family:'JetBrains Mono',monospace}
.lv-step.on .lv-stepn{border-color:var(--ice);background:rgba(127,212,245,.14);color:var(--glow)}
.lv-step.did .lv-stepn{border-color:var(--pass);background:rgba(52,211,153,.14);color:var(--pass)}
.lv-scroll::-webkit-scrollbar{width:9px;height:9px}
.lv-scroll::-webkit-scrollbar-thumb{background:var(--line-2);border-radius:9px}
.lv-scroll::-webkit-scrollbar-track{background:transparent}
.lv-pick{border:1px solid var(--line);border-radius:10px;padding:11px 13px;cursor:pointer;
  transition:all .18s var(--d);background:rgba(5,11,22,.4)}
.lv-pick:hover{border-color:var(--line-2);background:rgba(59,143,232,.07)}
.lv-pick.on{border-color:var(--azure);background:rgba(29,87,171,.18)}

@media (prefers-reduced-motion:reduce){.lv *,.lv *::before,.lv *::after{animation:none!important;transition-duration:.01ms!important}}
@media (max-width:980px){.lv-nav{width:60px}.lv-navlabel{display:none}.lv-body{padding:14px}}
`;

/* ============================== domain ============================== */

const AGENTS = [
  { id: "connection", short: "CON", name: "Connection", icon: Database,
    desc: "Authenticates DOMO and lists the datasets in scope.",
    phases: ["Authenticating", "Listing datasets", "Caching metadata"], ai: false, review: false, hitl: false },
  { id: "standardization", short: "STD", name: "Standardization", icon: Layers,
    desc: "Normalizes raw DOMO artifacts into a common shape.",
    phases: ["Reading raw artifacts", "Normalizing schema", "Deduplicating revisions"], ai: false, review: false, hitl: false },
  { id: "discovery", short: "DSC", name: "Discovery", icon: GitBranch,
    desc: "Extracts nodes, configs and lineage into the discovery table.",
    phases: ["Understanding dataflow", "Extracting nodes", "Resolving lineage", "Writing discovery table"], ai: false, review: false, hitl: true },
  { id: "md_plan", short: "PLN", name: "MD Plan", icon: FileCode2,
    desc: "Writes the migration plan and translates every tile to PySpark.",
    phases: ["Understanding tiles", "Context engineering", "Translating expressions", "Rendering plan", "Evaluating"], ai: true, review: true, hitl: true },
  { id: "cd_codegen", short: "GEN", name: "CD Codegen", icon: Code2,
    desc: "Turns the approved plan into a node-addressable notebook.",
    phases: ["Reading approved plan", "Extracting code", "Context engineering", "Assembling notebook", "Evaluating"], ai: true, review: true, hitl: true },
  { id: "validation", short: "VAL", name: "Validation", icon: ShieldCheck,
    desc: "Parses, executes and checks parity against DOMO output.",
    phases: ["Loading artifact", "Parsing syntax", "Running row parity", "Comparing schemas", "Evaluating"], ai: true, review: true, hitl: true },
  { id: "classifier", short: "CLS", name: "Classifier", icon: SquareStack,
    desc: "Splits node sections across the medallion layers.",
    phases: ["Reading node sections", "Classifying layers", "Writing manifest"], ai: true, review: false, hitl: false },
];
const AGENT_BY_ID = Object.fromEntries(AGENTS.map((a) => [a.id, a]));

const ISSUE_BANK = {
  discovery: [
    { sev: "minor", node: "node_4f2a", title: "Two tiles share a display name", detail: "Both are called “Filter Rows”. Node ids are distinct so codegen is unaffected, but the plan will read ambiguously." },
  ],
  md_plan: [
    { sev: "major", node: "s54", title: "CASE fallback drops the null guard", detail: "The Account Activity branch references the column without IFNULL, so union-introduced nulls propagate into the summary table." },
    { sev: "minor", node: "s39", title: "Union order differs from the DOMO tile", detail: "Append Rows 1 lists the frames in a different sequence than the source tile. Row order is not guaranteed either way, but reviewers expect a match." },
    { sev: "info", node: "s19", title: "Dynamic unpivot hardcodes id columns", detail: "The stack expression pins four id fields. If the source feed gains a column it will be treated as a value column." },
  ],
  cd_codegen: [
    { sev: "major", node: "df_join_data_4_s37", title: "Left join can duplicate rows", detail: "Join keys (Currency, Period End Date) are not unique in the right frame after the unpivot. Verify a dedupe before joining." },
    { sev: "minor", node: "df_append_rows_2_s52", title: "unionByName may mask schema drift", detail: "allowMissingColumns=True hides added columns across seven upstream frames. Consider asserting the column set first." },
    { sev: "info", node: "write_na_f_a_cms_post_close", title: "Overwrite without partition scope", detail: "Full-table overwrite is faithful to DOMO REPLACE, but replaceWhere on the period partition would shorten the write." },
  ],
  validation: [
    { sev: "major", node: "df_group_by_3_s45", title: "Row count differs by 412", detail: "DOMO reports 18,204 rows; the migrated frame returns 17,792. The gap traces to the filter on Paying Company." },
    { sev: "minor", node: "df_alter_columns_2_s26", title: "Decimal precision widened", detail: "Cast to DecimalType() without precision defaults to (10,0) in Spark. DOMO carried two decimal places." },
  ],
};

const CELLS = [
  { id: "na_f_a_plant_payments_payables_cms_rec_feed_df", op: "SOURCE", origin: "md",
    code: `na_f_a_plant_payments_payables_cms_rec_feed_df = spark.read.table(\n    "dev_test.domo_bronze.na_f_a_plant_payments_payables_cms_rec_feed"\n)\n# DOMO dataset: NA | F&A | Plant Payments (Payables) - CMS Rec | FEED` },
  { id: "df_join_data_2_s01", op: "JOIN", origin: "md",
    code: `_left = na_f_a_plant_payments_payables_cms_rec_feed_df.alias('left')\n_right = na_f_a_plant_payment_company_mapping_for_cms_rec_feed_df.alias('right')\ndf_join_data_2_s01 = _left.join(\n    _right,\n    (F.col('left.\`Supplier\`') == F.col('right.\`Company Name\`')),\n    'left',\n)` },
  { id: "df_add_formula_1_s03", op: "FORMULA", origin: "md",
    code: `df_add_formula_1_s03 = (\n    na_f_a_plant_ic_for_plug_calc_temp_df\n    .withColumn('Period End Date',\n        # DOMO : LAST_DAY(\`Date\`)\n        F.last_day(F.col('Date')))\n)` },
  { id: "df_risk_score_s21", op: "CUSTOM", origin: "ai",
    code: `# translated from plan prose — review before promoting\ndf_risk_score_s21 = (\n    df_alter_columns_4_s21\n    .withColumn('risk_band',\n        F.when(F.col('\`AP FX Gain/Loss\`') > F.lit(0), F.lit('gain'))\n         .otherwise(F.lit('loss')))\n)` },
  { id: "write_na_f_a_cms_post_close", op: "WRITE", origin: "md",
    code: `(\n    df_add_formula_13_s54\n    .write.format('delta').mode('overwrite')\n    .option('delta.columnMapping.mode', 'name')\n    .saveAsTable('dev_test.migrated_output.na_f_a_cms_post_close_summary')\n)` },
];

const DATAFLOWS = [
  { id: "8099", name: "CMS Reconciliation", app: "cms", nodes: 71, tiles: 55 },
  { id: "8842", name: "Plant Payments Rollup", app: "cms", nodes: 34, tiles: 28 },
  { id: "4127", name: "IC Netting Matrix", app: "cms", nodes: 44, tiles: 37 },
  { id: "7710", name: "GL Detail Post-Close", app: "fin", nodes: 52, tiles: 44 },
  { id: "5540", name: "Oracle FX Rates", app: "fin", nodes: 19, tiles: 14 },
  { id: "6301", name: "DNJP Remittance Feed", app: "ops", nodes: 28, tiles: 21 },
];

const THROUGHPUT = [
  { t: "00", runs: 2, cost: 3.1 }, { t: "03", runs: 1, cost: 1.4 }, { t: "06", runs: 4, cost: 6.8 },
  { t: "09", runs: 9, cost: 14.2 }, { t: "12", runs: 12, cost: 19.6 }, { t: "15", runs: 8, cost: 13.1 },
  { t: "18", runs: 6, cost: 9.4 }, { t: "21", runs: 3, cost: 4.7 },
];
const LATENCY = [
  { t: "00", p50: 620, p95: 1840 }, { t: "03", p50: 580, p95: 1620 }, { t: "06", p50: 710, p95: 2240 },
  { t: "09", p50: 940, p95: 3120 }, { t: "12", p50: 1180, p95: 3860 }, { t: "15", p50: 860, p95: 2680 },
  { t: "18", p50: 690, p95: 2010 }, { t: "21", p50: 640, p95: 1770 },
];
const COST_BY_AGENT = [
  { agent: "MD Plan", v: 128.4 }, { agent: "CD Codegen", v: 74.2 }, { agent: "Validation", v: 31.8 },
  { agent: "Discovery", v: 18.6 }, { agent: "Classifier", v: 12.1 }, { agent: "Standard.", v: 6.4 },
];
const LLM_CALLS = [
  { id: "c_9f2a", agent: "cd_codegen", role: "generator", model: "gpt-oss-120b", tin: 4820, tout: 1240, ms: 1840, status: "ok" },
  { id: "c_9f2b", agent: "cd_codegen", role: "evaluator", model: "gpt-oss-120b", tin: 9640, tout: 380, ms: 2210, status: "ok" },
  { id: "c_9f2c", agent: "md_plan", role: "generator", model: "claude-sonnet", tin: 12400, tout: 3820, ms: 4120, status: "ok" },
  { id: "c_9f2d", agent: "md_plan", role: "generator", model: "claude-sonnet", tin: 11800, tout: 3610, ms: 3980, status: "ok" },
  { id: "c_9f2e", agent: "validation", role: "evaluator", model: "gpt-oss-120b", tin: 7200, tout: 640, ms: 1620, status: "retry" },
  { id: "c_9f2f", agent: "cd_codegen", role: "generator", model: "gpt-oss-120b", tin: 3910, tout: 980, ms: 1510, status: "ok" },
  { id: "c_9f30", agent: "discovery", role: "generator", model: "gpt-oss-120b", tin: 2140, tout: 420, ms: 890, status: "ok" },
  { id: "c_9f31", agent: "classifier", role: "generator", model: "gpt-oss-120b", tin: 8600, tout: 1120, ms: 2440, status: "error" },
];

/* ============================== run model ============================== */

let SEQ = 100;
const uid = (p) => `${p}_${(SEQ++).toString(36)}${Math.random().toString(36).slice(2, 5)}`;

const mkAgentState = (a, status = "pending") => ({
  status, phase: null, phaseIdx: 0, progress: status === "done" ? 100 : 0,
  iteration: 1, tokens: 0, cost: 0, calls: 0,
  aiGen: a.ai, aiReview: a.review, hitl: a.hitl,
  issues: [], verdict: null, confidence: null, history: [],
});

function seedRun({ id, name, flow, app, dfid, status, upto, reviewAt, owner, src, nodes, cost, dur, started }) {
  const agents = {};
  AGENTS.forEach((a, i) => {
    const n = i + 1;
    let st = "pending";
    if (status === "passed") st = "done";
    else if (n < upto) st = "done";
    else if (n === upto) st = status === "review" ? "review" : status === "failed" ? "failed" : "running";
    agents[a.id] = mkAgentState(a, st);
    const s = agents[a.id];
    if (st === "done") { s.progress = 100; s.verdict = "pass"; s.confidence = 0.88 + Math.random() * 0.08; s.calls = a.ai ? 5 + Math.floor(Math.random() * 8) : 0; s.tokens = a.ai ? 14000 + Math.floor(Math.random() * 22000) : 0; s.cost = a.ai ? 0.3 + Math.random() * 0.9 : 0; }
    if (st === "review" || st === "failed") {
      s.progress = 100; s.verdict = st === "failed" ? "fail" : "revise";
      s.confidence = 0.62 + Math.random() * 0.18;
      s.issues = (ISSUE_BANK[a.id] || []).map((x, k) => ({ ...x, id: `${a.id}_${k}` }));
      s.iteration = st === "failed" ? 3 : 2; s.calls = 9; s.tokens = 32000; s.cost = 1.4;
    }
  });
  if (reviewAt && agents[reviewAt]) {
    const s = agents[reviewAt];
    s.status = "review"; s.verdict = "revise"; s.progress = 100;
    s.confidence = s.confidence || 0.68;
    s.issues = (ISSUE_BANK[reviewAt] || []).map((x, k) => ({ ...x, id: `${reviewAt}_${k}` }));
  }
  return { id, name, flow, app, dfid, status, stage: upto, owner, src, nodes, cost, dur, started, agents, log: [] };
}

const SEED = [
  seedRun({ id: "run_8099_a4f", name: "CMS Reconciliation", flow: "cms · 8099", app: "cms", dfid: "8099", status: "review", upto: 5, reviewAt: "cd_codegen", owner: "adarsh.a", src: "md", nodes: 71, cost: 4.82, dur: "12m 04s", started: "2m ago" }),
  seedRun({ id: "run_4127_e02", name: "IC Netting Matrix", flow: "cms · 4127", app: "cms", dfid: "4127", status: "review", upto: 4, reviewAt: "md_plan", owner: "adarsh.a", src: "md", nodes: 44, cost: 3.95, dur: "8m 12s", started: "26m ago" }),
  seedRun({ id: "run_7710_9be", name: "GL Detail Post-Close", flow: "fin · 7710", app: "fin", dfid: "7710", status: "passed", upto: 7, owner: "t.morrow", src: "md", nodes: 52, cost: 3.40, dur: "9m 18s", started: "1h ago" }),
  seedRun({ id: "run_6301_2aa", name: "DNJP Remittance Feed", flow: "ops · 6301", app: "ops", dfid: "6301", status: "failed", upto: 6, owner: "j.rhodes", src: "discovery", nodes: 28, cost: 6.07, dur: "21m 32s", started: "3h ago" }),
  seedRun({ id: "run_5540_77c", name: "Oracle FX Rates", flow: "fin · 5540", app: "fin", dfid: "5540", status: "passed", upto: 7, owner: "a.nandi", src: "md", nodes: 19, cost: 1.28, dur: "4m 02s", started: "5h ago" }),
];

function useEngine() {
  const [runs, setRuns] = useState(SEED);

  const tick = (r) => {
    const def = AGENTS[r.stage - 1];
    if (!def) return { ...r, status: "passed" };
    const st = { ...r.agents[def.id] };
    if (st.status !== "running") return r;

    const prog = Math.min(100, st.progress + 8 + Math.random() * 12);
    const pi = Math.min(def.phases.length - 1, Math.floor((prog / 100) * def.phases.length));
    const moved = pi !== st.phaseIdx || !st.phase;
    st.progress = prog; st.phaseIdx = pi; st.phase = def.phases[pi];
    if (st.aiGen) {
      st.tokens += 380 + Math.floor(Math.random() * 900);
      st.cost += 0.02 + Math.random() * 0.05;
      if (moved) st.calls += 1;
    }
    const log = moved ? [...r.log.slice(-40), { k: uid("l"), agent: def.id, msg: def.phases[pi].toLowerCase(), t: Date.now() }] : r.log;
    const cost = Number((r.cost + (st.aiGen ? 0.03 : 0)).toFixed(2));

    if (prog >= 100) {
      if (st.hitl) {
        st.status = "review"; st.verdict = "revise";
        st.confidence = 0.63 + Math.random() * 0.19;
        st.issues = (ISSUE_BANK[def.id] || []).map((x, k) => ({ ...x, id: `${def.id}_${k}_${st.iteration}` }));
        return { ...r, status: "review", cost, agents: { ...r.agents, [def.id]: st }, log };
      }
      st.status = "done"; st.verdict = "pass"; st.confidence = 0.9;
      const agents = { ...r.agents, [def.id]: st };
      const next = r.stage + 1;
      if (next > AGENTS.length) return { ...r, status: "passed", cost, agents, log, stage: AGENTS.length };
      const nd = AGENTS[next - 1];
      agents[nd.id] = { ...agents[nd.id], status: "running", phase: nd.phases[0], progress: 0, phaseIdx: 0 };
      return { ...r, stage: next, cost, agents, log };
    }
    return { ...r, cost, agents: { ...r.agents, [def.id]: st }, log };
  };

  useEffect(() => {
    const t = setInterval(() => setRuns((rs) => rs.map((r) => (r.status === "running" ? tick(r) : r))), 850);
    return () => clearInterval(t);
  }, []);

  const start = useCallback((cfg) => {
    const df = DATAFLOWS.find((d) => d.id === cfg.dfid);
    const id = uid("run");
    const agents = {};
    AGENTS.forEach((a, i) => {
      agents[a.id] = mkAgentState(a, i === 0 ? "running" : "pending");
      Object.assign(agents[a.id], cfg.toggles[a.id]);
      if (i === 0) agents[a.id].phase = a.phases[0];
    });
    setRuns((rs) => [{
      id, name: df.name, flow: `${df.app} · ${df.id}`, app: df.app, dfid: df.id,
      status: "running", stage: 1, owner: "adarsh.a", src: cfg.src, nodes: df.nodes,
      cost: 0, dur: "0m 00s", started: "just now", agents, log: [],
    }, ...rs]);
    return id;
  }, []);

  const resolve = useCallback((runId, agentId, { approve, decisions, note }) => {
    setRuns((rs) => rs.map((r) => {
      if (r.id !== runId) return r;
      const st = { ...r.agents[agentId] };
      st.history = [...st.history, {
        iter: st.iteration, verdict: st.verdict,
        accepted: Object.values(decisions || {}).filter((v) => v === "a").length, note,
      }];
      if (approve) {
        st.status = "done"; st.verdict = "pass"; st.progress = 100; st.issues = [];
        const agents = { ...r.agents, [agentId]: st };
        const next = AGENTS.findIndex((a) => a.id === agentId) + 2;
        const log = [...r.log, { k: uid("l"), agent: agentId, msg: "approved by adarsh.a", t: Date.now() }];
        if (next > AGENTS.length) return { ...r, status: "passed", agents, stage: AGENTS.length, log };
        const nd = AGENTS[next - 1];
        agents[nd.id] = { ...agents[nd.id], status: "running", phase: nd.phases[0], progress: 0, phaseIdx: 0 };
        return { ...r, status: "running", stage: next, agents, log };
      }
      st.status = "running"; st.iteration += 1; st.progress = 0; st.phaseIdx = 0;
      st.phase = "Applying feedback"; st.issues = []; st.verdict = null;
      return {
        ...r, status: "running", agents: { ...r.agents, [agentId]: st },
        log: [...r.log, { k: uid("l"), agent: agentId, msg: `regenerating v${st.iteration} with your feedback`, t: Date.now() }],
      };
    }));
  }, []);

  return { runs, start, resolve };
}

/* ============================== primitives ============================== */

const TONE = {
  running: { c: "var(--ice)", bg: "rgba(127,212,245,.11)", bd: "rgba(127,212,245,.42)", label: "Running" },
  review: { c: "var(--warn)", bg: "rgba(251,191,36,.11)", bd: "rgba(251,191,36,.42)", label: "Needs review" },
  passed: { c: "var(--pass)", bg: "rgba(52,211,153,.11)", bd: "rgba(52,211,153,.42)", label: "Passed" },
  done: { c: "var(--pass)", bg: "rgba(52,211,153,.11)", bd: "rgba(52,211,153,.42)", label: "Done" },
  failed: { c: "var(--fail)", bg: "rgba(251,113,133,.11)", bd: "rgba(251,113,133,.42)", label: "Failed" },
  pending: { c: "var(--dim)", bg: "rgba(91,110,136,.1)", bd: "rgba(91,110,136,.35)", label: "Waiting" },
};

const Chip = ({ tone = "running", children, dot }) => {
  const s = TONE[tone] || TONE.running;
  return (
    <span className="lv-chip" style={{ color: s.c, background: s.bg, borderColor: s.bd }}>
      {dot && <span style={{ width: 5, height: 5, borderRadius: 9, background: s.c, boxShadow: `0 0 7px ${s.c}` }} />}
      {children || s.label}
    </span>
  );
};

function CountUp({ value, decimals = 0, prefix = "", suffix = "", dur = 1000 }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf, t0;
    const step = (t) => {
      if (!t0) t0 = t;
      const p = Math.min((t - t0) / dur, 1);
      setN(value * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, dur]);
  return <>{prefix}{n.toFixed(decimals)}{suffix}</>;
}

const Stat = ({ icon: Icon, label, value, decimals, prefix, suffix, delta, foot, i = 0 }) => (
  <div className="lv-card lv-sheen hov" style={{ padding: 16, animationDelay: `${i * 65}ms` }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <Icon size={14} style={{ color: "var(--azure)" }} />
        <span style={{ fontSize: 11, color: "var(--muted)", letterSpacing: ".07em", textTransform: "uppercase", fontWeight: 600 }}>{label}</span>
      </div>
      {delta != null && <span className="mono" style={{ fontSize: 10.5, color: delta >= 0 ? "var(--pass)" : "var(--fail)" }}>{delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}%</span>}
    </div>
    <div className="disp" style={{ fontSize: 31, fontWeight: 600, marginTop: 11, lineHeight: 1 }}>
      <CountUp value={value} decimals={decimals} prefix={prefix} suffix={suffix} />
    </div>
    {foot && <div style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 6 }}>{foot}</div>}
  </div>
);

const Panel = ({ title, sub, right, children, pad = 16, style }) => (
  <div className="lv-card" style={style}>
    {(title || right) && (
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "13px 16px", borderBottom: "1px solid var(--line)" }}>
        <div>
          <div className="disp" style={{ fontSize: 13.5, fontWeight: 600 }}>{title}</div>
          {sub && <div style={{ fontSize: 11, color: "var(--dim)", marginTop: 2 }}>{sub}</div>}
        </div>
        {right}
      </div>
    )}
    <div style={{ padding: pad }}>{children}</div>
  </div>
);

const TT = ({ active, payload, label, unit = "" }) =>
  active && payload?.length ? (
    <div className="lv-card mono" style={{ padding: "8px 11px", fontSize: 11 }}>
      <div style={{ color: "var(--muted)", marginBottom: 4 }}>{label}</div>
      {payload.map((p) => <div key={p.dataKey} style={{ color: p.color }}>{p.dataKey}: {p.value}{unit}</div>)}
    </div>
  ) : null;

function Rail({ run, onPick, compact, active }) {
  const pct = ((run.stage - 0.5) / AGENTS.length) * 100;
  return (
    <div className="lv-rail" style={compact ? { padding: "15px 4px 4px" } : undefined}>
      <div className="lv-track" style={compact ? { top: 28 } : undefined}>
        <div className="lv-track-lit" style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} />
        {run.status === "running" && <><span className="lv-packet" /><span className="lv-packet" style={{ animationDelay: "1.15s" }} /><span className="lv-packet" style={{ animationDelay: "2.3s" }} /></>}
      </div>
      <div style={{ display: "flex", position: "relative" }}>
        {AGENTS.map((a) => {
          const st = run.agents[a.id]?.status || "pending";
          const Icon = a.icon;
          return (
            <div key={a.id} className="lv-stage" onClick={() => onPick?.(a.id)} tabIndex={onPick ? 0 : -1}
              onKeyDown={(e) => e.key === "Enter" && onPick?.(a.id)} title={a.name}>
              <div className={`lv-node ${st}`} style={compact
                ? { width: 25, height: 25, borderRadius: 8 }
                : active === a.id ? { boxShadow: "0 0 0 3px rgba(127,212,245,.25)" } : undefined}>
                <Icon size={compact ? 11 : 17} />
              </div>
              {!compact && (
                <div style={{ textAlign: "center" }}>
                  <div className="mono" style={{ fontSize: 9.5, color: "var(--dim)", letterSpacing: ".1em" }}>{a.short}</div>
                  <div style={{ fontSize: 11.5, marginTop: 1, color: st === "pending" ? "var(--dim)" : "var(--paper)" }}>{a.name}</div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

const reviewsOf = (runs) =>
  runs.flatMap((r) => AGENTS.filter((a) => r.agents[a.id]?.status === "review").map((a) => ({ run: r, agent: a, st: r.agents[a.id] })));

/* ============================== control tower ============================== */

function Tower({ runs, go, openRun }) {
  const live = runs.find((r) => r.status === "running") || runs[0];
  const reviews = reviewsOf(runs);
  const spend = runs.reduce((s, r) => s + r.cost, 0);
  const cur = AGENTS[live.stage - 1];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 12 }}>
        <div>
          <div className="mono" style={{ fontSize: 10.5, color: "var(--ice)", letterSpacing: ".18em", marginBottom: 6 }}>CONTROL TOWER</div>
          <h1 style={{ fontSize: 27, fontWeight: 600 }}>Seven agents, one pipeline</h1>
          <p style={{ color: "var(--muted)", marginTop: 6, fontSize: 13.5, maxWidth: 600 }}>
            Every dataflow moves left to right through the same rail, and stops wherever a person needs to decide.
          </p>
        </div>
        <button className="lv-btn pri" onClick={() => go("new")}><Plus size={14} /> Start a migration</button>
      </div>

      <div className="lv-card lv-sheen hov" style={{ padding: "4px 22px 16px", cursor: "pointer" }} onClick={() => openRun(live.id)}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, flexWrap: "wrap", gap: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            {live.status === "running" && <span className="lv-dot" />}
            <span className="mono" style={{ fontSize: 11.5 }}>{live.id}</span>
            <span style={{ color: "var(--dim)", fontSize: 12 }}>{live.name}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {live.status === "running" && cur && (
              <span className="mono" style={{ fontSize: 11.5, color: "var(--glow)" }}>
                {cur.name} · {live.agents[cur.id]?.phase}<span className="lv-dots" />
              </span>
            )}
            <Chip tone={live.status} dot={live.status === "running"} />
          </div>
        </div>
        <Rail run={live} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(196px,1fr))", gap: 14 }} className="lv-stagger">
        <Stat i={0} icon={Activity} label="Runs today" value={runs.length + 36} delta={12} foot={`${runs.filter((r) => r.status === "running").length} active now`} />
        <Stat i={1} icon={UserCheck} label="Waiting on you" value={reviews.length} foot={reviews.length ? `${reviews[0].agent.name} is oldest` : "queue is clear"} />
        <Stat i={2} icon={CircleDollarSign} label="Spend today" value={spend} decimals={2} prefix="$" delta={-8} foot="budget $250 · 29% used" />
        <Stat i={3} icon={Zap} label="Nodes generated" value={2841} foot="94% deterministic" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
        <Panel title="Throughput" sub="Runs started, last 24h" pad={10}>
          <ResponsiveContainer width="100%" height={190}>
            <AreaChart data={THROUGHPUT} margin={{ top: 6, right: 8, left: -22, bottom: 0 }}>
              <defs><linearGradient id="gR" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3B8FE8" stopOpacity={0.55} /><stop offset="100%" stopColor="#3B8FE8" stopOpacity={0.02} />
              </linearGradient></defs>
              <CartesianGrid stroke="#1B2E4A" strokeDasharray="2 5" vertical={false} />
              <XAxis dataKey="t" stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <YAxis stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <Tooltip content={<TT />} cursor={{ stroke: "#7FD4F5", strokeDasharray: "3 3" }} />
              <Area type="monotone" dataKey="runs" stroke="#7FD4F5" strokeWidth={2} fill="url(#gR)" />
            </AreaChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="Waiting on you" sub="Each agent reviews its own work" pad={0}
          right={<button className="lv-btn ghost sm" onClick={() => go("review")}>Open queue</button>}>
          <div style={{ maxHeight: 190, overflowY: "auto" }} className="lv-scroll">
            {reviews.length === 0 && (
              <div style={{ padding: 34, textAlign: "center" }}>
                <ListChecks size={22} style={{ color: "var(--dim)", marginBottom: 8 }} />
                <div style={{ fontSize: 12.5 }}>Nothing waiting</div>
                <div style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 3 }}>Start a migration to queue new work.</div>
              </div>
            )}
            {reviews.map(({ run, agent, st }) => {
              const Icon = agent.icon;
              return (
                <div key={run.id + agent.id} className="lv-row" style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 14px" }}
                  onClick={() => openRun(run.id, agent.id)}>
                  <div className="lv-node review" style={{ width: 28, height: 28, borderRadius: 9 }}><Icon size={13} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5 }}>{agent.name}</div>
                    <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>{run.flow}</div>
                  </div>
                  <span className="lv-chip" style={{ color: "var(--warn)", borderColor: "rgba(251,191,36,.4)", background: "rgba(251,191,36,.1)" }}>{st.issues.length}</span>
                </div>
              );
            })}
          </div>
        </Panel>
      </div>

      <Panel title="Recent runs" pad={0} right={<button className="lv-btn ghost sm" onClick={() => go("runs")}>View all <ArrowRight size={12} /></button>}>
        {runs.slice(0, 5).map((r, i) => (
          <div key={r.id} className="lv-row" onClick={() => openRun(r.id)}
            style={{ display: "grid", gridTemplateColumns: "1.5fr 190px 140px 84px 84px", gap: 12, padding: "11px 16px", alignItems: "center", animation: `cardIn .45s var(--d) ${i * 55}ms backwards` }}>
            <div>
              <div style={{ fontSize: 13 }}>{r.name}</div>
              <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", marginTop: 2 }}>{r.id} · {r.flow}</div>
            </div>
            <Rail run={r} compact />
            <Chip tone={r.status} dot={r.status === "running"} />
            <span className="mono" style={{ fontSize: 11.5 }}>${r.cost.toFixed(2)}</span>
            <span className="mono" style={{ fontSize: 11.5, color: "var(--dim)", textAlign: "right" }}>{r.started}</span>
          </div>
        ))}
      </Panel>
    </div>
  );
}

/* ============================== runs list ============================== */

function RunsList({ runs, openRun, go }) {
  const [q, setQ] = useState("");
  const [f, setF] = useState("all");
  const list = useMemo(() => runs.filter((r) =>
    (f === "all" || r.status === f) && (r.name + r.id + r.flow + r.owner).toLowerCase().includes(q.toLowerCase())), [runs, q, f]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 23, fontWeight: 600 }}>Runs</h1>
          <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4 }}>{list.length} of {runs.length} migrations</p>
        </div>
        <button className="lv-btn pri" onClick={() => go("new")}><Plus size={13} /> Start a migration</button>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
          <Search size={13} style={{ position: "absolute", left: 11, top: 10, color: "var(--dim)" }} />
          <input className="lv-in" style={{ paddingLeft: 31 }} placeholder="Search runs, dataflows, owners" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {["all", "running", "review", "passed", "failed"].map((k) => (
          <button key={k} className={`lv-btn ${f === k ? "" : "ghost"}`} onClick={() => setF(k)} style={{ textTransform: "capitalize" }}>
            {k === "all" && <Filter size={12} />}{k}
          </button>
        ))}
      </div>

      <Panel pad={0}>
        <div className="mono" style={{ display: "grid", gridTemplateColumns: "1.4fr 180px 132px 68px 58px 80px 88px", gap: 12, padding: "10px 16px", borderBottom: "1px solid var(--line)" }}>
          {["Run", "Pipeline", "Status", "Nodes", "Iter", "Cost", "Elapsed"].map((h) => (
            <span key={h} style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".1em", textTransform: "uppercase" }}>{h}</span>
          ))}
        </div>
        {list.map((r, i) => {
          const it = Math.max(...Object.values(r.agents).map((a) => a.iteration));
          return (
            <div key={r.id} className="lv-row" onClick={() => openRun(r.id)}
              style={{ display: "grid", gridTemplateColumns: "1.4fr 180px 132px 68px 58px 80px 88px", gap: 12, padding: "12px 16px", alignItems: "center", animation: `cardIn .4s var(--d) ${i * 40}ms backwards` }}>
              <div>
                <div style={{ fontSize: 13 }}>{r.name}</div>
                <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", marginTop: 2 }}>{r.id} · {r.owner}</div>
              </div>
              <Rail run={r} compact />
              <Chip tone={r.status} dot={r.status === "running"} />
              <span className="mono" style={{ fontSize: 12 }}>{r.nodes}</span>
              <span className="mono" style={{ fontSize: 12, color: it > 1 ? "var(--warn)" : "var(--muted)" }}>v{it}</span>
              <span className="mono" style={{ fontSize: 12 }}>${r.cost.toFixed(2)}</span>
              <span className="mono" style={{ fontSize: 11.5, color: "var(--dim)" }}>{r.dur}</span>
            </div>
          );
        })}
        {list.length === 0 && (
          <div style={{ padding: 44, textAlign: "center" }}>
            <Boxes size={26} style={{ color: "var(--dim)", marginBottom: 10 }} />
            <div style={{ fontSize: 13.5 }}>No runs match that filter</div>
            <div style={{ fontSize: 12, color: "var(--dim)", marginTop: 4 }}>Clear the search or pick a different status.</div>
          </div>
        )}
      </Panel>
    </div>
  );
}

/* ============================== new run ============================== */

function NewRun({ start, openRun, cancel }) {
  const [step, setStep] = useState(0);
  const [app, setApp] = useState("cms");
  const [dfid, setDfid] = useState("8099");
  const [src, setSrc] = useState("md");
  const [toggles, setToggles] = useState(Object.fromEntries(AGENTS.map((a) => [a.id, { aiGen: a.ai, aiReview: a.review, hitl: a.hitl }])));
  const [launching, setLaunching] = useState(false);
  const STEPS = ["Source", "Dataflow", "Pipeline", "Launch"];
  const df = DATAFLOWS.find((d) => d.id === dfid);
  const flip = (id, k) => setToggles((t) => ({ ...t, [id]: { ...t[id], [k]: !t[id][k] } }));

  if (launching) return (
    <div className="lv-hero" style={{ paddingTop: 80 }}>
      <div className="lv-orb">
        <svg className="r1" viewBox="0 0 112 112"><circle cx="56" cy="56" r="52" fill="none" stroke="#1D57AB" strokeWidth="1.5" strokeDasharray="16 10" /></svg>
        <svg className="r2" viewBox="0 0 88 88"><circle cx="44" cy="44" r="40" fill="none" stroke="#7FD4F5" strokeWidth="1.5" strokeDasharray="6 12" /></svg>
        <div className="lv-orb-core"><Radio size={24} /></div>
      </div>
      <div className="lv-phase">Opening the pipeline<span className="lv-dots" /></div>
      <div className="mono" style={{ fontSize: 11.5, color: "var(--dim)" }}>{df.name} · {df.app} · {df.id}</div>
    </div>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18, maxWidth: 900 }}>
      <div>
        <h1 style={{ fontSize: 23, fontWeight: 600 }}>Start a migration</h1>
        <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4 }}>Four decisions, then the agents take over.</p>
      </div>

      <div style={{ display: "flex", gap: 22, flexWrap: "wrap" }}>
        {STEPS.map((s, i) => (
          <div key={s} className={`lv-step ${i === step ? "on" : ""} ${i < step ? "did" : ""}`}>
            <span className="lv-stepn">{i < step ? <Check size={11} /> : i + 1}</span>{s}
          </div>
        ))}
      </div>

      <div className="lv-card" style={{ padding: 20, minHeight: 320 }} key={step}>
        <div style={{ animation: "viewIn .35s var(--d)" }}>
          {step === 0 && (
            <>
              <h3 style={{ fontSize: 15, marginBottom: 3 }}>Which application?</h3>
              <p style={{ fontSize: 12.5, color: "var(--muted)", marginBottom: 16 }}>The connection is already authenticated against the DENSO DOMO instance.</p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>
                {["cms", "fin", "ops"].map((k) => (
                  <div key={k} className={`lv-pick ${app === k ? "on" : ""}`}
                    onClick={() => { setApp(k); setDfid(DATAFLOWS.find((d) => d.app === k).id); }}>
                    <div className="mono" style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: ".08em" }}>{k}</div>
                    <div style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 4 }}>{DATAFLOWS.filter((d) => d.app === k).length} dataflows</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 18, display: "flex", alignItems: "center", gap: 9, fontSize: 12, color: "var(--muted)" }}>
                <span className="lv-dot" /> Connection healthy · token valid for 6h
              </div>
            </>
          )}

          {step === 1 && (
            <>
              <h3 style={{ fontSize: 15, marginBottom: 3 }}>Pick a dataflow</h3>
              <p style={{ fontSize: 12.5, color: "var(--muted)", marginBottom: 16 }}>One run migrates one dataflow end to end.</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {DATAFLOWS.filter((d) => d.app === app).map((d) => (
                  <div key={d.id} className={`lv-pick ${dfid === d.id ? "on" : ""}`} onClick={() => setDfid(d.id)}
                    style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13 }}>{d.name}</div>
                      <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", marginTop: 2 }}>{d.app} · {d.id}</div>
                    </div>
                    <span className="mono" style={{ fontSize: 11, color: "var(--muted)" }}>{d.tiles} tiles</span>
                    <span className="mono" style={{ fontSize: 11, color: "var(--muted)" }}>{d.nodes} nodes</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h3 style={{ fontSize: 15, marginBottom: 3 }}>How should the pipeline run?</h3>
              <p style={{ fontSize: 12.5, color: "var(--muted)", marginBottom: 14 }}>
                Source decides where the PySpark comes from. Per agent, choose whether a model generates, a model reviews, and whether you review.
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
                {[["md", "From the approved plan", "Extract already-translated code. A model only fills prose-only steps."],
                  ["discovery", "From the discovery table", "Deterministic transpile of the tile vocabulary, model for the tail."]].map(([k, t, d]) => (
                  <div key={k} className={`lv-pick ${src === k ? "on" : ""}`} onClick={() => setSrc(k)}>
                    <div style={{ fontSize: 13 }}>{t}</div>
                    <div style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 5, lineHeight: 1.5 }}>{d}</div>
                  </div>
                ))}
              </div>
              <div className="mono" style={{ display: "grid", gridTemplateColumns: "1.6fr 62px 62px 62px", gap: 8, padding: "0 4px 8px" }}>
                {["Agent", "AI gen", "AI eval", "You"].map((h) => (
                  <span key={h} style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".08em", textTransform: "uppercase", textAlign: h === "Agent" ? "left" : "center" }}>{h}</span>
                ))}
              </div>
              {AGENTS.map((a) => {
                const Icon = a.icon; const t = toggles[a.id];
                return (
                  <div key={a.id} style={{ display: "grid", gridTemplateColumns: "1.6fr 62px 62px 62px", gap: 8, alignItems: "center", padding: "7px 4px", borderTop: "1px solid rgba(27,46,74,.5)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                      <Icon size={14} style={{ color: "var(--azure)" }} />
                      <span style={{ fontSize: 12.5 }}>{a.name}</span>
                    </div>
                    {["aiGen", "aiReview", "hitl"].map((k) => (
                      <div key={k} style={{ display: "flex", justifyContent: "center" }}>
                        <div className={`lv-sw ${t[k] ? "on" : ""}`} onClick={() => flip(a.id, k)} tabIndex={0}
                          role="switch" aria-checked={t[k]} aria-label={`${a.name} ${k}`}
                          onKeyDown={(e) => e.key === "Enter" && flip(a.id, k)} />
                      </div>
                    ))}
                  </div>
                );
              })}
            </>
          )}

          {step === 3 && (
            <>
              <h3 style={{ fontSize: 15, marginBottom: 3 }}>Ready to run</h3>
              <p style={{ fontSize: 12.5, color: "var(--muted)", marginBottom: 16 }}>Check the summary, then launch.</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                {[["Dataflow", df.name], ["Identifier", `${df.app} · ${df.id}`],
                  ["Code source", src === "md" ? "Approved MD plan" : "Discovery table"],
                  ["Tiles to migrate", `${df.tiles}`],
                  ["You review at", AGENTS.filter((a) => toggles[a.id].hitl).map((a) => a.name).join(", ") || "no stages"],
                  ["Model-assisted", AGENTS.filter((a) => toggles[a.id].aiGen).map((a) => a.short).join(" · ") || "none"]].map(([k, v]) => (
                  <div key={k} style={{ padding: "11px 13px", background: "rgba(5,11,22,.45)", borderRadius: 9, border: "1px solid var(--line)" }}>
                    <div style={{ fontSize: 10.5, color: "var(--dim)", letterSpacing: ".07em", textTransform: "uppercase" }}>{k}</div>
                    <div style={{ fontSize: 12.5, marginTop: 5 }}>{v}</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <button className="lv-btn ghost" onClick={() => (step === 0 ? cancel() : setStep(step - 1))}>{step === 0 ? "Cancel" : "Back"}</button>
        {step < 3
          ? <button className="lv-btn pri" onClick={() => setStep(step + 1)}>Continue <ArrowRight size={13} /></button>
          : <button className="lv-btn pri" onClick={() => { setLaunching(true); setTimeout(() => openRun(start({ dfid, src, toggles })), 1500); }}>
              <Play size={13} /> Launch run
            </button>}
      </div>
    </div>
  );
}

/* ============================== agent detail ============================== */

function AgentDetail({ run, agentId, resolve, back }) {
  const def = AGENT_BY_ID[agentId];
  const st = run.agents[agentId];
  const Icon = def.icon;
  const [dec, setDec] = useState({});
  const [note, setNote] = useState("");
  const [hard, setHard] = useState(["Never rename source columns"]);
  const [openCell, setOpenCell] = useState(CELLS[1].id);

  useEffect(() => { setDec({}); setNote(""); }, [agentId, st.iteration]);
  const acc = Object.values(dec).filter((v) => v === "a").length;
  const rej = Object.values(dec).filter((v) => v === "r").length;
  const sevC = { major: "var(--fail)", minor: "var(--warn)", info: "var(--azure)" };
  const idx = AGENTS.findIndex((a) => a.id === agentId);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <button className="lv-btn ghost" onClick={back} style={{ alignSelf: "flex-start" }}>
        <ArrowRight size={13} style={{ transform: "rotate(180deg)" }} /> Back to pipeline
      </button>

      <div className="lv-card lv-sheen" style={{ padding: 18 }}>
        <div style={{ display: "flex", gap: 15, alignItems: "flex-start", flexWrap: "wrap" }}>
          <div className={`lv-node ${st.status}`} style={{ width: 50, height: 50, borderRadius: 14 }}><Icon size={22} /></div>
          <div style={{ flex: 1, minWidth: 230 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9, flexWrap: "wrap" }}>
              <h1 style={{ fontSize: 20, fontWeight: 600 }}>{def.name}</h1>
              <Chip tone={st.status} dot={st.status === "running"} />
              <span className="lv-chip mono" style={{ color: "var(--muted)", borderColor: "var(--line-2)", background: "transparent" }}>v{st.iteration}</span>
              <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>stage {idx + 1} of 7</span>
            </div>
            <p style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 5 }}>{def.desc}</p>
            <div style={{ display: "flex", gap: 7, marginTop: 10, flexWrap: "wrap" }}>
              {[["AI generation", st.aiGen], ["AI evaluation", st.aiReview], ["Human review", st.hitl]].map(([l, on]) => (
                <span key={l} className="lv-chip" style={{
                  textTransform: "none", letterSpacing: 0,
                  color: on ? "var(--ice)" : "var(--dim)",
                  borderColor: on ? "rgba(127,212,245,.35)" : "var(--line)",
                  background: on ? "rgba(127,212,245,.08)" : "transparent",
                }}>{on ? <Check size={10} /> : <CircleSlash size={10} />}{l}</span>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", gap: 20 }}>
            {[["Model calls", st.calls], ["Tokens", (st.tokens / 1000).toFixed(1) + "k"], ["Cost", "$" + st.cost.toFixed(2)]].map(([l, v]) => (
              <div key={l}>
                <div style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".07em", textTransform: "uppercase" }}>{l}</div>
                <div className="disp mono" style={{ fontSize: 17, marginTop: 4 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {st.status === "running" && (
        <div className="lv-card">
          <div className="lv-hero" style={{ padding: "26px 20px" }}>
            <div className="lv-orb">
              <svg className="r1" viewBox="0 0 112 112"><circle cx="56" cy="56" r="52" fill="none" stroke="#1D57AB" strokeWidth="1.5" strokeDasharray="16 10" /></svg>
              <svg className="r2" viewBox="0 0 88 88"><circle cx="44" cy="44" r="40" fill="none" stroke="#7FD4F5" strokeWidth="1.5" strokeDasharray="6 12" /></svg>
              <div className="lv-orb-core"><Brain size={24} /></div>
            </div>
            <div className="lv-phase" key={st.phase}>{st.phase}<span className="lv-dots" /></div>
            <div style={{ width: "min(460px,92%)" }}>
              <div className="lv-bar-t"><div className="lv-bar-f" style={{ width: `${st.progress}%` }} /></div>
              <div className="mono" style={{ display: "flex", justifyContent: "space-between", fontSize: 10.5, color: "var(--dim)", marginTop: 7 }}>
                <span>phase {st.phaseIdx + 1} of {def.phases.length}</span><span>{Math.round(st.progress)}%</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center" }}>
              {def.phases.map((p, i) => (
                <div key={p} className="lv-sub" style={{ color: i < st.phaseIdx ? "var(--pass)" : i === st.phaseIdx ? "var(--glow)" : "var(--dim)" }}>
                  {i < st.phaseIdx ? <Check size={11} /> : i === st.phaseIdx ? <Radio size={11} /> : <span style={{ width: 11, display: "inline-block" }} />}{p}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {st.status === "review" && (
        <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div className="lv-card" style={{ padding: 15, borderColor: "rgba(251,191,36,.35)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 9, flexWrap: "wrap" }}>
                <Bot size={15} style={{ color: "var(--warn)" }} />
                <span style={{ fontSize: 13, fontWeight: 550 }}>Evaluator says: revise</span>
                <span className="mono" style={{ fontSize: 11, color: "var(--dim)", marginLeft: "auto" }}>confidence {(st.confidence * 100).toFixed(0)}%</span>
              </div>
              <p style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 8, marginBottom: 0, lineHeight: 1.6 }}>
                Static checks passed. {st.issues.length} issues came out of the model review of iteration v{st.iteration}. Accept the ones worth fixing — anything you keep is left untouched.
              </p>
            </div>

            <div className="lv-stagger" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {st.issues.map((iss, i) => {
                const v = dec[iss.id];
                return (
                  <div key={iss.id} className="lv-card hov" style={{
                    padding: 14, animationDelay: `${i * 60}ms`,
                    borderColor: v === "a" ? "rgba(52,211,153,.5)" : v === "r" ? "rgba(91,110,136,.5)" : "var(--line)",
                  }}>
                    <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                      <span style={{ width: 6, height: 6, borderRadius: 9, background: sevC[iss.sev], marginTop: 6, flexShrink: 0, boxShadow: `0 0 8px ${sevC[iss.sev]}` }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                          <span style={{ fontSize: 13, fontWeight: 550 }}>{iss.title}</span>
                          <span className="lv-chip" style={{ color: sevC[iss.sev], borderColor: sevC[iss.sev] + "66", background: "transparent" }}>{iss.sev}</span>
                        </div>
                        <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", marginTop: 4 }}>node:{iss.node}</div>
                        <p style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 7, marginBottom: 0, lineHeight: 1.6 }}>{iss.detail}</p>
                        <div style={{ display: "flex", gap: 7, marginTop: 11 }}>
                          <button className="lv-btn sm" onClick={() => setDec((d) => ({ ...d, [iss.id]: d[iss.id] === "a" ? undefined : "a" }))}
                            style={v === "a" ? { background: "rgba(52,211,153,.18)", borderColor: "var(--pass)", color: "var(--pass)" } : {}}>
                            <Check size={11} /> Fix this
                          </button>
                          <button className="lv-btn ghost sm" onClick={() => setDec((d) => ({ ...d, [iss.id]: d[iss.id] === "r" ? undefined : "r" }))}
                            style={v === "r" ? { background: "rgba(91,110,136,.2)", borderColor: "var(--dim)" } : {}}>
                            <X size={11} /> Keep as-is
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12, position: "sticky", top: 76, alignSelf: "flex-start" }}>
            <Panel title="Your decision" sub={`Applies to ${def.name} only`} pad={14}>
              <div style={{ display: "flex", gap: 8, marginBottom: 13 }}>
                {[["Fixing", acc, "var(--pass)"], ["Keeping", rej, "var(--dim)"], ["Open", st.issues.length - acc - rej, "var(--warn)"]].map(([l, n, c]) => (
                  <div key={l} style={{ flex: 1, textAlign: "center", padding: "9px 4px", background: "rgba(5,11,22,.5)", borderRadius: 9, border: "1px solid var(--line)" }}>
                    <div className="disp" style={{ fontSize: 20, fontWeight: 600, color: c }}>{n}</div>
                    <div style={{ fontSize: 10, color: "var(--dim)", marginTop: 2 }}>{l}</div>
                  </div>
                ))}
              </div>
              <label style={{ fontSize: 10.5, color: "var(--muted)", letterSpacing: ".06em", textTransform: "uppercase", fontWeight: 600 }}>Notes for this agent</label>
              <textarea className="lv-in" rows={3} style={{ marginTop: 6, resize: "vertical" }} value={note} onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. keep the union order, it matches the DOMO tile sequence" />
              <div style={{ marginTop: 12 }}>
                <label style={{ fontSize: 10.5, color: "var(--muted)", letterSpacing: ".06em", textTransform: "uppercase", fontWeight: 600 }}>Hard constraints</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 6 }}>
                  {hard.map((h) => (
                    <span key={h} className="lv-chip" style={{ color: "var(--ice)", borderColor: "rgba(127,212,245,.35)", background: "rgba(127,212,245,.09)", textTransform: "none", letterSpacing: 0 }}>
                      {h}<X size={10} style={{ cursor: "pointer" }} onClick={() => setHard(hard.filter((x) => x !== h))} />
                    </span>
                  ))}
                  <button className="lv-btn ghost" style={{ padding: "3px 8px", fontSize: 11 }} onClick={() => setHard([...hard, "Preserve column order"])}>+ Add</button>
                </div>
                <p style={{ fontSize: 11, color: "var(--dim)", marginTop: 8, lineHeight: 1.5 }}>Constraints outrank the plan. The agent cannot override them.</p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 7, marginTop: 14 }}>
                <button className="lv-btn pri" style={{ justifyContent: "center" }} disabled={acc === 0 && !note.trim()}
                  onClick={() => resolve(run.id, agentId, { approve: false, decisions: dec, note })}>
                  <RefreshCw size={13} /> Send feedback and regenerate
                </button>
                <button className="lv-btn" style={{ justifyContent: "center" }}
                  onClick={() => resolve(run.id, agentId, { approve: true, decisions: dec, note })}>
                  <Check size={13} /> Approve and continue
                </button>
              </div>
            </Panel>

            {st.history.length > 0 && (
              <Panel title="Earlier passes" pad={0}>
                {st.history.map((h, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 9, padding: "10px 14px", borderBottom: "1px solid rgba(27,46,74,.5)" }}>
                    <span className="mono" style={{ fontSize: 11, color: "var(--dim)" }}>v{h.iter}</span>
                    <span style={{ fontSize: 12, flex: 1 }}>{h.accepted} accepted</span>
                    <Chip tone="review">{h.verdict}</Chip>
                  </div>
                ))}
              </Panel>
            )}
          </div>
        </div>
      )}

      {(st.status === "done" || st.status === "failed") && (
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14 }}>
          <Panel title="What this agent produced" sub={`iteration v${st.iteration} · node-addressable`} pad={0}
            right={<button className="lv-btn ghost sm"><Terminal size={12} /> Open in Databricks</button>}>
            <div className="lv-scroll" style={{ maxHeight: 380, overflowY: "auto" }}>
              {CELLS.map((c) => {
                const on = openCell === c.id;
                return (
                  <div key={c.id} className="lv-cell">
                    <div className="lv-cell-h" onClick={() => setOpenCell(on ? null : c.id)}>
                      {on ? <ChevronDown size={13} style={{ color: "var(--dim)" }} /> : <ChevronRight size={13} style={{ color: "var(--dim)" }} />}
                      <span className="mono" style={{ fontSize: 11, flex: 1, overflow: "hidden", textOverflow: "ellipsis" }}>{c.id}</span>
                      <span className="lv-chip" style={{ color: "var(--muted)", borderColor: "var(--line-2)", background: "transparent" }}>{c.op}</span>
                      <span className="lv-chip" style={{
                        color: c.origin === "ai" ? "var(--ai)" : "var(--azure)",
                        borderColor: c.origin === "ai" ? "rgba(192,132,252,.4)" : "rgba(59,143,232,.4)",
                        background: c.origin === "ai" ? "rgba(192,132,252,.1)" : "rgba(59,143,232,.1)",
                      }}>{c.origin}</span>
                    </div>
                    {on && (
                      <pre className="lv-code lv-scroll" style={{ margin: 0, padding: "12px 14px", border: "none", borderRadius: 0, background: "rgba(5,11,22,.55)", animation: "lineIn .3s var(--d)" }}>
                        <code style={{ color: "#B8CCE6" }}>{c.code}</code>
                      </pre>
                    )}
                  </div>
                );
              })}
            </div>
          </Panel>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <Panel title="Evaluator verdict" pad={15}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div className={`lv-node ${st.status}`} style={{ width: 36, height: 36, borderRadius: 11 }}>
                  {st.status === "failed" ? <X size={16} /> : <Check size={16} />}
                </div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 550 }}>{st.status === "failed" ? "Failed checks" : "Passed"}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--dim)", marginTop: 2 }}>
                    confidence {st.confidence ? (st.confidence * 100).toFixed(0) : "—"}% · v{st.iteration}
                  </div>
                </div>
              </div>
              <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 9 }}>
                {[["Syntax check", true], ["Node coverage", true], ["Unresolved slots", true], ["Row parity", st.status !== "failed"]].map(([l, ok]) => (
                  <div key={l} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                    {ok ? <Check size={12} style={{ color: "var(--pass)" }} /> : <X size={12} style={{ color: "var(--fail)" }} />}
                    <span style={{ color: ok ? "var(--muted)" : "var(--fail)" }}>{l}</span>
                  </div>
                ))}
              </div>
            </Panel>
            <Panel title="Phases" sub="What this agent did" pad={14}>
              {def.phases.map((p, i) => (
                <div key={p} style={{ display: "flex", alignItems: "center", gap: 9, fontSize: 12, padding: "5px 0" }}>
                  <Check size={12} style={{ color: "var(--pass)" }} />
                  <span style={{ flex: 1, color: "var(--muted)" }}>{p}</span>
                  <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>{(0.4 + i * 0.7).toFixed(1)}s</span>
                </div>
              ))}
            </Panel>
          </div>
        </div>
      )}

      {st.status === "pending" && (
        <div className="lv-card" style={{ padding: 46, textAlign: "center" }}>
          <Clock size={24} style={{ color: "var(--dim)", marginBottom: 10 }} />
          <div style={{ fontSize: 13.5 }}>Waiting its turn</div>
          <div style={{ fontSize: 12, color: "var(--dim)", marginTop: 4 }}>
            {def.name} starts once {AGENTS[idx - 1]?.name || "the previous stage"} finishes.
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================== run detail ============================== */

function RunDetail({ run, resolve, back, focusAgent, setFocusAgent }) {
  const [tab, setTab] = useState("monitor");
  const logRef = useRef(null);
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [run.log]);

  if (focusAgent) return <AgentDetail run={run} agentId={focusAgent} resolve={resolve} back={() => setFocusAgent(null)} />;

  const cur = AGENTS[run.stage - 1];
  const curSt = cur ? run.agents[cur.id] : null;
  const reviewing = AGENTS.filter((a) => run.agents[a.id].status === "review");
  const TABS = [["monitor", "Monitor"], ["pipeline", "Pipeline"], ["artifacts", "Artifacts"], ["telemetry", "Telemetry"]];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <button className="lv-btn ghost" onClick={back} style={{ alignSelf: "flex-start" }}>
        <ArrowRight size={13} style={{ transform: "rotate(180deg)" }} /> All runs
      </button>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <h1 style={{ fontSize: 22, fontWeight: 600 }}>{run.name}</h1>
            <Chip tone={run.status} dot={run.status === "running"} />
          </div>
          <div className="mono" style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 5 }}>
            {run.id} · {run.flow} · source={run.src} · {run.owner}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {run.status === "running" && <button className="lv-btn ghost"><Pause size={13} /> Pause</button>}
          <button className="lv-btn ghost"><RefreshCw size={13} /> Re-run</button>
          {reviewing.length > 0 && (
            <button className="lv-btn pri" onClick={() => setFocusAgent(reviewing[0].id)}>
              <UserCheck size={13} /> Review {reviewing[0].name}
            </button>
          )}
        </div>
      </div>

      <div className="lv-card lv-sheen" style={{ padding: "6px 20px 14px" }}>
        <Rail run={run} onPick={setFocusAgent} />
        <div style={{ textAlign: "center", fontSize: 11, color: "var(--dim)", marginTop: 4 }}>Select any stage to see what it produced</div>
      </div>

      <div style={{ display: "flex", gap: 4, borderBottom: "1px solid var(--line)" }}>
        {TABS.map(([k, l]) => <button key={k} className={`lv-tab ${tab === k ? "on" : ""}`} onClick={() => setTab(k)}>{l}</button>)}
      </div>

      {tab === "monitor" && (
        <div style={{ display: "grid", gridTemplateColumns: "1.25fr 1fr", gap: 14 }}>
          <div className="lv-card">
            {run.status === "running" && curSt ? (
              <div className="lv-hero">
                <div className="lv-orb">
                  <svg className="r1" viewBox="0 0 112 112"><circle cx="56" cy="56" r="52" fill="none" stroke="#1D57AB" strokeWidth="1.5" strokeDasharray="16 10" /></svg>
                  <svg className="r2" viewBox="0 0 88 88"><circle cx="44" cy="44" r="40" fill="none" stroke="#7FD4F5" strokeWidth="1.5" strokeDasharray="6 12" /></svg>
                  <div className="lv-orb-core">{React.createElement(cur.icon, { size: 24 })}</div>
                </div>
                <div style={{ textAlign: "center" }}>
                  <div className="mono" style={{ fontSize: 10.5, color: "var(--ice)", letterSpacing: ".16em" }}>{cur.short} · STAGE {run.stage} OF 7</div>
                  <div className="lv-phase" key={curSt.phase} style={{ marginTop: 7 }}>{curSt.phase}<span className="lv-dots" /></div>
                  <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 5, maxWidth: 400 }}>{cur.desc}</div>
                </div>
                <div style={{ width: "min(430px,92%)" }}>
                  <div className="lv-bar-t"><div className="lv-bar-f" style={{ width: `${curSt.progress}%` }} /></div>
                  <div className="mono" style={{ display: "flex", justifyContent: "space-between", fontSize: 10.5, color: "var(--dim)", marginTop: 7 }}>
                    <span>phase {curSt.phaseIdx + 1} of {cur.phases.length}</span><span>{Math.round(curSt.progress)}%</span>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 15, flexWrap: "wrap", justifyContent: "center" }}>
                  {cur.phases.map((p, i) => (
                    <div key={p} className="lv-sub" style={{ color: i < curSt.phaseIdx ? "var(--pass)" : i === curSt.phaseIdx ? "var(--glow)" : "var(--dim)" }}>
                      {i < curSt.phaseIdx ? <Check size={11} /> : i === curSt.phaseIdx ? <Radio size={11} /> : <span style={{ width: 11, display: "inline-block" }} />}{p}
                    </div>
                  ))}
                </div>
              </div>
            ) : reviewing.length > 0 ? (
              <div className="lv-hero">
                <div className="lv-node review" style={{ width: 60, height: 60, borderRadius: 17 }}><UserCheck size={26} /></div>
                <div style={{ textAlign: "center" }}>
                  <div className="lv-phase">Paused for your review</div>
                  <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 6, maxWidth: 390 }}>
                    {reviewing[0].name} finished iteration v{run.agents[reviewing[0].id].iteration} and raised {run.agents[reviewing[0].id].issues.length} issues. Nothing moves until you decide.
                  </div>
                </div>
                <button className="lv-btn pri" onClick={() => setFocusAgent(reviewing[0].id)}>Open review <ArrowRight size={13} /></button>
              </div>
            ) : (
              <div className="lv-hero">
                <div className={`lv-node ${run.status === "failed" ? "failed" : "done"}`} style={{ width: 60, height: 60, borderRadius: 17 }}>
                  {run.status === "failed" ? <X size={26} /> : <Check size={26} />}
                </div>
                <div style={{ textAlign: "center" }}>
                  <div className="lv-phase">{run.status === "failed" ? "Run stopped" : "Migration complete"}</div>
                  <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 6 }}>
                    {run.status === "failed" ? "Validation could not reconcile row counts." : `All seven agents finished · ${run.nodes} nodes generated.`}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Panel title="Agent stream" sub="What each agent reported" pad={0}>
              <div ref={logRef} className="lv-scroll" style={{ height: 218, overflowY: "auto", padding: "10px 14px" }}>
                {run.log.length === 0 && <div style={{ fontSize: 11.5, color: "var(--dim)" }}>No activity yet on this run.</div>}
                {run.log.slice(-24).map((l) => (
                  <div key={l.k} className="mono" style={{ display: "flex", gap: 8, fontSize: 11.5, lineHeight: 1.85, animation: "lineIn .3s var(--d)" }}>
                    <span style={{ color: "var(--azure)", flexShrink: 0 }}>{l.agent}</span>
                    <span style={{ color: "var(--dim)" }}>{l.msg}</span>
                  </div>
                ))}
              </div>
            </Panel>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Stat i={0} icon={SquareStack} label="Nodes" value={run.nodes} foot="addressable sections" />
              <Stat i={1} icon={CircleDollarSign} label="Cost so far" value={run.cost} decimals={2} prefix="$"
                foot={`${Object.values(run.agents).reduce((s, a) => s + a.calls, 0)} model calls`} />
            </div>
          </div>
        </div>
      )}

      {tab === "pipeline" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(272px,1fr))", gap: 12 }} className="lv-stagger">
          {AGENTS.map((a, i) => {
            const st = run.agents[a.id]; const Icon = a.icon;
            return (
              <div key={a.id} className="lv-card hov" style={{ padding: 15, cursor: "pointer", animationDelay: `${i * 55}ms` }} onClick={() => setFocusAgent(a.id)}>
                <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
                  <div className={`lv-node ${st.status}`} style={{ width: 36, height: 36, borderRadius: 11 }}><Icon size={16} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 550 }}>{a.name}</div>
                    <div className="mono" style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".08em" }}>{a.short} · STAGE {i + 1}</div>
                  </div>
                  <Chip tone={st.status} dot={st.status === "running"} />
                </div>
                <p style={{ fontSize: 11.5, color: "var(--muted)", marginTop: 10, marginBottom: 0, lineHeight: 1.55, minHeight: 34 }}>
                  {st.status === "running" ? <span style={{ color: "var(--glow)" }}>{st.phase}…</span>
                    : st.status === "review" ? <span style={{ color: "var(--warn)" }}>{st.issues.length} issues need your decision</span>
                    : a.desc}
                </p>
                <div className="lv-bar-t" style={{ marginTop: 11 }}>
                  <div className="lv-bar-f" style={{ width: `${st.progress}%`, background: st.status === "review" ? "linear-gradient(90deg,#B45309,#FBBF24)" : undefined }} />
                </div>
                <div className="mono" style={{ display: "flex", justifyContent: "space-between", marginTop: 9, fontSize: 10.5, color: "var(--dim)" }}>
                  <span>v{st.iteration} · {st.calls} calls</span><span>${st.cost.toFixed(2)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === "artifacts" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(248px,1fr))", gap: 12 }} className="lv-stagger">
          {[{ n: `etl_${run.dfid}_v2.py`, s: "38 KB", a: "cd_codegen" },
            { n: `plan_${run.dfid}_v3.md`, s: "74 KB", a: "md_plan" },
            { n: `discovery_${run.dfid}.json`, s: "112 KB", a: "discovery" },
            { n: `manifest_${run.dfid}.yaml`, s: "6 KB", a: "classifier" }].map((f, i) => (
            <div key={f.n} className="lv-card hov" style={{ padding: 15, cursor: "pointer", animationDelay: `${i * 55}ms` }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div style={{ width: 32, height: 32, borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(59,143,232,.13)", border: "1px solid rgba(59,143,232,.3)" }}>
                  <FileCode2 size={14} style={{ color: "var(--azure)" }} />
                </div>
                <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>{f.s}</span>
              </div>
              <div className="mono" style={{ fontSize: 12, marginTop: 11, overflow: "hidden", textOverflow: "ellipsis" }}>{f.n}</div>
              <div style={{ fontSize: 11, color: "var(--dim)", marginTop: 4 }}>from {f.a}</div>
            </div>
          ))}
        </div>
      )}

      {tab === "telemetry" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Panel title="Time per agent" pad={15}>
            {AGENTS.map((a, i) => {
              const st = run.agents[a.id];
              return (
                <div key={a.id} style={{ marginBottom: 11 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, marginBottom: 5 }}>
                    <span style={{ color: st.status === "pending" ? "var(--dim)" : "var(--paper)" }}>{a.name}</span>
                    <span className="mono" style={{ color: "var(--dim)" }}>{st.progress > 0 ? `${(st.progress / 12).toFixed(1)}s` : "—"}</span>
                  </div>
                  <div className="lv-bar-t"><div className="lv-bar-f" style={{ width: `${st.progress}%`, transitionDelay: `${i * 60}ms` }} /></div>
                </div>
              );
            })}
          </Panel>
          <Panel title="Model calls in this run" pad={0}>
            <div className="mono" style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr 1.1fr 72px 72px 70px 62px", gap: 10, padding: "10px 16px", borderBottom: "1px solid var(--line)" }}>
              {["Agent", "Role", "Model", "In", "Out", "Latency", "Status"].map((h) => (
                <span key={h} style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".1em", textTransform: "uppercase" }}>{h}</span>
              ))}
            </div>
            {LLM_CALLS.slice(0, 6).map((c) => (
              <div key={c.id} className="lv-row mono" style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr 1.1fr 72px 72px 70px 62px", gap: 10, padding: "10px 16px", fontSize: 11.5, alignItems: "center" }}>
                <span style={{ color: "var(--azure)" }}>{c.agent}</span>
                <span style={{ color: "var(--muted)" }}>{c.role}</span>
                <span style={{ color: "var(--muted)" }}>{c.model}</span>
                <span>{c.tin.toLocaleString()}</span><span>{c.tout.toLocaleString()}</span>
                <span style={{ color: c.ms > 3000 ? "var(--warn)" : "var(--muted)" }}>{c.ms}ms</span>
                <span style={{ color: c.status === "ok" ? "var(--pass)" : c.status === "retry" ? "var(--warn)" : "var(--fail)" }}>● {c.status}</span>
              </div>
            ))}
          </Panel>
        </div>
      )}
    </div>
  );
}

/* ============================== review queue ============================== */

function ReviewQueue({ runs, openRun }) {
  const items = reviewsOf(runs);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <div>
        <div className="mono" style={{ fontSize: 10.5, color: "var(--warn)", letterSpacing: ".18em", marginBottom: 6 }}>HUMAN IN THE LOOP</div>
        <h1 style={{ fontSize: 23, fontWeight: 600 }}>Review queue</h1>
        <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4, maxWidth: 640 }}>
          Each agent reviews its own work separately. Open one to see what it produced, what its evaluator flagged, and decide issue by issue.
        </p>
      </div>

      {items.length === 0 ? (
        <div className="lv-card" style={{ padding: 54, textAlign: "center" }}>
          <ListChecks size={26} style={{ color: "var(--dim)", marginBottom: 10 }} />
          <div style={{ fontSize: 14 }}>Queue is clear</div>
          <div style={{ fontSize: 12, color: "var(--dim)", marginTop: 4 }}>Agents park here when they need a decision.</div>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(326px,1fr))", gap: 12 }} className="lv-stagger">
          {items.map(({ run, agent, st }, i) => {
            const Icon = agent.icon;
            const maj = st.issues.filter((x) => x.sev === "major").length;
            return (
              <div key={run.id + agent.id} className="lv-card hov" style={{ padding: 16, cursor: "pointer", animationDelay: `${i * 60}ms`, borderColor: "rgba(251,191,36,.3)" }}
                onClick={() => openRun(run.id, agent.id)}>
                <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
                  <div className="lv-node review" style={{ width: 38, height: 38, borderRadius: 11 }}><Icon size={17} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 550 }}>{agent.name}</div>
                    <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", marginTop: 2 }}>{run.flow} · v{st.iteration}</div>
                  </div>
                  <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>{run.started}</span>
                </div>
                <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 11 }}>{run.name}</div>
                <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
                  {maj > 0 && <span className="lv-chip" style={{ color: "var(--fail)", borderColor: "rgba(251,113,133,.4)", background: "rgba(251,113,133,.1)" }}>{maj} major</span>}
                  <span className="lv-chip" style={{ color: "var(--warn)", borderColor: "rgba(251,191,36,.4)", background: "rgba(251,191,36,.1)" }}>{st.issues.length} issues</span>
                  <span className="lv-chip" style={{ color: "var(--muted)", borderColor: "var(--line-2)", background: "transparent" }}>conf {(st.confidence * 100).toFixed(0)}%</span>
                </div>
                <button className="lv-btn" style={{ width: "100%", justifyContent: "center", marginTop: 13 }}>Open review <ArrowRight size={12} /></button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ============================== obs / cost / outputs ============================== */

function Observability() {
  const sc = { ok: "var(--pass)", retry: "var(--warn)", error: "var(--fail)" };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <div>
        <h1 style={{ fontSize: 23, fontWeight: 600 }}>Observability</h1>
        <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4 }}>Every model call and node execution, straight from the audit tables.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(178px,1fr))", gap: 13 }} className="lv-stagger">
        <Stat i={0} icon={Cpu} label="Model calls" value={1284} delta={9} foot="last 24 hours" />
        <Stat i={1} icon={Clock} label="p95 latency" value={3.86} decimals={2} suffix="s" delta={-4} foot="p50 940ms" />
        <Stat i={2} icon={AlertTriangle} label="Error rate" value={0.9} decimals={1} suffix="%" foot="11 errors · 4 retried" />
        <Stat i={3} icon={TrendingUp} label="Tokens" value={8.4} decimals={1} suffix="M" foot="6.1M in · 2.3M out" />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Panel title="Latency distribution" sub="p50 vs p95 across the day" pad={10}>
          <ResponsiveContainer width="100%" height={186}>
            <LineChart data={LATENCY} margin={{ top: 6, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="#1B2E4A" strokeDasharray="2 5" vertical={false} />
              <XAxis dataKey="t" stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <YAxis stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <Tooltip content={<TT unit="ms" />} cursor={{ stroke: "#7FD4F5", strokeDasharray: "3 3" }} />
              <Line type="monotone" dataKey="p50" stroke="#3B8FE8" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="p95" stroke="#7FD4F5" strokeWidth={2} strokeDasharray="4 3" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Calls by agent" sub="Which agent is doing the talking" pad={10}>
          <ResponsiveContainer width="100%" height={186}>
            <BarChart data={COST_BY_AGENT} margin={{ top: 6, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="#1B2E4A" strokeDasharray="2 5" vertical={false} />
              <XAxis dataKey="agent" stroke="#5B6E88" tick={{ fontSize: 9.5, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <YAxis stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <Tooltip content={<TT />} cursor={{ fill: "rgba(59,143,232,.08)" }} />
              <Bar dataKey="v" radius={[4, 4, 0, 0]}>{COST_BY_AGENT.map((_, i) => <Cell key={i} fill={i === 0 ? "#7FD4F5" : "#1D57AB"} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <Panel title="Model calls" sub="llm_calls · most recent first" pad={0}>
        <div className="mono" style={{ display: "grid", gridTemplateColumns: "86px 1.1fr 1fr 1.1fr 74px 74px 72px 66px", gap: 10, padding: "10px 16px", borderBottom: "1px solid var(--line)" }}>
          {["Call", "Agent", "Role", "Model", "In", "Out", "Latency", "Status"].map((h) => (
            <span key={h} style={{ fontSize: 10, color: "var(--dim)", letterSpacing: ".1em", textTransform: "uppercase" }}>{h}</span>
          ))}
        </div>
        {LLM_CALLS.map((c, i) => (
          <div key={c.id} className="lv-row mono" style={{ display: "grid", gridTemplateColumns: "86px 1.1fr 1fr 1.1fr 74px 74px 72px 66px", gap: 10, padding: "11px 16px", alignItems: "center", fontSize: 11.5, animation: `cardIn .4s var(--d) ${i * 35}ms backwards` }}>
            <span style={{ color: "var(--dim)" }}>{c.id}</span>
            <span style={{ color: "var(--azure)" }}>{c.agent}</span>
            <span style={{ color: "var(--muted)" }}>{c.role}</span>
            <span style={{ color: "var(--muted)" }}>{c.model}</span>
            <span>{c.tin.toLocaleString()}</span><span>{c.tout.toLocaleString()}</span>
            <span style={{ color: c.ms > 3000 ? "var(--warn)" : "var(--muted)" }}>{c.ms}ms</span>
            <span style={{ color: sc[c.status] }}>● {c.status}</span>
          </div>
        ))}
      </Panel>
    </div>
  );
}

function CostView() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <div>
        <h1 style={{ fontSize: 23, fontWeight: 600 }}>Cost</h1>
        <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4 }}>What the pipeline spends, and where it goes.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(178px,1fr))", gap: 13 }} className="lv-stagger">
        <Stat i={0} icon={CircleDollarSign} label="Month to date" value={271.5} decimals={2} prefix="$" delta={-6} foot="budget $1,200" />
        <Stat i={1} icon={TrendingUp} label="Cost per run" value={3.42} decimals={2} prefix="$" delta={-14} foot="down from $3.98" />
        <Stat i={2} icon={Zap} label="Saved by determinism" value={1840} prefix="$" foot="calls avoided this month" />
        <Stat i={3} icon={Activity} label="Projected month" value={624} prefix="$" foot="52% of budget" />
      </div>
      <Panel title="Budget burn" sub="Month to date against the $1,200 envelope" pad={16}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 9, fontSize: 12 }}>
          <span className="mono" style={{ color: "var(--ice)" }}>$271.50 spent</span>
          <span className="mono" style={{ color: "var(--dim)" }}>$928.50 remaining</span>
        </div>
        <div className="lv-bar-t" style={{ height: 9 }}><div className="lv-bar-f" style={{ width: "22.6%" }} /></div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 9, fontSize: 11, color: "var(--dim)" }}>
          <span>Day 8 of 31</span><span>On pace to finish at $624</span>
        </div>
      </Panel>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14 }}>
        <Panel title="Daily spend" sub="Cost trend, last 24h" pad={10}>
          <ResponsiveContainer width="100%" height={198}>
            <AreaChart data={THROUGHPUT} margin={{ top: 6, right: 8, left: -20, bottom: 0 }}>
              <defs><linearGradient id="gC" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1D57AB" stopOpacity={0.7} /><stop offset="100%" stopColor="#1D57AB" stopOpacity={0.03} />
              </linearGradient></defs>
              <CartesianGrid stroke="#1B2E4A" strokeDasharray="2 5" vertical={false} />
              <XAxis dataKey="t" stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <YAxis stroke="#5B6E88" tick={{ fontSize: 10, fontFamily: "JetBrains Mono" }} tickLine={false} axisLine={false} />
              <Tooltip content={<TT unit="$" />} cursor={{ stroke: "#7FD4F5", strokeDasharray: "3 3" }} />
              <Area type="monotone" dataKey="cost" stroke="#7FD4F5" strokeWidth={2} fill="url(#gC)" />
            </AreaChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Spend by agent" sub="Month to date" pad={16}>
          {COST_BY_AGENT.map((a, i) => (
            <div key={a.agent} style={{ marginBottom: 13 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 5 }}>
                <span>{a.agent}</span><span className="mono" style={{ color: "var(--muted)" }}>${a.v.toFixed(2)}</span>
              </div>
              <div className="lv-bar-t"><div className="lv-bar-f" style={{ width: `${(a.v / COST_BY_AGENT[0].v) * 100}%`, transitionDelay: `${i * 80}ms` }} /></div>
            </div>
          ))}
        </Panel>
      </div>
    </div>
  );
}

function Outputs({ runs, openRun }) {
  const files = runs.flatMap((r) => ([
    { n: `etl_${r.dfid}_v2.py`, r, k: "notebook", s: "38 KB" },
    { n: `plan_${r.dfid}_v3.md`, r, k: "plan", s: "74 KB" },
  ])).slice(0, 10);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
      <div>
        <h1 style={{ fontSize: 23, fontWeight: 600 }}>Outputs</h1>
        <p style={{ color: "var(--muted)", fontSize: 12.5, marginTop: 4 }}>Generated notebooks and plans, versioned per iteration.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(258px,1fr))", gap: 12 }} className="lv-stagger">
        {files.map((f, i) => (
          <div key={f.n + i} className="lv-card hov" style={{ padding: 15, cursor: "pointer", animationDelay: `${i * 50}ms` }} onClick={() => openRun(f.r.id)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{
                width: 33, height: 33, borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center",
                background: f.k === "notebook" ? "rgba(59,143,232,.13)" : "rgba(192,132,252,.13)",
                border: `1px solid ${f.k === "notebook" ? "rgba(59,143,232,.32)" : "rgba(192,132,252,.32)"}`,
              }}>
                {f.k === "notebook" ? <Code2 size={15} style={{ color: "var(--azure)" }} /> : <FileCode2 size={15} style={{ color: "var(--ai)" }} />}
              </div>
              <span className="mono" style={{ fontSize: 10.5, color: "var(--dim)" }}>{f.r.started}</span>
            </div>
            <div className="mono" style={{ fontSize: 12.5, marginTop: 11 }}>{f.n}</div>
            <div style={{ fontSize: 11.5, color: "var(--dim)", marginTop: 3 }}>{f.r.flow}</div>
            <div style={{ display: "flex", gap: 14, marginTop: 11, paddingTop: 10, borderTop: "1px solid var(--line)" }}>
              <span className="mono" style={{ fontSize: 10.5, color: "var(--muted)" }}>{f.r.nodes} nodes</span>
              <span className="mono" style={{ fontSize: 10.5, color: "var(--muted)" }}>{f.s}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================== app ============================== */

const NAV = [
  { id: "tower", label: "Control tower", icon: LayoutGrid },
  { id: "runs", label: "Runs", icon: Activity },
  { id: "review", label: "Review", icon: UserCheck },
  { id: "obs", label: "Observability", icon: Eye },
  { id: "cost", label: "Cost", icon: CircleDollarSign },
  { id: "outputs", label: "Outputs", icon: Boxes },
];
const BOOT = ["authenticating databricks workspace", "attaching unity catalog · dev_test", "loading agent registry · 7 nodes", "restoring checkpointer state", "control tower ready"];

export default function App() {
  const { runs, start, resolve } = useEngine();
  const [booting, setBooting] = useState(true);
  const [fade, setFade] = useState(false);
  const [bstep, setBstep] = useState(0);
  const [view, setView] = useState("tower");
  const [runId, setRunId] = useState(null);
  const [focusAgent, setFocusAgent] = useState(null);
  const [clock, setClock] = useState(new Date());

  useEffect(() => {
    const a = setInterval(() => setBstep((s) => Math.min(s + 1, BOOT.length)), 420);
    const b = setTimeout(() => setFade(true), 2300);
    const c = setTimeout(() => setBooting(false), 2950);
    return () => { clearInterval(a); clearTimeout(b); clearTimeout(c); };
  }, []);
  useEffect(() => { const t = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(t); }, []);

  const run = runs.find((r) => r.id === runId);
  const pending = reviewsOf(runs).length;
  const go = (v) => { setRunId(null); setFocusAgent(null); setView(v); };
  const openRun = (id, agent = null) => { setRunId(id); setFocusAgent(agent); setView("runs"); };

  return (
    <div className="lv">
      <style>{CSS}</style>
      <div className="lv-bg" />

      {booting && (
        <div className={`lv-boot ${fade ? "out" : ""}`}>
          <div className="lv-mark">
            <svg viewBox="0 0 88 88" className="lv-ring"><circle cx="44" cy="44" r="38" fill="none" stroke="#1D57AB" strokeWidth="1.5" strokeDasharray="14 8" opacity=".85" /></svg>
            <svg viewBox="0 0 88 88" className="lv-ring-2"><circle cx="44" cy="44" r="28" fill="none" stroke="#7FD4F5" strokeWidth="1.5" strokeDasharray="5 11" opacity=".9" /></svg>
            <svg viewBox="0 0 88 88"><path d="M44 27 L57 51 L31 51 Z" fill="none" stroke="#9BE4FF" strokeWidth="2" strokeLinejoin="round" /><circle cx="44" cy="44" r="3" fill="#9BE4FF" /></svg>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="disp" style={{ fontSize: 19, fontWeight: 600 }}>LatentView Migration Platform</div>
            <div className="mono" style={{ fontSize: 10.5, color: "var(--dim)", letterSpacing: ".2em", marginTop: 6 }}>DOMO → DATABRICKS</div>
          </div>
          <div className="lv-boot-bar"><div className="lv-boot-fill" /></div>
          <div className="lv-boot-log mono">
            {BOOT.slice(0, bstep).map((l, i) => (
              <div key={l} className="lv-fade" style={{ animationDelay: `${i * 40}ms` }}><Check size={11} style={{ color: "var(--pass)" }} />{l}</div>
            ))}
          </div>
        </div>
      )}

      <div className="lv-shell">
        <aside className="lv-nav">
          <div style={{ padding: "17px 16px 14px", borderBottom: "1px solid var(--line)", display: "flex", alignItems: "center", gap: 10 }}>
            <svg viewBox="0 0 32 32" width="26" height="26">
              <path d="M16 7 L25 23 L7 23 Z" fill="none" stroke="#3B8FE8" strokeWidth="2" strokeLinejoin="round" />
              <circle cx="16" cy="17" r="2.6" fill="#7FD4F5" />
            </svg>
            <div className="lv-navlabel">
              <div className="disp" style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.15 }}>LatentView</div>
              <div className="mono" style={{ fontSize: 8.5, color: "var(--dim)", letterSpacing: ".16em" }}>MIGRATION</div>
            </div>
          </div>
          <div style={{ padding: "12px 12px 6px" }}>
            <button className="lv-btn pri" style={{ width: "100%", justifyContent: "center" }} onClick={() => go("new")}>
              <Plus size={13} /><span className="lv-navlabel">New run</span>
            </button>
          </div>
          <nav style={{ padding: "6px 0", flex: 1 }}>
            {NAV.map((n) => {
              const Icon = n.icon; const on = view === n.id;
              return (
                <div key={n.id} className={`lv-navitem ${on ? "on" : ""}`} onClick={() => go(n.id)} tabIndex={0} onKeyDown={(e) => e.key === "Enter" && go(n.id)}>
                  <Icon size={15} />
                  <span className="lv-navlabel" style={{ flex: 1 }}>{n.label}</span>
                  {n.id === "review" && pending > 0 && (
                    <span className="lv-navlabel mono" style={{ fontSize: 9.5, padding: "1px 6px", borderRadius: 20, background: "rgba(251,191,36,.16)", color: "var(--warn)", border: "1px solid rgba(251,191,36,.34)" }}>{pending}</span>
                  )}
                </div>
              );
            })}
          </nav>
          <div className="lv-navlabel" style={{ padding: 13, borderTop: "1px solid var(--line)" }}>
            <div className="lv-card" style={{ padding: 11, background: "rgba(29,87,171,.09)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                <span className="lv-dot" /><span className="mono" style={{ fontSize: 10, color: "var(--muted)" }}>7 agents healthy</span>
              </div>
              <div className="mono" style={{ fontSize: 9.5, color: "var(--dim)", marginTop: 5 }}>dev_test · unity catalog</div>
            </div>
          </div>
        </aside>

        <main className="lv-main">
          <header className="lv-top">
            <div style={{ display: "flex", alignItems: "center", gap: 7, flex: 1 }}>
              <Settings2 size={13} style={{ color: "var(--dim)" }} />
              <span className="mono" style={{ fontSize: 11.5, color: "var(--muted)" }}>environment</span>
              <span className="lv-chip" style={{ color: "var(--ice)", borderColor: "rgba(127,212,245,.32)", background: "rgba(127,212,245,.09)" }}>dev</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span className="lv-dot" />
              <span className="mono" style={{ fontSize: 11.5, color: "var(--muted)" }}>{runs.filter((r) => r.status === "running").length} running</span>
            </div>
            <div className="mono" style={{ fontSize: 11.5, color: "var(--dim)", borderLeft: "1px solid var(--line)", paddingLeft: 14 }}>{clock.toLocaleTimeString("en-GB")}</div>
            <div style={{ width: 27, height: 27, borderRadius: 8, background: "linear-gradient(135deg,var(--brand),var(--azure))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 600 }}>A</div>
          </header>

          <div className="lv-body" key={view + (runId || "") + (focusAgent || "")}>
            {view === "tower" && <Tower runs={runs} go={go} openRun={openRun} />}
            {view === "new" && <NewRun start={start} openRun={openRun} cancel={() => go("tower")} />}
            {view === "runs" && !run && <RunsList runs={runs} openRun={openRun} go={go} />}
            {view === "runs" && run && (
              <RunDetail run={run} resolve={resolve} back={() => { setRunId(null); setFocusAgent(null); }}
                focusAgent={focusAgent} setFocusAgent={setFocusAgent} />
            )}
            {view === "review" && <ReviewQueue runs={runs} openRun={openRun} />}
            {view === "obs" && <Observability />}
            {view === "cost" && <CostView />}
            {view === "outputs" && <Outputs runs={runs} openRun={openRun} />}
          </div>
        </main>
      </div>
    </div>
  );
}
