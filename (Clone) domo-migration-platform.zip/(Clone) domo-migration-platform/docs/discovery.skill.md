# SKILL: Discovery Agent (3) — addendum to core.domo.skill.md

**Mostly Python, no AI evaluation.** Discover all nodes/edges, write the dataflow's own table, verify completeness.

## Contract
- **In:** standardized JSON (by `dataflow_id`) — id-keyed, tiles under `actions`; read it through `core.contracts.standardized`.
- **Out:** the dataflow's discovery table — **create, or overwrite if it exists**.
- **Check:** structural only — every node and connection present in the final table. **No LLM.**

## Rules
- No `core.domo.llm` calls; no `prompts/`; no HITL.
- Create-or-overwrite the discovery table (pure overwrite, no iteration axis).
- The structural check must **fail loud** if any node/edge is missing — do not silently proceed.

## Tests (contracts/)
- every source node and edge appears in the output table;
- create path and overwrite path both work;
- structural check fails when a node/edge is missing;
- never calls the LLM wrapper.
