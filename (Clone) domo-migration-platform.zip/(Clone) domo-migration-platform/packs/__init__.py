"""Source packs (ADR 032 section 1): one directory per source platform, each exporting ``PACK``."""
