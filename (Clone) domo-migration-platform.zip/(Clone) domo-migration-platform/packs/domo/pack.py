"""packs.domo.pack - the DOMO ``SourcePack``, wrapping today's code unchanged (ADR 032 section 1).

| part          | wraps                                                                 |
|---------------|-----------------------------------------------------------------------|
| contract      | ``core/contracts/domo_raw.py`` (``is_raw_export``, ``to_standardized``) |
| vocabulary    | ``core/domo/tiles.py`` op sets + ``packs/domo/vocabulary.py``          |
| expressions   | ``core/domo/expr.py`` (Beast Mode Pratt parser, ``mysql_to_spark_format``) |
| registry      | ``tile_registry(target_dialect)``: the 14 ``Sql*Tile`` renderers / PySpark |
| caveats       | SEM002/SEM004, the apostrophe strip, ``_BATCH_LAST_RUN_``              |
| collaborators | ``scripts/mocks.py`` classes in the mocked harness                     |
| profile       | ``SOURCES["domo"]`` wording                                           |
"""
from __future__ import annotations

from typing import Any

from core.contracts import domo_raw
from core.domo import expr as _expr
from core.domo.tiles import tile_registry
from core.packs import Collaborators, PackCaveats, PackProfile
from packs.domo.vocabulary import VOCABULARY


class DomoContract:
    #: raw keys dropped on purpose (presentation, not logic)
    dropped_keys = frozenset(domo_raw._PRESENTATION)

    @staticmethod
    def is_raw_export(doc: Any) -> bool:
        return domo_raw.is_raw_export(doc)

    @staticmethod
    def to_standardized(doc: Any, dataflow_id: str = "") -> dict:
        return domo_raw.to_standardized(doc, dataflow_id)


class DomoExpressions:
    @staticmethod
    def translate(expression: str, *, dialect: str = "sql") -> Any:
        return _expr.translate(expression, dialect=dialect)

    @staticmethod
    def detect_functions(expression: str) -> set[str]:
        return _expr.detect_functions(expression)

    @staticmethod
    def date_format(fmt: str) -> str:
        return _expr.mysql_to_spark_format(fmt)


class DomoPack:
    platform = "domo"
    source_dialect = "domo_beastmode"
    version = "1"
    contract = DomoContract()
    vocabulary = VOCABULARY
    expressions = DomoExpressions()
    caveats = PackCaveats(literals_sensitive=False, as_of_column="_BATCH_LAST_RUN_",
                          judge_ids=("SEM002", "SEM004"),
                          notes=("DOMO prefixes some text values with an apostrophe; renderers strip it",))
    profile = PackProfile(label="DOMO", unit="dataflow", units="dataflows", step="tile", steps="tiles")

    @staticmethod
    def registry(target_dialect: str = "sql") -> Any:
        return tile_registry(target_dialect)

    @staticmethod
    def collaborators(mode: str = "mock") -> Collaborators:
        """The mocked harness's ports. Real ones arrive with the promoted runner (P3-10)."""
        if mode != "mock":
            raise NotImplementedError("the DOMO pack only ships the mocked collaborators today")
        import mocks  # scripts/mocks.py; on sys.path in the harness and the tests

        return Collaborators(table_reader=mocks.MockTableReader, pipeline_runner=mocks.MockPipelineRunner,
                             standardizer=mocks.RawAwareStandardizer, source_connection=mocks.MockDomoClient)


PACK = DomoPack()

__all__ = ["PACK", "DomoContract", "DomoExpressions", "DomoPack"]
