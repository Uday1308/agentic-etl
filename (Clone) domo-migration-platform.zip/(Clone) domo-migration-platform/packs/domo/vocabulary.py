"""packs.domo.vocabulary - DOMO's tile vocabulary as logic parity and the planner need it.

``columns_read`` / ``reads_in_order`` moved here from ``core/contracts/logic_parity.py``
(ADR 032 section 1: the DOMO pins move behind the pack); ``logic_parity`` keeps
same-named wrappers that delegate to the DOMO pack, so existing callers are unchanged.
"""
from __future__ import annotations

from typing import Any

from core.domo.expr import translate
from core.domo.tiles import (
    DYNAMIC_COLUMN_OPS,
    PASSTHROUGH_OPS,
    SCHEMA_AWARE_OPS,
    op_of,
    output_columns,
)

SOURCE_OPS = frozenset({"SOURCE", "DATASET", "LOADFROMVAULT"})
SINK_OPS = frozenset({"SINK", "WRITE", "OUTPUT", "PUBLISHTOVAULT"})


def columns_read(node: dict) -> set[str]:
    """Every column name a tile reads from its input.

    Read off the tile's own declaration where it makes one, and out of the parsed
    expression where it does not. A formula is the only tile whose column reads
    are not listed as data, which is exactly why the expression parser exists.
    """
    p = node.get("properties") or {}
    op = op_of(node)
    out: set[str] = set()

    def add(value: Any) -> None:
        if isinstance(value, str) and value:
            out.add(value)

    if op in ("SELECT", "SELECTCOLUMNS", "PROJECT"):
        for c in p.get("selectedColumns") or p.get("columns") or []:
            add(c if isinstance(c, str) else (c.get("column") or c.get("name")))
    elif op in ("GROUPBY", "AGGREGATE", "SUMMARIZE"):
        for c in p.get("groupByColumns") or []:
            add(c)
        for a in p.get("aggregations") or []:
            add(a.get("inputColumn") or a.get("column"))
    elif op in ("JOIN", "JOINDATA", "MERGE"):
        for k in p.get("joinKeys") or []:
            add(k.get("leftColumn"))
            add(k.get("rightColumn"))
    elif op in ("ALTERCOLUMNS", "ALTER", "CHANGECOLUMNS", "CAST"):
        for f in p.get("fields") or p.get("columns") or []:
            add(f if isinstance(f, str) else f.get("name"))
    elif op in ("DEDUPE", "UNIQUE", "REMOVEDUPLICATES"):
        for f in p.get("fields") or []:
            add(f if isinstance(f, str) else f.get("name"))
    elif op in ("RANK", "WINDOWACTION", "RANKWINDOW", "WINDOW"):
        for rule in (p.get("orderRules") or []) + (p.get("partitionRules") or []):
            add(rule.get("column") if isinstance(rule, dict) else rule)
    elif op in ("TEXT", "TEXTFORMATTING"):
        for f in p.get("fields") or []:
            add(f if isinstance(f, str) else f.get("name"))
    elif op in ("STRINGCALCULATOR", "STRINGCALC"):
        for calc in p.get("calculations") or []:
            for slot in ("A", "B", "C"):
                add(calc.get("field" + slot))
    elif op in ("FORMULA", "ADDFORMULA", "CALCULATOR"):
        for e in p.get("expressions") or []:
            try:
                emitted = translate(str(e.get("expression") or ""), dialect="sql")
            except Exception:           # noqa: BLE001 - an unparsable expression is
                continue                # the renderer's problem to report, not ours
            out |= set(emitted.columns_used)
    elif op in ("FILTER", "FILTERROWS"):
        for group in p.get("filterGroups") or []:
            for cond in group.get("conditions") or []:
                add(cond.get("column"))
    elif op in ("NORMALIZEALL", "UNPIVOT", "DYNAMICUNPIVOT"):
        for c in p.get("idFields") or []:
            add(c)
    return {c for c in out if c}


def reads_in_order(node: dict) -> list[tuple[set[str], str]]:
    """What a tile reads, and what it produces, in evaluation order.

    Only formula tiles need the ordering, and they need it badly: DOMO evaluates
    expressions top to bottom and a later one may read a column an earlier one
    just created. ``Add Formula 7`` on 8099 does exactly that - it computes
    ``Month Number`` and then reads it two lines later. Checking every read
    against the UPSTREAM columns alone reports that as a dangling reference,
    which is a false alarm on correct SQL, and a check that cries wolf is a check
    people learn to skip.

    Every other tile reads everything at once, so it is one entry.
    """
    op = op_of(node)
    if op not in ("FORMULA", "ADDFORMULA", "CALCULATOR"):
        return [(columns_read(node), "")]

    out: list[tuple[set[str], str]] = []
    for e in (node.get("properties") or {}).get("expressions") or []:
        produces = (e.get("fieldName") or e.get("outputColumn") or e.get("name") or "")
        try:
            emitted = translate(str(e.get("expression") or ""), dialect="sql")
            reads = set(emitted.columns_used)
        except Exception:               # noqa: BLE001 - the renderer reports this
            reads = set()
        out.append((reads, produces))
    return out


class DomoVocabulary:
    source_ops = SOURCE_OPS
    sink_ops = SINK_OPS
    passthrough_ops = PASSTHROUGH_OPS
    dynamic_column_ops = DYNAMIC_COLUMN_OPS
    schema_aware_ops = SCHEMA_AWARE_OPS

    @staticmethod
    def op_of(node: dict) -> str:
        return op_of(node)

    @staticmethod
    def output_columns(node: dict, upstream: list[list[str] | None]) -> list[str] | None:
        return output_columns(node, upstream)

    @staticmethod
    def columns_read(node: dict) -> set[str]:
        return columns_read(node)

    @staticmethod
    def reads_in_order(node: dict) -> list[tuple[set[str], str]]:
        return reads_in_order(node)


VOCABULARY = DomoVocabulary()

__all__ = ["SINK_OPS", "SOURCE_OPS", "VOCABULARY", "DomoVocabulary", "columns_read", "reads_in_order"]
