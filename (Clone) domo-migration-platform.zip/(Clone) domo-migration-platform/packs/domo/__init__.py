"""The DOMO pack: today's DOMO code behind the ``SourcePack`` protocol (ADR 032 section 1)."""
