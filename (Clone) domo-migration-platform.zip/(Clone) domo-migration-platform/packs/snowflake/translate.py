"""packs.snowflake.translate - one ETL's units through tier 0 and the fallback chain (ADR 032 sections 2-4, P3-08).

    unit document -> contract (SQL nodes) -> tier 0 per unit (sqlglot.transpile + rules + post-pass + validators +
    caveat scan + column check) -> units left over go to ``ChainTranslator`` (tier 1 Lakebridge cache, tier 2 LLM,
    tier 3 human) -> ``UnitResult`` per unit.

``phase_a_units`` is the pure first phase of the two-phase batch: the same tier-0 function, nothing written.
Evidence and attempts never carry source text (hard rule 11); the chain's ``Resolution`` holds the SQL in memory only.
"""
from __future__ import annotations

import dataclasses
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any

from agents.cd_codegen.translate.attempt import UNAVAILABLE, TranslationAttempt, unit_fingerprint
from agents.cd_codegen.translate.chain import (
    ChainTranslator,
    HumanTier,
    LakebridgeTier,
    LlmTier,
    TranslationSettings,
    coverage_of,
)
from agents.cd_codegen.translate.ports import SqlUnit
from packs.snowflake import caveats as cav
from packs.snowflake import code_units, dml_patterns, post_tier0
from packs.snowflake import contract as ct
from packs.snowflake import residue as rsd
from packs.snowflake import scripting_convert as sc
from packs.snowflake import streams as strm
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.overloads import Overloads
from packs.snowflake.postpass import Postpass, PostpassContext, transpile
from packs.snowflake.scripting import is_scripting, procedure_header, split_scripting
from packs.snowflake.validators import column_check, sniff_kind, validate

PACK_VERSION = "1"
#: node kinds the block-aware splitter keeps whole: no deterministic tier handles them
_WHOLE = {"block", "declare", "exception", "script"}
#: catalogue caveats whose detection is superseded by the rules in ``rules/gaps.py``: a unit that hits one is converted
#: by the rule (review flag) or escalated by the rule's own ``*-UNSUPPORTED`` flag with a suggested pattern. The residue
#: guard (FLATTEN, CONNECT BY, MATCH_RECOGNIZE, RESULT_SCAN) stays the net under a shape the parser let through.
RULE_OWNED = frozenset({"SNW-LATERAL-FLATTEN", "SNW-CONNECT-BY", "SNW-MATCH-RECOGNIZE", "SNW-RESULT-SCAN"})


@dataclass
class PreUnit:
    unit_id: str
    logic: dict
    engine: str

    @property
    def source_text(self) -> str:
        return str(self.logic.get("sql") or "")

    @property
    def unavailable(self) -> bool:
        return ct.is_unavailable(self.logic)


@dataclass
class UnitResult:
    unit_id: str
    engine: str
    source_text: str = field(repr=False, default="")
    sql: str = field(repr=False, default="")
    kind: str = ""                       # sniffed artifact kind of ``sql`` (cte_chain, statement, call, expression, ...)  # noqa: E501
    origin: str = "unresolved"           # mapped | transpiled | ai | manual | unresolved
    state: str = ""
    status: str = "resolved"             # resolved | awaiting_review | manual
    caveats: list[str] = field(default_factory=list)
    review_caveats: list[str] = field(default_factory=list)
    attempts: list[dict] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    confidence: float | None = None
    evidence: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""
    column_check: str = ""
    assumed: list[str] = field(default_factory=list)
    params: dict = field(default_factory=dict)
    #: a reviewer's hand-written text became this unit's code (origin ``manual``), or marked it out of scope
    edited: bool = False
    #: a reviewer's edit was offered but did not validate: the approval is not reused, the review reopens
    edit_rejected: bool = False
    #: ``(origin, status)`` the unit had when the reviewer saw it: the gate payload hash must not move when an edit
    #: or an out-of-scope decision is applied on resume
    reviewed_as: tuple[str, str] | None = None
    #: a rule's partial answer for a unit that still has no code (offered to the reviewer in the gate payload only)
    suggested_code: str = ""

    @property
    def no_code(self) -> bool:
        return self.status != "resolved" or not self.sql

    @property
    def needs_review(self) -> bool:
        return self.status != "resolved" or self.origin != "mapped" or bool(self.review_caveats)

    def record(self) -> dict:
        """The persisted form: no source text, no generated SQL (those are artifacts, by hash)."""
        return {"unit_id": self.unit_id, "engine": self.engine, "kind": self.kind, "origin": self.origin,
                "state": self.state, "status": self.status, "caveats": self.caveats,
                "review_caveats": self.review_caveats, "attempts": self.attempts, "reasons": self.reasons,
                "confidence": self.confidence, "evidence": self.evidence, "fingerprint": self.fingerprint,
                "column_check": self.column_check, "assumed": self.assumed, "no_code": self.no_code,
                "edited": self.edited}


@dataclass
class UnitContext:
    etl_key: str
    postpass: Postpass
    settings: TranslationSettings = field(default_factory=TranslationSettings)
    catalogue: dict[str, dict[str, str]] | None = None
    #: fingerprint -> tier-1 cache entry; None = Lakebridge off or unavailable (reported, not a failure)
    tier1_cache: dict[str, dict] | None = None
    tier1_reason: str = ""
    llm: Any = None
    default_catalog: str = "main"
    #: stream name (UPPER, last part) -> target base table; a stream read becomes the change data feed (streams.py)
    stream_tables: dict[str, str] = field(default_factory=dict)
    #: stream name (UPPER) -> ``{append_only, insert_only, show_initial_rows}`` (objects.parse_stream): the read filter
    stream_types: dict[str, dict] = field(default_factory=dict)
    caveat_catalogue: cav.Catalogue = field(default_factory=cav.load_catalogue)
    #: what a rule may read beyond the statement: account parameters, the target's capability profile and the column
    #: types of the referenced tables (conversion engine v2, packs/snowflake/conversion.py)
    conversion: ConversionContext = field(default_factory=ConversionContext)
    #: SOURCE procedure FQN (``DB.SCHEMA.NAME``, upper case) -> scalar RETURNS type, for the procedures converted in the
    #: same run: a ``v := (CALL p(..))`` in a body becomes ``CALL p__ret(.., v)`` only when ``p`` is listed here
    procedure_returns: dict[str, str] = field(default_factory=dict)
    #: REF001 (scripting_refactor): replace a provably safe row-by-row cursor loop by one set-based statement
    refactor_loops: bool = True
    #: REF002 / REF003 (judges.refactor): read a row count from the Delta commit metrics instead of a COUNT(*)
    #: pre-query, and a key by a uuid() run id instead of MAX(id). OFF by default: both trade a safe form for a
    #: faster one that reads another writer's commit under concurrency; PERF002 / CONC001 flag the pattern either way
    refactor_history: bool = False
    #: X6 (dynamic_sql.py): FQN of the runtime transpile function; set = a run-time EXECUTE IMMEDIATE is converted to
    #: ``EXECUTE IMMEDIATE <fn>(<expr>)`` with a review flag, empty = it escalates
    dynamic_shim: str = ""
    #: 6.12: UDF names renamed by signature (overloads.plan); the post-pass holds the call-site half
    overloads: Overloads = field(default_factory=Overloads)
    #: L12: SOURCE FQN (upper) -> parameter names of the JavaScript / Snowpark procedures that become notebooks
    notebook_procs: dict[str, list[str]] = field(default_factory=dict)

    def validate_fn(self, sql: str) -> list[str]:
        """Post-pass problems (an unmapped Snowflake name), the validator for the text's kind, then the residue
        guard: every tier's output (Lakebridge, AI, a reviewer's edit) passes through here."""
        if self.postpass.ctx.engine in code_units.CODE_ENGINES and not re.match(r"\s*CREATE\b", sql, re.I):
            return validate("python", sql)        # S2: a notebook (JavaScript / Snowpark procedure) is Python, not SQL
        problems = list(self.postpass.problems(sql))
        kind = sniff_kind(sql)
        return problems + validate(kind, sql) + rsd.problems(sql, self.conversion.capabilities)


def pre_units(doc: dict, etl_key: str) -> list[PreUnit]:
    engine = str(doc.get("engine") or "")
    return [PreUnit(f"{etl_key}-s{i}", logic, engine) for i, logic in enumerate(ct.node_units(doc))]


def _fingerprint(pre: PreUnit) -> str:
    """Identity of the SOURCE unit (text, dialect, engine, pack version). The conversion context is deliberately not
    part of it: the tier-1 cache is keyed by source text only, and a different context yields different output, hence
    a different gate payload hash, so an approval is never reused across contexts (ADR 037 section 5)."""
    return unit_fingerprint(pre.source_text, source_dialect=ct.SOURCE_DIALECT, engine=pre.engine,
                            pack_version=PACK_VERSION)


_IDENT = r'(?:"[^"]+"|[\w$]+)'
_CALL = re.compile(rf"^\s*CALL\s+(?P<name>{_IDENT}(?:\.{_IDENT}){{0,2}})\s*\((?P<args>.*)\)\s*;?\s*$", re.I | re.S)
_STREAM_COLUMN = re.compile(r"\bMETADATA\$(?:ACTION|ISUPDATE|ROW_ID)\b", re.I)
_EXEC_TASK = re.compile(rf"^\s*EXECUTE\s+TASK\s+(?P<name>{_IDENT}(?:\.{_IDENT}){{0,2}})\s*;?\s*$", re.I)


def split_args(text: str) -> list[str]:
    """Top-level comma split of a call's argument list (quotes and brackets respected)."""
    out, depth, cur, quote = [], 0, "", ""
    for ch in text:
        if quote:
            cur += ch
            quote = "" if ch == quote else quote
            continue
        if ch in "'\"":
            quote = ch
        elif ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def _qualify(name: str, db: str, schema: str) -> tuple[str, str, str]:
    parts = [p.strip('"') for p in re.findall(_IDENT, name)]
    if len(parts) == 1:
        parts = [db, schema, *parts]
    elif len(parts) == 2:
        parts = [db, *parts]
    return parts[0].upper(), parts[1].upper(), parts[2].upper()


def tier0_call(text: str, ctx: UnitContext) -> dict | None:
    """``CALL db.schema.proc(args)`` -> the callee and its arguments, or None (not a CALL, or a ``SYSTEM$`` procedure,
    which has no Databricks counterpart and goes down the chain). Deterministic: no AI."""
    m = _CALL.match(text or "")
    if not m or "$" in m.group("name"):
        return None
    pp = ctx.postpass.ctx
    db, schema, name = _qualify(m.group("name"), pp.default_db, pp.default_schema)
    if not (db and schema):
        return None
    out = {"db": db, "schema": schema, "name": name, "args": split_args(m.group("args")),
           "target": ct.derived_target(ctx.default_catalog, db, schema, name)}
    names = ctx.notebook_procs.get(f"{db}.{schema}.{name}".upper())
    if names is not None:            # L12: the callee is a notebook: its widgets are named by its parameters
        out["notebook_params"] = list(names)
    return out


def tier0_execute_task(text: str, ctx: UnitContext) -> dict | None:
    m = _EXEC_TASK.match(text or "")
    if not m:
        return None
    pp = ctx.postpass.ctx
    db, schema, name = _qualify(m.group("name"), pp.default_db, pp.default_schema)
    return {"db": db, "schema": schema, "name": name}


def _reads_stream(source: str, ctx: UnitContext) -> bool:
    """The statement names a stream the batch knows (``ctx.stream_tables``): a plain read needs the change feed too."""
    return any(re.search(rf"\b{re.escape(n)}\b", source, re.I) for n in ctx.stream_tables)


def _stream_base(table: Any, ctx: UnitContext) -> str | None:
    """The target base table of a stream named in the statement: from the inputs' ``base_table``, else the table the
    stream's name says it watches (``ORDERS_RAW_STREAM`` -> ``ORDERS_RAW``) when that one is in the table map."""
    name = str(table.name).upper()
    if name in ctx.stream_tables:
        return ctx.stream_tables[name]
    pp = ctx.postpass.ctx
    for suffix in ("_STREAM", "_STRM", "_STR"):
        if name.endswith(suffix) and len(name) > len(suffix):
            key = (str(table.catalog or pp.default_db).upper(), str(table.db or pp.default_schema).upper(),
                   name[: -len(suffix)])
            if key in pp.table_map:
                return pp.table_map[key]
    return None


def _pattern_unit(pat: Any, res: UnitResult, hit: list[str], cfg: dict, ctx: UnitContext, escalate: Callable
                  ) -> tuple[UnitResult, dict | None]:
    """A statement pattern (dml_patterns) that is converted completely, or escalated with its reasons."""
    res.caveats = hit = sorted({*hit, *pat.review})
    if pat.reasons:
        return escalate(pat.reasons, pat.draft)
    leftover = rsd.scan(pat.sql, ctx.conversion.capabilities)
    if not leftover.clean:
        res.caveats = sorted({*hit, rsd.RESIDUE_CAVEAT})
        return escalate(leftover.reasons(), pat.sql)
    review = [*pat.review, *([f"always_review:{res.engine}"] if cfg.get("always_review") else [])]
    res.sql, res.kind, res.origin, res.state = pat.sql, sniff_kind(pat.sql), "mapped", "derived"
    res.column_check = "not_applicable"
    res.review_caveats = sorted({*review, *cav.classify(hit, ctx.caveat_catalogue)["review"]})
    res.params = {**res.params, "conversion": ctx.conversion.summary()}
    res.attempts = [TranslationAttempt(0, "ok", caveats=hit).as_dict()]
    return res, None


def tier0_unit(pre: PreUnit, ctx: UnitContext) -> tuple[UnitResult, dict | None]:
    """``(result, chain_item)``: ``chain_item`` is None when tier 0 resolved the unit."""
    catalogue = ctx.caveat_catalogue
    cfg = ct.ENGINES.get(pre.engine, {})
    res = UnitResult(pre.unit_id, pre.engine, source_text=pre.source_text,
                     fingerprint=_fingerprint(pre), params=dict(pre.logic.get("params") or {}))
    if pre.unavailable:
        res.status, res.origin = "manual", "unresolved"
        res.reasons = [f"definition unavailable: {pre.logic.get('reason')}; never translated, a manual item "
                       "(ADR 033 suggests LIFT)"]
        return res, None
    hit = cav.detect(pre.source_text, catalogue)
    if pre.engine != "task":      # S17b: the rule pass owns these constructs and flags what it cannot convert itself
        hit = [h for h in hit if h not in RULE_OWNED]
    cls = cav.classify(hit, catalogue)
    res.caveats = hit

    def escalate(reasons: list[str], partial: str = "") -> tuple[UnitResult, dict]:
        res.reasons = reasons
        res.suggested_code = partial
        res.attempts = [TranslationAttempt(0, "failed", reasons, caveats=hit).as_dict()]
        return res, {"step": pre.unit_id, "reasons": reasons, "caveats": hit, "source_text": pre.source_text,
                     "fingerprint": res.fingerprint, "engine": pre.engine}


    call = tier0_call(pre.source_text, ctx)
    if call is not None and not cls["block"]:
        res.sql = f"CALL {call['target']}({', '.join(call['args'])})"
        res.kind, res.origin, res.state = "call", "mapped", "derived"
        res.params = {**res.params, "call": call}
        res.column_check = "not_applicable"
        res.attempts = [TranslationAttempt(0, "ok", caveats=hit).as_dict()]
        return res, None
    if pre.engine == "task":
        ex = tier0_execute_task(pre.source_text, ctx)
        if ex is not None:
            res.sql = f"EXECUTE TASK {ex['db']}.{ex['schema']}.{ex['name']}"
            res.kind, res.origin, res.state = "execute_task", "mapped", "derived"
            res.params = {**res.params, "execute_task": ex}
            res.column_check = "not_applicable"
            res.attempts = [TranslationAttempt(0, "ok", caveats=hit).as_dict()]
            return res, None
    source, cdf, extra_review = pre.source_text, None, []
    pat = None if cls["block"] else dml_patterns.detect(source, ctx, lambda t: _stream_base(t, ctx))
    if pat is not None:                     # S8: multi-table INSERT, NEXTVAL, stream MERGE -> AUTO CDC
        res.params = {**res.params, **pat.params}
        res.evidence = {**res.evidence, "pattern": {"name": pat.name, "notes": pat.notes}}
        if pat.reasons or pat.sql:
            return _pattern_unit(pat, res, hit, cfg, ctx, escalate)
        source, extra_review = pat.source, list(pat.review)
    if (_STREAM_COLUMN.search(source) or _reads_stream(source, ctx)) and not cls["block"]:
        cdf = strm.rewrite(source, lambda t: _stream_base(t, ctx), ctx.stream_types)
        if not cdf.ok:
            return escalate(["stream metadata column (METADATA$ACTION / ISUPDATE / ROW_ID): no deterministic rule for "
                             "the change data feed (_change_type): " + "; ".join(cdf.reasons)])
        source = cdf.sql
    if cls["block"]:
        return escalate([f"block caveat {', '.join(cls['block'])}: semantics cannot be preserved by a translator"])
    if pre.logic.get("node_kind") in _WHOLE or pre.logic.get("params", {}).get("unparsed"):
        return escalate(["control-flow block kept whole by the splitter: no deterministic tier"])
    if cfg.get("tier0") is False or pre.logic.get("language") not in ("sql", None):
        return escalate([f"engine {pre.engine} ({pre.logic.get('language')}) has no deterministic tier"])
    tr = transpile(source, conversion=ctx.conversion, names=ctx.postpass.ctx)
    if not tr.ok:
        return escalate([f"tier 0 transpile failed: {r}" for r in tr.reasons])
    if tr.flags:                    # S17a / S9: what the rule pass could not decide (rules/), by caveat id
        hit = sorted({*hit, *(f.id for f in tr.flags)})
        res.caveats = hit
        res.evidence = {**res.evidence, "rule_flags": [{"id": f.id, "row": f.row, "reason": f.reason}
                                                       for f in tr.flags]}
        cls = cav.classify(hit, catalogue)
    post = ctx.postpass.apply(tr.sql)
    partial = post.sql if cdf is not None else ""      # the stream rule's own draft: offered to the reviewer
    problems = post.problems
    rule_escalations = [f"{f.id}: {f.reason}" for f in tr.flags if f.severity == "escalate"]
    if problems:
        return escalate(rule_escalations + problems, partial)
    kind = sniff_kind(post.sql)
    problems = validate(kind, post.sql)
    if problems:
        return escalate(problems, partial)
    leftover = rsd.scan(post.sql, ctx.conversion.capabilities)
    if not leftover.clean:                         # X3: sqlglot passed a Snowflake-only construct through
        hit = sorted({*hit, rsd.RESIDUE_CAVEAT})
        res.caveats = hit
        # an escalate flag of a rule (a time-travel STATEMENT, ...) leaves its clause in the draft: name it first
        why_rule = [f"{f.id}: {f.reason}" for f in tr.flags if f.severity == "escalate"]
        return escalate(why_rule + leftover.reasons(), partial or post.sql)
    if cls["escalate"]:
        rule_reasons = [f"{f.id}: {f.reason}" for f in tr.flags if f.severity == "escalate"]
        return escalate(rule_reasons + [f"escalate caveat {c}: tier 0 output is not trusted" for c in cls["escalate"]
                                        if c not in {f.id for f in tr.flags}], post.sql if rule_reasons else "")
    if kind == "cte_chain":
        cc = column_check(post.sql, ctx.catalogue)
        res.column_check = cc.status
        if cc.status == "failed":
            return escalate([f"column check failed: {m}" for m in cc.missing] or [cc.reason])
    else:
        res.column_check = "unverifiable" if ctx.catalogue is None else "not_applicable"
    review = list(cls["review"]) + extra_review
    if post.renamed:
        review.append("SNW-UDF-OVERLOAD")
    if post.assumed and pre.engine in ctx.postpass.ctx.assume_engines:
        res.assumed = post.assumed
        review.append("SNW-NAME-RESOLUTION")
    if cfg.get("always_review"):
        review.append(f"always_review:{pre.engine}")
    res.sql, res.kind, res.origin, res.state = post.sql, kind, "mapped", "derived"
    if cdf is not None:
        res.params = {**res.params, "change_data_feed": {"tables": cdf.tables, "parameter": cdf.parameter,
                                                         "note": cdf.note}}
    res.review_caveats = sorted(set(review))
    res.params = {**res.params, "conversion": ctx.conversion.summary()}
    res.attempts = [TranslationAttempt(0, "ok", caveats=hit).as_dict()]
    return res, None


_TXN_STMT = re.compile(r"^\s*(?:BEGIN\s+(?:TRANSACTION|WORK|NAME)|START\s+TRANSACTION|COMMIT|ROLLBACK)\b", re.I)


def _scripting_services(ctx: UnitContext, engine: str) -> sc.Services:
    """The statement translation the scripting converter calls for every inner statement and expression: the SAME
    tier 0 a view gets (sqlglot + pack rules + post-pass + validators + caveat scan + residue guard), so the semantic
    rules apply inside procedure bodies. The column check is off inside a body (a variable is not a column)."""
    inner = dataclasses.replace(ctx, catalogue=None)

    def statement(text: str) -> sc.Translated:
        pre = PreUnit(f"{ctx.etl_key}-in", {"sql": text.strip(), "engine": engine, "language": "sql", "params": {}},
                      engine)
        res, item = tier0_unit(pre, inner)
        if item is not None:
            raise sc.ScriptingUnsupported("; ".join(res.reasons) or "the statement was not converted")
        return sc.Translated(res.sql, list(res.review_caveats), list(res.caveats))

    def call_target(name: str) -> dict | None:
        info = tier0_call(f"CALL {name}()", ctx)
        if info is not None and "notebook_params" in info:
            info = {**info, "notebook": True}
        return info

    return sc.Services(statement, call_target, ctx.dynamic_shim or None)


def scripting_unit(doc: dict, pres: list[PreUnit], ctx: UnitContext) -> tuple[UnitResult | None, list[str]]:
    """Tier 0 for a procedure body (or an anonymous block in a task) with control flow, handlers, cursors, RETURN or
    transactions: ``(one UnitResult for the whole body, [])``, or ``(None, [reasons])`` when it is not a scripting
    body / cannot be converted (the units then escalate one by one, with the reasons added).

    Input contract: the pack's splitter (``split_scripting`` nodes). Output: Databricks SQL scripting, the statements
    between ``AS BEGIN`` and ``END`` (procedure) or one compound statement (task); the handler wraps it. Capability
    profile: ``sql_scripting`` false -> a flag (a Python notebook is needed); ``sql_procedures`` false -> the body is
    kept as an anonymous compound statement for a notebook cell (``params["procedure"]["form"] == "notebook"``)."""
    engine = str(doc.get("engine") or "")
    if engine not in ("sql_procedure", "task") or not pres or any(p.unavailable for p in pres):
        return None, []
    text = ct._sql_text(doc)
    if text is None:
        return None, []
    body = ct.query_of_definition(engine, text)
    if engine == "task":
        if len(pres) != 1 or not is_scripting(body):
            return None, []
    elif not (any(p.logic.get("node_kind") in _WHOLE for p in pres)
              or any(_TXN_STMT.match(p.source_text) for p in pres)):
        return None, []
    caps = ctx.conversion
    if not caps.has("sql_scripting"):
        return None, [f"capability profile {caps.capabilities.name!r} has no SQL scripting (sql_scripting is false): a "
                      "body with control flow, variables or handlers needs a Python notebook, which no deterministic "
                      "rule produces"]
    catalogue = ctx.caveat_catalogue
    header = procedure_header(text) if engine == "sql_procedure" else {}
    pairs = ct.signature_pairs(doc) if engine == "sql_procedure" else []
    returns = header.get("returns") or str((doc.get("params") or {}).get("data_type") or "") or None
    try:
        nodes = split_scripting(body)
        conv = sc.convert(nodes, _scripting_services(ctx, engine), params=[n for n, _ in pairs], returns=returns,
                          script=engine == "task", procedures=ctx.procedure_returns, refactor=ctx.refactor_loops)
    except sc.ScriptingUnsupported as exc:
        return None, [f"scripting conversion: {exc}"]
    hit = conv.caveats                # what the statements inside hit (each went through tier 0 and its own scan)
    cls = cav.classify(hit, catalogue)
    leftover = rsd.scan(conv.text, caps.capabilities)
    if not leftover.clean:
        return None, leftover.reasons()
    pre = PreUnit(f"{ctx.etl_key}-s0", {**pres[0].logic, "sql": body}, engine)
    res = UnitResult(pre.unit_id, engine, source_text=body, fingerprint=_fingerprint(pre),
                     params=dict(doc.get("params") or {}))
    form = "script" if engine == "task" else "procedure" if caps.has("sql_procedures") else "notebook"
    res.sql, res.kind, res.origin, res.state, res.status = conv.text, "script_body", "mapped", "derived", "resolved"
    res.caveats = hit
    res.column_check = "unverifiable"
    res.review_caveats = sorted({*cls["review"], *conv.review})
    res.params = {**res.params, "conversion": caps.summary(),
                  "scripting_notes": [{"id": c, "note": m} for c, m in conv.notes],
                  "procedure": {"form": form, "returns": conv.returns, "return_type": conv.return_type,
                                "return_assumed": conv.return_assumed, "execute_as": header.get("execute_as", ""),
                                "param_names": [n for n, _ in pairs], "refactored": conv.refactored}}
    res.attempts = [TranslationAttempt(0, "ok", caveats=hit).as_dict()]
    return res, []


def phase_a_units(doc: dict, ctx: UnitContext) -> list[SqlUnit]:
    """Phase A (pure): the units tier 0 could not resolve, as the transpiler's input."""
    out = []
    pres = pre_units(doc, ctx.etl_key)
    if scripting_unit(doc, pres, ctx)[0] is not None or code_units.code_unit(doc, pres, ctx)[0] is not None:
        return out                       # the whole body is converted by rule: nothing for the later tiers
    for pre in pres:
        _, item = tier0_unit(pre, ctx)
        if item is not None and not cav.classify(item["caveats"], ctx.caveat_catalogue)["block"]:
            out.append(SqlUnit(ctx.etl_key, pre.unit_id, pre.source_text, _fingerprint(pre)))
    return out


def build_chain(ctx: UnitContext) -> ChainTranslator:
    s = ctx.settings
    tiers: list[Any] = []
    if "lakebridge" in s.tiers:
        cache = ctx.tier1_cache if s.lakebridge_enabled else None
        tiers.append(LakebridgeTier(cache, allowed_tools=s.lakebridge_transpilers,
                                    reason=ctx.tier1_reason or "Lakebridge is not enabled for this run"))
    if "llm" in s.tiers:
        tiers.append(LlmTier(ctx.llm))
    if "human" in s.tiers:
        tiers.append(HumanTier())
    return ChainTranslator(tiers, postpass=ctx.postpass, validate=ctx.validate_fn, min_confidence=s.min_confidence,
                           block_caveats=ctx.caveat_catalogue.ids_with("block"))


async def translate_etl(doc: dict, ctx: UnitContext, *, edits: dict[str, str] | None = None,
                        out_of_scope: dict[str, str] | None = None) -> list[UnitResult]:
    """``edits`` (unit id -> hand-written text) and ``out_of_scope`` (unit id -> the reviewer's reason) come from an
    approved review on resume; they apply only to a unit the chain could not resolve. The tier-0 results then go
    through the judges, the refactors and the equivalence check (S5 / S6, ``post_tier0``)."""
    results = await _translate_units(doc, ctx, edits=edits, out_of_scope=out_of_scope)
    return post_tier0.run(results, doc, ctx)


async def _translate_units(doc: dict, ctx: UnitContext, *, edits: dict[str, str] | None = None,
                           out_of_scope: dict[str, str] | None = None) -> list[UnitResult]:
    pres = pre_units(doc, ctx.etl_key)
    whole, why = scripting_unit(doc, pres, ctx)
    code_hit: list[str] = []
    if whole is None:                    # S2: JavaScript / Snowpark Python (and the Java / Scala packaging note)
        whole, code_why, code_hit = code_units.code_unit(doc, pres, ctx)
        why = why or code_why
    if whole is not None:
        return [whole]
    results: dict[str, UnitResult] = {}
    items: list[dict] = []
    for pre in pres:
        res, item = tier0_unit(pre, ctx)
        results[pre.unit_id] = res
        if item is not None:
            items.append(item)
    if items:
        chain = build_chain(ctx)
        answers = await chain.resolve_tail(SimpleNamespace(unresolved=items))
        cap = ctx.settings.unverified_cap
        for item in items:
            sid = item["step"]
            res, ans = results[sid], answers[sid]
            res.attempts = [a.as_dict() for a in ans.attempts]
            if ans.resolution is not None:
                r = ans.resolution
                res.sql, res.kind, res.origin, res.state = r.sql, sniff_kind(r.sql), r.origin, r.state
                res.confidence = r.confidence
                if r.origin == "ai" and ctx.catalogue is None and r.confidence is not None:
                    res.confidence = min(r.confidence, cap)       # an unverifiable column check caps confidence
                res.evidence = dict(r.evidence)
                res.attempts = [a.as_dict() for a in r.trace]
                res.reasons = []
                res.status = "resolved"
                res.review_caveats = sorted(set(res.review_caveats) | set(res.caveats) - {"SNW-IFF", "SNW-DATEADD",
                                                                                         "SNW-QUALIFY"})
            else:
                res.status, res.origin = "awaiting_review", "unresolved"
                res.reasons = list(res.reasons) + [ans.why_not]
    for pre in pres:
        res = results[pre.unit_id]
        if res.status == "resolved":
            continue
        if why and res.no_code:
            res.reasons = [*why, *res.reasons]       # the precise reason the scripting converter could not take it
            res.caveats = sorted({*res.caveats, *code_hit})
        res.reviewed_as = (res.origin, res.status)
        if edits and (edits.get(pre.unit_id) or "").strip():
            apply_edit(res, str(edits[pre.unit_id]), ctx)
        elif out_of_scope and pre.unit_id in out_of_scope:
            res.status, res.origin = "unsupported", "unresolved"
            res.reasons = [f"marked out of scope by the reviewer: {out_of_scope[pre.unit_id] or 'no reason given'}"]
    return [results[p.unit_id] for p in pres]


def apply_edit(res: UnitResult, text: str, ctx: UnitContext) -> None:
    """A reviewer's text becomes the unit's code (origin ``manual``). It passes the same post-pass and validator as
    any draft: a text that does not validate leaves the unit unresolved, with the problems as reasons."""
    text = text.strip().rstrip(";").strip()
    problems = ctx.validate_fn(text)
    if problems:
        res.reasons = [f"the reviewer's edit does not validate: {p}" for p in problems]
        res.edit_rejected = True
        return
    res.sql, res.kind, res.origin, res.state = text, sniff_kind(text), "manual", "provided"
    res.status, res.edited, res.confidence = "resolved", True, None
    res.attempts = [*res.attempts, TranslationAttempt(3, "ok", ["hand-written by the reviewer"]).as_dict()]
    res.reasons, res.review_caveats = [], sorted(set(res.review_caveats))


def tier_status(attempts: list[dict], tier: int) -> str:
    for a in attempts:
        if a.get("tier") == tier:
            return a.get("status", "")
    return ""


def coverage(results: list[UnitResult]) -> dict:
    return coverage_of(r.origin if r.status == "resolved" else "unresolved" for r in results)


def tier_report(results: list[UnitResult]) -> dict:
    """Coverage per tier. Tier 1 reads ``unavailable`` (not zero) when Lakebridge was absent for every unit."""
    attempts = [a for r in results for a in r.attempts]
    t1 = [a for a in attempts if a.get("tier") == 1]
    t1_state = ("unavailable" if t1 and all(a["status"] == UNAVAILABLE for a in t1)
                else "used" if any(a["status"] == "ok" for a in t1) else "not_reached" if not t1 else "no_output")
    return {"tier0": sum(1 for r in results if r.origin == "mapped" and r.status == "resolved"),
            "tier1": {"state": t1_state, "units": sum(1 for r in results if r.origin == "transpiled")},
            "tier2": sum(1 for r in results if r.origin == "ai"),
            "tier3": sum(1 for r in results if r.status != "resolved")}


def make_context(*, etl_key: str, engine: str, table_map: dict, default_db: str = "", default_schema: str = "",
                 settings: TranslationSettings | None = None, **kw: Any) -> UnitContext:
    pp = Postpass(PostpassContext(table_map=table_map, default_db=default_db, default_schema=default_schema,
                                  engine=engine, source_columns=kw.pop("source_columns", {}) or {},
                                  convention=frozenset(kw.pop("convention", ())),
                                  default_catalog=str(kw.get("default_catalog") or "main"),
                                  overload_calls=dict(getattr(kw.get("overloads"), "by_call", None) or {})))
    return UnitContext(etl_key=etl_key, postpass=pp, settings=settings or TranslationSettings(), **kw)


__all__ = ["PACK_VERSION", "PreUnit", "UnitContext", "UnitResult", "build_chain", "coverage", "make_context",
           "phase_a_units", "pre_units", "tier0_unit", "tier_report", "tier_status", "translate_etl"]
