"""packs.snowflake.dynamic_sql - X6: the runtime transpile shim for dynamic SQL (catalogue rows 5.7 and X6).

``EXECUTE IMMEDIATE <text built at run time>`` holds SNOWFLAKE SQL that no converter ever sees. The only safe
deterministic answer is to transpile it when it is built: the shim is sqlglot (pinned like the pack's own)
running inside the target.
Two artifacts, both OPT IN (``target.dynamic_sql_shim`` in the manifest, ``SNW-DYNAMIC-SQL-SHIM`` review flag on every
use, never auto-approved):

    shim_notebook_source()   a notebook module: ``run_snowflake_sql(spark, text)`` transpiles, LOGS (source hash,
                             outcome, transpiled text) and then ``spark.sql``; a text that does not transpile raises,
                             nothing runs
    shim_function_ddl(fqn)   the same transpile as a Unity Catalog Python function ``fqn(text) RETURNS STRING`` that a
                             converted SQL-scripting body calls: ``EXECUTE IMMEDIATE fqn(<expression>)``

The runtime transpile is the pack's tier 0 minus the rules that need the conversion context (parameters, column types):
a statement whose meaning depends on one of those is converted with sqlglot's defaults, which is why the use is flagged.
"""
from __future__ import annotations

import sqlglot

SHIM_CAVEAT = "SNW-DYNAMIC-SQL-SHIM"
SHIM_NOTE = ("the SQL text is built at run time and transpiled at run time (sqlglot snowflake -> databricks, no context "  # noqa: E501
             "rules: parameters, column types and the S17 rewrites do not apply); every executed text is logged")

_BODY = '''
import hashlib
import logging

import sqlglot

log = logging.getLogger("snowflake_runtime_shim")


def transpile_snowflake(text):
    """Snowflake SQL text -> Databricks SQL text (one statement per call)."""
    out = sqlglot.transpile(text, read="snowflake", write="databricks")
    if len(out) != 1:
        raise ValueError(f"expected one statement, got {len(out)}")
    return out[0]
'''


def shim_notebook_source() -> str:
    return (f"# Runtime transpile shim (catalogue X6). sqlglot=={sqlglot.__version__}. {SHIM_NOTE}.\n" + _BODY + '''

def run_snowflake_sql(spark, text):
    """Transpile, log, run. A text that does not transpile raises and nothing is executed."""
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]
    try:
        converted = transpile_snowflake(text)
    except Exception as exc:
        log.error("shim %s: not transpiled (%s)", digest, type(exc).__name__)
        raise
    log.warning("shim %s: running %s", digest, converted)
    return spark.sql(converted)
''')


def shim_function_ddl(fqn: str) -> str:
    body = _BODY.replace('log = logging.getLogger("snowflake_runtime_shim")\n', "")
    indented = "\n".join(("  " + ln) if ln.strip() else ln for ln in (body + "\nreturn transpile_snowflake(text)\n").splitlines())  # noqa: E501
    return (f"CREATE OR REPLACE FUNCTION {fqn}(text STRING)\nRETURNS STRING\nLANGUAGE PYTHON\n"
            f"ENVIRONMENT (dependencies = '[\"sqlglot=={sqlglot.__version__}\"]', environment_version = 'None')\n"
            f"COMMENT '{SHIM_NOTE.replace(chr(39), '')}'\nAS $$\n{indented}\n$$")


__all__ = ["SHIM_CAVEAT", "SHIM_NOTE", "shim_function_ddl", "shim_notebook_source"]
