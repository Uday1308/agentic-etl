# Ported from SNF2DBX-main/judges/rules.py and SNF2DBX-main/converters/refactor.py (LatentView internal): the
# deterministic judge families (PERF, CONC, POL, SEM, LIN, DET, STR) and the REF002 / REF003 refactors, reshaped from
# the file-bundle judge into a per-unit pass over a tier-0 result.
"""packs.snowflake.judges - the deterministic judge pass after tier 0 (S6, ADR 037 section 2).

Never calls a model. Reads one resolved tier-0 ``UnitResult`` (the Snowflake source text, the Databricks output text,
the ``UnitContext``) and returns findings, each one a caveat id from the new families SNW007-SNW012:

=========  =========================================================================================================
family     judges (SNF2DBX rule it comes from)
=========  =========================================================================================================
SNW007     performance and concurrency: PERF001 row-by-row loop running DML, PERF002 COUNT(*) pre-query that repeats
           the next statement, CONC001 key generated from MAX(id)
SNW008     policy and safety: POL001 role switch / privileged role, destructive DDL, GRANT, hard-coded credential,
           Databricks token, Snowflake warehouse name left in the code
SNW009     semantic declarations: SEM001 column set changed, SEM004 CURRENT_ROLE(), SEM005 session / time-zone
           sensitive functions
SNW010     lineage: LIN001 a source table is not read by the output, LIN003 a CALLed procedure is not invoked
SNW011     determinism and structure: DET003 a function of another database, STR002 an unresolved ``__PENDING_n__``
           slot, STR004 an empty output
SNW012     refactors applied here: REF002 row count read from the Delta commit metrics (instead of a COUNT(*)
           pre-query), REF003 concurrency-safe key read-back by a uuid() run id (instead of MAX(id))
=========  =========================================================================================================

Delegated, not repeated: DET002 (Snowflake-only construct left) is the residue guard (``residue.py``); STR003 (output
parses) is the per-kind validators; REF001 is ``scripting_refactor.py``; SNF001-003 are ``assembly.py`` reasons;
SRC001 is the "definition unavailable" manual unit; LIN002 / LIN004 / DET001 are batch-level (see leftovers in the
change notes). Severities come from ``caveats.yaml`` once the ids are appended there, else from ``CAVEAT_TABLE``
below (the single source the yaml block is generated from).

Evidence never carries source text (hard rule 11): a finding names a function, a table or a column, never a literal.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from packs.snowflake import caveats as cav

FAMILIES = {
    "SNW007": "performance and concurrency (judges)",
    "SNW008": "policy and safety (judges)",
    "SNW009": "semantic declarations (judges)",
    "SNW010": "lineage (judges)",
    "SNW011": "determinism and structure (judges)",
    "SNW012": "refactors applied by the engine",
    "SNW013": "equivalence check (S5)",
    "SNW014": "objects and patterns (S8)",
}

#: id -> (family, severity, note). The yaml block in ``caveats.yaml`` is generated from this table.
CAVEAT_TABLE: dict[str, tuple[str, str, str]] = {
    "SNW-PERF-ROW-LOOP": ("SNW007", "review", "PERF001: a row-by-row loop runs DML on every iteration; slow on a distributed engine, rewrite set-based"),  # noqa: E501
    "SNW-PERF-PRECOUNT": ("SNW007", "review", "PERF002: a COUNT(*) pre-query repeats the next statement's work just to get its row count"),  # noqa: E501
    "SNW-CONC-MAX-KEY": ("SNW007", "review", "CONC001: a key generated from MAX(id) races under concurrency; use an identity column or uuid()"),  # noqa: E501
    "SNW-POL-ROLE": ("SNW008", "review", "POL001: a role switch or a privileged role reference (ACCOUNTADMIN / SECURITYADMIN) in migrated code"),  # noqa: E501
    "SNW-POL-DDL": ("SNW008", "review", "POL001: destructive DDL (DROP TABLE / SCHEMA / DATABASE / VIEW) inside migrated logic"),  # noqa: E501
    "SNW-POL-GRANT": ("SNW008", "review", "POL001: a GRANT statement inside migrated logic; privileges go through the access framework (ADR 034)"),  # noqa: E501
    "SNW-POL-CREDENTIAL": ("SNW008", "escalate", "POL001: a hard-coded credential or Databricks token; never shipped, use a secret scope"),  # noqa: E501
    "SNW-POL-WAREHOUSE": ("SNW008", "review", "POL001: a Snowflake warehouse name is referenced; Databricks compute is configured on the job"),  # noqa: E501
    "SNW-SEM-COLUMNS": ("SNW009", "review", "SEM001: the output's column set differs from the source's (names compared case-insensitively)"),  # noqa: E501
    "SNW-SEM-CURRENT-ROLE": ("SNW009", "review", "SEM004: CURRENT_ROLE() has no Databricks equivalent (no session role)"),  # noqa: E501
    "SNW-SEM-SESSION-TZ": ("SNW009", "info", "SEM005: a time-zone or session sensitive function; the session time zone is not pinned on Databricks"),  # noqa: E501
    "SNW-LIN-TABLE-DROPPED": ("SNW010", "review", "LIN001: a table the source reads is not read by the converted code"),
    "SNW-LIN-CALL-DROPPED": ("SNW010", "review", "LIN003: a procedure the source CALLs is not invoked by the converted code"),  # noqa: E501
    "SNW-DET-FOREIGN-FN": ("SNW011", "escalate", "DET003: a function of another database that Databricks does not have (a typical model mistake)"),  # noqa: E501
    "SNW-STR-PENDING": ("SNW011", "escalate", "STR002: an unresolved __PENDING_n__ slot in the output"),
    "SNW-STR-EMPTY": ("SNW011", "escalate", "STR004: the output has no executable statement"),
    "SNW-REF-ROWCOUNT": ("SNW012", "review", "REF002: the row count is read from the Delta commit metrics of the statement instead of a COUNT(*) pre-query; a concurrent writer to the same table can be read instead"),  # noqa: E501
    "SNW-REF-RUNID": ("SNW012", "review", "REF003: the key is read back by a uuid() run id tagged on the inserted row instead of MAX(id)"),  # noqa: E501
    "SNW-EQUIV-EXPLAINED": ("SNW013", "info", "S5: source and output differ, and every difference is a declared rewrite"),  # noqa: E501
    "SNW-EQUIV-DIFF": ("SNW013", "review", "S5: source and output differ in a way no rule explains (structure or sample data); a reviewer decides"),  # noqa: E501
    "SNW-MULTI-INSERT": ("SNW014", "review", "4.3: multi-table INSERT became one INSERT per target from one temporary view; not atomic (a failure between targets leaves some loaded)"),  # noqa: E501
    "SNW-SEQ-IDENTITY": ("SNW014", "review", "6.11: a sequence became an identity column; values, gaps and ORDER are not the sequence's"),  # noqa: E501
    "SNW-SEQ-SHARED": ("SNW014", "escalate", "6.11: a sequence shared by several tables or called outside an INSERT has no single identity column; choose identity per table, uuid(), a counter table or row_number() + max"),  # noqa: E501
    "SNW-EXT-TABLE": ("SNW014", "review", "6.10: external table converted to a Unity Catalog external table or a file load; confirm the external location and the schema"),  # noqa: E501
    "SNW-EXT-LOCATION": ("SNW014", "review", "6.10 / 6.9: the stage URL is not known to the migrator; the location is a placeholder to resolve to an external location"),  # noqa: E501
    "SNW-ALERT-JOB": ("SNW014", "review", "6.7: alert converted to a paused job with a condition task and a notification; confirm the action and unpause"),  # noqa: E501
    "SNW-STREAM-TYPE": ("SNW014", "review", "6.4: stream type (append-only / insert-only / SHOW_INITIAL_ROWS) mapped to a change data feed filter; confirm"),  # noqa: E501
    "SNW-AUTO-CDC": ("SNW014", "review", "6.5: stream + task + MERGE converted to one AUTO CDC flow over the change data feed; the sequencing column is the commit version"),  # noqa: E501
}

#: caveats that declare a column was renamed on purpose (casing contract, collision aliases)
_RENAMES = frozenset({"SNW-QUOTED-IDENT", "SNW-QUOTED-CASE-COLLISION", "SNW-QUOTED-CASE-UNRESOLVED", "SNW-ALIAS-INLINED",  # noqa: E501
                      "SNW-OBJECT-STAR"})
PENDING_RX = re.compile(r"__PENDING_\d+__")
_TZ_RX = re.compile(r"\b(CURRENT_TIMESTAMP|SYSDATE|LOCALTIMESTAMP|CURRENT_TIME|CONVERT_TIMEZONE|GETDATE|TIMESTAMP_LTZ)\b",  # noqa: E501
                    re.I)
_FOREIGN_RX = re.compile(
    r"\b((?:PG_SLEEP(?:_FOR|_UNTIL)?|DBMS_LOCK\.SLEEP|DBMS_SESSION\.SLEEP|GETDATE|GETUTCDATE|SYSDATETIME|"
    r"STRING_TO_ARRAY|GENERATE_SERIES|TO_TSVECTOR|JSONB_\w+)\s*\(|WAITFOR\s+DELAY|ISNULL\s*\([^,()]+,|"
    r"SELECT\s+TOP\s+\d+|\bROWNUM\b)", re.I)
_POL = (
    ("SNW-POL-ROLE", re.compile(r"\bUSE\s+(?:SECONDARY\s+)?ROLES?\b|\bACCOUNTADMIN\b|\bSECURITYADMIN\b", re.I),
     "role switch or privileged role"),
    ("SNW-POL-DDL", re.compile(r"\bDROP\s+(?:TABLE|SCHEMA|DATABASE|CATALOG|VIEW)\b", re.I), "destructive DDL"),
    ("SNW-POL-GRANT", re.compile(r"^\s*GRANT\s+.+\s+TO\b|;\s*GRANT\s+.+\s+TO\b", re.I | re.S), "grant statement"),
    ("SNW-POL-CREDENTIAL", re.compile(r"\b(?:password|secret|token)\s*[=:]\s*['\"][^'\"]{4,}['\"]|\bdapi[0-9a-f]{32}\b",
                                      re.I), "hard-coded credential"),
)
_SQL_LOOP_DML_RX = re.compile(r"\b(FOR\s+\w+\s+(?:AS|IN)\b|WHILE\b|LOOP\b|REPEAT\b)(?:(?!\bEND\s+(?:FOR|WHILE|LOOP|REPEAT)\b).)*?"  # noqa: E501
                              r"\b(MERGE\s+INTO|INSERT\s+INTO|UPDATE\s+\w|DELETE\s+FROM)\b", re.I | re.S)
_MAX_KEY_RX = re.compile(
    r"(?:(?::=|=)\s*\(?\s*SELECT\s+(?:(?:COALESCE|NVL|IFNULL|ZEROIFNULL)\s*\(\s*)?MAX\s*\(\s*(\w*(?:ID|KEY)\w*)\s*\)"
    r"|MAX\s*\(\s*(\w*(?:ID|KEY)\w*)\s*\)\s*(?:,\s*\w+\s*)?\)?\s*\+\s*1)", re.I)
_PRECOUNT_RX = re.compile(r"SET\s+(\w+)\s*=\s*\(\s*SELECT\s+COUNT\s*\(\s*\*\s*\)\s+FROM\s+\((.+?)\)\s*AS\s+\w+\s*\)\s*;",  # noqa: E501
                          re.I | re.S)
_DML_AFTER_RX = re.compile(r"\b(MERGE\s+INTO|INSERT\s+(?:OVERWRITE\s+)?INTO|UPDATE|DELETE\s+FROM)\s+([\w.`]+)", re.I)
_CALL_RX = re.compile(r"\bCALL\s+([\w.\"`$]+)\s*\(", re.I)
_METRICS = {"MERGE": ("numTargetRowsInserted", "numTargetRowsUpdated", "numTargetRowsDeleted"),
            "INSERT": ("numOutputRows",), "UPDATE": ("numUpdatedRows",), "DELETE": ("numDeletedRows",)}


@dataclass
class Finding:
    id: str
    reason: str
    severity: str = ""

    def __post_init__(self) -> None:
        self.severity = self.severity or severity_of(self.id)


def severity_of(caveat_id: str) -> str:
    entry = cav.load_catalogue().by_id().get(caveat_id)
    if entry is not None:
        return entry.severity
    return CAVEAT_TABLE[caveat_id][1]


def yaml_block() -> str:
    """The ``caveats:`` lines (and the families) the catalogue needs for these ids, generated from ``CAVEAT_TABLE``."""
    lines = [f"  {fam}: {title}" for fam, title in FAMILIES.items()]
    out = ["families:"] + lines + ["migrator_only:"]
    for cid, (fam, sev, note) in CAVEAT_TABLE.items():
        out.append(f"  - {{id: {cid}, family: {fam}, severity: {sev}, detect: {{pattern: '(?!x)x'}},\n"
                   f"     note: \"{note}\"}}")
    return "\n".join(out)


def _code(text: str) -> str:
    """The text with strings and comments blanked: a judge never matches inside a literal."""
    return cav.blank_literals(text or "")


def _norm(sql: str) -> str:
    return re.sub(r"\s+", " ", sql).strip().lower().rstrip(";")


def _tables(sql: str, dialect: str) -> set[str] | None:
    try:
        trees = [t for t in sqlglot.parse(sql, read=dialect) if t is not None]
    except SqlglotError:
        return None
    out: set[str] = set()
    for tree in trees:
        ctes = {str(c.alias).lower() for c in tree.find_all(exp.CTE)}
        for t in tree.find_all(exp.Table):
            if isinstance(t.this, exp.Identifier) and t.name and t.name.lower() not in ctes:
                out.add(t.name.lower())
        for fn in tree.find_all(exp.Anonymous):             # TABLE_CHANGES('c.s.t', ...) reads t
            lit = fn.expressions[0] if fn.expressions else None
            if str(fn.this).upper() in ("TABLE_CHANGES", "IDENTIFIER") and isinstance(lit, exp.Literal) and lit.is_string:  # noqa: E501
                out.add(str(lit.this).split(".")[-1].strip('"`').lower())
    return out


def _select_names(sql: str, dialect: str) -> list[str] | None:
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except SqlglotError:
        return None
    if isinstance(tree, exp.Create):
        tree = tree.expression
    if not isinstance(tree, exp.Query):
        return None
    sel = tree.this if isinstance(tree, exp.Subquery) else tree
    while isinstance(sel, exp.SetOperation):
        sel = sel.this
    if not isinstance(sel, exp.Select):
        return None
    if any(isinstance(p, exp.Star) or (isinstance(p, exp.Column) and isinstance(p.this, exp.Star))
           for p in sel.expressions):
        return None                                   # a star's column set is the table's: not decidable here
    return [str(n).lower() for n in sel.named_selects]


# ------------------------------------------------------------------------------------------------ the judges
def judge_text(source: str, out: str, *, kind: str = "", source_is_sql: bool = True,
               name_map: dict[str, str] | None = None, warehouses: set[str] | None = None,
               declared: set[str] | frozenset[str] = frozenset()) -> list[Finding]:
    """Every judge over one (source, output) pair. Pure: no context beyond the two texts, ``name_map`` (source table
    name, lower case -> target table name), the Snowflake warehouse names of the account and ``declared``, the caveats
    the unit already carries (a rename a rule declared is not a lost column)."""
    found: list[Finding] = []
    code, src_code = _code(out), _code(source)

    if PENDING_RX.search(out):
        found.append(Finding("SNW-STR-PENDING", "an unresolved __PENDING_n__ slot is left in the output"))
    if not re.sub(r"[\s;]", "", code):
        found.append(Finding("SNW-STR-EMPTY", "the output has no executable statement"))
    for m in sorted({m.group(1).strip().rstrip("(").strip().upper() for m in _FOREIGN_RX.finditer(code)}):
        found.append(Finding("SNW-DET-FOREIGN-FN", f"{m} is not a Databricks construct"))
    for cid, rx, what in _POL:
        if rx.search(out if cid == "SNW-POL-CREDENTIAL" else code):
            found.append(Finding(cid, f"{what} in migrated logic"))
    if warehouses:
        for w in sorted(warehouses):
            if re.search(rf"\b{re.escape(w)}\b", code, re.I):
                found.append(Finding("SNW-POL-WAREHOUSE", f"Snowflake warehouse {w} is referenced"))
    hits = sorted({m.group(1).upper() for m in _TZ_RX.finditer(src_code)})
    if hits:
        found.append(Finding("SNW-SEM-SESSION-TZ", "time-zone / session sensitive: " + ", ".join(hits)))
    if re.search(r"\bCURRENT_ROLE\s*\(", src_code, re.I):
        found.append(Finding("SNW-SEM-CURRENT-ROLE", "CURRENT_ROLE() in the source has no Databricks session role"))
    if _SQL_LOOP_DML_RX.search(code):
        found.append(Finding("SNW-PERF-ROW-LOOP", "a loop runs DML on every iteration (cursor style)"))
    for m in _MAX_KEY_RX.finditer(code):
        found.append(Finding("SNW-CONC-MAX-KEY", f"key generated from MAX({m.group(1) or m.group(2)})"))
    for m in _PRECOUNT_RX.finditer(code):
        after = _DML_AFTER_RX.search(code, m.end())
        if after and _norm(m.group(2)) in _norm(code[after.start():after.start() + 20000]):
            found.append(Finding("SNW-PERF-PRECOUNT", "a COUNT(*) pre-query repeats the next statement's query"))

    if source_is_sql and kind in ("cte_chain", "statement", ""):
        names_in, names_out = _select_names(source, "snowflake"), _select_names(out, "databricks")
        if (names_in is not None and names_out is not None and sorted(names_in) != sorted(names_out)
                and not set(declared) & _RENAMES):
            gone = sorted(set(names_in) - set(names_out))
            new = sorted(set(names_out) - set(names_in))
            found.append(Finding("SNW-SEM-COLUMNS", f"columns only in the source {gone}; only in the output {new}"))
        t_in, t_out = _tables(source, "snowflake"), _tables(out, "databricks")
        if t_in and t_out is not None:
            names = name_map or {}
            lost = sorted(t for t in t_in if names.get(t, t).split(".")[-1] not in t_out)
            # a stream the batch could not name is read through TABLE_CHANGES(<base table>): one such read per stream
            lost = lost[len(re.findall(r"TABLE_CHANGES\s*\(", out, re.I)):] if "TABLE_CHANGES" in out.upper() else lost
            if lost:
                found.append(Finding("SNW-LIN-TABLE-DROPPED", f"the output does not read {lost}"))
    calls_in = {m.group(1).strip('"`').split(".")[-1].lower() for m in _CALL_RX.finditer(src_code)}
    calls_out = {m.group(1).strip('"`').split(".")[-1].lower().removesuffix("__ret") for m in _CALL_RX.finditer(code)}
    if calls_in and not calls_in <= calls_out and kind not in ("call", "execute_task"):
        found.append(Finding("SNW-LIN-CALL-DROPPED", f"the output never invokes {sorted(calls_in - calls_out)}"))
    return found


# ------------------------------------------------------------------------------------------------ REF002 / REF003
@dataclass
class Refactored:
    sql: str
    applied: list[Finding] = field(default_factory=list)


def refactor_rowcount(sql: str) -> Refactored:
    """REF002: ``SET v = (SELECT COUNT(*) FROM (<q>) AS x); <DML repeating q>`` -> the DML, then ``SET v`` read from the
    Delta commit metrics of that statement (``DESCRIBE HISTORY <table> LIMIT 1``). Only when the next statement repeats
    the counted query (that is the double work), and only for a kind with known metrics."""
    out, applied, cursor = sql, [], 0
    while True:
        m = _PRECOUNT_RX.search(out, cursor)
        if not m:
            break
        cursor = m.end()
        after = _DML_AFTER_RX.search(out, m.end())
        if not after or _norm(m.group(2)) not in _norm(out[after.start():after.start() + 20000]):
            continue
        end = out.find(";", after.start())
        end = len(out) if end < 0 else end + 1
        kind = re.match(r"(MERGE|INSERT|UPDATE|DELETE)", after.group(1), re.I).group(1).upper()
        total = " + ".join(f"COALESCE(CAST(operationMetrics['{x}'] AS BIGINT), 0)" for x in _METRICS[kind])
        read = f"SET {m.group(1)} = (SELECT {total} FROM (DESCRIBE HISTORY {after.group(2)} LIMIT 1));"
        pad = re.search(r"[ \t]*$", out[:m.start()]).group(0)             # the indentation of the removed SET
        out = (out[:m.start()] + out[m.end():after.start()].lstrip() + out[after.start():end] + "\n" + pad + read
               + out[end:])
        applied.append(Finding("SNW-REF-ROWCOUNT", f"{m.group(1)} after {kind} on {after.group(2)} is read from the "
                                                     "commit metrics"))
        cursor = 0
    return Refactored(out, applied)


_INSERT_VALUES = re.compile(r"INSERT\s+INTO\s+([\w.`]+)\s*\(([^)]*)\)\s*VALUES\s*\((.*?)\)\s*;", re.I | re.S)
_READ_BACK = re.compile(r"SET\s+(\w+)\s*=\s*\(\s*SELECT\s+MAX\s*\(\s*(\w+)\s*\)\s+FROM\s+([\w.`]+)(?:\s+WHERE\s+.*?)?\s*\)\s*;",  # noqa: E501
                        re.I | re.S)


def refactor_runid(sql: str, table_columns: Any) -> Refactored:
    """REF003: ``INSERT INTO t (cols) VALUES (...); SET v = (SELECT MAX(id) FROM t WHERE ...)`` -> tag the row with
    ``run_id_ = uuid()`` and read the key back by that tag. Only when the catalogue says ``t`` has a ``run_id`` column
    (the migrator never adds columns to a table it does not own); otherwise the CONC001 judge flags it."""
    out, applied = sql, []
    for ins in list(_INSERT_VALUES.finditer(sql)):
        rb = _READ_BACK.match(sql, ins.end(), ) or _READ_BACK.search(sql, ins.end(), ins.end() + 600)
        if not rb or rb.group(3).lower() != ins.group(1).lower():
            continue
        cols = table_columns(ins.group(1)) if callable(table_columns) else None
        if not cols or "run_id" not in {c.lower() for c in cols}:
            continue
        stored = (f"INSERT INTO {ins.group(1)} ({ins.group(2).strip()}, run_id) VALUES ({ins.group(3).strip()}, run_id_);")  # noqa: E501
        read = f"SET {rb.group(1)} = (SELECT {rb.group(2)} FROM {ins.group(1)} WHERE run_id = run_id_);"
        new = "SET run_id_ = uuid();\n" + stored + "\n" + read
        out = out.replace(sql[ins.start():rb.end()], new, 1)
        applied.append(Finding("SNW-REF-RUNID", f"{rb.group(1)} read back from {ins.group(1)} by run_id"))
    if applied and "DECLARE run_id_" not in out:
        out = "DECLARE run_id_ STRING;\n" + out
    return Refactored(out, applied)


def refactor(sql: str, table_columns: Any = None) -> Refactored:
    a = refactor_rowcount(sql)
    b = refactor_runid(a.sql, table_columns)
    return Refactored(b.sql, a.applied + b.applied)


__all__ = ["CAVEAT_TABLE", "FAMILIES", "Finding", "Refactored", "judge_text", "refactor", "refactor_rowcount",
           "refactor_runid", "severity_of", "yaml_block"]
