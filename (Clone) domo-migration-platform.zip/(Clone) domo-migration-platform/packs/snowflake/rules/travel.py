"""packs.snowflake.rules.travel - sampling, time travel and the CHANGES clause (catalogue rows 2.19, 2.20, 2.21).

These three used to be dropped silently: the post-pass rebuilt every table reference from its name and alias only, so
``t SAMPLE (10)``, ``t AT(OFFSET => -3600)`` and ``t CHANGES(...)`` came out as a plain ``t`` (a full scan, the current
state, no change feed) with nobody told. The post-pass now keeps those clauses; these rules decide what each one becomes:

    SAMPLE / TABLESAMPLE   sqlglot's ``TABLESAMPLE (n PERCENT | n ROWS) [REPEATABLE (seed)]`` is kept and ALWAYS flagged
                           ``SNW-SAMPLE``: the rows differ on every engine, a seed is repeatable only within Databricks,
                           ``n ROWS`` is a leading-rows limit there, and SYSTEM / BLOCK sampling has no block-level twin
    AT / BEFORE            ``AT(TIMESTAMP => ts)`` -> ``TIMESTAMP AS OF ts``;  ``AT(OFFSET => -s)`` ->
                           ``TIMESTAMP AS OF (CURRENT_TIMESTAMP() - INTERVAL s SECOND)``; ``BEFORE`` has no exact twin
                           (Delta resolves "at or before"): converted one millisecond earlier and flagged;
                           ``STATEMENT => query_id`` has none at all: flagged ``SNW-TIME-TRAVEL-STATEMENT`` (escalate)
    CHANGES(INFORMATION => ...) AT/END   ``table_changes('<table>', start[, end])`` (change data feed); APPEND_ONLY adds
                           ``WHERE _change_type = 'insert'``. Flagged ``SNW-CHANGES``: CDF must be enabled on the table
                           and the feed lists every row-level change, not Snowflake's net change per interval
"""
from __future__ import annotations

import sqlglot
from sqlglot import exp

from packs.snowflake.rules.base import (
    TARGET,
    RuleContext,
    lit_int,
    mark_generated,
    post_order,
    string,
    tpl,
)

HISTORY = ("the landed table has its own Delta history, which starts at its first load and is kept only for "
           "delta.deletedFileRetentionDuration / delta.logRetentionDuration (7 / 30 days by default): a point in time "
           "before that cannot be read")


def _kind(hd: exp.Expression) -> str:
    return str(hd.args.get("kind") or "").upper()


def _point(hd: exp.Expression, rc: RuleContext, row: str, what: str) -> exp.Expression | None:
    """The Databricks timestamp expression of a ``TIMESTAMP => ts`` / ``OFFSET => s`` point, None when it has none
    (``STATEMENT`` -> an escalate flag)."""
    kind, value = _kind(hd), hd.args.get("expression")
    if value is None:
        rc.flag("SNW-TIME-TRAVEL-STATEMENT", f"{what}: the point in time is missing", row)
        return None
    if kind == "TIMESTAMP":
        return value
    if kind == "OFFSET":
        n = lit_int(value)
        if n is not None:
            sign = "-" if n <= 0 else "+"
            return tpl(f"CURRENT_TIMESTAMP() {sign} INTERVAL {abs(n)} SECOND")
        # TIMESTAMPADD(unit, n, ts) is Databricks' own spelling: kept as written (sqlglot would print DATE_ADD)
        return mark_generated(exp.Anonymous(this="TIMESTAMPADD", expressions=[exp.var("SECOND"), value, exp.CurrentTimestamp()]),
                              keep=[value])
    rc.flag("SNW-TIME-TRAVEL-STATEMENT",
            f"{what}: a point in time given as {kind or 'a query id'} (STATEMENT => query_id) has no Delta equivalent; "
            "look up the commit timestamp (DESCRIBE HISTORY) and write TIMESTAMP AS OF / VERSION AS OF by hand", row)
    return None


def rule_sample(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.TableSample):
        method = str(node.args.get("method") or "BERNOULLI").upper()
        size = node.args.get("size") is not None and node.args.get("percent") is None
        bits = ["the sampled rows differ on every engine and on every run"]
        if node.args.get("seed") is not None:
            bits.append("REPEATABLE(seed) repeats within Databricks only: Snowflake's seed picks other rows")
        if size:
            bits.append("n ROWS is a leading-rows limit on Databricks (not a random sample of exactly n rows)")
        if method in ("SYSTEM", "BLOCK"):
            bits.append(f"{method} (block) sampling became row-level percent sampling")
        rc.flag("SNW-SAMPLE", "SAMPLE became TABLESAMPLE: " + "; ".join(bits)
                + ". Anything downstream that must be stable needs a deterministic filter instead", "2.19")


def rule_time_travel(tree: exp.Expression, rc: RuleContext) -> None:
    for table in post_order(tree, exp.Table):
        hd = table.args.get("when")
        if not isinstance(hd, exp.HistoricalData):
            continue
        before = str(hd.this).upper() == "BEFORE"
        what = f"{'BEFORE' if before else 'AT'}({_kind(hd) or '?'} => ...) on {table.name}"
        point = _point(hd, rc, "2.20", what)
        if point is None:
            continue                         # escalate flag: the clause stays so the draft shows what was not converted
        if before:
            point = tpl("__t__ - INTERVAL 1 MILLISECOND", __t__=point)
            rc.flag("SNW-TIME-TRAVEL", f"{what}: BEFORE excludes the point itself and Delta has no strict form; read one "
                                       "millisecond earlier (commit timestamps have millisecond resolution)", "2.20")
        if not isinstance(point, exp.Paren) and not isinstance(point, exp.Literal) and not isinstance(point, exp.Cast):
            point = mark_generated(exp.Paren(this=point), keep=[point])
        table.set("when", None)
        table.set("version", exp.Version(this=exp.var("TIMESTAMP"), expression=point, kind="AS OF"))
        rc.flag("SNW-TIME-TRAVEL", f"{what} became TIMESTAMP AS OF: {HISTORY}", "2.20")


def _qualified(table: exp.Table, rc: RuleContext) -> str:
    return rc.target_of(table) or ".".join(p for p in (table.catalog, table.db, table.name) if p)


def rule_changes(tree: exp.Expression, rc: RuleContext) -> None:
    for table in post_order(tree, exp.Table):
        chg = table.args.get("changes")
        if not isinstance(chg, exp.Changes):
            continue
        name = _qualified(table, rc)
        what = f"CHANGES on {table.name}"
        start_hd, end_hd = chg.args.get("at_before"), chg.args.get("end")
        if not isinstance(start_hd, exp.HistoricalData):
            rc.flag("SNW-TIME-TRAVEL-STATEMENT", f"{what}: no AT / BEFORE starting point to read from", "2.21")
            continue
        start = _point(start_hd, rc, "2.21", what)
        end = _point(end_hd, rc, "2.21", what + " END") if isinstance(end_hd, exp.HistoricalData) else None
        if start is None or (isinstance(end_hd, exp.HistoricalData) and end is None):
            continue
        info = chg.args.get("information")
        append_only = str(getattr(info, "name", info) or "").upper() == "APPEND_ONLY"
        args = [string(name), start] + ([end] if end is not None else [])
        feed = exp.Table(this=exp.Anonymous(this="table_changes", expressions=args))
        mark_generated(feed, keep=[a for a in args[1:]])
        alias = table.args.get("alias")
        if append_only:
            inner = sqlglot.parse_one("SELECT * FROM __f__ WHERE _change_type = 'insert'", read=TARGET)
            inner.find(exp.Table).replace(feed)
            new: exp.Expression = exp.Subquery(this=inner)
            mark_generated(new, keep=[a for a in args[1:]])
        else:
            new = feed
        if alias is not None:
            new.set("alias", alias.copy())
        table.replace(new)
        rc.flag("SNW-CHANGES", f"{what} became table_changes(): enable delta.enableChangeDataFeed on {name} (changes are "
                               "recorded only after it is enabled); the feed lists every row-level change with "
                               "_change_type / _commit_version / _commit_timestamp, not Snowflake's net change per "
                               "interval and its METADATA$ columns"
                + ("; APPEND_ONLY became _change_type = 'insert'" if append_only else ""), "2.21")


# CHANGES carries its own AT / END clauses (not ``when``): the plain time travel rule never sees them
RULES = (rule_sample, rule_changes, rule_time_travel)

__all__ = ["HISTORY", "RULES", "rule_changes", "rule_sample", "rule_time_travel"]
