# Ported from SNF2DBX-main/converters/dialect.py (LatentView internal): the REWRITES registry entries DIV0, DIV0NULL,
# ZEROIFNULL, NULLIFZERO, EQUAL_NULL, BOOLAND, BOOLOR, TO_BOOLEAN, TRY_TO_BOOLEAN, TO_DECIMAL/TO_NUMERIC (lines 59-113).
# Changed: the rules read the Snowflake-parsed tree (``SnowflakeSource`` keeps these calls as anonymous functions, so the
# author's call is what the rule sees), BOOLXOR is added, the BOOL* arguments are cast so non-zero numbers are true, and a
# number format is flagged instead of raising.
"""packs.snowflake.rules.functions - the function set of catalogue row 2.1 and the exact-number conversions.

    DIV0 / DIV0NULL / ZEROIFNULL / NULLIFZERO / EQUAL_NULL / BOOLAND / BOOLOR / BOOLXOR / TO_BOOLEAN /
    TO_DECIMAL / TO_NUMBER (sqlglot's default turns these into DOUBLE casts, silently losing the exact scale)
"""
from __future__ import annotations

from sqlglot import exp

from packs.snowflake.rules.base import (
    RuleContext,
    cast_to,
    lit_int,
    lit_str,
    post_order,
    string,
    strip_parens,
    tpl,
)
from packs.snowflake.rules.dates import is_numeric_format

ANONYMOUS_FUNCTIONS = ("ZEROIFNULL", "NULLIFZERO", "DIV0", "DIV0NULL", "EQUAL_NULL", "BOOLAND", "BOOLOR", "BOOLXOR",
                       "TO_BOOLEAN", "TRY_TO_BOOLEAN", "OBJECT_CONSTRUCT", "OBJECT_CONSTRUCT_KEEP_NULL")


def _as_bool(node: exp.Expression) -> exp.Expression:
    """BOOLAND & co regard a non-zero number as true: cast it (a boolean expression is left alone)."""
    inner = strip_parens(node)
    if isinstance(inner, (exp.Predicate, exp.Connector, exp.Not, exp.Boolean)):
        return node
    return cast_to(node, "BOOLEAN")


def rule_function_set(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.Anonymous):
        name = str(node.this).upper()
        args = node.expressions
        if name == "ZEROIFNULL" and len(args) == 1:
            node.replace(exp.Coalesce(this=args[0], expressions=[exp.Literal.number(0)]))
        elif name == "NULLIFZERO" and len(args) == 1:
            node.replace(exp.Nullif(this=args[0], expression=exp.Literal.number(0)))
        elif name in ("DIV0", "DIV0NULL") and len(args) == 2:
            a, b = args
            cond: exp.Expression = exp.EQ(this=b.copy(), expression=exp.Literal.number(0))
            if name == "DIV0NULL":
                cond = exp.Or(this=cond, expression=exp.Is(this=b.copy(), expression=exp.Null()))
            node.replace(exp.Case(ifs=[exp.If(this=cond, true=exp.Literal.number(0))], default=exp.Div(this=a, expression=b)))
        elif name == "EQUAL_NULL" and len(args) == 2:
            node.replace(exp.NullSafeEQ(this=args[0], expression=args[1]))
        elif name == "BOOLAND" and len(args) == 2:
            node.replace(exp.Paren(this=exp.And(this=_as_bool(args[0]), expression=_as_bool(args[1]))))
        elif name == "BOOLOR" and len(args) == 2:
            node.replace(exp.Paren(this=exp.Or(this=_as_bool(args[0]), expression=_as_bool(args[1]))))
        elif name == "BOOLXOR" and len(args) == 2:
            node.replace(exp.Paren(this=exp.NEQ(this=_as_bool(args[0]), expression=_as_bool(args[1]))))
        elif name == "TO_BOOLEAN" and len(args) == 1:
            node.replace(cast_to(args[0], "BOOLEAN"))
        elif name == "TRY_TO_BOOLEAN" and len(args) == 1:
            node.replace(cast_to(args[0], "BOOLEAN", safe=True))


def rule_to_number(tree: exp.Expression, rc: RuleContext) -> None:
    """TO_NUMBER / TO_DECIMAL / TRY_TO_*: an exact DECIMAL(p, s) (default NUMBER(38,0)), never DOUBLE."""
    for node in post_order(tree, exp.ToNumber):
        p, s = lit_int(node.args.get("precision")), lit_int(node.args.get("scale"))
        if p is None or s is None:
            rc.flag("SNW-NUMBER-FORMAT", "TO_NUMBER precision / scale is not a literal", "2.2")
            continue
        safe = bool(node.args.get("safe"))
        fmt_node = node.args.get("format")
        if fmt_node is None:
            node.replace(cast_to(node.this, f"DECIMAL({p}, {s})", safe=safe))
            continue
        fmt = lit_str(fmt_node)
        if fmt is None or not is_numeric_format(fmt) or "FM" in fmt.upper():
            rc.flag("SNW-NUMBER-FORMAT", f"TO_NUMBER format {fmt!r} has no direct Databricks to_number pattern", "2.2")
            continue
        fn = "TRY_TO_NUMBER" if safe else "TO_NUMBER"
        node.replace(cast_to(tpl(f"{fn}(__v__, __f__)", __v__=node.this, __f__=string(fmt)), f"DECIMAL({p}, {s})"))


RULES = (rule_function_set, rule_to_number)

__all__ = ["ANONYMOUS_FUNCTIONS", "RULES", "rule_function_set", "rule_to_number"]
