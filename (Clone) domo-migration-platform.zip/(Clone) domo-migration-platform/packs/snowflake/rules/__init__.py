"""packs.snowflake.rules - tier-0 rules over the Snowflake syntax tree (conversion engine v2: S17a, S9; ADR 037).

``convert`` is the one entry point the post-pass calls: parse the Snowflake text with ``SnowflakeSource``, run every
rule (``RULES``), generate Databricks SQL, and return the text with the rules' ``Flag`` list. A flag is a specific
caveat id (``caveats.yaml``) and a reason; its severity decides whether the unit still resolves with a review caveat or
is escalated. Rules read only the ``ConversionContext`` (parameters, capability profile, column types) and the
statement; they never guess.
"""
from __future__ import annotations

from sqlglot import ErrorLevel
from sqlglot import parse as sqlglot_parse
from sqlglot.errors import SqlglotError

from packs.snowflake import caveats as cav
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.rules import cortex, dates, functions, gaps, semantics, travel
from packs.snowflake.rules.base import TARGET, Flag, RuleContext, SnowflakeSource

#: the order matters: the function set first (it builds nodes the later rules read), ORDER BY last
RULES = (*gaps.RULES, *cortex.RULES, *functions.RULES, *dates.RULES, *travel.RULES, *semantics.RULES)


def apply_rules(tree, rc: RuleContext) -> None:                    # noqa: ANN001 - a sqlglot expression
    for rule in RULES:
        rule(tree, rc)


def convert(sql: str, conversion: ConversionContext, names: object = None, *, write: str = TARGET
            ) -> tuple[list[str], list[Flag]]:
    """``(statements, flags)``: Databricks text per statement and the rules' flags with their severities filled in.
    Raises ``sqlglot.errors.SqlglotError`` exactly as ``sqlglot.transpile`` would (parse errors, unsupported output),
    except when a rule has already escalated the unit: its draft is then generated leniently so the flag (and not a
    generic generator error) is what the reviewer reads."""
    rc = RuleContext(conversion, names)
    trees = [t for t in sqlglot_parse(sql, read=SnowflakeSource) if t is not None]
    for tree in trees:
        apply_rules(tree, rc)
    table = cav.load_catalogue().by_id()
    for f in rc.flags:
        entry = table.get(f.id)
        if entry is None:
            raise KeyError(f"rule flag {f.id} is not in caveats.yaml")
        f.severity = entry.severity
    escalated = any(f.severity == "escalate" for f in rc.flags)
    out: list[str] = []
    for tree in trees:
        try:
            out.append(tree.sql(dialect=write, unsupported_level=ErrorLevel.RAISE))
        except SqlglotError:
            if not escalated:
                raise
            out.append(tree.sql(dialect=write, unsupported_level=ErrorLevel.IGNORE))
    return out, rc.flags


__all__ = ["Flag", "RULES", "RuleContext", "SnowflakeSource", "apply_rules", "convert"]
