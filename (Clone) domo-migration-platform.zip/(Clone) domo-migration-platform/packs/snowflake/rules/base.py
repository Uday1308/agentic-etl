"""packs.snowflake.rules.base - what every tier-0 rule shares (conversion engine v2, S17a / S9; ADR 037 sections 2, 5, 8).

A rule is a function ``rule(tree, rc)`` that edits the Snowflake-parsed syntax tree in place and either rewrites a
construct or records a ``Flag`` (a specific caveat id and the reason). A rule never guesses: when the statement
alone cannot decide it (a missing account parameter, an unknown column type, a capability the profile lacks) it
flags, and the flag's severity (``caveats.yaml``) says whether the unit still resolves with a review caveat
(``review``) or is escalated (``escalate``).

``SnowflakeSource`` is the Snowflake dialect with sqlglot's format-string mapping switched off: the parser would
otherwise turn ``'YYYY-MM-DD HH24:MI:SS.FF3'`` into a strptime pattern and lose ``FF9`` / ``AUTO`` / ``TZH:TZM``;
the format rules need the text the author wrote.
"""
from __future__ import annotations

import re
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.dialects.snowflake import Snowflake
from sqlglot.errors import SqlglotError

from packs.snowflake.conversion import ConversionContext, ParamValue, type_family

TARGET = "databricks"
GENERATED = "rule_generated"


#: calls the rules read as the author wrote them: sqlglot's own parse (IF / CASE / XOR / DOUBLE casts) would hide them
_KEPT_ANONYMOUS = ("ZEROIFNULL", "NULLIFZERO", "DIV0", "DIV0NULL", "EQUAL_NULL", "BOOLAND", "BOOLOR", "BOOLXOR",
                   "TO_BOOLEAN", "TRY_TO_BOOLEAN", "OBJECT_CONSTRUCT", "OBJECT_CONSTRUCT_KEEP_NULL")


def _anonymous(name: str) -> Callable[[list[exp.Expression]], exp.Expression]:
    return lambda args: exp.Anonymous(this=name, expressions=args)


class SnowflakeSource(Snowflake):
    """Snowflake, with the date-time format strings and the calls in ``_KEPT_ANONYMOUS`` left as written."""
    TIME_MAPPING: dict[str, str] = {}

    class Parser(Snowflake.Parser):
        FUNCTIONS = {**Snowflake.Parser.FUNCTIONS, **{n: _anonymous(n) for n in _KEPT_ANONYMOUS}}


@dataclass
class Flag:
    """A rule's answer when it cannot (or should not) decide: the caveat id, why, and the catalogue row."""
    id: str
    reason: str
    row: str = ""
    severity: str = ""            # filled from caveats.yaml by ``apply``

    def key(self) -> tuple[str, str]:
        return self.id, self.reason


_TYPE_NUMBER = re.compile(r"^\s*(?:NUMBER|NUMERIC|DECIMAL|DEC)\s*(?:\(\s*(\d+)\s*(?:,\s*(\d+)\s*)?\))?\s*$", re.I)
_TYPE_INTEGER = re.compile(r"^\s*(?:INT|INTEGER|BIGINT|SMALLINT|TINYINT|BYTEINT)\s*$", re.I)
_TYPE_FLOATING = re.compile(r"^\s*(?:FLOAT|FLOAT4|FLOAT8|DOUBLE(?:\s+PRECISION)?|REAL)\s*$", re.I)


def number_scale(type_text: str | None) -> tuple[int, int] | None:
    """``(precision, scale)`` of an exact numeric type text (Snowflake spelling), None when it is floating point, not
    numeric, or unknown. ``NUMBER`` alone is NUMBER(38,0); INT and friends are NUMBER(38,0)."""
    if not type_text:
        return None
    if _TYPE_INTEGER.match(type_text):
        return 38, 0
    m = _TYPE_NUMBER.match(type_text)
    if not m:
        return None
    return int(m.group(1) or 38), int(m.group(2) or 0)


def is_floating(type_text: str | None) -> bool:
    return bool(type_text and _TYPE_FLOATING.match(type_text))


@dataclass
class ColInfo:
    """What the catalogue says about one column reference. ``kind``: table | derived | absent (every source of the
    statement is described and none has the column: an alias or an outer reference) | unknown."""
    kind: str = "unknown"
    table: str = ""
    type: str | None = None           # the SOURCE type text, None = not described
    known_table: bool = False         # the table's columns are in the catalogue at all

    @property
    def family(self) -> str | None:
        return type_family(self.type)


@dataclass
class RuleContext:
    conversion: ConversionContext
    #: the post-pass context (table_map, default_db, default_schema) - to name the target table of a reference
    names: Any = None
    flags: list[Flag] = field(default_factory=list)
    _cols: dict[int, ColInfo] = field(default_factory=dict)

    # ---------------------------------------------------------------- flags
    def flag(self, flag_id: str, reason: str, row: str = "") -> None:
        f = Flag(flag_id, reason, row)
        if f.key() not in {x.key() for x in self.flags}:
            self.flags.append(f)

    # ---------------------------------------------------------------- parameters and capabilities
    def has(self, capability: str) -> bool:
        return self.conversion.has(capability)

    def param(self, name: str) -> ParamValue:
        return self.conversion.param(name)

    def param_value(self, name: str, flag_id: str, row: str, what: str) -> str:
        """The account's value, or Snowflake's documented default WITH a recorded assumption (a review flag): the
        statement is converted for the documented default and says so (hard rule 6: never silently)."""
        value, assumed = self.param(name).value_or_default()
        if assumed:
            self.flag(flag_id, f"{name} was not extracted for this source: {what} assumes Snowflake's default "
                               f"({value}); confirm it matches the account", row)
        return value

    def param_int(self, name: str, flag_id: str, row: str, what: str) -> int | None:
        raw = self.param_value(name, flag_id, row, what)
        try:
            return int(str(raw).strip())
        except ValueError:
            self.flag(flag_id, f"{name} = {raw!r} is not a number: {what} cannot be decided", row)
            return None

    # ---------------------------------------------------------------- tables and columns
    def target_of(self, table: exp.Table) -> str | None:
        """The lower-case target ``catalog.schema.table`` the post-pass will give this reference, None when unmapped."""
        n = self.names
        if n is None or not isinstance(table.this, exp.Identifier):
            return None
        db = str(table.catalog or n.default_db).upper()
        schema = str(table.db or n.default_schema).upper()
        tgt = n.table_map.get((db, schema, table.name.upper()))
        return tgt.lower() if tgt else None

    def table_columns(self, table: exp.Table) -> dict[str, str | None] | None:
        tgt = self.target_of(table)
        cols = self.conversion.table_columns(tgt) if tgt else None
        return None if cols is None else dict(cols)

    def profile_of(self, col: exp.Expression) -> dict | None:
        """The data profile (X7: ``{row_count, null_count, min, max, ...}`` of the manifest's ``source_profiles``) of a
        column reference that resolves to a described table column, None when there is none (never a guess)."""
        if not isinstance(col, exp.Column) or not self.conversion.profiles:
            return None
        info = self.columns_of(col.root()).get(id(col))
        if info is None or info.kind != "table" or not info.table:
            return None
        return (self.conversion.profiles.get(info.table.lower()) or {}).get(col.name.lower())

    def columns_of(self, tree: exp.Expression) -> dict[int, ColInfo]:
        """``id(Column) -> ColInfo`` for every column reference in ``tree``, resolved through the statement's scopes."""
        from sqlglot.optimizer.scope import traverse_scope
        out: dict[int, ColInfo] = {}
        try:
            scopes = traverse_scope(tree)
        except (SqlglotError, KeyError, AttributeError, ValueError):
            return out
        for scope in scopes:
            srcs = dict(scope.sources)
            for col in scope.columns:
                out[id(col)] = self._resolve(col, srcs)
        return out

    def _resolve(self, col: exp.Column, srcs: dict[str, Any]) -> ColInfo:
        name = col.name.lower()
        cands = [(col.table, srcs.get(col.table))] if col.table else list(srcs.items())
        hits: list[ColInfo] = []
        maybe = False
        for alias, src in cands:
            if src is None:
                maybe = True
                continue
            if isinstance(src, exp.Table):
                cols = self.table_columns(src)
                if cols is None:
                    maybe = True
                elif name in cols:
                    hits.append(ColInfo("table", self.target_of(src) or "", cols[name], True))
            else:                                                     # a CTE / derived table: names known, types not
                expr = src.expression
                selects = getattr(expr, "named_selects", None)
                has_star = any(isinstance(s, exp.Star) or (isinstance(s, exp.Column) and isinstance(s.this, exp.Star))
                               for s in getattr(expr, "expressions", []) or [])
                if selects is None or has_star:
                    maybe = True
                elif name in {s.lower() for s in selects}:
                    hits.append(ColInfo("derived", str(alias), None, True))
        if len(hits) == 1 and (col.table or not maybe):
            return hits[0]
        if len(hits) == 1:
            return ColInfo(hits[0].kind, hits[0].table, hits[0].type, hits[0].known_table)
        if not hits and not maybe and cands:
            return ColInfo("absent")                           # every source is described and none has the column
        return ColInfo("unknown")


# ---------------------------------------------------------------------------------------------------- tree helpers
def post_order(tree: exp.Expression, *types: type[exp.Expression]) -> list[exp.Expression]:
    """Nodes of the given types, deepest first: replacing a parent after its children keeps the children's rewrites."""
    return [n for n in reversed(list(tree.find_all(*types))) if not n.meta.get(GENERATED)]


def mark_generated(node: exp.Expression, keep: Iterable[exp.Expression] = ()) -> exp.Expression:
    """Tag the nodes a rule built so no later rule re-reads them; the user's own sub-expressions in ``keep`` (and
    everything below them) stay untagged and remain subject to the remaining rules."""
    skip = {id(k) for k in keep}

    def visit(n: exp.Expression) -> None:
        if id(n) in skip:
            return
        n.meta[GENERATED] = True
        for child in n.iter_expressions():
            visit(child)
    visit(node)
    return node


def cast_to(node: exp.Expression, type_sql: str, *, safe: bool = False) -> exp.Expression:
    """``CAST(node AS type)`` as a rule-built node: only the CAST and its type are tagged, ``node`` stays readable."""
    cls = exp.TryCast if safe else exp.Cast
    out = cls(this=node, to=exp.DataType.build(type_sql, dialect=TARGET))
    out.meta[GENERATED] = True
    out.args["to"].meta[GENERATED] = True
    return out


def tpl(template: str, **subs: exp.Expression) -> exp.Expression:
    """A Databricks expression from ``template``; identifiers named in ``subs`` are replaced by copies of the given
    expressions. Template-built nodes are tagged generated, the substituted sub-expressions are not."""
    node = sqlglot.parse_one(template, read=TARGET)
    mark_generated(node)
    for col in list(node.find_all(exp.Column)):
        if not col.table and col.name in subs:
            new = subs[col.name].copy()
            if col is node:
                node = new
            else:
                col.replace(new)
    return node


def lit_str(node: exp.Expression | None) -> str | None:
    return node.this if isinstance(node, exp.Literal) and node.is_string else None


def lit_int(node: exp.Expression | None) -> int | None:
    if isinstance(node, exp.Neg) and isinstance(node.this, exp.Literal) and not node.this.is_string:
        v = lit_int(node.this)
        return None if v is None else -v
    if isinstance(node, exp.Literal) and not node.is_string:
        try:
            return int(node.this)
        except ValueError:
            return None
    return None


def strip_parens(node: exp.Expression) -> exp.Expression:
    while isinstance(node, exp.Paren):
        node = node.this
    return node


def same(a: exp.Expression, b: exp.Expression) -> bool:
    return a.sql(dialect=TARGET) == b.sql(dialect=TARGET)


def number(value: int | float | str) -> exp.Literal:
    return exp.Literal.number(value)


def string(value: str) -> exp.Literal:
    return exp.Literal.string(value)


Rule = Callable[[exp.Expression, RuleContext], None]


__all__ = ["cast_to", "ColInfo", "Flag", "GENERATED", "Rule", "RuleContext", "SnowflakeSource", "TARGET", "is_floating",
           "lit_int", "lit_str", "mark_generated", "number", "number_scale", "post_order", "same", "string",
           "strip_parens", "tpl"]
