"""packs.snowflake.rules.semantics - the silent-result rows of catalogue section 1 that are not date or time
(S17a, ADR 037 section 8). Each rule rewrites the construct to the Databricks form with Snowflake's result, or flags it
with a specific caveat id; none of them leaves sqlglot's default as the answer.

    1.1  NULL ordering            1.4  regular expressions        1.5  CONCAT_WS         1.6  ARRAY_CONTAINS
    1.7  SPLIT                    1.8  ARRAY_SLICE               1.9  OBJECT_CONSTRUCT  1.10 HASH
    1.11 alias in WHERE / GROUP BY / HAVING   1.12 implicit casts 1.13 quoted identifiers that collide
    1.19 LISTAGG / ARRAY_AGG ordering         1.20 KURTOSIS / SKEW 1.21 ROUND modes     1.22 NUMBER division
    1.23 approximate functions    1.24 CURRENT_USER              1.25 DECODE           1.27 GENERATOR / SEQ4
"""
from __future__ import annotations

import re
from collections import Counter

import sqlglot
from sqlglot import exp

from packs.snowflake.rules.base import (
    GENERATED,
    ColInfo,
    RuleContext,
    is_floating,
    lit_int,
    lit_str,
    mark_generated,
    number,
    number_scale,
    post_order,
    same,
    string,
    strip_parens,
    tpl,
)


# ------------------------------------------------------------------------------------------------ 1.1 NULL ordering
def rule_null_ordering(tree: exp.Expression, rc: RuleContext) -> None:
    """NULLs sort high in Snowflake (ASC: last, DESC: first); Databricks is the opposite. Make it explicit on every
    ORDER BY, including window and WITHIN GROUP orderings, so no later step depends on a dialect default."""
    for node in tree.find_all(exp.Ordered):
        if node.args.get("nulls_first") is None:
            node.set("nulls_first", bool(node.args.get("desc")))


# ------------------------------------------------------------------------------------------------ 1.4 regular expressions
_REGEX_FLAGS = {"i": "(?i)", "m": "(?m)", "s": "(?s)", "c": "", "e": ""}


def _flag_prefix(params: exp.Expression | None, rc: RuleContext, what: str) -> str | None:
    """The inline-flag prefix for Snowflake regexp parameters, '' for none, None (and a flag) when unknown."""
    if params is None:
        return ""
    text = lit_str(params)
    if text is None or any(c not in _REGEX_FLAGS for c in text):
        rc.flag("SNW-REGEX-PARAMS", f"{what}: regexp parameters {text!r} are not a literal of i / m / s / c / e", "1.4")
        return None
    return "".join(_REGEX_FLAGS[c] for c in dict.fromkeys(text))


def _pattern(pat: exp.Expression, prefix: str) -> exp.Expression:
    lit = lit_str(pat)
    if lit is not None:
        return string(prefix + lit)
    return pat if not prefix else tpl("CONCAT(__x__, __p__)", __x__=string(prefix), __p__=pat)


def _full_match(pat: exp.Expression, prefix: str) -> exp.Expression:
    """``^(?:pat)\\z``: Snowflake's RLIKE / REGEXP_LIKE match the whole string (``\\z``: not before a final newline)."""
    lit = lit_str(pat)
    if lit is not None:
        return string(f"{prefix}^(?:{lit})\\z")
    return tpl("CONCAT(__x__, __p__, __y__)", __x__=string(prefix + "^(?:"), __p__=pat, __y__=string(")\\z"))


def _replacement(text: str) -> str:
    """Snowflake ``\\1`` back-references become ``$1``; a literal ``$`` is escaped (Java replacement syntax). sqlglot's
    Snowflake tokenizer reads the escaped ``'\\\\1'`` as the control character U+0001, which is never real replacement
    text, so U+0001..U+0009 are read as the back-reference too."""
    out = re.sub(r"(?<!\\)\$", r"\\$", text)
    out = re.sub(r"[\x01-\x09]", lambda m: f"${ord(m.group(0))}", out)
    return re.sub(r"\\(\d)", r"$\1", out)


def rule_regexp(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.RegexpLike, exp.RegexpExtract, exp.RegexpReplace):
        if isinstance(node, exp.RegexpLike):
            prefix = _flag_prefix(node.args.get("flag"), rc, "REGEXP_LIKE / RLIKE")
            if prefix is None:
                continue
            node.replace(tpl("REGEXP_LIKE(__s__, __p__)", __s__=node.this, __p__=_full_match(node.expression, prefix)))
        elif isinstance(node, exp.RegexpExtract):
            _regexp_substr(node, rc)
        else:
            _regexp_replace(node, rc)


def _regexp_substr(node: exp.RegexpExtract, rc: RuleContext) -> None:
    params = node.args.get("parameters")
    prefix = _flag_prefix(params, rc, "REGEXP_SUBSTR")
    pos, occ = node.args.get("position"), node.args.get("occurrence")
    pos_v = 1 if pos is None else lit_int(pos)
    occ_v = 1 if occ is None else lit_int(occ)
    if prefix is None:
        return
    if pos_v is None or occ_v is None or pos_v < 1 or occ_v < 1:
        rc.flag("SNW-REGEX-PARAMS", "REGEXP_SUBSTR position / occurrence is not a positive literal", "1.4")
        return
    group = 0
    if params is not None and "e" in (lit_str(params) or ""):
        group = lit_int(node.args.get("group")) if node.args.get("group") is not None else 1
        if group is None:
            rc.flag("SNW-REGEX-PARAMS", "REGEXP_SUBSTR group number is not a literal", "1.4")
            return
    pat = _pattern(node.expression, prefix)
    src: exp.Expression = node.this if pos_v == 1 else tpl(f"SUBSTRING(__s__, {pos_v})", __s__=node.this)
    if occ_v == 1:                      # Snowflake returns NULL when nothing matches; Databricks returns ''
        new = tpl(f"CASE WHEN REGEXP_LIKE(__s__, __p__) THEN REGEXP_EXTRACT(__s__, __p__, {group}) END",
                  __s__=src, __p__=pat)
    else:
        new = tpl(f"TRY_ELEMENT_AT(REGEXP_EXTRACT_ALL(__s__, __p__, {group}), {occ_v})", __s__=src, __p__=pat)
    node.replace(new)


def _regexp_replace(node: exp.RegexpReplace, rc: RuleContext) -> None:
    pos, occ = node.args.get("position"), node.args.get("occurrence")
    if (pos is not None and lit_int(pos) != 1) or (occ is not None and lit_int(occ) != 0):
        rc.flag("SNW-REGEX-PARAMS", "REGEXP_REPLACE with a start position or an occurrence other than 'all' has no "
                                    "Databricks form", "1.4")
        return
    prefix = _flag_prefix(node.args.get("modifiers"), rc, "REGEXP_REPLACE")
    if prefix is None:
        return
    repl = node.args.get("replacement")
    lit = lit_str(repl) if repl is not None else ""
    if lit is None:
        rc.flag("SNW-REGEX-PARAMS", "REGEXP_REPLACE replacement is not a literal: back-references (\\1 -> $1) cannot be "
                                    "translated", "1.4")
        return
    node.replace(tpl("REGEXP_REPLACE(__s__, __p__, __r__)", __s__=node.this, __p__=_pattern(node.expression, prefix),
                     __r__=string(_replacement(lit))))


# ------------------------------------------------------------------------------------------------ 1.5 CONCAT_WS
def _may_be_null(node: exp.Expression) -> bool:
    inner = strip_parens(node)
    return not (isinstance(inner, exp.Literal) and inner.is_string) and not isinstance(inner, exp.Null)


def rule_concat_ws(tree: exp.Expression, rc: RuleContext) -> None:
    """Snowflake's CONCAT_WS returns NULL if any argument is NULL; Databricks skips the NULLs."""
    for node in post_order(tree, exp.ConcatWs):
        args = node.expressions
        checks = [a for a in args if _may_be_null(a)]
        call = exp.Anonymous(this="CONCAT_WS", expressions=[a.copy() for a in args])
        if not checks:
            node.replace(call)
            continue
        cond = exp.Is(this=checks[0].copy(), expression=exp.Null())
        for a in checks[1:]:
            cond = exp.Or(this=cond, expression=exp.Is(this=a.copy(), expression=exp.Null()))
        node.replace(exp.Case(ifs=[exp.If(this=cond, true=exp.Null())], default=call))


# ------------------------------------------------------------------------------------------------ 1.6 - 1.9 arrays
def rule_array_contains(tree: exp.Expression, rc: RuleContext) -> None:
    """ARRAY_CONTAINS(value, array): the argument order is swapped by the parser; the VARIANT cast on the value (which
    Snowflake requires) would make Databricks compare an ARRAY<T> with a VARIANT: drop it."""
    cols = rc.columns_of(tree)
    for node in post_order(tree, exp.ArrayContains):
        needle, arr = node.expression, node.this
        if isinstance(needle, exp.Cast) and needle.to.this == exp.DataType.Type.VARIANT:
            needle.replace(needle.this.copy())
        if isinstance(arr, exp.Cast) and arr.to.this in (exp.DataType.Type.VARIANT, exp.DataType.Type.ARRAY):
            arr.replace(arr.this.copy())
            arr = node.this
        info = cols.get(id(arr)) if isinstance(arr, exp.Column) else None
        if info is not None and info.family == "variant":
            rc.flag("SNW-VARIANT-ARRAY", "ARRAY_CONTAINS on a VARIANT column: Databricks array_contains needs an "
                                         "ARRAY<T>; the landed column type decides (cast with from_json / variant_get)",
                    "1.6")


def rule_split(tree: exp.Expression, rc: RuleContext) -> None:
    """Snowflake SPLIT takes a literal delimiter; Spark split takes a regular expression."""
    for node in post_order(tree, exp.Split):
        s, d = node.this, node.expression
        lit = lit_str(d)
        if lit is None:
            rc.flag("SNW-SPLIT-DYNAMIC", "SPLIT with a computed delimiter: the delimiter is quoted as a literal at run "
                                         "time (\\Q..\\E); an empty or \\E-containing value behaves differently", "1.7")
            node.replace(tpl("SPLIT(__s__, CONCAT(__q__, __d__, __e__))", __s__=s, __d__=d, __q__=string("\\Q"),
                             __e__=string("\\E")))
        elif lit == "":                                   # an empty delimiter returns the whole string in Snowflake
            node.replace(tpl("IF(__s__ IS NULL, NULL, ARRAY(__s__))", __s__=s))
        elif "\\E" in lit:
            rc.flag("SNW-SPLIT-DYNAMIC", "SPLIT delimiter contains \\E and cannot be quoted with \\Q..\\E", "1.7")
        else:
            node.replace(tpl("SPLIT(__s__, __d__)", __s__=s, __d__=string(f"\\Q{lit}\\E")))


def rule_array_slice(tree: exp.Expression, rc: RuleContext) -> None:
    """ARRAY_SLICE(a, from, to): 0-based, end exclusive, negative counts from the end; SLICE(a, start, length) is
    1-based."""
    for node in post_order(tree, exp.ArraySlice):
        a, lo, hi = node.this, node.args.get("start"), node.args.get("end")
        if lo is None or hi is None:
            continue
        lv, hv = lit_int(lo), lit_int(hi)
        if lv is not None and hv is not None and lv >= 0 and hv >= 0:
            node.replace(tpl(f"SLICE(__a__, {lv + 1}, {max(hv - lv, 0)})", __a__=a))
        elif lv is not None and hv is not None and lv < 0 and hv < 0:
            node.replace(tpl(f"SLICE(__a__, {lv}, {max(hv - lv, 0)})", __a__=a))
        else:                                              # general form, normalised against SIZE(a)
            node.replace(tpl(
                "SLICE(__a__, IF(__lo__ < 0, GREATEST(SIZE(__a__) + __lo__, 0), __lo__) + 1, "
                "GREATEST(IF(__hi__ < 0, SIZE(__a__) + __hi__, LEAST(__hi__, SIZE(__a__))) - "
                "IF(__lo__ < 0, GREATEST(SIZE(__a__) + __lo__, 0), __lo__), 0))", __a__=a, __lo__=lo, __hi__=hi))


def rule_object_construct(tree: exp.Expression, rc: RuleContext) -> None:
    """OBJECT_CONSTRUCT drops NULL-valued keys, OBJECT_CONSTRUCT_KEEP_NULL keeps them; Databricks has no OBJECT."""
    for node in post_order(tree, exp.Anonymous, exp.JSONObject):
        if isinstance(node, exp.JSONObject):                  # sqlglot reads OBJECT_CONSTRUCT_KEEP_NULL as JSON_OBJECT
            name, args = "OBJECT_CONSTRUCT_KEEP_NULL", []
            for kv in node.expressions:
                args += [kv.this, kv.expression] if isinstance(kv, exp.JSONKeyValue) else [exp.Star()]
        else:
            name = str(node.this).upper()
            if name not in ("OBJECT_CONSTRUCT", "OBJECT_CONSTRUCT_KEEP_NULL"):
                continue
            args = node.expressions
        if len(args) % 2 or not args or any(isinstance(a, exp.Star) for a in args):
            rc.flag("SNW-OBJECT-STAR", f"{name}(*) or an odd argument list builds keys from the row: no deterministic "
                                       "Databricks form", "1.9")
            continue
        pairs = ", ".join(f"__a{i}__" for i in range(len(args)))
        built = tpl(f"MAP({pairs})", **{f"__a{i}__": a for i, a in enumerate(args)})
        if name == "OBJECT_CONSTRUCT":
            built = tpl("MAP_FILTER(__m__, (k, v) -> v IS NOT NULL)", __m__=built)
        node.replace(built)


# ------------------------------------------------------------------------------------------------ 1.10 HASH
def rule_hash(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.Anonymous):
        if str(node.this).upper() == "HASH":
            rc.flag("SNW-HASH-NONPORTABLE", "HASH() is Snowflake's 64-bit hash: Databricks hash / xxhash64 return other "
                                            "values, so joins to persisted keys would break silently. Carry the loaded key "
                                            "values; new rows use a documented portable hash (sha2 / md5)", "1.10")


# ------------------------------------------------------------------------------------------------ 1.11 alias references
_PREC = {exp.Or: 1, exp.And: 2, exp.Not: 3, exp.EQ: 4, exp.NEQ: 4, exp.GT: 4, exp.GTE: 4, exp.LT: 4, exp.LTE: 4,
         exp.NullSafeEQ: 4, exp.Is: 4, exp.Like: 4, exp.ILike: 4, exp.In: 4, exp.Between: 4, exp.DPipe: 5, exp.Add: 6,
         exp.Sub: 6, exp.Mul: 7, exp.Div: 7, exp.Mod: 7, exp.IntDiv: 7, exp.Neg: 9}


def _prec(node: exp.Expression) -> int:
    return _PREC.get(type(node), 100)


def _wrap_for(inner: exp.Expression, parent: exp.Expression | None) -> exp.Expression:
    if parent is not None and _prec(inner) < _prec(parent) and not isinstance(parent, (exp.Where, exp.Having, exp.Group,
                                                                                         exp.Qualify, exp.Paren)):
        return exp.Paren(this=inner)
    return inner


def rule_alias_references(tree: exp.Expression, rc: RuleContext) -> None:
    """A SELECT alias used in WHERE / GROUP BY / HAVING / QUALIFY is read by Snowflake and not by Databricks: inline the
    expression. A real column of the same name wins in Snowflake, so it is left alone."""
    cols = rc.columns_of(tree)
    for sel in post_order(tree, exp.Select):
        aliases = {a.alias.lower(): a.this for a in sel.expressions
                   if isinstance(a, exp.Alias) and a.alias and not (isinstance(a.this, exp.Column)
                                                                  and a.this.name.lower() == a.alias.lower())}
        if not aliases:
            continue
        for key in ("where", "group", "having", "qualify"):
            clause = sel.args.get(key)
            if clause is None:
                continue
            for col in list(clause.find_all(exp.Column)):
                if col.table or col.name.lower() not in aliases or col.find_ancestor(exp.Select) is not sel:
                    continue
                info = cols.get(id(col))
                kind = info.kind if info else "unknown"
                if kind in ("table", "derived"):
                    continue                                  # a source column of that name: Snowflake reads the column
                if kind == "unknown":
                    rc.flag("SNW-ALIAS-INLINED", f"alias {col.name} is used in {key.upper()} and a source of the "
                                                 "statement is not described: inlined as a SELECT alias (a source "
                                                 "column of that name would win in Snowflake)", "1.11")
                inner = aliases[col.name.lower()].copy()
                col.replace(_wrap_for(inner, col.parent))


# ------------------------------------------------------------------------------------------------ 1.12 implicit casts
_COMPARE = (exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE)


def _literal_scale(node: exp.Expression) -> int | None:
    inner = node.this if isinstance(node, exp.Neg) else node
    if isinstance(inner, exp.Literal) and not inner.is_string:
        text = str(inner.this)
        return len(text.split(".")[1]) if "." in text else 0
    return None


def rule_implicit_cast(tree: exp.Expression, rc: RuleContext) -> None:
    """Snowflake casts a string column compared with a number to NUMBER; Databricks (ANSI) coerces differently or fails.
    Make the cast explicit from the catalogue's column types."""
    cols = rc.columns_of(tree)

    def info_of(n: exp.Expression) -> ColInfo | None:
        return cols.get(id(n)) if isinstance(n, exp.Column) else None

    for node in post_order(tree, *_COMPARE, exp.In):
        if isinstance(node, exp.In):
            col, others = node.this, node.expressions
            if not isinstance(col, exp.Column) or not others or node.args.get("query") is not None:
                continue
            scales = [_literal_scale(o) for o in others]
            if any(s is None for s in scales):
                continue
            info, scale = info_of(col), max(scales)  # type: ignore[type-var]
            other_num = True
            side = col
        else:
            left, right = node.this, node.expression
            li, ri = info_of(left), info_of(right)
            if isinstance(left, exp.Column) and _literal_scale(right) is not None:
                side, info, scale = left, li, _literal_scale(right)
            elif isinstance(right, exp.Column) and _literal_scale(left) is not None:
                side, info, scale = right, ri, _literal_scale(left)
            elif isinstance(left, exp.Column) and isinstance(right, exp.Column):
                fl, fr = (li.family if li else None), (ri.family if ri else None)
                if {fl, fr} == {"string", "numeric"}:
                    str_side, num_info = (left, ri) if fl == "string" else (right, li)
                    ns = number_scale(num_info.type if num_info else None)
                    if ns is None:
                        rc.flag("SNW-IMPLICIT-CAST", "a string column is compared with a floating-point or unsized "
                                                     "numeric column: choose the cast type", "1.12")
                        continue
                    str_side.replace(tpl(f"TRY_CAST(__c__ AS DECIMAL(38, {ns[1]}))", __c__=str_side))
                elif None in (fl, fr) and (li and li.kind == "table" or ri and ri.kind == "table") \
                        and not ({fl, fr} & {"string"}) and ("numeric" in (fl, fr)):
                    rc.flag("SNW-IMPLICIT-CAST", "a column of unknown type is compared with a numeric column: if it is "
                                                 "text, Snowflake casts it to NUMBER and Databricks may not", "1.12")
                continue
            else:
                continue
            other_num = True
        if info is None or info.kind != "table":
            continue                                          # an alias or a derived column: its type is the query's own
        if info.type is None:
            rc.flag("SNW-IMPLICIT-CAST", f"column {side.name} is compared with a number and its type is not described: "
                                         "if it is text, Snowflake casts it to NUMBER and Databricks may not", "1.12")
            continue
        if info.family == "string" and other_num:
            side.replace(tpl(f"TRY_CAST(__c__ AS DECIMAL(38, {scale}))", __c__=side))


# ------------------------------------------------------------------------------------------------ 1.13 quoted identifiers
def rule_quoted_collisions(tree: exp.Expression, rc: RuleContext) -> None:
    """``"Id"`` and ``"ID"`` are two columns in Snowflake and one in Databricks: rename deterministically in the select
    list (id, id_2) and flag; a collision elsewhere (DDL) is escalated."""
    spellings: dict[str, set[str]] = {}
    for ident in tree.find_all(exp.Identifier):
        if ident.parent is not None and isinstance(ident.parent, (exp.Table, exp.TableAlias, exp.Alias)):
            continue
        text = str(ident.this)
        spellings.setdefault(text.lower(), set()).add(text if ident.args.get("quoted") else text.upper())
    clash = {k for k, v in spellings.items() if len(v) > 1}
    if not clash:
        return
    handled = False
    mapping: list[str] = []
    for sel in post_order(tree, exp.Select):
        seen: Counter[str] = Counter()
        for i, proj in enumerate(list(sel.expressions)):
            if not isinstance(proj, exp.Column) or proj.name.lower() not in clash or proj.table:
                continue
            key = proj.name.lower()
            seen[key] += 1
            alias = key if seen[key] == 1 else f"{key}_{seen[key]}"
            new = exp.alias_(proj.copy(), alias)
            new.meta[GENERATED] = True
            sel.expressions[i].replace(new)
            mapping.append(f"{proj.name} -> {alias}")
            handled = True
    if handled:
        rc.flag("SNW-QUOTED-CASE-COLLISION", "quoted identifiers that differ only by case collide in Databricks; renamed "
                                             f"in the select list ({'; '.join(mapping)}); record the mapping table", "1.13")
    if any(isinstance(n, (exp.ColumnDef, exp.Create)) for n in tree.walk()) or not handled:
        rc.flag("SNW-QUOTED-CASE-UNRESOLVED", "identifiers that differ only by case (" + ", ".join(sorted(clash)) +
                ") are used outside a select list; Databricks cannot tell them apart", "1.13")


# ------------------------------------------------------------------------------------------------ 1.19 ordered aggregates
def _cmp_case(i: int, key: exp.Ordered) -> str:
    desc = bool(key.args.get("desc"))
    nf = -1 if key.args.get("nulls_first") else 1
    lt = 1 if desc else -1
    k = f"k{i}"
    return (f"CASE WHEN l.{k} IS NULL AND r.{k} IS NULL THEN 0 WHEN l.{k} IS NULL THEN {nf} WHEN r.{k} IS NULL THEN {-nf} "
            f"WHEN l.{k} < r.{k} THEN {lt} WHEN l.{k} > r.{k} THEN {-lt} ELSE 0 END")


def _ordered_array(value: exp.Expression, keys: list[exp.Ordered], distinct: bool, rc: RuleContext, row: str = "1.19"
                   ) -> exp.Expression | None:
    """An ARRAY of ``value`` in the order of ``keys`` (NULL values dropped, as ARRAY_AGG and LISTAGG do)."""
    if len(keys) == 1 and same(keys[0].this, value):
        base = tpl("COLLECT_SET(__v__)" if distinct else "COLLECT_LIST(__v__)", __v__=value)
        out = tpl("ARRAY_SORT(__b__)", __b__=base)
        return tpl("REVERSE(__o__)", __o__=out) if keys[0].args.get("desc") else out
    if distinct:
        rc.flag("SNW-LISTAGG-ORDER", "DISTINCT with an ORDER BY on another expression has no Databricks form", row)
        return None
    fields = ", ".join(f"'k{i}', __k{i}__" for i in range(len(keys)))
    cmp_all = "COALESCE(" + ", ".join(f"NULLIF({_cmp_case(i, k)}, 0)" for i, k in enumerate(keys)) + ", 0)"
    subs = {f"__k{i}__": k.this for i, k in enumerate(keys)}
    return tpl(f"TRANSFORM(ARRAY_SORT(COLLECT_LIST(CASE WHEN __v__ IS NOT NULL THEN NAMED_STRUCT({fields}, 'v', __v__) END), "
               f"(l, r) -> {cmp_all}), x -> x.v)", __v__=value, **subs)


def rule_ordered_aggregates(tree: exp.Expression, rc: RuleContext) -> None:
    """LISTAGG / ARRAY_AGG ... WITHIN GROUP (ORDER BY ...): native ``listagg`` when the target has it (Cap), else
    ARRAY_SORT over the collected rows; ``collect_list`` alone has no defined order."""
    for node in post_order(tree, exp.GroupConcat, exp.WithinGroup):
        if node.find_ancestor(exp.Window) is not None:
            rc.flag("SNW-LISTAGG-ORDER", "an ordered aggregate used as a window function has no Databricks form", "1.19")
            continue
        if isinstance(node, exp.WithinGroup):
            agg, order = node.this, node.expression
            if not isinstance(agg, exp.ArrayAgg) or not isinstance(order, exp.Order):
                continue
            value, distinct = agg.this, False
            if isinstance(value, exp.Distinct) and len(value.expressions) == 1:
                value, distinct = value.expressions[0], True
            new = _ordered_array(value, list(order.expressions), distinct, rc)
            if new is not None:
                node.replace(new)
            continue
        # GroupConcat = LISTAGG
        body, sep = node.this, node.args.get("separator")
        keys: list[exp.Ordered] = []
        if isinstance(body, exp.Order):
            keys, body = list(body.expressions), body.this
        value, distinct = body, False
        if isinstance(value, exp.Distinct) and len(value.expressions) == 1:
            value, distinct = value.expressions[0], True
        if rc.has("listagg"):
            continue                                          # native listagg ... WITHIN GROUP (ORDER BY ...)
        sep = sep if sep is not None else string("")
        if keys:
            arr = _ordered_array(value, keys, distinct, rc)
        else:
            arr = tpl("COLLECT_SET(__v__)" if distinct else "COLLECT_LIST(__v__)", __v__=value)
        if arr is not None:
            node.replace(tpl("ARRAY_JOIN(__a__, __s__)", __a__=arr, __s__=sep))


# ------------------------------------------------------------------------------------------------ 1.20 - 1.21, 1.23
def rule_skew_kurtosis(tree: exp.Expression, rc: RuleContext) -> None:
    """Snowflake's KURTOSIS / SKEW are the bias-corrected sample statistics; Spark's are the population formulas."""
    for node in post_order(tree, exp.Kurtosis, exp.Skewness):
        if node.find_ancestor(exp.Window) is not None:
            rc.flag("SNW-STAT-WINDOW", "KURTOSIS / SKEW as a window function: the sample correction needs the window's "
                                       "COUNT; no deterministic rule", "1.20")
            continue
        x = node.this
        if isinstance(node, exp.Kurtosis):          # G2 = (n-1) / ((n-2)(n-3)) * ((n+1) * g2 + 6), n > 3
            new = tpl("CASE WHEN COUNT(__x__) > 3 THEN ((COUNT(__x__) - 1) / ((COUNT(__x__) - 2) * (COUNT(__x__) - 3))) * "
                      "((COUNT(__x__) + 1) * KURTOSIS(__x__) + 6) END", __x__=x)
        else:                                       # G1 = g1 * sqrt(n (n-1)) / (n-2), n > 2
            new = tpl("CASE WHEN COUNT(__x__) > 2 THEN SKEWNESS(__x__) * SQRT(COUNT(__x__) * (COUNT(__x__) - 1)) / "
                      "(COUNT(__x__) - 2) END", __x__=x)
        node.replace(new)


def rule_round(tree: exp.Expression, rc: RuleContext) -> None:
    """ROUND(x, d, 'HALF_TO_EVEN') is BROUND; the default mode and Databricks ROUND agree for exact numbers, not FLOAT."""
    cols = rc.columns_of(tree)
    for node in post_order(tree, exp.Round):
        x, d, mode = node.this, node.args.get("decimals"), node.args.get("truncate")
        if mode is not None:
            m = (lit_str(mode) or "").upper()
            if m == "HALF_TO_EVEN":
                node.replace(tpl("BROUND(__x__, __d__)", __x__=x, __d__=d if d is not None else number(0)))
            elif m == "HALF_AWAY_FROM_ZERO":
                node.replace(exp.Round(this=x, decimals=d))
            else:
                rc.flag("SNW-ROUND-MODE", "ROUND rounding mode is not a literal HALF_TO_EVEN / HALF_AWAY_FROM_ZERO", "1.21")
            continue
        info = cols.get(id(x)) if isinstance(x, exp.Column) else None
        if info is not None and info.kind == "table" and is_floating(info.type):
            rc.flag("SNW-ROUND-FLOAT", f"ROUND on the FLOAT column {x.name}: Snowflake rounds the decimal rendering, "
                                       "Databricks the binary value; results can differ at .5 boundaries", "1.21")


def rule_approximate(tree: exp.Expression, rc: RuleContext) -> None:
    """APPROX_COUNT_DISTINCT / HLL / APPROX_PERCENTILE use other algorithms (compare within a tolerance); persisted
    sketches are incompatible and are recomputed, never copied."""
    for node in post_order(tree, exp.Anonymous):
        if str(node.this).upper() in ("HLL_ACCUMULATE", "HLL_COMBINE", "HLL_ESTIMATE", "HLL_EXPORT", "HLL_IMPORT"):
            rc.flag("SNW-HLL-SKETCH", f"{str(node.this).upper()}: a persisted HyperLogLog sketch is incompatible with "
                                      "Databricks; recompute it from the data, never copy it", "1.23")
    for node in post_order(tree, exp.Hll):
        node.replace(exp.ApproxDistinct(this=node.this))
        rc.flag("SNW-APPROX-PARITY", "HLL maps to approx_count_distinct: a different algorithm, compare within a "
                                     "tolerance", "1.23")
    if any(True for _ in tree.find_all(exp.ApproxDistinct, exp.ApproxQuantile)):
        rc.flag("SNW-APPROX-PARITY", "approximate aggregates use a different algorithm on Databricks: compare within a "
                                     "tolerance, not for equality", "1.23")


# ------------------------------------------------------------------------------------------------ 1.24, 1.25
def rule_current_user(tree: exp.Expression, rc: RuleContext) -> None:
    if any(True for _ in tree.find_all(exp.CurrentUser)):
        rc.flag("SNW-CURRENT-USER", "CURRENT_USER() is a user name in Snowflake and an e-mail address in Databricks: "
                                    "row filters and audit columns must go through the governance role mapping", "1.24")


def rule_decode(tree: exp.Expression, rc: RuleContext) -> None:
    """Snowflake DECODE matches NULL with NULL: a CASE with the null-safe ``<=>``."""
    for node in post_order(tree, exp.DecodeCase):
        parts = node.expressions
        if len(parts) < 3:
            continue
        x, rest = parts[0], parts[1:]
        ifs = [exp.If(this=exp.NullSafeEQ(this=x.copy(), expression=rest[i]), true=rest[i + 1])
               for i in range(0, len(rest) - 1, 2)]
        default = rest[-1] if len(rest) % 2 else None
        node.replace(exp.Case(ifs=ifs, default=default))


# ------------------------------------------------------------------------------------------------ 1.22 division
def _operand_scale(node: exp.Expression, cols: dict[int, ColInfo]) -> tuple[str, int | None]:
    """``(kind, scale)``: exact (scale) | float | unknown."""
    inner = strip_parens(node)
    if isinstance(inner, exp.Column):
        info = cols.get(id(inner))
        if info is None or info.type is None:
            return "unknown", None
        if is_floating(info.type):
            return "float", None
        ns = number_scale(info.type)
        return ("exact", ns[1]) if ns else ("unknown", None)
    s = _literal_scale(inner)
    return ("exact", s) if s is not None else ("unknown", None)


#: Snowflake's result scale of NUMBER / NUMBER: at least 6 fractional digits, more when the dividend has them.
#: UNVERIFIED until the X5 data tests run on a real account (catalogue 1.22); the rule always carries a review flag.
def division_scale(dividend_scale: int) -> int:
    return max(dividend_scale, 6)


def rule_division(tree: exp.Expression, rc: RuleContext) -> None:
    cols = rc.columns_of(tree)
    for node in post_order(tree, exp.Div):
        ka, sa = _operand_scale(node.this, cols)
        kb, _ = _operand_scale(node.expression, cols)
        if "float" in (ka, kb):
            continue                                              # floating-point division: same in both
        if ka == "exact" and kb == "exact" and sa is not None:
            scale = division_scale(sa)
            node.replace(tpl(f"CAST(__d__ AS DECIMAL(38, {scale}))", __d__=node.copy()))
            rc.flag("SNW-DIVISION-SCALE", f"NUMBER / NUMBER given the explicit result DECIMAL(38,{scale}); Snowflake's "
                                          "result-scale rule is unverified until the X5 data test runs on the account",
                    "1.22")
        else:
            rc.flag("SNW-DIVISION-SCALE", "a division whose operand types are not described: Snowflake's NUMBER division "
                                          "scale and Databricks' differ, make the CAST explicit once the types are known",
                    "1.22")


# ------------------------------------------------------------------------------------------------ 1.27 generator
def rule_generator(tree: exp.Expression, rc: RuleContext) -> None:
    """TABLE(GENERATOR(ROWCOUNT => n)) with SEQ4() is ``range(n)``; Databricks monotonically_increasing_id is not
    contiguous."""
    for rows in post_order(tree, exp.TableFromRows):
        gen = rows.this
        if not isinstance(gen, exp.Generator):
            continue
        if gen.args.get("rowcount") is None or gen.args.get("timelimit") is not None:
            rc.flag("SNW-GENERATOR-LIMIT", "GENERATOR with TIMELIMIT (or without ROWCOUNT) is not deterministic", "1.27")
            continue
        alias = rows.args.get("alias")
        name = alias.name if alias is not None and alias.name else "gen"
        table = sqlglot.parse_one(f"SELECT 1 FROM RANGE(__n__) AS {name}(seq)", read="databricks").find(exp.Table)
        assert table is not None
        mark_generated(table)
        rng = table.this
        rng.set("expressions", [gen.args["rowcount"].copy()])
        sel = rows.find_ancestor(exp.Select)
        rows.replace(table)
        if sel is None:
            continue
        for seq in list(sel.find_all(exp.Seq1, exp.Seq2, exp.Seq4, exp.Seq8)):
            if seq.find_ancestor(exp.Select) is sel:
                col = exp.column("seq", table=name)
                col.meta[GENERATED] = True
                seq.replace(col)
    for seq in tree.find_all(exp.Seq1, exp.Seq2, exp.Seq4, exp.Seq8):
        rc.flag("SNW-SEQ-NO-GENERATOR", "SEQ1/2/4/8() outside TABLE(GENERATOR(...)): values are not reproducible; Databricks "
                                        "has no contiguous per-row sequence", "1.27")
        break


RULES = (rule_alias_references, rule_decode, rule_concat_ws, rule_regexp, rule_split, rule_array_contains,
         rule_array_slice, rule_object_construct, rule_hash, rule_ordered_aggregates, rule_skew_kurtosis, rule_round,
         rule_approximate, rule_current_user, rule_generator, rule_implicit_cast, rule_division, rule_quoted_collisions,
         rule_null_ordering)

__all__ = ["RULES", "division_scale", *[r.__name__ for r in RULES]]
