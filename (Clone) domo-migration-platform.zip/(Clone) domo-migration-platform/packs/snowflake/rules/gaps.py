"""packs.snowflake.rules.gaps - the catalogue section 2 gaps (S17b): table functions, relation-level constructs and system
tables that sqlglot passes through or cannot parse for Databricks.

    2.4   STRTOK / STRTOK_TO_ARRAY / SPLIT_PART(0) / SPLIT_TO_TABLE / STRTOK_SPLIT_TO_TABLE
    2.10  LATERAL FLATTEN (OUTER, PATH, MODE; INDEX / KEY / PATH / THIS outputs); RECURSIVE is flagged with a pattern
    2.13  ASOF JOIN ... MATCH_CONDITION  -> LEFT JOIN + ROW_NUMBER() window (nearest earlier / later row)
    2.14  MATCH_RECOGNIZE common shapes (runs ``a+``; sessions ``a b*``) -> window functions, else flagged
    2.15  CONNECT BY / START WITH / LEVEL / SYS_CONNECT_BY_PATH / CONNECT_BY_ROOT -> WITH RECURSIVE (capability
          ``recursive_cte``), else flagged with the notebook-loop alternative
    2.17  dynamic PIVOT (ANY / subquery): frozen to the manifest's ``pivot_values`` (review) or flagged (escalate)
    2.23  RESULT_SCAN: flagged with the temp-view pattern
    2.24  INFORMATION_SCHEMA -> ``<catalog>.information_schema``; ACCOUNT_USAGE -> ``system.*`` (columns differ: flagged)

Every rewrite builds on the Snowflake-parsed tree, copies the author's own sub-expressions (so the later rules still
apply to them) and tags what it built (``mark_generated``). A shape the rule does not take records an ``escalate`` flag
with the reason and a suggested pattern: the construct is never converted silently.
"""
from __future__ import annotations

import re

import sqlglot
from sqlglot import exp

from packs.snowflake.rules.base import (
    GENERATED,
    TARGET,
    RuleContext,
    lit_int,
    lit_str,
    mark_generated,
    post_order,
    string,
)

# ------------------------------------------------------------------------------------------------ 2.4 strings
_CLASS_UNSAFE = set("\\[]^-")


def _delimiter_class(delims: str) -> str | None:
    """``[...]`` regex character class of a STRTOK delimiter set, None when it holds a character that needs a
    backslash (a backslash inside a SQL string literal is an escape: no safe spelling without raw strings)."""
    if not delims or any(c in _CLASS_UNSAFE for c in delims):
        return None
    return "[" + delims + "]"


def _regex_literal(delim: str) -> str | None:
    """A whole-string delimiter (SPLIT_TO_TABLE) as a regex, None when it needs a backslash."""
    if not delim or any(c in "\\" for c in delim):
        return None
    return "".join(f"[{c}]" if c in ".$|()*+?{}" else c for c in delim) if all(c not in "[]^" for c in delim) else None


def _tokens(arg: exp.Expression, regex: str) -> exp.Expression:
    """``filter(split(arg, regex), x -> x <> '')``: the non-empty tokens, in order."""
    node = sqlglot.parse_one("FILTER(SPLIT(__s__, __r__), x -> x <> '')", read=TARGET)
    mark_generated(node)
    node.find(exp.Column).replace(arg.copy())
    for c in list(node.find_all(exp.Column)):
        if c.name == "__r__":
            c.replace(string(regex))
    return node


def rule_strtok(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.Strtok, exp.StrtokToArray, exp.SplitPart):
        if isinstance(node, exp.SplitPart):
            idx = node.args.get("part_index")
            if lit_int(idx) == 0:                         # Snowflake: 0 means the first part; Databricks raises
                node.set("part_index", exp.Literal.number(1))
                rc.flag("SNW-STRTOK", "SPLIT_PART(.., 0) is the first part on Snowflake and an error on Databricks: "
                                      "rewritten to index 1", "2.4")
            continue
        delim = node.args.get("delimiter") if isinstance(node, exp.Strtok) else node.args.get("expression")
        delims = " " if delim is None else lit_str(delim)
        cls = _delimiter_class(delims) if delims is not None else None
        if cls is None:
            rc.flag("SNW-STRTOK-UNSUPPORTED", "STRTOK delimiter set is not a literal without \\ [ ] ^ - characters: "
                                              "no deterministic regex class (write the split by hand)", "2.4")
            continue
        toks = _tokens(node.this, cls)
        if isinstance(node, exp.StrtokToArray):
            node.replace(toks)
        else:
            n = node.args.get("part_index") or exp.Literal.number(1)
            call = exp.Anonymous(this="try_element_at", expressions=[toks, n.copy()])
            mark_generated(call, keep=[n])
            node.replace(call)
        rc.flag("SNW-STRTOK", "STRTOK became filter(split(s, '[delimiters]'), x -> x <> '') (empty tokens dropped, any "
                              "delimiter character splits); a token beyond the last is NULL (try_element_at)", "2.4")


# ------------------------------------------------------------------------------------------------ 2.10 / 2.4 lateral
_FLATTEN_COLS = ("SEQ", "KEY", "PATH", "INDEX", "VALUE", "THIS")
_RECURSIVE_PATTERN = ("walk the levels: WITH RECURSIVE over variant_explode(v) (join each level's value back to "
                      "variant_explode until no row is an array or object), or a notebook loop; PATH is the "
                      "concatenation of the keys / [index] of the ancestors")


def _kwargs(fn: exp.Expression) -> tuple[exp.Expression | None, dict[str, exp.Expression]]:
    first = fn.this
    kws: dict[str, exp.Expression] = {}
    inp = None
    if isinstance(first, exp.Kwarg):
        kws[first.this.name.lower()] = first.expression
    elif first is not None:
        inp = first
    for e in fn.expressions:
        if isinstance(e, exp.Kwarg):
            kws[e.this.name.lower()] = e.expression
    return kws.pop("input", inp), kws


def _bool(node: exp.Expression | None) -> bool | None:
    return None if node is None else (node.this if isinstance(node, exp.Boolean) else None)


def _lateral_source(join: exp.Join) -> tuple[exp.Expression | None, exp.TableAlias | None]:
    node = join.this
    if isinstance(node, (exp.Lateral, exp.TableFromRows)):
        return node.this, node.args.get("alias")
    return None, None


def _is_flatten(fn: exp.Expression | None) -> bool:
    return isinstance(fn, exp.Explode) and isinstance(fn.this, exp.Kwarg) \
        or isinstance(fn, exp.Anonymous) and str(fn.this).upper() == "FLATTEN"


def _used_outputs(select: exp.Select, alias: str, columns: tuple[str, ...]) -> tuple[set[str], bool]:
    used: set[str] = set()
    star = any(isinstance(e, exp.Star) for e in select.expressions)
    for col in select.find_all(exp.Column):
        if col.table.lower() == alias.lower():
            if isinstance(col.this, exp.Star):
                star = True
            else:
                used.add(col.name.upper())
        elif not col.table and col.name.upper() in columns:
            used.add(col.name.upper())
    return used, star


def _replace_outputs(select: exp.Select, alias: str, mapping: dict[str, exp.Expression]) -> None:
    for col in list(select.find_all(exp.Column)):
        if isinstance(col.this, exp.Star):
            continue
        tbl = col.table.lower()
        name = col.name.upper()
        if name in mapping and (tbl == alias.lower() or not tbl):
            new = mapping[name].copy()
            if isinstance(col.parent, exp.Select):          # a projection keeps the column's name
                new = exp.alias_(new, col.name.lower())
                new.meta[GENERATED] = True
            col.replace(new)


def _star_of(alias: str) -> exp.Column:
    return exp.Column(this=exp.Star(), table=exp.to_identifier(alias))


def _col(alias: str, name: str) -> exp.Column:
    return exp.column(name, table=alias)


def _add_lateral(select: exp.Select, fn: exp.Expression, alias: str, columns: list[str], outer: bool) -> None:
    lat = exp.Lateral(this=fn, view=True, outer=outer,
                      alias=exp.TableAlias(this=exp.to_identifier(alias), columns=[exp.to_identifier(c) for c in columns]))
    select.set("laterals", [*(select.args.get("laterals") or []), lat])


def rule_flatten(tree: exp.Expression, rc: RuleContext) -> None:
    for select in post_order(tree, exp.Select):
        for join in list(select.args.get("joins") or []):
            fn, alias_node = _lateral_source(join)
            if not _is_flatten(fn):
                continue
            alias = alias_node.name if alias_node is not None else "flatten"
            inp, kw = _kwargs(fn)
            if inp is None:
                rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN without an input argument", "2.10")
                continue
            if _bool(kw.get("recursive")) is not False and "recursive" in kw:
                rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN(RECURSIVE => ...) has no single explode; suggested pattern: "
                        + _RECURSIVE_PATTERN, "2.10")
                continue
            outer_raw = kw.get("outer")
            outer = _bool(outer_raw) if outer_raw is not None else False
            if outer is None:
                rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN(OUTER => <expression>) is not a literal boolean", "2.10")
                continue
            mode = (lit_str(kw["mode"]) or "").upper() if "mode" in kw else "BOTH"
            if mode not in ("ARRAY", "OBJECT", "BOTH") or ("mode" in kw and lit_str(kw["mode"]) is None):
                rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN(MODE => ...) is not ARRAY / OBJECT / BOTH literal", "2.10")
                continue
            path = lit_str(kw.get("path")) if "path" in kw else None
            if "path" in kw and path is None:
                rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN(PATH => <expression>) is not a literal", "2.10")
                continue
            typ = ""
            if isinstance(inp, exp.Column):
                info = rc.columns_of(select).get(id(inp))
                typ = (info.type or "").upper() if info else ""
            kind = mode if mode in ("ARRAY", "OBJECT") else (
                "ARRAY" if typ.startswith("ARRAY") else "OBJECT" if typ.startswith(("OBJECT", "MAP")) else
                "VARIANT" if typ.startswith("VARIANT") else "")
            used, star = _used_outputs(select, alias, _FLATTEN_COLS)
            notes: list[str] = []
            inp_copy = inp.copy()
            if path is not None:
                if not rc.has("variant"):
                    rc.flag("SNW-FLATTEN-UNSUPPORTED", "FLATTEN(PATH => ...) needs the VARIANT path syntax; the target "
                            "profile has no variant support", "2.10")
                    continue
                inp_copy = sqlglot.parse_one(f"{inp.sql(dialect=TARGET)}:{path}", read=TARGET)
                kind = "VARIANT"
                notes.append(f"PATH => '{path}' became the variant path expression")
            all_cols = star
            if kind == "OBJECT":
                fn_new: exp.Expression = exp.Explode(this=inp_copy)
                cols = ["key", "value"]
                mapping = {"INDEX": exp.Null(), "PATH": _col(alias, "key")}
            elif kind == "VARIANT":
                fn_new = exp.Anonymous(this="variant_explode", expressions=[inp_copy])
                cols = ["index", "key", "value"]
                prefix = (path or "")
                mapping = {"PATH": exp.Case(ifs=[exp.If(this=exp.Is(this=_col(alias, "key"), expression=exp.Null()),
                                                        true=sqlglot.parse_one(
                                                            f"CONCAT('{prefix}[', CAST({alias}.`index` AS STRING), ']')",
                                                            read=TARGET))],
                                            default=sqlglot.parse_one(
                                                f"CONCAT('{prefix}.', {alias}.`key`)" if prefix else f"{alias}.`key`",
                                                read=TARGET))}
                notes.append("variant_explode: INDEX is the position for arrays and objects alike (NULL on Snowflake "
                             "for objects)")
            else:
                if kind == "":
                    notes.append("the input's type is not described: assumed to be an ARRAY (an object needs MODE => "
                                 "'OBJECT' / a MAP column, a VARIANT column needs the variant profile)")
                needs_pos = bool(used - {"VALUE"}) or all_cols
                if needs_pos:
                    fn_new, cols = exp.Posexplode(this=inp_copy), ["index", "value"]
                else:
                    fn_new, cols = exp.Explode(this=inp_copy), ["value"]
                mapping = {"KEY": exp.Null(),
                           "PATH": sqlglot.parse_one(f"CONCAT('[', CAST({alias}.`index` AS STRING), ']')", read=TARGET)}
            if used & {"SEQ", "THIS"} or all_cols:
                mapping.setdefault("SEQ", exp.Null())
                mapping.setdefault("THIS", inp.copy())
                notes.append("SEQ (the input row's sequence) is not produced (NULL); THIS is the input expression")
            for m in mapping.values():
                mark_generated(m)
            select.set("joins", [j for j in select.args["joins"] if j is not join] or None)
            _replace_outputs(select, alias, mapping)
            mark_generated(fn_new, keep=[inp_copy])
            _add_lateral(select, fn_new, alias, cols, bool(outer))
            rc.flag("SNW-FLATTEN", "FLATTEN became LATERAL VIEW " + ("OUTER " if outer else "")
                    + (fn_new.sql(dialect=TARGET).split("(")[0]) + "; " + "; ".join(notes or ["outputs the query reads "
                       "are mapped (INDEX, KEY, PATH, VALUE)"]), "2.10")


def rule_split_to_table(tree: exp.Expression, rc: RuleContext) -> None:
    for select in post_order(tree, exp.Select):
        for join in list(select.args.get("joins") or []):
            fn, alias_node = _lateral_source(join)
            if isinstance(fn, exp.Anonymous) and str(fn.this).upper() == "STRTOK_SPLIT_TO_TABLE":
                strtok = True
            elif isinstance(fn, exp.SplitToTable):
                strtok = False
            else:
                continue
            args = [fn.this, fn.args.get("expression")] if isinstance(fn, exp.SplitToTable) else list(fn.expressions)
            alias = alias_node.name if alias_node is not None else "split"
            delim = lit_str(args[1]) if len(args) > 1 else " "
            regex = (_delimiter_class(delim) if strtok else _regex_literal(delim)) if delim is not None else None
            if regex is None or not args:
                rc.flag("SNW-STRTOK-UNSUPPORTED", "SPLIT_TO_TABLE delimiter is not a literal that has a regex spelling "
                        "without backslashes", "2.4")
                continue
            used, star = _used_outputs(select, alias, ("SEQ", "INDEX", "VALUE", "THIS"))
            tokens = _tokens(args[0], regex) if strtok else sqlglot.parse_one("SPLIT(__s__, __r__)", read=TARGET)
            if not strtok:
                mark_generated(tokens)
                tokens.find(exp.Column).replace(args[0].copy())
                for c in list(tokens.find_all(exp.Column)):
                    if c.name == "__r__":
                        c.replace(string(regex))
            mapping = {"INDEX": sqlglot.parse_one(f"({alias}.pos + 1)", read=TARGET), "SEQ": exp.Null()}
            for m in mapping.values():
                mark_generated(m)
            select.set("joins", [j for j in select.args["joins"] if j is not join] or None)
            _replace_outputs(select, alias, mapping)
            fn_new = mark_generated(exp.Posexplode(this=tokens), keep=[args[0]])
            _add_lateral(select, fn_new, alias, ["pos", "value"], False)
            rc.flag("SNW-STRTOK", "SPLIT_TO_TABLE became LATERAL VIEW POSEXPLODE(split(..)); INDEX is pos + 1 "
                    "(1-based on Snowflake); SEQ is not produced" + ("; STRTOK form drops empty tokens" if strtok else
                    "; empty tokens are kept like Snowflake"), "2.4")


# ------------------------------------------------------------------------------------------------ 2.13 ASOF
_OPS = {exp.GTE: (True, False), exp.GT: (True, True), exp.LTE: (False, False), exp.LT: (False, True)}


def _refs(node: exp.Expression) -> set[str]:
    return {c.table.lower() for c in node.find_all(exp.Column) if c.table}


def rule_asof(tree: exp.Expression, rc: RuleContext) -> None:
    for select in post_order(tree, exp.Select):
        joins = select.args.get("joins") or []
        asof = [j for j in joins if str(j.args.get("method") or "").upper() == "ASOF"]
        if not asof:
            continue
        why = None
        j = asof[0]
        left = select.args["from_"].this if select.args.get("from_") else None
        right = j.this
        match = j.args.get("match_condition")
        if len(joins) != 1 or len(asof) != 1:
            why = "an ASOF JOIN combined with other joins"
        elif select.args.get("where") or select.args.get("group") or select.args.get("having") \
                or select.args.get("qualify") or select.args.get("distinct"):
            why = "an ASOF JOIN in a query with WHERE / GROUP BY / HAVING / QUALIFY / DISTINCT (the nearest row must be " \
                  "chosen before the filter: put the ASOF join in a CTE first)"
        elif any(isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star))
                 for e in select.expressions) or any(True for _ in select.find_all(exp.Window)):
            why = "an ASOF JOIN under SELECT * / a window function (the helper row id column would leak)"
        elif not (isinstance(left, (exp.Table, exp.Subquery)) and isinstance(right, (exp.Table, exp.Subquery))
                  and left.alias and right.alias):
            why = "an ASOF JOIN of sources without an alias"
        elif type(match) not in _OPS:
            why = "a MATCH_CONDITION that is not a single >=, >, <= or < comparison"
        if why:
            rc.flag("SNW-ASOF-UNSUPPORTED", f"ASOF JOIN not converted: {why}; suggested pattern: LEFT JOIN on the equality "
                    "keys and the time condition, then ROW_NUMBER() OVER (PARTITION BY the left row ORDER BY the right "
                    "time DESC) = 1", "2.13")
            continue
        la, ra = left.alias.lower(), right.alias.lower()
        lhs, rhs = match.this, match.expression
        ge, strict = _OPS[type(match)]
        if ra in _refs(lhs) and la in _refs(rhs):          # q.ts <= t.ts: flip so that lhs is the left side
            lhs, rhs, ge = rhs, lhs, not ge
        if la not in _refs(lhs) or ra not in _refs(rhs) or ra in _refs(lhs) or la in _refs(rhs):
            rc.flag("SNW-ASOF-UNSUPPORTED", "ASOF JOIN MATCH_CONDITION does not compare a left expression with a right "
                    "expression", "2.13")
            continue
        op = (exp.GT if strict else exp.GTE) if ge else (exp.LT if strict else exp.LTE)
        cond = op(this=lhs.copy(), expression=rhs.copy())
        on = j.args.get("on")
        j.set("on", exp.And(this=on.copy(), expression=cond) if on is not None else cond)
        j.set("method", None)
        j.set("match_condition", None)
        j.set("side", "LEFT")
        sub = exp.select(_star_of(left.alias), exp.alias_(exp.Anonymous(this="monotonically_increasing_id"),
                                                                          "__asof_id")).from_(left.copy())
        new_left = exp.Subquery(this=sub, alias=exp.TableAlias(this=exp.to_identifier(left.alias)))
        select.args["from_"].set("this", new_left)
        order = exp.Ordered(this=rhs.copy(), desc=ge, nulls_first=False)
        win = exp.Window(this=exp.RowNumber(),
                         partition_by=[exp.column("__asof_id", table=left.alias)], order=exp.Order(expressions=[order]))
        select.set("qualify", exp.Qualify(this=exp.EQ(this=win, expression=exp.Literal.number(1))))
        mark_generated(win, keep=[order.this])
        rc.flag("SNW-ASOF", "ASOF JOIN became a LEFT JOIN on the match condition with QUALIFY ROW_NUMBER() = 1 over a "
                "per-row id (monotonically_increasing_id) taking the "
                + ("latest earlier" if ge else "earliest later") + " right row; ties are broken arbitrarily (as on "
                "Snowflake); the join is a range join: check its cost on large tables", "2.13")


# ------------------------------------------------------------------------------------------------ 2.14 MATCH_RECOGNIZE
_RUN = re.compile(r"^\(?\s*(\w+)\s*\+\s*\)?$")
_SESSION = re.compile(r"^\(?\s*(\w+)\s+(\w+)\s*\*\s*\)?$")


def _strip_var(node: exp.Expression, variables: set[str]) -> exp.Expression:
    for c in list(node.find_all(exp.Column)):
        if c.table and c.table.lower() in variables:
            c.set("table", None)
    return node


def _order_key(order: exp.Order) -> tuple[exp.Expression, bool]:
    items = order.expressions
    desc = bool(items[0].args.get("desc"))
    key = items[0].this.copy() if len(items) == 1 else exp.Anonymous(this="struct", expressions=[i.this.copy() for i in items])
    return key, desc


def rule_match_recognize(tree: exp.Expression, rc: RuleContext) -> None:
    for select in post_order(tree, exp.Select):
        mr = select.args.get("match")
        if not isinstance(mr, exp.MatchRecognize):
            continue
        why = _mr_unsupported(select, mr)
        if why:
            rc.flag("SNW-MATCH-RECOGNIZE-UNSUPPORTED", f"MATCH_RECOGNIZE not converted: {why}; suggested pattern: number "
                    "the rows per partition, mark each match start with LAG / LEAD, take a running SUM of the starts as "
                    "the match id and aggregate per id; or an AI draft checked by the equivalence test", "2.14")
            continue
        pattern = re.sub(r"\s+", " ", str(mr.args["pattern"].name if hasattr(mr.args["pattern"], "name")
                                          else mr.args["pattern"])).strip()
        run, sess = _RUN.match(pattern), _SESSION.match(pattern)
        variables = {m.lower() for m in (run.groups() if run else sess.groups())}
        defines = {d.alias.lower(): d.this for d in mr.args["define"]}
        part = [p.copy() for p in mr.args.get("partition_by") or []]
        okey, odesc = _order_key(mr.args["order"])
        pby = ("PARTITION BY " + ", ".join(p.sql(dialect=TARGET) for p in part)) if part else ""
        win = f"({pby} ORDER BY {okey.sql(dialect=TARGET)}{' DESC' if odesc else ''})"
        var = list(defines)[0] if len(defines) == 1 else None
        cond = defines[var].copy() if var else None
        if cond is None or (run and var != run.group(1).lower()) or (sess and var != sess.group(2).lower()):
            rc.flag("SNW-MATCH-RECOGNIZE-UNSUPPORTED", "MATCH_RECOGNIZE not converted: DEFINE does not match the pattern "
                    "variable", "2.14")
            continue
        _strip_var(cond, variables)
        for prev in list(cond.find_all(exp.Anonymous)):
            if str(prev.this).upper() == "PREV" and len(prev.expressions) == 1:
                lag = sqlglot.parse_one(f"LAG(__x__) OVER {win}", read=TARGET)
                lag.this.this.replace(prev.expressions[0].copy())
                prev.replace(lag)
        src = select.args["from_"].this
        src_alias = src.alias or "mr"
        s0 = exp.select(exp.Star(), exp.alias_(cond, "__mr_c")).from_(src.copy())
        s1 = exp.select(exp.Star(), exp.alias_(sqlglot.parse_one(
            f"SUM(CASE WHEN COALESCE(__mr_c, FALSE) THEN 0 ELSE 1 END) OVER {win}", read=TARGET),
            "__mr_g")).from_(exp.Subquery(this=s0, alias=exp.TableAlias(this=exp.to_identifier("__mr0"))))
        meas: list[exp.Expression] = []
        for m in mr.args.get("measures") or []:
            al = m.this
            agg = _strip_var(al.this.copy(), variables)
            if isinstance(agg, exp.First):
                agg = exp.Anonymous(this="max_by" if odesc else "min_by", expressions=[agg.this, okey.copy()])
            elif isinstance(agg, exp.Last):
                agg = exp.Anonymous(this="min_by" if odesc else "max_by", expressions=[agg.this, okey.copy()])
            meas.append(exp.alias_(agg, al.alias))
        outer = exp.select(*[p.copy() for p in part], *meas).from_(
            exp.Subquery(this=s1, alias=exp.TableAlias(this=exp.to_identifier("__mr1"))))
        if run:
            outer = outer.where(exp.column("__mr_c"))
        outer = outer.group_by(*[p.copy() for p in part], exp.column("__mr_g"))
        alias = mr.args.get("alias")
        new = exp.Subquery(this=outer, alias=alias.copy() if alias is not None else exp.TableAlias(this=exp.to_identifier(src_alias)))
        select.args["from_"].set("this", new)
        select.set("match", None)
        rc.flag("SNW-MATCH-RECOGNIZE-REWRITE",
                ("consecutive runs (PATTERN (a+))" if run else "sessions (PATTERN (start cont*))")
                + " rewritten with window functions (gaps and islands); one row per match; FIRST / LAST measures use "
                "min_by / max_by on the ORDER BY key; verify against the source on real data", "2.14")


def _mr_unsupported(select: exp.Select, mr: exp.MatchRecognize) -> str | None:
    pat = mr.args.get("pattern")
    text = re.sub(r"\s+", " ", str(getattr(pat, "name", pat) or "")).strip()
    if not (_RUN.match(text) or _SESSION.match(text)):
        return f"pattern {text!r} is not a run (a+) or a session (a b*)"
    if not isinstance(select.args["from_"].this, (exp.Table, exp.Subquery)) or select.args.get("joins"):
        return "the source is not a single table or subquery"
    if mr.args.get("rows") or (mr.args.get("after") and "PAST LAST" not in str(mr.args["after"]).upper()):
        return "ALL ROWS PER MATCH / AFTER MATCH SKIP other than past last row"
    if not mr.args.get("order") or len(mr.args.get("define") or []) != 1:
        return "no ORDER BY, or DEFINE with more than one variable"
    for m in mr.args.get("measures") or []:
        al = m.this
        agg = al.this if isinstance(al, exp.Alias) else None
        if agg is None or not isinstance(agg, (exp.Count, exp.Min, exp.Max, exp.Sum, exp.Avg, exp.First, exp.Last)):
            return "a measure other than COUNT / MIN / MAX / SUM / AVG / FIRST / LAST (MATCH_NUMBER, CLASSIFIER, ...)"
        if any(isinstance(c, exp.Column) and c.table for c in agg.find_all(exp.Column)) and \
                {c.table.lower() for c in agg.find_all(exp.Column) if c.table} - {"a"} and False:
            return "variable-qualified measure"
    for node in mr.args["define"][0].find_all(exp.Anonymous):
        if str(node.this).upper() in ("NEXT", "FIRST", "LAST", "CLASSIFIER", "MATCH_NUMBER") or \
                (str(node.this).upper() == "PREV" and len(node.expressions) != 1):
            return f"DEFINE uses {str(node.this).upper()}"
    return None


# ------------------------------------------------------------------------------------------------ 2.15 CONNECT BY
def rule_connect_by(tree: exp.Expression, rc: RuleContext) -> None:
    for select in post_order(tree, exp.Select):
        cb = select.args.get("connect")
        if not isinstance(cb, exp.Connect):
            continue
        frm = select.args.get("from_")
        table = frm.this if frm is not None else None
        if not rc.has("recursive_cte"):
            rc.flag("SNW-CONNECT-BY-UNSUPPORTED", "CONNECT BY needs WITH RECURSIVE and the target profile does not have "
                    "it; suggested pattern: an iterative notebook loop (seed the roots, join the children level by "
                    "level into a temp view until no row is added)", "2.15")
            continue
        why = None
        if not isinstance(table, exp.Table) or select.args.get("joins"):
            why = "CONNECT BY over more than one table or a subquery (put the hierarchy in a view first)"
        elif cb.args.get("nocycle"):
            why = "NOCYCLE (a cycle guard needs the visited path)"
        elif any(isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star))
                 for e in select.expressions):
            why = "SELECT * (the level / path helper columns would leak)"
        cond = cb.args.get("connect")
        if why is None and not any(isinstance(n, exp.Prior) for n in cond.find_all(exp.Prior)):
            why = "no PRIOR in the CONNECT BY condition"
        if why is None:
            anon = {str(a.this).upper() for a in select.find_all(exp.Anonymous)}
            if "CONNECT_BY_ISLEAF" in anon or "CONNECT_BY_ISCYCLE" in anon or any(
                    isinstance(c, exp.Column) and c.name.upper() in ("CONNECT_BY_ISLEAF", "CONNECT_BY_ISCYCLE")
                    for c in select.find_all(exp.Column)):
                why = "CONNECT_BY_ISLEAF / CONNECT_BY_ISCYCLE"
        if why:
            rc.flag("SNW-CONNECT-BY-UNSUPPORTED", f"CONNECT BY not converted: {why}; suggested pattern: WITH RECURSIVE "
                    "(anchor = START WITH rows, step = join children on the PRIOR condition) or a notebook loop", "2.15")
            continue
        a = table.alias or table.name
        # derived columns the outer query reads
        extras: list[tuple[str, exp.Expression]] = []   # (column name, anchor expr)
        steps: list[exp.Expression] = []

        def add_extra(name: str, anchor: exp.Expression, step: exp.Expression) -> exp.Column:
            extras.append((name, anchor))
            steps.append(step)
            return exp.column(name)
        for node in list(select.find_all(exp.Column)):
            if not node.table and node.name.upper() == "LEVEL":
                node.replace(exp.column("__level"))
        for node in list(select.find_all(exp.Anonymous, exp.ConnectByRoot)):
            if isinstance(node, exp.ConnectByRoot):
                n = f"__root{len(extras)}"
                node.replace(add_extra(n, node.this.copy(), exp.column(n, table="p")))
            elif str(node.this).upper() == "SYS_CONNECT_BY_PATH" and len(node.expressions) == 2:
                col, sep = node.expressions
                n = f"__path{len(extras)}"
                anchor = exp.Anonymous(this="concat", expressions=[sep.copy(), exp.Cast(this=col.copy(), to=exp.DataType.build("STRING"))])
                step = exp.Anonymous(this="concat", expressions=[exp.column(n, table="p"), sep.copy(), exp.Cast(this=col.copy(), to=exp.DataType.build("STRING"))])
                node.replace(add_extra(n, anchor, step))
        for i, st in enumerate(steps):
            for c in st.find_all(exp.Column):
                if not c.table:
                    c.set("table", exp.to_identifier(a))
        # the recursive step: PRIOR x reads the parent row p, everything else the child row
        step_cond = cond.copy()
        for pr in list(step_cond.find_all(exp.Prior)):
            inner = pr.this
            for c in inner.find_all(exp.Column):
                c.set("table", exp.to_identifier("p"))
            pr.replace(inner)
        for c in step_cond.find_all(exp.Column):
            if c.table != "p" and not c.table:
                c.set("table", exp.to_identifier(a))
        base = table.copy()
        base.set("alias", exp.TableAlias(this=exp.to_identifier(a)))
        start = cb.args.get("start")
        anchor_sel = exp.select(_star_of(a), exp.alias_(exp.Literal.number(1), "__level"),
                                *[exp.alias_(e.copy(), n) for n, e in extras]).from_(base.copy())
        if start is not None:
            anchor_sel = anchor_sel.where(start.copy())
        step_sel = exp.select(_star_of(a), exp.alias_(exp.Add(this=exp.column("__level", table="p"), expression=exp.Literal.number(1)), "__level"),
                              *[exp.alias_(s.copy(), n) for (n, _), s in zip(extras, steps)]).from_(base.copy()).join(
            exp.Table(this=exp.to_identifier("__cb"), alias=exp.TableAlias(this=exp.to_identifier("p"))), on=step_cond)
        union = exp.Union(this=anchor_sel, expression=step_sel, distinct=False)
        cte = exp.CTE(this=union, alias=exp.TableAlias(this=exp.to_identifier("__cb")))
        w = select.args.get("with_")
        if w is None:
            w = exp.With(expressions=[cte], recursive=True)
        else:
            w.set("recursive", True)
            w.append("expressions", cte)
        select.set("with_", w)
        new_from = exp.Table(this=exp.to_identifier("__cb"), alias=exp.TableAlias(this=exp.to_identifier(a)))
        frm.set("this", mark_generated(new_from))
        select.set("connect", None)
        rc.flag("SNW-CONNECT-BY-REWRITE", "CONNECT BY became WITH RECURSIVE (LEVEL -> __level; the WHERE filter applies "
                "after the hierarchy is built, as on Snowflake); Databricks stops a recursion at "
                "spark.sql.cteRecursionLevelLimit (default 100 levels) and a cycle in the data does not raise like "
                "Snowflake's CONNECT BY: verify the depth and that the hierarchy is acyclic", "2.15")


# ------------------------------------------------------------------------------------------------ 2.17 PIVOT
def rule_pivot_any(tree: exp.Expression, rc: RuleContext) -> None:
    for pivot in post_order(tree, exp.Pivot):
        for f in pivot.args.get("fields") or []:
            if not isinstance(f, exp.In):
                continue
            dyn = any(isinstance(e, exp.PivotAny) for e in f.expressions) or f.args.get("query") is not None or any(
                isinstance(e, exp.Subquery) for e in f.expressions)
            if not dyn:
                continue
            col = f.this.name.upper() if isinstance(f.this, exp.Column) else ""
            vals = rc.conversion.pivot_values.get(col)
            if not vals:
                rc.flag("SNW-PIVOT-DYNAMIC", f"PIVOT ... IN (ANY | subquery) on {col or 'an expression'}: Databricks needs a "
                        "literal list; add the column's values to the manifest `pivot_values` ({COLUMN: [values]}) to "
                        "freeze them at build time, or generate the statement with EXECUTE IMMEDIATE", "2.17")
                continue
            f.set("expressions", [mark_generated(string(str(v)) if not isinstance(v, (int, float)) else exp.Literal.number(v))
                                  for v in vals])
            f.set("query", None)
            rc.flag("SNW-PIVOT-FROZEN", f"dynamic PIVOT on {col} frozen to {len(vals)} build-time values: a new value in "
                    "the data is not a new column until the list is refreshed", "2.17")


# ------------------------------------------------------------------------------------------------ 2.23 / 2.24
INFO_SCHEMA = {"TABLES": "tables", "COLUMNS": "columns", "SCHEMATA": "schemata", "VIEWS": "views",
               "TABLE_PRIVILEGES": "table_privileges"}
ACCOUNT_USAGE = {"QUERY_HISTORY": "system.query.history", "WAREHOUSE_METERING_HISTORY": "system.billing.usage",
                 "LOGIN_HISTORY": "system.access.audit", "ACCESS_HISTORY": "system.access.table_lineage",
                 "TABLES": "system.information_schema.tables", "COLUMNS": "system.information_schema.columns"}


def rule_system_tables(tree: exp.Expression, rc: RuleContext) -> None:
    for node in post_order(tree, exp.TableFromRows, exp.Anonymous):
        fn = node.this if isinstance(node, exp.TableFromRows) else node
        if isinstance(fn, exp.Anonymous) and str(fn.this).upper() == "RESULT_SCAN":
            rc.flag("SNW-RESULT-SCAN-UNSUPPORTED", "RESULT_SCAN reads the previous statement's result, which has no "
                    "Databricks counterpart; suggested pattern: CREATE OR REPLACE TEMP VIEW prev_result AS <the "
                    "previous statement> and select from it (for SHOW ... + RESULT_SCAN read "
                    "system.information_schema)", "2.23")
            break
    cat = (getattr(rc.names, "default_catalog", "") or "main").lower()
    for t in post_order(tree, exp.Table):
        schema = t.db.upper() if t.db else ""
        if schema == "INFORMATION_SCHEMA" and t.name.upper() in INFO_SCHEMA and not t.meta.get("rule_generated"):
            new = exp.Table(this=exp.to_identifier(INFO_SCHEMA[t.name.upper()]), db=exp.to_identifier("information_schema"),
                            catalog=exp.to_identifier(cat))
            if t.args.get("alias") is not None:
                new.set("alias", t.args["alias"].copy())
            t.replace(mark_generated(new, keep=[]))
            rc.flag("SNW-SYSTEM-TABLE", f"INFORMATION_SCHEMA.{t.name.upper()} became {cat}.information_schema."
                    f"{INFO_SCHEMA[t.name.upper()]} (one catalog; the column names match for the common columns; "
                    "Snowflake-only columns do not exist)", "2.24")
        elif schema == "ACCOUNT_USAGE" and (t.catalog or "").upper() == "SNOWFLAKE":
            tgt = ACCOUNT_USAGE.get(t.name.upper())
            rc.flag("SNW-SYSTEM-TABLE-UNMAPPED", f"SNOWFLAKE.ACCOUNT_USAGE.{t.name.upper()} -> "
                    f"{tgt or 'no system table'}: the column names and semantics differ; map them by hand", "2.24")


# ------------------------------------------------------------------------------------------------ X7 profile decisions
_INT64 = 9_223_372_036_854_775_807


def rule_profile_number_width(tree: exp.Expression, rc: RuleContext) -> None:
    """``col::NUMBER(p, 0)`` with p > 18 is DECIMAL(p, 0) on Databricks (slow, wide). When the data profile of the column
    shows every value fits a BIGINT, the cast is BIGINT (flagged: a later larger value overflows)."""
    for cast in post_order(tree, exp.Cast):
        dt = cast.args.get("to")
        if not isinstance(dt, exp.DataType) or dt.this != exp.DataType.Type.DECIMAL:
            continue
        params = [lit_int(p.this) for p in dt.expressions if isinstance(p, exp.DataTypeParam)]
        if len(params) != 2 or params[1] != 0 or (params[0] or 0) <= 18:
            continue
        prof = rc.profile_of(cast.this)
        try:
            lo, hi = int(float(prof["min"])), int(float(prof["max"]))        # type: ignore[index]
        except (KeyError, TypeError, ValueError):
            continue
        if -_INT64 <= lo and hi <= _INT64:
            cast.set("to", mark_generated(exp.DataType.build("BIGINT", dialect=TARGET)))
            rc.flag("SNW-PROFILE-ASSUMED", f"NUMBER({params[0]},0) became BIGINT: the column's profile (min {lo}, max {hi}) "
                    "fits 64 bits; a later value beyond it overflows", "3.1")


# ------------------------------------------------------------------------------------------------ 6.11 DEFAULT seq.NEXTVAL
def rule_default_nextval(tree: exp.Expression, rc: RuleContext) -> None:
    """``col NUMBER DEFAULT seq.NEXTVAL`` in a table definition -> ``GENERATED BY DEFAULT AS IDENTITY`` when the
    sequence is in the manifest's ``source_objects`` (L9); an unknown sequence is flagged, never invented."""
    from packs.snowflake import objects as ob
    for col in post_order(tree, exp.ColumnDef):
        for c in list(col.args.get("constraints") or []):
            kind = c.args.get("kind")
            dflt = kind.this if isinstance(kind, exp.DefaultColumnConstraint) else None
            if not (isinstance(dflt, exp.Column) and dflt.name.upper() == "NEXTVAL" and dflt.table):
                continue
            seq = ".".join(p for p in (dflt.args.get("catalog") and dflt.args["catalog"].name,
                                       dflt.args.get("db") and dflt.args["db"].name, dflt.table) if p)
            clause = ob.default_to_identity(f"{seq}.NEXTVAL", dict(rc.conversion.sequences))
            if clause is None:
                rc.flag("SNW-SEQ-SHARED", f"DEFAULT {seq}.NEXTVAL: the sequence is not in the manifest's source_objects "
                        "(its start and increment are unknown): choose identity, uuid(), a counter table or "
                        "row_number() + max", "6.11")
                continue
            spec = rc.conversion.sequences.get(seq.upper()) or rc.conversion.sequences.get(dflt.table.upper()) or {}
            c.set("kind", mark_generated(exp.GeneratedAsIdentityColumnConstraint(
                this=False, start=exp.Literal.number(spec["start"]), increment=exp.Literal.number(spec["increment"]))))
            rc.flag("SNW-SEQ-IDENTITY", f"DEFAULT {seq}.NEXTVAL became {clause}: values, gaps and ORDER are not the "
                    "sequence's; if the sequence feeds other columns they now number independently", "6.11")


RULES = (rule_profile_number_width, rule_default_nextval, rule_flatten, rule_split_to_table, rule_strtok, rule_asof, rule_match_recognize, rule_connect_by,
         rule_pivot_any, rule_system_tables)

__all__ = ["ACCOUNT_USAGE", "INFO_SCHEMA", "RULES"]
