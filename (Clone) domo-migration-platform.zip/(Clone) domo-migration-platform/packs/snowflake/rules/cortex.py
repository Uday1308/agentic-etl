"""packs.snowflake.rules.cortex - Snowflake Cortex functions -> Databricks ``ai_*`` functions (catalogue row 2.30).

    SENTIMENT -> ai_analyze_sentiment    SUMMARIZE -> ai_summarize           TRANSLATE(t, from, to) -> ai_translate(t, to)
    CLASSIFY_TEXT(t, labels) -> ai_classify(t, labels)    EXTRACT_ANSWER(t, q) / COMPLETE(model, prompt) -> ai_query(endpoint, ..)
    EMBED_TEXT_768 / 1024(model, t) -> ai_query(embedding endpoint, t)

The model -> endpoint map is ``cortex_endpoints.yaml`` (override: ``MIGRATOR_CORTEX_ENDPOINTS_FILE``). Every call is flagged
``SNW-CORTEX`` (review): the outputs are model-generated, differ in type and wording, cost per call and are not repeatable,
so nothing downstream may assume the Snowflake values. An unmapped model uses the default endpoint (``SNW-CORTEX-MODEL``).
"""
from __future__ import annotations

import os
import pathlib
from functools import lru_cache

import yaml
from sqlglot import exp

from packs.snowflake.rules.base import RuleContext, lit_str, mark_generated, post_order

DEFAULT_FILE = pathlib.Path(__file__).resolve().parents[1] / "cortex_endpoints.yaml"


@lru_cache(maxsize=4)
def _load(path: str) -> dict:
    return dict(yaml.safe_load(pathlib.Path(path).read_text(encoding="utf-8")) or {})


def endpoint_map() -> dict:
    return _load(os.environ.get("MIGRATOR_CORTEX_ENDPOINTS_FILE") or str(DEFAULT_FILE))


def _fn(name: str, args: list[exp.Expression]) -> exp.Expression:
    return mark_generated(exp.Anonymous(this=name, expressions=args), keep=args)


def _is_structured(node: exp.Expression) -> bool:
    return isinstance(node, exp.Array) or (isinstance(node, exp.Anonymous)
                                           and str(node.this).upper() in ("ARRAY_CONSTRUCT", "OBJECT_CONSTRUCT"))


def rule_cortex(tree: exp.Expression, rc: RuleContext) -> None:
    cfg = endpoint_map()
    for dot in post_order(tree, exp.Dot):
        fn, left = dot.expression, dot.this
        if not (isinstance(fn, exp.Anonymous) and isinstance(left, exp.Dot)
                and isinstance(left.this, exp.Identifier) and isinstance(left.expression, exp.Identifier)
                and left.this.name.upper() == "SNOWFLAKE" and left.expression.name.upper() == "CORTEX"):
            continue
        name, args = str(fn.this).upper(), [a.copy() for a in fn.expressions]
        new: exp.Expression | None = None
        extra = ""
        if name == "SENTIMENT" and len(args) == 1:
            new = _fn("ai_analyze_sentiment", args)
            extra = "returns a label (positive / negative / neutral / mixed), Snowflake a score from -1 to 1"
        elif name == "SUMMARIZE" and len(args) == 1:
            new = _fn("ai_summarize", args)
        elif name == "TRANSLATE" and len(args) == 3:
            new = _fn("ai_translate", [args[0], args[2]])
            extra = "the source language argument is dropped (auto-detected)"
        elif name == "CLASSIFY_TEXT" and len(args) == 2:
            new = _fn("ai_classify", args)
            extra = "returns the label, Snowflake an object {label: ...}"
        elif name == "COMPLETE" and len(args) in (2, 3):
            model = lit_str(args[0])
            if model is None:
                rc.flag("SNW-CORTEX-MODEL", "COMPLETE with a model that is not a literal: choose the endpoint by hand", "2.30")
                continue
            if _is_structured(args[1]):
                rc.flag("SNW-CORTEX-MODEL", "COMPLETE with a messages array / options object: build the ai_query "
                        "request by hand", "2.30")
                continue
            endpoint = (cfg.get("models") or {}).get(model.lower())
            if endpoint is None:
                endpoint = cfg.get("default_endpoint", "")
                rc.flag("SNW-CORTEX-MODEL", f"Cortex model {model!r} is not in the endpoint map: used the default "
                        f"endpoint {endpoint}; add it to cortex_endpoints.yaml", "2.30")
            new = _fn("ai_query", [exp.Literal.string(endpoint), args[1]])
            if len(args) == 3:
                extra = "the options argument (temperature, max_tokens) is dropped"
        elif name == "EXTRACT_ANSWER" and len(args) == 2:
            prompt = mark_generated(exp.Anonymous(this="concat", expressions=[
                exp.Literal.string("Answer the question using only the text. Question: "), args[1],
                exp.Literal.string(". Text: "), args[0]]), keep=args)
            new = _fn("ai_query", [exp.Literal.string(cfg.get("default_endpoint", "")), prompt])
            extra = "EXTRACT_ANSWER became a prompt; the answer is free text, not an array of {answer, score}"
        elif name.startswith("EMBED_TEXT_") and len(args) == 2:
            model = lit_str(args[0]) or ""
            endpoint = (cfg.get("embeddings") or {}).get(model.lower())
            if endpoint is None:
                endpoint = cfg.get("default_embedding_endpoint", "")
                rc.flag("SNW-CORTEX-MODEL", f"embedding model {model!r} is not in the endpoint map: used {endpoint}",
                        "2.30")
            new = _fn("ai_query", [exp.Literal.string(endpoint), args[1]])
            extra = "the vector dimension differs from the Snowflake model: re-embed every stored vector"
        if new is None:
            rc.flag("SNW-CORTEX-MODEL", f"SNOWFLAKE.CORTEX.{name} with {len(args)} argument(s) has no ai_* mapping", "2.30")
            continue
        dot.replace(new)
        rc.flag("SNW-CORTEX", f"Cortex {name} became {new.this}: model output is non-deterministic, billed per call "
                "and differs from Snowflake's" + (f"; {extra}" if extra else ""), "2.30")


RULES = (rule_cortex,)
__all__ = ["RULES", "endpoint_map", "rule_cortex"]
