# Ported from SNF2DBX-main/converters/dialect.py (LatentView internal): the date-part rewrites (_DATE_PARTS, _date_part,
# _date_parts, lines ~159-230) and from SNF2DBX-main/converters/file_formats.py (spark_datetime_pattern, lines 21-56): the
# Snowflake format-string -> Spark datetime pattern translator. Extended here: the rules read the account parameters
# (WEEK_START, WEEK_OF_YEAR_POLICY, TIMESTAMP_TYPE_MAPPING, TIMEZONE, *_INPUT_FORMAT) from the ConversionContext and
# flag instead of guessing when one is missing; WEEK_OF_YEAR_POLICY=1 is computed, not refused.
"""packs.snowflake.rules.dates - the date and time rows of catalogue section 1 (ADR 037 section 8).

    1.2  DATEDIFF counts boundaries crossed          1.14 WEEK_START / WEEK_OF_YEAR_POLICY date parts
    1.3  TIMESTAMP alias type (TIMESTAMP_TYPE_MAPPING) 1.15 TO_TIMESTAMP(number): epoch scale
    1.16 format strings (token translator, AUTO)      1.17 TIMESTAMP_TZ keeps a per-row offset
    1.18 nanosecond precision                         1.26 session TIMEZONE
"""
from __future__ import annotations

import re

from sqlglot import exp

from packs.snowflake.rules.base import (
    ColInfo,
    RuleContext,
    cast_to,
    lit_int,
    lit_str,
    number,
    post_order,
    string,
    tpl,
)

DType = exp.DataType.Type

# ------------------------------------------------------------------------------------------------ date-part names
_DATE_PARTS: dict[str, str] = {}
for _canonical, _aliases in {
    "YEAR": "Y YY YYY YYYY YR YEARS YRS", "QUARTER": "Q QTR QTRS QUARTERS", "MONTH": "MM MON MONS MONTHS",
    "DAY": "D DD DAYS DAYOFMONTH", "DAYOFWEEK": "WEEKDAY DOW DW", "DAYOFWEEKISO": "WEEKDAY_ISO DOW_ISO DW_ISO",
    "DAYOFYEAR": "YEARDAY DOY DY", "WEEK": "W WK WEEKOFYEAR WOY WY", "WEEKISO": "WEEK_ISO WEEKOFYEARISO WEEKOFYEAR_ISO",
    "YEAROFWEEK": "", "YEAROFWEEKISO": "", "HOUR": "H HH HR HOURS HRS", "MINUTE": "M MI MIN MINUTES MINS",
    "SECOND": "S SEC SECONDS SECS", "MILLISECOND": "MS MSEC MILLISECONDS", "MICROSECOND": "US USEC MICROSECONDS",
    "NANOSECOND": "NS NSEC NANOSEC NANOSECONDS",
}.items():
    for _name in [_canonical, *_aliases.split()]:
        _DATE_PARTS[_name] = _canonical

#: units a Databricks DATE_TRUNC understands, by canonical Snowflake part
_TRUNC_UNITS = {"YEAR": "YEAR", "QUARTER": "QUARTER", "MONTH": "MONTH", "WEEK": "WEEK", "DAY": "DAY", "HOUR": "HOUR",
                "MINUTE": "MINUTE", "SECOND": "SECOND", "MILLISECOND": "MILLISECOND", "MICROSECOND": "MICROSECOND"}


def part_name(node: exp.Expression | None) -> str:
    if node is None:
        return ""
    if isinstance(node, (exp.Literal, exp.Var, exp.Identifier, exp.Column)):
        return str(node.name).strip("'\"").upper()
    return node.sql().strip("'\"").upper()


def canonical_part(node: exp.Expression | None) -> str | None:
    return _DATE_PARTS.get(part_name(node))


# ------------------------------------------------------------------------------------------------ format strings
#: (Snowflake element, Spark pattern), longest first so FF3 beats FF and TZH:TZM beats TZH
_FORMAT_ELEMENTS: tuple[tuple[str, str], ...] = (
    ("TZH:TZM", "XXX"), ("TZHTZM", "XX"), ("TZH", "X"),
    ("FF9", "SSSSSSSSS"), ("FF8", "SSSSSSSS"), ("FF7", "SSSSSSS"), ("FF6", "SSSSSS"), ("FF5", "SSSSS"),
    ("FF4", "SSSS"), ("FF3", "SSS"), ("FF2", "SS"), ("FF1", "S"), ("FF0", ""), ("FF", "SSSSSSSSS"),
    ("YYYY", "yyyy"), ("YY", "yy"), ("MONTH", "MMMM"), ("MON", "MMM"), ("MM", "MM"), ("DDD", "DDD"), ("DD", "dd"),
    ("DAY", "EEEE"), ("DY", "EEE"), ("HH24", "HH"), ("HH12", "hh"), ("MI", "mm"), ("SS", "ss"),
    ("A.M.", "a"), ("P.M.", "a"), ("AM", "a"), ("PM", "a"),
)
_NUMERIC_FORMAT = re.compile(r"^[\s09.,$FMBSXLCG]*$", re.I)


def is_numeric_format(fmt: str) -> bool:
    """A TO_CHAR / TO_NUMBER format made of number elements (9 0 . , $ ...), not date-time elements."""
    body = re.sub(r'"[^"]*"', "", fmt)
    if re.search(r"YYYY|YY|DD|HH|SS|FF|MON|DY|DAY|TZ|AM|PM", body, re.I):
        return False
    return bool(re.search(r"[09$]", body)) and bool(_NUMERIC_FORMAT.match(body))


def spark_pattern(value: str) -> tuple[str | None, list[str]]:
    """``(pattern, notes)``: a Snowflake date-time format as a Spark pattern, or ``(None, [reason])`` when an element
    has no direct match (never guessed). ``notes`` lists lossy-but-converted elements (``YY``, ``FF7-9``)."""
    out, rest, notes = "", value, []
    has_meridian = bool(re.search(r'AM|PM|A\.M\.|P\.M\.', re.sub(r'"[^"]*"', "", value), re.I))
    while rest:
        up = rest.upper()
        if up.startswith("HH") and not up.startswith(("HH24", "HH12")):
            out, rest = out + ("hh" if has_meridian else "HH"), rest[2:]
            continue
        for snow, spark in _FORMAT_ELEMENTS:
            if up.startswith(snow):
                if snow == "YY":
                    notes.append("YY")
                if snow in ("FF7", "FF8", "FF9", "FF"):
                    notes.append("FF>6")
                out, rest = out + spark, rest[len(snow):]
                break
        else:
            ch = rest[0]
            if ch in "-/:. _,":
                out, rest = out + ch, rest[1:]
            elif ch == '"':                                   # Snowflake quoted literal text
                end = rest.find('"', 1)
                if end < 0:
                    return None, ["unterminated quoted text in the format"]
                out, rest = out + "'" + rest[1:end].replace("'", "''") + "'", rest[end + 1:]
            elif ch in "Tt" and not rest[1:2].isalpha():
                out, rest = out + "'T'", rest[1:]
            else:
                return None, [f"format element at {rest[:6]!r} has no Databricks pattern"]
    return out, notes


# ------------------------------------------------------------------------------------------------ 1.14 date parts
def _spark_start_day(week_start: int) -> int:
    """The Spark ``dayofweek`` number (Sunday = 1) of the day a week starts on, for WEEK_START 1..7 (1 = Monday) and
    0 (legacy, weeks start Monday)."""
    ws = 1 if week_start == 0 else week_start
    return (ws % 7) + 1


def date_part_expr(part: str, value: exp.Expression, rc: RuleContext) -> exp.Expression | None:
    """Databricks expression with Snowflake's result for DATE_PART(part, value) under the account's WEEK_START and
    WEEK_OF_YEAR_POLICY; None (and a flag) when the result cannot be reproduced."""
    row = "1.14"
    if part in ("YEAR", "QUARTER", "MONTH", "DAY", "HOUR", "MINUTE"):
        return tpl(f"EXTRACT({part} FROM __v__)", __v__=value)
    if part == "SECOND":
        return tpl("SECOND(__v__)", __v__=value)        # whole seconds; EXTRACT(SECOND ...) carries the fraction
    if part == "DAYOFYEAR":
        return tpl("DAYOFYEAR(__v__)", __v__=value)
    if part == "DAYOFWEEKISO":
        return tpl("((DAYOFWEEK(__v__) + 5) % 7) + 1", __v__=value)
    needs_policy = part in ("WEEK", "YEAROFWEEK")
    week_start = rc.param_int("WEEK_START", "SNW-PARAM-ASSUMED", row, f"DATE_PART({part})")
    policy = rc.param_int("WEEK_OF_YEAR_POLICY", "SNW-PARAM-ASSUMED", row, f"DATE_PART({part})") if needs_policy else 0
    if week_start is None or policy is None or not 0 <= week_start <= 7:
        rc.flag("SNW-WEEK-PARAM", f"DATE_PART({part}) needs a WEEK_START in 0..7 and a WEEK_OF_YEAR_POLICY of 0 or 1", row)
        return None
    if part == "DAYOFWEEK":
        if week_start == 0:                               # legacy: Sunday = 0 ... Saturday = 6
            return tpl("DAYOFWEEK(__v__) - 1", __v__=value)
        sd = _spark_start_day(week_start)                 # the configured first day = 1
        if sd == 1:
            return tpl("DAYOFWEEK(__v__)", __v__=value)
        return tpl(f"((DAYOFWEEK(__v__) + {7 - sd}) % 7) + 1", __v__=value)
    if part == "WEEKISO":
        return tpl("WEEKOFYEAR(__v__)", __v__=value)
    if part == "YEAROFWEEKISO":
        return tpl("EXTRACT(YEAROFWEEK FROM __v__)", __v__=value)
    if policy == 0 and week_start in (0, 1):               # ISO 8601, as Snowflake with WEEK_OF_YEAR_POLICY=0
        return tpl("WEEKOFYEAR(__v__)" if part == "WEEK" else "EXTRACT(YEAROFWEEK FROM __v__)", __v__=value)
    if policy == 1:                                        # week 1 = the week containing January 1st
        if part == "YEAROFWEEK":
            return tpl("YEAR(__v__)", __v__=value)
        sd = _spark_start_day(week_start)
        return tpl(f"((DAYOFYEAR(__v__) - 1 + ((DAYOFWEEK(MAKE_DATE(YEAR(__v__), 1, 1)) - {sd} + 7) % 7)) DIV 7) + 1",
                   __v__=value)
    rc.flag("SNW-WEEK-PARAM", f"DATE_PART({part}) with WEEK_OF_YEAR_POLICY=0 and WEEK_START={week_start} has no Databricks "
                              "equivalent (Databricks only has ISO weeks)", row)
    return None


def _trunc_week(value: exp.Expression, rc: RuleContext) -> exp.Expression | None:
    week_start = rc.param_int("WEEK_START", "SNW-PARAM-ASSUMED", "1.14", "DATE_TRUNC('week')")
    if week_start is None or not 0 <= week_start <= 7:
        rc.flag("SNW-WEEK-PARAM", "DATE_TRUNC('week') needs a WEEK_START in 0..7", "1.14")
        return None
    if week_start in (0, 1):                               # weeks start on Monday, as Databricks
        return tpl("DATE_TRUNC('WEEK', __v__)", __v__=value)
    k = week_start - 1                                     # start day = Monday + k
    return tpl(f"DATE_TRUNC('WEEK', __v__ - INTERVAL {k} DAY) + INTERVAL {k} DAY", __v__=value)


def rule_date_parts(tree: exp.Expression, rc: RuleContext) -> None:
    """DAYOFWEEK / WEEK / YEAROFWEEK / EXTRACT / DATE_PART / DATE_TRUNC with the account's week parameters."""
    cols = rc.columns_of(tree)
    simple = {exp.DayOfWeek: "DAYOFWEEK", exp.DayOfWeekIso: "DAYOFWEEKISO", exp.Week: "WEEK",
              exp.YearOfWeek: "YEAROFWEEK", exp.YearOfWeekIso: "YEAROFWEEKISO"}
    for node in post_order(tree, exp.Extract, exp.DayOfWeek, exp.DayOfWeekIso, exp.Week, exp.YearOfWeek,
                           exp.YearOfWeekIso, exp.DateTrunc, exp.TimestampTrunc, exp.Anonymous):
        if isinstance(node, exp.Extract):
            part = canonical_part(node.this)
            if part is None:
                rc.flag("SNW-DATE-PART", f"date part {part_name(node.this)} has no Databricks equivalent with the same "
                                         "result", "1.14")
                continue
            if part in ("MILLISECOND", "MICROSECOND", "NANOSECOND"):
                rc.flag("SNW-DATE-PART", f"date part {part} has no Databricks equivalent with the same result", "1.14")
                continue
            new = date_part_expr(part, node.expression, rc)
            if new is not None:
                node.replace(new)
        elif isinstance(node, exp.Anonymous):
            name = str(node.this).upper()
            if name in ("WEEKISO", "YEAROFWEEKISO", "DAYOFWEEKISO") and len(node.expressions) == 1:
                new = date_part_expr(name, node.expressions[0], rc)
                if new is not None:
                    node.replace(new)
        elif isinstance(node, (exp.DateTrunc, exp.TimestampTrunc)):
            unit = node.args.get("unit")
            part = canonical_part(unit)
            if part is None or part not in _TRUNC_UNITS:
                rc.flag("SNW-DATE-PART", f"DATE_TRUNC unit {part_name(unit)} has no Databricks equivalent with the same "
                                         "result", "1.14")
                continue
            value = node.this
            if part == "WEEK":
                new = _trunc_week(value, rc)
            else:
                new = tpl(f"DATE_TRUNC('{_TRUNC_UNITS[part]}', __v__)", __v__=value)
            if new is None:
                continue
            info = cols.get(id(value)) if isinstance(value, exp.Column) else None
            if info is not None and info.family == "date":            # Databricks DATE_TRUNC always returns a timestamp
                new = cast_to(new, "DATE")
            node.replace(new)
        else:
            part = simple[type(node)]
            if part == "WEEK" and node.args.get("mode"):
                rc.flag("SNW-DATE-PART", "WEEK with a mode argument is not a Snowflake function shape", "1.14")
                continue
            new = date_part_expr(part, node.this, rc)
            if new is not None:
                node.replace(new)


# ------------------------------------------------------------------------------------------------ 1.2 DATEDIFF
_EPOCH_MONDAY = "CAST('1900-01-01' AS DATE)"          # a Monday: the anchor of the week index


def rule_datediff(tree: exp.Expression, rc: RuleContext) -> None:
    """``DATEDIFF(unit, a, b)`` counts the unit boundaries crossed between a and b, not whole units."""
    for node in post_order(tree, exp.DateDiff):
        unit = canonical_part(node.args.get("unit"))
        later, earlier = node.this, node.expression
        if unit is None or later is None or earlier is None:
            rc.flag("SNW-DATEDIFF-UNIT", f"DATEDIFF unit {part_name(node.args.get('unit')) or '(dynamic)'} cannot be "
                                         "decided at conversion time", "1.2")
            continue
        sub = {"__b__": later, "__a__": earlier}
        if unit == "YEAR":
            new = tpl("YEAR(__b__) - YEAR(__a__)", **sub)
        elif unit == "QUARTER":
            new = tpl("(YEAR(__b__) * 4 + QUARTER(__b__)) - (YEAR(__a__) * 4 + QUARTER(__a__))", **sub)
        elif unit == "MONTH":
            new = tpl("(YEAR(__b__) * 12 + MONTH(__b__)) - (YEAR(__a__) * 12 + MONTH(__a__))", **sub)
        elif unit == "WEEK":
            ws = rc.param_int("WEEK_START", "SNW-PARAM-ASSUMED", "1.2", "DATEDIFF(week)")
            if ws is None or not 0 <= ws <= 7:
                rc.flag("SNW-WEEK-PARAM", "DATEDIFF(week) needs a WEEK_START in 0..7", "1.2")
                continue
            k = 0 if ws in (0, 1) else ws - 1
            idx = f"FLOOR((DATEDIFF(CAST(%s AS DATE), {_EPOCH_MONDAY}) - {k}) / 7)"
            new = tpl((idx % "__b__") + " - " + (idx % "__a__"), **sub)
        elif unit == "DAY":
            new = tpl("DATEDIFF(CAST(__b__ AS DATE), CAST(__a__ AS DATE))", **sub)
        elif unit == "HOUR":
            new = tpl("(DATEDIFF(CAST(__b__ AS DATE), CAST(__a__ AS DATE)) * 24) + (HOUR(__b__) - HOUR(__a__))", **sub)
        elif unit == "MINUTE":
            new = tpl("(DATEDIFF(CAST(__b__ AS DATE), CAST(__a__ AS DATE)) * 1440) + ((HOUR(__b__) - HOUR(__a__)) * 60)"
                      " + (MINUTE(__b__) - MINUTE(__a__))", **sub)
        elif unit == "SECOND":
            new = tpl("(DATEDIFF(CAST(__b__ AS DATE), CAST(__a__ AS DATE)) * 86400) + ((HOUR(__b__) - HOUR(__a__)) * 3600)"
                      " + ((MINUTE(__b__) - MINUTE(__a__)) * 60) + (SECOND(__b__) - SECOND(__a__))", **sub)
        else:
            rc.flag("SNW-DATEDIFF-UNIT", f"DATEDIFF({unit}) has no deterministic Databricks rule (sub-second boundaries)",
                    "1.2")
            continue
        node.replace(new)


# ------------------------------------------------------------------------------------------------ 1.3 / 1.17 / 1.18 types
def rule_timestamp_types(tree: exp.Expression, rc: RuleContext) -> None:
    """The TIMESTAMP / DATETIME alias is NTZ or LTZ by TIMESTAMP_TYPE_MAPPING; TIMESTAMP_TZ has no Databricks twin."""
    for node in post_order(tree, exp.DataType):
        this = node.this
        if this in (DType.TIMESTAMP, DType.DATETIME):
            mapping = rc.param_value("TIMESTAMP_TYPE_MAPPING", "SNW-PARAM-ASSUMED", "1.3", "the TIMESTAMP alias").upper()
            if mapping == "TIMESTAMP_NTZ":
                node.set("this", DType.TIMESTAMPNTZ)
            elif mapping == "TIMESTAMP_LTZ":
                node.set("this", DType.TIMESTAMP)             # Databricks TIMESTAMP is LTZ
                rc.flag("SNW-SESSION-TZ", "TIMESTAMP maps to TIMESTAMP_LTZ in this account: values are read in the "
                                          "session time zone, pin the Databricks session to the account TIMEZONE", "1.26")
            else:
                node.set("this", DType.TIMESTAMP)
                rc.flag("SNW-TIMESTAMP-TZ", f"TIMESTAMP_TYPE_MAPPING = {mapping}: the per-row offset is lost "
                                            "(Databricks has no offset type)", "1.17")
        elif this == DType.TIMESTAMPTZ:
            rc.flag("SNW-TIMESTAMP-TZ", "TIMESTAMP_TZ keeps a per-row offset and Databricks has no offset type: store "
                                        "the UTC instant plus an offset column when the profile shows offsets vary "
                                        "(X7), otherwise confirm they do not", "1.17")
            node.set("this", DType.TIMESTAMP)
        elif this == DType.TIMESTAMPLTZ:
            tz = rc.param("TIMEZONE")
            rc.flag("SNW-SESSION-TZ", "TIMESTAMP_LTZ values are interpreted in the session time zone: pin the "
                                      f"Databricks session to {tz.value if tz.known else 'the account TIMEZONE (not extracted)'}",
                    "1.26")
        if this in (DType.TIMESTAMP, DType.DATETIME, DType.TIMESTAMPNTZ, DType.TIMESTAMPTZ, DType.TIMESTAMPLTZ):
            for p in node.expressions:
                prec = lit_int(p.this if isinstance(p, exp.DataTypeParam) else p)
                if prec is not None and prec > 6:
                    rc.flag("SNW-TS-NANOS", f"TIMESTAMP({prec}) keeps nanoseconds; Databricks keeps microseconds (the "
                                            "last digits are lost)", "1.18")
                    node.set("expressions", [])


# ------------------------------------------------------------------------------------------------ 1.16 / 1.15 conversions
_STRING_TO_TS = {"TO_TIMESTAMP": "map", "TO_TIMESTAMP_NTZ": "ntz", "TO_TIMESTAMP_LTZ": "ltz", "TO_TIMESTAMP_TZ": "tz",
                 "TRY_TO_TIMESTAMP": "map", "TRY_TO_TIMESTAMP_NTZ": "ntz", "TRY_TO_TIMESTAMP_LTZ": "ltz",
                 "TRY_TO_TIMESTAMP_TZ": "tz"}
_STRING_TO_DATE = {"TO_DATE": False, "DATE": False, "TRY_TO_DATE": True}


def _input_format(rc: RuleContext, which: str, row: str, what: str) -> tuple[str | None, str]:
    """``(spark pattern or None, reason)`` of the account's implicit input format (DATE_INPUT_FORMAT etc.). None means
    AUTO or unknown: the caller keeps the native ISO parse and flags."""
    p = rc.param(which)
    if not p.known:
        return None, f"{which} was not extracted: {what} may accept layouts other than ISO"
    if str(p.value).upper() == "AUTO":
        return None, f"{which} = AUTO accepts several layouts; Databricks parses ISO only"
    pat, notes = spark_pattern(str(p.value))
    if pat is None:
        return None, f"{which} = {p.value!r} has no Databricks pattern ({'; '.join(notes)})"
    return pat, ""


def _ts_wrap(call: exp.Expression, kind: str, rc: RuleContext) -> exp.Expression:
    """Type the parsed timestamp: NTZ (explicit or by the account mapping) is cast, LTZ stays, TZ is flagged (1.17)."""
    if kind == "map":
        kind = {"TIMESTAMP_NTZ": "ntz", "TIMESTAMP_LTZ": "ltz", "TIMESTAMP_TZ": "tz"}.get(
            rc.param_value("TIMESTAMP_TYPE_MAPPING", "SNW-PARAM-ASSUMED", "1.3", "the TIMESTAMP alias").upper(), "ntz")
    if kind == "tz":
        rc.flag("SNW-TIMESTAMP-TZ", "a TIMESTAMP_TZ result keeps a per-row offset that Databricks cannot store", "1.17")
        return call
    if kind == "ltz":
        rc.flag("SNW-SESSION-TZ", "a TIMESTAMP_LTZ result is parsed in the session time zone: pin the Databricks session "
                                  "to the account TIMEZONE", "1.26")
        return call
    return cast_to(call, "TIMESTAMP_NTZ")


def _note_format(notes: list[str], rc: RuleContext, what: str) -> None:
    if "YY" in notes:
        rc.flag("SNW-FORMAT-YY", f"{what}: a two-digit year (YY) reads 70-99 as 19xx in Snowflake "
                                 "(TWO_DIGIT_CENTURY_START) and 20xx in Databricks", "1.16")
    if "FF>6" in notes:
        rc.flag("SNW-TS-NANOS", f"{what}: fractional seconds beyond 6 digits (FF7-FF9) are truncated to microseconds",
                "1.18")


def _string_arg_unknown(arg: exp.Expression, info: ColInfo | None) -> bool:
    """May the argument be text? A typed non-string column or a function result is not asked about."""
    if isinstance(arg, exp.Literal):
        return arg.is_string
    if isinstance(arg, exp.Column):
        fam = info.family if info else None
        return fam in (None, "string")
    return False


def rule_formats(tree: exp.Expression, rc: RuleContext) -> None:
    """TO_DATE / TO_TIMESTAMP* / TRY_TO_* / TO_TIME / TO_CHAR with Snowflake format strings and AUTO detection."""
    cols = rc.columns_of(tree)
    for node in post_order(tree, exp.StrToTime, exp.TsOrDsToDate, exp.TsOrDsToTime, exp.ToChar, exp.StrToDate,
                           exp.TimeToStr, exp.UnixToTime, exp.Anonymous):
        if isinstance(node, exp.Anonymous):
            _anonymous_conversion(node, rc, cols)
            continue
        if isinstance(node, exp.UnixToTime):
            _epoch(node, rc)
            continue
        fmt_node = node.args.get("format")
        arg = node.this
        info = cols.get(id(arg)) if isinstance(arg, exp.Column) else None
        if isinstance(node, exp.ToChar):
            _to_char(node, rc, info)
            continue
        if isinstance(node, (exp.TimeToStr, exp.StrToDate)):
            continue                                                   # not produced by the Snowflake parser here
        fmt = lit_str(fmt_node)
        is_time = isinstance(node, exp.TsOrDsToTime)
        if fmt_node is not None and fmt is None:
            rc.flag("SNW-FORMAT-DYNAMIC", "the date-time format is not a literal: it cannot be translated to a "
                                          "Databricks pattern at conversion time", "1.16")
            continue
        if is_time:
            rc.flag("SNW-TIME-TYPE", "TO_TIME / TIME values have no Databricks type; keep the value as a string or a "
                                     "timestamp", "1.16")
            continue
        if fmt is None or fmt.upper() == "AUTO":                       # AUTO detection / the account's input format
            which = "DATE_INPUT_FORMAT" if isinstance(node, exp.TsOrDsToDate) else "TIMESTAMP_INPUT_FORMAT"
            if fmt is None and not _string_arg_unknown(arg, info):
                pat, why = None, ""                                    # a date / timestamp / function result: no parse
            else:
                pat, why = _input_format(rc, which, "1.16", "the conversion")
            if pat is None and why:
                rc.flag("SNW-FORMAT-AUTO", f"{why}: rows in another layout become NULL or fail instead of parsing", "1.16")
            fmt_pat = pat
        else:
            fmt_pat, notes = spark_pattern(fmt)
            if fmt_pat is None:
                rc.flag("SNW-FORMAT-UNSUPPORTED", f"format {fmt!r}: {'; '.join(notes)}", "1.16")
                continue
            _note_format(notes, rc, f"format {fmt!r}")
            if "TZH" in fmt.upper():
                rc.flag("SNW-TIMESTAMP-TZ", f"format {fmt!r} carries a UTC offset: the offset is applied then dropped",
                        "1.17")
        safe = bool(node.args.get("safe"))
        if isinstance(node, exp.TsOrDsToDate):
            if fmt_pat is None:
                new = tpl("CAST(__v__ AS DATE)", __v__=arg) if not safe else tpl("TRY_CAST(__v__ AS DATE)", __v__=arg)
            elif safe:
                new = tpl("CAST(TRY_TO_TIMESTAMP(__v__, __f__) AS DATE)", __v__=arg, __f__=string(fmt_pat))
            else:
                new = tpl("TO_DATE(__v__, __f__)", __v__=arg, __f__=string(fmt_pat))
            node.replace(new)
            continue
        target = node.args.get("target_type")
        kind = {DType.TIMESTAMPNTZ: "ntz", DType.TIMESTAMPLTZ: "ltz", DType.TIMESTAMPTZ: "tz"}.get(
            target.this if target is not None else None, "map")
        fn = "TRY_TO_TIMESTAMP" if safe else "TO_TIMESTAMP"
        call = tpl(f"{fn}(__v__, __f__)", __v__=arg, __f__=string(fmt_pat)) if fmt_pat else tpl(f"{fn}(__v__)", __v__=arg)
        node.replace(_ts_wrap(call, kind, rc))


def _to_char(node: exp.ToChar, rc: RuleContext, info: ColInfo | None) -> None:
    arg, fmt_node = node.this, node.args.get("format")
    fmt = lit_str(fmt_node)
    if fmt_node is None:
        fam = info.family if info else None
        if fam in ("numeric", "string", "boolean") or isinstance(arg, exp.Literal):
            node.replace(tpl("CAST(__v__ AS STRING)", __v__=arg))
        else:
            node.replace(tpl("CAST(__v__ AS STRING)", __v__=arg))
            rc.flag("SNW-TO-CHAR-DEFAULT", "TO_CHAR / TO_VARCHAR without a format renders a timestamp with the "
                                           "account's output format (3 fractional digits); CAST AS STRING differs",
                    "1.16")
        return
    if fmt is None:
        rc.flag("SNW-FORMAT-DYNAMIC", "the TO_CHAR format is not a literal", "1.16")
        return
    if is_numeric_format(fmt):
        if re.search(r"FM|X|B|L|C|G", re.sub(r'"[^"]*"', "", fmt), re.I):
            rc.flag("SNW-FORMAT-UNSUPPORTED", f"number format {fmt!r} uses elements Databricks to_char does not have", "1.16")
            return
        node.replace(tpl("TO_CHAR(__v__, __f__)", __v__=arg, __f__=string(fmt)))
        return
    pat, notes = spark_pattern(fmt)
    if pat is None:
        rc.flag("SNW-FORMAT-UNSUPPORTED", f"format {fmt!r}: {'; '.join(notes)}", "1.16")
        return
    _note_format(notes, rc, f"format {fmt!r}")
    node.replace(tpl("DATE_FORMAT(__v__, __f__)", __v__=arg, __f__=string(pat)))


_EPOCH_FUNCS = {0: "TIMESTAMP_SECONDS", 3: "TIMESTAMP_MILLIS", 6: "TIMESTAMP_MICROS"}


def _epoch_expr(value: exp.Expression, scale: int, rc: RuleContext) -> exp.Expression | None:
    if scale in _EPOCH_FUNCS:
        call = tpl(f"{_EPOCH_FUNCS[scale]}(__v__)", __v__=value)
    elif scale == 9:
        rc.flag("SNW-TS-NANOS", "an epoch in nanoseconds is truncated to microseconds", "1.18")
        call = tpl("TIMESTAMP_MICROS(CAST(__v__ / 1000 AS BIGINT))", __v__=value)
    else:
        rc.flag("SNW-EPOCH-SCALE", f"TO_TIMESTAMP scale {scale} has no Databricks function", "1.15")
        return None
    return call


def _magnitude_scale(v: int) -> int:
    a = abs(v)
    if a < 31536000000:
        return 0
    if a < 31536000000000:
        return 3
    if a < 31536000000000000:
        return 6
    return 9


def _profile_scale(prof: dict | None) -> int | None:
    """The epoch scale every profiled value shares (min and max in the same magnitude band), else None."""
    try:
        lo, hi = _magnitude_scale(int(float(prof["min"]))), _magnitude_scale(int(float(prof["max"])))   # type: ignore[index]
    except (KeyError, TypeError, ValueError):
        return None
    return lo if lo == hi else None


def _epoch(node: exp.UnixToTime, rc: RuleContext) -> None:
    """``TO_TIMESTAMP(number [, scale])``: with a scale or a literal the answer is deterministic; otherwise it
    depends on the magnitude of every value (Snowflake guesses seconds / ms / us / ns)."""
    value, scale_node = node.this, node.args.get("scale")
    scale = lit_int(scale_node)
    if scale_node is not None and scale is None:
        rc.flag("SNW-EPOCH-SCALE", "TO_TIMESTAMP scale is not a literal", "1.15")
        return
    if scale is None:
        v = lit_int(value)
        prof = rc.profile_of(value) if v is None else None
        if prof is not None:                               # X7: the profile's range decides the scale
            try:
                lo, hi = _magnitude_scale(int(float(prof["min"]))), _magnitude_scale(int(float(prof["max"])))
            except (KeyError, TypeError, ValueError):
                lo, hi = -1, -2
            if lo == hi:
                new = _epoch_expr(value, lo, rc)
                if new is not None:
                    node.replace(new)
                    rc.flag("SNW-PROFILE-ASSUMED", f"TO_TIMESTAMP(number): the column's profile (min {prof['min']}, max "
                            f"{prof['max']}) says every value is scale {lo}; a later value of another size would be "
                            "read wrongly", "1.15")
                    return
        if v is None:
            rc.flag("SNW-EPOCH-SCALE", "TO_TIMESTAMP(number) guesses seconds / milliseconds / microseconds / nanoseconds "
                                       "from each value's size; the scale needs the data profile (X7) or a decision",
                    "1.15")
            return
        scale = _magnitude_scale(v)
    new = _epoch_expr(value, scale, rc)
    if new is not None:
        node.replace(new)


def _anonymous_conversion(node: exp.Anonymous, rc: RuleContext, cols: dict[int, ColInfo]) -> None:
    name = str(node.this).upper()
    if name not in _STRING_TO_TS and name not in _STRING_TO_DATE and name not in ("TO_TIME", "TRY_TO_TIME"):
        return
    args = node.expressions
    if len(args) != 1:
        if name in ("TO_TIME", "TRY_TO_TIME"):
            rc.flag("SNW-TIME-TYPE", "TO_TIME / TIME values have no Databricks type", "1.16")
        return
    arg = args[0]
    info = cols.get(id(arg)) if isinstance(arg, exp.Column) else None
    fam = info.family if info else None
    if name in ("TO_TIME", "TRY_TO_TIME"):
        rc.flag("SNW-TIME-TYPE", "TO_TIME / TIME values have no Databricks type", "1.16")
        return
    if name in _STRING_TO_DATE:
        if isinstance(arg, exp.Column) and fam in ("date", "timestamp", "timestamp_ntz", "timestamp_ltz"):
            node.replace(tpl("CAST(__v__ AS DATE)", __v__=arg))
            return
        if not _string_arg_unknown(arg, info) and not isinstance(arg, exp.Literal):
            node.replace(tpl("CAST(__v__ AS DATE)", __v__=arg))
            return
        pat, why = _input_format(rc, "DATE_INPUT_FORMAT", "1.16", "the conversion")
        if pat is None and why and not (isinstance(arg, exp.Literal) and re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", arg.name)):
            rc.flag("SNW-FORMAT-AUTO", f"{why}: rows in another layout become NULL or fail instead of parsing", "1.16")
        safe = _STRING_TO_DATE[name]
        if pat:
            new = tpl("CAST(TRY_TO_TIMESTAMP(__v__, __f__) AS DATE)" if safe else "TO_DATE(__v__, __f__)", __v__=arg,
                      __f__=string(pat))
        else:
            new = tpl("TRY_CAST(__v__ AS DATE)" if safe else "CAST(__v__ AS DATE)", __v__=arg)
        node.replace(new)
        return
    kind = _STRING_TO_TS[name]
    safe = name.startswith("TRY_")
    if fam in ("numeric", None) and isinstance(arg, exp.Column):
        scale = _profile_scale(rc.profile_of(arg))           # X7: the column's observed range decides the epoch scale
        if scale is not None:
            made = _epoch_expr(arg, scale, rc)
            if made is not None:
                node.replace(made)
                rc.flag("SNW-PROFILE-ASSUMED", f"{name}(number): the column's profile says every value is an epoch of scale "
                        f"{scale}; a later value of another size would be read wrongly", "1.15")
                return
    if fam in ("numeric", None) and not isinstance(arg, exp.Literal):
        rc.flag("SNW-EPOCH-SCALE", f"{name}(x) on a column whose type is {'unknown' if fam is None else 'numeric'}: a number "
                                   "is an epoch whose scale Snowflake guesses per value, a string is parsed with "
                                   "TIMESTAMP_INPUT_FORMAT; decide from the data profile (X7)", "1.15")
        return
    if fam in ("date", "timestamp", "timestamp_ntz", "timestamp_ltz", "timestamp_tz") and isinstance(arg, exp.Column):
        node.replace(_ts_wrap(tpl("CAST(__v__ AS TIMESTAMP)", __v__=arg), kind, rc))
        return
    pat, why = _input_format(rc, "TIMESTAMP_INPUT_FORMAT", "1.16", "the conversion")
    if pat is None and why:
        rc.flag("SNW-FORMAT-AUTO", f"{why}: rows in another layout become NULL or fail instead of parsing", "1.16")
    fn = "TRY_TO_TIMESTAMP" if safe else "TO_TIMESTAMP"
    call = tpl(f"{fn}(__v__, __f__)", __v__=arg, __f__=string(pat)) if pat else tpl(f"{fn}(__v__)", __v__=arg)
    node.replace(_ts_wrap(call, kind, rc))


# ------------------------------------------------------------------------------------------------ 1.26 session timezone
def rule_session_timezone(tree: exp.Expression, rc: RuleContext) -> None:
    """The session TIMEZONE decides 2-argument CONVERT_TIMEZONE, CURRENT_DATE and SYSDATE."""
    tz = rc.param("TIMEZONE")
    for node in post_order(tree, exp.ConvertTimezone):
        if node.args.get("source_tz") is not None:
            continue
        if tz.known:
            node.set("source_tz", string(str(tz.value)))
        else:
            rc.flag("SNW-SESSION-TZ", "2-argument CONVERT_TIMEZONE converts from the session time zone and TIMEZONE was "
                                      "not extracted: the Databricks session time zone applies instead", "1.26")
    for node in post_order(tree, exp.CurrentDate):
        if node.args.get("this") is not None:
            continue
        if tz.known:
            node.replace(tpl("CAST(CONVERT_TIMEZONE(__z__, CURRENT_TIMESTAMP()) AS DATE)", __z__=string(str(tz.value))))
        else:
            rc.flag("SNW-SESSION-TZ", "CURRENT_DATE depends on the session time zone and TIMEZONE was not extracted: "
                                      "the Databricks session time zone applies instead", "1.26")
    for node in post_order(tree, exp.CurrentTimestamp):
        if node.args.get("sysdate"):                                          # SYSDATE(): UTC wall clock, no time zone
            node.replace(tpl("CAST(CONVERT_TIMEZONE('UTC', CURRENT_TIMESTAMP()) AS TIMESTAMP_NTZ)"))


def _is_date(node: exp.Expression, cols: dict[int, ColInfo]) -> bool:
    inner = node
    while isinstance(inner, exp.Paren):
        inner = inner.this
    if isinstance(inner, exp.Cast):
        return inner.to.this == DType.DATE
    if isinstance(inner, exp.CurrentDate):
        return True
    if isinstance(inner, exp.Column):
        info = cols.get(id(inner))
        return bool(info and info.family == "date")
    return False


def rule_dateadd(tree: exp.Expression, rc: RuleContext) -> None:
    """DATEADD(day|week, n, <date>) is a DATE in Snowflake; Databricks ``dateadd(unit, n, d)`` returns a TIMESTAMP, so a
    value known to be a DATE goes through ``date_add`` (the DATE type is kept)."""
    cols = rc.columns_of(tree)
    for node in post_order(tree, exp.DateAdd):
        unit = canonical_part(node.args.get("unit"))
        if unit not in ("DAY", "WEEK") or node.this is None or node.expression is None or not _is_date(node.this, cols):
            continue
        n = node.expression
        days = tpl("CAST(__n__ AS INT)", __n__=n) if unit == "DAY" else tpl("CAST(__n__ AS INT) * 7", __n__=n)
        node.replace(tpl("DATE_ADD(__d__, __n__)", __d__=node.this, __n__=days))


RULES = (rule_date_parts, rule_datediff, rule_timestamp_types, rule_formats, rule_session_timezone, rule_dateadd)

__all__ = ["RULES", "canonical_part", "date_part_expr", "is_numeric_format", "number", "rule_date_parts", "rule_datediff",
           "rule_formats", "rule_session_timezone", "rule_timestamp_types", "rule_dateadd", "spark_pattern"]
