# Ported from SNF2DBX-main/converters/refactor.py (LatentView internal)
# ruff: noqa: E501
"""Deterministic Databricks-native refactoring of Snowflake Scripting, applied before emission.

R1 - row-by-row cursor loop -> one set-based statement.
     FOR rec IN <cursor> DO [v := rec.K;]* <one DML filtered by col = :v / rec.K> [acc := acc + SQLROWCOUNT;] END FOR
     becomes the same DML filtered by col IN (SELECT K FROM (<cursor>)) run once, and acc := acc + SQLROWCOUNT once.
     Applied only when every condition below holds; otherwise the loop is kept and the reason is reported:
       * the body is only key assignments, exactly one INSERT ... SELECT / UPDATE / DELETE / MERGE, and an optional
         row-count accumulation;
       * the loop key appears only in `col = key` conjuncts of that statement's WHERE (the read side);
       * the cursor returns each key once (DISTINCT, GROUP BY the key, or the key is a declared primary/unique key);
       * iterations touch disjoint rows: aggregation groups by the filtered column, there is no LIMIT / ORDER BY /
         QUALIFY / window function, a MERGE matches on that column, an UPDATE does not change it;
       * the written table is not read by the cursor or by the statement itself;
       * the key variables are not used anywhere else in the procedure.
     Under these conditions the set-based statement changes exactly the union of the rows the iterations changed, and
     its row count equals the sum of the per-iteration counts.

R2 (row counts from Delta commit metrics) and R3 (concurrency-safe run id instead of MAX(id)) are applied by the
emitter (converters/scripting.py) because they change how statements are written, not which statements run.
"""
from __future__ import annotations

import re

import sqlglot
from sqlglot import exp

from packs.snowflake.dml_shapes import DML

_BIND = re.compile(r"('(?:[^']|'')*')|(?<![:\w]):([A-Za-z_][\w$]*)")
_ACC = re.compile(r"^\s*([A-Za-z_][\w$]*)\s*\+\s*SQLROWCOUNT\s*$", re.I)


class Refused(ValueError):
    pass


def _texts(nodes) -> list[str]:
    from packs.snowflake.scripting_convert import Emitter
    return Emitter._texts(nodes)


def _hide_binds(sql: str) -> str:
    return _BIND.sub(lambda m: m.group(1) or f"__bind_{m.group(2)}", sql)


def _show_binds(sql: str) -> str:
    return re.sub(r"\b__bind_([A-Za-z_][\w$]*)", r":\1", sql)


def _parse(sql: str) -> exp.Expression:
    try:
        tree = sqlglot.parse_one(_hide_binds(sql), read="snowflake")
    except Exception as error:
        raise Refused(f"statement could not be analyzed ({str(error)[:80]})") from None
    if tree is None or isinstance(tree, exp.Command):
        raise Refused("statement could not be analyzed")
    return tree


def _tables(tree: exp.Expression) -> set[str]:
    return {".".join(part for part in (table.catalog, table.db, table.name) if part).upper()
            for table in tree.find_all(exp.Table) if isinstance(table.this, exp.Identifier)}


def _same_table(a: str, b: str) -> bool:
    return a.split(".")[-1] == b.split(".")[-1] and (a.count(".") < 1 or b.count(".") < 1 or a.split(".")[-2:] == b.split(".")[-2:])


def _conjuncts(where: exp.Expression) -> list[exp.Expression]:
    return list(where.flatten()) if isinstance(where, exp.And) else [where]


def _cursor_query(source: str, cursors: dict) -> str:
    text = source.strip()
    if re.match(r"^\(?\s*(SELECT|WITH)\b", text, re.I):
        return re.sub(r"^\(\s*|\s*\)$", "", text)
    query = cursors.get(text.upper())
    if not query:
        raise Refused(f"loop source {text} is not a declared cursor")
    return query


def _key_is_unique(cursor: exp.Expression, key: str, unique_keys: dict) -> str:
    if not isinstance(cursor, exp.Select):
        raise Refused("cursor is not a single SELECT")
    names = [projection.alias_or_name.upper() for projection in cursor.expressions]
    if key.upper() not in names:
        raise Refused(f"cursor does not select {key} by name")
    if cursor.args.get("distinct"):
        return "the cursor selects DISTINCT keys"
    group = cursor.args.get("group")
    if group and [g.sql().upper() for g in group.expressions] in ([key.upper()], [str(names.index(key.upper()) + 1)]):
        return f"the cursor groups by {key}"
    tables = list(cursor.find_all(exp.Table))
    if len(tables) == 1 and not cursor.args.get("joins"):
        table = ".".join(p for p in (tables[0].db, tables[0].name) if p).upper()
        for name, columns in unique_keys.items():
            if _same_table(name, table) and key.upper() in columns:
                return f"{key} is a primary/unique key of {tables[0].name}"
    raise Refused(f"the cursor may return the same {key} more than once (no DISTINCT, GROUP BY or declared key)")


def _read_query(tree: exp.Expression) -> exp.Expression | None:
    if isinstance(tree, exp.Merge):
        using = tree.args.get("using")
        return using.this if isinstance(using, exp.Subquery) else None
    if isinstance(tree, exp.Insert):
        return tree.expression if isinstance(tree.expression, exp.Select) else None
    if isinstance(tree, (exp.Update, exp.Delete)):
        return tree
    return None


def _check_grouping(select: exp.Expression, column: exp.Column):
    if not isinstance(select, exp.Select):
        return
    for part in ("limit", "order", "qualify"):
        if select.args.get(part):
            raise Refused(f"the statement uses {part.upper()}, which depends on all rows at once")
    if any(select.find_all(exp.Window)):
        raise Refused("the statement uses a window function over rows of several iterations")
    group = select.args.get("group")
    aggregated = group is not None or select.args.get("distinct") or any(
        isinstance(node, exp.AggFunc) for projection in select.expressions for node in projection.walk())
    if not aggregated:
        return
    projections = [p.unalias() if isinstance(p, exp.Alias) else p for p in select.expressions]
    keys = []
    for item in (group.expressions if group else []):
        if isinstance(item, exp.Literal) and item.is_int and 0 < int(item.this) <= len(projections):
            item = projections[int(item.this) - 1]
        keys.append(item.sql().upper())
    if column.sql().upper() not in keys and column.name.upper() not in [k.split(".")[-1] for k in keys]:
        raise Refused(f"the statement aggregates without grouping by {column.name}, so iterations would be merged")


def rewrite_loop(node, cursors: dict, unique_keys: dict, used_elsewhere) -> tuple[list, str]:
    """(replacement nodes, changelog line) for a for_cursor node, or raise Refused with the reason."""
    from packs.snowflake.scripting_convert import Node
    rec = node.a["var"]
    aliases, dml, acc = {}, None, None
    for item in node.a["body"]:
        if item.kind == "assign":
            field = re.fullmatch(rf"\s*{re.escape(rec)}\.([A-Za-z_][\w$]*)\s*", item.a["value"], re.I)
            total = _ACC.match(item.a["value"])
            if field:
                aliases[item.a["name"].upper()] = field.group(1)
                continue
            if total and total.group(1).upper() == item.a["name"].upper() and acc is None:
                acc = item
                continue
            raise Refused(f"the loop body assigns {item.a['name']} from something other than the cursor row")
        if item.kind == "sql" and DML.match(item.a["sql"]) and dml is None:
            dml = item
            continue
        if item.kind == "noop":
            continue
        raise Refused(f"the loop body has a {item.kind.upper()} statement besides its one write")
    if dml is None:
        raise Refused("the loop body has no INSERT / UPDATE / DELETE / MERGE")
    for variable in aliases:
        if used_elsewhere(variable):
            raise Refused(f"{variable} is used outside the loop, where it would hold the last key")
    if acc is not None and not re.search(r"\bSQLROWCOUNT\b", acc.a["value"], re.I):
        raise Refused("row-count accumulation not recognized")
    cursor_sql = _cursor_query(node.a["source"], cursors)
    cursor = _parse(cursor_sql)
    text = dml.a["sql"]
    for variable, field in aliases.items():
        text = re.sub(rf"(?<![\w$.]):{re.escape(variable)}\b", f"__loopkey_{field}", text, flags=re.I)
    text = re.sub(rf"(?<![\w$.]){re.escape(rec)}\.([A-Za-z_][\w$]*)\b", r"__loopkey_\1", text, flags=re.I)
    if re.search(rf"(?<![\w$.]):?(?:{'|'.join(map(re.escape, aliases)) or '(?!)'})\b", text, re.I):
        raise Refused("the key variable is used without a colon bind or outside a filter")
    tree = _parse(text)
    keys = {column.name[len("__loopkey_"):].upper() for column in tree.find_all(exp.Column)
            if column.name.lower().startswith("__loopkey_")}
    if len(keys) != 1:
        raise Refused("the statement must be filtered by exactly one cursor column" if keys else
                      "the statement does not use the cursor row, so every iteration repeats the same work")
    key = keys.pop()
    proof = [_key_is_unique(cursor, key, unique_keys)]
    target = tree.this if isinstance(tree, (exp.Merge, exp.Insert, exp.Update, exp.Delete)) else None
    while target is not None and not isinstance(target, exp.Table):
        target = target.this if isinstance(target, exp.Expression) else None
    if target is None:
        raise Refused("the written table could not be read")
    written = ".".join(p for p in (target.db, target.name) if p).upper()
    if any(_same_table(written, name) for name in _tables(cursor)):
        raise Refused(f"the cursor reads {target.name}, which the loop writes")
    read = _read_query(tree)
    if read is None:
        raise Refused("only INSERT ... SELECT, UPDATE, DELETE and MERGE USING (subquery) are rewritten")
    if not isinstance(tree, (exp.Update, exp.Delete)) and any(_same_table(written, name) for name in _tables(read)):
        raise Refused(f"the statement reads {target.name} while writing it")
    where = read.args.get("where")
    replacements = []
    for column in [c for c in tree.find_all(exp.Column) if c.name.lower().startswith("__loopkey_")]:
        eq = column.parent
        if not isinstance(eq, exp.EQ) or where is None:
            raise Refused("the cursor key is used outside a `column = key` filter")
        holder = eq.parent
        while isinstance(holder, (exp.And, exp.Paren)):
            holder = holder.parent
        if holder is not where:
            raise Refused("the cursor key filter is not a top-level AND condition of the WHERE clause")
        other = eq.left if eq.right is column else eq.right
        if not isinstance(other, exp.Column) or other.name.lower().startswith("__loopkey_"):
            raise Refused("the cursor key is compared with an expression, not a column")
        replacements.append((eq, other))
    filtered = replacements[0][1]
    _check_grouping(read if isinstance(read, exp.Select) else exp.Select(), filtered)
    if isinstance(tree, exp.Merge):
        projections = {(p.alias_or_name.upper(), (p.unalias() if isinstance(p, exp.Alias) else p).sql().upper())
                       for p in read.expressions}
        out_names = {alias for alias, source in projections if source.split(".")[-1] == filtered.name.upper()}
        source_alias = (tree.args["using"].alias or "").upper()
        on = tree.args.get("on")
        matched = False
        for condition in _conjuncts(on) if on is not None else []:
            if isinstance(condition, exp.EQ):
                for side in (condition.left, condition.right):
                    if isinstance(side, exp.Column) and side.name.upper() in out_names and (
                            not side.table or side.table.upper() == source_alias):
                        matched = True
        if not matched:
            raise Refused(f"the MERGE does not match on {filtered.name}, so iterations could update the same row")
        proof.append(f"the MERGE matches on {filtered.name}, so each iteration updates its own rows")
    if isinstance(tree, exp.Update):
        changed = {e.this.name.upper() for e in tree.expressions if isinstance(e, exp.EQ) and isinstance(e.this, exp.Column)}
        if filtered.name.upper() in changed:
            raise Refused(f"the UPDATE changes {filtered.name}, the column the loop filters on")
    keys_sql = f"(SELECT {key} FROM ({_hide_binds(cursor_sql)}) AS loop_keys_)"
    for eq, other in replacements:
        eq.replace(sqlglot.parse_one(f"{other.sql(dialect='snowflake')} IN {keys_sql}", read="snowflake"))
    new_sql = _show_binds(tree.sql(dialect="snowflake"))
    out = [Node("sql", dml.line, {"sql": new_sql})]
    if acc is not None:
        out.append(Node("assign", acc.line, {"name": acc.a["name"], "value": acc.a["value"]}))
    kind = type(tree).__name__.upper()
    note = (f"REF001|Row-by-row loop over {node.a['source'].strip()[:60]} replaced by one set-based {kind} filtered by "
            f"{filtered.name} IN (cursor query). Safe because " + "; ".join(proof)
            + "; the loop body had exactly one write and its key variables are not used elsewhere")
    return out, note


def apply(block, unique_keys: dict | None = None, record: list | None = None) -> list[str]:
    """Rewrite every provably safe cursor loop in place. Returns notes (REF001 applied / INFO not applied).
    `record` (optional) receives {'original': loop DML, 'rewritten': set-based DML} per rewrite, for validation."""
    unique_keys = {name.upper(): {c.upper() for c in cols} for name, cols in (unique_keys or {}).items()}
    cursors, notes = {}, []

    def collect(b):
        for decl in b.decls:
            if decl.kind == "cursor":
                cursors[decl.a["name"].upper()] = decl.a["query"]
        for item in _walk_nodes(b):
            if item.kind == "block":
                collect(item.a["block"])
    collect(block)

    def text_without(loop) -> str:
        """Everything the procedure runs except this loop (declarations count only through their default values)."""
        saved, loop.a = loop.a, {}
        try:
            parts = _texts(block.stmts + [n for _, stmts in block.handlers for n in stmts])
            parts += [decl.a.get("value") or decl.a.get("query") or "" for decl in block.decls]
            return " ".join(part for part in parts if part)
        finally:
            loop.a = saved

    def rewrite(nodes: list) -> list:
        out = []
        for item in nodes:
            for key in ("body", "else"):
                if isinstance(item.a.get(key), list):
                    item.a[key] = rewrite(item.a[key])
            if isinstance(item.a.get("branches"), list):
                item.a["branches"] = [(cond, rewrite(body)) for cond, body in item.a["branches"]]
            if isinstance(item.a.get("whens"), list):
                item.a["whens"] = [(value, rewrite(body)) for value, body in item.a["whens"]]
            if item.kind == "block":
                inner = item.a["block"]
                inner.stmts = rewrite(inner.stmts)
            if item.kind == "for_cursor":
                outside = text_without(item)

                def used_elsewhere(variable, outside=outside):
                    return bool(re.search(rf"(?<![\w$.]):?{re.escape(variable)}\b", outside, re.I))
                try:
                    replacement, note = rewrite_loop(item, cursors, unique_keys, used_elsewhere)
                    out += replacement
                    notes.append(note)
                    if record is not None:
                        original = next(n.a["sql"] for n in item.a["body"] if n.kind == "sql")
                        record.append({"original": original, "rewritten": replacement[0].a["sql"]})
                    continue
                except Refused as reason:
                    notes.append(f"INFO|Row-by-row loop over {item.a['source'].strip()[:60]} kept as a loop: {reason}")
            out.append(item)
        return out

    block.stmts = rewrite(block.stmts)
    block.handlers = [(names, rewrite(stmts)) for names, stmts in block.handlers]
    return notes


def _walk_nodes(block):
    stack = list(block.stmts)
    while stack:
        item = stack.pop()
        yield item
        for key in ("body", "else"):
            if isinstance(item.a.get(key), list):
                stack += item.a[key]
        for key in ("branches", "whens"):
            for _, body in item.a.get(key) or []:
                stack += body
