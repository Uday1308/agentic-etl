# Ported from SNF2DBX-main/converters/python_proc.py (LatentView internal), adapted to the pack: the NameMapper and the
# SNF2DBX ``transpile`` became ``CodeServices`` (table map, tier 0 for every inner statement, residue guard); a callee
# that is a SQL procedure with a scalar RETURNS is read through its ``__ret`` twin's one-row result; evidence and notes
# never quote source text.
"""packs.snowflake.python_convert - Snowpark Python procedures -> PySpark notebooks; Python UDFs -> Unity Catalog UDFs.

Deterministic ``ast`` rewrites only (catalogue rows 5.12, 6.12). Anything without an exact rule raises ``CodeRefused``
with the line, which routes the object to the AI tier (or to a human) instead of guessing. The Snowpark API names that
differ from PySpark are renamed, the session becomes ``spark``, every literal SQL string goes through tier 0, table
names go through the batch's table map, ``save_as_table`` / ``write_pandas`` become ``saveAsTable`` writes.
"""
from __future__ import annotations

import ast
import json
import re

from packs.snowflake.code_common import CodeNames, CodeObject, CodeRefused, CodeServices, caster

# snowflake.snowpark.functions names that are identical in pyspark.sql.functions
SAME_FUNCTIONS = set('''abs acos asin atan atan2 avg ceil coalesce col column concat concat_ws contains cos count
count_distinct current_date current_timestamp date_format dayofmonth dayofweek dayofyear dense_rank desc asc exp explode
first_value floor greatest hash hour initcap lag last_value lead least length lit ln log lower lpad ltrim max md5 mean min
minute month ntile percent_rank pow quarter rank regexp_replace repeat replace round row_number rpad rtrim second sha1
sha2 sign sin sqrt startswith endswith stddev stddev_pop stddev_samp substring sum sum_distinct tan to_date
to_timestamp translate trim trunc upper var_pop var_samp variance weekofyear when year cume_dist split array_contains
collect_list collect_set expr monotonically_increasing_id isnull'''.split())
RENAMED_FUNCTIONS = {'array_agg': 'collect_list', 'call_builtin': 'call_function', 'sql_expr': 'expr', 'random': 'rand',
                     'array_size': 'size', 'to_char': 'date_format', 'is_null': 'isnull', 'charindex': 'locate'}
SAME_TYPES = set('''StringType IntegerType LongType ShortType ByteType DoubleType FloatType BooleanType DateType
TimestampType DecimalType StructType StructField ArrayType MapType BinaryType NullType'''.split())
SESSION_SAME = {'sql', 'table', 'range'}
SESSION_RENAMED = {'create_dataframe': 'createDataFrame'}
METHOD_RENAMES = {'with_column': 'withColumn', 'with_columns': 'withColumns', 'with_column_renamed': 'withColumnRenamed',
                  'group_by': 'groupBy', 'order_by': 'orderBy', 'sort_by': 'sort', 'drop_duplicates': 'dropDuplicates',
                  'union_all_by_name': 'unionByName', 'union_by_name': 'unionByName', 'union_all': 'unionAll',
                  'to_pandas': 'toPandas', 'select_expr': 'selectExpr', 'cross_join': 'crossJoin', 'to_df': 'toDF',
                  'is_null': 'isNull', 'is_not_null': 'isNotNull', 'in_': 'isin', 'equal_null': 'eqNullSafe',
                  'partition_by': 'partitionBy', 'rows_between': 'rowsBetween', 'range_between': 'rangeBetween',
                  'random_split': 'randomSplit', 'na_fill': 'fillna', 'fillna': 'fillna', 'dropna': 'dropna',
                  'cache_result': 'cache', 'create_or_replace_temp_view': 'createOrReplaceTempView'}
WINDOW_CONSTANTS = {'UNBOUNDED_PRECEDING': 'unboundedPreceding', 'UNBOUNDED_FOLLOWING': 'unboundedFollowing',
                    'CURRENT_ROW': 'currentRow'}
SNOWPARK_ONLY_METHODS = {'copy_into_table', 'join_table_function', 'create_or_replace_view',
                         'create_or_replace_dynamic_table', 'to_local_iterator', 'save_as_table_async', 'collect_nowait',
                         'add_import', 'add_packages', 'add_requirements'}
TABLE_ONLY_METHODS = {'update', 'delete', 'merge'}  # snowpark Table DML; dict.update etc. are left alone
SESSION_DROPPED = {'use_warehouse', 'query_tag'}
PREINSTALLED = {'pandas', 'numpy', 'scipy', 'scikit-learn', 'requests', 'pyarrow', 'python-dateutil', 'pytz', 'six'}
_SQL_STATEMENT = re.compile(r'\s*(SELECT|WITH|INSERT|UPDATE|DELETE|MERGE|CREATE|CALL)\b', re.I)


def _literal(node):
    return node.value if isinstance(node, ast.Constant) and isinstance(node.value, str) else None


def _split_fqn(name: str) -> list[str]:
    return re.findall(r'"(?:[^"]|"")*"|[^.\s]+', name)


def _table_name(node, names: CodeNames, where: str) -> str:
    if isinstance(node, (ast.List, ast.Tuple)) and all(_literal(item) for item in node.elts):
        parts = [_literal(item) for item in node.elts]
    elif _literal(node) is not None:
        parts = _split_fqn(_literal(node))
    else:
        raise CodeRefused(f'{where}: table name is computed at run time, so it cannot be mapped to a Unity Catalog name')
    return names.table(parts, where)


class _Rewriter(ast.NodeTransformer):
    def __init__(self, svc: CodeServices, session_names):
        self.svc, self.names = svc, svc.names
        self.sessions = set(session_names)
        self.notes, self.removed, self.function_aliases, self.window_names, self.tables = [], set(), set(), set(), set()
        self.need_when = False

    def fail(self, node, message):
        raise CodeRefused(f'line {getattr(node, "lineno", "?")}: {message}')

    def _convert_sql(self, text, where):
        try:
            return self.svc.statement(text)
        except CodeRefused as error:
            raise CodeRefused(f'{where}: SQL could not be converted: {error}') from None

    # ---- imports
    def visit_Import(self, node):
        kept = []
        for alias in node.names:
            name = alias.name
            if name == '_snowflake' or name.startswith('_snowflake.'):
                self.fail(node, '_snowflake (secrets, vectorized APIs) has no Databricks equivalent here: move the '
                                'secret to a Databricks secret scope by hand')
            if name == 'snowflake.snowpark.functions':
                kept.append(ast.alias('pyspark.sql.functions', alias.asname))
                self.function_aliases.add(alias.asname or name)
            elif name == 'snowflake.snowpark.types':
                kept.append(ast.alias('pyspark.sql.types', alias.asname))
            elif name.startswith('snowflake'):
                self.removed.add((alias.asname or name).split('.')[0])
            else:
                kept.append(alias)
        if not kept:
            return None
        node.names = kept
        return node

    def visit_ImportFrom(self, node):
        module = node.module or ''
        if module == '_snowflake':
            self.fail(node, '_snowflake (secrets, vectorized APIs) has no Databricks equivalent here: move the secret '
                            'to a Databricks secret scope by hand')
        if module == 'snowflake.snowpark.functions':
            names = []
            for alias in node.names:
                name = RENAMED_FUNCTIONS.get(alias.name, alias.name)
                if alias.name == 'iff':
                    self.need_when = True
                    self.removed.add(alias.asname or 'iff')
                    continue
                if name not in SAME_FUNCTIONS and alias.name not in RENAMED_FUNCTIONS:
                    self.fail(node, f'snowflake.snowpark.functions.{alias.name} has no exact PySpark rule')
                names.append(ast.alias(name, alias.asname or (alias.name if name != alias.name else None)))
            if self.need_when and not any(item.name == 'when' for item in names):
                names.append(ast.alias('when'))
            node.module, node.names = 'pyspark.sql.functions', names
            return node
        if module == 'snowflake.snowpark.types':
            for alias in node.names:
                if alias.name not in SAME_TYPES:
                    self.fail(node, f'snowflake.snowpark.types.{alias.name} has no PySpark type rule (VARIANT / '
                                    'GEOGRAPHY need manual mapping)')
            node.module = 'pyspark.sql.types'
            return node
        if module == 'snowflake.snowpark.exceptions':
            node.module = 'pyspark.errors'
            node.names = [ast.alias('PySparkException', alias.asname or alias.name) for alias in node.names]
            return node
        if module in ('snowflake.snowpark', 'snowflake'):
            kept = []
            for alias in node.names:
                local = alias.asname or alias.name
                if alias.name == 'functions':
                    kept.append(('pyspark.sql', ast.alias('functions', alias.asname)))
                    self.function_aliases.add(local)
                elif alias.name == 'types':
                    kept.append(('pyspark.sql', ast.alias('types', alias.asname)))
                elif alias.name in ('Window', 'Row', 'DataFrame', 'Column'):
                    kept.append(('pyspark.sql', ast.alias(alias.name, alias.asname)))
                    if alias.name == 'Window':
                        self.window_names.add(local)
                else:  # Session, the snowpark module itself, etc. are only used for typing
                    self.removed.add(local)
            if not kept:
                return None
            return ast.ImportFrom(module='pyspark.sql', names=[item for _, item in kept], level=0)
        if module.startswith('snowflake'):
            self.fail(node, f'{module} has no Databricks equivalent rule')
        return node

    # ---- annotations referencing removed Snowpark names would fail at definition time
    def _mentions_removed(self, node):
        return node is not None and any(isinstance(item, ast.Name) and item.id in self.removed for item in ast.walk(node))

    def visit_FunctionDef(self, node):
        for arg in node.args.args + node.args.kwonlyargs + node.args.posonlyargs:
            if self._mentions_removed(arg.annotation):
                arg.annotation = None
        if self._mentions_removed(node.returns):
            node.returns = None
        for decorator in node.decorator_list:
            text = ast.unparse(decorator)
            if 'vectorized' in text or 'udf' in text or 'sproc' in text:
                self.fail(decorator, 'Snowpark decorators (udf / sproc / vectorized) need manual conversion')
        self.generic_visit(node)
        return node

    def visit_AnnAssign(self, node):
        self.generic_visit(node)
        if self._mentions_removed(node.annotation):
            return ast.Assign(targets=[node.target], value=node.value, lineno=node.lineno) if node.value else None
        return node

    # ---- names and attributes
    def visit_Attribute(self, node):
        self.generic_visit(node)
        if isinstance(node.value, ast.Name) and node.value.id in self.window_names and node.attr in WINDOW_CONSTANTS:
            node.attr = WINDOW_CONSTANTS[node.attr]
        elif isinstance(node.value, ast.Name) and node.value.id in self.function_aliases:
            if node.attr == 'iff':
                return node
            name = RENAMED_FUNCTIONS.get(node.attr, node.attr)
            if name not in SAME_FUNCTIONS and node.attr not in RENAMED_FUNCTIONS:
                self.fail(node, f'functions.{node.attr} has no exact PySpark rule')
            node.attr = name
        return node

    def visit_Name(self, node):
        if node.id in self.removed and isinstance(node.ctx, ast.Load) and node.id != 'iff':
            self.fail(node, f'{node.id} (Snowpark) is used outside type annotations')
        return node

    def _is_table(self, node):
        if isinstance(node, ast.Name):
            return node.id in self.tables
        return (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'table'
                and isinstance(node.func.value, ast.Name) and node.func.value.id in self.sessions | {'spark'})

    def visit_Assign(self, node):
        value = node.value
        if (isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute) and value.func.attr == 'table'
                and isinstance(value.func.value, ast.Name) and value.func.value.id in self.sessions):
            self.tables |= {target.id for target in node.targets if isinstance(target, ast.Name)}
        self.generic_visit(node)
        return node

    # ---- calls
    def visit_Call(self, node):
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr in TABLE_ONLY_METHODS and self._is_table(func.value):
            self.fail(node, f'Table.{func.attr}() (Snowpark DML) has no exact rule; use a Delta MERGE / UPDATE / DELETE '
                            'statement')
        # iff(c, a, b) -> when(c, a).otherwise(b)
        if (isinstance(func, ast.Name) and func.id == 'iff') or (
                isinstance(func, ast.Attribute) and func.attr == 'iff' and isinstance(func.value, ast.Name)
                and func.value.id in self.function_aliases):
            if len(node.args) != 3:
                self.fail(node, 'iff needs exactly three arguments')
            self.generic_visit(node)
            when = ast.Name('when', ast.Load()) if isinstance(func, ast.Name) else ast.Attribute(func.value, 'when', ast.Load())
            return ast.Call(ast.Attribute(ast.Call(when, node.args[:2], []), 'otherwise', ast.Load()), [node.args[2]], [])
        if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name) and func.value.id in self.sessions:
            return self.session_call(node)
        self.generic_visit(node)
        func = node.func
        if isinstance(func, ast.Attribute):
            if func.attr == 'save_as_table':
                return self.save_as_table(node)
            if func.attr in SNOWPARK_ONLY_METHODS:
                self.fail(node, f'.{func.attr}() is Snowpark-specific and has no exact rule')
            if func.attr == 'cache_result':
                self.notes.append('SEM004|cache_result() became cache(): Spark caching is lazy and session-scoped, not a '
                                  'temporary table')
            if func.attr in METHOD_RENAMES:
                func.attr = METHOD_RENAMES[func.attr]
        return node

    def session_call(self, node):
        method = node.func.attr
        where = f'line {node.lineno}: session.{method}'
        for index, arg in enumerate(node.args):
            node.args[index] = self.visit(arg)
        for keyword in node.keywords:
            keyword.value = self.visit(keyword.value)
        if method == 'sql':
            if not node.args:
                self.fail(node, 'session.sql() without a query')
            text = _literal(node.args[0])
            if text is None:
                self.notes.append(f'SEM004|{where} builds SQL at run time; the text is passed unchanged and must already '
                                  'be Databricks SQL')
            else:
                node.args[0] = ast.Constant(self._convert_sql(text, where))
            for keyword in node.keywords:
                if keyword.arg == 'params':
                    keyword.arg = 'args'
            return node
        if method == 'table':
            if not node.args:
                self.fail(node, 'session.table() without a name')
            node.args = [ast.Constant(_table_name(node.args[0], self.names, where))] + node.args[1:]
            return node
        if method in SESSION_RENAMED:
            node.func.attr = SESSION_RENAMED[method]
            return node
        if method in SESSION_SAME:
            return node
        if method == 'call':
            return self.call_procedure(node, where)
        if method == 'write_pandas':
            return self.write_pandas(node, where)
        if method in SESSION_DROPPED:
            self.notes.append(f'INFO|{where} removed: Databricks compute is chosen by the job, not by the procedure')
            return ast.Constant(None)
        self.fail(node, f'session.{method}() has no Databricks rule')

    def call_procedure(self, node, where):
        name = _literal(node.args[0]) if node.args else None
        if name is None:
            self.fail(node, 'session.call() with a computed procedure name')
        fqn, target = self.names.routine(_split_fqn(name))
        markers = ', '.join('?' for _ in node.args[1:])
        call = ast.Call(ast.Attribute(ast.Name(node.func.value.id, ast.Load()), 'sql', ast.Load()),
                        [ast.Constant(f'CALL {target}({markers})')],
                        [ast.keyword('args', ast.List(list(node.args[1:]), ast.Load()))] if node.args[1:] else [])
        if fqn in self.svc.procedures:
            # CALL target(...) of a converted SQL procedure ends with SELECT return_value AS return_value: read it back
            return ast.Subscript(ast.Subscript(ast.Call(ast.Attribute(call, 'collect', ast.Load()), [], []),
                                               ast.Constant(0), ast.Load()), ast.Constant(0), ast.Load())
        self.notes.append(f'SEM004|{where} became spark.sql("CALL ..."); the callee is outside this conversion, so its '
                          'return value is not read')
        return call

    def write_pandas(self, node, where):
        if len(node.args) < 2:
            self.fail(node, 'write_pandas needs a DataFrame and a literal table name')
        options = {keyword.arg: keyword.value for keyword in node.keywords}
        parts = [_literal(options[key]) for key in ('database', 'schema') if key in options]
        name = _literal(node.args[1])
        if name is None or any(part is None for part in parts):
            self.fail(node, 'write_pandas with computed table names cannot be mapped')
        target = _table_name(ast.Constant('.'.join(parts + [name])), self.names, where)
        overwrite = options.get('overwrite')
        mode = 'overwrite' if isinstance(overwrite, ast.Constant) and overwrite.value is True else 'append'
        if overwrite is not None and not isinstance(overwrite, ast.Constant):
            self.fail(node, 'write_pandas overwrite flag is computed at run time')
        frame = ast.Call(ast.Attribute(ast.Name(node.func.value.id, ast.Load()), 'createDataFrame', ast.Load()),
                         [node.args[0]], [])
        writer = ast.Call(ast.Attribute(ast.Attribute(frame, 'write', ast.Load()), 'mode', ast.Load()),
                          [ast.Constant(mode)], [])
        return ast.Call(ast.Attribute(writer, 'saveAsTable', ast.Load()), [ast.Constant(target)], [])

    def save_as_table(self, node):
        where = f'line {node.lineno}: save_as_table'
        if not node.args:
            self.fail(node, 'save_as_table without a table name')
        target = _table_name(node.args[0], self.names, where)
        writer = node.func.value
        for keyword in node.keywords:
            if keyword.arg == 'mode':
                writer = ast.Call(ast.Attribute(writer, 'mode', ast.Load()), [keyword.value], [])
            elif keyword.arg in ('table_type', 'column_order', 'create_temp_table', 'statement_params', 'block'):
                if keyword.arg == 'table_type' and _literal(keyword.value) in ('temp', 'temporary', 'transient'):
                    self.notes.append(f'SEM004|{where}: a {_literal(keyword.value)} table became a Delta table; drop it '
                                      'when no longer needed')
                continue
            else:
                self.fail(node, f'save_as_table({keyword.arg}=...) has no rule')
        return ast.Call(ast.Attribute(writer, 'saveAsTable', ast.Load()), [ast.Constant(target)], [])


def _parse(body: str):
    try:
        return ast.parse(body)
    except SyntaxError as error:
        raise CodeRefused(f'Python syntax error at line {error.lineno}: {error.msg}') from None


def _rewrite(body: str, svc: CodeServices, session_names):
    tree = _parse(body)
    rewriter = _Rewriter(svc, session_names)
    tree = ast.fix_missing_locations(rewriter.visit(tree))
    code = ast.unparse(tree)
    for node in ast.walk(tree):                       # SQL text that was not run through tier 0 (built, or not a literal)
        text = _literal(node)
        if text and _SQL_STATEMENT.match(text):
            left = svc.residue(text)
            if left:
                raise CodeRefused(f'line {getattr(node, "lineno", "?")}: SQL text still contains Snowflake-only '
                                  'constructs: ' + ', '.join(left))
    return tree, code, rewriter.notes


def _handler(tree, name):
    if not name:
        raise CodeRefused('HANDLER is missing (the definition carries the code without its HANDLER)')
    if '.' in name:
        raise CodeRefused(f'HANDLER {name} refers to a staged module; only inline handlers are converted')
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
        if isinstance(node, ast.ClassDef) and node.name == name:
            raise CodeRefused(f'HANDLER {name} is a class (UDTF); Python table functions need manual conversion')
    raise CodeRefused(f'HANDLER {name} is not defined in the inline code')


def _packages(packages):
    names = []
    for item in packages:
        name = re.split(r'[=<>!~ ]', item.strip(), 1)[0].lower()
        if name and name not in ('snowflake-snowpark-python', 'snowflake-connector-python'):
            names.append(item.strip())
    return names


def convert_python_procedure(obj: CodeObject, svc: CodeServices, notebook: str) -> tuple[str, list[str]]:
    """``(notebook source, notes)``; raises ``CodeRefused`` with a precise reason. Notes are ``CODE|text``."""
    if obj.imports:
        raise CodeRefused('IMPORTS from stages are not converted; inline the code or upload the files to a Databricks '
                          'volume')
    if obj.external_access:
        raise CodeRefused('EXTERNAL_ACCESS_INTEGRATIONS / SECRETS have no rule: recreate them as a Unity Catalog '
                          'connection and a secret scope by hand')
    tree = _parse(obj.body)
    handler = _handler(tree, obj.handler)
    if not handler.args.args:
        raise CodeRefused(f'HANDLER {handler.name} must take the Snowpark session as its first argument')
    session = handler.args.args[0].arg
    args = obj.args
    if len(handler.args.args) - 1 != len(args):
        raise CodeRefused(f'HANDLER {handler.name} takes {len(handler.args.args) - 1} arguments but the procedure '
                          f'declares {len(args)}')
    tree, code, notes = _rewrite(obj.body, svc, {session, 'session'})
    notes = list(notes) + [
        'SEM004|Notebook runs with the job principal, not Snowflake owner/caller rights; review access before deployment',
        'SEM004|Snowflake returns unquoted column names in upper case; check row["NAME"] lookups against the Databricks '
        'column case']
    packages = _packages(obj.packages)
    extra = [item for item in packages if re.split(r'[=<>!~ ]', item, 1)[0].lower() not in PREINSTALLED]
    lines = ['# Databricks notebook source', notebook, '']
    if extra:
        # %pip restarts Python, so it must be the first cell on its own.
        lines += ['# MAGIC %pip install ' + ' '.join(json.dumps(item) for item in extra), '', '# COMMAND ----------', '']
        notes.append('SETUP001|Notebook installs Python packages with %pip: ' + ', '.join(extra))
    lines += ['import datetime', 'import json', '',
              'def _bool(value):', '    return value.strip().lower() in ("true", "1", "yes")', '',
              'def _arg(name, cast):', '    value = dbutils.widgets.get(name)', '    return None if value == "" else cast(value)', '']
    for arg in args:
        default = arg.get('default') or ''
        default = default[1:-1].replace("''", "'") if default.startswith("'") and default.endswith("'") else default
        lines.append(f'dbutils.widgets.text({json.dumps(arg["name"])}, {json.dumps(default)})')
    lines += ['', '# COMMAND ----------', '', code, '', '# COMMAND ----------', '']
    call_args = ', '.join(['spark'] + [f'_arg({json.dumps(arg["name"])}, {caster(arg["type"])})' for arg in args])
    lines.append(f'_result = {handler.name}({call_args})')
    if obj.returns.upper().startswith('TABLE'):
        lines.append('dbutils.notebook.exit(json.dumps([row.asDict() for row in _result.limit(10000).collect()], '
                     'default=str))')
        notes.append('SEM004|RETURNS TABLE: the notebook exits with up to 10,000 rows as JSON; write large results to a '
                     'table instead')
    else:
        lines.append('dbutils.notebook.exit("" if _result is None else _result if isinstance(_result, str) else '
                     'json.dumps(_result, default=str))')
        notes.append('SEM004|Return value is the notebook exit string (dbutils.notebook.run returns it to callers)')
    if obj.runtime_version:
        notes.append(f'INFO|Snowflake Python {obj.runtime_version}; Databricks runtimes use Python 3.10+ - check '
                     'version-specific code')
    return '\n'.join(lines) + '\n', notes


def convert_python_udf(obj: CodeObject, target: str, args_sql: str, returns_sql: str) -> tuple[str, list[str]]:
    """``(CREATE FUNCTION ... LANGUAGE PYTHON, notes)``; raises ``CodeRefused``."""
    if obj.imports:
        raise CodeRefused('IMPORTS from stages are not converted; inline the code')
    if obj.table_function:
        raise CodeRefused('Python table functions (UDTF handler classes) need manual conversion')
    if obj.external_access:
        raise CodeRefused('EXTERNAL_ACCESS_INTEGRATIONS / SECRETS have no rule: a Unity Catalog Python UDF has neither')
    body = obj.body
    tree = _parse(body)
    handler = _handler(tree, obj.handler)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            module = node.module if isinstance(node, ast.ImportFrom) else node.names[0].name
            if (module or '').split('.')[0] in ('_snowflake', 'snowflake'):
                raise CodeRefused(f'line {node.lineno}: {module} is not available in Databricks Python UDFs')
    for decorator in handler.decorator_list:
        raise CodeRefused(f'line {decorator.lineno}: decorated handlers (vectorized UDFs) need manual conversion')
    names = [arg['name'] for arg in obj.args]
    if any(not name.isidentifier() for name in names):
        raise CodeRefused('argument names must be valid Python identifiers')
    if len(handler.args.args) != len(names):
        raise CodeRefused(f'HANDLER {handler.name} takes {len(handler.args.args)} arguments but the function declares '
                          f'{len(names)}')
    if '$$' in body:
        raise CodeRefused('function body contains $$')
    notes, tail = [], []
    if obj.strict and names:
        tail.append('if ' + ' or '.join(f'{name} is None' for name in names) + ':\n    return None')
    tail.append(f'return {handler.name}({", ".join(names)})')
    environment = ''
    packages = _packages(obj.packages)
    if packages:
        environment = f"\nENVIRONMENT (dependencies = '{json.dumps(packages)}', environment_version = 'None')"
        notes.append('SETUP001|Python UDF dependencies use ENVIRONMENT (Databricks SQL / serverless or DBR 16.2+): '
                     + ', '.join(packages))
    code = (f'CREATE OR REPLACE FUNCTION {target}({args_sql})\nRETURNS {returns_sql}\nLANGUAGE PYTHON{environment}\n'
            f'AS $$\n{body.rstrip()}\n\n' + '\n'.join(tail) + '\n$$')
    notes.append('SETUP001|Unity Catalog Python UDFs require Databricks SQL (pro / serverless) or DBR 13.3+ with Unity '
                 'Catalog')
    if obj.runtime_version:
        notes.append(f'INFO|Snowflake Python {obj.runtime_version}; Databricks runs the UDF on its own Python version')
    return code, notes


__all__ = ["CodeRefused", "convert_python_procedure", "convert_python_udf"]
