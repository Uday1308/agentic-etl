"""packs.snowflake.run - one Snowflake ETL through the pack (ADR 032 sections 2-5, P3-09 / P3-10).

``run_etl`` is what ``core.runner.run_pipeline`` calls for this pack. Steps (each appended to ``completed``):

    routing        engine -> translate | file_load | statement | unsupported (checked BEFORE the definition)
    standardization  unit document -> SQL node(s) -> the folded planner dataflow (shape check)
    translation    tier 0 per unit, the chain for the rest (``translate.translate_etl``), the ``translation`` gate
    cd_codegen     the handler's artifacts, validated per kind, stored by hash, the ``cd_codegen`` (sql) gate

The review rule decides every gate (``HarnessGates``): ``ai`` / ``transpiled`` / ``manual`` units and ``review``
caveats leave their gates open and the ETL ends ``awaiting_review``. The persisted record and the gate payloads hold
``artifact_ref`` + ``sha256`` + a masked preview, never SQL text.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import inspect
import pathlib
import uuid
from dataclasses import dataclass, field
from typing import Any

from agents.cd_codegen.translate.artifacts import ArtifactError, read_artifact, write_artifact
from agents.cd_codegen.translate.chain import TranslationSettings
from agents.cd_codegen.translate.twophase import TierOneReport
from core.contracts.standardized import StandardizedSchemaError, to_planner_dataflow
from core.packs import Collaborators
from core.runner import GateDecision, HarnessGates, RunRecord
from packs.snowflake import contract as ct
from packs.snowflake import translate as tr
from packs.snowflake import units as _units
from packs.snowflake.assembly import EtlOutcome
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.federation import federated_view
from packs.snowflake.handlers import (
    BUILDERS,
    ROUTE_FEDERATED,
    ROUTE_FILE_LOAD,
    ROUTE_STATEMENT,
    ROUTE_UNSUPPORTED,
    Artifact,
    HandlerContext,
    build_artifacts,
    route_of,
    target_name,
    unit_stub,
)
from packs.snowflake.overloads import Overloads
from packs.snowflake.postpass import table_key
from packs.snowflake.validators import sniff_kind, validate


@dataclass
class BatchContext:
    """Everything a batch shares across its ETLs (built once by ``prepare_batch``)."""

    table_map: dict[tuple[str, str, str], str] = field(default_factory=dict)
    target_map: dict[str, str] = field(default_factory=dict)
    catalogue: dict[str, dict[str, str]] | None = None
    tier1: TierOneReport = field(default_factory=TierOneReport)
    settings: TranslationSettings = field(default_factory=TranslationSettings)
    default_catalog: str = "main"
    #: account parameters + capability profile + column types (conversion engine v2); built by ``prepare_batch``
    conversion: ConversionContext = field(default_factory=ConversionContext)
    #: SOURCE procedure FQN (``DB.SCHEMA.NAME``, upper) -> scalar RETURNS type, for every SQL procedure of the
    #: batch that gets a ``<name>__ret`` OUT-parameter twin (L4: the pre-pass of ``prepare_batch``), so that
    #: ``v := (CALL p())`` converts
    procedure_returns: dict[str, str] = field(default_factory=dict)
    #: S3 post-conversion validation (``packs.snowflake.verify.VerifyConfig``); ``None`` = off (nothing recorded)
    verify: Any = None
    #: X8: the Lakehouse Federation foreign catalog an ETL routed ``federated`` is queried through (manifest
    #: ``target.federation_catalog``); empty = a placeholder the reviewer must fill
    federation_catalog: str = ""
    #: X6: FQN of the runtime transpile function (manifest ``target.dynamic_sql_shim``); empty = off
    dynamic_sql_shim: str = ""
    #: 6.12: overloaded UDFs renamed by signature (``overloads.plan`` over the manifest)
    overloads: Overloads = field(default_factory=Overloads)
    #: L12: SOURCE FQN (upper) -> parameter names of the procedures that become notebooks
    notebook_procs: dict[str, list[str]] = field(default_factory=dict)


def build_table_map(manifest: dict) -> tuple[dict[tuple[str, str, str], str], dict[str, str]]:
    """``(DB, SCHEMA, NAME) -> target`` and ``asset_id -> target`` from ``table_map``, ``target_map`` and every
    ETL's input / output ``table`` (the handoff already resolved them; the post-pass needs the SOURCE names)."""
    by_asset: dict[str, str] = {}
    for src in (manifest.get("target_map") or {}, manifest.get("table_map") or {}):
        by_asset.update({str(k): str(v) for k, v in src.items() if v})
    for e in manifest.get("etls", []) + manifest.get("file_loads", []):
        for io in (*(e.get("inputs") or []), *(e.get("outputs") or [])):
            if io.get("dataset_id") and io.get("table"):
                by_asset[str(io["dataset_id"])] = str(io["table"])
    for r in manifest.get("read_statements", []):
        if r.get("dataset_id") and r.get("table"):
            by_asset.setdefault(str(r["dataset_id"]), str(r["table"]))
    keyed: dict[tuple[str, str, str], str] = {}
    for aid, table in by_asset.items():
        p = ct.parse_native_id(aid)
        if p["name"] and p["db"] and p["schema"] and not p["objtype"]:
            keyed[table_key(p["db"], p["schema"], p["name"])] = table
    return keyed, by_asset


def etl_key_of(etl: dict, source_id: str = "") -> str:
    """The per-ETL folder key: ``{source_id}__{etl_id}`` unless the manifest row carries ``etl_key`` (ADR 029)."""
    etl_id = str(etl["etl_id"])
    return str(etl.get("etl_key") or (f"{source_id}__{etl_id}" if source_id else etl_id))


def make_unit_context(doc: dict, etl_key: str, batch: BatchContext, llm: Any = None) -> tr.UnitContext:
    native = ct.parse_native_id(str(doc.get("asset_id") or ""))
    return tr.make_context(etl_key=etl_key, engine=doc["engine"], table_map=batch.table_map,
                           default_db=native["db"], default_schema=native["schema"], settings=batch.settings,
                           catalogue=batch.catalogue, tier1_cache=batch.tier1.cache, tier1_reason=batch.tier1.reason,
                           llm=llm, default_catalog=batch.default_catalog, conversion=batch.conversion,
                           procedure_returns=dict(batch.procedure_returns), dynamic_shim=batch.dynamic_sql_shim, overloads=batch.overloads, notebook_procs=dict(batch.notebook_procs),  # noqa: E501
                           stream_tables={str(i.get("name") or "").split(".")[-1].upper(): i["base_table"]
                                          for i in doc.get("inputs") or [] if i.get("base_table")})


def short_key(key: str, limit: int = 24) -> str:
    """`key` for ids repeated inside one path (run id, gate ids): unchanged when short, else a stable prefix + hash,
    so Windows paths stay under MAX_PATH (the folder itself is still named by the full key)."""
    if len(key) <= limit:
        return key
    return f"{key[:limit - 9]}-{hashlib.sha1(key.encode('utf-8')).hexdigest()[:8]}"


def _new_record(etl: dict, volume: pathlib.Path, source_id: str) -> RunRecord:
    etl_id = str(etl["etl_id"])
    key = short_key(etl_key_of(etl, source_id))    # one short key for folder, artifacts and gate ids
    stamp = dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H-%M-%S")
    run_id = f"run-{key}-{stamp}-{uuid.uuid4().hex[:4]}"    # unique per run: gate ids derive from it
    art = pathlib.Path(volume) / key / run_id
    art.mkdir(parents=True, exist_ok=True)
    return RunRecord(etl_id, key, run_id, art)


def reviewer_decisions(gates: Any, volume: pathlib.Path) -> tuple[dict[str, str], dict[str, str]]:
    """``(edits, out_of_scope)`` of an approved translation review (``--resume``): unit id -> the reviewer's text,
    unit id -> their reason. The text is read back from the restricted volume by its ``artifact_ref``."""
    entry = (getattr(gates, "reuse", None) or {}).get("translation") or {}
    edits: dict[str, str] = {}
    for uid, ref in (entry.get("edits") or {}).items():
        try:
            edits[str(uid)] = read_artifact(volume, str(ref["artifact_ref"] if isinstance(ref, dict) else ref))
        except (ArtifactError, OSError, KeyError):
            continue            # an unreadable edit leaves the unit unresolved: it is never invented
    return edits, {str(k): str(v) for k, v in (entry.get("out_of_scope") or {}).items()}


def gate_id_of(rec: RunRecord, agent: str) -> str:
    """A per-run gate id (the decision file is keyed by it); resume reuses approvals by payload hash."""
    return f"gate-{agent}-{rec.etl_key}-{rec.run_id.rsplit('-', 1)[-1]}"


def _preview_payload(volume: pathlib.Path, rec: RunRecord, source_id: str, art: Any) -> dict:
    stored = write_artifact(volume, rec.etl_key, art.text, source_id=source_id, kind=art.kind)
    return {"kind": art.kind, "name": art.name, "artifact_ref": stored.artifact_ref, "sha256": stored.sha256,
            "preview": stored.preview, "origin": art.origin, "caveats": art.caveats,
            "review_reasons": art.review_reasons}


def _attach_source(rec: RunRecord, text: str, volume: pathlib.Path, source_id: str) -> None:
    """Store the unit source SQL by hash on the restricted volume; the record keeps only ref + hash (no SQL)."""
    if text and text.strip():
        stored = write_artifact(volume, rec.etl_key, text, source_id=source_id, kind="source")
        rec.source_definition_ref = {"artifact_ref": stored.artifact_ref, "sha256": stored.sha256}


async def run_etl(etl: dict, *, collaborators: Collaborators, gates: HarnessGates, work: pathlib.Path,
                  volume: pathlib.Path, source_id: str = "", stop_at: str = "", batch: BatchContext | None = None
                  ) -> RunRecord:
    batch = batch or BatchContext()
    rec = _new_record(etl, volume, source_id)
    rec.llm = str(collaborators.extra.get("llm_mode") or "")
    route, why = route_of(etl)
    rec.completed.append("routing")
    if route == ROUTE_UNSUPPORTED:
        rec.status_override, rec.reason = "unsupported", why
        rec.write_record()
        return rec
    if route == ROUTE_FEDERATED:                    # X8: queried in place, reviewed, never auto-approved
        udoc = ct.unit_doc(etl, etl.get("payload"))
        built = federated_view(udoc, target_name(udoc, HandlerContext(
            target_map=batch.target_map, default_catalog=batch.default_catalog)), batch.federation_catalog)
        if built["status"] == "unsupported":
            rec.status_override, rec.reason = "unsupported", "; ".join(built["reasons"])
            rec.write_record()
            return rec
        art = Artifact("statement", str(etl.get("name") or ""), built["text"], "manual", str(etl.get("etl_id") or ""),
                       caveats=built["review"], review_reasons=built["reasons"])
        arts = [_preview_payload(volume, rec, source_id, art)]
        payload = {"artifact": {"kind": "sql", "artifacts": arts}, "judges": [], "origins": ["manual"],
                   "reviewed": [a["sha256"] for a in arts]}
        rec.gate("cd_codegen", payload, gates.decide("cd_codegen", payload, origins=["manual"],
                                                     gate_id=gate_id_of(rec, "cd_codegen")))
        rec.completed += ["standardization", "cd_codegen"]
        rec.reason = built["reasons"][0]
        rec.write_record()
        return rec
    if route in (ROUTE_FILE_LOAD, ROUTE_STATEMENT):
        builder = BUILDERS.get(route)
        stub = unit_stub(route, etl)
        udoc = ct.unit_doc(etl, etl.get("payload"))
        body = udoc.get("definition")
        text = ";\n".join(_units._texts(etl, udoc)) if route == ROUTE_STATEMENT else body
        _attach_source(rec, text if isinstance(text, str) else "", volume, source_id)
        if builder is None:
            payload = {"artifact": {"kind": "translation", "units": [stub]}, "judges": []}
            rec.gate("translation", payload, gates.decide("translation", payload, origins=["manual"],
                                                          gate_id=gate_id_of(rec, "translation")))
            rec.units = [stub]
            rec.write_record()
            return rec
        # a later track (P3-18 / P3-19) installed its builder: it returns reviewed artifacts, never auto-approved
        llm = collaborators.extra.get("llm_translator")
        built = builder(etl, udoc, HandlerContext(
            target_map=batch.target_map, default_catalog=batch.default_catalog,
            unit_ctx_factory=lambda d, key: make_unit_context(d, key, batch, llm)))
        if inspect.isawaitable(built):
            built = await built
        arts = [_preview_payload(volume, rec, source_id, a) for a in built]
        payload = {"artifact": {"kind": "sql", "artifacts": arts}, "judges": [], "origins": ["manual"],
                   "reviewed": [a["sha256"] for a in arts]}
        rec.gate("cd_codegen", payload, gates.decide("cd_codegen", payload, origins=["manual"],
                                                     gate_id=gate_id_of(rec, "cd_codegen")))
        rec.completed += ["standardization", "cd_codegen"]
        rec.write_record()
        return rec
    doc = ct.unit_doc(etl, etl.get("payload")) if "doc" not in etl else etl["doc"]
    try:
        std = ct.to_standardized(doc, str(etl["etl_id"]))
        to_planner_dataflow(std, str(etl["etl_id"]))
        rec.completed.append("standardization")
    except (ValueError, StandardizedSchemaError) as exc:
        rec.failures.append(f"standardization: {exc}")
        rec.write_record()
        return rec

    if isinstance(doc.get("definition"), str):
        _attach_source(rec, doc["definition"], volume, source_id)
    h = HandlerContext(target_map=batch.target_map, default_catalog=batch.default_catalog,
                       overloads=dict(batch.overloads.by_asset))
    ctx = make_unit_context(doc, rec.etl_key, batch, collaborators.extra.get("llm_translator"))
    edits, out_of_scope = reviewer_decisions(gates, volume)
    results = await tr.translate_etl(doc, ctx, edits=edits, out_of_scope=out_of_scope)
    rec.completed.append("translation")
    if batch.verify is not None:       # S3: EXPLAIN / DESCRIBE QUERY evidence; failures add review caveats
        from packs.snowflake.verify import verify_results

        verify_results(results, batch.verify, batch.conversion)
    rec.units = [r.record() for r in results]
    rec.coverage = tr.coverage(results)
    rec.tiers = tr.tier_report(results)
    origins = [r.origin if r.status == "resolved" else "unresolved" for r in results]
    review_caveats = sorted({c for r in results for c in r.review_caveats})

    # a ``translation`` item is a unit past tier 0 (or none); review caveats on a mapped unit hold the sql gate instead
    review_items = [r for r in results if r.origin != "mapped" or r.status != "resolved"]
    if review_items:
        payload = {"artifact": {"kind": "translation",
                                "units": [{**r.record(), **({"suggested_code": r.suggested_code}
                                                            if r.no_code and r.suggested_code else {})}
                                          for r in review_items]}, "judges": [],
                   "origins": sorted(set(origins)),
                   # units with nothing to approve: the API refuses ``approve`` unless each carries an edit or is
                   # marked out of scope (api.app.submit_feedback)
                   "no_code_unit_ids": [r.unit_id for r in review_items if r.no_code and not r.edited]}
        # what the reviewer saw: applying their edit / out-of-scope decision on resume must not change the hash
        payload["reviewed"] = {"units": [(r.unit_id, r.fingerprint, *(r.reviewed_as or (r.origin, r.status)))
                                         for r in review_items]}
        decision = gates.decide("translation", payload, origins=origins, review_caveats=review_caveats,
                                gate_id=gate_id_of(rec, "translation"))
        if decision.status == "approved" and any(r.edit_rejected for r in review_items):
            # the approval was for text that does not validate: never reuse it, the review reopens with the problems
            decision = GateDecision(decision.gate_id, "translation", "open", decision.payload_hash,
                                    "the reviewer's edit does not validate")
        rec.gate("translation", payload, decision)
    artifacts = build_artifacts(doc, results, h)
    for a in artifacts:
        kind = sniff_kind(a.text) if a.kind in ("task_body",) else a.kind
        problems = [] if a.kind == "task_body" else validate(kind, a.text)
        if problems:
            rec.failures.append(f"{a.kind} {a.name}: {'; '.join(problems)}")
    from packs.snowflake.caveats import load_catalogue

    review_ids = load_catalogue().ids_with("review") | load_catalogue().ids_with("escalate")
    review_caveats = sorted(set(review_caveats) | {c for a in artifacts for c in a.caveats if c in review_ids}
                            | ({"artifact_review"} if any(a.review_reasons for a in artifacts) else set()))
    if artifacts and not rec.failures:
        arts = [_preview_payload(volume, rec, source_id, a) for a in artifacts]
        payload = {"artifact": {"kind": "sql", "artifacts": arts}, "judges": [], "origins": sorted(set(origins)),
                   "reviewed": [a["sha256"] for a in arts]}
        rec.gate("cd_codegen", payload,
                 gates.decide("cd_codegen", payload, origins=origins, review_caveats=review_caveats,
                              gate_id=gate_id_of(rec, "cd_codegen")))
        rec.completed.append("cd_codegen")
    elif not artifacts and not rec.held and not rec.failures:
        out = [r for r in results if r.status == "unsupported"]
        if out:        # the reviewer marked a unit out of scope: the ETL is unsupported, with their reason
            rec.status_override = "unsupported"
            rec.reason = "; ".join(f"{r.unit_id}: {'; '.join(r.reasons)}" for r in out)[:500]
        else:
            rec.failures.append("no artifact was produced and no review is open")
    rec.outcome = EtlOutcome(str(etl["etl_id"]), rec.etl_key, str(doc["engine"]), str(doc.get("name") or ""),
                             str(doc.get("asset_id") or ""), int(etl.get("order") or 0),
                             {**(doc.get("params") or {}),
                              "stream_tables": {str(i.get("name") or "").split(".")[-1].upper(): i["base_table"]
                                                for i in doc.get("inputs") or [] if i.get("base_table")}},
                             rec.status, results, artifacts)
    rec.write_record()
    return rec

_units.install()      # P3-18 / P3-19: file_load and statement builders replace the stubs

__all__ = ["BatchContext", "build_table_map", "etl_key_of", "make_unit_context", "run_etl"]
