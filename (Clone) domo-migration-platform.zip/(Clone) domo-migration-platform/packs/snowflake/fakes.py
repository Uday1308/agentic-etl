"""packs.snowflake.fakes - the scripted tier-2 translator for offline runs and the translation eval (hard rule 10:
no live model). It answers like ``SqlTailTranslator.resolve_tail``: ``step_id -> answer`` with ``usable``, ``sql``,
``confidence`` and ``why_not``. Keyed by unit fingerprint or by a substring of the unit's source text, so a fixture
stays independent of generated unit ids."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ScriptedAnswer:
    step_id: str
    sql: str = ""
    confidence: float | None = None
    why_not: str = ""

    @property
    def usable(self) -> bool:
        return bool(self.sql)


class ScriptedTranslator:
    """``answers``: ``{key: sql | (sql, confidence)}`` where ``key`` is a fingerprint, a step id or a lower-case
    substring of the source text. No match -> an unusable answer (the chain moves to tier 3)."""

    def __init__(self, answers: dict[str, object] | None = None, *, default_confidence: float = 0.8) -> None:
        self.answers = dict(answers or {})
        self.default_confidence = default_confidence
        self.calls: list[list[str]] = []

    async def resolve_tail(self, build, *, config=None, user_prompt="", feedback=None, issues=None, hard=None):
        out = {}
        self.calls.append([str(i.get("step")) for i in build.unresolved])
        for item in build.unresolved:
            sid = str(item.get("step"))
            text = str(item.get("source_text") or "").lower()
            hit = self.answers.get(str(item.get("fingerprint"))) or self.answers.get(sid)
            if hit is None:
                hit = next((v for k, v in self.answers.items() if k and k.lower() in text), None)
            if hit is None:
                out[sid] = ScriptedAnswer(sid, why_not="the scripted model has no answer for this unit")
                continue
            sql, conf = hit if isinstance(hit, tuple) else (hit, self.default_confidence)
            out[sid] = ScriptedAnswer(sid, str(sql), float(conf))
        return out


__all__ = ["ScriptedAnswer", "ScriptedTranslator"]
