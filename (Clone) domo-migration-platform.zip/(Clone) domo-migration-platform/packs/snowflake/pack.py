"""packs.snowflake.pack - the Snowflake ``SourcePack`` (ADR 032 sections 1-5, Phase 3).

| part          | provided by                                                                            |
|---------------|----------------------------------------------------------------------------------------|
| contract      | ``contract.py``: the SQL node, hidden-definition marker, Scripting split               |
| vocabulary    | ``vocabulary.py``: ``sqlglot.lineage`` reads, ``unverifiable`` when not derivable        |
| expressions   | sqlglot ``read="snowflake"`` -> ``write="databricks"``                                  |
| registry      | ``SnowflakeRegistry``: tier 0 for one SQL node (transpile + rules + caveat scan)        |
| caveats       | ``caveats.yaml`` + the ``SNW00x`` judges generated from it                              |
| collaborators | fixture readers, a scripted LLM translator, an optional ``Transpiler`` (mock mode)      |
"""
from __future__ import annotations

import functools
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from core.domo.tiles_pyspark import RenderResult
from core.packs import Collaborators, PackCaveats, PackProfile
from packs.snowflake import caveats as cav
from packs.snowflake.contract import SnowflakeContract
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.postpass import transpile
from packs.snowflake.translate import PACK_VERSION
from packs.snowflake.vocabulary import VOCABULARY


@functools.lru_cache(maxsize=1)
def _default_conversion() -> ConversionContext:
    return ConversionContext.build()


class SnowflakeExpressions:
    @staticmethod
    def translate(expression: str, *, dialect: str = "sql", conversion: ConversionContext | None = None) -> Any:
        """One expression through tier 0 WITH the pack rules (L5): ``conversion`` is the batch's context
        (``prepare_batch(...).conversion``); without one the default context applies, so a rule that needs an account
        parameter still runs (on Snowflake's documented default, flagged) instead of being skipped."""
        # a bare expression is wrapped in SELECT so a rule can replace the expression itself (a root has no parent)
        res = transpile(f"SELECT {expression}", conversion=conversion or _default_conversion())
        return res.sql[len("SELECT "):] if res.ok and res.sql.startswith("SELECT ") else None

    @staticmethod
    def detect_functions(expression: str) -> set[str]:
        try:
            tree = sqlglot.parse_one(expression, read="snowflake")
        except SqlglotError:
            return set()
        return {(f.sql_name() if isinstance(f, exp.Func) else str(f.this)).upper()
                for f in tree.find_all(exp.Func, exp.Anonymous)}


class SnowflakeRegistry:
    """The ``render(node, inputs, df_var)`` renderer the shared plan and SQL path expects, for ``sql`` nodes: tier 0
    for one unit. Unresolved (parse error, ``escalate`` / ``block`` caveat) goes to the chain, never guessed."""

    def __init__(self, conversion: ConversionContext | None = None) -> None:
        self.catalogue = cav.load_catalogue()
        #: the batch's ConversionContext (parameters, capability profile, column types): the rules apply everywhere (L5)
        self.conversion = conversion or _default_conversion()

    def render(self, node: dict, inputs: list[str], df_var: str) -> RenderResult:
        props = node.get("properties") or node.get("logic") or {}
        ntype = str(node.get("type") or "").lower()
        if ntype in ("source", "target"):
            return RenderResult(code=f"SELECT * FROM {props.get('table') or props.get('fq_name') or df_var}")
        sql = str(props.get("sql") or "")
        if not sql:
            return RenderResult(unresolved=["SQL node has no definition (hidden or unavailable)"])
        hit = cav.detect(sql, self.catalogue)
        tr = transpile(sql, conversion=self.conversion)
        if not tr.ok:
            return RenderResult(unresolved=tr.reasons, notes=hit)
        hit = sorted({*hit, *(f.id for f in tr.flags)})       # what the rules could not decide, by caveat id
        cls = cav.classify(hit, self.catalogue)
        if cls["block"] or cls["escalate"]:
            return RenderResult(code=tr.sql, unresolved=[f"caveat {c}" for c in cls["block"] + cls["escalate"]],
                                notes=hit)
        return RenderResult(code=tr.sql, confidence="MEDIUM" if cls["review"] else "HIGH", notes=hit)


class SnowflakePack:
    platform = "snowflake"
    source_dialect = "snowflake"
    version = PACK_VERSION
    contract = SnowflakeContract()
    vocabulary = VOCABULARY
    expressions = SnowflakeExpressions()
    caveats = PackCaveats(
        literals_sensitive=True, as_of_column="",
        judge_ids=tuple(sorted(cav.load_catalogue().families)),
        escalate=cav.load_catalogue().ids_with("escalate"), block=cav.load_catalogue().ids_with("block"),
        review=cav.load_catalogue().ids_with("review"),
        notes=("Snowflake SQL often holds personal data in literals: prompts and logs are masked in every environment",))  # noqa: E501
    profile = PackProfile(label="Snowflake", unit="object", units="objects", step="statement", steps="statements",
                          ready=True)

    @staticmethod
    def registry(target_dialect: str = "sql", *, conversion: ConversionContext | None = None) -> Any:
        if target_dialect != "sql":
            raise ValueError("the Snowflake pack renders SQL only (Snowpark -> PySpark goes through tier 2)")
        return SnowflakeRegistry(conversion)

    @staticmethod
    async def run_etl(etl: dict, **kw: Any) -> Any:
        """``core.runner.run_pipeline`` calls this for packs that export it (lazy import: no cycle)."""
        from packs.snowflake.run import run_etl

        return await run_etl(etl, **kw)

    @staticmethod
    def route_of(row: dict) -> tuple[str, str]:
        from packs.snowflake.handlers import route_of

        return route_of(row)

    @staticmethod
    def prepare_batch(*a: Any, **kw: Any) -> Any:
        """Phase A of the two-phase batch (see ``packs.snowflake.batch``)."""
        from packs.snowflake.batch import prepare_batch

        return prepare_batch(*a, **kw)

    @staticmethod
    def finish_batch(*a: Any, **kw: Any) -> dict:
        from packs.snowflake.batch import finish_batch

        return finish_batch(*a, pack=PACK, **kw)

    @staticmethod
    def outcome_to_dict(o: Any) -> dict:
        from packs.snowflake.assembly import outcome_to_dict
        return outcome_to_dict(o)

    @staticmethod
    def outcome_from_dict(d: dict) -> Any:
        from packs.snowflake.assembly import outcome_from_dict
        return outcome_from_dict(d)

    @staticmethod
    def judges() -> list:
        return cav.generate_judges()

    @staticmethod
    def collaborators(mode: str = "mock") -> Collaborators:
        """Mock mode: the scripted translator and no transpiler. Real readers arrive with P3-15 (SQL API client port,
        D-35); live collaborators are built by the caller and passed to the runner."""
        if mode != "mock":
            raise NotImplementedError("the Snowflake pack ships mock collaborators; pass live ports to run_pipeline")
        from packs.snowflake.fakes import ScriptedTranslator

        return Collaborators(extra={"llm_translator": ScriptedTranslator({}), "transpiler": None})


PACK = SnowflakePack()

__all__ = ["PACK", "SnowflakeExpressions", "SnowflakePack", "SnowflakeRegistry"]
