"""packs.snowflake.warehouse - the SQL warehouse port the post-conversion checks use (S3 / S4 / S10, ADR 037).

Rules 4 and 5: nothing in this module imports ``databricks.*``. The migrator already owns one warehouse client,
``api.store_delta.connect_databricks`` (the existing allowed adapter; it imports the connector lazily). The real
adapter here only WRAPS that ``query(statement) -> list[dict]`` callable; tests use ``FakeWarehouse``.

    Warehouse.sql(statement) -> list[dict]      raises WarehouseError(error_class, message) on any failure
    SourceQuery.query(sql)   -> list[dict]      the Snowflake side of the parity checker (read-only aggregates)

Nothing here ever returns a value for a statement it could not run: a missing warehouse is ``None`` and the callers
record ``unverifiable`` with a reason (hard rule 6), never a pass.
"""
from __future__ import annotations

import os
import re
from collections.abc import Callable
from typing import Any, Protocol, runtime_checkable

ENV_WAREHOUSE_ID = "DATABRICKS_WAREHOUSE_ID"
ENV_HTTP_PATH = "DATABRICKS_HTTP_PATH"
#: error classes that only say "an object is not on the target (yet)": the plan may create it later
MISSING_OBJECT_CLASSES = frozenset({"TABLE_OR_VIEW_NOT_FOUND", "SCHEMA_NOT_FOUND", "CATALOG_NOT_FOUND",
                                    "ROUTINE_NOT_FOUND"})
_CLASS_RX = re.compile(r"\[([A-Z][A-Z0-9_]+(?:\.[A-Z0-9_]+)*)\]")


class WarehouseError(Exception):
    """A statement failed on the warehouse. ``error_class`` is the Databricks error class (``TABLE_OR_VIEW_NOT_FOUND``,
    ``CANNOT_MERGE_INCOMPATIBLE_DATA_TYPE``, ``PARSE_SYNTAX_ERROR``) or ``UNKNOWN``. ``message`` may quote source text:
    it is for the caller's logic, never stored in evidence."""

    def __init__(self, error_class: str, message: str = "") -> None:
        super().__init__(f"{error_class}: {message[:200]}")
        self.error_class = error_class
        self.message = message


def error_class_of(message: str) -> str:
    m = _CLASS_RX.search(message or "")
    if m:
        return m.group(1)
    if re.search(r"ParseException|syntax error", message or "", re.I):
        return "PARSE_SYNTAX_ERROR"
    if re.search(r"AnalysisException|cannot be found|cannot be resolved", message or "", re.I):
        return "ANALYSIS_ERROR"
    return "UNKNOWN"


@runtime_checkable
class Warehouse(Protocol):
    def sql(self, statement: str) -> list[dict]: ...


@runtime_checkable
class SourceQuery(Protocol):
    def query(self, sql: str) -> list[dict]: ...


class QueryWarehouse:
    """Adapter over a ``query(statement) -> list[dict]`` callable (the existing connector or anything shaped so)."""

    def __init__(self, query: Callable[..., list[dict]]) -> None:
        self._query = query

    def sql(self, statement: str) -> list[dict]:
        try:
            return list(self._query(statement) or [])
        except WarehouseError:
            raise
        except Exception as exc:          # the connector raises its own types; the port has one
            raise WarehouseError(error_class_of(str(exc)), str(exc)) from exc


def configured() -> bool:
    return bool(os.environ.get(ENV_WAREHOUSE_ID) or os.environ.get(ENV_HTTP_PATH))


def from_env() -> tuple[Warehouse | None, str]:
    """``(warehouse, reason)``: the reason says why there is none. Never raises, never connects until first use."""
    if not configured():
        return None, f"no SQL warehouse configured ({ENV_WAREHOUSE_ID} / {ENV_HTTP_PATH} not set)"
    try:
        from api.store_delta import connect_databricks  # the existing allowed adapter (lazy import)

        return QueryWarehouse(connect_databricks()[0]), ""
    except Exception as exc:
        return None, f"warehouse unavailable: {type(exc).__name__}"


def explain(wh: Warehouse, query: str) -> None:
    """``EXPLAIN <query>``; raises ``WarehouseError`` when Databricks cannot analyze it. EXPLAIN never executes."""
    rows = wh.sql("EXPLAIN " + query) or []
    # Databricks may return an analysis failure as the plan text rather than raising it
    text = "\n".join(str(v) for row in rows for v in (row.values() if isinstance(row, dict) else [row]))
    if re.search(r"Error occurred during query planning|AnalysisException", text):
        msg = text.split("Error occurred during query planning:", 1)[-1].strip()
        raise WarehouseError(error_class_of(msg), msg)


def describe_query(wh: Warehouse, query: str) -> list[tuple[str, str]]:
    """``DESCRIBE QUERY``: ``[(column, type)]`` in output order (the warehouse is the authority on types)."""
    out: list[tuple[str, str]] = []
    for row in wh.sql("DESCRIBE QUERY " + query):
        name = str(row.get("col_name") or "")
        if not name or name.startswith("#"):
            break
        out.append((name, str(row.get("data_type") or "")))
    return out


class FakeWarehouse:
    """Scripted warehouse for offline tests (rule 10). ``on(substring, rows=... | error=...)``; first match wins (case
    insensitive). ``error`` is a ``WarehouseError`` or an ``error_class`` string. Unscripted statements answer
    ``default`` (rows) or raise when ``strict``. ``calls`` records every statement."""

    def __init__(self, *, default: list[dict] | None = None, strict: bool = False) -> None:
        self.rules: list[tuple[str, Any]] = []
        self.default = [] if default is None else default
        self.strict = strict
        self.calls: list[str] = []

    def on(self, needle: str, rows: list[dict] | Callable[[str], Any] | None = None,
           error: WarehouseError | str | None = None) -> FakeWarehouse:
        if isinstance(error, str):
            error = WarehouseError(error, f"[{error}] scripted failure")
        self.rules.append((needle.lower(), error if error is not None else (rows if rows is not None else [])))
        return self

    def sql(self, statement: str) -> list[dict]:
        self.calls.append(statement)
        low = statement.lower()
        for needle, answer in self.rules:
            if needle in low:
                if callable(answer):
                    answer = answer(statement)
                if isinstance(answer, Exception):
                    raise answer
                return list(answer)
        if self.strict:
            raise WarehouseError("UNKNOWN", f"unscripted statement: {statement[:80]}")
        return list(self.default)

    def query(self, sql: str) -> list[dict]:      # also usable as the parity source
        return self.sql(sql)


__all__ = ["FakeWarehouse", "MISSING_OBJECT_CLASSES", "QueryWarehouse", "SourceQuery", "Warehouse", "WarehouseError",
           "configured", "describe_query", "error_class_of", "explain", "from_env"]
