# Ported from SNF2DBX-main/migration/equivalence.py and migration/equivalence_objects.py (LatentView internal):
# the canonical-form structural comparison (sqlglot.diff) and the seeded-sample DuckDB execution with a multiset
# comparison, reduced to the query forms the engine converts (views, materialized views, dynamic tables, CTAS,
# INSERT ... SELECT, plain queries) and rewired to the pack's ConversionContext.
"""packs.snowflake.equivalence - is the converted query equivalent to its Snowflake source? (S5, ADR 037 section 2)

Runs after tier 0 and before the human gate, offline: nothing touches Snowflake or Databricks. Two techniques:

1. **Structural**: both texts are parsed (Snowflake / Databricks), tables flattened to one name per target table,
   canonical forms applied (parentheses, GROUP BY ordinals, spellings that mean the same), rendered as DuckDB SQL and
   compared; ``sqlglot.diff`` lists what differs.
2. **Sample data**: the referenced tables are created in an in-memory DuckDB from the batch's column catalogue
   (``ConversionContext.column_types``, SOURCE types) and filled with seeded rows (NULLs, zero, negatives, empty
   strings, month ends); the source query (Snowflake -> DuckDB) and the output query (Databricks -> DuckDB) both run
   and their results are compared as multisets (floats to 6 places). ``duckdb`` is imported lazily: absent from the
   migrator venv, the sample step is skipped and the verdict says so (never a vacuous pass, hard rule 6).

Verdict (``status``):

* ``equivalent``            canonical trees are identical, or the sample results match and are not vacuous
* ``differs_explained``     they differ, and every difference matches a rewrite the engine declared (a caveat or flag on
                            the unit, or a standard rewrite that needs no warning)
* ``differs_unexplained``   they differ and no rule explains it (structure with a sample result that differs, or a
                            sample difference): the caller adds ``SNW-EQUIV-DIFF`` and a reviewer decides
* ``not_checkable``         the pair cannot be emulated offline (VARIANT paths, FLATTEN, stage columns, tables or
                            column types not described, escalated rules, no duckdb for a structural difference no rule
                            explains): said so with the reason

A construct whose Snowflake semantics DuckDB does not share (the ``_UNSAFE`` list and any escalated rule flag) makes
the pair ``not_checkable`` before anything runs: a sample match proves nothing when the emulation of the SOURCE is
itself wrong. Reasons carry names and counts, never literals or SQL text (hard rule 11).
"""
from __future__ import annotations

import random
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.diff import Insert, Remove, Update, diff
from sqlglot.errors import SqlglotError

from packs.snowflake.conversion import ConversionContext, type_family

EQUIVALENT, EXPLAINED, UNEXPLAINED, NOT_CHECKABLE = ("equivalent", "differs_explained", "differs_unexplained",
                                                      "not_checkable")
SAMPLE_ROWS = 60
SEED = 7
_UNSAFE = re.compile(r"(?<![\w$])\$\d+\b|\bMETADATA\$|\bFLATTEN\s*\(|\bLATERAL\b|\bSEQ[1248]\s*\(|\bGENERATOR\s*\(|"
                     r"\bCONNECT\s+BY\b|\bMATCH_RECOGNIZE\b|\bASOF\b|\bSAMPLE\s*\(|\bTABLESAMPLE\b|\bCHANGES\s*\(|"
                     r"\b(?:AT|BEFORE)\s*\(\s*(?:TIMESTAMP|OFFSET|STATEMENT)\s*=>|\bRESULT_SCAN\b|\bIDENTIFIER\s*\(|"
                     r"\bGET_PATH\s*\(|\w\s*:\s*[A-Za-z_\"\[]|\bPARSE_JSON\b|\bOBJECT_CONSTRUCT|\bARRAY_|"
                     r"\bCONVERT_TIMEZONE\b|\bHASH\s*\(|\bUUID_STRING\b|\bRANDOM\s*\(", re.I)
#: types whose DuckDB twin is not the same type: a table with such a column is not emulated
_NOT_EMULATED_FAMILIES = frozenset({"variant", "geo", "binary", "other", "time", "timestamp_tz", "timestamp_ltz"})

#: (regex over the difference text, caveat ids that declare it). An empty id tuple is a standard rewrite that needs no
#: warning. A difference is explained when its pattern matches AND (no ids, or one of the ids is on the unit).
_DECLARED: tuple[tuple[str, tuple[str, ...]], ...] = (
    (r"\bIF\b|\bCASE\b", ("SNW-IFF",)),
    (r"DATE_ADD|DATEADD|DATE_DIFF|DATEDIFF|\bINTERVAL\b|\bYEAR\b|\bMONTH\b|\bDAY\b|\bQUARTER\b|\bWEEK\b|EXTRACT|DATE_TRUNC",
     ("SNW-DATEADD", "SNW-DATEDIFF", "SNW-ADD-MONTHS", "SNW-DATEDIFF-UNIT", "SNW-DATE-PART", "SNW-WEEK-PARAM",
      "SNW-PARAM-ASSUMED", "SNW-SESSION-TZ")),
    (r"ROW_NUMBER|QUALIFY", ("SNW-QUALIFY",)),
    (r"LISTAGG|STRING_AGG|ARRAY_AGG|GROUP_CONCAT", ("SNW-LISTAGG", "SNW-LISTAGG-ORDER")),
    (r"REGEXP|\bRLIKE\b|\bSIMILAR\b", ("SNW-REGEXP-ANCHOR", "SNW-REGEX-PARAMS")),
    (r"CURRENT_TIMESTAMP|CURRENT_USER|CURRENT_ROLE|\bNOW\b|AT TIME ZONE", ("SNW-SESSION-TZ", "SNW-TIMESTAMP-TZ",
                                                                         "SNW-CURRENT-USER", "SNW-SEM-SESSION-TZ")),
    (r"NULLS (?:FIRST|LAST)", ()),                                     # ORDER BY null placement rule (row 1.1)
    (r"COALESCE|\bNULLIF\b|IS NOT DISTINCT|\bIS NULL\b", ()),          # ZEROIFNULL / NULLIFZERO / EQUAL_NULL
    (r"\bCAST\b|::|\bTRY_CAST\b|\bROUND\b|\bTRUNC\b|DECIMAL|DOUBLE|\bNUMERIC\b",
     ("SNW-IMPLICIT-CAST", "SNW-NUMBER-PRECISION", "SNW-DIVISION-SCALE", "SNW-ROUND-FLOAT", "SNW-ROUND-MODE",
      "SNW-INT-DIVISION", "SNW-TO-CHAR-DEFAULT", "SNW-FORMAT-AUTO", "SNW-FORMAT-YY", "SNW-NUMBER-FORMAT")),
    (r"\bDIV0\b|\bDIV0NULL\b|\bDIV\b|\/", ("SNW-INT-DIVISION", "SNW-DIVISION-SCALE")),
)
_VOLATILE_NAMES = ("now", "get_current_timestamp", "sysdate", "getdate", "current_timestamp", "localtimestamp")


@dataclass
class Verdict:
    status: str
    detail: list[str] = field(default_factory=list)        # the differences, or why it is not checkable
    explained: list[str] = field(default_factory=list)
    sample: str = ""                                       # match | differ | inconclusive | skipped: <reason>
    structure: str = ""                                    # same | differs

    def record(self) -> dict[str, Any]:
        return {"status": self.status, "detail": self.detail[:8], "explained": self.explained[:8],
                "sample": self.sample, "structure": self.structure}


# ------------------------------------------------------------------------------------------------ extraction
def _query_of(tree: exp.Expression | None) -> exp.Expression | None:
    """The read part: the query itself, a CREATE VIEW / TABLE ... AS query, INSERT ... SELECT."""
    if tree is None or isinstance(tree, exp.Command):
        return None
    if isinstance(tree, exp.Query):
        return tree
    if isinstance(tree, exp.Create) and isinstance(tree.expression, exp.Query):
        return tree.expression
    if isinstance(tree, exp.Insert) and isinstance(tree.expression, exp.Query):
        return tree.expression
    return None


def _parse(sql: str, dialect: str) -> exp.Expression | None:
    try:
        trees = [t for t in sqlglot.parse(sql, read=dialect) if t is not None]
    except SqlglotError:
        return None
    return _query_of(trees[0]) if len(trees) == 1 else None


# ------------------------------------------------------------------------------------------------ normalisation
def _flatten_tables(tree: exp.Expression, resolve) -> list[str]:  # noqa: ANN001
    """Every table becomes one lower-case identifier ``catalog__schema__table`` (its TARGET name). Returns the names
    that could not be resolved (a source table with no mapping)."""
    ctes = {str(c.alias).lower() for c in tree.find_all(exp.CTE)}
    missing: list[str] = []
    for t in list(tree.find_all(exp.Table)):
        if not isinstance(t.this, exp.Identifier) or not t.name or t.name.lower() in ctes:
            continue
        target = resolve(t)
        if target is None:
            missing.append(t.name.lower())
            continue
        new = exp.Table(this=exp.to_identifier("__".join(target.lower().split("."))))
        if t.args.get("alias") is not None:
            new.set("alias", t.args["alias"].copy())
        t.replace(new)
    return missing


def _pin_volatile(tree: exp.Expression) -> exp.Expression:
    """The same fixed clock on both sides, so the sample compares logic and not timing."""
    tree = tree.copy()
    for node in list(tree.find_all(exp.CurrentTimestamp, exp.CurrentDate, exp.CurrentTime)):
        lit = {exp.CurrentDate: "DATE '2026-01-31'", exp.CurrentTime: "TIME '12:00:00'"}.get(
            type(node), "TIMESTAMP '2026-01-31 12:00:00'")
        node.replace(sqlglot.parse_one(lit, read="duckdb"))
    for node in list(tree.find_all(exp.Anonymous)):
        if str(node.this).lower() in _VOLATILE_NAMES:
            node.replace(sqlglot.parse_one("TIMESTAMP '2026-01-31 12:00:00'", read="duckdb"))
    return tree


def _canonical_forms(tree: exp.Expression) -> None:
    """Spellings that mean the same thing become one form, so they compare equal."""
    for paren in list(tree.find_all(exp.Paren)):
        if isinstance(paren.parent, (exp.If, exp.Where, exp.Having)) or isinstance(
                paren.this, (exp.Column, exp.Literal, exp.Paren, exp.Func)):
            paren.replace(paren.this.copy())
    for select in tree.find_all(exp.Select):                         # GROUP BY 1, 2 -> the selected expressions
        group = select.args.get("group")
        if not group:
            continue
        projections = [p.unalias() if isinstance(p, exp.Alias) else p for p in select.expressions]
        for item in list(group.expressions):
            if isinstance(item, exp.Literal) and item.is_int and 0 < int(item.this) <= len(projections):
                item.replace(projections[int(item.this) - 1].copy())
    temporal = {exp.DataType.Type.DATE, exp.DataType.Type.TIMESTAMP, exp.DataType.Type.TIMESTAMPTZ,
                exp.DataType.Type.TIMESTAMPNTZ, exp.DataType.Type.DATETIME}
    date_fns = (exp.Year, exp.Month, exp.Day, exp.DayOfWeek, exp.DayOfYear, exp.DayOfMonth, exp.Quarter, exp.Week,
                exp.Extract, exp.DateTrunc, exp.TimestampTrunc)
    for cast in list(tree.find_all(exp.Cast)):                       # YEAR(CAST(d AS DATE)) == YEAR(d)
        if isinstance(cast.parent, date_fns) and cast.to.this in temporal and not isinstance(cast.this, exp.Literal):
            cast.replace(cast.this.copy())


def _normalise(tree: exp.Expression, dialect: str, resolve) -> tuple[exp.Expression | None, list[str]]:  # noqa: ANN001
    tree = tree.copy()
    missing = _flatten_tables(tree, resolve)
    if missing:
        return None, missing
    for ph in tree.find_all(exp.Placeholder):
        ph.set("this", None)
    _canonical_forms(tree)
    try:
        rendered = sqlglot.parse_one(tree.sql(dialect="duckdb", normalize=True), read="duckdb")
    except SqlglotError:
        return None, []
    _canonical_forms(rendered)
    return rendered, []


def describe_diff(a: exp.Expression, b: exp.Expression, limit: int = 6) -> list[str]:
    """Readable differences between two canonical trees (node kinds and counts, never literals)."""
    try:
        edits = diff(a, b, delta_only=True)
    except Exception:                                                   # noqa: BLE001 - sqlglot.diff is best effort
        return ["statements differ"]
    out: list[str] = []
    for edit in edits:
        if isinstance(edit, (Insert, Remove)):
            side = "only in Snowflake: " if isinstance(edit, Remove) else "only in Databricks: "
            out.append(side + _shape(edit.expression))
        elif isinstance(edit, Update):
            out.append(f"changed: {_shape(edit.source)} -> {_shape(edit.target)}")
        if len(out) >= limit:
            break
    return list(dict.fromkeys(out)) or ["statements differ"]


def _shape(node: exp.Expression) -> str:
    """The SQL of a node with literals blanked: structure and names, no data."""
    n = node.copy()
    if isinstance(n, exp.Literal):
        return "<string literal>" if n.is_string else "<number literal>"
    for lit in list(n.find_all(exp.Literal)):
        lit.replace(exp.Literal.string("?") if lit.is_string else exp.Literal.number(0))
    return n.sql(dialect="duckdb")[:140]


def _explained_by(difference: str, caveat_ids: set[str], *, warned: bool = False) -> bool:
    """``warned``: only a rewrite the unit DECLARED (a caveat or flag) explains it; a standard rewrite that needs no
    warning explains a structural difference but never a difference in the rows (it must not change them)."""
    return any(re.search(rx, difference, re.I) and (caveat_ids & set(ids) if ids else not warned)
               for rx, ids in _DECLARED)


# ------------------------------------------------------------------------------------------------ sample data
def _duck_type(source_type: str | None) -> str | None:
    fam = type_family(source_type)
    if fam is None or fam in _NOT_EMULATED_FAMILIES:
        return None
    try:
        return exp.DataType.build(str(source_type), dialect="snowflake").sql("duckdb")
    except (SqlglotError, ValueError):
        return None


def _value(duck: str, rng: random.Random) -> Any:
    if rng.random() < 0.1:
        return None
    t = duck.upper()
    if t.startswith("DECIMAL") or t in ("BIGINT", "INTEGER", "SMALLINT", "TINYINT", "HUGEINT"):
        return rng.choice([0, 1, 2, 3, 4, 5, -1, 1000])
    if t in ("DOUBLE", "FLOAT", "REAL"):
        return rng.choice([0.0, 1.5, 2.25, -3.0, 100.125])
    if t == "DATE":
        return date(2026, 1, 28) + timedelta(days=rng.randint(0, 6))
    if t.startswith("TIMESTAMP"):
        return datetime(2026, 1, 30, rng.randint(0, 23), rng.choice([0, 30, 59]))
    if t == "BOOLEAN":
        return rng.random() < 0.5
    return rng.choice(["A", "B", "Y", "N", "CANCELED", "OPEN", "", "x y", "1", "2"])


def _norm_value(v: Any) -> Any:
    if isinstance(v, (float, Decimal)):
        return round(float(v), 6)
    return v


def _rows(con: Any, sql: str) -> list[tuple]:
    return [tuple(_norm_value(v) for v in r) for r in con.execute(sql).fetchall()]


def _sample(source_tree: exp.Expression, out_tree: exp.Expression, tables: dict[str, dict[str, str | None]],
            ) -> tuple[str, str]:
    """``(result, detail)``: match | differ | inconclusive | skipped. Both trees are duckdb-normalised already."""
    try:
        import duckdb  # noqa: PLC0415 - lazy: absent from the migrator venv
    except ImportError:
        return "skipped", "duckdb is not installed in this environment"
    rng = random.Random(SEED)
    con = duckdb.connect(":memory:")
    try:
        for name, cols in sorted(tables.items()):
            ddl = []
            for c, t in cols.items():
                duck = _duck_type(t)
                if duck is None:
                    return "skipped", f"column {c} of {name} has a type that is not emulated ({t})"
                ddl.append((c, duck))
            if not ddl:
                return "skipped", f"table {name} has no described columns"
            con.execute(f'CREATE TABLE "{name}" (' + ", ".join(f'"{c}" {t}' for c, t in ddl) + ")")
            rows = [tuple(_value(t, rng) for _, t in ddl) for _ in range(SAMPLE_ROWS)]
            con.executemany(f'INSERT INTO "{name}" VALUES (' + ",".join("?" for _ in ddl) + ")", rows)
        a, b = _pin_volatile(source_tree).sql(dialect="duckdb"), _pin_volatile(out_tree).sql(dialect="duckdb")
        try:
            left = _rows(con, a)
        except Exception as exc:                                      # noqa: BLE001 - a duckdb error is a result
            return "inconclusive", f"the source query does not run on DuckDB ({type(exc).__name__})"
        try:
            right = _rows(con, b)
        except Exception as exc:                                      # noqa: BLE001
            return "inconclusive", f"the output query does not run on DuckDB ({type(exc).__name__})"
        if Counter(left) != Counter(right):
            only_l, only_r = Counter(left) - Counter(right), Counter(right) - Counter(left)
            return "differ", (f"results differ on sample data ({len(left)} source rows, {len(right)} output rows; "
                              f"{sum(only_l.values())} only in the source, {sum(only_r.values())} only in the output)")
        if not left:
            return "inconclusive", "both results are empty on the sample data"
        return "match", f"the same {len(left)} row(s) on sample data"
    finally:
        con.close()


# ------------------------------------------------------------------------------------------------ the check
def check(source: str, out: str, *, names: Any = None, conversion: ConversionContext | None = None,
          caveat_ids: set[str] | frozenset[str] = frozenset(), escalated: bool = False) -> Verdict:
    """Compare one Snowflake query with its Databricks conversion. ``names`` is the post-pass context (table map and
    default database / schema), ``caveat_ids`` the caveats and rule flags the unit already carries."""
    ids = set(caveat_ids)
    if escalated:
        return Verdict(NOT_CHECKABLE, ["a rule escalated this unit: the emulation of the source is not trusted"])
    if _UNSAFE.search(re.sub(r"'(?:[^']|'')*'", "''", source)):
        return Verdict(NOT_CHECKABLE, ["the source uses a construct DuckDB does not share (semi-structured paths, "
                                       "FLATTEN, stage columns, generators, time travel, hashes, randomness, ...)"])
    src_q, out_q = _parse(source, "snowflake"), _parse(out, "databricks")
    if src_q is None or out_q is None:
        return Verdict(NOT_CHECKABLE, ["no single query on one side (a script, a CALL or an unparsable text)"])

    def resolve_source(t: exp.Table) -> str | None:
        if names is None:
            return None
        db = str(t.catalog or names.default_db).upper()
        schema = str(t.db or names.default_schema).upper()
        return names.table_map.get((db, schema, t.name.upper()))

    def resolve_out(t: exp.Table) -> str | None:
        return ".".join(p for p in (t.catalog, t.db, t.name) if p)

    a, missing_a = _normalise(src_q, "snowflake", resolve_source)
    b, missing_b = _normalise(out_q, "databricks", resolve_out)
    if a is None or b is None:
        why = f"tables not mapped: {sorted(set(missing_a + missing_b))}" if missing_a or missing_b else \
            "a side could not be normalised"
        return Verdict(NOT_CHECKABLE, [why])
    same = a.sql() == b.sql()
    if same:
        return Verdict(EQUIVALENT, ["canonical trees are identical"], structure="same")
    differences = describe_diff(a, b)
    explained = [d for d in differences if _explained_by(d, ids)]
    unexplained = [d for d in differences if d not in explained]
    verdict = Verdict(UNEXPLAINED, unexplained, explained, structure="differs")

    referenced = {t.name.lower() for t in b.find_all(exp.Table) if isinstance(t.this, exp.Identifier)} | \
        {t.name.lower() for t in a.find_all(exp.Table) if isinstance(t.this, exp.Identifier)}
    ctes = {str(c.alias).lower() for q in (a, b) for c in q.find_all(exp.CTE)}
    tables: dict[str, dict[str, str | None]] = {}
    cannot = ""
    for flat in sorted(referenced - ctes):
        real = flat.replace("__", ".")
        cols = conversion.table_columns(real) if conversion is not None else None
        if not cols:
            cannot = f"table {real} is not described in the column catalogue"
            break
        tables[flat] = dict(cols)
    if cannot:
        verdict.sample = f"skipped: {cannot}"
    else:
        result, detail = _sample(a, b, tables)
        verdict.sample = result if result in ("match", "differ") else f"{result}: {detail}"
        if result == "match":
            return Verdict(EQUIVALENT, [f"{len(differences)} structural difference(s), results match: {detail}"],
                           explained, sample="match", structure="differs")
        if result == "differ":
            declared = [d for d in differences if _explained_by(d, ids, warned=True)]
            if declared and len(declared) == len(differences):
                return Verdict(EXPLAINED, [detail], declared, sample="differ", structure="differs")
            return Verdict(UNEXPLAINED, [detail, *[d for d in differences if d not in declared]], declared,
                           sample="differ", structure="differs")
    if not unexplained:
        return Verdict(EXPLAINED, [], explained, sample=verdict.sample, structure="differs")
    # structure differs, no rule explains it, and the sample could not decide: not provable here (no review noise)
    return Verdict(NOT_CHECKABLE, [f"{len(unexplained)} structural difference(s) no rule explains and the sample data "
                                   f"could not decide ({verdict.sample})", *unexplained], explained,
                   sample=verdict.sample, structure="differs")


__all__ = ["EQUIVALENT", "EXPLAINED", "NOT_CHECKABLE", "UNEXPLAINED", "Verdict", "check", "describe_diff"]
