# Ported from SNF2DBX-main/converters/scripting.py (LatentView internal)
# ruff: noqa: E501
"""packs.snowflake.scripting_convert - Snowflake Scripting -> Databricks SQL scripting, tier 0 (S1, ADR 037; catalogue
rows 5.1-5.6, 5.8, 5.10, 5.14).

Ported from SNF2DBX ``converters/scripting.py`` and adapted to this pack:

- The INPUT CONTRACT is the pack's splitter (``packs.snowflake.scripting.split_scripting``): ``convert`` takes its
  ``ScriptNode`` list. Top-level node boundaries come from the splitter; the nodes it keeps whole (IF / FOR / WHILE /
  LOOP / REPEAT / CASE / nested BEGIN, LET, RETURN, RAISE, EXECUTE ...) and its ``declare`` / ``exception`` nodes are
  parsed here into a small statement tree.
- Every embedded SQL statement or expression goes through ``Services.statement`` (the pack's own statement
  translation: ``translate.tier0_unit``: sqlglot + rules + post-pass + validators + residue guard), so the semantic
  rules apply inside procedure bodies exactly as they do to a view. Names, types and rules are NOT duplicated here.
- Nothing is guessed: any construct not understood raises ``ScriptingUnsupported(reason, line)``; the caller turns it
  into a precise flag (the unit stays with the reviewer / the later tiers).
- Not ported: sequences / identity read-back (S8) and the Delta-history row counts (R2/R3): they need table DDL the
  procedure path does not have. ``.NEXTVAL`` therefore stays a residue token and is flagged.

Review caveat ids this module can add (``CAVEATS``): the catalogue's ``SNW-TXN`` and ``SNW-EXEC-AS`` plus the
scripting ids below (migrator-only, severity review; to be listed in ``caveats.yaml``).
"""
from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field

from packs.snowflake.dml_shapes import DML, NotCountable, count_query
from packs.snowflake.scripting import ScriptNode
from packs.snowflake.sqlscan import split_top

#: review caveat id -> what it tells the reviewer
CAVEATS: dict[str, str] = {
    "SNW-SCRIPTING": "Snowflake Scripting converted to Databricks SQL scripting: not proven to run until executed on "
                     "the target (labels, handlers, variable scoping)",
    "SNW-SCRIPT-ROWCOUNT": "SQLROWCOUNT / SQLFOUND / SQLNOTFOUND read from a count taken just before the statement",
    "SNW-SCRIPT-RETURN": "RETURN converted to an OUT-parameter twin (<name>__ret) and a one-row result, or a final "
                         "result set for RETURNS TABLE; callers must be adapted",
    "SNW-SCRIPT-HANDLER": "EXCEPTION handler mapped to DECLARE EXIT HANDLER; Snowflake error names / codes are not preserved",
    "SNW-SCRIPT-SEMANTICS": "construct whose behaviour differs on Databricks in a small, documented way (see notes)",
    "SNW-SCRIPT-REFACTOR": "REF001: a row-by-row cursor loop was replaced by one set-based statement (proof in notes)",
    "SNW-TXN": "BEGIN / COMMIT removed: Delta has no multi-statement transactions, each statement commits on its own",
    "SNW-EXEC-AS": "EXECUTE AS: Databricks procedures run with SQL SECURITY INVOKER",
}


class ScriptingUnsupported(Exception):
    def __init__(self, reason: str, line: int | None = None):
        super().__init__(reason if line is None else f"{reason} (procedure body line {line})")
        self.reason, self.line = reason, line


# ---------------------------------------------------------------- types (ported from SNF2DBX converters/types.py)
_SIMPLE: dict[str, tuple[str, str | None]] = {
    "VARCHAR": ("STRING", None), "STRING": ("STRING", None), "TEXT": ("STRING", None),
    "CHAR": ("STRING", "CHAR padding semantics differ; mapped to STRING"),
    "CHARACTER": ("STRING", "CHAR padding semantics differ; mapped to STRING"),
    "NCHAR": ("STRING", None), "NVARCHAR": ("STRING", None), "NVARCHAR2": ("STRING", None),
    "CHARACTER VARYING": ("STRING", None),
    "BOOLEAN": ("BOOLEAN", None), "DATE": ("DATE", None),
    "DATETIME": ("TIMESTAMP_NTZ", None), "TIMESTAMP": ("TIMESTAMP_NTZ", None), "TIMESTAMP_NTZ": ("TIMESTAMP_NTZ", None),
    "TIMESTAMP_LTZ": ("TIMESTAMP", "TIMESTAMP_LTZ -> TIMESTAMP uses the Spark session time zone"),
    "TIMESTAMP_TZ": ("TIMESTAMP", "TIMESTAMP_TZ offset is not stored in Delta; values normalized to UTC"),
    "TIME": ("STRING", "Databricks has no TIME type; stored as STRING HH:MM:SS"),
    "FLOAT": ("DOUBLE", None), "FLOAT4": ("DOUBLE", None), "FLOAT8": ("DOUBLE", None), "DOUBLE": ("DOUBLE", None),
    "DOUBLE PRECISION": ("DOUBLE", None), "REAL": ("DOUBLE", None),
    "INT": ("DECIMAL(38,0)", None), "INTEGER": ("DECIMAL(38,0)", None), "BIGINT": ("DECIMAL(38,0)", None),
    "SMALLINT": ("DECIMAL(38,0)", None), "TINYINT": ("DECIMAL(38,0)", None), "BYTEINT": ("DECIMAL(38,0)", None),
    "BINARY": ("BINARY", None), "VARBINARY": ("BINARY", None),
    "VARIANT": ("VARIANT", "VARIANT needs a runtime with the VARIANT type"),
}


def map_type(sf: str) -> tuple[str, str | None]:
    """Snowflake type text -> ``(Databricks type, risk note or None)``; an unknown type raises (never a default)."""
    t = re.sub(r"\s+", " ", sf.strip().upper())
    m = re.match(r"^(NUMBER|NUMERIC|DECIMAL|DEC)\s*(?:\(\s*(\d+)\s*(?:,\s*(\d+))?\s*\))?$", t)
    if m:
        return f"DECIMAL({min(int(m.group(2) or 38), 38)},{int(m.group(3) or 0)})", None
    m = re.match(r"^(VARCHAR|STRING|TEXT|CHAR|CHARACTER|NCHAR|NVARCHAR|NVARCHAR2|CHARACTER VARYING|BINARY|VARBINARY)"
                 r"\s*\(\s*\d+\s*\)$", t)
    if m:
        return _SIMPLE[m.group(1)]
    m = re.match(r"^(TIMESTAMP(?:_NTZ|_LTZ|_TZ)?|DATETIME|TIME)\s*\(\s*(\d)\s*\)$", t)
    if m:
        dbx, risk = _SIMPLE[m.group(1)]
        if int(m.group(2)) > 6 and dbx.startswith("TIMESTAMP"):
            risk = (risk + "; " if risk else "") + "nanosecond precision truncated to microseconds"
        return dbx, risk
    if t in _SIMPLE:
        return _SIMPLE[t]
    raise ScriptingUnsupported(f"type {sf.strip()!r} has no deterministic Databricks mapping in a procedure")


# ---------------------------------------------------------------- tokens
_TOKEN = re.compile(r"""
    (?P<ws>\s+)
  | (?P<comment>--[^\n]*|//[^\n]*|/\*.*?\*/)
  | (?P<str>'(?:[^'\\]|''|\\.)*')
  | (?P<dollar>\$\$.*?\$\$)
  | (?P<qid>"(?:[^"]|"")*")
  | (?P<word>[A-Za-z_][\w$]*)
  | (?P<num>\d+(?:\.\d+)?)
  | (?P<op>:=|::|<=|>=|<>|!=|\|\|)
  | (?P<ch>.)
""", re.S | re.X)


@dataclass
class Tok:
    kind: str
    text: str
    start: int
    end: int

    @property
    def up(self) -> str:
        return self.text.upper() if self.kind == "word" else self.text


def tokenize(text: str) -> list[Tok]:
    out = []
    for m in _TOKEN.finditer(text):
        kind = m.lastgroup
        if kind in ("ws", "comment"):
            continue
        out.append(Tok(kind, m.group(0), m.start(), m.end()))
    return out


# ---------------------------------------------------------------- tree
@dataclass
class Node:
    kind: str
    line: int
    a: dict = field(default_factory=dict)


@dataclass
class Block:
    decls: list[Node]
    stmts: list[Node]
    handlers: list[tuple[list[str], list[Node]]]
    line: int


STOP = {"END", "ELSE", "ELSEIF", "WHEN", "UNTIL", "EXCEPTION"}
_LABELLED = {"FOR", "WHILE", "LOOP", "REPEAT", "BEGIN", "DECLARE"}


class Parser:
    def __init__(self, text: str):
        self.text, self.toks, self.i = text, tokenize(text), 0

    # -- helpers
    def line(self, tok: Tok | None = None) -> int:
        tok = tok or self.peek() or (self.toks[-1] if self.toks else None)
        return self.text.count("\n", 0, tok.start) + 1 if tok else 1

    def peek(self, k: int = 0) -> Tok | None:
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else None

    def up(self, k: int = 0) -> str:
        t = self.peek(k)
        return t.up if t else ""

    def take(self) -> Tok:
        t = self.peek()
        if t is None:
            raise ScriptingUnsupported("Unexpected end of procedure body", self.line())
        self.i += 1
        return t

    def expect(self, *words: str) -> Tok:
        t = self.take()
        if t.up not in words:
            raise ScriptingUnsupported(f"Expected {' or '.join(words)} but found '{t.text}'", self.line(t))
        return t

    def accept(self, *words: str) -> bool:
        if self.up() in words:
            self.i += 1
            return True
        return False

    def until(self, stops: set[str], allow_end: bool = False) -> str:
        """Source text up to (not including) a stop token at paren depth 0."""
        depth, first = 0, self.peek()
        if first is None:
            raise ScriptingUnsupported("Unexpected end of procedure body", self.line())
        last = None
        while True:
            t = self.peek()
            if t is None:
                if allow_end:
                    break
                raise ScriptingUnsupported(f"Missing {' or '.join(sorted(stops))}", self.line(first))
            if depth == 0 and t.up in stops:
                break
            if t.text == "(":
                depth += 1
            elif t.text == ")":
                depth -= 1
            last = self.take()
        if last is None:
            raise ScriptingUnsupported(f"Empty expression before '{self.peek().text}'", self.line(first))
        return self.text[first.start:last.end].strip()

    def semi(self):
        self.expect(";")

    # -- grammar
    def block(self) -> Block:
        line = self.line()
        decls = []
        if self.accept("DECLARE"):
            while self.up() != "BEGIN":
                decls.append(self.decl())
        self.expect("BEGIN")
        stmts = self.stmts()
        handlers = []
        if self.accept("EXCEPTION"):
            while self.accept("WHEN"):
                names = [self.take().text.strip('"')]
                while self.accept("OR"):
                    names.append(self.take().text.strip('"'))
                self.expect("THEN")
                handlers.append((names, self.stmts()))
        self.expect("END")
        if self.peek() and self.peek().kind == "word" and self.up() not in STOP:
            self.take()  # optional block label
        self.accept(";")
        return Block(decls, stmts, handlers, line)

    def decl(self, let: bool = False) -> Node:
        line = self.line()
        name = self.take()
        if name.kind not in ("word", "qid"):
            raise ScriptingUnsupported(f"Invalid variable name '{name.text}'", line)
        var = name.text.strip('"')
        if self.accept("CURSOR"):
            self.expect("FOR")
            query = self.until({";"})
            self.semi()
            return Node("cursor", line, {"name": var, "query": query})
        if self.accept("RESULTSET"):
            query = None
            if self.accept("DEFAULT", ":="):
                query = self.until({";"})
            self.semi()
            return Node("resultset", line, {"name": var, "query": query})
        if self.accept("EXCEPTION"):
            message = None
            if self.accept("("):
                self.until({","})
                self.expect(",")
                message = self.until({")"})
                self.expect(")")
            self.semi()
            return Node("exception", line, {"name": var, "message": message})
        dtype = None
        if self.up() not in ("DEFAULT", ":=", ";"):
            dtype = self.until({"DEFAULT", ":=", ";"})
        value = None
        if self.accept("DEFAULT", ":="):
            value = self.until({";"})
        self.semi()
        if dtype is None and value is None:
            raise ScriptingUnsupported(f"Variable {var} needs a type or default value", line)
        return Node("var", line, {"name": var, "type": dtype, "value": value, "let": let})

    def stmts(self) -> list[Node]:
        out = []
        while self.peek() is not None and self.up() not in STOP:
            out.append(self.stmt())
        return out

    def loop_end(self, *words: str) -> str | None:
        self.expect("END")
        self.expect(*words)
        label = None
        if self.peek() and self.peek().kind == "word":
            label = self.take().text
        self.semi()
        return label

    def stmt(self) -> Node:
        t, line, kw = self.peek(), self.line(), self.up()
        nxt = self.up(1)
        if t is not None and t.kind == "word" and nxt == ":" and self.up(2) in _LABELLED:
            label = self.take().text      # `lbl: FOR ...` (the splitter keeps the label with its block)
            self.take()
            node = self.stmt()
            if node.kind in ("while", "repeat", "loop", "for_range", "for_cursor", "block"):
                node.a["label"] = node.a.get("label") or label
            return node
        if (kw == "BEGIN" and nxt in ("TRANSACTION", "WORK", "NAME")) or (kw == "START" and nxt == "TRANSACTION"):
            self.until({";"})
            self.semi()
            return Node("txn", line, {"what": "BEGIN TRANSACTION"})
        if kw in ("BEGIN", "DECLARE"):
            return Node("block", line, {"block": self.block()})
        if kw == "LET":
            self.take()
            return self.decl(let=True)
        if kw == "IF":
            self.take()
            branches = []
            cond = self.until({"THEN"})
            self.expect("THEN")
            branches.append((cond, self.stmts()))
            other = None
            while True:
                if self.accept("ELSEIF"):
                    cond = self.until({"THEN"})
                    self.expect("THEN")
                    branches.append((cond, self.stmts()))
                elif self.accept("ELSE"):
                    other = self.stmts()
                else:
                    break
            self.expect("END")
            self.expect("IF")
            self.semi()
            return Node("if", line, {"branches": branches, "else": other})
        if kw == "CASE":
            self.take()
            subject = None if self.up() == "WHEN" else self.until({"WHEN"})
            whens, other = [], None
            while self.accept("WHEN"):
                value = self.until({"THEN"})
                self.expect("THEN")
                whens.append((value, self.stmts()))
            if self.accept("ELSE"):
                other = self.stmts()
            self.expect("END")
            self.accept("CASE")
            self.semi()
            return Node("case", line, {"subject": subject, "whens": whens, "else": other})
        if kw == "WHILE":
            self.take()
            cond = self.until({"DO", "LOOP"})
            self.take()
            body = self.stmts()
            label = self.loop_end("WHILE", "LOOP")
            return Node("while", line, {"cond": cond, "body": body, "label": label})
        if kw == "REPEAT":
            self.take()
            body = self.stmts()
            self.expect("UNTIL")
            cond = self.until({"END"})
            label = self.loop_end("REPEAT")
            return Node("repeat", line, {"cond": cond, "body": body, "label": label})
        if kw == "LOOP":
            self.take()
            body = self.stmts()
            label = self.loop_end("LOOP")
            return Node("loop", line, {"body": body, "label": label})
        if kw == "FOR":
            self.take()
            var = self.take().text.strip('"')
            self.expect("IN")
            reverse = self.accept("REVERSE")
            source = self.until({"TO", "DO", "LOOP"})
            if self.accept("TO"):
                upper = self.until({"DO", "LOOP"})
                self.take()
                body = self.stmts()
                label = self.loop_end("FOR", "LOOP")
                return Node("for_range", line, {"var": var, "lo": source, "hi": upper, "reverse": reverse, "body": body, "label": label})
            self.take()
            body = self.stmts()
            label = self.loop_end("FOR", "LOOP")
            return Node("for_cursor", line, {"var": var, "source": source, "body": body, "label": label})
        if kw in ("BREAK", "EXIT", "CONTINUE", "ITERATE"):
            self.take()
            label = self.take().text if self.up() != ";" else None
            self.semi()
            return Node("break" if kw in ("BREAK", "EXIT") else "continue", line, {"label": label})
        if kw == "RETURN":
            self.take()
            if self.up() == "TABLE" and self.up(1) == "(":
                self.take()
                self.expect("(")
                source = self.until({")"})
                self.expect(")")
                self.semi()
                return Node("return_table", line, {"source": source})
            value = None if self.up() == ";" else self.until({";"})
            self.semi()
            return Node("return", line, {"value": value})
        if kw == "RAISE":
            self.take()
            name = None if self.up() == ";" else self.take().text.strip('"')
            self.semi()
            return Node("raise", line, {"name": name})
        if kw in ("OPEN", "FETCH", "CLOSE"):
            raise ScriptingUnsupported(f"Explicit cursor {kw} is not converted; use FOR <record> IN <cursor> DO", line)
        if kw == "EXECUTE" and nxt == "IMMEDIATE":
            self.take(), self.take()
            sql = self.until({"USING", ";"})
            using = None
            if self.accept("USING"):
                using = self.until({";"})
            self.semi()
            return Node("execute", line, {"sql": sql, "using": using})
        if kw in ("COMMIT", "ROLLBACK"):
            self.until({";"})
            self.semi()
            return Node("txn", line, {"what": kw})
        if kw == "NULL" and nxt == ";":
            self.take(), self.take()
            return Node("noop", line)
        if t.kind in ("word", "qid") and nxt == ":=":
            name = self.take().text.strip('"')
            self.take()
            value = self.until({";"})
            self.semi()
            return Node("assign", line, {"name": name, "value": value})
        if t.kind == "ch" and t.text == ";":
            self.take()
            return Node("noop", line)
        sql = self.until({";"}, allow_end=True)
        self.accept(";")
        return Node("sql", line, {"sql": sql})


# ---------------------------------------------------------------- emit
_BIND = re.compile(r"(?<![:\w]):([A-Za-z_][\w$]*)")
_SYSTEM_WAIT = re.compile(r"^\s*(?:CALL|SELECT)\s+SYSTEM\$WAIT\s*\(", re.I)
_SELECT_INTO = re.compile(r"^\s*SELECT\b", re.I)
_CALL = r"^\s*CALL\s+((?:\"[^\"]+\"|[\w$]+)(?:\s*\.\s*(?:\"[^\"]+\"|[\w$]+)){0,2})\s*\((.*)\)\s*(INTO\b.*)?$"
_ROWCOUNT = re.compile(r"\b(SQLROWCOUNT|SQLFOUND|SQLNOTFOUND)\b", re.I)
_ROWCOUNT_AS = {"SQLROWCOUNT": "rowcount_", "SQLFOUND": "(rowcount_ > 0)", "SQLNOTFOUND": "(rowcount_ = 0)"}
# A scalar procedure P is emitted as P__ret(args, OUT return_value) plus P(args) returning a one-row result.
RET_SUFFIX = "__ret"


def _outside_strings(text: str, fn) -> str:
    """Apply fn to segments outside '...' literals."""
    parts = re.split(r"('(?:[^'\\]|''|\\.)*')", text)
    return "".join(p if i % 2 else fn(p) for i, p in enumerate(parts))


@dataclass
class Scope:
    names: set[str] = field(default_factory=set)
    queries: dict[str, str] = field(default_factory=dict)  # cursor/resultset -> query
    conditions: dict[str, tuple[str, str]] = field(default_factory=dict)  # exception -> (sqlstate, message)


@dataclass
class Translated:
    sql: str
    review: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)


@dataclass
class Services:
    """What the emitter needs from the pack: the statement translation and callee resolution. ``statement`` takes ONE
    Snowflake statement (binds already turned into variable names) and returns Databricks text, or raises
    ``ScriptingUnsupported`` with the precise reason. ``call_target`` maps a CALL's name text to
    ``{db, schema, name, target}`` or None when it cannot be resolved (a ``SYSTEM$`` procedure, an unknown schema)."""
    statement: Callable[[str], Translated]
    call_target: Callable[[str], dict | None]
    #: X6: FQN of the runtime transpile function (dynamic_sql.shim_function_ddl); None = run-time EXECUTE IMMEDIATE is
    #: not converted (the unit escalates)
    dynamic_shim: str | None = None


class Emitter:
    def __init__(self, services: Services, returns: str | None, params: list[str], procedures: dict | None = None):
        self.services = services
        self.notes: list[tuple[str, str]] = []
        self.review: set[str] = set()
        self.caveats: set[str] = set()
        # SOURCE FQN (upper) -> scalar return type, for procedures converted with a <name>__ret OUT-parameter twin
        self.procedures = {key.upper(): value for key, value in (procedures or {}).items()}
        self.rowcount = False  # rowcount_ holds the row count of the last DML statement emitted
        self.need_rowcount = False
        self.deferred: list[str] = []  # CALLs from DECLARE defaults; they run after the block's declarations
        self.deferred_vars: list[str] = []
        self.table = bool(returns and re.match(r"TABLE\b", returns, re.I))
        self.scopes = [Scope(names={p.upper() for p in params})]
        self.loops: list[tuple[str, str, str]] = []  # (label, break_stmt, continue_stmt)
        self.labels = 0
        self.states = 0
        self.need_noop = False
        self.renames: dict[str, str] = {}
        self.in_handler = 0
        self.handler_outer = False
        self.returned_table = False
        self.script = False
        self.branches = 0
        self.tail = True  # the statement being emitted is the last one the procedure runs
        self.unread: set[str] = set()  # dynamic-SQL RESULTSETs not yet consumed

    # -- helpers
    def note(self, code: str, message: str):
        """``code`` is a review caveat id (``CAVEATS``): it is added to the unit's review caveats."""
        self.review.add(code)
        if (code, message) not in self.notes:
            self.notes.append((code, message))

    def label(self, prefix: str) -> str:
        self.labels += 1
        return f"{prefix}{self.labels}"

    def known(self, name: str) -> bool:
        return any(name.upper() in scope.names for scope in self.scopes)

    def lookup(self, name: str, key: str):
        for scope in reversed(self.scopes):
            value = getattr(scope, key).get(name.upper())
            if value is not None:
                return value
        return None

    def prep(self, text: str) -> str:
        def fix(segment):
            segment = _BIND.sub(r"\1", segment)
            for old, new in self.renames.items():
                segment = re.sub(rf"\b{old}\b", new, segment, flags=re.I)
            if self.rowcount:
                segment = _ROWCOUNT.sub(lambda m: _ROWCOUNT_AS[m.group(1).upper()], segment)
            return segment
        return _outside_strings(text, fix)

    def depth(self) -> tuple:
        return self.branches, len(self.loops), self.in_handler

    # -- SQLROWCOUNT / SQLFOUND / SQLNOTFOUND: count the rows just before the statement that changes them
    @staticmethod
    def reads_rowcount(nodes: list[Node]) -> bool:
        """Do the statements after a DML read its row count before the next statement that changes it?"""
        for node in nodes:
            if node.kind == "execute":
                return False
            for text in Emitter._texts([node]):
                if _ROWCOUNT.search(text):
                    return True
                if DML.match(text) or re.match(r"\s*CALL\b", text, re.I):
                    return False
        return False

    def counted(self, node: Node, nodes_after: list[Node]) -> list[str]:
        """Emit a DML node; when its row count is read later, put it in rowcount_ (R2: from the commit the statement
        just made, so the work is not repeated; otherwise by counting the rows just before it runs)."""
        text = node.a["sql"]
        need = self.reads_rowcount(nodes_after)
        before = []
        if need:
            try:
                query = count_query(text)
            except NotCountable as reason:
                raise ScriptingUnsupported(f"SQLROWCOUNT / SQLFOUND / SQLNOTFOUND read after this statement: {reason}",
                                           node.line) from None
            self.need_rowcount = True
            before = ["SET rowcount_ = ("] + self.indent(self.sql(query, node.line).splitlines()) + [");"]
            self.note("SNW-SCRIPT-ROWCOUNT", "SQLROWCOUNT / SQLFOUND / SQLNOTFOUND: rowcount_ counts the rows just before the "
                                "statement runs (MERGE: rows in its source), because Databricks SQL scripting has no "
                                "SQLROWCOUNT. Verify the count where it drives logic")
        out = before + self.stmt(node, last=self.tail)
        self.rowcount = need
        return out

    def sql(self, text: str, line: int) -> str:
        """One Snowflake statement -> Databricks text (the pack's statement translation), no trailing ``;``."""
        try:
            out = self.services.statement(self.prep(text))
        except ScriptingUnsupported as error:
            raise ScriptingUnsupported(error.reason, line) from None
        self.review.update(out.review)
        self.caveats.update(out.caveats)
        return out.sql.rstrip(";").rstrip()

    def expr(self, text: str, line: int) -> str:
        out = self.sql("SELECT " + text, line)
        m = re.match(r"\s*SELECT\s+(.*)$", out, re.I | re.S)
        if not m:
            raise ScriptingUnsupported("an expression did not translate to a single SELECT item", line)
        return m.group(1)

    def dtype(self, text: str) -> str:
        target, risk = map_type(text.strip())
        if risk:
            self.note("SNW-SCRIPT-SEMANTICS", f"{text.strip()} -> {target}: {risk}")
        return target

    @staticmethod
    def indent(lines: list[str], n: int = 1) -> list[str]:
        pad = "  " * n
        return [pad + line if line else line for line in lines]

    # -- blocks
    def block(self, block: Block, label: str | None = None, outer: bool = False) -> list[str]:
        scope = Scope()
        self.scopes.append(scope)
        try:
            head, body = [], []
            for decl in block.decls:
                # CALL/DML from declarations runs as statements, in source order; Databricks needs all DECLAREs first.
                lines = self.declare(decl, scope)
                if decl.kind == "resultset":
                    self.deferred += lines
                else:
                    head += lines
            ran, self.deferred, self.deferred_vars = self.deferred, [], []
            handlers, covered = [], set()
            for names, stmts in block.handlers:
                handlers += self.handler(names, stmts, block.line, outer, covered)
            body = ran + self.stmts(block.stmts)
            lines = [(label + ": " if label else "") + "BEGIN"] + self.indent(head + handlers + (body or self.noop())) + \
                    ["END" + (" " + label if label else "") + ";"]
            return lines
        finally:
            self.scopes.pop()

    def declare(self, node: Node, scope: Scope) -> list[str]:
        a, name = node.a, node.a["name"]
        if node.kind == "cursor":
            scope.queries[name.upper()] = a["query"]
            return []
        if node.kind == "resultset":
            if a["query"] is None:
                scope.queries[name.upper()] = ""  # filled by a later `name := (...)`
                return []
            scope.queries[name.upper()] = ""
            out = self.bind_resultset(name, a["query"], node.line, scope)
            if not out:
                self.note("SNW-SCRIPT-SEMANTICS", f"RESULTSET {name} is evaluated where it is used, not where it is declared; verify no intervening data changes")
            return out
        if node.kind == "exception":
            self.states += 1
            state = f"45{self.states:03d}"
            message = a["message"] or f"'{name}'"
            scope.conditions[name.upper()] = (state, message)
            self.note("SNW-SCRIPT-HANDLER", f"Exception {name} mapped to SQLSTATE {state}; Snowflake exception numbers are not preserved")
            return [f"DECLARE {name} CONDITION FOR SQLSTATE '{state}';"]
        scope.names.add(name.upper())
        parts = [f"DECLARE {name}"]
        call = self.parse_call(a["value"]) if a["value"] is not None else None
        if call:
            fqn = call[0]
            dtype = a["type"] or self.procedures.get(fqn.upper())
            if not dtype:
                raise ScriptingUnsupported(f"Variable {name} takes the return value of {fqn}; include {fqn} in the conversion so its type and OUT-parameter twin are known", node.line)
            self.deferred += self.call_into(name, a["value"], node.line)
            self.deferred_vars.append(name)
            return [f"DECLARE {name} {self.dtype(dtype)};"]
        if a["value"] is not None and self.deferred and any(
                re.search(rf"\b{re.escape(pending)}\b", a["value"], re.I) for pending in self.deferred_vars):
            raise ScriptingUnsupported(f"Default of {name} uses a variable filled by an earlier CALL in the same DECLARE section", node.line)
        if a["type"]:
            parts.append(self.dtype(a["type"]))
        if a["value"] is not None:
            parts.append("DEFAULT " + self.expr(a["value"], node.line))
        return [" ".join(parts) + ";"]

    def handler(self, names: list[str], stmts: list[Node], line: int, outer: bool, covered: set[str]) -> list[str]:
        conditions = []
        for name in names:
            if name.upper() in ("OTHER", "STATEMENT_ERROR", "EXPRESSION_ERROR"):
                if name.upper() != "OTHER":
                    self.note("SNW-SCRIPT-HANDLER", f"{name.upper()} handler mapped to SQLEXCEPTION (covers all errors)")
                if "SQLEXCEPTION" not in conditions:
                    conditions.append("SQLEXCEPTION")
            elif self.lookup(name, "conditions"):
                conditions.append(name)
            else:
                raise ScriptingUnsupported(f"Exception handler for undeclared exception {name}", line)
        for condition in conditions:
            if condition.upper() in covered:
                raise ScriptingUnsupported(
                    f"exception handlers for {', '.join(names)} and an earlier handler of the block both map to "
                    f"{condition}: Databricks cannot tell Snowflake's OTHER / STATEMENT_ERROR / EXPRESSION_ERROR apart, "
                    "so which handler runs would change", line)
            covered.add(condition.upper())
        text = " ".join(self._texts(stmts)).upper()
        used = {key: bool(re.search(rf"\b{key}\b", text)) for key in ("SQLERRM", "SQLSTATE", "SQLCODE")}
        saved = dict(self.renames), self.handler_outer
        self.renames.update({"SQLERRM": "err_message", "SQLSTATE": "err_state", "SQLCODE": "err_code"})
        self.in_handler += 1
        self.handler_outer = outer
        try:
            inner = []
            diagnostics = []
            if used["SQLERRM"]:
                inner.append("DECLARE err_message STRING;")
                diagnostics.append("err_message = MESSAGE_TEXT")
            if used["SQLSTATE"]:
                inner.append("DECLARE err_state STRING;")
                diagnostics.append("err_state = RETURNED_SQLSTATE")
            if used["SQLCODE"]:
                inner.append("DECLARE err_code INT;")
                self.note("SNW-SCRIPT-HANDLER", "SQLCODE has no Databricks equivalent; err_code is NULL. Use err_state (SQLSTATE) instead")
            if diagnostics:
                inner.append("GET DIAGNOSTICS CONDITION 1 " + ", ".join(diagnostics) + ";")
            inner += self.stmts(stmts) or self.noop()
        finally:
            self.in_handler -= 1
            self.renames, self.handler_outer = saved
        return [f"DECLARE EXIT HANDLER FOR {', '.join(conditions)}", "BEGIN"] + self.indent(inner) + ["END;"]

    @staticmethod
    def _texts(nodes) -> list[str]:
        out = []
        for node in nodes:
            for value in node.a.values():
                if isinstance(value, str):
                    out.append(value)
                elif isinstance(value, list):
                    for item in value:
                        if isinstance(item, Node):
                            out += Emitter._texts([item])
                        elif isinstance(item, tuple):
                            out += [part for part in item if isinstance(part, str)]
                            out += Emitter._texts([n for part in item if isinstance(part, list) for n in part])
                elif isinstance(value, Block):
                    out += Emitter._texts(value.stmts)
        return out

    _DYNAMIC = "\x00EXEC:"  # marks a RESULTSET filled by EXECUTE IMMEDIATE
    _RAN = "\x00RAN:"  # marks a RESULTSET whose CALL/DML already ran at its source position

    def bind_resultset(self, name: str, value: str, line: int, scope: Scope | None = None) -> list[str]:
        """Record what a RESULTSET holds; statements with side effects run here, at their source position."""
        text = re.sub(r"^\(\s*|\s*\)$", "", value.strip())
        out = []
        if re.match(r"(SELECT|WITH)\b", text, re.I):
            stored = text
        elif re.match(r"EXECUTE\s+IMMEDIATE\b", text, re.I):
            stored = self._DYNAMIC + text
            self.unread.add(name.upper())
        elif re.match(r"(CALL|INSERT|UPDATE|DELETE|MERGE)\b", text, re.I):
            out = self.sql_statement(text, line)
            stored = self._RAN + text.split()[0].upper()
        else:
            raise ScriptingUnsupported(f"RESULTSET {name} assigned something other than a query or CALL", line)
        targets = [scope] if scope else [s for s in reversed(self.scopes) if name.upper() in s.queries][:1]
        for target in targets:
            target.queries[name.upper()] = stored
        return out

    def assign_resultset(self, name: str, value: str, line: int) -> list[str]:
        side_effect = re.match(r"\(?\s*(CALL|INSERT|UPDATE|DELETE|MERGE)\b", value.strip(), re.I)
        if not side_effect and (self.branches or self.loops or self.in_handler):
            raise ScriptingUnsupported(f"RESULTSET {name} assigned a query inside IF/CASE/loop/handler; which query it holds depends on runtime flow", line)
        return self.bind_resultset(name, value, line)

    def resultset_query(self, source: str, line: int) -> str | None:
        query = self.lookup(source, "queries")
        if query == "":
            raise ScriptingUnsupported(f"RESULTSET {source} is used before a query is assigned", line)
        if query and query.startswith(self._RAN):
            raise ScriptingUnsupported(f"RESULTSET {source} reads the result of a {query[len(self._RAN):]}; Databricks cannot capture that result in a variable", line)
        self.unread.discard(source.upper())
        return query

    def execute(self, sql: str, using: str | None, line: int) -> list[str]:
        sql = sql.strip()
        if re.fullmatch(r"'(?:[^'\\]|''|\\.)*'", sql, re.S):
            inner = sql[1:-1].replace("''", "'")
        elif re.fullmatch(r"\$\$.*\$\$", sql, re.S):
            inner = sql[2:-2].strip()
        elif self.services.dynamic_shim:
            args = ""
            if using:
                inner = re.sub(r"^\(\s*|\s*\)$", "", using.strip())
                args = " USING " + ", ".join(self.expr(arg, line) for arg in split_top(inner))
            self.review.add("SNW-DYNAMIC-SQL-SHIM")
            self.caveats.add("SNW-DYNAMIC-SQL-SHIM")
            return [f"EXECUTE IMMEDIATE {self.services.dynamic_shim}({self.expr(sql, line)}){args};"]
        else:
            raise ScriptingUnsupported(
                "EXECUTE IMMEDIATE of SQL text built at run time: that text is Snowflake SQL; only the runtime "
                "transpile shim (catalogue X6) can convert it: opt in with target.dynamic_sql_shim (the shim function "
                "name; dynamic_sql.shim_function_ddl builds it)", line)
        if re.match(r"\s*(?:BEGIN|DECLARE)\b", inner, re.I):
            raise ScriptingUnsupported("EXECUTE IMMEDIATE of a literal scripting block is not converted (inline the "
                                       "block, or convert it as its own procedure)", line)
        sql = "'" + self.sql(inner, line).replace("'", "''") + "'"
        args = ""
        if using:
            inner = re.sub(r"^\(\s*|\s*\)$", "", using.strip())
            args = " USING " + ", ".join(self.expr(arg, line) for arg in split_top(inner))
        return [f"EXECUTE IMMEDIATE {sql}{args};"]

    def call_args(self, text: str, line: int) -> str:
        return ", ".join(self.expr(arg, line) for arg in split_top(text)) if text.strip() else ""

    def resolve_call(self, name: str, line: int) -> dict:
        info = self.services.call_target(name)
        if info is None:
            why = "has no Databricks equivalent" if "$" in name else "cannot be resolved to a procedure of this account"
            raise ScriptingUnsupported(f"CALL {name} {why}", line)
        if info.get("notebook"):
            raise ScriptingUnsupported(
                f"CALL {name} is a JavaScript / Snowpark procedure converted to a notebook: a SQL script cannot run a "
                "notebook; run it as a notebook task of the calling job (before or after this procedure), or convert the "
                "caller to a notebook too", line)
        return info

    @staticmethod
    def callee_key(info: dict) -> str:
        return f"{info['db']}.{info['schema']}.{info['name']}".upper()

    def parse_call(self, value: str | None) -> tuple[str, dict, str] | None:
        """`(CALL db.s.p(args))` -> (SOURCE FQN key, resolved callee, args text), else None."""
        if not value:
            return None
        text = value.strip()
        if text.startswith("(") and text.endswith(")"):
            text = text[1:-1].strip()
        call = re.match(_CALL, text, re.I | re.S)
        if not call or call.group(3):
            return None
        info = self.resolve_call(call.group(1), 0)
        return self.callee_key(info), info, call.group(2)

    def call_into(self, var: str, value: str, line: int) -> list[str]:
        """Snowflake `var := (CALL p(...))`: Databricks returns values only through OUT parameters."""
        fqn, info, args = self.parse_call(value)
        if fqn.upper() not in self.procedures:
            raise ScriptingUnsupported(
                f"{var} takes the return value of {fqn}; Databricks procedures return values only through OUT parameters, "
                f"so {fqn} must be a SQL procedure with a scalar RETURNS type in the same conversion", line)
        target = info["target"] + RET_SUFFIX
        args = self.call_args(args, line)
        self.note("SNW-SCRIPT-RETURN", f"{var} receives {fqn}'s return value through the OUT parameter of {target}")
        return [f"CALL {target}({args + ', ' if args else ''}{var});"]

    def noop(self) -> list[str]:
        self.need_noop = True
        return ["SET noop_ = 0;"]

    def stmts(self, nodes: list[Node]) -> list[str]:
        out = []
        for index, node in enumerate(nodes):
            if node.kind == "var" and node.a.get("let"):
                if self.known(node.a["name"]) and not node.a["type"]:
                    out += self.stmt(Node("assign", node.line, {"name": node.a["name"], "value": node.a["value"]}))
                    continue
                # Databricks DECLARE must open a block; scope the rest of the list inside it.
                scope = Scope()
                self.scopes.append(scope)
                try:
                    decl = self.declare(node, scope)
                    decl, self.deferred, self.deferred_vars = decl + self.deferred, [], []
                    rest = self.stmts(nodes[index + 1:])
                finally:
                    self.scopes.pop()
                out += ["BEGIN"] + self.indent(decl + (rest or self.noop())) + ["END;"]
                return out
            if node.kind in ("cursor", "resultset", "exception"):
                scope = Scope()
                self.scopes.append(scope)
                try:
                    decl = self.declare(node, scope)
                    rest = self.stmts(nodes[index + 1:])
                finally:
                    self.scopes.pop()
                out += (["BEGIN"] + self.indent(decl + (rest or self.noop())) + ["END;"]) \
                    if node.kind != "resultset" and decl else decl + rest
                return out
            saved = self.tail
            self.tail = saved and index == len(nodes) - 1
            try:
                if node.kind == "sql" and DML.match(node.a["sql"]):
                    out += self.counted(node, nodes[index + 1:])
                else:
                    out += self.stmt(node, last=self.tail)
                    if node.kind == "execute" or any(DML.match(text) or re.match(r"\s*CALL\b", text, re.I)
                                                     for text in self._texts([node])):
                        self.rowcount = False  # a statement that changes rows ran (or may have run) since the count
            finally:
                self.tail = saved
        return out

    def loop(self, label: str | None, prefix: str, continue_stmt: str | None = None):
        label = label or self.label(prefix)
        self.loops.append((label, f"LEAVE {label};", continue_stmt or f"ITERATE {label};"))
        return label

    def stmt(self, node: Node, last: bool = False) -> list[str]:
        a, line = node.a, node.line
        kind = node.kind
        if kind == "block":
            return self.block(a["block"], label=a.get("label"))
        if kind == "assign":
            if self.lookup(a["name"], "queries") is not None and not self.known(a["name"]):
                return self.assign_resultset(a["name"], a["value"], line)
            if self.parse_call(a["value"]):
                return self.call_into(a["name"], a["value"], line)
            return [f"SET {a['name']} = {self.expr(a['value'], line)};"]
        if kind == "if":
            self.branches += 1
            try:
                out = []
                for index, (cond, body) in enumerate(a["branches"]):
                    out.append(("IF " if index == 0 else "ELSEIF ") + self.expr(cond, line) + " THEN")
                    out += self.indent(self.stmts(body) or self.noop())
                if a["else"] is not None:
                    out.append("ELSE")
                    out += self.indent(self.stmts(a["else"]) or self.noop())
            finally:
                self.branches -= 1
            return out + ["END IF;"]
        if kind == "case":
            self.branches += 1
            try:
                out = ["CASE" + (" " + self.expr(a["subject"], line) if a["subject"] else "")]
                for value, body in a["whens"]:
                    out.append("  WHEN " + self.expr(value, line) + " THEN")
                    out += self.indent(self.stmts(body) or self.noop(), 2)
                if a["else"] is not None:
                    out.append("  ELSE")
                    out += self.indent(self.stmts(a["else"]) or self.noop(), 2)
            finally:
                self.branches -= 1
            return out + ["END CASE;"]
        if kind in ("while", "repeat", "loop"):
            label = self.loop(a["label"], "loop_")
            try:
                body = self.stmts(a["body"]) or self.noop()
            finally:
                self.loops.pop()
            if kind == "while":
                return [f"{label}: WHILE {self.expr(a['cond'], line)} DO"] + self.indent(body) + [f"END WHILE {label};"]
            if kind == "repeat":
                return [f"{label}: REPEAT"] + self.indent(body) + [f"UNTIL {self.expr(a['cond'], line)}", f"END REPEAT {label};"]
            return [f"{label}: LOOP"] + self.indent(body) + [f"END LOOP {label};"]
        if kind == "for_range":
            var, step = a["var"], "-" if a["reverse"] else "+"
            label = a["label"] or self.label("loop_")
            inner = self.label("body_")
            end_var = f"{var}_end_"
            self.loops.append((label, f"LEAVE {label};", f"LEAVE {inner};"))
            self.scopes.append(Scope(names={var.upper(), end_var.upper()}))
            try:
                body = self.stmts(a["body"]) or self.noop()
            finally:
                self.loops.pop()
                self.scopes.pop()
            start, stop = (a["hi"], a["lo"]) if a["reverse"] else (a["lo"], a["hi"])
            compare = ">=" if a["reverse"] else "<="
            return (["BEGIN",
                     f"  DECLARE {var} BIGINT DEFAULT {self.expr(start, line)};",
                     f"  DECLARE {end_var} BIGINT DEFAULT {self.expr(stop, line)};",
                     f"  {label}: WHILE {var} {compare} {end_var} DO",
                     f"    {inner}: BEGIN"] + self.indent(body, 3) +
                    [f"    END {inner};", f"    SET {var} = {var} {step} 1;", f"  END WHILE {label};", "END;"])
        if kind == "for_cursor":
            source = a["source"].strip()
            query = self.resultset_query(source, line)
            if query and query.startswith(self._DYNAMIC):
                raise ScriptingUnsupported(f"FOR loop over dynamic-SQL RESULTSET {source}", line)
            if query is None:
                if re.match(r"^\(?\s*(SELECT|WITH)\b", source, re.I):
                    query = re.sub(r"^\(\s*|\s*\)$", "", source)
                else:
                    raise ScriptingUnsupported(f"FOR loop source {source} is not a declared cursor or RESULTSET", line)
            label = self.loop(a["label"], "loop_")
            self.scopes.append(Scope(names={a["var"].upper()}))
            try:
                body = self.stmts(a["body"]) or self.noop()
            finally:
                self.loops.pop()
                self.scopes.pop()
            return [f"{label}: FOR {a['var']} AS"] + self.indent(self.sql(query, line).splitlines(), 2) + \
                   ["DO"] + self.indent(body) + [f"END FOR {label};"]
        if kind in ("break", "continue"):
            if not self.loops:
                raise ScriptingUnsupported(f"{kind.upper()} outside a loop", line)
            target = None
            if a["label"]:
                target = next((loop for loop in reversed(self.loops) if loop[0].upper() == a["label"].upper()), None)
                if target is None:
                    raise ScriptingUnsupported(f"Unknown loop label {a['label']}", line)
            else:
                target = self.loops[-1]
            return [target[1] if kind == "break" else target[2]]
        if kind == "return":
            if self.script:
                raise ScriptingUnsupported("RETURN inside a task/script block has no Databricks equivalent", line)
            if self.table:
                raise ScriptingUnsupported("RETURN of a scalar in a RETURNS TABLE procedure", line)
            out = []
            if a["value"] is not None:
                out.append(f"SET return_value = {self.expr(a['value'], line)};")
            if self.in_handler and self.handler_outer:
                return out or self.noop()  # the EXIT handler already leaves the main block
            if self.in_handler:
                raise ScriptingUnsupported("RETURN inside an exception handler of a nested block", line)
            return out + ["LEAVE main;"]
        if kind == "return_table":
            source = a["source"].strip()
            match = re.match(r"^(?:RESULTSET_FROM_CURSOR\s*\(\s*)?([\w$\"]+)\s*\)?$", source, re.I)
            query = self.resultset_query(match.group(1).strip('"'), line) if match else None
            if query is None and re.match(r"^\(?\s*(SELECT|WITH)\b", source, re.I):
                query = re.sub(r"^\(\s*|\s*\)$", "", source)
            if query is None:
                raise ScriptingUnsupported(f"RETURN TABLE source {source} is not a declared RESULTSET or cursor", line)
            if not (last and not self.branches and not self.loops and not self.in_handler):
                raise ScriptingUnsupported("RETURN TABLE is only converted as the final statement of the procedure", line)
            self.returned_table = True
            if query.startswith(self._DYNAMIC):
                dynamic = re.match(r"EXECUTE\s+IMMEDIATE\s+(.*?)(?:\s+USING\s*(\(.*\)))?$", query[len(self._DYNAMIC):], re.I | re.S)
                self.note("SNW-SCRIPT-RETURN", "RETURN TABLE of dynamic SQL: the procedure returns the result of the final EXECUTE IMMEDIATE; verify on Databricks")
                return self.execute(dynamic.group(1), dynamic.group(2), line)
            return [self.sql(query, line) + ";"]
        if kind == "raise":
            if a["name"] is None:
                if not self.in_handler:
                    raise ScriptingUnsupported("RAISE without an exception outside a handler", line)
                return ["RESIGNAL;"]
            condition = self.lookup(a["name"], "conditions")
            if condition is None:
                raise ScriptingUnsupported(f"RAISE of undeclared exception {a['name']}", line)
            return [f"SIGNAL {a['name']} SET MESSAGE_TEXT = {condition[1]};"]
        if kind == "execute":
            return self.execute(a["sql"], a["using"], line)
        if kind == "txn":
            if a["what"] == "ROLLBACK":
                raise ScriptingUnsupported(
                    "ROLLBACK undoes the writes of the transaction; Delta has no multi-statement transactions, so the "
                    "writes before it would persist. Restructure (staging table + one MERGE / swap) or review by hand",
                    line)
            self.note("SNW-TXN", f"{a['what']} removed: Databricks SQL scripting does not run Snowflake multi-statement "
                                 "transactions; each statement commits on its own, so the group is no longer atomic")
            return []
        if kind == "noop":
            return []
        if kind == "sql":
            return self.sql_statement(a["sql"], line)
        if kind == "var":
            raise ScriptingUnsupported("Variable declaration in an unexpected position", line)
        raise ScriptingUnsupported(f"Unsupported statement {kind}", line)

    def sql_statement(self, text: str, line: int) -> list[str]:
        if _SYSTEM_WAIT.match(text):
            self.note("SNW-SCRIPT-SEMANTICS", "SYSTEM$WAIT removed: Databricks SQL has no sleep; use job task dependencies, retries or schedules instead")
            return []
        call = re.match(_CALL, text, re.I | re.S)
        if call:
            if call.group(3):
                into = re.fullmatch(r"INTO\s*:?\s*([A-Za-z_][\w$]*)\s*", call.group(3), re.I)
                if not into:
                    raise ScriptingUnsupported("CALL ... INTO must name a single variable", line)
                return self.call_into(into.group(1), text[:call.start(3)], line)
            info = self.resolve_call(call.group(1), line)
            return [f"CALL {info['target']}({self.call_args(call.group(2), line)});"]
        if _SELECT_INTO.match(text):
            converted = self.select_into(text, line)
            if converted:
                return converted
            self.note("SNW-SCRIPT-SEMANTICS", "A standalone SELECT inside the procedure now returns a result set to the caller; Snowflake discarded it")
        if re.match(r"^\s*(SHOW|DESCRIBE|DESC|USE|ALTER\s+(TASK|WAREHOUSE|SESSION)|GRANT|REVOKE)\b", text, re.I):
            raise ScriptingUnsupported(f"Snowflake administrative statement '{text.split()[0].upper()}' has no automatic Databricks equivalent", line)
        return [line_ + "" for line_ in (self.sql(text, line) + ";").splitlines()]

    def select_into(self, text: str, line: int) -> list[str] | None:
        visible = _outside_strings(text, lambda s: s)
        depth, into_at, end_at = 0, None, None
        for match in re.finditer(r"\(|\)|\bINTO\b|\b(FROM|WHERE|GROUP|ORDER|LIMIT|QUALIFY|HAVING|UNION)\b", visible, re.I):
            token = match.group(0).upper()
            if token == "(":
                depth += 1
            elif token == ")":
                depth -= 1
            elif depth == 0 and token == "INTO" and into_at is None:
                into_at = match
            elif depth == 0 and into_at is not None and end_at is None:
                end_at = match.start()
                break
        if into_at is None:
            return None
        targets = text[into_at.end():end_at].strip() if end_at else text[into_at.end():].strip()
        names = [self.prep(name).strip() for name in split_top(targets)]
        if not names or not all(re.fullmatch(r"[A-Za-z_][\w$]*", name) for name in names):
            raise ScriptingUnsupported("SELECT ... INTO targets must be variables", line)
        query = text[:into_at.start()] + (" " + text[end_at:] if end_at else "")
        converted = self.sql(query, line)
        self.note("SNW-SCRIPT-SEMANTICS", "SELECT ... INTO became SET ... = (SELECT ...): verify the no-row and several-row behaviour (Databricks: NULL for no rows, an error for several)")
        target = names[0] if len(names) == 1 else "(" + ", ".join(names) + ")"
        lines = converted.splitlines()
        return [f"SET {target} = ("] + self.indent(lines) + [");"]




# ---------------------------------------------------------------- tables a body reads and writes
_IDENT_RX = r'(?:"[^"]+"|[A-Za-z_][\w$]*)'
_TABLE_REF = re.compile(rf"\b(?:FROM|JOIN|INTO|UPDATE|MERGE\s+INTO|USING|TRUNCATE\s+TABLE|TABLE)\s+({_IDENT_RX}(?:\s*\.\s*{_IDENT_RX}){{0,2}})", re.I)
_NOT_A_TABLE = {"SELECT", "VALUES", "TABLE", "DUAL", "LATERAL", "IF", "THE"}


def table_refs(body: str) -> list[list[str]]:
    """Table names (1-3 parts, source spelling) a scripting body mentions after FROM / JOIN / INTO / UPDATE / MERGE
    INTO / USING / TRUNCATE TABLE, including the SQL text inside literal EXECUTE IMMEDIATE strings. A read-only
    helper for callers that need the table map of a procedure before translating it (the benchmark, a catalogue
    check); it never feeds the converter."""
    text = re.sub(r"--[^\n]*|/\*.*?\*/", " ", body, flags=re.S)
    found: list[list[str]] = []
    for m in _TABLE_REF.finditer(text):
        parts = [p.strip().strip('"') for p in re.findall(_IDENT_RX, m.group(1))]
        if parts and parts[-1].upper() not in _NOT_A_TABLE and parts not in found:
            found.append(parts)
    return found


# ---------------------------------------------------------------- the splitter's nodes -> the statement tree
def build_block(nodes: Sequence[ScriptNode]) -> Block:
    """The statement tree of a procedure body from the splitter's nodes (``split_scripting``).

    ``declare`` -> declarations (one per child), ``exception`` -> handlers, every other top-level node (a simple
    statement, a CALL, a whole IF / FOR / WHILE / LOOP / REPEAT / CASE / nested BEGIN, a LET / RETURN / RAISE ...) is
    parsed on its own, so the splitter's boundaries are the contract and the parser never reads past them."""
    decls: list[Node] = []
    stmts: list[Node] = []
    handlers: list[tuple[list[str], list[Node]]] = []
    for n in nodes:
        if n.kind == "declare":
            for child in n.children:
                decls.append(Parser(child + ";").decl())
        elif n.kind == "exception":
            parser = Parser(n.text.rstrip().rstrip(";") + ";")
            parser.expect("EXCEPTION")
            while parser.accept("WHEN"):
                names = [parser.take().text.strip('"')]
                while parser.accept("OR"):
                    names.append(parser.take().text.strip('"'))
                parser.expect("THEN")
                handlers.append((names, parser.stmts()))
            if parser.peek() is not None:
                raise ScriptingUnsupported(f"Unexpected text in the exception section: '{parser.peek().text}'")
        else:
            parser = Parser(n.text.rstrip().rstrip(";") + ";")
            node = parser.stmt()
            node.line = n.statement_index + 1
            if parser.peek() is not None:
                raise ScriptingUnsupported(f"Unexpected text after statement {n.statement_index + 1}: "
                                           f"'{parser.peek().text}'")
            stmts.append(node)
    return Block(decls, stmts, handlers, 1)


def walk(nodes: list[Node]):
    """Every statement node under ``nodes`` (branches, loop bodies, nested blocks, handlers)."""
    stack = list(nodes)
    while stack:
        item = stack.pop()
        yield item
        for key in ("body", "else"):
            if isinstance(item.a.get(key), list):
                stack += item.a[key]
        for key in ("branches", "whens"):
            for _, body in item.a.get(key) or []:
                stack += body
        if item.kind == "block":
            inner = item.a["block"]
            stack += inner.stmts + [n for _, stmts in inner.handlers for n in stmts]


def returns_value(block: Block) -> bool:
    return any(n.kind == "return" and n.a.get("value") is not None
               for n in walk(block.stmts + [n for _, stmts in block.handlers for n in stmts]))


def _check_unread(emitter: Emitter) -> None:
    if emitter.unread:
        raise ScriptingUnsupported(
            "EXECUTE IMMEDIATE stored in RESULTSET " + ", ".join(sorted(emitter.unread)) +
            " is never read; converting it would either drop or reorder that dynamic SQL", None)


@dataclass
class Converted:
    #: procedure: the statements between ``AS BEGIN`` and ``END``; script: the whole compound statement
    text: str
    notes: list[tuple[str, str]] = field(default_factory=list)
    review: list[str] = field(default_factory=list)
    returns: str = "none"                  # none | scalar | table
    return_type: str = ""                  # Databricks type of the scalar return
    return_assumed: bool = False           # the declared return type was not known (STRING assumed)
    refactored: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)      # the caveat ids the statements inside hit (catalogue scan)


def convert(nodes: Sequence[ScriptNode], services: Services, *, params: Sequence[str] = (), returns: str | None = None,
            script: bool = False, procedures: dict | None = None, refactor: bool = True,
            unique_keys: dict | None = None) -> Converted:
    """Splitter nodes -> Databricks SQL scripting. ``script`` = an anonymous block (a task body): ``RETURN`` is refused.
    Raises ``ScriptingUnsupported`` with the reason (and procedure-body line) for anything it does not understand."""
    block = build_block(nodes)
    notes: list[tuple[str, str]] = []
    if refactor and not script:
        from packs.snowflake.scripting_refactor import apply as refactor_block
        for note in refactor_block(block, unique_keys):
            code, _, message = note.partition("|")
            if code == "REF001":
                notes.append(("SNW-SCRIPT-REFACTOR", message))
            else:
                notes.append(("", message))                  # INFO: a loop kept as a loop, with the reason
    emitter = Emitter(services, returns, list(params), procedures)
    emitter.script = script
    for code, message in notes:
        if code:
            emitter.note(code, message)
    main = emitter.block(block, label="main", outer=True)
    _check_unread(emitter)
    head = (["DECLARE noop_ INT;"] if emitter.need_noop else []) +            (["DECLARE rowcount_ BIGINT DEFAULT 0;"] if emitter.need_rowcount else [])
    if emitter.table and not emitter.returned_table:
        raise ScriptingUnsupported("RETURNS TABLE procedure without a final RETURN TABLE(...)", None)
    scalar = (not script) and (not emitter.table) and returns_value(block)
    ret_type, assumed = "", False
    if scalar:
        if returns:
            ret_type = emitter.dtype(returns)
        else:
            ret_type, assumed = "STRING", True
            emitter.note("SNW-SCRIPT-RETURN", "the procedure's RETURNS type is not known: the return value is typed STRING")
    if scalar:
        emitter.note("SNW-SCRIPT-RETURN", "scalar RETURN: the value goes through the variable return_value (procedure form: the "
                                          "OUT parameter of <name>__ret, which <name> calls and returns as a one-row "
                                          "return_value result)")
    if emitter.table:
        emitter.note("SNW-SCRIPT-RETURN", "RETURNS TABLE: the procedure's final statement returns the result set; "
                                          "verify how callers read it")
    lines = head + main
    if script:
        lines = ["BEGIN"] + Emitter.indent(lines) + ["END;"] if head else main
    emitter.note("SNW-SCRIPTING", "Databricks SQL scripting needs a SQL warehouse / runtime that supports compound "
                                  "statements and procedures (profile flags sql_scripting / sql_procedures)")
    return Converted("\n".join(lines), [n for n in emitter.notes], sorted(emitter.review),
                     "table" if emitter.table else "scalar" if scalar else "none", ret_type, assumed,
                     [m for c, m in notes if not c], sorted(emitter.caveats))


__all__ = ["CAVEATS", "RET_SUFFIX", "Converted", "ScriptingUnsupported", "Services", "Translated", "build_block",
           "convert", "map_type", "returns_value", "table_refs", "walk"]
