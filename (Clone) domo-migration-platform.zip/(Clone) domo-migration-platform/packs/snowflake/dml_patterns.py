"""packs.snowflake.dml_patterns - statement patterns tier 0 converts across more than one statement (S8; catalogue 4.3,
6.5, 6.11; ADR 037 section 2, "tier 0 pattern across statements").

``detect(source, ctx, stream_base)`` is called by ``translate.tier0_unit`` before the generic transpile and returns a
``PatternResult`` or None (not one of these patterns):

* **multi-table INSERT** (4.3): ``INSERT ALL | FIRST [WHEN c THEN] INTO t [(cols)] [VALUES (...)] ... SELECT ...`` ->
  ``CREATE OR REPLACE TEMPORARY VIEW mti_<hash> AS <select>`` and one ``INSERT INTO t SELECT <values> FROM mti_<hash>
  WHERE <predicate>`` per target. ALL: each target's own predicate. FIRST: mutually exclusive predicates, each one
  ``c_i AND NOT COALESCE(c_j, FALSE)`` for every earlier ``j`` (a NULL condition is not true, so the row falls through
  exactly as in Snowflake), ELSE = no earlier condition true. Atomicity is lost (Snowflake loads all targets in one
  statement): ``SNW-MULTI-INSERT`` review and the reason says so. ``INSERT OVERWRITE ALL`` and a source column with no
  name escalate.
* **sequence in INSERT ... SELECT / VALUES** (6.11): one ``seq.NEXTVAL`` projected into one target column -> that column
  and projection are dropped (the target column is an identity column, ``objects.convert_sequence``),
  ``SNW-SEQ-IDENTITY``
  review; the column list comes from the INSERT or the batch's column catalogue, else escalate. A NEXTVAL anywhere else
  (WHERE, UPDATE, twice, in an expression) escalates with ``SNW-SEQ-SHARED`` and the options.
* **stream + MERGE -> AUTO CDC** (6.5): ``MERGE INTO tgt USING (SELECT ... [METADATA$ACTION AS a] FROM <stream>) ...``
  with
  key equalities in ON, at most one ``MATCHED AND a = 'DELETE' THEN DELETE``, one ``MATCHED THEN UPDATE SET <all
  columns>`` and one ``NOT MATCHED THEN INSERT`` -> ``CREATE OR REFRESH STREAMING TABLE tgt; AUTO CDC INTO tgt FROM
  STREAM(base) KEYS (...) APPLY AS DELETE WHEN _change_type = 'delete' SEQUENCE BY _commit_version COLUMNS * EXCEPT
  (...) STORED AS SCD TYPE 1`` (the form ``validators._AUTO_CDC`` accepts). ``SNW-AUTO-CDC`` review always: the exact
  syntax and the change-feed read are UNVERIFIED until the data tests run on Databricks (X5). A MERGE that does not fit
  the shape returns None and keeps the generic stream rewrite.

Nothing here guesses: a shape it cannot prove is returned as ``reasons`` (escalate) or as None.
"""
from __future__ import annotations

import dataclasses
import hashlib
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from packs.snowflake.postpass import Postpass, transpile
from packs.snowflake.validators import validate

_STREAM_META = re.compile(r"\bMETADATA\$ACTION\b", re.I)
SEQ_OPTIONS = ("one identity column per table (each table gets its own numbers)", "uuid() when the value is only a key",
               "a counter table updated in the same job", "row_number() over (...) + (SELECT max(...)) inside one "
               "writer, which races when two runs overlap")


@dataclass
class PatternResult:
    name: str
    #: finished Databricks text (one or more statements), when the pattern is converted completely
    sql: str = ""
    #: Snowflake text to continue through the generic tier 0 (a pre-rewrite)
    source: str = ""
    review: list[str] = field(default_factory=list)         # caveat ids to add as review
    reasons: list[str] = field(default_factory=list)        # non-empty: escalate with these reasons
    notes: list[str] = field(default_factory=list)          # reviewer-facing facts
    params: dict[str, Any] = field(default_factory=dict)
    draft: str = ""                                          # a partial answer offered to the reviewer


def _name(t: exp.Table) -> str:
    return ".".join(p for p in (t.catalog, t.db, t.name) if p)


def _sql(node: exp.Expression) -> str:
    return node.sql(dialect="snowflake")


# ------------------------------------------------------------------------------------------------ 4.3 multi-table INSERT  # noqa: E501
def multi_insert(tree: exp.MultitableInserts, ctx: Any, source_text: str) -> PatternResult:
    if tree.args.get("overwrite") or re.match(r"\s*INSERT\s+OVERWRITE\b", source_text, re.I):
        return PatternResult("multi_insert", reasons=["INSERT OVERWRITE ALL / FIRST: every target is overwritten once; "
                                                      "no deterministic rule for the overwrite + temp view order"])
    src = tree.args.get("source")
    if not isinstance(src, exp.Query):
        return PatternResult("multi_insert", reasons=["the multi-table INSERT has no SELECT source"])
    sel = src.this if isinstance(src, exp.Subquery) else src
    while isinstance(sel, exp.SetOperation):
        sel = sel.this
    names = [p.alias_or_name for p in getattr(sel, "expressions", [])] if isinstance(sel, exp.Select) else []
    if not names or any(not n for n in names) or len({n.lower() for n in names}) != len(names):
        return PatternResult("multi_insert", reasons=["a source column has no name or is duplicated: it cannot become a "  # noqa: E501
                                                      "view column (alias every source expression)"])
    first = str(tree.args.get("kind") or "ALL").upper() == "FIRST"
    view = "mti_" + hashlib.sha1(re.sub(r"\s+", " ", source_text.strip().lower()).encode()).hexdigest()[:8]  # noqa: S324
    pp = Postpass(dataclasses.replace(ctx.postpass.ctx, convention=frozenset({*ctx.postpass.ctx.convention,
                                                                              view.upper()})))
    stmts = [f"CREATE OR REPLACE TEMPORARY VIEW {view} AS {_sql(src)}"]
    seen: list[exp.Expression] = []
    targets: list[str] = []
    for branch in tree.expressions:
        ins, cond = branch.this, branch.args.get("expression")
        preds: list[str] = []
        before = [f"NOT COALESCE({_sql(c)}, FALSE)" for c in seen] if first else []
        if cond is not None:
            preds.append(f"({_sql(cond)})" if before else _sql(cond))
        if first:
            preds += before
            if cond is not None:
                seen.append(cond)
            else:                                   # an unconditional / ELSE branch takes every remaining row
                seen.append(exp.true())
        target, values = ins.this, ins.expression
        cols = ""
        if isinstance(target, exp.Schema):
            cols = " (" + ", ".join(_sql(c) for c in target.expressions) + ")"
            target = target.this
        proj = "*"
        if isinstance(values, exp.Values):
            rows = values.expressions
            if len(rows) != 1 or not isinstance(rows[0], exp.Tuple):
                return PatternResult("multi_insert", reasons=["an INTO clause has more than one VALUES row"])
            proj = ", ".join(_sql(e) for e in rows[0].expressions)
        targets.append(_name(target))
        where = f" WHERE {' AND '.join(preds)}" if preds else ""
        stmts.append(f"INSERT INTO {_sql(target)}{cols} SELECT {proj} FROM {view}{where}")
    out: list[str] = []
    flags: list[Any] = []
    for text in stmts:
        tr = transpile(text, conversion=ctx.conversion, names=ctx.postpass.ctx)
        if not tr.ok:
            return PatternResult("multi_insert", reasons=[f"multi-table INSERT: tier 0 transpile failed: {r}"
                                                          for r in tr.reasons])
        post = pp.apply(tr.sql)
        if post.problems:
            return PatternResult("multi_insert", reasons=post.problems)
        bad = validate("statement", post.sql)
        if bad:
            return PatternResult("multi_insert", reasons=bad)
        out.append(post.sql)
        flags += tr.flags
    notes = [f"{'INSERT FIRST' if first else 'INSERT ALL'} into {len(targets)} target(s) became one temporary view "
             f"{view} and one INSERT per target; Snowflake loads every target in ONE statement, here a failure after the "  # noqa: E501
             "first INSERT leaves the earlier targets loaded (re-run the whole unit, or make the targets idempotent)"]
    return PatternResult("multi_insert", sql=";\n".join(out), review=["SNW-MULTI-INSERT"], notes=notes,
                         params={"multi_insert": {"mode": "FIRST" if first else "ALL", "targets": targets,
                                                  "view": view}, "rule_flags": sorted({f.id for f in flags})})


# ------------------------------------------------------------------------------------------------ 6.11 sequences
def _is_nextval(c: exp.Expression) -> bool:
    return isinstance(c, exp.Column) and c.name.upper() == "NEXTVAL" and bool(c.table)


def sequence_insert(tree: exp.Insert, ctx: Any) -> PatternResult | None:
    nexts = [c for c in tree.find_all(exp.Column) if _is_nextval(c)]
    if not nexts:
        return None
    options = "; ".join(SEQ_OPTIONS)
    expr = tree.expression
    if isinstance(expr, exp.Values):
        if len(expr.expressions) != 1 or not isinstance(expr.expressions[0], exp.Tuple):
            return PatternResult("sequence_insert", review=["SNW-SEQ-SHARED"],
                                 reasons=[f"{nexts[0].table}.NEXTVAL in a multi-row VALUES: choose one of: {options}"])
        items = list(expr.expressions[0].expressions)
    elif isinstance(expr, exp.Select):
        items = list(expr.expressions)
    else:
        return PatternResult("sequence_insert", review=["SNW-SEQ-SHARED"],
                             reasons=[f"{nexts[0].table}.NEXTVAL outside a plain INSERT ... SELECT / VALUES: choose one of: "  # noqa: E501
                                      f"{options}"])
    pos = [i for i, it in enumerate(items) if _is_nextval(it.unalias() if isinstance(it, exp.Alias) else it)]
    if len(nexts) != 1 or len(pos) != 1:
        return PatternResult("sequence_insert", review=["SNW-SEQ-SHARED"],
                             reasons=[f"{nexts[0].table}.NEXTVAL is not exactly one projected column ({len(nexts)} use(s)): "  # noqa: E501
                                      f"choose one of: {options}"])
    target = tree.this.this if isinstance(tree.this, exp.Schema) else tree.this
    if isinstance(tree.this, exp.Schema):
        cols = [str(c.name) for c in tree.this.expressions]
        names_known = True
    else:
        t = ctx.postpass.ctx.table_map.get((str(target.catalog or ctx.postpass.ctx.default_db).upper(),
                                            str(target.db or ctx.postpass.ctx.default_schema).upper(),
                                            target.name.upper()))
        known = ctx.conversion.table_columns(t) if t else None
        cols = list(known) if known else []
        names_known = bool(cols)
    if not names_known or len(cols) != len(items):
        return PatternResult("sequence_insert", review=["SNW-SEQ-SHARED"],
                             reasons=[f"{nexts[0].table}.NEXTVAL: the target column of the sequence is not known (no column list in "  # noqa: E501
                                      "the INSERT and the batch's column catalogue does not describe the table); "
                                      f"choose one of: {options}"])  # noqa: E501
    col = cols[pos[0]]
    seq = nexts[0].table
    new = tree.copy()
    new_target = new.this
    names = [c for i, c in enumerate(cols) if i != pos[0]]
    new.set("this", exp.Schema(this=(new_target.this if isinstance(new_target, exp.Schema) else new_target).copy(),
                               expressions=[exp.to_identifier(n) for n in names]))
    ne = new.expression
    keep = [e for i, e in enumerate(ne.expressions[0].expressions if isinstance(ne, exp.Values) else ne.expressions)
            if i != pos[0]]
    if isinstance(ne, exp.Values):
        ne.set("expressions", [exp.Tuple(expressions=[e.copy() for e in keep])])
    else:
        ne.set("expressions", [e.copy() for e in keep])
    note = (f"{seq}.NEXTVAL fed column {col}: the INSERT leaves it out so the identity column of the target assigns the "  # noqa: E501
            "number (values, gaps and ORDER are the identity column's, not the sequence's)")
    return PatternResult("sequence_insert", source=_sql(new), review=["SNW-SEQ-IDENTITY"], notes=[note],
                         params={"sequence_identity": {"sequence": seq, "column": col}})


# ------------------------------------------------------------------------------------------------ 6.5 AUTO CDC
def _delete_when(cond: exp.Expression, act_alias: str, alias_of: str) -> str | None:
    """The ``_change_type`` predicate of ``s.act = 'DELETE'`` / ``METADATA$ACTION = 'DELETE'``, else None."""
    if not isinstance(cond, exp.EQ):
        return None
    col, lit = cond.this, cond.expression
    if not isinstance(col, exp.Column) or not (isinstance(lit, exp.Literal) and lit.is_string):
        return None
    if lit.this.upper() != "DELETE":
        return None
    if col.name.lower() == act_alias.lower() or col.name.upper() == "METADATA$ACTION":
        return "_change_type = 'delete'"
    return None


def auto_cdc(tree: exp.Merge, ctx: Any, stream_base: Callable[[exp.Table], str | None]) -> PatternResult | None:
    using = tree.args.get("using")
    inner = using.this if isinstance(using, exp.Subquery) else using
    base_tables = [t for t in inner.find_all(exp.Table)] if inner is not None else []
    streams = [(t, stream_base(t)) for t in base_tables if isinstance(t.this, exp.Identifier)]
    streams = [(t, b) for t, b in streams if b]
    if len(streams) != 1 or (isinstance(inner, exp.Select) and (inner.args.get("joins") or inner.args.get("group"))):
        return None
    sel = inner if isinstance(inner, exp.Select) else None
    act_alias = ""
    cols: list[str] = []
    if sel is not None:
        for p in sel.expressions:
            u = p.unalias() if isinstance(p, exp.Alias) else p
            if isinstance(u, exp.Column) and u.name.upper() == "METADATA$ACTION":
                act_alias = p.alias_or_name
            elif isinstance(u, exp.Column) and p.alias_or_name.lower() == u.name.lower():
                cols.append(u.name)
            elif isinstance(u, exp.Star):
                cols.append("*")
            else:
                return None                    # a computed projection: no AUTO CDC column mapping
        if sel.args.get("where") is not None:
            return None
    on = tree.args.get("on")
    keys: list[str] = []
    for c in (list(on.flatten()) if isinstance(on, exp.And) else [on]):
        if not (isinstance(c, exp.EQ) and isinstance(c.this, exp.Column) and isinstance(c.expression, exp.Column)
                and c.this.name.lower() == c.expression.name.lower()):
            return None
        keys.append(c.this.name)
    delete_when, saw = None, {"update": False, "insert": False}
    for w in tree.args["whens"].expressions:
        then, cond = w.args.get("then"), w.args.get("condition")
        if w.args.get("matched") and isinstance(then, exp.Var) and str(then.this).upper() == "DELETE":
            delete_when = _delete_when(cond, act_alias, "") if cond is not None else None
            if delete_when is None:
                return None
        elif w.args.get("matched") and isinstance(then, exp.Update) and cond is None and not saw["update"]:
            saw["update"] = True
            for e in then.expressions:
                if not (isinstance(e, exp.EQ) and isinstance(e.this, exp.Column) and isinstance(e.expression, exp.Column)  # noqa: E501
                        and e.this.name.lower() == e.expression.name.lower()):
                    return None
        elif not w.args.get("matched") and isinstance(then, exp.Insert) and cond is None and not saw["insert"]:
            saw["insert"] = True
        else:
            return None
    if not keys or not saw["insert"] or (not saw["update"] and delete_when is None):
        return None
    tgt_tree = tree.this
    tgt = _name(tgt_tree)
    base = streams[0][1]
    tr = transpile(f"SELECT 1 FROM {tgt}", conversion=ctx.conversion, names=ctx.postpass.ctx)
    if not tr.ok:
        return None
    mapped = ctx.postpass.apply(tr.sql)
    if mapped.problems:
        return PatternResult("auto_cdc", reasons=mapped.problems)
    target_name = re.search(r"FROM\s+(\S+)", mapped.sql, re.I).group(1)
    apply_delete = f" APPLY AS DELETE WHEN {delete_when}" if delete_when else ""
    keep = f" COLUMNS {', '.join(cols)}" if cols and cols != ["*"] else \
        " COLUMNS * EXCEPT (_change_type, _commit_version, _commit_timestamp)"
    text = (f"CREATE OR REFRESH STREAMING TABLE {target_name};\n"
            f"AUTO CDC INTO {target_name} FROM STREAM({base}) KEYS ({', '.join(k.lower() for k in keys)}){apply_delete}"
            f" SEQUENCE BY _commit_version{keep} STORED AS SCD TYPE 1")
    notes = [f"stream + MERGE on {target_name} became one AUTO CDC flow over the change data feed of {base} "
             "(enable delta.enableChangeDataFeed and read the feed with readChangeFeed; deliver insert / update_postimage "  # noqa: E501
             "/ delete rows only, drop update_preimage rows in the source view); sequencing is the commit version. "
             "Syntax and feed options are UNVERIFIED until the data tests run on Databricks (X5)"]
    return PatternResult("auto_cdc", sql=text, review=["SNW-AUTO-CDC"], notes=notes,
                         params={"auto_cdc": {"target": target_name, "source": base, "keys": [k.lower() for k in keys],
                                              "delete": bool(delete_when), "update": saw["update"]}})


# ------------------------------------------------------------------------------------------------ entry point
_QUICK = re.compile(r"^\s*(?:INSERT\s+(?:OVERWRITE\s+)?(?:ALL|FIRST)\b|INSERT\b[\s\S]*\bNEXTVAL\b|MERGE\b[\s\S]*\bMETADATA\$ACTION\b|"  # noqa: E501
                    r"MERGE\b)", re.I)


def detect(source: str, ctx: Any, stream_base: Callable[[exp.Table], str | None] | None = None) -> PatternResult | None:
    """The pattern the statement is, else None. Never raises on unparsable text (the generic path reports it)."""
    if not _QUICK.match(source or ""):
        return None
    try:
        tree = sqlglot.parse_one(source, read="snowflake")
    except SqlglotError:
        return None
    if isinstance(tree, exp.MultitableInserts):
        return multi_insert(tree, ctx, source)
    if isinstance(tree, exp.Insert):
        return sequence_insert(tree, ctx)
    if isinstance(tree, exp.Merge) and stream_base is not None and _STREAM_META.search(source):
        return auto_cdc(tree, ctx, stream_base)
    return None


__all__ = ["PatternResult", "SEQ_OPTIONS", "auto_cdc", "detect", "multi_insert", "sequence_insert"]
