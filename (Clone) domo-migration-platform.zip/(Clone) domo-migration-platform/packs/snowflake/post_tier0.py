"""packs.snowflake.post_tier0 - what runs on a resolved tier-0 unit before the human gate (S5, S6; ADR 037 section 2).

One hook, ``run(results, doc, ctx)``, called by ``translate.translate_etl`` after every unit has been through tier 0
(and the chain). It touches ONLY a unit tier 0 resolved (``origin == "mapped"``, not a reviewer's edit):

1. the REF002 / REF003 refactors (``judges.refactor``), only when ``ctx.refactor_history`` is on (off by default: the
   converter's COUNT(*) pre-query and MAX(id) read-back are the safe forms; the judges flag them either way): the
   text of a procedure body may change, with a caveat;
2. the deterministic judges (``judges.judge_text``): findings become caveat ids;
3. the equivalence check (``equivalence.check``) for a query-shaped unit: its verdict goes to ``evidence``;
   ``differs_unexplained`` adds ``SNW-EQUIV-DIFF``, ``differs_explained`` adds the info id ``SNW-EQUIV-EXPLAINED``.

A finding whose severity is ``review`` joins ``review_caveats`` (the unit still resolves but is never auto-approved); an
``info`` one is only recorded in ``caveats``; an ``escalate`` one turns the unit into ``awaiting_review`` with the
draft kept as ``suggested_code`` (exactly what an escalation at tier 0 does). Evidence carries names, never SQL text.
"""
from __future__ import annotations

from typing import Any

from packs.snowflake import equivalence as eqv
from packs.snowflake import judges

_QUERY_ENGINES = frozenset({"sql_view", "materialized_view", "dynamic_table", "query", "udf_sql"})


def _eligible(res: Any) -> bool:
    return (res.status == "resolved" and res.origin == "mapped" and bool(res.sql) and not res.edited
            and not res.evidence.get("post_tier0"))


def _name_map(ctx: Any) -> dict[str, str]:
    names = {k[2].lower(): v.split(".")[-1].lower() for k, v in ctx.postpass.ctx.table_map.items()}
    names.update({k.lower(): v.split(".")[-1].lower() for k, v in ctx.stream_tables.items()})   # a stream reads its base  # noqa: E501
    return names


def _checkable(res: Any) -> bool:
    if res.engine not in _QUERY_ENGINES:
        return False
    head = res.sql.lstrip().upper()
    return res.kind == "cte_chain" or (res.kind == "statement" and head.startswith(("CREATE", "INSERT")))


def run(results: list[Any], doc: dict, ctx: Any) -> list[Any]:
    params = (doc or {}).get("params") or {}
    warehouses = {str(params[k]) for k in ("warehouse", "WAREHOUSE") if params.get(k)}
    names = _name_map(ctx)
    for res in results:
        if not _eligible(res):
            continue
        findings: list[judges.Finding] = []
        rf = judges.Refactored(res.sql)
        if getattr(ctx, "refactor_history", False):
            rf = judges.refactor(res.sql, lambda t: ctx.conversion.table_columns(t.strip("`")))
        if rf.applied:
            res.sql = rf.sql
            findings += rf.applied
        findings += judges.judge_text(res.source_text, res.sql, kind=res.kind, name_map=names, warehouses=warehouses,
                                     declared=set(res.caveats))
        record: dict[str, Any] = {"judges": [{"id": f.id, "severity": f.severity, "reason": f.reason}
                                             for f in findings]}
        if _checkable(res):
            flags = {f["id"] for f in res.evidence.get("rule_flags") or []}
            verdict = eqv.check(res.source_text, res.sql, names=ctx.postpass.ctx, conversion=ctx.conversion,
                                caveat_ids={*res.caveats, *flags},
                                escalated=any(judges_sev(c) == "escalate" for c in flags))
            record["equivalence"] = verdict.record()
            if verdict.status == eqv.UNEXPLAINED:
                findings.append(judges.Finding("SNW-EQUIV-DIFF", "source and output differ and no rule explains it: "
                                                                  + "; ".join(verdict.detail[:3])))
            elif verdict.status == eqv.EXPLAINED:
                findings.append(judges.Finding("SNW-EQUIV-EXPLAINED", "every difference is a declared rewrite"))
        res.evidence = {**res.evidence, **record, "post_tier0": True}
        ids = sorted({f.id for f in findings})
        res.caveats = sorted({*res.caveats, *ids})
        res.review_caveats = sorted({*res.review_caveats, *(f.id for f in findings if f.severity == "review")})
        stop = [f for f in findings if f.severity == "escalate"]
        if stop:
            res.suggested_code, res.sql = res.sql, ""
            res.status, res.origin = "awaiting_review", "unresolved"
            res.reasons = [f"{f.id}: {f.reason}" for f in stop]
            res.reviewed_as = (res.origin, res.status)
    return results


def judges_sev(caveat_id: str) -> str:
    try:
        return judges.severity_of(caveat_id)
    except KeyError:
        return ""


__all__ = ["run"]
