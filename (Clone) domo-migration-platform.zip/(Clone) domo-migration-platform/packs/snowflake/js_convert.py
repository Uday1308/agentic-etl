# Ported from SNF2DBX-main/converters/javascript.py (LatentView internal), adapted to the pack: the NameMapper and the
# SNF2DBX ``transpile`` became ``CodeServices`` (table map, tier 0 for every inner statement, residue guard), esprima is
# imported lazily (``ConverterUnavailable`` says "esprima not installed"), refusals are ``CodeRefused`` with the line, and
# no note quotes source text. The JavaScript semantics helpers and the statement / expression rules are unchanged.
"""packs.snowflake.js_convert - Snowflake JavaScript procedures -> Databricks Python notebooks; JavaScript UDFs ->
Unity Catalog Python functions (catalogue rows 5.11 and 6.12, tier 0, no AI).

esprima parses the body; each statement / expression is translated by an explicit rule. JavaScript semantics that differ
from Python (string +, %, Math.round, String(), truthy joins) go through small helpers emitted only when used. The
Snowflake API (``snowflake.execute`` / ``createStatement``, ResultSet, Statement) is provided by helper classes over
``spark.sql``, so method calls keep their names. Anything without a rule raises ``CodeRefused`` with the line.
"""
from __future__ import annotations

import json
import keyword
import re

from packs.snowflake.caveats import blank_literals
from packs.snowflake.code_common import CodeObject, CodeRefused, CodeServices, ConverterUnavailable, caster

JavaScriptUnsupported = CodeRefused
_FQN = r'(?:"[^"]+"|[A-Za-z_][\w$]*)(?:\.(?:"[^"]+"|[A-Za-z_][\w$]*)){0,2}'


HELPERS = {
    '_s': '''def _s(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if v != v:
            return "NaN"
        if v.is_integer():
            return str(int(v))
    if isinstance(v, (list, tuple)):
        return ",".join("" if item is None else _s(item) for item in v)
    return str(v)''',
    '_add': '''def _add(a, b):
    if isinstance(a, (str, list, tuple, dict)) or isinstance(b, (str, list, tuple, dict)):
        return _s(a) + _s(b)
    return (0 if a is None else a) + (0 if b is None else b)''',
    '_mod': '''def _mod(a, b):
    result = math.fmod(a, b)
    return int(result) if isinstance(a, int) and isinstance(b, int) else result''',
    '_round': '''def _round(v):
    return math.floor(v + 0.5)''',
    '_num': '''def _num(v):
    if v is None or v == "":
        return 0
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return v
    try:
        text = str(v).strip()
        return int(text) if re.fullmatch(r"[+-]?\\d+", text) else float(text)
    except ValueError:
        return float("nan")''',
    '_parse_int': '''def _parse_int(v, base=10):
    match = re.match(r"\\s*([+-]?[0-9a-zA-Z]+)", _s(v))
    try:
        return int(match.group(1), base) if match else float("nan")
    except ValueError:
        digits = re.match(r"[+-]?\\d+", match.group(1))
        return int(digits.group(0), base) if digits else float("nan")''',
    '_parse_float': '''def _parse_float(v):
    match = re.match(r"\\s*[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?", _s(v))
    return float(match.group(0)) if match else float("nan")''',
    '_typeof': '''def _typeof(v):
    if v is None:
        return "object"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    return "function" if callable(v) else "object"''',
    '_to_json': '''def _to_json(v):
    if isinstance(v, datetime.datetime):
        if v.tzinfo is not None:
            v = v.astimezone(datetime.timezone.utc).replace(tzinfo=None)
        return v.isoformat(timespec="milliseconds") + "Z"
    if isinstance(v, datetime.date):
        return v.isoformat() + "T00:00:00.000Z"
    return json.dumps(v, default=str)''',
    '_join': '''def _join(values, separator=","):
    return separator.join("" if v is None else _s(v) for v in values)''',
    '_index_of': '''def _index_of(values, item):
    if isinstance(values, str):
        return values.find(item)
    return values.index(item) if item in values else -1''',
    '_substring': '''def _substring(text, start, end=None):
    end = len(text) if end is None else end
    start, end = max(0, min(int(start), len(text))), max(0, min(int(end), len(text)))
    return text[min(start, end):max(start, end)]''',
    '_split': '''def _split(text, separator=None):
    if separator is None:
        return [text]
    return list(text) if separator == "" else text.split(separator)''',
    '_keys': '''def _keys(value):
    return list(value.keys()) if isinstance(value, dict) else [str(i) for i in range(len(value))]''',
    '_error': '''def _error(value):
    return value if isinstance(value, BaseException) else Exception(_s(value))''',
    '_message': '''def _message(error):
    getter = getattr(error, "getMessage", None)
    return getter() if callable(getter) else str(error)''',
    '_error_code': '''def _error_code(error):
    getter = getattr(error, "getErrorClass", None)
    return getter() if callable(getter) else type(error).__name__''',
    '_error_state': '''def _error_state(error):
    getter = getattr(error, "getSqlState", None)
    return getter() if callable(getter) else None''',
    '_rebind': '''def _rebind(binds, order):
    return [binds[n - 1] for n in order]''',
    '_snowflake': '''def _js_value(v):
    if isinstance(v, decimal.Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    return v


class _ResultSet:
    def __init__(self, rows, columns):
        self._rows, self._columns, self._index = rows, [c.upper() for c in columns], -1

    def next(self):
        self._index += 1
        return self._index < len(self._rows)

    def getColumnValue(self, key):
        row = self._rows[self._index]
        return _js_value(row[key - 1] if isinstance(key, int) else row[self._columns.index(str(key).upper())])

    def getColumnValueAsString(self, key):
        value = self.getColumnValue(key)
        return "" if value is None else _s(value)

    def getRowCount(self):
        return len(self._rows)

    def getColumnCount(self):
        return len(self._columns)

    def getColumnName(self, index):
        return self._columns[index - 1]


class _Statement:
    def __init__(self, sql, binds=None):
        self._sql, self._binds, self._affected, self._rows = sql, list(binds or []), -1, 0

    def execute(self):
        frame = spark.sql(self._sql, args=self._binds) if self._binds else spark.sql(self._sql)
        rows = frame.collect()
        if frame.columns[:1] == ["num_affected_rows"] and len(rows) == 1:
            self._affected = rows[0][0]
        self._rows = len(rows)
        return _ResultSet(rows, frame.columns)

    def getNumRowsAffected(self):
        return self._affected

    def getRowCount(self):
        return self._rows

    def getSqlText(self):
        return self._sql


def _sf_execute(sql, binds=None):
    return _Statement(sql, binds).execute()''',
}
HELPER_DEPENDS = {'_add': ['_s'], '_join': ['_s'], '_error': ['_s'], '_parse_int': ['_s'], '_parse_float': ['_s'],
                  '_snowflake': ['_s']}
HELPER_IMPORTS = {'_mod': 'math', '_round': 'math', '_num': 're', '_parse_int': 're', '_parse_float': 're', '_snowflake': 'decimal'}
RESERVED = set(keyword.kwlist) | {'len', 'str', 'int', 'float', 'json', 'math', 're', 'datetime', 'decimal', 'spark', 'dbutils',
                                  'print', 'isinstance', 'range', 'list', 'dict', 'min', 'max', 'abs', 'round', 'sum', 'True',
                                  'False', 'None', 'Exception', 'type', 'callable', 'getattr', 'bool', 'tuple', 'match'}
STATEMENT_METHODS = {'execute', 'getNumRowsAffected', 'getRowCount', 'getSqlText', 'next', 'getColumnValue',
                     'getColumnValueAsString', 'getColumnCount', 'getColumnName'}
MATH = {'floor': 'math.floor', 'ceil': 'math.ceil', 'abs': 'abs', 'sqrt': 'math.sqrt', 'pow': 'math.pow', 'max': 'max',
        'min': 'min', 'log': 'math.log', 'exp': 'math.exp', 'trunc': 'math.trunc'}
# `x instanceof T` for the built-in types a procedure can receive (a DATE/TIMESTAMP argument is a Python date/datetime).
_INSTANCE_TYPES = {'Date': 'datetime.date', 'Array': 'list', 'Object': 'dict', 'Error': 'BaseException'}
_TXN = re.compile(r'^\s*(BEGIN(\s+(TRANSACTION|WORK))?|START\s+TRANSACTION|COMMIT(\s+WORK)?|ROLLBACK(\s+WORK)?)\s*;?\s*$', re.I)
_SQL_START = re.compile(r'^\s*(SELECT|WITH|INSERT|UPDATE|DELETE|MERGE|CREATE|TRUNCATE|DROP|ALTER|CALL|USE|BEGIN|START|COMMIT|ROLLBACK)\b', re.I)


class _Translator:
    def __init__(self, svc, allow_sql):
        self.svc, self.names, self.allow_sql = svc, svc.names, allow_sql
        self.helpers, self.notes, self.errors, self.functions = set(), [], set(), set()
        self.fragment_binds = None

    def fail(self, node, message):
        line = getattr(getattr(getattr(node, 'loc', None), 'start', None), 'line', None)
        raise CodeRefused(f'line {line - 1 if line else "?"}: {message}')

    def use(self, name):
        self.helpers.add(name)
        return name

    def name(self, identifier):
        return identifier + '_js' if identifier in RESERVED or identifier.startswith('_') else identifier

    # ------------------------------------------------------------ SQL text
    def sql_literal(self, text, node, binds=None):
        """Convert one complete SQL statement given as a literal. Returns (python expression, binds expression)."""
        if _TXN.match(text):
            self.notes.append('SEM004|Transaction control (BEGIN/COMMIT/ROLLBACK) was removed: each Databricks statement commits on its own')
            return json.dumps("SELECT 'transaction control skipped' AS status"), binds
        if re.match(r'^\s*ALTER\s+SESSION\s+(SET|UNSET)\b', text, re.I):
            self.notes.append('INFO|ALTER SESSION (e.g. QUERY_TAG) has no Databricks equivalent and was skipped; job runs are tagged by job name')
            return json.dumps("SELECT 'session setting skipped' AS status"), None
        if re.search(r'\bQUERY_HISTORY\w*\s*\(', text, re.I):
            # SnowConvert's error handler looks up the failed statement's text; Databricks query history is not
            # queryable the same way, so the lookup returns no row and the handler's own fallback text is used.
            self.notes.append('SEM004|Query-history lookup (information_schema.query_history*) returns no row on Databricks; '
                              'the error log records the fallback text instead of the failed statement')
            return json.dumps("SELECT CAST(NULL AS STRING) AS QUERY_TEXT WHERE FALSE"), None
        order = []
        visible = blank_literals(text)

        def bind(match):
            order.append(int(match.group(1)))
            return '?'
        if re.search(r':\d+\b', visible):
            pieces, last = [], 0
            for match in re.finditer(r':(\d+)\b', visible):
                pieces.append(text[last:match.start()])
                pieces.append(bind(match))
                last = match.end()
            text = ''.join(pieces) + text[last:]
            if binds is None:
                self.fail(node, 'numbered binds (:1) used without a binds array')
            binds = f'{self.use("_rebind")}({binds}, {order})'
        use = re.match(r'^\s*USE\s+(SCHEMA|DATABASE)\s+(' + _FQN + r')\s*;?\s*$', text, re.I)
        call = re.match(r'^\s*CALL\s+(' + _FQN + r')\s*\((.*)\)\s*;?\s*$', text, re.I | re.S)
        try:
            if use:
                return json.dumps(self.names.use_statement(use.group(1), _split_fqn(use.group(2)))), binds
            if call:
                if '$' in call.group(1):
                    self.fail(node, f'CALL {call.group(1)} has no Databricks equivalent')
                _, target = self.names.routine(_split_fqn(call.group(1)))
                args = call.group(2).strip()
                args = self.svc.statement('SELECT ' + args)[7:] if args else ''
                return json.dumps(f'CALL {target}({args})'), binds
            return json.dumps(self.svc.statement(text)), binds
        except CodeRefused as error:
            if str(error).startswith('line '):
                raise
            self.fail(node, f'SQL could not be converted: {error}')

    def sql_fragment(self, text, node):
        """A piece of dynamically built SQL: map three-part names, refuse Snowflake-only constructs."""
        if re.search(r'\bTRANSIENT\s+TABLE\b', text, re.I):
            text = re.sub(r'\bTRANSIENT\s+(?=TABLE\b)', '', text, flags=re.I)
            self.notes.append('INFO|TRANSIENT dropped: Databricks has no transient tables')
        residue = self.svc.residue(text)
        if residue:
            self.fail(node, 'dynamic SQL text contains Snowflake-only constructs: ' + ', '.join(residue))
        part = r'(?:"[^"]+"|[A-Za-z_]\w*)'

        def mapped(match):
            parts = _split_fqn(match.group(0))
            if text[match.end():].lstrip().startswith('('):   # DB.SCHEMA.UDF(...): named like the routine's own artifact
                return self.names.routine(parts)[1]
            try:
                target = self.names.table(parts, 'dynamic SQL')
            except CodeRefused as error:
                self.fail(node, str(error))
            return '.'.join(p if re.fullmatch(r'[a-z_][a-z0-9_]*', p) else f'`{p}`' for p in target.split('.'))
        # Three-part names, quoted or not, including function calls (DB.SCHEMA.UDF(...)).
        text = re.sub(rf'(?<![\w."]){part}\.{part}\.{part}(?![\w"])', mapped, text)
        if self.fragment_binds is not None:  # :1 binds in SQL built from pieces become ? (reordered by _rebind)
            visible = blank_literals(text)
            pieces, last = [], 0
            for match in re.finditer(r':(\d+)\b', visible):
                pieces += [text[last:match.start()], '?']
                self.fragment_binds.append(int(match.group(1)))
                last = match.end()
            text = ''.join(pieces) + text[last:]
        return text

    def sql_argument(self, node, binds):
        """The sqlText of snowflake.execute/createStatement."""
        if node.type == 'Literal' and isinstance(node.value, str):
            return self.sql_literal(node.value, node, binds)
        if node.type == 'TemplateLiteral' and not node.expressions:
            return self.sql_literal(node.quasis[0].value.cooked, node, binds)
        self.notes.append('SEM004|SQL text built at run time is passed through with mapped three-part names; '
                          'review that it is valid Databricks SQL')
        self.fragment_binds = []
        try:
            text = self.expr(node, sql=True)
            order = self.fragment_binds
        finally:
            self.fragment_binds = None
        if order:
            if binds is None:
                self.fail(node, 'numbered binds (:1) used without a binds array')
            binds = f'{self.use("_rebind")}({binds}, {order})'
        return text, binds

    # ------------------------------------------------------------ expressions
    def expr(self, node, sql=False, fragment=False):
        kind = node.type
        if kind == 'Literal':
            if getattr(node, 'regex', None):
                self.fail(node, 'regular expression literal outside .replace()/.test()')
            value = node.value
            if value is None:
                return 'None'
            if isinstance(value, bool):
                return 'True' if value else 'False'
            if isinstance(value, str):
                if (sql or _SQL_START.match(value)) and self.allow_sql:
                    if not fragment and _SQL_START.match(value):
                        try:  # a complete statement held in a variable converts like a direct sqlText literal
                            return self.sql_literal(value, node)[0]
                        except CodeRefused as error:
                            self.notes.append('SEM004|a string that starts like a SQL statement was not converted as one '
                                              f'({str(error)[:120]}); it passes through with mapped three-part names')
                    value = self.sql_fragment(value, node)
                elif self.allow_sql and re.fullmatch(r'[A-Za-z_]\w*\.[A-Za-z_]\w*\.[A-Za-z_]\w*', value):
                    # A string that is exactly DB.SCHEMA.TABLE is almost always a table name spliced into SQL later.
                    parts = value.split('.')
                    target = self.names.maybe_table(parts)
                    if target is not None:
                        self.notes.append('SEM004|a string that is exactly a three-part table name was treated as a table '
                                          'name and mapped to its Databricks name')
                        value = target
                    elif self.names.known_database(parts[0]):
                        self.fail(node, 'a string names a table of the source database that is not in the batch\'s table '
                                        'map, so it has no Databricks name')
                return json.dumps(value)
            return repr(value)
        if kind == 'Identifier':
            if node.name == 'undefined':
                return 'None'
            if node.name in ('NaN', 'Infinity'):
                return 'float("nan")' if node.name == 'NaN' else 'float("inf")'
            return self.name(node.name)
        if kind == 'TemplateLiteral':
            parts = []
            for index, quasi in enumerate(node.quasis):
                text = quasi.value.cooked
                if text:
                    is_sql = (sql or _SQL_START.match(node.quasis[0].value.cooked)) and self.allow_sql
                    if is_sql and not node.expressions and not fragment and _SQL_START.match(text):
                        try:
                            return self.sql_literal(text, node)[0]
                        except CodeRefused as error:
                            self.notes.append('SEM004|a template that starts like a SQL statement was not converted as one '
                                              f'({str(error)[:120]}); it passes through with mapped three-part names')
                    parts.append(json.dumps(self.sql_fragment(text, node) if is_sql else text))
                if index < len(node.expressions):
                    parts.append(f'{self.use("_s")}({self.expr(node.expressions[index], sql, True)})')
            return '(' + ' + '.join(parts or ['""']) + ')'
        if kind == 'ArrayExpression':
            return '[' + ', '.join(self.expr(item) for item in node.elements) + ']'
        if kind == 'ObjectExpression':
            items = []
            for prop in node.properties:
                if prop.computed or prop.kind != 'init':
                    self.fail(prop, 'computed or accessor object keys')
                key = prop.key.name if prop.key.type == 'Identifier' else str(prop.key.value)
                items.append(f'{json.dumps(key)}: {self.expr(prop.value)}')
            return '{' + ', '.join(items) + '}'
        if kind == 'UnaryExpression':
            operand = self.expr(node.argument)
            if node.operator == '!':
                return f'(not {operand})'
            if node.operator == '-':
                return f'(-{operand})'
            if node.operator == '+':
                return f'{self.use("_num")}({operand})'
            if node.operator == 'typeof':
                return f'{self.use("_typeof")}({operand})'
            self.fail(node, f'unary operator {node.operator}')
        if kind == 'BinaryExpression':
            left, right = self.expr(node.left, sql, True), self.expr(node.right, sql, True)
            op = node.operator
            if op == '+':
                if _is_string(node.left) or _is_string(node.right):
                    def text(side, code):
                        return code if _is_string(side) and side.type != 'TemplateLiteral' and side.type == 'BinaryExpression' else f'{self.use("_s")}({code})'
                    return f'({text(node.left, left)} + {text(node.right, right)})'
                return f'{self.use("_add")}({left}, {right})'
            if op == '%':
                return f'{self.use("_mod")}({left}, {right})'
            if op in ('==', '===', '!=', '!==') and (_is_null(node.left) or _is_null(node.right)):
                value = left if _is_null(node.right) else right
                return f'({value} is {"not " if op.startswith("!") else ""}None)'
            if op in ('==', '==='):
                if op == '==':
                    self.notes.append('SEM004|JavaScript == (loose equality) became Python ==, which does not convert types')
                return f'({left} == {right})'
            if op in ('!=', '!=='):
                return f'({left} != {right})'
            if op in ('<', '>', '<=', '>=', '-', '*', '/'):
                return f'({left} {op} {right})'
            if op == 'instanceof' and node.right.type == 'Identifier' and node.right.name in _INSTANCE_TYPES:
                return f'isinstance({left}, {_INSTANCE_TYPES[node.right.name]})'
            self.fail(node, f'operator {op}')
        if kind == 'LogicalExpression':
            op = {'&&': 'and', '||': 'or'}.get(node.operator)
            if not op:
                self.fail(node, f'operator {node.operator}')
            return f'({self.expr(node.left)} {op} {self.expr(node.right)})'
        if kind == 'ConditionalExpression':
            return f'({self.expr(node.consequent)} if {self.expr(node.test)} else {self.expr(node.alternate)})'
        if kind == 'MemberExpression':
            target = self.expr(node.object)
            if node.computed:
                return f'{target}[{self.expr(node.property)}]'
            prop = node.property.name
            if prop == 'length':
                return f'len({target})'
            if node.object.type == 'Identifier' and node.object.name in self.errors:
                if prop == 'message':
                    return f'{self.use("_message")}({target})'
                if prop == 'code':
                    self.notes.append('SEM004|err.code is the Databricks error class, not a Snowflake numeric error code')
                    return f'{self.use("_error_code")}({target})'
                if prop == 'state':
                    return f'{self.use("_error_state")}({target})'
                if prop == 'stackTraceTxt':
                    return f'str({target})'
            if node.object.type == 'Identifier' and node.object.name == 'Math' and prop == 'PI':
                return 'math.pi'
            return f'{target}[{json.dumps(prop)}]'
        if kind == 'CallExpression':
            return self.call(node)
        if kind == 'NewExpression':
            callee = node.callee.name if node.callee.type == 'Identifier' else ''
            if callee == 'Error':
                return f'Exception({", ".join(self.expr(a) for a in node.arguments)})'
            if callee == 'Array' and not node.arguments:
                return '[]'
            if callee == 'Object' and not node.arguments:
                return '{}'
            self.fail(node, f'new {callee or "expression"}() has no rule (Date and custom classes need manual conversion)')
        if kind == 'ArrowFunctionExpression' and node.expression:
            params = [self.name(p.name) for p in node.params if p.type == 'Identifier']
            if len(params) != len(node.params):
                self.fail(node, 'arrow function parameters')
            return f'(lambda {", ".join(params)}: {self.expr(node.body)})'
        if kind == 'AssignmentExpression' or kind == 'UpdateExpression':
            self.fail(node, 'assignment or ++/-- inside an expression; split it into its own statement')
        self.fail(node, f'{kind} has no rule')

    def _callback_body(self, node):
        """(parameter names, body expression) for a callback that only returns an expression:
        function (c) { return <expr>; }, (c) => <expr> or (c) => { return <expr>; }. None for anything else."""
        if node.type not in ('FunctionExpression', 'ArrowFunctionExpression') or getattr(node, 'generator', False) \
                or getattr(node, 'async', False) or any(p.type != 'Identifier' for p in node.params):
            return None
        body = node.body
        if node.type == 'ArrowFunctionExpression' and node.expression:
            expression = body
        elif body.type == 'BlockStatement' and len(body.body) == 1 and body.body[0].type == 'ReturnStatement' \
                and body.body[0].argument is not None:
            expression = body.body[0].argument
        else:
            return None
        return [p.name for p in node.params], expression

    def _replace_callback(self, node, pattern, callback):
        """str.replace(/re/, function (match, g1, ...) { return expr; }) -> re.sub with a function replacement.
        JavaScript passes the match, then each capture group; Python passes a match object, so the parameters are
        bound to m.group(0), m.group(1), ... The offset/string arguments JavaScript adds after the groups have no rule."""
        params, expression = self._callback_body(callback)
        try:
            groups = re.compile(pattern.regex.pattern).groups
        except re.error:
            self.fail(node, 'regular expression that Python cannot compile')
        if len(params) > groups + 1:
            self.fail(node, 'replace callback that uses the offset or whole-string arguments')
        names = [self.name(p) for p in params]
        if not names:
            return f'(lambda _m: {self.expr(expression)})'
        values = ', '.join(f'_m.group({index})' for index in range(len(names)))
        return f'(lambda _m: (lambda {", ".join(names)}: {self.expr(expression)})({values}))'

    def call(self, node):
        callee = node.callee
        def regex(item):
            return item.type == 'Literal' and getattr(item, 'regex', None) is not None
        method_name = callee.property.name if callee.type == 'MemberExpression' and not callee.computed else None
        callback = (node.arguments[1] if method_name in ('replace', 'replaceAll') and len(node.arguments) == 2
                    and regex(node.arguments[0]) and self._callback_body(node.arguments[1]) else None)
        args = [None if regex(a) or a is callback else self.expr(a) for a in node.arguments] if not _is_snowflake_api(callee) else []
        if callee.type == 'Identifier':
            name = callee.name
            if name == 'parseInt':
                return f'{self.use("_parse_int")}({", ".join(args)})'
            if name == 'parseFloat':
                return f'{self.use("_parse_float")}({args[0]})'
            if name == 'Number':
                return f'{self.use("_num")}({args[0] if args else 0})'
            if name == 'String':
                return f'{self.use("_s")}({args[0] if args else chr(34) * 2})'
            if name == 'Boolean':
                return f'bool({args[0]})'
            if name == 'isNaN':
                return f'({self.use("_num")}({args[0]}) != {self.use("_num")}({args[0]}))'
            if name not in self.functions:
                # Never forward an undeclared global (eval, setTimeout, ...) to a Python builtin of the same name.
                self.fail(node, f'{name}() is not declared in this code and has no rule')
            return f'{self.name(name)}({", ".join(args)})'
        if callee.type != 'MemberExpression' or callee.computed:
            self.fail(node, 'computed function call')
        method, obj = callee.property.name, callee.object
        if obj.type == 'Identifier' and obj.name == 'snowflake':
            if not self.allow_sql:
                self.fail(node, 'snowflake.* is not available in a function (UDF)')
            if method in ('execute', 'createStatement'):
                spec = node.arguments[0] if node.arguments else None
                if spec is None or spec.type != 'ObjectExpression':
                    self.fail(node, f'snowflake.{method} needs an object literal {{sqlText, binds}}')
                values = {(p.key.name if p.key.type == 'Identifier' else p.key.value): p.value for p in spec.properties}
                unknown = set(values) - {'sqlText', 'binds'}
                if unknown or 'sqlText' not in values:
                    self.fail(node, f'snowflake.{method} options {sorted(unknown) or "without sqlText"} have no rule')
                binds = self.expr(values['binds']) if 'binds' in values else None
                sql, binds = self.sql_argument(values['sqlText'], binds)
                self.use('_snowflake')
                target = '_sf_execute' if method == 'execute' else '_Statement'
                return f'{target}({sql}' + (f', {binds})' if binds else ')')
            if method == 'log':
                return f'print({", ".join(self.expr(a) for a in node.arguments[1:]) or chr(34) * 2})'
            self.fail(node, f'snowflake.{method}() has no Databricks rule')
        if obj.type == 'Identifier' and obj.name == 'Math':
            if method == 'round':
                return f'{self.use("_round")}({args[0]})'
            if method == 'random':
                return '__import__("random").random()'
            if method in MATH:
                return f'{MATH[method]}({", ".join(args)})'
            self.fail(node, f'Math.{method}')
        if obj.type == 'Identifier' and obj.name == 'JSON':
            if method == 'stringify' and len(args) == 1:
                return f'json.dumps({args[0]}, separators=(",", ":"), default=str)'
            if method == 'parse' and len(args) == 1:
                return f'json.loads({args[0]})'
            self.fail(node, f'JSON.{method} with these arguments')
        if obj.type == 'Identifier' and obj.name == 'Array' and method == 'isArray':
            return f'isinstance({args[0]}, list)'
        if obj.type == 'Identifier' and obj.name == 'Object' and method == 'keys':
            return f'{self.use("_keys")}({args[0]})'
        if method == 'test' and regex(obj):
            flags = obj.regex.flags
            return f'bool(re.search({json.dumps(obj.regex.pattern)}, {self.use("_s")}({args[0]}){", flags=re.I" if "i" in flags else ""}))'
        pattern = node.arguments[0] if node.arguments and regex(node.arguments[0]) else None
        if pattern is not None and method not in ('replace', 'replaceAll'):
            self.fail(node, f'regular expression argument to .{method}()')
        target = self.expr(obj)
        if method in STATEMENT_METHODS:
            return f'{target}.{method}({", ".join(args)})'
        if pattern is not None:
            flags = pattern.regex.flags
            if set(flags) - set('gim'):
                self.fail(node, f'regular expression flags {flags}')
            count = '0' if 'g' in flags else '1'
            # JavaScript \w \b \d are ASCII-only; Python's are Unicode unless re.A is set.
            ascii_classes = re.search(r'\\[wWbBdD]', pattern.regex.pattern) is not None
            options = ' | '.join(['re.I'] * ('i' in flags) + ['re.M'] * ('m' in flags) + ['re.A'] * ascii_classes) or '0'
            replacement = node.arguments[1] if len(node.arguments) == 2 else None
            if replacement is not None and replacement is callback:
                function = self._replace_callback(node, pattern, replacement)
                return f're.sub({json.dumps(pattern.regex.pattern)}, {function}, {target}, count={count}, flags={options})'
            if replacement is None or not (replacement.type == 'Literal' and isinstance(replacement.value, str)) or '$' in replacement.value:
                self.fail(node, 'regex replace needs a literal replacement without $ groups, or a callback that returns an expression')
            return f're.sub({json.dumps(pattern.regex.pattern)}, {args[1]}, {target}, count={count}, flags={options})'
        simple = {'toUpperCase': 'upper', 'toLowerCase': 'lower', 'trim': 'strip', 'trimStart': 'lstrip', 'trimEnd': 'rstrip',
                  'startsWith': 'startswith', 'endsWith': 'endswith'}
        if method in simple:
            return f'{target}.{simple[method]}({", ".join(args)})'
        if method == 'push':
            if len(args) != 1:
                self.fail(node, 'push with several values')
            return f'{target}.append({args[0]})'
        if method == 'pop' and not args:
            return f'{target}.pop()'
        if method == 'join':
            return f'{self.use("_join")}({target}{", " + args[0] if args else ""})'
        if method == 'indexOf' and len(args) == 1:
            return f'{self.use("_index_of")}({target}, {args[0]})'
        if method == 'includes' and len(args) == 1:
            return f'({args[0]} in {target})'
        if method == 'substring':
            return f'{self.use("_substring")}({target}, {", ".join(args)})'
        if method in ('slice', 'substr') and 1 <= len(args) <= 2:
            if method == 'substr':
                return f'{target}[{args[0]}:' + (f'({args[0]}) + ({args[1]})' if len(args) == 2 else '') + ']'
            return f'{target}[{args[0]}:{args[1] if len(args) == 2 else ""}]'
        if method == 'split':
            return f'{self.use("_split")}({target}{", " + args[0] if args else ""})'
        if method == 'replace' and len(args) == 2:
            return f'{target}.replace({args[0]}, {args[1]}, 1)'
        if method == 'replaceAll' and len(args) == 2:
            return f'{target}.replace({args[0]}, {args[1]})'
        if method == 'toString' and not args:
            return f'{self.use("_s")}({target})'
        if method == 'toJSON' and not args:  # Date.toJSON(): ISO-8601 text; dates bound to SQL arrive as Python datetimes
            return f'{self.use("_to_json")}({target})'
        if method == 'toFixed' and len(args) <= 1:
            return f'format({target}, "." + str({args[0] if args else 0}) + "f")'
        if method == 'charAt' and len(args) == 1:
            return f'{target}[{args[0]}:({args[0]}) + 1]'
        if method == 'concat':
            return f'({target} + ' + ' + '.join(args) + ')'
        if method == 'map' and len(node.arguments) == 1 and node.arguments[0].type == 'ArrowFunctionExpression':
            return f'list(map({args[0]}, {target}))'
        if method in ('map', 'filter') and len(node.arguments) == 1 and node.arguments[0].type == 'Identifier' \
                and node.arguments[0].name in self.functions:  # e.g. [a, b].map(fix_binds) with a declared helper
            return f'list({method}(lambda _v: {self.name(node.arguments[0].name)}(_v), {target}))'
        if method == 'filter' and len(node.arguments) == 1 and node.arguments[0].type == 'ArrowFunctionExpression':
            return f'list(filter({args[0]}, {target}))'
        self.fail(node, f'.{method}() has no rule')

    # ------------------------------------------------------------ statements
    def block(self, statements, depth, loop=None):
        lines = []
        hoisted = [s for s in statements if s.type == 'FunctionDeclaration']
        for statement in hoisted + [s for s in statements if s.type != 'FunctionDeclaration']:
            lines += self.statement(statement, depth, loop)
        return lines or ['    ' * depth + 'pass']

    def body(self, node, depth, loop=None):
        return self.block(node.body if node.type == 'BlockStatement' else [node], depth, loop)

    def assign(self, target, op, value, node):
        if target.type == 'Identifier':
            name = self.name(target.name)
        elif target.type == 'MemberExpression':
            name = self.expr(target)
            if name.startswith('len('):
                self.fail(node, 'assigning to .length')
        else:
            self.fail(node, 'destructuring assignment')
        if op == '=':
            return f'{name} = {value}'
        if op == '+=':
            return f'{name} = {self.use("_add")}({name}, {value})'
        if op == '%=':
            return f'{name} = {self.use("_mod")}({name}, {value})'
        if op in ('-=', '*=', '/='):
            return f'{name} {op} {value}'
        self.fail(node, f'assignment operator {op}')

    def statement(self, node, depth, loop=None):
        pad = '    ' * depth
        kind = node.type
        if kind == 'VariableDeclaration':
            lines = []
            for declaration in node.declarations:
                if declaration.id.type != 'Identifier':
                    self.fail(node, 'destructuring declaration')
                lines.append(pad + f'{self.name(declaration.id.name)} = ' + (self.expr(declaration.init) if declaration.init else 'None'))
            return lines
        if kind == 'ExpressionStatement':
            expression = node.expression
            if expression.type == 'AssignmentExpression':
                return [pad + self.assign(expression.left, expression.operator, self.expr(expression.right), node)]
            if expression.type == 'UpdateExpression':
                op = '+=' if expression.operator == '++' else '-='
                return [pad + self.assign(expression.argument, op, '1', node)]
            if expression.type == 'SequenceExpression':
                return [line for item in expression.expressions
                        for line in self.statement(type('S', (), {'type': 'ExpressionStatement', 'expression': item, 'loc': node.loc})(), depth, loop)]
            return [pad + self.expr(expression)]
        if kind == 'IfStatement':
            lines = [pad + f'if {self.expr(node.test)}:'] + self.body(node.consequent, depth + 1, loop)
            alternate = node.alternate
            while alternate is not None and alternate.type == 'IfStatement':
                lines += [pad + f'elif {self.expr(alternate.test)}:'] + self.body(alternate.consequent, depth + 1, loop)
                alternate = alternate.alternate
            if alternate is not None:
                lines += [pad + 'else:'] + self.body(alternate, depth + 1, loop)
            return lines
        if kind == 'BlockStatement':
            return self.block(node.body, depth, loop)
        if kind == 'EmptyStatement':
            return []
        if kind == 'ReturnStatement':
            return [pad + 'return' + (' ' + self.expr(node.argument) if node.argument else '')]
        if kind == 'ThrowStatement':
            return [pad + f'raise {self.use("_error")}({self.expr(node.argument)})']
        if kind == 'BreakStatement' or kind == 'ContinueStatement':
            if node.label:
                self.fail(node, 'labelled break/continue')
            if kind == 'ContinueStatement' and loop == 'do':
                self.fail(node, 'continue inside do...while')
            return [pad + ('break' if kind == 'BreakStatement' else 'continue')]
        if kind == 'WhileStatement':
            return [pad + f'while {self.expr(node.test)}:'] + self.body(node.body, depth + 1, 'while')
        if kind == 'DoWhileStatement':
            return ([pad + 'while True:'] + self.body(node.body, depth + 1, 'do')
                    + [pad + f'    if not {self.expr(node.test)}:', pad + '        break'])
        if kind == 'ForStatement':
            lines = []
            if node.init is not None:
                init = node.init if node.init.type == 'VariableDeclaration' else type('S', (), {'type': 'ExpressionStatement', 'expression': node.init, 'loc': node.loc})()
                lines += self.statement(init, depth, loop)
            test = self.expr(node.test) if node.test is not None else 'True'
            update = []
            if node.update is not None:
                update = self.statement(type('S', (), {'type': 'ExpressionStatement', 'expression': node.update, 'loc': node.loc})(), depth + 2)
            has_continue = _contains(node.body, 'ContinueStatement', LOOPS)
            has_break = _contains(node.body, 'BreakStatement', LOOPS + ('SwitchStatement',))
            if has_continue and update:
                if has_break:
                    self.fail(node, 'for loop with both continue and break needs manual conversion')
                # finally runs the update after continue, like the JavaScript for-loop update clause
                lines += [pad + f'while {test}:', pad + '    try:'] + self.body(node.body, depth + 2, 'for') + [pad + '    finally:'] + update
            else:
                lines += [pad + f'while {test}:'] + self.body(node.body, depth + 1, 'for') + [line[4:] for line in update]
            return lines
        if kind == 'ForOfStatement' or kind == 'ForInStatement':
            left = node.left.declarations[0].id if node.left.type == 'VariableDeclaration' else node.left
            if left.type != 'Identifier':
                self.fail(node, 'destructuring loop variable')
            source = self.expr(node.right)
            if kind == 'ForInStatement':
                source = f'{self.use("_keys")}({source})'
            return [pad + f'for {self.name(left.name)} in {source}:'] + self.body(node.body, depth + 1, 'for')
        if kind == 'TryStatement':
            lines = [pad + 'try:'] + self.body(node.block, depth + 1, loop)
            if node.handler is not None:
                param = node.handler.param
                if param is not None:
                    self.errors.add(param.name)
                lines += [pad + 'except Exception' + (f' as {self.name(param.name)}:' if param is not None else ':')]
                lines += self.body(node.handler.body, depth + 1, loop)
            if node.finalizer is not None:
                lines += [pad + 'finally:'] + self.body(node.finalizer, depth + 1, loop)
            return lines
        if kind == 'SwitchStatement':
            return self.switch(node, depth, loop)
        if kind == 'FunctionDeclaration':
            params = [p for p in node.params]
            if any(p.type != 'Identifier' for p in params):
                self.fail(node, 'default or destructured function parameters')
            outer = sorted(_assigned(node.body) - _declared(node))
            lines = [pad + f'def {self.name(node.id.name)}({", ".join(self.name(p.name) for p in params)}):']
            if outer:
                lines.append(pad + '    nonlocal ' + ', '.join(self.name(name) for name in outer))
            return lines + self.body(node.body, depth + 1)
        self.fail(node, f'{kind} has no rule')

    def switch(self, node, depth, loop):
        pad = '    ' * depth
        lines, pending, subject = [], [], self.expr(node.discriminant)
        for index, case in enumerate(node.cases):
            body = [s for s in case.consequent]
            if not body and index < len(node.cases) - 1:
                pending.append(case)
                continue
            group = pending + [case]
            pending = []
            ends = body and body[-1].type in ('BreakStatement', 'ReturnStatement', 'ThrowStatement', 'ContinueStatement')
            if not ends and index < len(node.cases) - 1:
                self.fail(case, 'switch fall-through between cases')
            if any(s.type == 'BreakStatement' for s in body[:-1]) or any(_contains(s, 'BreakStatement') for s in body[:-1]):
                self.fail(case, 'break before the end of a switch case')
            if body and body[-1].type == 'BreakStatement':
                body = body[:-1]
            tests = [c.test for c in group]
            if any(t is None for t in tests):
                if len(tests) > 1 or index != len(node.cases) - 1:
                    self.fail(case, 'default case must be last and alone')
                header = 'else:' if lines else 'if True:'
            else:
                condition = ' or '.join(f'{subject} == {self.expr(t)}' for t in tests)
                header = ('elif ' if lines else 'if ') + condition + ':'
            lines += [pad + header] + (self.block(body, depth + 1, loop) if body else [pad + '    pass'])
        return lines



def _is_string(node):
    """Statically a string: a string literal, a template, or a + chain containing one (JavaScript + then concatenates)."""
    if (node.type == 'Literal' and isinstance(node.value, str)) or node.type == 'TemplateLiteral':
        return True
    return node.type == 'BinaryExpression' and node.operator == '+' and (_is_string(node.left) or _is_string(node.right))


def _is_null(node):
    return (node.type == 'Literal' and node.value is None and not getattr(node, 'regex', None)) or (
        node.type == 'Identifier' and node.name == 'undefined')


def _is_snowflake_api(callee):
    return callee.type == 'MemberExpression' and callee.object.type == 'Identifier' and callee.object.name == 'snowflake'


def _children(node):
    for value in vars(node).values():
        items = value if isinstance(value, list) else [value]
        for item in items:
            if hasattr(item, 'type') and isinstance(getattr(item, 'type'), str):
                yield item


LOOPS = ('FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression', 'WhileStatement', 'DoWhileStatement',
         'ForStatement', 'ForOfStatement', 'ForInStatement')


def _contains(node, kind, stop=LOOPS + ('SwitchStatement',)):
    """True if `kind` occurs in node without crossing a `stop` construct (which owns its own break/continue)."""
    if node.type == kind:
        return True
    return any(child.type == kind or (child.type not in stop and _contains(child, kind, stop)) for child in _children(node))


def _assigned(node):
    found = set()
    for child in _children(node):
        if child.type == 'AssignmentExpression' and child.left.type == 'Identifier':
            found.add(child.left.name)
        if child.type == 'UpdateExpression' and child.argument.type == 'Identifier':
            found.add(child.argument.name)
        if child.type not in ('FunctionDeclaration', 'FunctionExpression'):
            found |= _assigned(child)
    return found


def _declared(function):
    names = {p.name for p in function.params if p.type == 'Identifier'}
    def walk(node):
        for child in _children(node):
            if child.type == 'VariableDeclarator' and child.id.type == 'Identifier':
                names.add(child.id.name)
            if child.type not in ('FunctionDeclaration', 'FunctionExpression'):
                walk(child)
    walk(function.body)
    return names



def _split_fqn(name: str) -> list[str]:
    return re.findall(r'"(?:[^"]|"")*"|[^.\s]+', name)


def _parse(body):
    try:
        import esprima
    except ImportError:
        raise ConverterUnavailable('esprima not installed: the deterministic JavaScript converter needs esprima==4.0.1 '
                                   '(apps/domo-migration-platform/requirements.txt)') from None
    try:
        return esprima.parseScript('function __body__() {\n' + body + '\n}', {'loc': True}).body[0]
    except esprima.Error as error:
        message = str(error)
        line = re.search(r'Line (\d+)', message)
        raise CodeRefused('JavaScript syntax error' + (f' at line {int(line.group(1)) - 1}' if line else '') + ': '
                          + message.split(':', 1)[-1].strip()[:80]) from None


def _helpers(used):
    pending, ordered = list(used), []
    while pending:
        name = pending.pop()
        if name in ordered:
            continue
        ordered.append(name)
        pending += HELPER_DEPENDS.get(name, [])
    ordered.sort(key=lambda name: (name == '_snowflake', name))
    imports = sorted({HELPER_IMPORTS[name] for name in ordered if name in HELPER_IMPORTS})
    return imports, [HELPERS[name] for name in ordered]


def _translate(obj: CodeObject, svc: CodeServices, allow_sql: bool):
    function = _parse(obj.body or '')
    translator = _Translator(svc, allow_sql)
    # JavaScript procedures and UDFs see their arguments upper-cased.
    names = [translator.name(arg['name'].upper()) for arg in obj.args]
    if any(not name.isidentifier() for name in names):
        raise CodeRefused('argument names must be simple identifiers')

    def callables(node):
        for child in _children(node):
            if child.type == 'FunctionDeclaration':
                translator.functions.add(child.id.name)
            if child.type == 'VariableDeclarator' and child.init is not None and child.init.type == 'ArrowFunctionExpression':
                translator.functions.add(child.id.name)
            callables(child)
    callables(function.body)
    lines = translator.block(function.body.body, 1)
    return names, lines, translator


def convert_javascript_procedure(obj: CodeObject, svc: CodeServices, notebook: str) -> tuple[str, list[str]]:
    """``(notebook source, notes)``; raises ``CodeRefused`` (a precise reason with the line)."""
    names, lines, translator = _translate(obj, svc, True)
    returns = (obj.returns or '').upper()
    if returns.startswith('TABLE'):
        raise CodeRefused('JavaScript procedures returning TABLE need manual conversion')
    json_result = returns.startswith(('VARIANT', 'OBJECT', 'ARRAY'))
    if not json_result:
        translator.use('_s')
    imports, helpers = _helpers(translator.helpers)
    imports = sorted(set(imports) | {'datetime', 'json', 're', 'math'})
    out = ['# Databricks notebook source', notebook, ''] + [f'import {name}' for name in imports] + ['']
    out += ['def _bool(value):', '    return value.strip().lower() in ("true", "1", "yes")', '',
            'def _arg(name, cast):', '    value = dbutils.widgets.get(name)', '    return None if value == "" else cast(value)', '']
    for arg in obj.args:
        out.append(f'dbutils.widgets.text({json.dumps(arg["name"])}, "")')
    schema = svc.names.schema_of(obj.database, obj.schema) if obj.database and obj.schema else None
    if schema:
        out += ['', "# Unqualified names resolve against the procedure's own database and schema, as in Snowflake.",
                f'spark.sql({json.dumps("USE " + schema)})']
    else:
        translator.notes.append("SEM004|the procedure's own schema did not land in one Databricks schema: unqualified "
                                'names in SQL built at run time are not resolved')
    out += ['', '# COMMAND ----------', '']
    out += [helper + '\n' for helper in helpers]
    out += [f'def _procedure({", ".join(names)}):'] + lines + ['', '', '# COMMAND ----------', '']
    call_args = ', '.join(f'_arg({json.dumps(arg["name"])}, {caster(arg["type"])})' for arg in obj.args)
    out.append(f'_result = _procedure({call_args})')
    out.append('dbutils.notebook.exit(json.dumps(_result, default=str))' if json_result
               else 'dbutils.notebook.exit("" if _result is None else _s(_result))')
    notes = list(dict.fromkeys(translator.notes)) + [
        'SEM004|Notebook runs with the job principal, not Snowflake owner/caller rights; review access before deployment',
        'SEM004|Return value is the notebook exit string (dbutils.notebook.run returns it to callers)']
    if '_snowflake' in translator.helpers:
        notes += ['SEM004|ResultSets are collected to the driver; very large result sets need a DataFrame rewrite',
                  'SEM004|DATE/TIMESTAMP values are Python datetimes, not Snowflake SfDate objects; check string formatting']
        if 'binds' in (obj.body or ''):
            notes.append('SETUP001|Bind variables use spark.sql(args=[...]) positional markers (Databricks Runtime 14+ / serverless)')
    return '\n'.join(out) + '\n', notes


def convert_javascript_udf(obj: CodeObject, target: str, args_sql: str, returns_sql: str,
                           svc: CodeServices) -> tuple[str, list[str]]:
    """``(CREATE FUNCTION ... LANGUAGE PYTHON, notes)``; raises ``CodeRefused``."""
    if obj.table_function:
        raise CodeRefused('JavaScript table functions need manual conversion')
    names, lines, translator = _translate(obj, svc, False)
    imports, helpers = _helpers(translator.helpers)
    text = '\n'.join(lines)
    imports = sorted(set(imports) | ({'json'} if 'json.' in text else set()) | ({'re'} if 're.' in text else set())
                     | ({'math'} if 'math.' in text else set()))
    declared = [arg['name'] for arg in obj.args]
    if any(not name.isidentifier() for name in declared):
        raise CodeRefused('argument names must be valid Python identifiers')
    body = [f'import {name}' for name in imports] + [helper for helper in helpers]
    body += [f'def _udf({", ".join(names)}):'] + lines
    body.append(f'return _udf({", ".join(declared)})')
    if '$$' in '\n'.join(body):
        raise CodeRefused('translated body contains $$')
    code = (f'CREATE OR REPLACE FUNCTION {target}({args_sql})\nRETURNS {returns_sql}\nLANGUAGE PYTHON\n'
            'AS $$\n' + '\n'.join(body) + '\n$$')
    notes = list(dict.fromkeys(translator.notes)) + [
        'SETUP001|Unity Catalog Python UDFs require Databricks SQL (pro/serverless) or DBR 13.3+ with Unity Catalog',
        'SEM004|JavaScript numbers are doubles; the Python UDF keeps integers exact, which can differ for very large values']
    return code, notes


__all__ = ["CodeRefused", "convert_javascript_procedure", "convert_javascript_udf"]
