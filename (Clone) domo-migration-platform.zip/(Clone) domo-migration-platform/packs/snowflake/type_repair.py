# Ported from SNF2DBX-main/migration/type_repair.py (LatentView internal)
"""packs.snowflake.type_repair - repair of set-operation type conflicts (S10, ADR 037; catalogue X2 type-repair port).

Databricks requires every column of a set operation (UNION / INTERSECT / EXCEPT, including a recursive CTE) to have one
type across its branches; Snowflake coerces silently. Typical case: an identity column mapped to BIGINT is unioned
with a NUMBER(38,0) column mapped to DECIMAL(38,0) -> ``[CANNOT_MERGE_INCOMPATIBLE_DATA_TYPE]``.

The warehouse is the authority on types: each branch is described with ``DESCRIBE QUERY`` (read-only) through the
``Warehouse`` port (``packs.snowflake.warehouse``), the column types are widened to a common type, and every branch
gets explicit CASTs. ``repair_statement`` returns the repaired text and the per-column changes; the caller
(``packs.snowflake.verify``) offers it only if it passes ``EXPLAIN``, and always with the review caveat
``SNW-TYPE-REPAIR`` (a cast can change a value: it is never applied silently). Changes list column labels and types
only, never SQL text.
"""
from __future__ import annotations

import re

import sqlglot
from sqlglot import exp

from packs.snowflake.sqlscan import strip_comments
from packs.snowflake.warehouse import Warehouse, WarehouseError, describe_query

TYPE_ERROR_RX = re.compile(r"CANNOT_MERGE_INCOMPATIBLE_DATA_TYPE|INCOMPATIBLE_COLUMN_TYPE|NUM_COLUMNS_MISMATCH|"
                           r"DATATYPE_MISMATCH|incompatible data types", re.I)
_QUERY_RX = re.compile(r"^(?P<head>\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMPORARY\s+)?(?:MATERIALIZED\s+)?"
                       r"(?:VIEW|TABLE)\b.*?\bAS\s*)(?P<paren>\()?\s*(?P<query>(?:SELECT|WITH)\b.*)", re.I | re.S)
#: sqlglot renamed the ``with`` arg to ``with_`` (the migrator pins a recent one); accept both
_WITH = "with_" if "with_" in exp.Select.arg_types else "with"
_INTEGERS = {"TINYINT": 3, "BYTE": 3, "SMALLINT": 5, "SHORT": 5, "INT": 10, "INTEGER": 10, "BIGINT": 19, "LONG": 19}
_DECIMAL_RX = re.compile(r"(?:DECIMAL|NUMERIC|DEC)\s*\(\s*(\d+)\s*(?:,\s*(\d+))?\s*\)", re.I)


def is_type_error(error_class_or_text: str) -> bool:
    return bool(TYPE_ERROR_RX.search(error_class_or_text or ""))


def _numeric(kind: str):
    """(integer digits, scale) for exact numerics, 'float' for approximate, None otherwise."""
    upper = kind.strip().upper()
    if upper in _INTEGERS:
        return _INTEGERS[upper], 0
    match = _DECIMAL_RX.fullmatch(upper)
    if match:
        precision, scale = int(match.group(1)), int(match.group(2) or 0)
        return precision - scale, scale
    if upper in ("DECIMAL", "NUMERIC"):
        return 10, 0
    if upper in ("FLOAT", "DOUBLE", "REAL"):
        return "float"
    return None


def widen(left: str, right: str) -> str | None:
    """Smallest type both values fit in, or None when no lossless common type exists."""
    if left.strip().upper() == right.strip().upper():
        return left
    a, b = _numeric(left), _numeric(right)
    if a is not None and b is not None:
        if a == "float" or b == "float":
            return "DOUBLE"
        if a[1] == 0 and b[1] == 0 and left.strip().upper() in _INTEGERS and right.strip().upper() in _INTEGERS:
            return left if a[0] >= b[0] else right
        digits, scale = max(a[0], b[0]), max(a[1], b[1])
        return f"DECIMAL({min(38, digits + scale)},{scale})"
    pair = {left.strip().upper(), right.strip().upper()}
    if pair <= {"DATE", "TIMESTAMP", "TIMESTAMP_NTZ"}:
        return "TIMESTAMP_NTZ" if "TIMESTAMP_NTZ" in pair else "TIMESTAMP"
    if "STRING" in pair:
        return "STRING"
    return None


def _date_step(projection: exp.Expression) -> bool:
    """DATEADD / date_add / add_months by whole days, weeks, months, quarters or years (no time-of-day part)."""
    node = projection.this if isinstance(projection, exp.Alias) else projection
    if isinstance(node, (exp.DateAdd, exp.DateSub, exp.TsOrDsAdd, exp.TimestampAdd)):
        unit = (node.args.get("unit").name if node.args.get("unit") is not None else "DAY").upper()
        return unit in ("DAY", "DAYS", "WEEK", "WEEKS", "MONTH", "MONTHS", "QUARTER", "YEAR", "YEARS")
    return isinstance(node, exp.AddMonths)


def _branches(node: exp.Expression) -> list[exp.Select]:
    if isinstance(node, exp.SetOperation):
        return _branches(node.this) + _branches(node.expression)
    if isinstance(node, exp.Subquery):
        return _branches(node.this)
    return [node] if isinstance(node, exp.Select) else []


def _top_set_operations(tree: exp.Expression):
    """Outermost set operations (a chain a UNION b UNION c is one operation with three branches)."""
    return [n for n in tree.walk() if isinstance(n, exp.SetOperation) and not isinstance(n.parent, exp.SetOperation)]


def _probe(branch: exp.Select, tree: exp.Expression, recursive: dict[str, tuple[exp.Select, list[str]]]) -> str:
    """Stand-alone SQL with the branch's column types: sibling CTEs kept, recursive self-references replaced by the
    anchor branch (the anchor determines the types the recursion starts from). The stand-in carries the CTE's declared
    column names, so references such as h.ANCESTORBRANCHID still resolve."""
    probe = branch.copy()
    for table in list(probe.find_all(exp.Table)):
        entry = recursive.get(table.name.lower()) if not table.args.get("db") else None
        if entry is not None:
            anchor, columns = entry
            alias = exp.TableAlias(this=exp.to_identifier(table.alias_or_name),
                                   columns=[exp.to_identifier(c) for c in columns])
            table.replace(exp.Subquery(this=anchor.copy(), alias=alias))
    with_ = tree.args.get(_WITH)
    if with_ is not None:
        siblings = [cte.copy() for cte in with_.expressions if cte.alias.lower() not in recursive]
        if siblings:
            probe.set(_WITH, exp.With(expressions=siblings))
    return probe.sql(dialect="databricks")


def _describe(wh: Warehouse, sql: str) -> list[str]:
    return [t for _, t in describe_query(wh, sql)]


def keep_markers(original: str, repaired: str) -> str:
    """The repaired statement with the original's leading comment lines (NODE markers) kept."""
    head = []
    for line in original.lstrip("\n").splitlines():
        if line.strip().startswith("--") or not line.strip():
            head.append(line)
        else:
            break
    return "\n".join(head + [repaired.strip()])


def repair_statement(wh: Warehouse, statement: str) -> dict | None:
    """``{"sql", "changes"}`` with explicit casts, or None when nothing can (or needs to) be repaired. A warehouse
    failure while describing a branch means the branch cannot be typed: no repair (never a guessed one)."""
    text = strip_comments(statement).strip().rstrip(";")
    match = _QUERY_RX.match(text)
    if match:
        query, head, paren = match.group("query").strip(), match.group("head"), bool(match.group("paren"))
        if paren and query.endswith(")"):
            query = query[:-1]
    elif re.match(r"\s*(SELECT|WITH)\b", text, re.I):
        query, head, paren = text.strip(), "", False
    else:
        return None
    try:
        tree = sqlglot.parse_one(query, read="databricks")
    except sqlglot.errors.SqlglotError:
        return None
    recursive: dict[str, tuple[exp.Select, list[str]]] = {}
    with_ = tree.args.get(_WITH)
    if with_ is not None and with_.args.get("recursive"):
        for cte in with_.expressions:
            branches = _branches(cte.this)
            if len(branches) > 1:
                alias = cte.args.get("alias")
                columns = ([c.name for c in alias.columns] if alias is not None and alias.columns
                           else [p.alias_or_name for p in branches[0].expressions])
                if len(columns) != len(branches[0].expressions) or not all(columns):
                    return None             # cannot name the recursion's columns reliably
                recursive[cte.alias.lower()] = (branches[0], columns)
    changes: list[str] = []
    try:
        for operation in _top_set_operations(tree):
            branches = _branches(operation)
            if len(branches) < 2 or any(isinstance(e, exp.Star) or e.find(exp.Star)
                                        for b in branches for e in b.expressions):
                continue
            described = [_describe(wh, _probe(b, tree, recursive)) for b in branches]
            width = len(branches[0].expressions)
            if any(len(t) != width or len(b.expressions) != width for t, b in zip(described, branches, strict=True)):
                continue
            names = [p.alias_or_name for p in branches[0].expressions]
            holder = operation.parent if isinstance(operation.parent, exp.CTE) else None
            declared = ([c.name for c in holder.args["alias"].columns]
                        if holder is not None and holder.args.get("alias") else [])
            labels = declared if len(declared) == width else names
            common: list[str | None] = []
            for pos in range(width):
                kind: str | None = described[0][pos]
                for types in described[1:]:
                    kind = kind and widen(kind, types[pos])
                if (holder is not None and holder.alias.lower() in recursive and described[0][pos].upper() == "DATE"
                        and kind and kind.upper().startswith("TIMESTAMP")
                        and all(_date_step(b.expressions[pos]) for b in branches[1:])):
                    # Recursive CTE: Snowflake keeps the anchor's DATE (DATEADD by days/months/years on a DATE is a
                    # DATE there); Databricks DATEADD returns a TIMESTAMP. Casting back keeps Snowflake's values.
                    kind = "DATE"
                common.append(kind)
            for pos, kind in enumerate(common):
                if not kind or all(t[pos].upper() == kind.upper() for t in described):
                    continue
                changes.append(f"{labels[pos] or 'column ' + str(pos + 1)}: "
                               + " / ".join(t[pos] for t in described) + f" -> {kind}")
                for index, branch in enumerate(branches):
                    projection = branch.expressions[pos]
                    inner = projection.this if isinstance(projection, exp.Alias) else projection
                    cast = exp.Cast(this=inner.copy(), to=exp.DataType.build(kind, dialect="databricks"))
                    alias = names[pos] if index == 0 else projection.alias_or_name
                    projection.replace(exp.alias_(cast, alias) if alias else cast)
    except WarehouseError:
        return None
    if not changes:
        return None
    rendered = tree.sql(dialect="databricks", pretty=True)
    if recursive and not re.match(r"\s*WITH\s+RECURSIVE\b", rendered, re.I):
        rendered = re.sub(r"^\s*WITH\b", "WITH RECURSIVE", rendered, count=1, flags=re.I)   # the writer drops it
    return {"sql": head + ("(" if paren else "") + rendered + (")" if paren else ""), "changes": changes}


__all__ = ["TYPE_ERROR_RX", "is_type_error", "keep_markers", "repair_statement", "widen"]
