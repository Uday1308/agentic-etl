# Informed by SNF2DBX-main/migration/compile_check.py and correctness.py (LatentView internal)
"""packs.snowflake.verify - post-conversion validation against a SQL warehouse (S3, ADR 037; catalogue X2).

Optional per batch. ``BatchContext.verify`` is ``None`` (off: nothing is recorded) or a ``VerifyConfig``. With a
config whose ``warehouse`` is ``None`` (nothing configured) every converted unit records ``verify.status =
"unverifiable"`` with the reason: never ``passed`` (hard rule 6).

Checks, per converted unit (read-only; EXPLAIN and DESCRIBE QUERY never execute anything):

    explain   EXPLAIN on every converted statement / view query / CTAS query. ``failed`` carries the Databricks
              ERROR CLASS only (never the message: it quotes source text). A missing-object class
              (TABLE_OR_VIEW_NOT_FOUND, ...) is ``unverifiable``: the object may be created by the same plan.
    schema    DESCRIBE QUERY vs the expected column types (X2: ``conversion.column_types`` of the created object,
              source types mapped to Databricks). Names, order and the type family (+ scale of exact numerics).
    repair    a set-operation type conflict (S10) is repaired with explicit CASTs through ``type_repair`` and
              accepted only if the repaired text passes EXPLAIN; it always adds the review caveat SNW-TYPE-REPAIR.

Feeding the gates: a failed explain adds the ``escalate`` caveat SNW-VERIFY-EXPLAIN, a failed schema comparison the
``review`` caveat SNW-VERIFY-SCHEMA, to ``unit.review_caveats``, so the unit needs review and its gates open.
Evidence is ``unit.evidence["verify"]`` and holds no SQL text, no source text.

After a deploy (when one happens later) ``check_deployed`` runs object-exists checks (DESCRIBE TABLE / FUNCTION /
PROCEDURE) over the deployed objects and returns an evidence dict in the same vocabulary.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from packs.snowflake import type_repair as tr
from packs.snowflake.scripting import split_scripting
from packs.snowflake.sqlscan import strip_comments
from packs.snowflake.validators import sniff_kind
from packs.snowflake.warehouse import (
    MISSING_OBJECT_CLASSES,
    Warehouse,
    WarehouseError,
    describe_query,
    explain,
)

PASSED, FAILED, UNVERIFIABLE, NOT_APPLICABLE = "passed", "failed", "unverifiable", "not_applicable"
CAV_EXPLAIN, CAV_SCHEMA, CAV_REPAIR = "SNW-VERIFY-EXPLAIN", "SNW-VERIFY-SCHEMA", "SNW-TYPE-REPAIR"

_QUERY_RX = re.compile(r"^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMPORARY\s+)?(?:MATERIALIZED\s+)?(?P<kind>VIEW|TABLE)\b"
                       r"(?P<head>.*?)\bAS\s*(?P<paren>\()?\s*(?P<query>(?:SELECT|WITH)\b.*)", re.I | re.S)
_EXPLAINABLE = re.compile(r"^\s*\(?\s*(SELECT|WITH|INSERT|MERGE|UPDATE|DELETE)\b", re.I)
_PART = r"(?:`[^`]+`|[\w$]+)"
_NAME = re.compile(rf"^\s*(?:IF\s+NOT\s+EXISTS\s+)?(?P<name>{_PART}(?:\.{_PART}){{0,2}})\s*(?P<cols>\(.*\))?",
                   re.S | re.I)


@dataclass
class VerifyConfig:
    #: the port; ``None`` = nothing configured (units record ``unverifiable`` with ``reason``)
    warehouse: Warehouse | None = None
    reason: str = "no SQL warehouse configured"
    check_schema: bool = True
    repair_types: bool = True
    #: True: a missing object is a failure (every referenced table is expected to be landed already)
    missing_is_failure: bool = False
    #: filled as units are verified: ``{"unit_id", "status", ...}`` (no SQL), the batch report's ``verify`` section
    units: list[dict] = field(default_factory=list)

    def summary(self) -> dict:
        counts = Counter(u["status"] for u in self.units)
        return {"enabled": True, "warehouse": self.warehouse is not None,
                **({} if self.warehouse is not None else {"reason": self.reason}),
                "units": len(self.units), "by_status": dict(sorted(counts.items())),
                "failed": [u["unit_id"] for u in self.units if u["status"] == FAILED]}


# ------------------------------------------------------------------------------------------------ what to check
def query_of(statement: str) -> str | None:
    """The query of ``CREATE [OR REPLACE] VIEW|TABLE ... AS <query>``, comments stripped; None for another shape."""
    m = _QUERY_RX.match(strip_comments(statement))
    if not m:
        return None
    q = m.group("query").strip().rstrip(";").strip()
    return q[:-1] if m.group("paren") and q.endswith(")") else q


def created_object(statement: str) -> tuple[str, list[str]] | None:
    """``(lower-case name, declared column list)`` of a CREATE VIEW / TABLE ... AS statement."""
    m = _QUERY_RX.match(strip_comments(statement))
    if not m:
        return None
    n = _NAME.match(m.group("head"))
    if not n:
        return None
    cols = [c.strip().strip("`") for c in n.group("cols")[1:-1].split(",")] if n.group("cols") else []
    return n.group("name").replace("`", "").lower(), [c for c in cols if c]


def explain_targets(kind: str, sql: str) -> list[str]:
    """The queries / statements to EXPLAIN for one converted text (``[]`` = nothing explainable: not applicable)."""
    text = strip_comments(sql or "").strip().rstrip(";").strip()
    if not text:
        return []
    q = query_of(text)
    if q:
        return [q]
    if kind == "pipeline":
        m = re.search(r"\bAS\b\s*(.+)$", text, re.I | re.S)
        return [m.group(1).strip()] if m else []
    if kind == "script":
        m = re.search(r"\bBEGIN\b(.*)\bEND\b\s*;?\s*$", text, re.I | re.S)
        nodes = split_scripting("BEGIN " + (m.group(1) if m else "") + " END")
        return [n.text for n in nodes if n.kind == "statement" and _EXPLAINABLE.match(n.text)]
    return [text] if _EXPLAINABLE.match(text) else []


# ------------------------------------------------------------------------------------------------ type comparison
def _norm(type_text: str | None) -> tuple[str, int | None] | None:
    """``(category, scale)`` of a Databricks or Snowflake type text; None when unknown."""
    if not type_text:
        return None
    t = re.sub(r"\s+", " ", type_text.strip().upper())
    m = re.match(r"^(?:DECIMAL|NUMERIC|DEC|NUMBER)\s*(?:\(\s*\d+\s*(?:,\s*(\d+))?\s*\))?$", t)
    if m:
        return "exact", int(m.group(1) or 0)
    if t in ("TINYINT", "SMALLINT", "INT", "INTEGER", "BIGINT", "LONG", "SHORT", "BYTE", "BYTEINT"):
        return "exact", 0
    if t in ("DOUBLE", "FLOAT", "REAL", "DOUBLE PRECISION", "FLOAT4", "FLOAT8"):
        return "float", None
    base = re.split(r"[(<\s]", t, maxsplit=1)[0]
    if base in ("STRING", "VARCHAR", "CHAR", "TEXT", "CHARACTER", "NCHAR", "NVARCHAR"):
        return "string", None
    if base == "BOOLEAN":
        return "bool", None
    if base == "DATE":
        return "date", None
    if base in ("TIMESTAMP_NTZ", "DATETIME"):
        return "timestamp_ntz", None
    if base == "TIMESTAMP":
        return "timestamp", None
    if base in ("BINARY", "VARBINARY"):
        return "binary", None
    if base in ("VARIANT", "ARRAY", "MAP", "STRUCT", "OBJECT"):
        return "variant", None
    return "other", None


def expected_target_type(source_type: str | None) -> str | None:
    """The Databricks type a SOURCE (Snowflake) type lands as, or None when it is unknown or unmapped."""
    if not source_type:
        return None
    from packs.snowflake.scripting_convert import ScriptingUnsupported, map_type
    try:
        return map_type(source_type)[0]
    except (ScriptingUnsupported, ValueError):
        return None


def compare_schema(expected: dict[str, str | None] | list[tuple[str, str | None]], actual: list[tuple[str, str]]
                   ) -> dict:
    """``{"status", "problems": [...], "checked": n, "unknown": n}``. ``expected`` is ``{column: SOURCE type | None}``
    in order. Problems name columns and type categories only. A column whose expected type is unknown is not checked
    (counted in ``unknown``); when none can be checked the status is ``unverifiable`` (never a vacuous pass)."""
    exp_list = list(expected.items()) if isinstance(expected, dict) else list(expected)
    problems: list[str] = []
    en, an = [c.lower() for c, _ in exp_list], [c.lower() for c, _ in actual]
    if en != an:
        lost, extra = [c for c in en if c not in an], [c for c in an if c not in en]
        if lost:
            problems.append("missing columns: " + ", ".join(lost))
        if extra:
            problems.append("extra columns: " + ", ".join(extra))
        if not lost and not extra:
            problems.append("column order differs")
    got = {c.lower(): t for c, t in actual}
    checked = unknown = 0
    for col, src in exp_list:
        want = _norm(expected_target_type(src))
        have = _norm(got.get(col.lower()))
        if want is None or have is None:
            unknown += col.lower() in got
            continue
        checked += 1
        if want[0] != have[0] or (want[0] == "exact" and want[1] != have[1]):
            problems.append(f"{col.lower()}: expected {want[0]}{'' if want[1] is None else f' scale {want[1]}'}, "
                            f"got {have[0]}{'' if have[1] is None else f' scale {have[1]}'}")
    if problems:
        status = FAILED
    elif checked == 0:
        status = UNVERIFIABLE
    else:
        status = PASSED
    return {"status": status, "problems": problems, "checked": checked, "unknown": unknown,
            **({"reason": "no expected column types for this object"} if status == UNVERIFIABLE else {})}


# ------------------------------------------------------------------------------------------------ one unit
def _explain_one(cfg: VerifyConfig, wh: Warehouse, query: str) -> tuple[str, str]:
    """``(status, error_class)``."""
    try:
        explain(wh, query)
        return PASSED, ""
    except WarehouseError as exc:
        if exc.error_class in MISSING_OBJECT_CLASSES and not cfg.missing_is_failure:
            return UNVERIFIABLE, exc.error_class
        return FAILED, exc.error_class


def verify_sql(cfg: VerifyConfig, kind: str, sql: str, *, conversion: Any = None) -> tuple[dict, str | None]:
    """``(evidence, repaired_sql | None)`` for one converted text. Never raises."""
    wh = cfg.warehouse
    if wh is None:
        return {"status": UNVERIFIABLE, "reason": cfg.reason}, None
    targets = explain_targets(kind, sql)
    ev: dict[str, Any] = {}
    repaired: str | None = None
    if not targets:
        ev["explain"] = {"status": NOT_APPLICABLE, "reason": f"nothing to EXPLAIN for a {kind or 'unknown'} artifact"}
    else:
        failed_class, unver_class, statuses = "", "", []
        for q in targets:
            status, cls = _explain_one(cfg, wh, q)
            if status == FAILED and cfg.repair_types and len(targets) == 1 and tr.is_type_error(cls):
                fix = tr.repair_statement(wh, sql)
                fix_q = query_of(fix["sql"]) if fix else None
                if fix and _explain_one(cfg, wh, fix_q or fix["sql"])[0] == PASSED:
                    repaired = fix["sql"]
                    ev["repair"] = {"status": "applied", "error_class": cls, "changes": fix["changes"]}
                    status, cls = PASSED, ""
                else:
                    ev["repair"] = {"status": "not_possible", "error_class": cls}
            statuses.append(status)
            failed_class = failed_class or (cls if status == FAILED else "")
            unver_class = unver_class or (cls if status == UNVERIFIABLE else "")
        if FAILED in statuses:
            ev["explain"] = {"status": FAILED, "error_class": failed_class, "statements": len(targets)}
        elif UNVERIFIABLE in statuses:
            ev["explain"] = {"status": UNVERIFIABLE, "error_class": unver_class, "statements": len(targets),
                             "reason": "a referenced object is not on the target yet"}
        else:
            ev["explain"] = {"status": PASSED, "statements": len(targets)}
    if cfg.check_schema and ev["explain"]["status"] == PASSED:
        ev["schema"] = _schema_check(wh, repaired or sql, conversion)
    # failed anywhere -> failed; EXPLAIN passed -> passed (the schema check's own status stays visible);
    # otherwise unverifiable (never a vacuous pass)
    ex, sc = ev["explain"]["status"], ev.get("schema", {}).get("status", NOT_APPLICABLE)
    ev["status"] = FAILED if FAILED in (ex, sc) else PASSED if ex == PASSED else UNVERIFIABLE
    if ev["status"] == UNVERIFIABLE:
        ev["reason"] = ev["explain"].get("reason", "")
    return ev, repaired


def _schema_check(wh: Warehouse, sql: str, conversion: Any) -> dict:
    made = created_object(sql)
    q = query_of(sql)
    if not made or not q:
        return {"status": NOT_APPLICABLE, "reason": "not a CREATE VIEW / TABLE AS statement"}
    name, declared = made
    cols = conversion.table_columns(name) if conversion is not None else None
    if not cols:
        return {"status": UNVERIFIABLE, "reason": "no expected column types for this object"}
    try:
        actual = describe_query(wh, q)
    except WarehouseError as exc:
        return {"status": UNVERIFIABLE, "error_class": exc.error_class, "reason": "DESCRIBE QUERY failed"}
    if declared and len(declared) == len(actual):
        actual = [(d, t) for d, (_, t) in zip(declared, actual, strict=True)]
    return compare_schema(dict(cols), actual)


def verify_results(results: list, cfg: VerifyConfig, conversion: Any = None) -> dict:
    """Verify every converted unit of one ETL: mutates ``evidence`` / ``review_caveats`` (and ``sql`` for an accepted
    type repair), appends to ``cfg.units``, returns this ETL's small summary. A unit with no code is not checked."""
    out = Counter()
    for r in results:
        if r.status != "resolved" or not r.sql:
            continue
        ev, repaired = verify_sql(cfg, r.kind, r.sql, conversion=conversion)
        r.evidence = {**r.evidence, "verify": ev}
        if repaired:
            r.sql, r.kind = repaired, sniff_kind(repaired)
            _flag(r, CAV_REPAIR)
        if ev.get("explain", {}).get("status") == FAILED:
            _flag(r, CAV_EXPLAIN)
        if ev.get("schema", {}).get("status") == FAILED:
            _flag(r, CAV_SCHEMA)
        out[ev["status"]] += 1
        cls = ev.get("explain", {}).get("error_class")
        cfg.units.append({"unit_id": r.unit_id, "status": ev["status"], **({"error_class": cls} if cls else {})})
    return dict(out)


def _flag(res: Any, caveat: str) -> None:
    res.caveats = sorted({*res.caveats, caveat})
    res.review_caveats = sorted({*res.review_caveats, caveat})


# ------------------------------------------------------------------------------------------------ after deploy
_DESCRIBE = {"table": "DESCRIBE TABLE", "view": "DESCRIBE TABLE", "materialized_view": "DESCRIBE TABLE",
             "streaming_table": "DESCRIBE TABLE", "function": "DESCRIBE FUNCTION", "procedure": "DESCRIBE PROCEDURE"}


def _q(name: str) -> str:
    return ".".join("`" + p.replace("`", "``") + "`" for p in name.replace("`", "").split("."))


def check_deployed(wh: Warehouse | None, objects: list[dict], *, reason: str = "no SQL warehouse configured") -> dict:
    """Object-exists checks after a deploy. ``objects``: ``[{"name": "cat.schema.obj", "kind": "table|view|function|
    procedure|..."}]``. With no warehouse every object is ``unverifiable`` (never passed)."""
    rows = []
    for o in objects:
        name, kind = str(o.get("name") or ""), str(o.get("kind") or "").lower()
        if wh is None:
            rows.append({"name": name, "kind": kind, "status": UNVERIFIABLE, "reason": reason})
        elif kind not in _DESCRIBE or name.count(".") != 2:
            rows.append({"name": name, "kind": kind, "status": NOT_APPLICABLE,
                         "reason": "no object-exists check for this kind or a name that is not catalog.schema.object"})
        else:
            try:
                wh.sql(f"{_DESCRIBE[kind]} {_q(name)}")
                rows.append({"name": name, "kind": kind, "status": PASSED})
            except WarehouseError as exc:
                rows.append({"name": name, "kind": kind, "status": FAILED, "error_class": exc.error_class})
    sts = {r["status"] for r in rows}
    status = (FAILED if FAILED in sts else UNVERIFIABLE if UNVERIFIABLE in sts or sts <= {NOT_APPLICABLE}
              else PASSED)
    return {"status": status, "objects": rows}


__all__ = ["CAV_EXPLAIN", "CAV_REPAIR", "CAV_SCHEMA", "VerifyConfig", "check_deployed", "compare_schema",
           "created_object", "expected_target_type", "explain_targets", "query_of", "verify_results", "verify_sql"]
