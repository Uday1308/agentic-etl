"""packs.snowflake.postpass - tier 0 and the one deterministic post-pass every tier's output goes through
(ADR 032 sections 3-4, P3-08).

Tier 0 is ``sqlglot.transpile(read="snowflake", write="databricks", unsupported_level=RAISE)`` plus the pack rules
(function renames sqlglot does not know). The post-pass then, in order: qualifies 1- and 2-part names with the
object's own database and schema (recording the assumption, ``SNW-NAME-RESOLUTION``), rewrites every ``exp.Table``
through ``table_map``, folds unquoted identifiers to lower case (casing contract, ADR 031), and maps columns through
the landed ``source_columns``. A reference still unmapped afterwards is a validation problem (``block``), except
local names (CTEs) and anything in ``convention`` (already a target name). Tier 1-3 drafts and a reviewer's
``provided`` SQL pass the same function, so they get exactly the rewrites tier 0 gets.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import ErrorLevel, exp
from sqlglot.errors import SqlglotError

SOURCE, TARGET = "snowflake", "databricks"
#: function renames sqlglot leaves as anonymous calls (pack rules; checked against the pinned sqlglot)
FUNCTION_RENAMES = {"SYSDATE": "current_timestamp", "ZEROIFNULL": "coalesce_zero"}


#: engines whose bodies are scripts with parameters / declared variables (``:name`` binds become bare names)
PROCEDURE_ENGINES = frozenset({"sql_procedure"})


@dataclass
class Tier0Result:
    ok: bool
    sql: str = ""
    reasons: list[str] = field(default_factory=list)
    #: the rule pass's flags (``packs.snowflake.rules.Flag``: caveat id, reason, row, severity); empty without a context
    flags: list = field(default_factory=list)


def transpile(sql: str, *, read: str = SOURCE, write: str = TARGET, conversion: Any = None, names: Any = None
              ) -> Tier0Result:
    """Tier 0: transpile with ``unsupported_level=RAISE`` then the pack rules. One statement in, one out.

    With a ``ConversionContext`` (S17a / S9, ADR 037 section 8) the Snowflake tree goes through
    ``packs.snowflake.rules`` first: one rule per catalogue section 1 row, reading the account parameters, the
    capability profile and the column types, and returning flags where it cannot decide. Without one it is the plain
    sqlglot transpile (legacy callers)."""
    try:
        if conversion is not None and read == SOURCE:
            from packs.snowflake import rules
            out, flags = rules.convert(sql, conversion, names, write=write)
        else:
            out, flags = sqlglot.transpile(sql, read=read, write=write, unsupported_level=ErrorLevel.RAISE), []
    except SqlglotError as exc:
        return Tier0Result(False, "", [f"{type(exc).__name__}: {str(exc)[:200]}"])
    if len(out) != 1:
        return Tier0Result(False, "", [f"expected one statement, got {len(out)}"])
    return Tier0Result(True, apply_rules(out[0]), [], flags)


def apply_rules(sql: str) -> str:
    """Pack rules over the Databricks text: anonymous functions sqlglot has no mapping for."""
    try:
        tree = sqlglot.parse_one(sql, read=TARGET)
    except SqlglotError:
        return sql
    for fn in list(tree.find_all(exp.Anonymous)):
        new = FUNCTION_RENAMES.get(str(fn.this).upper())
        if new == "current_timestamp":
            fn.replace(exp.CurrentTimestamp())
        elif new == "coalesce_zero" and len(fn.expressions) == 1:
            fn.replace(exp.Coalesce(this=fn.expressions[0], expressions=[exp.Literal.number(0)]))
    return tree.sql(dialect=TARGET)


@dataclass
class PostpassContext:
    #: (DB, SCHEMA, NAME) upper-case -> target ``catalog.schema.table``
    table_map: dict[tuple[str, str, str], str] = field(default_factory=dict)
    default_db: str = ""
    default_schema: str = ""
    engine: str = ""
    #: landed column map ``SOURCE_COLUMN_UPPER -> landed name`` (ADR 031 ``source_columns``)
    source_columns: dict[str, str] = field(default_factory=dict)
    #: names that are already target names (``convention`` case, section 7)
    convention: frozenset[str] = frozenset()
    #: catalog the derived names of routines (UDFs, procedures) live in: ``catalog.<db>_<schema>.<name>``
    default_catalog: str = "main"
    #: engines whose unqualified names are resolved by assumption (procedures, tasks): SNW-NAME-RESOLUTION
    assume_engines: frozenset[str] = frozenset({"sql_procedure", "task", "query"})
    #: 6.12 (overloads.py): (DB, SCHEMA, NAME) -> {argument count: renamed function, None = ambiguous}
    overload_calls: dict[tuple[str, str, str], dict[int, str | None]] = field(default_factory=dict)


@dataclass
class PostpassResult:
    sql: str
    unmapped: list[str] = field(default_factory=list)
    assumed: list[str] = field(default_factory=list)
    parse_error: str = ""
    #: overloaded UDF calls rewritten by signature (6.12) and the calls that could not be (same argument count)
    renamed: list[str] = field(default_factory=list)
    ambiguous: list[str] = field(default_factory=list)

    @property
    def problems(self) -> list[str]:
        out = [f"unmapped reference {u}" for u in self.unmapped]
        out += [f"overloaded function call {a}: members with the same argument count cannot be told apart without "
                "the argument types" for a in self.ambiguous]
        return ([f"post-pass could not parse the SQL: {self.parse_error}"] if self.parse_error else []) + out


def table_key(db: str, schema: str, name: str) -> tuple[str, str, str]:
    return (db.upper(), schema.upper(), name.upper())


class Postpass:
    """Callable post-pass. ``apply`` returns the full record; ``__call__`` is the ``ChainTranslator`` hook and
    ``problems`` its ``validate`` hook."""

    def __init__(self, ctx: PostpassContext | None = None) -> None:
        self.ctx = ctx or PostpassContext()

    def apply(self, sql: str) -> PostpassResult:
        c = self.ctx
        try:
            trees = [t for t in sqlglot.parse(sql, read=TARGET) if t is not None]
        except SqlglotError as exc:
            return PostpassResult(sql, parse_error=str(exc)[:200])
        res = PostpassResult("")
        targets = {v.lower() for v in c.table_map.values()}
        for tree in trees:
            ctes = {str(cte.alias).upper() for cte in tree.find_all(exp.CTE)}
            for t in list(tree.find_all(exp.Table)):
                name = t.name
                if not name or not isinstance(t.this, exp.Identifier) or name.upper() in ctes:
                    continue
                if t.catalog and not t.db:      # a stray one-part target name: nothing to resolve
                    continue
                if t.db.lower() == "information_schema" or t.catalog.lower() == "system":
                    continue                    # a Unity Catalog system table (S17b, rows 2.24): not a landed table
                fq = ".".join(p for p in (t.catalog, t.db, name) if p)
                if fq.lower() in targets or fq.upper() in {x.upper() for x in c.convention}:
                    continue            # already a target (or convention) name: idempotent on its own output
                db = t.catalog or c.default_db
                schema = t.db or c.default_schema
                if not t.db or not t.catalog:
                    res.assumed.append(f"{fq} -> {db}.{schema}.{name}")
                target = c.table_map.get(table_key(db, schema, name))
                if target is None:
                    res.unmapped.append(f"{db}.{schema}.{name}".strip("."))
                    continue
                new = exp.to_table(target)
                # everything but the name parts moves to the mapped table: alias, SAMPLE, time travel (version / when),
                # CHANGES, pivots ... (rebuilding from the name alone silently dropped them: rows 2.19-2.21)
                for key, val in t.args.items():
                    if key not in ("this", "db", "catalog") and val is not None:
                        new.set(key, val.copy() if isinstance(val, exp.Expression) else val)
                t.replace(new)
            self._rewrite_literal_names(tree, res, targets)
            self._rewrite_routine_calls(tree, res)
            if c.engine in PROCEDURE_ENGINES:     # `:P_LIMIT` binds a script variable; a Databricks body names it
                for ph in list(tree.find_all(exp.Placeholder)):
                    if isinstance(ph.this, str) and ph.this.isidentifier():
                        ph.replace(exp.column(ph.this))
            for ident in tree.find_all(exp.Identifier):
                if not ident.args.get("quoted"):
                    ident.set("this", str(ident.this).lower())
            if c.source_columns:
                for col in tree.find_all(exp.Column):
                    landed = c.source_columns.get(col.name.upper())
                    if landed and col.this is not None:
                        col.this.set("this", landed)
        res.sql = ";\n".join(t.sql(dialect=TARGET) for t in trees)
        res.assumed = sorted(set(res.assumed))
        res.unmapped = sorted(set(res.unmapped))
        return res

    def _rewrite_literal_names(self, tree: exp.Expression, res: PostpassResult, targets: set[str]) -> None:
        """``TABLE_CHANGES('DB.S.T', n)`` / ``IDENTIFIER('DB.S.T')`` name a table in a string: map it like a Table."""
        c = self.ctx
        for fn in list(tree.find_all(exp.Anonymous)):
            nm = str(fn.this).upper()
            if nm not in ("TABLE_CHANGES", "IDENTIFIER") or not fn.expressions:
                continue
            lit = fn.expressions[0]
            if not (isinstance(lit, exp.Literal) and lit.is_string):
                continue
            parts = [p.strip('"') for p in str(lit.this).split(".")]
            if ".".join(parts).lower() in targets or len(parts) > 3:
                continue
            db = parts[-3] if len(parts) == 3 else c.default_db
            schema = parts[-2] if len(parts) >= 2 else c.default_schema
            target = c.table_map.get(table_key(db, schema, parts[-1]))
            if target:
                lit.set("this", target)
            elif nm == "TABLE_CHANGES":
                res.unmapped.append(f"{db}.{schema}.{parts[-1]}")

    def _rewrite_routine_calls(self, tree: exp.Expression, res: PostpassResult | None = None) -> None:
        """``DB.SCHEMA.FN(...)`` / ``SCHEMA.FN(...)`` calls of a user routine become the derived target name the
        routine's own artifact is created under (``catalog.<db>_<schema>.<fn>``): one rule for definition and call."""
        from packs.snowflake.contract import derived_target
        c = self.ctx
        for dot in list(tree.find_all(exp.Dot)):
            fn = dot.expression
            if not isinstance(fn, exp.Anonymous) or isinstance(dot.parent, exp.Dot) and dot.parent.expression is dot:
                continue
            left = dot.this
            names = []
            while isinstance(left, exp.Dot) and isinstance(left.expression, exp.Identifier):
                names.insert(0, left.expression.name)
                left = left.this
            if not isinstance(left, exp.Identifier):
                continue
            names.insert(0, left.name)
            if not 1 <= len(names) <= 2:
                continue
            db, schema = (names[0], names[1]) if len(names) == 2 else (c.default_db, names[0])
            if len(names) == 2 and names[0].lower() == (c.default_catalog or "main").lower():
                continue                 # already `catalog.schema.fn`
            fname = str(fn.this)
            group = c.overload_calls.get((db.upper(), schema.upper(), fname.upper()))
            if group is not None:
                new = group.get(len(fn.expressions))
                if new is None:
                    if res is not None:
                        res.ambiguous.append(f"{db}.{schema}.{fname}({len(fn.expressions)} args)")
                else:
                    if res is not None:
                        res.renamed.append(f"{fname} -> {new}")
                    fname = new
            cat, sch, name = derived_target(c.default_catalog or "main", db, schema, fname).split(".")
            call = exp.Anonymous(this=name, expressions=[e.copy() for e in fn.expressions])
            dot.replace(exp.Dot.build([exp.to_identifier(cat), exp.to_identifier(sch), call]))

    def __call__(self, sql: str) -> str:
        return self.apply(sql).sql

    def problems(self, sql: str) -> list[str]:
        """Problems of an already post-passed text: it is re-checked, so a draft that still names an unmapped source
        object (an AI answer that kept a Snowflake name) fails validation."""
        return self.apply(sql).problems


__all__ = ["FUNCTION_RENAMES", "Postpass", "PostpassContext", "PostpassResult", "Tier0Result", "apply_rules",
           "table_key", "transpile"]
