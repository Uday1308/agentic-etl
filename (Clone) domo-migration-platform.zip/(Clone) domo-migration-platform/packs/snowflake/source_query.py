# Ported from packages/srcintel-core/src/srcintel/adapters/snowflake/{auth,client}.py (the ONE Snowflake client, D-35):
# the migrator has its own venv and cannot import srcintel, so the small read-only part is repeated here.
"""packs.snowflake.source_query - the ``SourceQuery`` of the parity checker over the Snowflake SQL API v2 (L7).

Read-only: it submits the generated aggregate statements (``parity.source_sql``) and returns ``list[dict]`` rows keyed
by the column names Snowflake reports. Auth is the key-pair JWT, signed in process (PyJWT + cryptography). Where the
credentials come from: Discovery hands the source connection's account / user / role / warehouse and key to the batch on
STDIN (``--credentials-stdin``, ADR 032 section 7: only when the manifest says ``needs_source_credentials``); the
runner puts them in ``SOURCE_CREDENTIAL_*`` variables of ITS OWN process and ``from_env`` reads them. The PEM arrives
as an owner-only file whose path is the value: it is read once into memory and the file is deleted.

No secret, token, statement text or response body is ever put in an exception message or a log line: errors carry the
HTTP status and Snowflake's code only. A missing or unusable credential is ``None`` + a reason (parity is then
``unverifiable``), never a pass (hard rule 6).
"""
from __future__ import annotations

import base64
import contextlib
import hashlib
import os
import pathlib
import re
import time
import uuid
from collections.abc import Callable
from typing import Any

DOMAIN = "snowflake" + "computing.com"
TOKEN_LIFETIME_S = 59 * 60
_POLL_S = 1.0
_DEADLINE_GRACE_S = 60.0
_RETRY = frozenset({429, 503, 504})
ENV_PREFIX = "SOURCE_CREDENTIAL_"


class SourceQueryError(Exception):
    """A Snowflake read failed. ``kind``: auth | timeout | statement | http | network. Fixed text, no secrets."""

    def __init__(self, message: str, *, kind: str = "http", code: str | None = None) -> None:
        super().__init__(message)
        self.kind, self.error_class = kind, (code or kind).upper()


def _clean(account: str) -> str:
    text = re.sub(r"^[a-z][a-z0-9+.-]*://", "", (account or "").strip(), flags=re.I)
    text = text.split("/", 1)[0].strip().rstrip(".")
    if text.lower().endswith("." + DOMAIN):
        text = text[: -len(DOMAIN) - 1]
    if not text or any(ch.isspace() for ch in text):
        raise SourceQueryError("the Snowflake account is empty or not a valid account identifier", kind="auth")
    return text


def _is_region(seg: str) -> bool:
    return "-" in seg or seg[-1:].isdigit()


def _org_form(text: str) -> bool:
    parts = text.split(".")
    if len(parts) == 1:
        return "-" in text
    return len(parts) == 2 and not _is_region(parts[1])


def account_host(account: str, host: str | None = None) -> str:
    if host and host.strip():
        return re.sub(r"^[a-z][a-z0-9+.-]*://", "", host.strip(), flags=re.I).split("/", 1)[0].strip().lower()
    text = _clean(account)
    part = text.replace(".", "-").replace("_", "-").lower() if _org_form(text) else text.lower()
    return f"{part}.{DOMAIN}"


def jwt_account(account: str) -> str:
    text = _clean(account)
    return text.replace(".", "-").upper() if _org_form(text) else text.split(".", 1)[0].upper()


class KeyPairAuth:
    def __init__(self, account: str, user: str, pem: str, passphrase: str | None = None, *,
                 clock: Callable[[], float] = time.time) -> None:
        from cryptography.exceptions import UnsupportedAlgorithm
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        if not (user or "").strip():
            raise SourceQueryError("the Snowflake user is empty", kind="auth")
        self.account, self.user = jwt_account(account), user.strip().upper()
        try:
            key = serialization.load_pem_private_key(pem.strip().encode("ascii"),
                                                     password=passphrase.encode("utf-8") if passphrase else None)
        except (ValueError, TypeError, UnsupportedAlgorithm, AttributeError):
            raise SourceQueryError("the private key could not be opened (wrong passphrase or not a PEM key)",
                                   kind="auth") from None
        if not isinstance(key, rsa.RSAPrivateKey):
            raise SourceQueryError("not an RSA private key", kind="auth")
        self._key, self._clock = key, clock
        der = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        self._fp = "SHA256:" + base64.b64encode(hashlib.sha256(der).digest()).decode("ascii")
        self._token: str | None = None
        self._exp = 0.0

    def headers(self, *, force: bool = False) -> dict[str, str]:
        import jwt

        now = self._clock()
        if force or self._token is None or now >= self._exp - 300:
            q = f"{self.account}.{self.user}"
            iat = int(now)
            self._token = jwt.encode({"iss": f"{q}.{self._fp}", "sub": q, "iat": iat, "exp": iat + TOKEN_LIFETIME_S},
                                     self._key, algorithm="RS256")
            self._exp = float(iat + TOKEN_LIFETIME_S)
        return {"Authorization": f"Bearer {self._token}", "X-Snowflake-Authorization-Token-Type": "KEYPAIR_JWT"}


class SnowflakeSourceQuery:
    """``SourceQuery`` over the SQL API. One keep-alive ``httpx.Client``; ``transport`` is for tests (MockTransport)."""

    def __init__(self, account: str, auth: KeyPairAuth, *, host: str | None = None, role: str | None = None,
                 warehouse: str | None = None, transport: Any = None, timeout_s: int = 300,
                 sleep: Callable[[float], None] = time.sleep, monotonic: Callable[[], float] = time.monotonic) -> None:
        self.host = account_host(account, host)
        self.auth, self.role, self.warehouse = auth, role or None, warehouse or None
        self.timeout_s, self._transport = int(timeout_s), transport
        self._sleep, self._mono = sleep, monotonic
        self._http: Any = None
        self.statements = 0              # aggregate statements run (budget accounting; never the text)

    def close(self) -> None:
        http, self._http = self._http, None
        if http is not None:
            http.close()

    def _client(self) -> Any:
        if self._http is None:
            import httpx

            self._http = httpx.Client(base_url=f"https://{self.host}", timeout=60.0, transport=self._transport,
                                      headers={"Accept": "application/json", "User-Agent": "source-intel-migrator/1"})
        return self._http

    def _send(self, method: str, url: str, **kw: Any) -> Any:
        import httpx

        resigned, attempt = False, 0
        while True:
            try:
                r = self._client().request(method, url, headers=self.auth.headers(), **kw)
            except httpx.TransportError as exc:
                raise SourceQueryError(f"could not reach {self.host}: {type(exc).__name__}", kind="network") from None
            if r.status_code == 401 and not resigned:
                resigned = True
                self.auth.headers(force=True)
                continue
            if r.status_code in _RETRY and attempt < 3:
                attempt += 1
                self._sleep(min(2.0 ** attempt, 10.0))
                params = kw.get("params")
                if isinstance(params, dict) and "requestId" in params:
                    kw["params"] = {**params, "retry": "true"}
                continue
            return r

    @staticmethod
    def _body(r: Any, step: str) -> dict:
        if r.status_code not in (200, 202):
            code = ""
            with contextlib.suppress(Exception):
                code = str((r.json() or {}).get("code") or "")
            kind = "auth" if r.status_code in (401, 403) else "timeout" if r.status_code == 408 else (
                "statement" if r.status_code == 422 else "http")
            raise SourceQueryError(f"{step}: HTTP {r.status_code}" + (f" ({code})" if code else ""), kind=kind,
                                   code=code or None)
        try:
            body = r.json()
        except ValueError:
            raise SourceQueryError(f"{step}: HTTP {r.status_code} with a body that is not JSON") from None
        return body if isinstance(body, dict) else {}

    def query(self, sql: str) -> list[dict]:
        body: dict[str, Any] = {"statement": sql, "timeout": self.timeout_s,
                                "parameters": {"QUERY_TAG": "srcintel-migrator-parity"}}
        if self.role:
            body["role"] = self.role
        if self.warehouse:
            body["warehouse"] = self.warehouse
        self.statements += 1
        r = self._send("POST", "/api/v2/statements", params={"requestId": str(uuid.uuid4())}, json=body)
        deadline = self._mono() + self.timeout_s + _DEADLINE_GRACE_S
        res = self._body(r, "statement submit")
        handle = str(res.get("statementHandle") or "")
        while r.status_code == 202:
            if not handle:
                raise SourceQueryError("statement submit: HTTP 202 without a statement handle")
            if self._mono() > deadline:
                self._send("POST", f"/api/v2/statements/{handle}/cancel")
                raise SourceQueryError("statement still running after the deadline; cancelled", kind="timeout")
            self._sleep(_POLL_S)
            r = self._send("GET", f"/api/v2/statements/{handle}")
            res = self._body(r, "statement status")
        meta = res.get("resultSetMetaData") or {}
        cols = [str(c.get("name")) for c in meta.get("rowType") or []]
        data = list(res.get("data") or [])
        for n in range(1, len(meta.get("partitionInfo") or [])):
            data += list(self._body(self._send("GET", f"/api/v2/statements/{handle}", params={"partition": n}),
                                    f"result partition {n}").get("data") or [])
        return [dict(zip(cols, row, strict=False)) for row in data]


def credentials_from_env(env: dict[str, str] | None = None) -> dict[str, str]:
    """``name -> value`` of the ``SOURCE_CREDENTIAL_*`` variables the runner set from stdin (lower-case names)."""
    env = os.environ if env is None else env
    return {k[len(ENV_PREFIX):].lower(): v for k, v in env.items() if k.startswith(ENV_PREFIX) and v}


def _read_key(value: str) -> str:
    """A PEM value, or the path of the owner-only file the stdin reader wrote it to (read once, then deleted)."""
    if "-----BEGIN" in value:
        return value
    path = pathlib.Path(value)
    pem = path.read_text(encoding="ascii")
    with contextlib.suppress(OSError):
        path.unlink()
    return pem


def from_env(env: dict[str, str] | None = None, *, transport: Any = None) -> tuple[SnowflakeSourceQuery | None, str]:
    """``(source, reason)``: the reason says why there is none. Never raises, never connects until first use."""
    creds = credentials_from_env(env)
    missing = [k for k in ("account", "user", "private_key") if not creds.get(k)]
    if missing:
        return None, "no Snowflake source credentials were passed to the batch (" + ", ".join(missing) + " missing)"
    try:
        auth = KeyPairAuth(creds["account"], creds["user"], _read_key(creds["private_key"]),
                           creds.get("private_key_passphrase") or creds.get("passphrase") or None)
        return SnowflakeSourceQuery(creds["account"], auth, host=creds.get("host"), role=creds.get("role"),
                                    warehouse=creds.get("warehouse"), transport=transport), ""
    except (SourceQueryError, OSError) as exc:
        detail = exc if isinstance(exc, SourceQueryError) else "key file unreadable"
        return None, f"Snowflake source unavailable: {detail}"


__all__ = ["KeyPairAuth", "SnowflakeSourceQuery", "SourceQueryError", "account_host", "credentials_from_env",
           "from_env", "jwt_account"]
