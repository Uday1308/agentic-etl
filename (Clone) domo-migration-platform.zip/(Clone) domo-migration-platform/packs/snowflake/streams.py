"""packs.snowflake.streams - tier 0 rule for statements that read a Snowflake STREAM (deterministic, no AI).

A stream read becomes the Delta change data feed: ``FROM <stream>`` -> ``FROM table_changes('<base table target>',
:start_version)`` (batch), and the stream metadata columns map onto ``_change_type``:

=========================================  ============================================
``METADATA$ACTION='INSERT'`` + not update   ``_change_type = 'insert'``
``METADATA$ACTION='INSERT'`` + ``ISUPDATE``  ``_change_type = 'update_postimage'``
``METADATA$ACTION='DELETE'`` + not update   ``_change_type = 'delete'``
``METADATA$ACTION='DELETE'`` + ``ISUPDATE``  ``_change_type = 'update_preimage'``
``METADATA$ACTION='INSERT'`` alone           ``_change_type IN ('insert', 'update_postimage')`` (a stream's INSERT row
                                            includes the new image of an update)
``METADATA$ACTION='DELETE'`` alone           ``_change_type IN ('delete', 'update_preimage')``
=========================================  ============================================

A stream created ``APPEND_ONLY`` / ``INSERT_ONLY`` shows inserts only, so its read gets ``_change_type = 'insert'``
(``types``: stream name upper case -> ``{append_only, insert_only, show_initial_rows}``, from ``objects.parse_stream``);
``SHOW_INITIAL_ROWS`` is a note (the first read must start at version 0). ``start_version`` is a parameter the job
supplies. ``METADATA$ROW_ID``, a metadata column used as a value, or a stream
without a known base table has no rule: the unit goes down the chain.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

PARAM = "start_version"
_META = ("METADATA$ACTION", "METADATA$ISUPDATE", "METADATA$ROW_ID")
_CT = "_change_type"
_PAIR = {("INSERT", False): "insert", ("INSERT", True): "update_postimage",
         ("DELETE", False): "delete", ("DELETE", True): "update_preimage"}
_ALONE = {"INSERT": ("insert", "update_postimage"), "DELETE": ("delete", "update_preimage")}


@dataclass
class StreamRewrite:
    sql: str = ""                                   # the Snowflake text with the stream reads and columns rewritten
    tables: list[str] = field(default_factory=list)  # base tables that need delta.enableChangeDataFeed
    parameter: str = PARAM
    notes_extra: list[str] = field(default_factory=list)   # stream-type facts a reviewer needs
    reasons: list[str] = field(default_factory=list)  # why no rule applies (sql == "")

    @property
    def ok(self) -> bool:
        return bool(self.sql)

    @property
    def note(self) -> str:
        return ("uses Change Data Feed; enable delta.enableChangeDataFeed on " + ", ".join(self.tables)
                + f"; the job supplies the {self.parameter} parameter (first table version to read)"
                + "".join("; " + n for n in self.notes_extra))


def _meta(node: exp.Expression | None) -> str:
    return node.name.upper() if isinstance(node, exp.Column) and node.name.upper() in _META else ""


def _ct(col: exp.Column) -> exp.Column:
    return exp.column(_CT, table=col.table or None)


def _strings(expr: exp.Expression) -> str:
    return expr.this.upper() if isinstance(expr, exp.Literal) and expr.is_string else ""


def _bool(expr: exp.Expression) -> bool | None:
    return expr.this if isinstance(expr, exp.Boolean) else None


def _unwrap(node: exp.Expression) -> exp.Expression:
    while isinstance(node, exp.Paren):
        node = node.this
    return node


def _classify(node: exp.Expression) -> tuple[str, object, exp.Column] | None:
    """``("action", 'INSERT'|'DELETE', col)`` / ``("upd", bool, col)`` for one recognised predicate, else None."""
    node = _unwrap(node)
    if isinstance(node, exp.EQ):
        for a, b in ((node.this, node.expression), (node.expression, node.this)):
            m = _meta(a)
            if m == "METADATA$ACTION" and _strings(b) in _ALONE:
                return "action", _strings(b), a
            if m == "METADATA$ISUPDATE" and _bool(b) is not None:
                return "upd", _bool(b), a
        return None
    if isinstance(node, exp.Not) and _meta(_unwrap(node.this)) == "METADATA$ISUPDATE":
        return "upd", False, _unwrap(node.this)
    if _meta(node) == "METADATA$ISUPDATE":
        return "upd", True, node
    return None


def _in(col: exp.Column, values: tuple[str, ...]) -> exp.Expression:
    return exp.In(this=_ct(col), expressions=[exp.Literal.string(v) for v in values])


def _conjuncts(node: exp.Expression) -> list[exp.Expression]:
    if isinstance(node, exp.And):
        return _conjuncts(node.this) + _conjuncts(node.expression)
    return [node]


def _combine(action: tuple[str, exp.Column] | None, upd: tuple[bool, exp.Column] | None) -> exp.Expression:
    if action and upd:
        return exp.EQ(this=_ct(action[1]), expression=exp.Literal.string(_PAIR[(action[0], upd[0])]))
    if action:
        return _in(action[1], _ALONE[action[0]])
    assert upd
    return _in(upd[1], ("update_preimage", "update_postimage") if upd[0] else ("insert", "delete"))


def rewrite(text: str, resolve: Callable[[exp.Table], str | None], types: dict[str, dict] | None = None
            ) -> StreamRewrite:
    """``resolve(table)`` returns the target base table of a stream (None: not a known stream)."""
    try:
        tree = sqlglot.parse_one(text, read="snowflake")
    except SqlglotError as exc:
        return StreamRewrite(reasons=[f"the statement does not parse: {str(exc)[:120]}"])
    if tree is None:
        return StreamRewrite(reasons=["empty statement"])
    ctes = {str(c.alias).upper() for c in tree.find_all(exp.CTE)}
    tables: list[str] = []
    extra: list[str] = []
    for t in list(tree.find_all(exp.Table)):
        if not isinstance(t.this, exp.Identifier) or t.name.upper() in ctes:
            continue
        base = resolve(t)
        if not base:
            continue
        fn = exp.Anonymous(this="table_changes", expressions=[exp.Literal.string(base), exp.Placeholder(this=PARAM)])
        new: exp.Expression = exp.Table(this=fn)
        kind = (types or {}).get(t.name.upper()) or {}
        if t.args.get("alias") is not None:
            new.set("alias", t.args["alias"].copy())
        if kind.get("append_only") or kind.get("insert_only"):      # the stream never showed updates or deletes
            only = exp.EQ(this=exp.column(_CT), expression=exp.Literal.string("insert"))
            sel = exp.select("*").from_(new).where(only)
            new = exp.Subquery(this=sel, alias=exp.TableAlias(this=exp.to_identifier(
                t.alias or t.name)))
            new.this.args["from_"].this.set("alias", None)
            extra.append(f"{t.name} is APPEND_ONLY / INSERT_ONLY: read as inserts only")
        if kind.get("show_initial_rows"):
            extra.append(f"{t.name} was created with SHOW_INITIAL_ROWS: the first run must start at version 0")
        t.replace(new)
        tables.append(base)
    if not tables:
        return StreamRewrite(reasons=["the stream's base table is unknown (no input names it)"])
    if any(_meta(c) == "METADATA$ROW_ID" for c in tree.find_all(exp.Column)):
        return StreamRewrite(reasons=["METADATA$ROW_ID has no change data feed equivalent"])
    # conjunction groups first (ACTION and ISUPDATE together), then single predicates
    for root in [n for n in tree.find_all(exp.And) if not isinstance(n.parent, exp.And)]:
        parts = _conjuncts(root)
        found = [(i, _classify(p)) for i, p in enumerate(parts)]
        acts = [(i, c) for i, c in found if c and c[0] == "action"]
        upds = [(i, c) for i, c in found if c and c[0] == "upd"]
        if not (acts or upds) or len(acts) > 1 or len(upds) > 1:
            continue
        pred = _combine((str(acts[0][1][1]), acts[0][1][2]) if acts else None,
                        (bool(upds[0][1][1]), upds[0][1][2]) if upds else None)
        first = min(i for i, _ in acts + upds)
        used = {i for i, _ in acts + upds}
        rebuilt = [pred if i == first else p for i, p in enumerate(parts) if i == first or i not in used]
        root.replace(exp.and_(*rebuilt, copy=False))
    for col in list(tree.find_all(exp.Column)):
        if not _meta(col):
            continue
        cand = col.parent if isinstance(col.parent, (exp.EQ, exp.Not)) else col
        hit = _classify(cand)
        if hit is None:
            return StreamRewrite(reasons=[f"{_meta(col)} is used in a way no rule covers (only = 'INSERT' / "
                                          "'DELETE' and ISUPDATE predicates map to _change_type)"])
        kind, val, c = hit
        cand.replace(_combine((str(val), c) if kind == "action" else None, (bool(val), c) if kind == "upd" else None))
    return StreamRewrite(sql=tree.sql(dialect="snowflake"), tables=sorted(set(tables)), notes_extra=sorted(set(extra)))


__all__ = ["PARAM", "StreamRewrite", "rewrite"]
