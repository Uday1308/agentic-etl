# Ported from SNF2DBX-main/migration/parity.py (LatentView internal)
"""packs.snowflake.parity - source/target data parity on aggregates (S4, ADR 037). No row data leaves either platform.

Per table: row count; per column: nulls, distinct values and a type-specific check (exact sum / min / max for exact
numerics, a text checksum and total length for strings, formatted min / max for dates and timestamps, true count for
booleans; VARIANT and unknown types get nulls only: JSON text differs in key order across platforms, and a type the
extraction did not describe is never guessed). BLOCKING metrics must match exactly (``Decimal`` compare, never float);
ADVISORY metrics (floating-point sums) match within a relative tolerance. The Snowflake side is read at the load's
time-travel boundary when one was recorded, so both sides describe the same data.

Two ports (``packs.snowflake.warehouse``): ``SourceQuery.query(sql)`` for Snowflake (read-only aggregates) and
``Warehouse.sql(sql)`` for Databricks. The SQL is generated (``source_sql`` / ``target_sql``) so a caller can also run
it elsewhere; the comparison is pure (``compare``) and testable offline.

Quality-framework interface (``packages/srcintel-quality`` is NOT touched here). A ``parity`` rule type wraps this
module as follows; nothing in it is migrator-specific:

    params   {"tables": [{"source": "DB.SCHEMA.T", "target": "cat.schema.t",
                          "columns": [{"name": "ID", "type": "NUMBER(38,0)"}, ...]}],
              "boundaries": {"DB.SCHEMA.T": "2026-11-06T00:00:00Z"},        # optional time-travel instant
              "tolerance": 1e-9, "column_tolerance": {"AMOUNT": 1e-6}}      # optional (``ParityConfig``)
    run      ``run_parity(source, target, tables, boundaries, config)`` -> report dict (below)
    result   report["status"]: passed | mismatched | inconclusive | unverifiable
             report["tables"][i]["status"]: passed | passed with advisory differences | mismatched | error
             report["tables"][i]["metrics"][j]: {column, metric, blocking, source, target, match}
    mapping  rule pass = table status in (passed, passed with advisory differences); a failed metric row is a rule
             violation (column + metric, never row values); ``error`` / ``unverifiable`` are NOT a pass.

``evidence_by_target(report)`` gives the per-table evidence a unit or a rule result attaches; ``attach_to_results``
does it for migrator units (adds the ``escalate`` caveat SNW-PARITY-MISMATCH on a mismatch); ``write_report`` writes the
batch-level ``parity/parity_report.json`` (no values beyond the aggregates).
"""
from __future__ import annotations

import json
import pathlib
import re
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any

from packs.snowflake.scripting_convert import ScriptingUnsupported, map_type
from packs.snowflake.warehouse import SourceQuery, Warehouse

PASSED, ADVISORY, MISMATCHED, ERROR = "passed", "passed with advisory differences", "mismatched", "error"
CAV_PARITY = "SNW-PARITY-MISMATCH"
_BOUNDARY = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?)?(?:Z|[+-]\d{2}:?\d{2})?$")
_SIMPLE_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*")


@dataclass(frozen=True)
class ParityConfig:
    #: relative tolerance of ADVISORY (floating-point) metrics
    tolerance: Decimal = Decimal("1e-9")
    #: per-column relative tolerance (UPPER or lower case column name)
    column_tolerance: dict[str, Decimal] = field(default_factory=dict)
    #: True: floating-point sums are blocking (still compared within the tolerance)
    float_blocking: bool = False
    #: text checksum / total length for string columns (one MD5 per row: skip on very large tables)
    text_checksums: bool = True

    def tolerance_of(self, column: str) -> Decimal:
        for k, v in self.column_tolerance.items():
            if k.lower() == column.lower():
                return Decimal(str(v))
        return Decimal(str(self.tolerance))


@dataclass(frozen=True)
class Metric:
    alias: str
    column: str
    metric: str
    blocking: bool
    source_expr: str
    target_expr: str
    approx: bool = False


def _snow(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _dbx(name: str) -> str:
    return "`" + name.replace("`", "``") + "`"


def target_type(source_type: str | None) -> str | None:
    """The Databricks type a source column type lands as (``map_type``); None when unknown or not deterministic."""
    if not source_type:
        return None
    try:
        return map_type(source_type)[0]
    except (ScriptingUnsupported, ValueError):
        return None


def metrics_for(columns: Iterable[dict], config: ParityConfig | None = None) -> list[Metric]:
    """``columns``: ``[{"name", "type"}]`` with SOURCE types (``type`` may be None: nulls and distinct only)."""
    cfg = config or ParityConfig()
    out = [Metric("m0", "*", "row_count", True, "COUNT(*)", "COUNT(*)")]
    for i, col in enumerate(columns):
        name, stype = col["name"], str(col.get("type") or "")
        s, d, base = _snow(name), _dbx(name), f"c{i}_"
        tgt = target_type(stype) or ""
        out.append(Metric(base + "nulls", name, "null_count", True, f"COUNT_IF({s} IS NULL)", f"COUNT_IF({d} IS NULL)"))
        if tgt == "VARIANT" or stype.upper().startswith(("ARRAY", "OBJECT", "MAP")):
            continue                      # JSON text differs in key order and spacing across platforms: nulls only
        out.append(Metric(base + "distinct", name, "distinct_count", True, f"COUNT(DISTINCT {s})",
                          f"COUNT(DISTINCT {d})"))
        if tgt.startswith("DECIMAL"):
            out += [Metric(base + "sum", name, "sum", True, f"SUM({s})", f"SUM({d})"),
                    Metric(base + "min", name, "min", True, f"MIN({s})", f"MIN({d})"),
                    Metric(base + "max", name, "max", True, f"MAX({s})", f"MAX({d})")]
        elif tgt == "DOUBLE":
            out.append(Metric(base + "sum", name, "sum", cfg.float_blocking, f"SUM({s})", f"SUM({d})", approx=True))
        elif tgt == "STRING" and cfg.text_checksums and not stype.upper().startswith(("GEOGRAPHY", "GEOMETRY")):
            text_s = f"TO_CHAR({s}, 'HH24:MI:SS')" if stype.upper().startswith("TIME") else s
            out += [Metric(base + "checksum", name, "checksum", True,
                           f"SUM(TO_NUMBER(SUBSTR(MD5({text_s}), 1, 15), 'XXXXXXXXXXXXXXX'))",
                           f"SUM(CAST(conv(substr(md5({d}), 1, 15), 16, 10) AS DECIMAL(38,0)))"),
                    Metric(base + "length", name, "total_length", True, f"SUM(LENGTH({text_s}))", f"SUM(LENGTH({d}))")]
        elif tgt == "DATE":
            out += [Metric(base + "min", name, "min", True, f"TO_CHAR(MIN({s}), 'YYYY-MM-DD')",
                           f"date_format(MIN({d}), 'yyyy-MM-dd')"),
                    Metric(base + "max", name, "max", True, f"TO_CHAR(MAX({s}), 'YYYY-MM-DD')",
                           f"date_format(MAX({d}), 'yyyy-MM-dd')")]
        elif tgt in ("TIMESTAMP", "TIMESTAMP_NTZ"):
            if tgt == "TIMESTAMP":        # an instant: compare in UTC on both sides
                src, dst = f"CONVERT_TIMEZONE('UTC', {s})", f"to_utc_timestamp({d}, current_timezone())"
            else:
                src, dst = s, d
            out += [Metric(base + "min", name, "min", True, f"TO_CHAR(MIN({src}), 'YYYY-MM-DD HH24:MI:SS.FF6')",
                           f"date_format(MIN({dst}), 'yyyy-MM-dd HH:mm:ss.SSSSSS')"),
                    Metric(base + "max", name, "max", True, f"TO_CHAR(MAX({src}), 'YYYY-MM-DD HH24:MI:SS.FF6')",
                           f"date_format(MAX({dst}), 'yyyy-MM-dd HH:mm:ss.SSSSSS')")]
        elif tgt == "BOOLEAN":
            out.append(Metric(base + "true", name, "true_count", True, f"COUNT_IF({s})", f"COUNT_IF({d})"))
    return out


# ------------------------------------------------------------------------------------------------ SQL generators
def _parts(name: str) -> list[str]:
    parts = name.split(".")
    if len(parts) != 3 or any(not _SIMPLE_NAME.fullmatch(p) for p in parts):
        raise ValueError(f"{name!r}: only simple three-part names are validated")
    return parts


def source_sql(table: str, metrics: list[Metric], boundary: str | None = None) -> str:
    """The Snowflake aggregate statement. ``boundary`` (ISO-8601 instant) reads the table AT that time-travel
    timestamp; it is validated and inlined (the source port takes no bind parameters)."""
    name = ".".join(_snow(p) for p in _parts(table))
    sql = "SELECT " + ", ".join(f"{m.source_expr} AS {m.alias}" for m in metrics) + f" FROM {name}"
    if boundary:
        if not _BOUNDARY.fullmatch(boundary.strip()):
            raise ValueError("boundary must be an ISO-8601 timestamp")
        sql += f" AT (TIMESTAMP => TO_TIMESTAMP_TZ('{boundary.strip()}'))"
    return sql


def target_sql(table: str, metrics: list[Metric]) -> str:
    """The Databricks aggregate statement."""
    name = ".".join(_dbx(p) for p in _parts(table))
    return "SELECT " + ", ".join(f"{m.target_expr} AS {m.alias}" for m in metrics) + f" FROM {name}"


# ------------------------------------------------------------------------------------------------ comparator
def _text(v: Any) -> str | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def same(left: Any, right: Any, *, blocking: bool, approx: bool = False, tolerance: Decimal = Decimal("1e-9")) -> bool:
    """Decimal-safe equality: both NULL match; one NULL does not; numbers compare as ``Decimal`` (exact when blocking
    and not approximate; relative tolerance otherwise); anything else compares as text."""
    if left is None or right is None:
        return left is None and right is None
    try:
        a, b = Decimal(str(left)), Decimal(str(right))
    except InvalidOperation:
        return _text(left) == _text(right)
    if not a.is_finite() or not b.is_finite():
        return _text(left) == _text(right)
    if blocking and not approx:
        return a == b
    return abs(a - b) <= tolerance * max(abs(a), abs(b), Decimal(1))


def compare(metrics: list[Metric], source_row: dict, target_row: dict,
            config: ParityConfig | None = None) -> list[dict]:
    cfg = config or ParityConfig()
    lo_t = {k.lower(): v for k, v in target_row.items()}
    lo_s = {k.lower(): v for k, v in source_row.items()}
    rows = []
    for m in metrics:
        left, right = lo_s.get(m.alias), lo_t.get(m.alias)
        rows.append({"column": m.column, "metric": m.metric, "blocking": m.blocking, "source": _text(left),
                     "target": _text(right),
                     "match": same(left, right, blocking=m.blocking, approx=m.approx,
                                   tolerance=cfg.tolerance_of(m.column))})
    return rows


def table_status(rows: list[dict]) -> str:
    if any(r["blocking"] and not r["match"] for r in rows):
        return MISMATCHED
    return ADVISORY if any(not r["match"] for r in rows) else PASSED


def check_table(source: SourceQuery, target: Warehouse, table: dict, boundary: str | None = None,
                config: ParityConfig | None = None) -> dict:
    """Run the matching aggregates on both platforms and compare them (``table``: source, target, columns)."""
    metrics = metrics_for(table["columns"], config)
    s_rows = source.query(source_sql(table["source"], metrics, boundary))
    t_rows = target.sql(target_sql(table["target"], metrics))
    if not s_rows or not t_rows:
        raise ValueError("an aggregate query returned no row")
    rows = compare(metrics, s_rows[0], t_rows[0], config)
    return {"source": table["source"], "target": table["target"], "status": table_status(rows), "metrics": rows,
            "boundary": boundary, "rows": next((r["source"] for r in rows if r["metric"] == "row_count"), None),
            "columns_checked": len(table["columns"])}


def run_parity(source: SourceQuery | None, target: Warehouse | None, tables: list[dict],
               boundaries: dict[str, str] | None = None, config: ParityConfig | None = None, *,
               record: Callable[[str, str, str], None] | None = None,
               cancelled: Callable[[], bool] = lambda: False, reason: str = "") -> dict:
    """The batch-level parity report. A missing port is ``unverifiable`` for every table (never a pass); an error on
    one table is recorded as ``error`` (with the exception CLASS only) and the run continues."""
    boundaries = boundaries or {}
    if source is None or target is None:
        why = reason or ("no Snowflake source connection" if source is None else "no SQL warehouse configured")
        return {"status": "unverifiable", "reason": why,
                "tables": [{"source": t["source"], "target": t["target"], "status": "unverifiable", "reason": why,
                            "metrics": []} for t in tables]}
    results = []
    for t in tables:
        if cancelled():
            break
        key = t["source"]
        if record:
            record(key, "running", "")
        try:
            out = check_table(source, target, t, boundaries.get(key) or boundaries.get(key.upper()), config)
            bad = [f"{r['column']} {r['metric']}" for r in out["metrics"] if not r["match"]]
            if record:
                record(key, "failed" if out["status"] == MISMATCHED else "succeeded",
                       out["status"] + (": " + ", ".join(bad[:5]) if bad else ""))
        except Exception as exc:         # one table must not take the batch down; the class only, never the message
            out = {"source": key, "target": t["target"], "status": ERROR,
                   "error_class": getattr(exc, "error_class", type(exc).__name__), "metrics": []}
            if record:
                record(key, "failed", ERROR)
        results.append(out)
    statuses = {r["status"] for r in results}
    status = ("passed" if results and statuses <= {PASSED, ADVISORY} else MISMATCHED if MISMATCHED in statuses
              else "inconclusive")
    return {"status": status, "tables": results,
            "summary": {s: sum(1 for r in results if r["status"] == s) for s in sorted(statuses)}}


# ------------------------------------------------------------------------------------------------ specs and evidence
def tables_from_context(conversion: Any, table_map: dict[tuple[str, str, str], str]) -> list[dict]:
    """Parity specs from the ConversionContext's column catalogue (X2): one per source table in ``table_map`` whose
    target has described columns. Types are SOURCE types (``None`` stays ``None``). Tables with no described columns
    are left out (nothing to compare is not a pass: the caller reports them as ``unverifiable``)."""
    out = []
    for (db, schema, name), tgt in sorted(table_map.items()):
        cols = conversion.table_columns(tgt)
        if cols:
            out.append({"source": f"{db}.{schema}.{name}", "target": tgt,
                        "columns": [{"name": c.upper(), "type": t} for c, t in cols.items()]})
    return out


def evidence_by_target(report: dict) -> dict[str, dict]:
    """``{target table (lower): {status, rows, mismatches[], boundary}}``: the per-table evidence (aggregates only)."""
    out = {}
    for t in report.get("tables", []):
        bad = [f"{r['column']} {r['metric']}" for r in t.get("metrics", []) if not r["match"]]
        out[str(t["target"]).lower()] = {"status": t["status"], "rows": t.get("rows"), "boundary": t.get("boundary"),
                                         "mismatches": bad[:20],
                                         **({"error_class": t["error_class"]} if t.get("error_class") else {}),
                                         **({"reason": t["reason"]} if t.get("reason") else {})}
    return out


def attach_to_results(results: list, report: dict, targets_of: Callable[[Any], Iterable[str]]) -> None:
    """Attach ``evidence["parity"]`` to each unit that writes a checked table; a mismatch adds SNW-PARITY-MISMATCH."""
    ev = evidence_by_target(report)
    for r in results:
        mine = {str(t).lower(): ev[str(t).lower()] for t in targets_of(r) if str(t).lower() in ev}
        if not mine:
            continue
        r.evidence = {**r.evidence, "parity": mine}
        if any(v["status"] == MISMATCHED for v in mine.values()):
            r.caveats = sorted({*r.caveats, CAV_PARITY})
            r.review_caveats = sorted({*r.review_caveats, CAV_PARITY})


def write_report(report: dict, out_dir: pathlib.Path) -> pathlib.Path:
    """``<out_dir>/parity/parity_report.json`` (the batch-level report)."""
    d = pathlib.Path(out_dir) / "parity"
    d.mkdir(parents=True, exist_ok=True)
    path = d / "parity_report.json"
    path.write_text(json.dumps(report, indent=1, default=str), encoding="utf-8")
    return path


__all__ = ["CAV_PARITY", "Metric", "ParityConfig", "attach_to_results", "check_table", "compare", "evidence_by_target",
           "metrics_for", "run_parity", "same", "source_sql", "table_status", "tables_from_context", "target_sql",
           "target_type", "write_report"]
