"""packs.snowflake.code_units - tier 0 for procedural CODE objects (S2, ADR 037; catalogue rows 5.11-5.13, 6.12) and the
L4 pre-pass over SQL procedures.

    engine                  tier 0 (deterministic, no AI)   output
    javascript_procedure    js_convert (esprima AST)        Python notebook (kind python)
    udf_js                  js_convert                      CREATE FUNCTION ... LANGUAGE PYTHON
    snowpark_python         python_convert (ast)            PySpark notebook (kind python)
    udf_python              python_convert                  CREATE FUNCTION ... LANGUAGE PYTHON
    snowpark_java / snowpark_scala /      no translation: a packaging flag (SNW-CODE-PACKAGING) naming the handler, the
    udf_java / udf_scala                  JARs and what a human does with them (row 5.13); the chain still runs

Every SQL statement inside the code goes through the SAME tier 0 a view gets (``translate.tier0_unit``: sqlglot + pack
rules + post-pass + validators + caveat scan + residue guard), so a statement the engine cannot convert refuses the
whole unit with the statement's reason. A refusal is a precise reason with the line (never the source text, hard rule
11) and the unit then goes down the normal chain: Lakebridge, the AI tier, a human. The converters return notes
(``SEM004|...``) that become the unit's review reasons; the unit always needs a reviewer (``always_review``).
"""
from __future__ import annotations

import dataclasses
import re

from packs.snowflake import caveats as cav
from packs.snowflake import contract as ct
from packs.snowflake import residue as rsd
from packs.snowflake.code_common import (
    CodeNames,
    CodeObject,
    CodeRefused,
    CodeServices,
    ConverterUnavailable,
    clean_reason,
    db_type,
    packaging_reasons,
    parse_code_object,
)
from packs.snowflake.postpass import Postpass
from packs.snowflake.scripting import procedure_header, split_scripting
from packs.snowflake.validators import validate

JS_ENGINES = frozenset({"javascript_procedure", "udf_js"})
PYTHON_ENGINES = frozenset({"snowpark_python", "udf_python"})
CODE_ENGINES = JS_ENGINES | PYTHON_ENGINES
PACKAGING_ENGINES = frozenset({"snowpark_java", "snowpark_scala", "udf_java", "udf_scala"})
UDF_ENGINES = frozenset({"udf_js", "udf_python"})
CAVEAT_JS, CAVEAT_PYTHON = "SNW-CODE-JS", "SNW-CODE-PYTHON"
CAVEAT_REFUSED, CAVEAT_PACKAGING = "SNW-CODE-REFUSED", "SNW-CODE-PACKAGING"
_NOTE = re.compile(r"^(SEM004|INFO|SETUP001)\|")


# --------------------------------------------------------------------------------------------------- L4
def procedure_return_type(doc: dict) -> tuple[str, str] | None:
    """``(SOURCE FQN upper, scalar RETURNS type)`` of a SQL procedure that the scripting converter turns into a
    ``<name>__ret`` OUT-parameter twin, else None. Mirrors ``translate.scripting_unit``'s gate (control flow, variables,
    handlers or transactions in the body) and the converter's own rule that a scalar return needs a ``RETURN <v>``."""
    from packs.snowflake import scripting_convert as sc
    from packs.snowflake import translate as tr

    if str(doc.get("engine") or "") != "sql_procedure":
        return None
    text = ct._sql_text(doc)
    if text is None:
        return None
    pres = tr.pre_units(doc, "pre")
    if any(p.unavailable for p in pres) or not (
            any(p.logic.get("node_kind") in tr._WHOLE for p in pres)
            or any(tr._TXN_STMT.match(p.source_text) for p in pres)):
        return None
    returns = procedure_header(text).get("returns") or str((doc.get("params") or {}).get("data_type") or "") or None
    if not returns or re.match(r"TABLE\b", returns, re.I):
        return None
    try:
        block = sc.build_block(split_scripting(ct.query_of_definition("sql_procedure", text)))
        if not sc.returns_value(block):
            return None
    except sc.ScriptingUnsupported:
        return None
    native = ct.parse_native_id(str(doc.get("asset_id") or ""))
    if not (native["db"] and native["schema"] and native["name"]):
        return None
    return f"{native['db']}.{native['schema']}.{native['name']}".upper(), returns


# --------------------------------------------------------------------------------------------------- S2
def _services(ctx, engine: str) -> CodeServices:
    """Tier 0 for one inner statement, exactly as ``translate._scripting_services`` does for a SQL procedure body (the
    column check is off inside code: a variable is not a column; the unqualified names of the object's own schema are
    resolved by assumption, as for a procedure)."""
    from packs.snowflake import translate as tr

    pp = ctx.postpass.ctx
    inner = dataclasses.replace(ctx, catalogue=None, postpass=Postpass(
        dataclasses.replace(pp, assume_engines=frozenset(pp.assume_engines | {engine}))))
    names = CodeNames(pp.table_map, pp.default_db, pp.default_schema, ctx.default_catalog)
    svc = CodeServices(lambda text: "", lambda text: [], names, dict(ctx.procedure_returns))

    def statement(text: str) -> str:
        pre = tr.PreUnit(f"{ctx.etl_key}-in", {"sql": text.strip(), "engine": engine, "language": "sql", "params": {}},
                         engine)
        res, item = tr.tier0_unit(pre, inner)
        if item is not None:
            raise CodeRefused("; ".join(clean_reason(r) for r in res.reasons) or "the statement was not converted")
        svc.statements += 1
        svc.review.update(c for c in res.review_caveats if not c.startswith("always_review:"))
        svc.caveats.update(res.caveats)
        return res.sql

    def residue(text: str) -> list[str]:
        return rsd.scan(text, ctx.conversion.capabilities).tokens

    svc.statement, svc.residue = statement, residue
    return svc


def _notes(raw: list[str]) -> list[dict]:
    out = []
    for n in raw:
        code, _, note = n.partition("|") if _NOTE.match(n) else ("INFO", "", n)
        out.append({"id": code, "note": note or n})
    return out


def _signature(obj: CodeObject) -> tuple[str, str]:
    args = ", ".join(f"{a['name']} {db_type(a['type'])}" for a in obj.args)
    return args, db_type(obj.returns) if obj.returns else "STRING"


def code_unit(doc: dict, pres: list, ctx) -> tuple[object | None, list[str], list[str]]:
    """``(one UnitResult for the whole object, [], [])`` when the converter handled it, else ``(None, reasons,
    caveat ids)``: the precise reason it was refused (or the packaging note for Java / Scala), which the unit carries
    into the chain and the reviewer. ``(None, [], [])`` = not a code object at all."""
    from packs.snowflake import translate as tr

    engine = str(doc.get("engine") or "")
    if engine in PACKAGING_ENGINES:
        return None, packaging_reasons(doc), [CAVEAT_PACKAGING]
    if engine not in CODE_ENGINES or not pres or any(p.unavailable for p in pres):
        return None, [], []
    obj = parse_code_object(doc)
    if obj is None:
        return None, ["the definition has no inline AS $$ ... $$ body to convert (a staged module or a definition the "
                      "extraction could not read in full)"], [CAVEAT_REFUSED]
    want = "javascript" if engine in JS_ENGINES else "python"
    if obj.language and obj.language != want:
        return None, [f"the definition says LANGUAGE {obj.language.upper()}, the engine is {engine}"], [CAVEAT_REFUSED]
    obj.language = want
    svc = _services(ctx, engine)
    native = ct.parse_native_id(str(doc.get("asset_id") or ""))
    renamed = ctx.overloads.by_asset.get(str(doc.get("asset_id") or ""))
    target = ct.derived_target(ctx.default_catalog, native["db"], native["schema"], renamed or native["name"] or obj.name)  # noqa: E501
    try:
        if engine in UDF_ENGINES:
            args_sql, returns_sql = _signature(obj)
            if want == "javascript":
                from packs.snowflake.js_convert import convert_javascript_udf
                text, notes = convert_javascript_udf(obj, target, args_sql, returns_sql, svc)
            else:
                from packs.snowflake.python_convert import convert_python_udf
                text, notes = convert_python_udf(obj, target, args_sql, returns_sql)
            kind = "statement"
        else:
            label = native["name"] or obj.name
            header = f"# Converted from Snowflake {want.capitalize()} procedure {label} (LatentView migrator)"
            if want == "javascript":
                from packs.snowflake.js_convert import convert_javascript_procedure
                text, notes = convert_javascript_procedure(obj, svc, header)
            else:
                from packs.snowflake.python_convert import convert_python_procedure
                text, notes = convert_python_procedure(obj, svc, header)
            kind = "python"
    except ConverterUnavailable as exc:
        return None, [str(exc)], [CAVEAT_REFUSED]
    except CodeRefused as exc:
        return None, [f"{want} code conversion refused: {clean_reason(str(exc))}"], [CAVEAT_REFUSED]
    problems = validate(kind, text)
    if problems:
        return (None, [f"the converted {want} code does not validate: {clean_reason(p)}" for p in problems],
                [CAVEAT_REFUSED])
    if kind == "statement":                      # the UDF text must also hold a body that parses as Python
        import ast
        body = text.split("AS $$\n", 1)[1].rsplit("\n$$", 1)[0]
        try:
            ast.parse(body)
        except SyntaxError as exc:
            return None, [f"the converted {want} function body does not parse: {exc.msg} (line {exc.lineno})"], \
                [CAVEAT_REFUSED]
    pre = pres[0]
    res = tr.UnitResult(pre.unit_id, engine, source_text=pre.source_text, fingerprint=tr._fingerprint(pre),
                        params=dict(doc.get("params") or {}))
    tag = CAVEAT_JS if want == "javascript" else CAVEAT_PYTHON
    hit = sorted(svc.caveats)        # caveats of the inner SQL statements (SQL text patterns say nothing about code)
    cls = cav.classify(hit, ctx.caveat_catalogue)
    cfg = ct.ENGINES.get(engine, {})
    review = {tag, *cls["review"], *svc.review}
    if cfg.get("always_review"):
        review.add(f"always_review:{engine}")
    res.sql, res.kind, res.origin, res.state, res.status = text, kind, "mapped", "derived", "resolved"
    res.caveats = sorted({*hit, tag})
    res.review_caveats = sorted(review)
    res.column_check = "not_applicable"
    res.evidence = {"code_converter": {"language": want, "kind": obj.kind, "inner_statements": svc.statements,
                                       "notes": len(notes)}}
    res.params = {**res.params, "conversion": ctx.conversion.summary(),
                  "code": {"language": want, "kind": obj.kind, "form": "udf" if kind == "statement" else "notebook",
                           "target": target, "notes": _notes(notes)}}
    res.attempts = [tr.TranslationAttempt(0, "ok", caveats=res.caveats).as_dict()]
    return res, [], []


__all__ = ["CAVEAT_JS", "CAVEAT_PACKAGING", "CAVEAT_PYTHON", "CAVEAT_REFUSED", "CODE_ENGINES", "PACKAGING_ENGINES",
           "code_unit", "procedure_return_type"]
