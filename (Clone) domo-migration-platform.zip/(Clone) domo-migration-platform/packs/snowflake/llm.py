"""packs.snowflake.llm - the tier-2 translator of a Snowflake batch, chosen from configuration (9.1).

``scripts/run_batch.py`` used to pass an EMPTY scripted translator (the AI tier produced nothing anywhere). It asks
``choose_llm()`` and records the answer in the batch report (``translation.llm``) and every ``run.json`` (``llm``):

    serving   a Databricks model-serving endpoint through ``core.domo.llm.LLMClient`` (the one sanctioned entry point)
    scripted  a canned translator seeded for the synthetic Snowflake fixture objects (offline demo, tests)
    off       no translator: the AI tier reports ``unavailable`` and unresolved units wait for a human, with no code

The migrator has its own venv and does not import ``srcintel``: it reads the SAME settings the app uses, from the
environment and the repo's ``config/{local,databricks}.yaml`` ``llm:`` block.

    MIGRATOR_LLM                   serving | scripted | off              explicit choice, wins over everything
    MIGRATOR_LLM_ENDPOINT          serving endpoint name                 (else SRCINTEL__LLM__ENDPOINT, else the yaml)
    SRCINTEL__LLM__PROVIDER        databricks_serving -> serving, fake -> scripted, anything else -> off
    SRCINTEL__LLM__ENDPOINT        serving endpoint name
    SRCINTEL__LLM__TEMPERATURE / SRCINTEL__LLM__MAX_TOKENS / SRCINTEL__LLM__TIMEOUT_S
    SRCINTEL_ENV                   local | databricks (which yaml supplies the defaults; default local)
    SRCINTEL_CONFIG_DIR            the config directory (default: <repo>/config)

Tier-2 output is always ``origin=ai`` / ``state=inferred`` and held for review (``core.review``), whichever mode ran.
Prompts carry no string literals: they become ``'<<L1>>'`` placeholders and are put back into the answer (Snowflake
literals often hold personal data; the pack declares ``literals_sensitive``).
"""
from __future__ import annotations

import asyncio
import os
import pathlib
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from core.literals import _LITERAL
from core.llm_budget import BudgetConfig, RunBudget, UsageLedger, ledger_for, load_budget, load_pricing
from packs.snowflake.fakes import ScriptedAnswer, ScriptedTranslator

MODES = ("serving", "scripted", "off")
REPO = pathlib.Path(__file__).resolve().parents[4]


@dataclass(frozen=True)
class LlmChoice:
    mode: str                      # serving | scripted | off
    endpoint: str = ""
    reason: str = ""

    def as_dict(self) -> dict:
        return {"mode": self.mode, "endpoint": self.endpoint, "reason": self.reason}


def _yaml_llm(env: dict[str, str]) -> dict:
    name = "databricks.yaml" if (env.get("SRCINTEL_ENV") or "local").lower() == "databricks" else "local.yaml"
    root = pathlib.Path(env.get("SRCINTEL_CONFIG_DIR") or REPO / "config")
    try:
        import yaml

        data = yaml.safe_load((root / name).read_text(encoding="utf-8")) or {}
    except (OSError, ValueError, ImportError):
        return {}
    llm = data.get("llm")
    return dict(llm) if isinstance(llm, dict) else {}


def choose_llm(env: dict[str, str] | None = None) -> LlmChoice:
    env = dict(os.environ if env is None else env)
    cfg = _yaml_llm(env)
    endpoint = (env.get("MIGRATOR_LLM_ENDPOINT") or env.get("SRCINTEL__LLM__ENDPOINT")
                or str(cfg.get("endpoint") or "")).strip()
    explicit = (env.get("MIGRATOR_LLM") or "").strip().lower()
    if explicit:
        if explicit not in MODES:
            return LlmChoice("off", reason=f"MIGRATOR_LLM={explicit!r} is not one of {list(MODES)}")
        if explicit == "serving" and not endpoint:
            return LlmChoice("off", reason="MIGRATOR_LLM=serving but no endpoint is configured "
                                           "(MIGRATOR_LLM_ENDPOINT or SRCINTEL__LLM__ENDPOINT)")
        return LlmChoice(explicit, endpoint if explicit == "serving" else "", "MIGRATOR_LLM")
    provider = (env.get("SRCINTEL__LLM__PROVIDER") or str(cfg.get("provider") or "fake")).strip().lower()
    if provider == "databricks_serving":
        if not endpoint:
            return LlmChoice("off", reason="provider databricks_serving but no endpoint is configured")
        return LlmChoice("serving", endpoint, f"llm.provider={provider}")
    if provider == "fake":
        if (env.get("SRCINTEL_ENV") or "local").lower() == "databricks":
            return LlmChoice("off", reason="llm.provider=fake on a Databricks deployment: no translator is set up "
                                           "(set SRCINTEL__LLM__PROVIDER=databricks_serving or MIGRATOR_LLM)")
        return LlmChoice("scripted", reason="llm.provider=fake (offline): the canned fixture translator")
    return LlmChoice("off", reason=f"llm.provider={provider} is not supported by the migrator "
                                   "(databricks_serving, or fake for the offline demo)")


# ------------------------------------------------------------------------------------------------ scripted
#: lower-case substring of the unit's SOURCE text -> Databricks SQL. Names are Snowflake names: the chain's post-pass
#: maps them to the batch's targets. Seeded for tests/fixtures/snowflake only.
FIXTURE_ANSWERS: dict[str, object] = {
    "merge into sales_db.core.orders": (
        "MERGE INTO SALES_DB.CORE.ORDERS t\n"
        "USING (SELECT ORDER_ID, CUSTOMER_ID, TO_DATE(ORDER_TS) AS ORDER_DATE, AMOUNT, DISCOUNT, STATUS, REGION, "
        "PRODUCT_ID\n"
        "       FROM table_changes('SALES_DB.RAW.ORDERS_RAW', 1) WHERE _change_type = 'insert') s\n"
        "ON t.ORDER_ID = s.ORDER_ID\n"
        "WHEN MATCHED THEN UPDATE SET t.AMOUNT = s.AMOUNT, t.DISCOUNT = s.DISCOUNT, t.STATUS = s.STATUS\n"
        "WHEN NOT MATCHED THEN INSERT (ORDER_ID, CUSTOMER_ID, ORDER_DATE, AMOUNT, DISCOUNT, STATUS, REGION, "
        "PRODUCT_ID) "
        "VALUES (s.ORDER_ID, s.CUSTOMER_ID, s.ORDER_DATE, s.AMOUNT, s.DISCOUNT, s.STATUS, s.REGION, s.PRODUCT_ID)",
        0.78),
    "system$send_email": (
        "SELECT 'notification: send it with a job email notification (SYSTEM$SEND_EMAIL has no SQL equivalent)' "
        "AS notify_note", 0.72),
}


def scripted_translator() -> ScriptedTranslator:
    return ScriptedTranslator(dict(FIXTURE_ANSWERS))


# ------------------------------------------------------------------------------------------------ serving
SNOWFLAKE_BASE_PROMPT = """\
You translate ONE Snowflake SQL statement into ONE Databricks SQL statement (Unity Catalog, Spark SQL dialect).

Rules:
- Return exactly one statement in a ```sql fenced block, with no trailing semicolon. Keep the statement's kind
  (a MERGE stays a MERGE, an INSERT stays an INSERT, a SELECT stays a SELECT).
- Keep every table and column name exactly as written (they are mapped to Unity Catalog names afterwards).
- String literals appear as '<<L1>>', '<<L2>>' placeholders: copy them unchanged where the literal belongs.
- Snowflake streams (METADATA$ACTION ...) become the Delta change data feed: table_changes('<table>', <version>) with
  _change_type. Snowflake system procedures (SYSTEM$...) have no SQL equivalent: say so (see FAILURE).
- Never invent a table, a column or a function. If you cannot translate faithfully, do not guess.

FAILURE: if you cannot translate it faithfully, return a ```sql block containing exactly:
-- CANNOT TRANSLATE: <one line saying why>
That is a useful answer; a plausible guess is not.
"""

_PLACEHOLDER = re.compile(r"'<<L(\d+)>>'")


def mask_for_prompt(text: str) -> tuple[str, list[str]]:
    """``(text with '<<Ln>>' placeholders, the original literals in order)``."""
    found: list[str] = []

    def sub(m: re.Match) -> str:
        found.append(m.group(0))
        return f"'<<L{len(found)}>>'"

    return _LITERAL.sub(sub, text or ""), found


def restore_literals(sql: str, literals: list[str]) -> str:
    return _PLACEHOLDER.sub(lambda m: literals[int(m.group(1)) - 1] if 0 < int(m.group(1)) <= len(literals)
                            else m.group(0), sql)


def default_validate(sql: str) -> list[str]:
    """The checks every tier-2 answer must pass anyway (validator for its kind + the residue guard)."""
    from packs.snowflake import residue
    from packs.snowflake.validators import sniff_kind, validate

    return validate(sniff_kind(sql), sql) + residue.problems(sql)


_CLASSES = (("PARSE", re.compile(r"pars|syntax|sqlglot|not valid", re.I)),
            ("RESIDUE", re.compile(r"snowflake|residue", re.I)),
            ("UNMAPPED_NAME", re.compile(r"unmapped|not mapped|unknown (table|name)", re.I)),
            ("EMPTY", re.compile(r"empty|no statement", re.I)))


def problem_class(problem: str) -> str:
    """A coarse class of one validator message, so feedback and the ledger never carry the message itself."""
    return next((name for name, rx in _CLASSES if rx.search(problem)), "VALIDATION")


_HINT = {"PARSE": "the answer did not parse as one Databricks SQL statement",
         "RESIDUE": "a Snowflake-only construct was left in the answer",
         "UNMAPPED_NAME": "a name was not kept exactly as in the input",
         "EMPTY": "the statement was empty", "VALIDATION": "the statement kind failed its structural checks"}


def caveat_ids(sql: str) -> list[str]:
    from packs.snowflake.caveats import detect

    return detect(sql)


def validator_feedback(classes: list[str], caveats: list[str], attempt: int) -> str:
    """Prompt addendum for the next attempt: validator error CLASSES and caveat ids only (no source text)."""
    lines = [f"\nYour previous answer (attempt {attempt}) was rejected by the validators. Fix it and return one "
             "statement in a ```sql block, or the CANNOT TRANSLATE line."]
    lines += [f"- {c}: {_HINT.get(c, _HINT['VALIDATION'])}" for c in classes]
    if caveats:
        lines.append(f"- Constructs detected in your answer that need care: {', '.join(caveats)}")
    return "\n".join(lines) + "\n"


@dataclass
class LlmAnswer:
    step_id: str
    sql: str = ""
    confidence: float | None = None
    why_not: str = ""

    @property
    def usable(self) -> bool:
        return bool(self.sql)


class NullObservability:
    """The migrator's own observability (run.json carries the tier attempts); calls are counted, never stored."""

    def __init__(self) -> None:
        self.calls = 0

    def record_llm_call(self, row: Any) -> None:
        self.calls += 1

    def record_node(self, row: Any) -> None:
        return None


class ServingTranslator:
    """Tier 2 over a Databricks serving endpoint, through ``LLMClient`` (the only sanctioned entry point)."""

    mode = "serving"

    def __init__(self, llm: Any, *, pool: str = "translation", budget: RunBudget | None = None,
                 ledger: UsageLedger | None = None, endpoint: str = "", run_id: str = "",
                 validate: Callable[[str], list[str]] | None = default_validate) -> None:
        self._llm, self._pool = llm, pool
        self.calls: list[list[str]] = []
        # S14: per-run budget, usage ledger and the validator-feedback retry loop
        self.budget = budget or RunBudget(BudgetConfig(attempts_per_unit=1))
        self.ledger, self.endpoint, self.run_id, self.validate = ledger, endpoint, run_id, validate

    async def resolve_tail(self, build, *, config=None, user_prompt="", feedback=None, issues=None, hard=None):
        pending = list(build.unresolved or [])
        self.calls.append([str(i.get("step")) for i in pending])
        answers = await asyncio.gather(*(self._one(i, config, user_prompt) for i in pending))
        return {a.step_id: a for a in answers}

    def build_prompt(self, item: dict) -> tuple[str, list[str]]:
        masked, literals = mask_for_prompt(str(item.get("source_text") or ""))
        why = "; ".join(str(r) for r in (item.get("reasons") or []))[:600] or "unknown"
        caveats = ", ".join(item.get("caveats") or []) or "none"
        text = (f"{SNOWFLAKE_BASE_PROMPT}\nObject kind: {item.get('engine') or 'unknown'}\n"
                f"Why the deterministic translator could not do it: {mask_for_prompt(why)[0]}\n"
                f"Caveats detected: {caveats}\n\nSnowflake SQL:\n```sql\n{masked}\n```\n")
        return text, literals

    async def _one(self, item: dict, config: Any, user_prompt: str) -> LlmAnswer:
        from agents.cd_codegen.sql_translation import _REFUSAL, extract_sql
        from core.domo.models import Role
        from core.domo.prompts import PromptLayers

        sid = str(item.get("step") or "")
        base, literals = self.build_prompt(item)
        cfg = config or {"configurable": {"environment": "dev", "agent": "translation", "node": sid,
                                          "dataflow_id": str(item.get("etl_key") or "")}}
        attempts = self.budget.cfg.attempts_per_unit
        feedback = ""
        classes: list[str] = []
        for attempt in range(1, attempts + 1):
            stop = self.budget.exhausted()
            if stop:
                self._log(sid, attempt, "budget", 0, 0, None, "BUDGET_EXHAUSTED")
                return LlmAnswer(sid, why_not=f"LLM budget exhausted ({stop}); the unit waits for a person")
            self.budget.reserve()
            try:
                result = await self._llm.complete(
                    Role.GENERATOR, PromptLayers(base=base + feedback, user_prompt=user_prompt), pool=self._pool,
                    config=cfg)
            except Exception as exc:                # noqa: BLE001 - one unit must not take the batch down
                self._log(sid, attempt, "failed", 0, 0, None, type(exc).__name__)
                return LlmAnswer(sid, why_not=f"serving endpoint call failed: {type(exc).__name__}: {str(exc)[:160]}")
            tin, tout = int(getattr(result, "tokens_in", 0) or 0), int(getattr(result, "tokens_out", 0) or 0)
            cost = self.budget.add(self.endpoint, tin, tout)
            sql = extract_sql(result.raw_text).strip().rstrip(";").strip()
            if not sql:
                self._log(sid, attempt, "completed", tin, tout, cost, "EMPTY_ANSWER")
                return LlmAnswer(sid, why_not="the model returned nothing usable")
            refusal = _REFUSAL.search(sql)
            if refusal:
                self._log(sid, attempt, "completed", tin, tout, cost, "")
                return LlmAnswer(sid, why_not=f"model declined: {refusal.group(1).strip() or 'no reason given'}")
            candidate = restore_literals(sql, literals)
            problems = self.validate(candidate) if self.validate else []
            if not problems:
                self._log(sid, attempt, "completed", tin, tout, cost, "")
                return LlmAnswer(sid, candidate, None)
            classes = sorted({problem_class(p) for p in problems})
            self._log(sid, attempt, "completed", tin, tout, cost, ",".join(classes))
            feedback = validator_feedback(classes, caveat_ids(candidate), attempt)
        return LlmAnswer(sid, why_not=f"no valid answer after {attempts} attempt(s); last validator class(es): "
                                      f"{', '.join(classes) or 'none'}")

    def _log(self, sid: str, attempt: int, status: str, tin: int, tout: int, cost: float | None, error: str) -> None:
        if self.ledger is not None:           # classes and counts only: no prompt, source text or answer
            self.ledger.record(run_id=self.run_id, unit=sid, endpoint=self.endpoint, attempt=attempt, status=status,
                               tokens_in=tin, tokens_out=tout, cost=cost, error_class=error, purpose="translation")


def serving_translator(choice: LlmChoice, env: dict[str, str] | None = None, *, caller: Any = None,
                       budget: RunBudget | None = None, ledger: UsageLedger | None = None,
                       run_id: str = "") -> ServingTranslator:
    """``caller`` replaces the Databricks endpoint call (tests); production leaves it None. ``budget`` / ``ledger``
    (S14) default to the config files' limits and no ledger."""
    from core.domo.concurrency import ConcurrencyManager
    from core.domo.llm import LLMClient
    from core.domo.models import EndpointSpec, ModelRegistry
    from core.domo.prompts import HardConstraintChecker, PromptAssembler

    env = dict(os.environ if env is None else env)
    cfg = _yaml_llm(env)

    def num(key: str, default: float) -> float:
        try:
            return float(env.get(f"SRCINTEL__LLM__{key.upper()}") or cfg.get(key) or default)
        except ValueError:
            return default

    spec = EndpointSpec(endpoint=choice.endpoint, timeout_s=int(num("timeout_s", 120)),
                        params={"temperature": num("temperature", 0.0), "max_tokens": int(num("max_tokens", 2048))})
    client = LLMClient(registry=ModelRegistry({"dev": {"generator": spec}}), assembler=PromptAssembler(),
                       checker=HardConstraintChecker(),
                       concurrency=ConcurrencyManager({"translation": 4, "default": 4}),
                       observability=NullObservability(), timeout_s=spec.timeout_s, caller=caller)
    budget = budget or RunBudget(load_budget(env=env), load_pricing())
    return ServingTranslator(client, budget=budget, ledger=ledger, endpoint=choice.endpoint, run_id=run_id)


def build_translator(choice: LlmChoice, env: dict[str, str] | None = None, *, run_id: str = "",
                     volume: pathlib.Path | str | None = None) -> Any:
    """The tier-2 translator for ``choice`` (None for ``off``: the chain then reports the tier ``unavailable``)."""
    if choice.mode == "serving":
        return serving_translator(choice, env, run_id=run_id,
                                  ledger=ledger_for(volume, run_id) if volume and run_id else None)
    if choice.mode == "scripted":
        return scripted_translator()
    return None


__all__ = ["FIXTURE_ANSWERS", "LlmAnswer", "LlmChoice", "MODES", "ServingTranslator", "ScriptedAnswer",
           "build_translator", "choose_llm", "mask_for_prompt", "restore_literals", "scripted_translator",
           "serving_translator"]
