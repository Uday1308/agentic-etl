# Ported from SNF2DBX-main/converters/dml_shapes.py (LatentView internal)
# ruff: noqa: E501
"""Shapes of single Snowflake DML statements, read without a full SQL parser.

The Snowflake Scripting converter needs two facts about a DML statement that sqlglot does not give directly:
which row a single-row INSERT writes (sequence numbers -> identity columns) and how many rows a statement will
change (SQLROWCOUNT). Both are answered here or refused with a reason; nothing is guessed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from packs.snowflake.sqlscan import FQN, find_top_kw, matching_paren, split_top

DML = re.compile(r"^\s*(INSERT|UPDATE|DELETE|MERGE)\b", re.I)
_ALIAS = r"[A-Za-z_][\w$]*"


class NotCountable(ValueError):
    """The rows a statement changes cannot be counted by a query run just before it."""


@dataclass
class Insert:
    table: str  # as written in the source
    columns: list[str]
    values: list[str]  # the single VALUES row, one expression per column


def single_row_insert(text: str) -> Insert | None:
    """INSERT INTO t (c1, ...) VALUES (v1, ...) with exactly one row, else None."""
    match = re.match(rf"^\s*INSERT\s+INTO\s+({FQN})\s*\(", text, re.I)
    if not match:
        return None
    close = matching_paren(text, match.end() - 1)
    columns = split_top(text[match.end():close])
    rest = re.match(r"\s*VALUES\s*", text[close + 1:], re.I)
    if not rest:
        return None
    rows = split_top(text[close + 1 + rest.end():].strip())
    if len(rows) != 1 or not rows[0].startswith("("):
        return None
    row = rows[0]
    end = matching_paren(row, 0)
    values = split_top(row[1:end])
    if row[end + 1:].strip() or len(values) != len(columns):
        return None
    return Insert(match.group(1), columns, values)


def count_query(text: str) -> str:
    """Snowflake query that, run just before `text`, returns the number of rows `text` changes."""
    kind = DML.match(text)
    if not kind:
        raise NotCountable("it is not an INSERT, UPDATE, DELETE or MERGE")
    return {"INSERT": _insert_count, "UPDATE": _update_count, "DELETE": _delete_count,
            "MERGE": _merge_count}[kind.group(1).upper()](text)


def _insert_count(text):
    match = re.match(rf"^\s*INSERT\s+(?:OVERWRITE\s+)?INTO\s+{FQN}\s*", text, re.I)
    if not match:
        raise NotCountable("INSERT ALL / INSERT FIRST are not counted")
    rest = text[match.end():]
    if rest.startswith("(") and not re.match(r"\(\s*(SELECT|WITH)\b", rest, re.I):
        rest = rest[matching_paren(rest, 0) + 1:].strip()  # column list
    values = re.match(r"VALUES\s*", rest, re.I)
    if values:
        return f"SELECT {len(split_top(rest[values.end():]))}"
    if re.match(r"\(?\s*(SELECT|WITH)\b", rest, re.I):
        return f"SELECT COUNT(*) FROM ({rest}) AS counted_"
    raise NotCountable("the INSERT has neither VALUES nor a query")


def _filtered(table, alias, text, start, verb):
    if find_top_kw(text, "FROM" if verb == "UPDATE" else "USING", start) >= 0:
        raise NotCountable(f"{verb} that joins other tables ({'FROM' if verb == 'UPDATE' else 'USING'}) is not counted")
    where = find_top_kw(text, "WHERE", start)
    return f"SELECT COUNT(*) FROM {table}{alias}" + (" " + text[where:].strip() if where >= 0 else "")


def _update_count(text):
    match = re.match(rf"^\s*UPDATE\s+({FQN})((?:\s+AS)?\s+(?!SET\b){_ALIAS})?\s+SET\b", text, re.I)
    if not match:
        raise NotCountable("the UPDATE target could not be read")
    return _filtered(match.group(1), match.group(2) or "", text, match.end(), "UPDATE")


def _delete_count(text):
    match = re.match(rf"^\s*DELETE\s+FROM\s+({FQN})((?:\s+AS)?\s+(?!WHERE\b|USING\b){_ALIAS})?", text, re.I)
    if not match:
        raise NotCountable("the DELETE target could not be read")
    return _filtered(match.group(1), match.group(2) or "", text, match.end(), "DELETE")


def _merge_count(text):
    match = re.match(rf"^\s*MERGE\s+INTO\s+({FQN})((?:\s+AS)?\s+(?!USING\b){_ALIAS})?\s+USING\s+", text, re.I)
    if not match:
        raise NotCountable("the MERGE target could not be read")
    target, target_alias, rest = match.group(1), match.group(2) or "", text[match.end():]
    if rest.startswith("("):
        close = matching_paren(rest, 0)
        source, rest = rest[:close + 1], rest[close + 1:]
    else:
        table = re.match(FQN, rest)
        if not table:
            raise NotCountable("the MERGE source could not be read")
        source, rest = table.group(0), rest[table.end():]
    alias = re.match(rf"\s*(?:AS\s+)?(?!ON\b)({_ALIAS})", rest, re.I)
    source_alias = " AS " + alias.group(1) if alias else ""
    on = find_top_kw(rest, "ON")
    whens, at = [], find_top_kw(rest, "WHEN", max(on, 0))
    while at >= 0:
        whens.append(at)
        at = find_top_kw(rest, "WHEN", at + 4)
    if on < 0 or not whens:
        raise NotCountable("the MERGE ON / WHEN clauses could not be read")
    branches = set()
    for start, end in zip(whens, whens[1:] + [len(rest)]):
        clause = " ".join(rest[start:end].split()).upper()
        if re.match(r"WHEN MATCHED THEN UPDATE\b", clause):
            branches.add("update")
        elif re.match(r"WHEN NOT MATCHED(?: BY TARGET)? THEN INSERT\b", clause):
            branches.add("insert")
        else:
            raise NotCountable("MERGE with a conditional (WHEN ... AND ...) or DELETE branch is not counted")
    rows = f"SELECT COUNT(*) FROM {source}{source_alias}"
    if branches == {"update", "insert"}:
        return rows  # every source row either updates its match or is inserted
    condition = rest[on + 2:whens[0]].strip()
    exists = "EXISTS" if branches == {"update"} else "NOT EXISTS"
    return f"{rows} WHERE {exists} (SELECT 1 FROM {target}{target_alias} WHERE {condition})"
