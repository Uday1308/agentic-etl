# Ported from SNF2DBX-main/converters/dialect.py (LatentView internal): the SNOWFLAKE_ONLY residue list (lines 414-431),
# extended with docs/plans/snowflake-conversion-catalogue.md (ADR 037 section 6) and made literal-aware and
# capability-aware.
"""packs.snowflake.residue - the residue guard (conversion engine v2, X3).

After tier 0 and after any later tier's output (Lakebridge, AI, a reviewer's edit) the Databricks text must not still
contain a construct only Snowflake understands. ``scan`` returns the offending tokens; the caller escalates with the
caveat ``SNW-RESIDUE`` listing them (``reasons``). sqlglot passes unknown functions through silently, and an AI draft
may keep a Snowflake call, so a clean ``parse`` proves nothing; this check is the net under both.

Literal-aware: string literals, quoted identifiers, ``$$`` bodies and comments are masked before matching, so
``SELECT 'IFF(a)'`` or a column named ``"TO_VARCHAR"`` is not residue. The ``//`` line comment is Snowflake-only
syntax and is detected on the scan of the unmasked-comment text (outside strings). Where the text parses as
Databricks SQL, function names are also read from the syntax tree (``exp.Anonymous``), which catches a call split
by whitespace or an inline comment. Capability-aware: tokens that exist on a Databricks target only when the profile
says so (``LISTAGG``, ``WITH RECURSIVE``, ``COLLATE``, ``VARIANT``, temp tables, transactions, ...) are residue under
a profile that lacks the capability.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError

from packs.snowflake.conversion import CapabilityProfile

RESIDUE_CAVEAT = "SNW-RESIDUE"

#: Functions that have no Databricks function of that name (or whose Databricks twin differs: the rewrite lives in
#: tier 0, a surviving call means it did not fire). Upper case.
SNOWFLAKE_ONLY_FUNCTIONS: frozenset[str] = frozenset("""
    IFF ARRAY_CONSTRUCT ARRAY_CONSTRUCT_COMPACT OBJECT_CONSTRUCT OBJECT_CONSTRUCT_KEEP_NULL
    TO_VARCHAR DIV0 DIV0NULL ZEROIFNULL NULLIFZERO SYSDATE GETDATE TO_DECIMAL TO_NUMERIC
    TRY_TO_DECIMAL TRY_TO_NUMERIC TO_BOOLEAN TRY_TO_BOOLEAN STRTOK STRTOK_TO_ARRAY
    STRTOK_SPLIT_TO_TABLE SPLIT_TO_TABLE OBJECT_KEYS OBJECT_INSERT OBJECT_DELETE OBJECT_PICK
    ARRAY_CAT ARRAY_TO_STRING ARRAY_SLICE TO_VARIANT TO_OBJECT TO_ARRAY CURRENT_WAREHOUSE
    CURRENT_ROLE CURRENT_ACCOUNT CURRENT_REGION CURRENT_SESSION LAST_QUERY_ID IS_ROLE_IN_SESSION
    RESULT_SCAN GET_DDL RATIO_TO_REPORT CONDITIONAL_TRUE_EVENT CONDITIONAL_CHANGE_EVENT FLATTEN
    GENERATOR SEQ1 SEQ2 SEQ4 SEQ8 UUID_STRING TIME_SLICE HASH_AGG HLL HLL_ESTIMATE HLL_EXPORT
    HLL_IMPORT MINHASH ENCRYPT DECRYPT BOOLAND BOOLOR BOOLXOR TO_TIMESTAMP_TZ QUERY_HISTORY
    QUERY_HISTORY_BY_USER QUERY_HISTORY_BY_SESSION TASK_HISTORY COMPLETE SUMMARIZE SENTIMENT
    EXTRACT_ANSWER CLASSIFY_TEXT
""".split())

#: Syntax-level residue (matched on the masked text): ``(token shown, regex)``.
_SYNTAX: tuple[tuple[str, str], ...] = (
    ("SYSTEM$", r"\bSYSTEM\$\w+"),
    ("METADATA$", r"\bMETADATA\$\w+"),
    (".NEXTVAL", r"\.\s*NEXTVAL\b"),
    (".CURRVAL", r"\.\s*CURRVAL\b"),
    ("$n positional", r"(?<![\w$])\$\d+\b"),
    ("LATERAL FLATTEN", r"\bLATERAL\s+FLATTEN\b"),
    ("TABLE(FLATTEN", r"\bTABLE\s*\(\s*FLATTEN\b"),
    ("EXPLODE named argument", r"\b(?:POS)?EXPLODE\s*\(\s*INPUT\s*=>"),   # what sqlglot makes of FLATTEN(input => ...)
    ("PIVOT IN (ANY)", r"\bIN\s*\(\s*ANY\b"),
    ("MATCH_RECOGNIZE", r"\bMATCH_RECOGNIZE\b"),
    ("MATCH_CONDITION", r"\bMATCH_CONDITION\b"),
    ("ASOF JOIN", r"\bASOF\s+JOIN\b"),
    ("CONNECT BY", r"\bCONNECT\s+BY\b"),
    ("SYS_CONNECT_BY_PATH", r"\bSYS_CONNECT_BY_PATH\b|\bCONNECT_BY_ROOT\b"),
    ("SAMPLE(", r"\bSAMPLE\s*\("),
    ("CHANGES(", r"\bCHANGES\s*\(\s*INFORMATION\b"),
    ("AT(TIMESTAMP =>", r"\b(?:AT|BEFORE)\s*\(\s*(?:TIMESTAMP|OFFSET|STATEMENT)\s*=>"),
    ("TRANSIENT TABLE", r"\bTRANSIENT\s+TABLE\b"),
    ("ALTER SESSION", r"\bALTER\s+SESSION\b"),
    ("AUTOINCREMENT", r"\bAUTOINCREMENT\b"),
    ("CREATE STAGE/STREAM/PIPE/TASK", r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:STAGE|STREAM|PIPE|TASK|"
                                      r"DYNAMIC\s+TABLE|WAREHOUSE|SEQUENCE)\b"),
    ("COPY INTO @stage", r"\bCOPY\s+INTO\s+@"),
    ("@stage reference", r"(?<![\w@])@[A-Za-z_~]\w*(?:\.\w+)*/"),
    ("PUT/GET/LIST file", r"^\s*(?:PUT|GET)\s+file://"),
    ("SQLROWCOUNT", r"\bSQLROWCOUNT\b|\bSQLFOUND\b|\bSQLNOTFOUND\b"),
    (":= assignment", r":="),
    ("TIMESTAMP_TZ type", r"\bTIMESTAMP_TZ\b"),
    ("NUMBER type", r"(?<![\w.])NUMBER\s*\("),
    ("CLUSTER BY expression", r"\bCLUSTER\s+BY\s*\([^)]*\("),
    ("DATA_RETENTION_TIME_IN_DAYS", r"\bDATA_RETENTION_TIME_IN_DAYS\b"),
    ("LANGUAGE JAVASCRIPT", r"\bLANGUAGE\s+JAVASCRIPT\b"),
)

#: capability flag -> (token shown, regex) that is residue only when the target lacks the flag
_CAPABILITY: dict[str, tuple[tuple[str, str], ...]] = {
    "listagg": (("LISTAGG", r"\bLISTAGG\s*\("),),
    "recursive_cte": (("WITH RECURSIVE", r"\bWITH\s+RECURSIVE\b"),),
    "collations": (("COLLATE", r"\bCOLLATE\b"),),
    "variant": (("VARIANT", r"\bVARIANT\b|\bPARSE_JSON\s*\(|\bTRY_PARSE_JSON\s*\(|\bVARIANT_GET\s*\("),),
    "geo_types": (("GEOGRAPHY/GEOMETRY", r"\bGEOGRAPHY\b|\bGEOMETRY\b|\bST_\w+\s*\("),),
    "temp_tables": (("TEMPORARY TABLE",
                     r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:LOCAL\s+|GLOBAL\s+)?TEMP(?:ORARY)?\s+TABLE\b"),),
    "multi_statement_txn": (("transaction", r"\bBEGIN\s+(?:TRANSACTION|WORK)\b|\bROLLBACK\b|\bCOMMIT\b"),),
    "sql_procedures": (("CREATE PROCEDURE", r"\bCREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\b"),),
    "sql_scripting": (("scripting block", r"\bDECLARE\b[\s\S]*\bBEGIN\b|\bWHILE\b[\s\S]*\bDO\b|"
                                          r"\bLOOP\b[\s\S]*\bEND\s+LOOP\b"),),
    "abac": (("CREATE POLICY", r"\bCREATE\s+(?:OR\s+REPLACE\s+)?POLICY\b"),),
}

_FUNC_RX = re.compile(r"\b(" + "|".join(sorted(map(re.escape, SNOWFLAKE_ONLY_FUNCTIONS), key=len, reverse=True))
                      + r")\s*\(", re.I)
_SYNTAX_RX = tuple((tok, re.compile(rx, re.I | re.M)) for tok, rx in _SYNTAX)
_CAP_RX = {flag: tuple((tok, re.compile(rx, re.I)) for tok, rx in items) for flag, items in _CAPABILITY.items()}


def mask(sql: str) -> tuple[str, bool]:
    """``(masked, has_slash_comment)``: strings, quoted identifiers, backticks, ``$$`` bodies and comments replaced by
    spaces of the same length; ``//`` line comments (Snowflake-only) reported separately."""
    out: list[str] = []
    n, i, slash = len(sql), 0, False
    while i < n:
        c, two = sql[i], sql[i:i + 2]
        if two == "--" or two == "//":
            j = sql.find("\n", i)
            j = n if j < 0 else j
            slash = slash or two == "//"
            out.append(" " * (j - i))
            i = j
        elif two == "/*":
            j = sql.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append(" " * (j - i))
            i = j
        elif two == "$$":
            j = sql.find("$$", i + 2)
            j = n if j < 0 else j + 2
            out.append(" " * (j - i))
            i = j
        elif c in "'\"`":
            j = i + 1
            while j < n:
                if sql[j] == "\\" and c == "'":
                    j += 2
                    continue
                if sql[j] == c:
                    if sql[j + 1:j + 2] == c:           # doubled quote
                        j += 2
                        continue
                    break
                j += 1
            j = min(j + 1, n)
            out.append(" " * (j - i))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out), slash


@dataclass
class ResidueReport:
    tokens: list[str] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return not self.tokens

    @property
    def caveat(self) -> str | None:
        return None if self.clean else RESIDUE_CAVEAT

    def reasons(self) -> list[str]:
        return [f"{RESIDUE_CAVEAT}: Snowflake-only construct(s) survive in the output: {', '.join(self.tokens)}"] \
            if self.tokens else []


def _tree_functions(sql: str) -> set[str]:
    try:
        trees = [t for t in sqlglot.parse(sql, read="databricks") if t is not None]
    except SqlglotError:
        return set()
    names: set[str] = set()
    for tree in trees:
        for fn in tree.find_all(exp.Anonymous):
            names.add(str(fn.this).upper())
    return names


def scan(sql: str, capabilities: CapabilityProfile | None = None) -> ResidueReport:
    """Snowflake-only tokens left in ``sql`` (sorted, de-duplicated). ``capabilities`` None = flags that matter for
    a modern warehouse only (no capability-gated token is reported)."""
    masked, slash = mask(sql or "")
    found: set[str] = set()
    if slash:
        found.add("// comment")
    found |= {m.group(1).upper() + "(" for m in _FUNC_RX.finditer(masked)}
    found |= {f"{n}(" for n in _tree_functions(sql or "") if n in SNOWFLAKE_ONLY_FUNCTIONS}
    for tok, rx in _SYNTAX_RX:
        if rx.search(masked):
            found.add(tok)
    if capabilities is not None:
        for flag, items in _CAP_RX.items():
            if not capabilities.has(flag):
                found |= {tok for tok, rx in items if rx.search(masked)}
    return ResidueReport(sorted(found))


def problems(sql: str, capabilities: CapabilityProfile | None = None) -> list[str]:
    """Validation-hook form: one problem line per scan, empty when clean."""
    return scan(sql, capabilities).reasons()


__all__ = ["RESIDUE_CAVEAT", "ResidueReport", "SNOWFLAKE_ONLY_FUNCTIONS", "mask", "problems", "scan"]
