"""Block-aware Snowflake Scripting splitter for the migrator (ADR 032 section 2, P3-07).

The adapter (``srcintel.adapters.snowflake.sql.split_scripting``) extracts EVERY DML/DDL statement with its control
path; this splitter keeps control-flow blocks WHOLE: each ``IF`` / ``FOR`` / ``WHILE`` / ``LOOP`` / ``REPEAT`` /
statement ``CASE`` / nested ``BEGIN`` / ``DECLARE`` / exception section is one node with ``unparsed=True`` and the
ordered child statement texts in ``children``, so no logic or ordering is dropped. Only top-level simple statements
become their own parsed nodes. Both sides run the shared corpus in ``tests/fixtures/snowflake/scripting/``.

Statement context decides what a keyword means: ``CASE`` at a statement start opens a block closed by ``END CASE``;
inside a statement it is an expression closed by a plain ``END``. ``BEGIN TRANSACTION`` / ``BEGIN WORK`` / ``BEGIN;``
and ``START TRANSACTION`` are simple statements.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from sqlglot.dialects.snowflake import Snowflake

_OPENERS = {"IF", "FOR", "WHILE", "LOOP", "REPEAT", "CASE", "BEGIN", "DECLARE"}
_TERMINATORS = {"END", "ELSE", "ELSEIF", "WHEN", "EXCEPTION", "UNTIL"}
#: statements that are control or variable handling, not SQL: kept as one unparsed node
_SCRIPT_VERBS = {"LET", "RETURN", "BREAK", "CONTINUE", "LEAVE", "ITERATE", "RAISE", "OPEN", "CLOSE", "FETCH",
                 "NULL", "EXECUTE", "ASYNC", "AWAIT", "CURSOR"}
_TXN_NEXT = {"TRANSACTION", "WORK", "NAME"}


@dataclass
class ScriptNode:
    statement_index: int
    kind: str                       # statement | call | block | declare | exception | script
    text: str
    unparsed: bool = False
    children: list[str] = field(default_factory=list)
    opener: str = ""                # IF / FOR / ... for blocks
    reason: str = ""

    def as_dict(self) -> dict:
        return {"statement_index": self.statement_index, "kind": self.kind, "text": self.text,
                "unparsed": self.unparsed, "children": list(self.children), "opener": self.opener,
                "reason": self.reason}


def extract_body(ddl: str) -> str:
    """The body of a ``CREATE PROCEDURE ... AS <body>``: ``$$ ... $$`` (nesting-aware: the LAST closing ``$$``) or a
    single-quoted literal with ``''`` unescaped. Text with neither is returned unchanged."""
    text = ddl or ""
    first = text.find("$$")
    if first >= 0:
        last = text.rfind("$$")
        return text[first + 2:last] if last > first else text[first + 2:]
    m = re.search(r"\bAS\s+'", text, re.I)
    if m:
        lit = text[m.end():]
        end = len(lit)
        i = 0
        while i < len(lit):
            if lit[i] == "'":
                if lit[i + 1:i + 2] == "'":
                    i += 2
                    continue
                end = i
                break
            i += 1
        return lit[:end].replace("''", "'")
    return text


def procedure_header(ddl: str) -> dict:
    """``{returns, execute_as, params}`` read from the text of a ``CREATE PROCEDURE`` before its body: the
    ``RETURNS`` type (``TABLE (...)`` kept whole), the declared ``(name TYPE, ...)`` list and ``EXECUTE AS OWNER |
    CALLER | RESTRICTED CALLER``; a key is absent when the definition does not say (a body without its CREATE has
    none of them)."""
    text = ddl or ""
    cut = text.find("$$")
    head = text if cut < 0 else text[:cut]
    out: dict = {}
    m = re.search(r"\bRETURNS\s+(TABLE\s*\((?:[^()]|\([^()]*\))*\)|[A-Za-z_][\w]*(?:\s*\([^()]*\))?)", head, re.I)
    if m:
        out["returns"] = re.sub(r"\s+", " ", m.group(1)).strip()
    m = re.search(r"\bPROCEDURE\s+[\w.$\"]+\s*\(", head, re.I)
    if m:
        depth, cur, parts = 1, "", []
        for ch in head[m.end():]:
            depth += ch == "("
            depth -= ch == ")"
            if depth == 0:
                break
            if ch == "," and depth == 1:
                parts.append(cur)
                cur = ""
            else:
                cur += ch
        parts.append(cur)
        pairs = [tuple(p.strip().split(None, 1)) for p in parts if len(p.strip().split(None, 1)) == 2]
        if pairs:
            out["params"] = [(a, b.strip()) for a, b in pairs]
    m = re.search(r"\bEXECUTE\s+AS\s+(RESTRICTED\s+CALLER|OWNER|CALLER)\b", head, re.I)
    if m:
        out["execute_as"] = re.sub(r"\s+", " ", m.group(1)).upper()
    return out


class _Toks:
    def __init__(self, body: str) -> None:
        self.body = body
        self.toks = [(t.text, t.start, t.end + 1, t.text.upper()) for t in Snowflake.Tokenizer().tokenize(body)]
        self.n = len(self.toks)

    def up(self, i: int) -> str:
        return self.toks[i][3] if 0 <= i < self.n else ""

    def text(self, a: int, b: int) -> str:
        """Source text from token a through token b-1 (inclusive), trailing ``;`` removed."""
        b = min(b, self.n)          # a malformed body (an unclosed block) may run past the last token
        if a >= b:
            return ""
        s = self.body[self.toks[a][1]:self.toks[b - 1][2]].strip()
        return s[:-1].rstrip() if s.endswith(";") else s


class _Parser:
    def __init__(self, body: str) -> None:
        self.t = _Toks(body)

    def _skip_to(self, i: int, words: set[str]) -> int:
        """Index of the first token in ``words`` at paren depth 0 (or n)."""
        depth = 0
        while i < self.t.n:
            u = self.t.up(i)
            if u == "(":
                depth += 1
            elif u == ")":
                depth -= 1
            elif depth <= 0 and u in words:
                return i
            i += 1
        return i

    def _simple_end(self, i: int) -> int:
        """Index just past the ``;`` that ends the simple statement starting at i (or n)."""
        j = self._skip_to(i, {";"})
        return min(j + 1, self.t.n)

    def is_txn_begin(self, i: int) -> bool:
        nxt = self.t.up(i + 1)
        return self.t.up(i) == "BEGIN" and (nxt in _TXN_NEXT or nxt == ";" or nxt == "")

    def label_len(self, i: int) -> int:
        """2 when tokens i, i+1 are ``label :`` before an opener."""
        if self.t.up(i + 1) == ":" and self.t.up(i + 2) in _OPENERS:
            return 2
        return 0

    def seq(self, i: int) -> tuple[list[tuple[int, int, str]], int]:
        """Statements until a terminator at a statement start. ``(spans, index_of_terminator_or_n)``;
        a span is ``(start, end, opener)`` (opener empty for simple statements)."""
        spans: list[tuple[int, int, str]] = []
        while i < self.t.n:
            if self.t.up(i) == ";":
                i += 1
                continue
            lab = self.label_len(i)
            u = self.t.up(i + lab)
            if u in _TERMINATORS and not lab:
                return spans, i
            if u in _OPENERS and not (u == "BEGIN" and self.is_txn_begin(i + lab)):
                end = self.block(i + lab)
                spans.append((i, end, u))
                i = end
                continue
            end = self._simple_end(i)
            spans.append((i, end, ""))
            i = end
        return spans, i

    def _header_end(self, i: int, opener: str) -> int:
        """Index of the first body token after the opener's header (``THEN`` / ``DO`` / first ``WHEN``)."""
        j = i + 1
        if opener == "IF":
            return self._skip_to(j, {"THEN"}) + 1
        if opener in ("FOR", "WHILE"):
            return self._skip_to(j, {"DO"}) + 1
        if opener == "CASE":
            return self._skip_to(j, {"WHEN"})
        return j

    def _branch(self, j: int) -> int | None:
        """Advance past a branch keyword; None when the block ends here."""
        u = self.t.up(j)
        if u in ("ELSEIF", "WHEN"):
            return self._skip_to(j + 1, {"THEN"}) + 1
        if u in ("ELSE", "EXCEPTION"):
            return j + 1
        if u == "UNTIL":
            return self._skip_to(j + 1, {"END"})
        return None

    def block(self, i: int) -> int:
        """Index just past the block opened at i (through its ``END ...;``)."""
        opener = self.t.up(i)
        if opener == "DECLARE":
            j = i + 1
            while j < self.t.n and self.t.up(j) != "BEGIN":      # declarations are simple statements
                j = self._simple_end(j)
            return self.block(j) if j < self.t.n else j
        j = self._header_end(i, opener)
        while True:
            _, j = self.seq(j)
            nxt = self._branch(j)
            if nxt is None:
                break
            j = nxt
        if self.t.up(j) == "END":
            j += 1
            if self.t.up(j) in ("IF", "FOR", "WHILE", "LOOP", "REPEAT", "CASE"):
                j += 1
            while j < self.t.n and self.t.up(j) != ";" and self.t.toks[j][0].replace("_", "").isalnum():
                j += 1                                           # an optional end label
            if self.t.up(j) == ";":
                j += 1
        return j

    def children_of(self, a: int, b: int) -> list[str]:
        """Ordered child statement texts of the block spanning tokens a..b (header and ``END`` excluded): every
        simple statement and every nested block (kept whole) inside any branch."""
        out: list[str] = []
        i = a + self.label_len(a)
        opener = self.t.up(i)
        if opener == "DECLARE":
            j = i + 1
            while j < b and self.t.up(j) != "BEGIN":
                e = self._simple_end(j)
                out.append(self.t.text(j, e))
                j = e
            return out + (self.children_of(j, b) if j < b else [])
        j = self._header_end(i, opener)
        while j < b:
            spans, j = self.seq(j)
            out += [self.t.text(s, e) for s, e, _ in spans]
            nxt = self._branch(j)
            if nxt is None:
                break
            j = nxt
        return out


def _first_word(text: str) -> str:
    m = re.match(r"\s*([A-Za-z_]+)", text)
    return m.group(1).upper() if m else ""


def split_scripting(body: str) -> list[ScriptNode]:
    """Top-level nodes of a Scripting body (``$$`` / quotes already removed, or run ``extract_body`` first).

    A non-scripting body (plain statements) is split on top-level ``;``. The outer ``DECLARE ... BEGIN ... END``
    wrapper is unwrapped: declarations become one ``declare`` node, the body statements follow, and an outermost
    ``EXCEPTION`` section is one ``exception`` node."""
    p = _Parser(body)
    t = p.t
    nodes: list[ScriptNode] = []
    i = 0

    def add(kind: str, text: str, **kw) -> None:
        nodes.append(ScriptNode(len(nodes), kind, text, **kw))

    def emit(spans: list[tuple[int, int, str]]) -> None:
        for s, e, opener in spans:
            text = t.text(s, e)
            if opener:
                add("block", text, unparsed=True, children=p.children_of(s, e), opener=opener,
                    reason=f"{opener} block kept whole")
                continue
            verb = t.up(s)
            if verb in _SCRIPT_VERBS:
                add("script", text, unparsed=True, reason=f"{verb} is not a SQL statement")
            elif t.up(s + 1) == ":=" or (t.up(s + 1) == ":" and t.up(s + 2) == "="):
                add("script", text, unparsed=True, reason="variable assignment")
            elif verb == "CALL":
                add("call", text)
            else:
                add("statement", text)

    if t.up(0) == "DECLARE":
        j = 1
        decls: list[str] = []
        while j < t.n and t.up(j) != "BEGIN":
            e = p._simple_end(j)
            decls.append(t.text(j, e))
            j = e
        add("declare", t.text(0, j), unparsed=True, children=decls, opener="DECLARE", reason="declarations")
        i = j
    if t.up(i) == "BEGIN" and not p.is_txn_begin(i):
        spans, j = p.seq(i + 1)
        emit(spans)
        if t.up(j) == "EXCEPTION":
            k = j + 1
            handlers: list[str] = []
            while k < t.n and t.up(k) != "END":
                if t.up(k) == "WHEN":
                    k = p._skip_to(k + 1, {"THEN"}) + 1
                sp, k = p.seq(k)
                handlers += [t.text(s, e) for s, e, _ in sp]
            add("exception", t.text(j, k), unparsed=True, children=handlers, opener="EXCEPTION",
                reason="exception handlers kept whole")
    else:
        spans, _ = p.seq(i)
        emit(spans)
    return nodes


def shape(nodes: list[ScriptNode]) -> list[tuple[str, str]]:
    """``(kind, first three words)`` per node: the comparable form the corpus goldens use."""
    return [(n.kind, " ".join(n.text.split()[:3]).upper()) for n in nodes]


def is_scripting(body: str) -> bool:
    # only a stored DDL or a ``$$``-wrapped text is unwrapped: a body may itself hold a ``$$`` literal
    text = extract_body(body) if body.lstrip().startswith("$$") or re.match(r"\s*CREATE\b", body, re.I) else body
    t = _Toks(text)
    return t.up(0) in ("DECLARE", "BEGIN") and not (t.up(0) == "BEGIN" and t.up(1) in _TXN_NEXT)


__all__ = ["ScriptNode", "extract_body", "is_scripting", "procedure_header", "shape", "split_scripting"]
