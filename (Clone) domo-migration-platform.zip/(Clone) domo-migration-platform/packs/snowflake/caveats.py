"""Caveat catalogue loader, detection and generated judges (ADR 032 section 4, P3-08).

``caveats.yaml`` owns ids, severity, rewrites and detect rules. Detection runs over the SOURCE text with string
literals and comments blanked (literals never reach a judge or a log, hard rule 11). The ``SNW00x`` judges are
generated from the ``family`` field, one per family.
"""
from __future__ import annotations

import functools
import pathlib
import re
from dataclasses import dataclass
from typing import Any

import yaml

from core.contracts.judges import Finding, Judge, JudgeKind, JudgeResult, Verdict

HERE = pathlib.Path(__file__).parent
SEVERITIES = ("info", "review", "escalate", "block")


@dataclass(frozen=True)
class Caveat:
    id: str
    family: str
    severity: str
    detect: dict
    rewrite: str = ""
    note: str = ""
    migrator_only: bool = False

    def __post_init__(self) -> None:
        if self.severity not in SEVERITIES:
            raise ValueError(f"{self.id}: unknown severity {self.severity!r}")


@dataclass(frozen=True)
class Catalogue:
    version: str
    families: dict[str, str]
    entries: tuple[Caveat, ...]

    @property
    def ids(self) -> tuple[str, ...]:
        """The ids shared with the adapter README (migrator-only ids excluded)."""
        return tuple(c.id for c in self.entries if not c.migrator_only)

    def by_id(self) -> dict[str, Caveat]:
        return {c.id: c for c in self.entries}

    def ids_with(self, severity: str) -> frozenset[str]:
        return frozenset(c.id for c in self.entries if c.severity == severity)


@functools.lru_cache(maxsize=1)
def load_catalogue(path: str | None = None) -> Catalogue:
    raw = yaml.safe_load(pathlib.Path(path or HERE / "caveats.yaml").read_text(encoding="utf-8"))
    entries = [Caveat(id=e["id"], family=e["family"], severity=e["severity"], detect=dict(e.get("detect") or {}),
                      rewrite=str(e.get("rewrite") or ""), note=str(e.get("note") or ""))
               for e in raw["caveats"]]
    entries += [Caveat(id=e["id"], family=e["family"], severity=e["severity"], detect=dict(e.get("detect") or {}),
                       rewrite=str(e.get("rewrite") or ""), note=str(e.get("note") or ""), migrator_only=True)
                for e in raw.get("migrator_only") or []]
    return Catalogue(str(raw["version"]), dict(raw["families"]), tuple(entries))


_STRING = re.compile(r"'(?:[^']|'')*'")
_LINE_COMMENT = re.compile(r"--[^\n]*|//[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_DOLLAR = re.compile(r"\$\$.*?\$\$", re.S)


def blank_literals(sql: str) -> str:
    """Strings and comments replaced by spaces of the same length (offsets stay valid, literals never leak)."""
    out = sql
    for rx in (_DOLLAR, _BLOCK_COMMENT, _LINE_COMMENT, _STRING):
        out = rx.sub(lambda m: " " * len(m.group(0)), out)
    return out


@functools.lru_cache(maxsize=None)
def _rx(pattern: str) -> re.Pattern:
    return re.compile(pattern, re.I)


def detect(sql: str, catalogue: Catalogue | None = None) -> list[str]:
    """Sorted caveat ids whose rule matches the (literal-blanked) source SQL."""
    cat = catalogue or load_catalogue()
    text = blank_literals(sql or "")
    hit: set[str] = set()
    for c in cat.entries:
        d = c.detect
        if d.get("pattern") and _rx(d["pattern"]).search(text):
            hit.add(c.id)
        elif d.get("function") and not str(d["function"]).startswith("_") \
                and _rx(rf"\b{re.escape(str(d['function']))}\s*\(").search(text):
            hit.add(c.id)
    return sorted(hit)


def classify(ids: list[str] | set[str], catalogue: Catalogue | None = None) -> dict[str, list[str]]:
    """``{severity: [ids]}`` for the ids that were hit."""
    cat = catalogue or load_catalogue()
    table = cat.by_id()
    out: dict[str, list[str]] = {s: [] for s in SEVERITIES}
    for i in sorted(set(ids)):
        if i in table:
            out[table[i].severity].append(i)
    return out


class FamilyJudge(Judge):
    """One ``SNW00x`` judge: the caveats of one family that a unit hit and nobody acknowledged.

    Reads ``subject.meta["caveats_hit"]`` (unit/node id -> caveat ids). ``block`` caveats FAIL, ``review`` /
    ``escalate`` WARN (a human decides), ``info`` passes. ``meta["caveats_acknowledged"]`` clears review items.
    """
    kind = JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)

    def __init__(self, rule_id: str, title: str, catalogue: Catalogue) -> None:
        self.rule_id, self.title = rule_id, title
        self._table = {c.id: c for c in catalogue.entries if c.family == rule_id}

    def run(self, subject: Any) -> JudgeResult:
        hit = dict((getattr(subject, "meta", None) or {}).get("caveats_hit") or {})
        ack = set((getattr(subject, "meta", None) or {}).get("caveats_acknowledged") or ())
        findings: list[Finding] = []
        worst = Verdict.PASS
        checked = 0
        for node, ids in sorted(hit.items()):
            for cid in ids:
                c = self._table.get(cid)
                if c is None:
                    continue
                checked += 1
                if c.severity == "info" or cid in ack:
                    continue
                findings.append(Finding(node=str(node), message=f"{cid} ({c.severity})", detail=c.note))
                if c.severity == "block":
                    worst = Verdict.FAIL
                elif worst is Verdict.PASS:
                    worst = Verdict.WARN
        return self._result(worst, tuple(findings), checked=checked)


def generate_judges(catalogue: Catalogue | None = None) -> list[Judge]:
    cat = catalogue or load_catalogue()
    return [FamilyJudge(fam, f"Snowflake caveats: {title}", cat) for fam, title in sorted(cat.families.items())]


__all__ = ["Caveat", "Catalogue", "FamilyJudge", "blank_literals", "classify", "detect", "generate_judges",
           "load_catalogue"]
