"""packs.snowflake.units - the ``file_load`` (P3-18, D-29) and ``statement`` (P3-19, D-28) unit builders.

Both are installed into ``handlers.BUILDERS`` by ``install()``. ``run_etl`` gates their output as ``cd_codegen`` with
origin ``manual``: it never auto-approves, so these ETLs always end ``awaiting_review``.

* ``file_load``: a Snowpipe, stage-fed external table or ``COPY INTO`` loader becomes ONE Databricks counterpart,
  built from the cloud path and file format Phase 1 extracted (ADR 030): Auto Loader
  (``CREATE OR REFRESH STREAMING TABLE ... read_files(...)``) for continuous loads, ``COPY INTO`` for one-shot loads.
  A format option with no Databricks equivalent becomes a review reason and a caveat; it is never dropped silently.
* ``statement``: every redacted representative query text goes through the same chain as any unit (tier 0 transpile,
  optional Lakebridge, LLM, human) and is gated for review; a ``repoint_task`` artifact lists the source objects to
  replace with their ``target_map`` names. Literals stay redacted: only object names are ever listed.
"""
from __future__ import annotations

import re
from typing import Any

from sqlglot import exp, parse_one
from sqlglot.errors import SqlglotError

from packs.snowflake import contract as ct
from packs.snowflake import handlers as hd
from packs.snowflake import translate as tr
from packs.snowflake.handlers import Artifact, HandlerContext, slug, target_name
from packs.snowflake.postpass import table_key

_FORMATS = {"CSV": "csv", "JSON": "json", "PARQUET": "parquet", "AVRO": "avro", "ORC": "orc", "XML": "xml",
            "TEXT": "text", "BINARYFILE": "binaryFile"}
#: Snowflake format option -> (Databricks option, value transform or None for as-is)
_OPTIONS: dict[str, tuple[str, Any]] = {
    "FIELD_DELIMITER": ("delimiter", None),
    "FIELD_OPTIONALLY_ENCLOSED_BY": ("quote", None),
    "ESCAPE": ("escape", None),
    "MULTI_LINE": ("multiLine", lambda v: str(v).lower()),
    "PARSE_HEADER": ("header", lambda v: str(v).lower()),
    "SKIP_BLANK_LINES": ("ignoreEmptyLines", lambda v: str(v).lower()),
    "STRIP_OUTER_ARRAY": ("multiLine", lambda v: str(v).lower()),
}
#: accepted without a Databricks option (Spark infers it / has it by default / does not apply to reads)
_IGNORED = {"TYPE", "COMPRESSION", "ERROR_ON_COLUMN_COUNT_MISMATCH", "REPLACE_INVALID_CHARACTERS",
            "EMPTY_FIELD_AS_NULL", "SKIP_BYTE_ORDER_MARK", "BINARY_FORMAT", "ALLOW_DUPLICATE", "BINARY_AS_TEXT",
            "ENABLE_OCTAL", "IGNORE_UTF8_ERRORS"}
#: Snowflake `ENCODING` names -> Java charset names
_ENCODINGS = {"ISO88591": "ISO-8859-1", "ISO88592": "ISO-8859-2", "WINDOWS1250": "windows-1250",
              "WINDOWS1251": "windows-1251", "WINDOWS1252": "windows-1252", "UTF16": "UTF-16",
              "UTF16LE": "UTF-16LE", "UTF16BE": "UTF-16BE", "UTF32": "UTF-32"}
_NONE = {"NONE", ""}
_CLOUD = re.compile(r"^(s3|gcs|gs|azure|abfss?|wasbs?)://", re.I)
#: Snowflake date / time format tokens -> Java (Spark) pattern letters, longest first
_TOKENS = [("YYYY", "yyyy"), ("YY", "yy"), ("MMMM", "MMMM"), ("MON", "MMM"), ("MM", "MM"), ("DD", "dd"),
           ("DY", "EEE"), ("HH24", "HH"), ("HH12", "hh"), ("HH", "HH"), ("MI", "mm"), ("SS", "ss"),
           ("FF9", "SSSSSSSSS"), ("FF6", "SSSSSS"), ("FF3", "SSS"), ("FF", "SSS"), ("TZH:TZM", "XXX"),
           ("TZHTZM", "XX"), ("AM", "a"), ("PM", "a")]


def cloud_path(url: str) -> tuple[str, list[str]]:
    """The Databricks-side path for a Snowflake stage URL, plus review reasons when it cannot be mapped exactly."""
    u = url.strip().strip("'\"")
    m = re.match(r"^azure://([^/.]+)\.blob\.core\.windows\.net/([^/]+)/?(.*)$", u, re.I)
    if m:
        return f"abfss://{m.group(2)}@{m.group(1)}.dfs.core.windows.net/{m.group(3)}", []
    if u.lower().startswith("gcs://"):
        return "gs://" + u[6:], []
    if u.lower().startswith("s3://"):
        return u, []
    if _CLOUD.match(u):
        return u, []
    return u, [f"stage location {u!r} is not a cloud path: choose the Unity Catalog volume or external location"]


_IDENT = r'(?:"[^"]+"|[\w$]+)'


def parse_copy(text: str) -> dict[str, Any]:
    """What a pipe / COPY INTO definition says: target parts, column list, source (stage ref or url), the file format
    (named or inline options), pattern, on_error, match_by_column_name. Missing parts are simply absent."""
    out: dict[str, Any] = {}
    if not isinstance(text, str) or not text.strip():
        return out
    m = re.search(rf"\bCOPY\s+INTO\s+({_IDENT}(?:\s*\.\s*{_IDENT}){{0,2}})\s*(\([^)]*\))?", text, re.I)
    if m:
        out["target"] = [p.strip('"') if p.startswith('"') else p.upper()
                         for p in re.split(r"\s*\.\s*", m.group(1).strip())]
        if m.group(2):
            out["columns"] = [c.strip().strip('"') for c in m.group(2)[1:-1].split(",") if c.strip()]
    m = re.search(r"\bFROM\s+'([^']*)'", text, re.I)
    if m:
        out["url"] = m.group(1)
    else:
        m = re.search(r"\bFROM\s+(@[^\s;()]+)", text, re.I)
        if m:
            out["stage"] = m.group(1)
    m = re.search(r"\bFILE_FORMAT\s*=\s*\(([^)]*)\)", text, re.I)
    if m:
        inner = m.group(1)
        fm = re.search(r"FORMAT_NAME\s*=\s*('?)([^'\s,)]+)\1", inner, re.I)
        if fm:
            out["format_name"] = fm.group(2)
        else:
            raw = re.findall(r"(\w+)\s*=\s*('(?:[^']|'')*'|[^\s,)]+)", inner)
            out["format_options"] = {a.upper(): b.strip("'") for a, b in raw}
    else:
        m = re.search(r"\bFILE_FORMAT\s*=\s*'?([\w$.\"]+)'?", text, re.I)
        if m:
            out["format_name"] = m.group(1)
    for key, rx in (("pattern", r"\bPATTERN\s*=\s*'((?:[^']|'')*)'"), ("on_error", r"\bON_ERROR\s*=\s*'?(\w+)'?"),
                    ("match_by_column_name", r"\bMATCH_BY_COLUMN_NAME\s*=\s*(\w+)")):
        m = re.search(rx, text, re.I)
        if m:
            out[key] = m.group(1).replace("''", "'")
    return out


def _flat(ff: Any) -> dict[str, Any]:
    if isinstance(ff, str):
        return {"TYPE": ff}
    if not isinstance(ff, dict):
        return {}
    flat = dict(ff.get("options") or {})
    flat.update({k: v for k, v in ff.items() if k not in ("options", "name", "inline")})
    return {str(k).upper(): v for k, v in flat.items()}


def _same_format(a: str, b: str) -> bool:
    return str(a).strip("'\" ").upper().split(".")[-1] == str(b).strip("'\" ").upper().split(".")[-1]


def _opts(doc: dict, row: dict, copy: dict[str, Any] | None = None) -> tuple[dict[str, Any], list[str]]:
    """The file-format options of this load: the COPY's inline options, else the named format (taken from the
    manifest's resolved format when the names agree), else the manifest / stage format. `(options, reasons)`."""
    params = doc.get("params") or {}
    copy = copy or {}
    ff = row.get("file_format") or params.get("file_format") or doc.get("file_format") or {}
    if copy.get("format_options"):
        return {str(k).upper(): v for k, v in copy["format_options"].items()}, []
    if copy.get("format_name"):
        same = not ff.get("name") or _same_format(ff["name"], copy["format_name"]) if isinstance(ff, dict) else False
        if same and ff.get("options"):
            return _flat(ff), []
        return {}, [f"file format not resolved: the load names format {copy['format_name']!r} but its definition was "
                    "not extracted; choose the format and its options"]
    flat = _flat(ff)
    if not flat:
        return {}, ["file format not resolved: no FILE_FORMAT on the load and none on its stage; choose the format"]
    return flat, []


def _lit(v: Any) -> str:
    return "'" + str(v).replace("\\", "\\\\").replace("'", "\\'") + "'"


def snowflake_datetime(fmt: str) -> str | None:
    """A Snowflake date / time format as a Java pattern; None when a token is not understood."""
    out, i = "", 0
    while i < len(fmt):
        for tok, rep in _TOKENS:
            if fmt[i:i + len(tok)].upper() == tok:
                out += rep
                i += len(tok)
                break
        else:
            ch = fmt[i]
            if ch.isalpha():
                return None
            out += ch
            i += 1
    return out


def regex_to_glob(rx: str) -> str | None:
    """A Snowflake PATTERN (regex over the whole path) as a pathGlobFilter glob; None when it is not a simple one."""
    out, i = "", 0
    while i < len(rx):
        if rx.startswith(".*", i):
            out += "*"
            i += 2
        elif rx.startswith("[.]", i):
            out += "."
            i += 3
        elif rx.startswith("\\.", i):
            out += "."
            i += 2
        elif rx[i] == ".":
            out += "?"
            i += 1
        elif rx[i] in "+?|()^${}[]\\":
            return None
        else:
            out += rx[i]
            i += 1
    return out


def map_format(opts: dict[str, Any]) -> tuple[str, dict[str, str], list[str]]:
    """``(format, databricks options, review reasons)``. Snowflake-only values never leak: ``AUTO`` formats are left
    to Spark's inference, formats are translated to Java patterns, anything unmappable is a review reason."""
    reasons: list[str] = []
    ftype = str(opts.get("TYPE") or "").upper()
    fmt = _FORMATS.get(ftype)
    if fmt is None:
        reasons.append(f"file format type {ftype or 'unavailable'} has no read_files format: choose one")
        fmt = "csv"
    out: dict[str, str] = {}
    for key, val in opts.items():
        k = key.upper()
        if k in _IGNORED or val in (None, ""):
            continue
        if k in ("ESCAPE", "FIELD_OPTIONALLY_ENCLOSED_BY") and str(val).strip().upper() in _NONE:
            continue
        if k == "SKIP_HEADER":
            n = int(val) if str(val).isdigit() else 0
            if n >= 1:
                out["header"] = "true"
            if n > 1:
                out["skipRows"] = str(n - 1)
                reasons.append(f"SKIP_HEADER = {n}: header => true with skipRows => {n - 1}; confirm the first rows")
            continue
        if k in ("DATE_FORMAT", "TIMESTAMP_FORMAT", "TIME_FORMAT"):
            v = str(val).strip()
            if v.upper() == "AUTO":
                continue                                    # Spark infers dates and timestamps
            java = snowflake_datetime(v)
            target = {"DATE_FORMAT": "dateFormat", "TIMESTAMP_FORMAT": "timestampFormat"}.get(k)
            if java is None or target is None:
                reasons.append(f"{k} = {v!r} has no Java pattern equivalent: set the date / timestamp format by hand")
            else:
                out[target] = java
            continue
        if k == "NULL_IF":
            vals = [str(x) for x in (val if isinstance(val, (list, tuple)) else [val])]
            vals = [x for x in vals if x != ""]            # the empty string is already null by default
            if vals:
                out["nullValue"] = vals[0]
            if len(vals) > 1:
                reasons.append(f"NULL_IF lists several values {vals}: only the first maps to nullValue")
            continue
        if k == "ENCODING":
            norm = str(val).upper().replace("-", "").replace("_", "")
            if norm == "UTF8":
                continue                                    # the default
            if norm in _ENCODINGS:
                out["encoding"] = _ENCODINGS[norm]
            else:
                reasons.append(f"ENCODING = {val!r} is not a known charset name: set encoding by hand")
            continue
        if k == "RECORD_DELIMITER":
            if str(val) in ("\n", "\\n", "\r\n", "\\r\\n") or str(val).upper() == "NONE":
                continue                                    # newline records are the default
            out["lineSep"] = str(val)
            continue
        if k == "TRIM_SPACE":
            if str(val).lower() == "true":
                out["ignoreLeadingWhiteSpace"] = out["ignoreTrailingWhiteSpace"] = "true"
            continue
        if k in _OPTIONS:
            name, fn = _OPTIONS[k]
            out[name] = fn(val) if fn else str(val)
            continue
        reasons.append(f"format option {k} has no Databricks equivalent")
    return fmt, out, reasons


def _row_path(doc: dict, row: dict, copy: dict[str, Any] | None = None) -> str:
    if copy and copy.get("url"):
        return str(copy["url"])
    params = doc.get("params") or {}
    for src in (row, params, doc):
        for k in ("url", "stage_url", "cloud_path", "location", "path"):
            if src.get(k) and not ct.is_unavailable(src.get(k)):
                return str(src[k])
    return ""


def _copy_target(copy: dict[str, Any], doc: dict, row: dict, h: HandlerContext) -> tuple[str | None, list[str]]:
    """The Databricks table the COPY INTO writes, found through the unit's outputs / ``target_map`` by its OWN
    qualified name (never the first output): ``(table, reasons)``; ``(None, [])`` when the definition names none."""
    parts = copy.get("target")
    if not parts:
        return None, []
    native = ct.parse_native_id(str(doc.get("asset_id") or ""))
    full = ([native["db"], native["schema"]] + parts)[-3:] if len(parts) < 3 else parts[-3:]
    dotted = ".".join(str(x).upper() for x in full)
    for o in [*(doc.get("outputs") or []), *(row.get("outputs") or [])]:
        if o.get("table") and str(o.get("name") or "").upper() == dotted:
            return str(o["table"]), []
    for aid, tbl in h.target_map.items():
        pid = ct.parse_native_id(aid)
        if not pid["objtype"] and ".".join(str(pid[k]).upper() for k in ("db", "schema", "name")) == dotted:
            return tbl, []
    return None, [f"COPY INTO target {dotted} has no target table in the hand-off: choose the Databricks table"]


def build_file_load(row: dict, doc: dict, h: HandlerContext) -> list[Artifact]:
    """One counterpart artifact for a file-load row (``kind="file_load"``, origin ``manual``)."""
    etl_id = str(row.get("etl_id") or doc.get("etl_id") or "")
    reasons: list[str] = []
    copy = parse_copy(doc.get("definition") if isinstance(doc.get("definition"), str) else "")
    name, why_t = _copy_target(copy, doc, row, h)
    reasons += why_t
    if name is None:
        name = target_name(doc, h)
    raw = _row_path(doc, row, copy)
    path, why = cloud_path(raw) if raw else ("", ["cloud path unavailable from the extraction: set the location"])
    reasons += why
    opts, why_f = _opts(doc, row, copy)
    reasons += why_f
    fmt, options, fmt_reasons = map_format(opts)
    reasons += fmt_reasons
    params = doc.get("params") or {}
    pattern = copy.get("pattern") or row.get("pattern") or params.get("pattern")
    continuous = bool(row.get("auto_ingest") or params.get("auto_ingest") or doc.get("engine") == "snowpipe")
    on_error = str(copy.get("on_error") or row.get("on_error") or params.get("on_error") or "").upper()
    if on_error:
        if on_error == "ABORT_STATEMENT":
            options["mode"] = "FAILFAST"
        else:
            options["mode"] = "PERMISSIVE"
            reasons.append(f"ON_ERROR = {on_error}: bad records land in _rescued_data (mode => PERMISSIVE); Snowflake "
                           f"skipped {'the whole file' if 'SKIP_FILE' in on_error else 'the bad rows'}: decide the "
                           "rescue / badRecordsPath behaviour with the owner")
    if copy.get("match_by_column_name") or row.get("match_by_column_name") or params.get("match_by_column_name"):
        reasons.append("MATCH_BY_COLUMN_NAME: confirm the target schema and schemaEvolutionMode")
    if copy.get("columns"):
        reasons.append(f"COPY INTO lists columns {copy['columns']}: read_files infers its own columns; map them in "
                       "the streaming table's SELECT if the file layout differs")
    glob = None
    if pattern:
        glob = regex_to_glob(str(pattern))
        if glob is None:
            reasons.append(f"PATTERN {pattern!r} is a regex that is not a simple glob: set pathGlobFilter by hand")
    path_sql = _lit(path or "<unavailable>")
    if continuous:
        opt_sql = "".join(f",\n  {k} => {_lit(v)}" for k, v in sorted(options.items()))
        gl = f",\n  pathGlobFilter => {_lit(glob)}" if glob else ""
        text = (f"CREATE OR REFRESH STREAMING TABLE {name} AS\nSELECT * FROM STREAM read_files(\n  {path_sql},\n"
                f"  format => {_lit(fmt)}{opt_sql}{gl}\n)")
        shape = "auto_loader"
    else:
        opt_sql = ", ".join(f"{_lit(k)} = {_lit(v)}" for k, v in sorted(options.items()))
        fo = f"\nFORMAT_OPTIONS ({opt_sql})" if opt_sql else ""
        pt = f"\nPATTERN {_lit(glob)}" if glob else ""
        text = f"COPY INTO {name}\nFROM {path_sql}\nFILEFORMAT = {fmt.upper()}{pt}{fo}"
        shape = "copy_into"
    caveats = []
    if any(r.startswith("file format not resolved") for r in reasons):
        caveats.append("SNW-FILE-FORMAT")
    if reasons:
        caveats.append("SNW-STAGE-COLS")
    art = Artifact("file_load", name, text, "manual", etl_id, [f"{etl_id}-fl"], caveats, reasons,
                   spec={"shape": shape, "format": fmt, "path": path, "copy_target": copy.get("target")})
    return [art]


# --------------------------------------------------------------------------- statements

def _texts(row: dict, doc: dict) -> list[str]:
    out: list[str] = []
    for s in row.get("statements") or []:
        t = s.get("text") or s.get("query_text") or s.get("sql") if isinstance(s, dict) else s
        if t and isinstance(t, str):
            out.append(t)
    for k in ("text", "query_text", "sql"):
        if isinstance(row.get(k), str) and row[k]:
            out.append(row[k])
    d = doc.get("definition")
    if not out and isinstance(d, str) and d.strip():
        out.append(d)
    return out


def source_objects(text: str, table_map: dict, default_db: str = "", default_schema: str = "") -> list[tuple[str, str]]:
    """``(source object, target name or '')`` for every table a statement reads or writes. Names only."""
    try:
        tree = parse_one(text, read="snowflake")
    except (SqlglotError, ValueError):
        return []
    seen: dict[str, str] = {}
    ctes = {c.alias_or_name.upper() for c in tree.find_all(exp.CTE)}
    for t in tree.find_all(exp.Table):
        if not t.name or (not t.db and t.name.upper() in ctes):
            continue
        db = t.catalog or default_db
        sch = t.db or default_schema
        shown = ".".join(p for p in (t.catalog, t.db, t.name) if p)
        seen.setdefault(shown, str(table_map.get(table_key(db, sch, t.name), "")) if db and sch else "")
    return sorted(seen.items())


async def build_statement(row: dict, doc: dict, h: HandlerContext) -> list[Artifact]:
    """Translated statement artifacts (always for review) plus one ``repoint_task`` artifact."""
    etl_id = str(row.get("etl_id") or doc.get("etl_id") or "")
    base = slug(str(row.get("name") or doc.get("name") or etl_id))
    texts = _texts(row, doc)
    arts: list[Artifact] = []
    repoint: list[tuple[str, str]] = []
    table_map: dict = {}
    for i, text in enumerate(texts):
        sub = {**doc, "engine": "query", "definition": text, "params": dict(doc.get("params") or {})}
        reasons = ["statement unit: always reviewed; confirm the translation against the query's consumers"]
        caveats: list[str] = []
        if h.unit_ctx_factory is None:
            res_sql, origin = "", "manual"
            reasons.append("no translation context: the redacted text is kept for manual translation")
        else:
            ctx = h.unit_ctx_factory(sub, f"{etl_id}-st{i}")
            table_map = ctx.postpass.ctx.table_map
            results = await tr.translate_etl(sub, ctx)
            done = [r for r in results if r.status == "resolved" and r.sql]
            res_sql = ";\n".join(r.sql for r in done) if len(done) == len(results) else ""
            origin = "manual" if not res_sql else tr_origin(done)
            caveats = sorted({c for r in results for c in (*r.caveats, *r.review_caveats)})
            for r in results:
                reasons += r.reasons
        if not res_sql:
            res_sql = "-- NOT TRANSLATED (a reviewer translates this redacted text)\n" + "\n".join(
                f"-- {ln}" for ln in text.splitlines())
        arts.append(Artifact("statement", f"{base}_stmt{i + 1}", res_sql, origin, etl_id, [f"{etl_id}-st{i}"],
                             caveats, reasons))
        repoint += source_objects(text, table_map)
    if texts:
        by_name = dict(repoint)
        lines = [f"-- Re-point task for {base}: replace each Snowflake object with its Databricks name."]
        miss = "<no target_map entry: map it or LIFT>"
        lines += [f"-- {src} -> {tgt or miss}" for src, tgt in sorted(by_name.items())]
        arts.append(Artifact("repoint_task", f"{base}_repoint", "\n".join(lines), "manual", etl_id,
                             [f"{etl_id}-repoint"], [], ["owner replaces the source objects in the consuming tool"]))
    return arts


def tr_origin(results: list[Any]) -> str:
    order = ["mapped", "transpiled", "ai", "manual"]
    worst = max((r.origin for r in results), key=lambda o: order.index(o) if o in order else 0, default="manual")
    return "transpiled" if worst == "mapped" else worst


def install() -> None:
    hd.BUILDERS["file_load"] = build_file_load
    hd.BUILDERS["statement"] = build_statement


__all__ = ["build_file_load", "build_statement", "cloud_path", "install", "map_format", "source_objects"]
