"""packs.snowflake.code_common - what the procedural-code converters share (S2, ADR 037; rows 5.11-5.13, 6.12).

The JavaScript and Python/Snowpark converters (``js_convert``, ``python_convert``) are ports of SNF2DBX
``converters/javascript.py`` and ``converters/python_proc.py``. Where SNF2DBX gave them a ``NameMapper`` and its own
``transpile``, they get a ``CodeServices`` here: every SQL statement inside the code goes through the SAME tier 0 a view
gets (sqlglot + pack rules + post-pass + validators + caveat scan + residue guard), table names come from the batch's
table map, and nothing is guessed (an unmapped table is a refusal that names it).

``CodeRefused`` is the one exception a converter raises: the reason names the construct and its line, never the source
text (hard rule 11), and the unit then goes down the normal chain (Lakebridge, AI, a human).
"""
from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass, field

from sqlglot import exp
from sqlglot.errors import SqlglotError

from packs.snowflake import contract as ct
from packs.snowflake.postpass import table_key


class CodeRefused(ValueError):
    """The converter has no exact rule: the message is the precise reason (construct, line)."""


class ConverterUnavailable(CodeRefused):
    """A dependency of the converter is not installed (esprima for JavaScript): the reason says which."""


_SQL_NOISE = re.compile(r"\.?\s*Line \d+, Col:.*", re.S)


def clean_reason(reason: str, limit: int = 220) -> str:
    """An inner reason without sqlglot's echo of the offending SQL text (hard rule 11): cut at ``Line n, Col: m``."""
    text = _SQL_NOISE.sub("", str(reason))
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    return " ".join(text.split())[:limit]


# --------------------------------------------------------------------------------------------------- names
@dataclass
class CodeNames:
    """Name resolution for code that names tables and procedures in strings (the SNF2DBX ``NameMapper``, backed by the
    post-pass's table map instead of a naming convention)."""
    table_map: dict[tuple[str, str, str], str]
    default_db: str
    default_schema: str
    default_catalog: str = "main"

    def resolve(self, parts: list[str]) -> tuple[str, str, str]:
        """``(DB, SCHEMA, NAME)`` of a 1-3 part reference: unquoted parts fold to upper case, quoted parts stay."""
        p = [x[1:-1].replace('""', '"') if x.startswith('"') else x.upper() for x in parts]
        if len(p) == 1:
            p = [self.default_db, self.default_schema, p[0]]
        elif len(p) == 2:
            p = [self.default_db, *p]
        if len(p) != 3 or not all(p):
            raise CodeRefused(f"the name {'.'.join(parts)} cannot be qualified (no database / schema known)")
        return p[0], p[1], p[2]

    def table(self, parts: list[str], where: str) -> str:
        db, schema, name = self.resolve(parts)
        target = self.table_map.get(table_key(db, schema, name))
        if target is None:
            raise CodeRefused(f"{where}: table {db}.{schema}.{name} is not in the batch's table map, so it has no "
                              "Databricks name (add it to the handoff)")
        return target

    def maybe_table(self, parts: list[str]) -> str | None:
        try:
            return self.table_map.get(table_key(*self.resolve(parts)))
        except CodeRefused:
            return None

    def known_database(self, db: str) -> bool:
        return db.upper() in {k[0] for k in self.table_map}

    def routine(self, parts: list[str]) -> tuple[str, str]:
        """``(SOURCE FQN upper, Databricks name)`` of a procedure or function."""
        db, schema, name = self.resolve(parts)
        return f"{db}.{schema}.{name}", ct.derived_target(self.default_catalog, db, schema, name)

    def schema_of(self, db: str, schema: str) -> str | None:
        """``catalog.schema`` the tables of one source schema landed in, when they all landed in one."""
        found = {v.rsplit(".", 1)[0] for k, v in self.table_map.items()
                 if k[0] == db.upper() and k[1] == schema.upper()}
        return found.pop() if len(found) == 1 else None

    def use_statement(self, kind: str, parts: list[str]) -> str:
        if kind.upper() == "DATABASE":
            return f"USE CATALOG {self.default_catalog}"
        parts = ([self.default_db] + parts) if len(parts) == 1 else parts
        target = self.schema_of(parts[0], parts[-1])
        if target is None:
            raise CodeRefused(f"USE SCHEMA {parts[0]}.{parts[-1]}: the tables of that schema did not land in one "
                              "Databricks schema")
        return f"USE {target}"


# --------------------------------------------------------------------------------------------------- services
@dataclass
class CodeServices:
    """What a converter may call. ``statement`` is tier 0 for one complete Snowflake statement (it returns Databricks
    text or raises ``CodeRefused``); ``residue`` lists the Snowflake-only tokens in a piece of SQL text; ``procedures``
    maps SOURCE procedure FQN (upper) to its scalar RETURNS type for the procedures that have a ``__ret`` twin."""
    statement: Callable[[str], str]
    residue: Callable[[str], list[str]]
    names: CodeNames
    procedures: dict[str, str] = field(default_factory=dict)
    #: filled by the callers of ``statement``: review caveats and caveat ids the inner statements hit
    review: set[str] = field(default_factory=set)
    caveats: set[str] = field(default_factory=set)
    statements: int = 0


# --------------------------------------------------------------------------------------------------- the object
@dataclass
class CodeObject:
    kind: str                       # procedure | function
    name: str
    language: str
    body: str
    args: list[dict] = field(default_factory=list)       # name, type, default
    returns: str = ""
    handler: str | None = None
    runtime_version: str | None = None
    packages: list[str] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    strict: bool = False
    execute_as: str = ""
    table_function: bool = False
    external_access: bool = False
    inline: bool = True             # the code is in the definition (a JAR / staged module is not)
    database: str = ""
    schema: str = ""

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["table_function"] = self.table_function
        return d


_CREATE = re.compile(r"^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:SECURE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:AGGREGATE\s+)?"
                     r"(PROCEDURE|FUNCTION)\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w$.\"]+)\s*\(", re.I)
_BODY = re.compile(r"\bAS\s+('(?:[^'\\]|''|\\.)*'|\$\$.*?\$\$)\s*;?\s*$", re.I | re.S)
_PROP_STOP = (r"LANGUAGE|NOT\s+NULL|NULL|STRICT|CALLED|RETURNS\s+NULL|VOLATILE|IMMUTABLE|COMMENT|EXECUTE|"
              r"RUNTIME_VERSION|"
              r"PACKAGES|HANDLER|IMPORTS|EXTERNAL_ACCESS_INTEGRATIONS|SECRETS|TARGET_PATH|MEMOIZABLE|COPY")


def sql_string(lit: str) -> str:
    """Decode a Snowflake ``'...'`` literal or ``$$...$$`` body."""
    lit = lit.strip()
    if lit.startswith("$$") and lit.endswith("$$"):
        return lit[2:-2]
    if lit.startswith("'") and lit.endswith("'"):
        return lit[1:-1].replace("''", "'").replace("\\'", "'").replace("\\\\", "\\")
    return lit


def _matching(text: str, start: int) -> int:
    depth, quote = 0, ""
    for i in range(start, len(text)):
        ch = text[i]
        if quote:
            quote = "" if ch == quote else quote
        elif ch in "'\"":
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _split_top(text: str) -> list[str]:
    out, depth, cur, quote = [], 0, "", ""
    for ch in text:
        if quote:
            cur += ch
            quote = "" if ch == quote else quote
            continue
        if ch in "'\"":
            quote = ch
        elif ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return out


def _prop(head: str, key: str) -> str | None:
    m = re.search(rf"\b{key}\s*=\s*('(?:[^']|'')*'|\$\$.*?\$\$|[^\s,)]+)", head, re.I | re.S)
    return sql_string(m.group(1)) if m else None


def _listing(head: str, key: str) -> list[str]:
    m = re.search(rf"\b{key}\s*=\s*\(([^)]*)\)", head, re.I)
    return [p.strip().strip("'\"") for p in m.group(1).split(",") if p.strip()] if m else []


def _as_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(v) for v in value]
    text = str(value or "").strip()
    if not text:
        return []
    if text.startswith("["):
        try:
            return [str(v) for v in json.loads(text)]
        except ValueError:
            pass
    return [p.strip().strip("[]'\"") for p in text.split(",") if p.strip().strip("[]'\"")]


def parse_code_object(doc: dict) -> CodeObject | None:
    """The procedure / function a unit document holds: from a stored ``CREATE ... AS $$ code $$`` text, or from the
    body alone plus the extraction's parameters. None when the document has no definition text."""
    text = ct._sql_text(doc)
    if text is None:
        return None
    engine = str(doc.get("engine") or "")
    params = doc.get("params") or {}
    native = ct.parse_native_id(str(doc.get("asset_id") or ""))
    language = str(doc.get("language") or "").lower()
    kind = "procedure" if "procedure" in engine or engine.startswith("snowpark") else "function"
    m = _CREATE.match(text)
    if not m:                                                  # a body without its CREATE (INFORMATION_SCHEMA)
        body = sql_string(text) if text.lstrip().startswith(("$$", "'")) else text
        pairs = ct.signature_pairs(doc)
        returns = str(params.get("data_type") or "").upper()
        return CodeObject(
            kind, native["name"], language, body, [{"name": n, "type": t.upper(), "default": None} for n, t in pairs],
            returns, str(params.get("handler") or "") or None, str(params.get("runtime_version") or "") or None,
            _as_list(params.get("packages")), _as_list(params.get("imports")), False,
            str(params.get("execute_as") or "").upper(), returns.startswith("TABLE"), False, True,
            native["db"], native["schema"])
    kind = m.group(1).lower()
    open_at = m.end() - 1
    close = _matching(text, open_at)
    if close < 0:
        return None
    args = []
    for a in _split_top(text[open_at + 1:close]):
        am = re.match(r'\s*("(?:[^"]|"")+"|[\w$]+)\s+(.+?)(?:\s+DEFAULT\s+(.+))?$', a, re.I | re.S)
        if am:
            args.append({"name": am.group(1).strip('"'), "type": am.group(2).strip().upper(), "default": am.group(3)})
    rest = text[close + 1:]
    bm = None
    for mm in _BODY.finditer(rest):
        bm = mm
    if bm is None:
        return None                                            # a JAR handler has no inline body: no AS '...'
    head, body = rest[:bm.start()], sql_string(bm.group(1))
    rm = re.search(rf"\bRETURNS\s+(.+?)(?=\s+(?:{_PROP_STOP})\b|$)", head, re.I | re.S)
    lang = (re.search(r"\bLANGUAGE\s+(\w+)", head, re.I) or [None, language or "sql"])[1].lower()
    em = re.search(r"\bEXECUTE\s+AS\s+(OWNER|CALLER|RESTRICTED\s+CALLER)", head, re.I)
    returns = re.sub(r"\s+", " ", rm.group(1)).strip().upper() if rm else ""
    return CodeObject(
        kind, m.group(2).split(".")[-1].strip('"'), lang, body, args, returns, _prop(head, "HANDLER"),
        _prop(head, "RUNTIME_VERSION"), _listing(head, "PACKAGES"), _listing(head, "IMPORTS"),
        bool(re.search(r"\bSTRICT\b|\bRETURNS\s+NULL\s+ON\s+NULL\s+INPUT\b", head, re.I)),
        re.sub(r"\s+", " ", em.group(1)).upper() if em else "", returns.startswith("TABLE"),
        bool(re.search(r"\bEXTERNAL_ACCESS_INTEGRATIONS\b|\bSECRETS\b", head, re.I)), True,
        native["db"], native["schema"])


def packaging_reasons(doc: dict) -> list[str]:
    """Java / Scala (row 5.13): not translated; what a human needs to package it. Names only, never the code."""
    engine = str(doc.get("engine") or "")
    lang = "Scala" if "scala" in engine else "Java"
    kind = "procedure" if "procedure" in engine or engine.startswith("snowpark") else "function"
    text = ct._sql_text(doc) or ""
    head = text.split("$$", 1)[0]
    handler = _prop(head, "HANDLER") or str((doc.get("params") or {}).get("handler") or "") or "unknown"
    jars = _listing(head, "IMPORTS") or _as_list((doc.get("params") or {}).get("imports"))
    pkgs = _listing(head, "PACKAGES") or _as_list((doc.get("params") or {}).get("packages"))
    inline = "$$" in text or bool(re.search(r"\bAS\s+'", head, re.I))
    out = [f"{lang} {kind} (handler {handler}) is not translated: {lang} code is compiled, so it is packaged for a "
           "human (row 5.13)"]
    if jars:
        out.append(f"copy the staged JAR(s) {', '.join(jars)} to a Unity Catalog volume")
    if kind == "procedure":
        out.append("run it as a JAR task (spark_jar_task) in a Lakeflow job with the procedure's arguments as task "
                   "parameters, or rewrite it as a Python / SQL procedure")
    else:
        out.append("rewrite it as a SQL or Python function in Unity Catalog; a JVM UDF is available only through a "
                   "cluster library, not a SQL warehouse")
    if pkgs:
        out.append(f"declared packages to carry over as cluster libraries: {', '.join(pkgs)}")
    if inline:
        out.append(f"the {lang} source is inline in the definition: it can be given to the AI tier as a draft")
    return out


# --------------------------------------------------------------------------------------------------- SQL types
def db_type(type_text: str) -> str:
    """A Snowflake type as a Databricks type text (STRING when unknown, like the handlers)."""
    try:
        return exp.DataType.build(type_text, dialect="snowflake").sql("databricks")
    except (SqlglotError, ValueError):
        return "STRING"


def caster(sql_type: str) -> str:
    """The Python callable that turns a notebook widget string into the argument's type."""
    t = sql_type.upper()
    if re.match(r"(NUMBER|NUMERIC|DECIMAL)\s*\(\s*\d+\s*,\s*[1-9]", t) or t.startswith(("FLOAT", "DOUBLE", "REAL")):
        return "float"
    if t.startswith(("NUMBER", "NUMERIC", "DECIMAL", "INT", "BIGINT", "SMALLINT", "TINYINT", "BYTEINT")):
        return "int"
    if t.startswith("BOOLEAN"):
        return "_bool"
    if t.startswith("DATE"):
        return "datetime.date.fromisoformat"
    if t.startswith(("TIMESTAMP", "DATETIME")):
        return "datetime.datetime.fromisoformat"
    if t.startswith(("VARIANT", "OBJECT", "ARRAY")):
        return "json.loads"
    return "str"


__all__ = ["CodeNames", "CodeObject", "CodeRefused", "CodeServices", "ConverterUnavailable", "caster", "clean_reason",
           "db_type", "packaging_reasons", "parse_code_object", "sql_string"]
