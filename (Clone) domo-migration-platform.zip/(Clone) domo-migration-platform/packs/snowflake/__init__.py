"""The Snowflake source pack (ADR 032, Phase 3). Import ``packs.snowflake.pack.PACK``; this package does not
import it eagerly so a DOMO-only install pays nothing."""
