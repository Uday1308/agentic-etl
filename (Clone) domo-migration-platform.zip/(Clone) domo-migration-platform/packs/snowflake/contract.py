"""packs.snowflake.contract - the SQL node in the standardized contract (ADR 032 section 2, P3-07).

A Snowflake ETL is one object (view, dynamic table, task, procedure, UDF, pipe, recurring query). Its unit document
is the manifest row merged with the raw definition (``unit_doc``); ``to_standardized`` folds it into the same
``{id: {actions, connections, ...}}`` shape DOMO uses, so ``validate_standardized`` and ``to_planner_dataflow`` work
unchanged:

    source nodes  -> sql node(s) -> target nodes
                     {id, name, type: "sql", logic: {sql, source_dialect, engine, statement_index, language,
                      fq_name, signature, original_ddl_ref, params, state}}

A definition the extract could not read (secure view, procedure not owned by the extraction role) is ONE sql node
with ``logic = {"state": "unavailable", "reason": ...}``: never translated, a ``manual`` item (hard rule 6).
``signature`` is parsed from the canonical id (``proc/LOAD(VARCHAR,NUMBER)``), not a second identity component.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from packs.snowflake.scripting import extract_body, is_scripting, procedure_header, split_scripting

SOURCE_DIALECT = "snowflake"
HERE = Path(__file__).parent
SQL_KINDS = ("sql_view", "materialized_view", "dynamic_table", "task", "sql_procedure", "udf_sql", "query")


def load_engines() -> dict[str, dict]:
    return dict(yaml.safe_load((HERE / "engines.yaml").read_text(encoding="utf-8"))["engines"])


ENGINES: dict[str, dict] = load_engines()

#: raw partition column holding the definition text, per engine
_BODY_COLUMN = {"sql_view": "VIEW_DEFINITION", "materialized_view": "VIEW_DEFINITION", "dynamic_table": "text",
                "task": "DEFINITION", "snowpipe": "DEFINITION", "query": "QUERY_TEXT"}
_LANGUAGE = {"sql_view": "sql", "materialized_view": "sql", "dynamic_table": "sql", "task": "sql", "snowpipe": "sql",
             "sql_procedure": "sql", "udf_sql": "sql", "query": "sql", "javascript_procedure": "javascript",
             "snowpark_python": "python", "snowpark_java": "java", "snowpark_scala": "scala", "udf_js": "javascript",
             "udf_python": "python", "udf_java": "java", "udf_scala": "scala"}


def unavailable(reason: str) -> dict:
    return {"state": "unavailable", "reason": reason}


def is_unavailable(value: Any) -> bool:
    return isinstance(value, dict) and value.get("state") == "unavailable"


def parse_native_id(asset_id: str) -> dict:
    """``{db, schema, name, objtype, signature}`` from ``<account>.<db>.<schema>.[proc/|func/]<name>[(types)]``."""
    native = str(asset_id or "").split(":", 2)[-1]
    sig = ""
    m = re.search(r"\(([^()]*)\)$", native)
    if m:
        sig, native = m.group(1), native[:m.start()]
    parts = re.findall(r'"(?:[^"]|"")*"|[^.]+', native)
    parts = [p.strip('"') if p.startswith('"') else p for p in parts if p != "."]
    tail = parts[-1] if parts else ""
    objtype = tail.split("/")[0] if "/" in tail else ""
    name = tail.split("/")[-1]
    return {"db": parts[-3] if len(parts) >= 4 else "", "schema": parts[-2] if len(parts) >= 3 else "",
            "name": name, "objtype": objtype, "signature": sig}


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_") or "x"


def derived_target(catalog: str, db: str, schema: str, name: str) -> str:
    """The Databricks name of a procedure / function / task with no explicit name: ``catalog.<db>_<schema>.<name>``
    (one rule, shared by the object's own artifact and every call site)."""
    return f"{catalog or 'main'}.{slugify(f'{db}_{schema}') if db else 'default'}.{slugify(name)}"


def signature_of(asset_id: str) -> list[str] | None:
    sig = parse_native_id(asset_id)["signature"]
    return [s.strip() for s in sig.split(",") if s.strip()] if sig else None


def param_names(doc: dict) -> list[str]:
    """The procedure / function parameter names: the real ones when the extraction carried ``ARGUMENT_SIGNATURE``
    (``(P_MODE VARCHAR, P_LIMIT NUMBER(38,0))``), else ``argN`` over the types in the asset id."""
    sig = signature_of(str(doc.get("asset_id") or "")) or []
    named = str((doc.get("params") or {}).get("argument_signature") or "").strip()
    names: list[str] = []
    if named.startswith("(") and named.endswith(")"):
        parts, depth, cur = [], 0, ""
        for ch in named[1:-1]:
            depth += ch == "("
            depth -= ch == ")"
            if ch == "," and depth == 0:
                parts.append(cur)
                cur = ""
            else:
                cur += ch
        parts.append(cur)
        names = [p.strip().split(None, 1)[0] for p in parts if p.strip() and len(p.strip().split(None, 1)) == 2]
    if len(names) != len(sig):
        names = [f"arg{i + 1}" for i in range(len(sig))]
    return names


def signature_pairs(doc: dict) -> list[tuple[str, str]]:
    """``(name, Snowflake type)`` per parameter. Types and names come from the asset id and ``ARGUMENT_SIGNATURE``
    (``param_names``); when the extraction carried no names (``argN``), or no signature at all, from the
    ``(name TYPE, ...)`` list of the stored ``CREATE PROCEDURE`` text, so the body's own parameter names are used."""
    sig = signature_of(str(doc.get("asset_id") or "")) or []
    text = _sql_text(doc)
    header = list(procedure_header(text).get("params") or []) if text else []
    names = param_names(doc)
    if sig and not (header and len(header) == len(sig) and all(re.fullmatch(r"arg\d+", n) for n in names)):
        return list(zip(names, sig, strict=False))
    if sig:
        return [(h[0], s) for h, s in zip(header, sig, strict=False)]
    return header


def _rows(payload: dict) -> list[dict]:
    cols = [c["name"] for c in payload.get("rowType") or []]
    return [dict(zip(cols, r, strict=False)) for r in payload.get("data") or []]


_NOT_OBJECT_NAME = {"DATABASE_NAME", "SCHEMA_NAME", "WAREHOUSE_NAME", "OWNER_NAME", "CATALOG_NAME"}


def _row_identity(r: dict) -> tuple[str, str, str]:
    """``(db, schema, name)`` of a raw row by column convention: ``DATABASE_NAME`` / ``SCHEMA_NAME`` / ``NAME`` (tasks,
    dynamic tables) or ``*_CATALOG`` / ``*_SCHEMA`` / ``*_NAME`` (information schema)."""
    up = {str(k).upper(): str(v or "") for k, v in r.items()}
    db = up.get("DATABASE_NAME") or next((v for k, v in up.items() if k.endswith("_CATALOG")), "")
    schema = up.get("SCHEMA_NAME") or next((v for k, v in up.items() if k.endswith("_SCHEMA")), "")
    name = up.get("NAME") or next((v for k, v in up.items() if k.endswith("_NAME") and k not in _NOT_OBJECT_NAME
                                   and not k.startswith("OWNER")), "")
    return db, schema, name


def _types_of_signature(text: str) -> list[str]:
    """``(P_MODE VARCHAR, P_LIMIT NUMBER(38,2))`` -> ``["VARCHAR", "NUMBER(38,2)"]`` (a bare type list works too)."""
    inner = text.strip()
    if inner.startswith("(") and inner.endswith(")"):
        inner = inner[1:-1]
    parts, depth, cur = [], 0, ""
    for ch in inner:
        depth += ch == "("
        depth -= ch == ")"
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    out = []
    for p in parts:
        toks = p.strip().split(None, 1)
        out.append((toks[1] if len(toks) > 1 else toks[0]).strip().upper().replace(" ", ""))
    return out


def pick_row(payload: dict, etl_id: str) -> dict | None:
    """The row of a raw SQL API partition that describes ``etl_id``: by database / schema / name columns (and the
    argument signature when the id carries one, so overloads do not collapse), else by an id column, else the only
    row."""
    rows = _rows(payload)
    native = str(etl_id).split(":", 2)[-1]
    want = parse_native_id(native)
    hits = []
    for r in rows:
        db, schema, name = _row_identity(r)
        if (want["name"] and name.upper() == want["name"].upper() and schema.upper() == want["schema"].upper()
                and (db or want["db"]).upper() == want["db"].upper()):
            hits.append(r)
    if len(hits) > 1 and native.endswith(")"):
        wt = [t.upper().replace(" ", "") for t in _types_of_signature(want["signature"])]
        exact = [r for r in hits if "ARGUMENT_SIGNATURE" in {str(k).upper() for k in r}
                 and _types_of_signature(str(next(v for k, v in r.items() if str(k).upper() == "ARGUMENT_SIGNATURE")
                                                 or "()")) == wt]
        hits = exact or hits
    if hits:
        return hits[0]
    for r in rows:
        for k, v in r.items():
            if k.upper().endswith("_ID") and v and (str(v) == native or native.endswith(str(v))):
                return r
    return rows[0] if len(rows) == 1 else None


def unit_doc(row: dict, payload: Any) -> dict:
    """The manifest ETL row merged with its raw definition (a SQL API partition, or an already merged document)."""
    engine = str(row.get("engine") or "")
    doc: dict[str, Any] = {"etl_id": str(row.get("etl_id") or ""), "asset_id": row.get("asset_id"),
                           "name": row.get("name") or "", "engine": engine, "inputs": list(row.get("inputs") or []),
                           "outputs": list(row.get("outputs") or []), "params": {}, "language": _LANGUAGE.get(engine)}
    if isinstance(payload, dict) and "rowType" in payload:
        r = pick_row(payload, doc["etl_id"] or str(row.get("asset_id") or ""))
        col = _BODY_COLUMN.get(engine) or next((k for k in (r or {}) if k.upper().endswith("_DEFINITION")), "")
        if engine in ("sql_procedure", "javascript_procedure", "snowpark_python", "snowpark_java", "snowpark_scala"):
            col = "PROCEDURE_DEFINITION"
        elif engine.startswith("udf_"):
            col = "FUNCTION_DEFINITION"
        body = (r or {}).get(col)
        doc["definition"] = body if body else unavailable("definition not readable by the extraction role"
                                                          if r is not None else "no matching row in the raw record")
        if r:
            doc["params"] = {k.lower(): v for k, v in r.items()
                             if k.upper() in ("TARGET_LAG", "REFRESH_MODE", "SCHEDULE", "PREDECESSORS", "STATE",
                                              "CONDITION_TEXT", "IS_SECURE", "PROCEDURE_LANGUAGE", "DATA_TYPE",
                                              "ARGUMENT_SIGNATURE", "EXECUTE_AS", "FUNCTION_LANGUAGE", "TASK_RELATIONS",
                                              "ROOT_TASK_ID", "HANDLER", "RUNTIME_VERSION", "PACKAGES", "IMPORTS")}
            doc["params"]["secure"] = str(r.get("IS_SECURE") or "").lower() in ("true", "yes")
    elif isinstance(payload, dict):
        doc.update({k: v for k, v in payload.items() if k not in ("etl_id",)})
    elif isinstance(payload, str):
        doc["definition"] = payload
    doc.setdefault("definition", unavailable("no definition in the bundle"))
    return doc


def _sql_text(doc: dict) -> str | None:
    d = doc.get("definition")
    if d is None and doc.get("sql") is not None:
        d = doc["sql"]
    if is_unavailable(d) or not isinstance(d, str) or not d.strip():
        return None
    return d


_CREATE_AS = re.compile(r"^\s*create\b.*?\bas\b\s*(?=\S)", re.I | re.S)


def query_of_definition(engine: str, text: str) -> str:
    """The query/body inside a stored definition: ``CREATE VIEW v AS <q>`` -> ``<q>``; a procedure keeps its body."""
    if "$$" in text:
        return extract_body(text).strip()
    if re.match(r"\s*create\b", text, re.I):
        if engine in ("sql_procedure", "udf_sql"):
            return extract_body(text).strip()
        m = _CREATE_AS.match(text)
        return text[m.end():].strip().rstrip(";") if m else text
    return text.strip().rstrip(";")


def node_units(doc: dict) -> list[dict]:
    """The SQL nodes' logic dicts for a unit document, in statement order (one for most engines; a Scripting
    procedure is split by the block-aware splitter)."""
    engine, fq = str(doc.get("engine") or ""), str(doc.get("fq_name") or doc.get("asset_id") or doc.get("name") or "")
    common = {"source_dialect": SOURCE_DIALECT, "engine": engine, "language": doc.get("language") or _LANGUAGE.get(engine),  # noqa: E501
              "fq_name": fq, "signature": signature_of(str(doc.get("asset_id") or "")),
              "original_ddl_ref": doc.get("original_ddl_ref") or unavailable("no original DDL reference"),
              "params": dict(doc.get("params") or {}), "state": "derived"}
    text = _sql_text(doc)
    if text is None:
        reason = (doc.get("definition") or {}).get("reason") if is_unavailable(doc.get("definition")) else "empty"
        return [{**common, **unavailable(str(reason or "definition unavailable")), "sql": None, "statement_index": 0}]
    body = query_of_definition(engine, text)
    if engine == "sql_procedure" and (is_scripting(body) or ";" in body):
        out = []
        nodes = split_scripting(body)
        dropped = ""
        if (len(nodes) > 1 and nodes[-1].kind == "script"
                and re.match(r"RETURN\b", nodes[-1].text.strip(), re.I)):
            dropped = nodes[-1].text.strip()      # a status value: Databricks procedures return none (reviewed)
            nodes = nodes[:-1]
            common = {**common, "params": {**common["params"], "dropped_return": dropped}}
        for n in nodes:
            params = {**common["params"], **({"unparsed": True, "children": n.children, "block": n.opener}
                                             if n.unparsed else {})}
            out.append({**common, "sql": n.text, "statement_index": n.statement_index, "params": params,
                        "node_kind": n.kind})
        return out or [{**common, "sql": body, "statement_index": 0}]
    return [{**common, "sql": body, "statement_index": 0}]


def to_standardized(doc: Any, dataflow_id: str = "") -> dict:
    if not isinstance(doc, dict) or not doc.get("engine"):
        raise ValueError("a Snowflake unit document needs an 'engine' (see packs.snowflake.contract.unit_doc)")
    engine = doc["engine"]
    if engine not in ENGINES:
        raise ValueError(f"unknown Snowflake engine {engine!r}")
    uid = str(dataflow_id or doc.get("etl_id") or doc.get("asset_id") or "")
    actions: list[dict] = []
    connections: list[dict] = []
    for i, inp in enumerate(doc.get("inputs") or []):
        actions.append({"id": f"in{i}", "name": inp.get("name") or inp.get("dataset_id") or f"in{i}", "type": "source",
                        "logic": {"dataset_id": inp.get("dataset_id"), "fq_name": inp.get("fq_name") or inp.get("name"),
                                  "table": inp.get("table"), "availability": inp.get("availability"),
                                  "dataset_name": inp.get("name")}})
    first_sql = len(actions)
    for k, logic in enumerate(node_units(doc)):
        actions.append({"id": f"sql{k}", "name": f"{doc.get('name') or uid} #{k}", "type": "sql", "logic": logic})
    sql_ids = [a["id"] for a in actions[first_sql:]]
    for a in actions[:first_sql]:
        connections.append({"from": a["id"], "to": sql_ids[0]})
    connections += [{"from": a, "to": b} for a, b in zip(sql_ids, sql_ids[1:], strict=False)]
    outputs = []
    for j, out in enumerate(doc.get("outputs") or []):
        tid = f"out{j}"
        actions.append({"id": tid, "name": out.get("name") or tid, "type": "target",
                        "logic": {"dataset_id": out.get("dataset_id"), "fq_name": out.get("fq_name") or out.get("name"),
                                  "table": out.get("table"), "dataset_name": out.get("name")}})
        connections.append({"from": sql_ids[-1], "to": tid})
        outputs.append({"dataset_id": out.get("dataset_id"), "fq_name": out.get("fq_name") or out.get("name"),
                        "table": out.get("table"), "dataSourceName": out.get("name")})
    return {uid: {"id": uid, "name": doc.get("name") or "", "database_type": "SNOWFLAKE", "engine": engine,
                  "actions": actions, "connections": connections, "outputs": outputs}}


def is_raw_export(doc: Any) -> bool:
    return isinstance(doc, dict) and (doc.get("engine") in ENGINES or "rowType" in doc)


class SnowflakeContract:
    dropped_keys: frozenset = frozenset()

    @staticmethod
    def is_raw_export(doc: Any) -> bool:
        return is_raw_export(doc)

    @staticmethod
    def to_standardized(doc: Any, dataflow_id: str = "") -> dict:
        return to_standardized(doc, dataflow_id)


__all__ = ["ENGINES", "SQL_KINDS", "SnowflakeContract", "is_raw_export", "is_unavailable", "load_engines",
           "node_units", "param_names", "parse_native_id", "pick_row", "signature_of", "signature_pairs",
           "to_standardized", "unavailable", "unit_doc"]
