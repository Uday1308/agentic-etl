"""packs.snowflake.benchmark - the conversion benchmark runner (S15, ADR 037 section 7).

The corpus (``tests/fixtures/snowflake/conversion/corpus_*.yaml``) holds at least one case per catalogue row of
section 1 and a representative subset of sections 2-6. Each case is run through the REAL tier 0 (``translate_etl``
with the human tier only: no Lakebridge, no model, hard rule 10), then scored against what the catalogue says the
engine should do:

    deterministic_rate  of the rule / pattern cases, how many tier 0 (or a deterministic handler route) resolves
    residue_clean_rate  of the resolved outputs, how many contain no Snowflake-only construct (residue guard)
    flag_correct_rate   of the flag / not_migrated / ai cases, how many are NOT converted silently (escalated, routed
                        to a handler that reports them, or resolved with a review caveat)
    silent_safe_rate    of the silent (data-changing) rows, how many are either flagged or already emit the expected
                        SQL: the share that cannot return different numbers without anybody being told
    sql_match_rate      of the cases with an expected Databricks text, how many match it after normalization

``expected`` texts and the data sets of the silent rows are hand-written specifications, unverified until the X5 data
tests run them (docs/plans/snowflake-conversion-catalogue.md section 7). The gate file holds the CURRENT baseline
(metric >= threshold, per section and overall); raise a threshold in the same change that makes the engine better.
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import logging
import pathlib
import re
import sys
from dataclasses import dataclass, field
from typing import Any

import sqlglot
import yaml
from sqlglot import exp
from sqlglot.errors import SqlglotError

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import residue as rsd
from packs.snowflake import translate as tr
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.handlers import ROUTE_FILE_LOAD, ROUTE_UNSUPPORTED, route_of
from packs.snowflake.scripting_convert import table_refs

CLASSES = ("rule", "pattern", "flag", "ai", "not_migrated")
DETERMINISTIC_CLASSES = ("rule", "pattern")
FLAGGED_CLASSES = ("flag", "ai", "not_migrated")
SECTIONS = ("1", "2", "3", "4", "5", "6")
METRICS = ("deterministic_rate", "residue_clean_rate", "flag_correct_rate", "silent_safe_rate", "sql_match_rate")
DEFAULT_DIR = pathlib.Path(__file__).resolve().parents[4] / "tests" / "fixtures" / "snowflake" / "conversion"
_NOT_INFORMATIVE = re.compile(r"^(always_review:|SNW-NAME-RESOLUTION$)")
_DB, _SCHEMA = "BENCH", "PUBLIC"
logging.getLogger("sqlglot").setLevel(logging.CRITICAL)      # it echoes unparsable text (hard rule 11)


@dataclass
class Case:
    id: str
    row: str
    title: str
    cls: str
    input: str
    engine: str | None = "sql_view"
    sql: str | None = None
    silent: bool = False
    context: dict = field(default_factory=dict)
    prelude: str | None = None
    data: dict | None = None
    source: str = ""
    #: a reason when the converted SQL cannot run faithfully on DuckDB (X5: such a case runs on Databricks only)
    live_only: str | None = None

    @property
    def section(self) -> str:
        return self.row.split(".")[0]


@dataclass
class Outcome:
    case: Case
    observed: str                    # mapped | escalated | routed | unrouted | error
    sql: str = ""
    review: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    residue: list[str] = field(default_factory=list)
    sql_match: bool | None = None

    @property
    def flagged(self) -> bool:
        """Not converted silently: someone is told (escalation, an unsupported / unmodelled route, a review caveat)."""
        if self.observed == "mapped":
            return bool(self.review)
        return self.observed in ("escalated", "unrouted", "error") or bool(self.review)

    @property
    def deterministic(self) -> bool:
        return self.observed == "mapped" or self.observed == "routed" and not self.reasons

    @property
    def silent_safe(self) -> bool:
        return self.flagged or self.sql_match is True


# ------------------------------------------------------------------------------------------------ corpus
#: cases the last ``load_corpus`` left out because a module they ``requires:`` is not installed (the JavaScript
#: converter needs esprima): reported, never counted, so a missing optional dependency fails no gate and hides nothing
SKIPPED: list[str] = []


def load_corpus(root: pathlib.Path | str | None = None) -> list[Case]:
    base = pathlib.Path(root) if root else DEFAULT_DIR
    cases: list[Case] = []
    SKIPPED.clear()
    for path in sorted(base.glob("corpus_*.yaml")):
        for raw in yaml.safe_load(path.read_text(encoding="utf-8"))["cases"]:
            missing = [m for m in raw.get("requires") or [] if importlib.util.find_spec(str(m)) is None]
            if missing:
                SKIPPED.append(f"{raw['id']} (needs {', '.join(missing)})")
                continue
            cases.append(Case(id=str(raw["id"]), row=str(raw["row"]), title=str(raw["title"]), cls=str(raw["class"]),
                              input=str(raw["input"]), engine=raw["engine"] if "engine" in raw else "sql_view",
                              sql=raw.get("sql"), silent=str(raw["row"]).startswith("1."),
                              context=dict(raw.get("context") or {}),
                              prelude=raw.get("prelude"), data=raw.get("data"), source=path.name,
                              live_only=raw.get("live_only")))
    return cases


def validate_corpus(cases: list[Case]) -> list[str]:
    """Structural problems of the corpus (a gate: the corpus itself must stay well-formed)."""
    problems: list[str] = []
    ids = [c.id for c in cases]
    problems += [f"duplicate case id {i}" for i in sorted({i for i in ids if ids.count(i) > 1})]
    for c in cases:
        if c.cls not in CLASSES:
            problems.append(f"{c.id}: class {c.cls!r} is not one of {CLASSES}")
        if c.section not in SECTIONS:
            problems.append(f"{c.id}: row {c.row!r} is not in a catalogue section 1-6")
        if not c.input.strip():
            problems.append(f"{c.id}: empty input")
        if c.silent:
            d = c.data
            if not isinstance(d, dict) or "tables" not in d or "expect" not in d:
                problems.append(f"{c.id}: a silent row needs data {{tables, expect}} (expect: null + note when the "
                                "result is not reproducible outside Snowflake)")
                continue
            if d["expect"] is None and not d.get("note"):
                problems.append(f"{c.id}: expect is null without a note saying why")
            for name, t in (d.get("tables") or {}).items():
                width = len(t.get("columns") or [])
                if not width or any(len(r) != width for r in t.get("rows") or []):
                    problems.append(f"{c.id}: table {name} has rows that do not match its columns")
            if d["expect"] is not None and not all(isinstance(r, list) for r in d["expect"]):
                problems.append(f"{c.id}: expect must be a list of rows")
    return problems


# ------------------------------------------------------------------------------------------------ running
def _tables_of(sql: str) -> list[tuple[str, str, str]]:
    try:
        trees = [t for t in sqlglot.parse(sql, read="snowflake") if t is not None]
    except SqlglotError:
        trees = []
    out: set[tuple[str, str, str]] = set()
    for tree in trees:
        ctes = {str(c.alias).upper() for c in tree.find_all(exp.CTE)}
        for t in tree.find_all(exp.Table):
            if t.name and isinstance(t.this, exp.Identifier) and t.name.upper() not in ctes:
                out.add(((t.catalog or _DB).upper(), (t.db or _SCHEMA).upper(), t.name.upper()))
    if "$$" in sql or not out:          # a procedure body is not one parsable statement: read its table names too
        for parts in table_refs(sql):
            full = [_DB, _SCHEMA, *parts][-3:] if len(parts) < 3 else parts
            out.add((full[0].upper(), full[1].upper(), full[2].upper()))
    return sorted(out)


def _context_of(case: Case) -> ConversionContext:
    ctx = case.context or {}
    params = {k: {"state": "provided", "value": str(v), "level": "account"}
              for k, v in (ctx.get("parameters") or {}).items()}
    return ConversionContext.build(source_parameters=params, catalogue=ctx.get("columns"),
                                   capability_profile=ctx.get("capability"), pivot_values=ctx.get("pivot_values"),
                                   profiles=ctx.get("profiles"), source_objects=ctx.get("source_objects"))


def _definition(case: Case) -> str:
    text = case.input.strip()
    if case.engine == "sql_view" and not re.match(r"\s*CREATE\b", text, re.I):
        return f"CREATE VIEW {_DB}.{_SCHEMA}.V AS\n{text}"
    return text


def _unit_context(case: Case, engine: str, table_map: dict) -> tr.UnitContext:
    """The tier-0 context of a case: the context's columns / parameters / capability, and ``stream_tables``
    (stream name -> target base table) and ``stream_types`` (name -> {append_only, ...}) for the stream rules."""
    c = case.context or {}
    return tr.make_context(etl_key="bench", engine=engine, table_map=table_map, default_db=_DB, default_schema=_SCHEMA,
                           settings=TranslationSettings(tiers=("human",)), conversion=_context_of(case),
                           stream_tables={k.upper(): v for k, v in (c.get("stream_tables") or {}).items()},
                           stream_types={k.upper(): dict(v) for k, v in (c.get("stream_types") or {}).items()},
                           dynamic_shim=str(c.get("dynamic_sql_shim") or ""))


def run_object_case(case: Case) -> Outcome:
    """An object kind the pack converts outside the ETL units (``engine: object:<kind>``: sequence, external_table,
    alert, stream; ``objects.py``)."""
    from packs.snowflake import objects as ob
    kind = str(case.engine).split(":", 1)[1]
    table_map = {k: f"main.{k[1].lower()}.{k[2].lower()}".replace("main.public.", "main.bench_public.")
                 for k in _tables_of(case.input)}
    ctx = _unit_context(case, "sql_view", table_map)
    c = case.context or {}
    try:
        res = ob.convert_object(kind, case.input.strip(), ctx=ctx, stage_urls=c.get("stage_urls"), usages=c.get("usages"),  # noqa: E501
                                convert_query=ob.tier0_query_converter(ctx))
    except Exception as exc:                                   # a crash is a result, not a stop
        return Outcome(case, "error", reasons=[f"{type(exc).__name__}: {str(exc)[:160]}"])
    review = [x for x in res.review if not _NOT_INFORMATIVE.match(x)]
    if res.status == "converted":
        out = Outcome(case, "mapped", sql=res.text, review=review, caveats=list(res.caveats))
        out.residue = rsd.scan(res.text, ctx.conversion.capabilities).tokens if res.text else []
        if case.sql:
            out.sql_match = sql_equal(res.text, case.sql)
        return out
    out = Outcome(case, "escalated", review=review, caveats=list(res.caveats), reasons=list(res.reasons))
    if case.sql:
        out.sql_match = False
    return out


def run_case(case: Case) -> Outcome:
    if case.engine is None:
        return Outcome(case, "unrouted", reasons=["no translate route for this object kind in the pack today"])
    if case.engine.startswith("object:"):
        return run_object_case(case)
    row = {"engine": case.engine, "etl_id": case.id}
    route, why = route_of(row)
    if route == ROUTE_UNSUPPORTED:
        return Outcome(case, "routed", reasons=[why], review=["unsupported"])
    if route == ROUTE_FILE_LOAD:
        return Outcome(case, "routed")          # the file_load unit builds it deterministically
    doc = {"etl_id": case.id, "asset_id": f"bench:view:acme.{_DB}.{_SCHEMA}.OBJ", "engine": case.engine,
           "name": case.id, "definition": _definition(case), "params": {}}
    table_map = {k: f"main.{k[1].lower()}.{k[2].lower()}".replace("main.public.", "main.bench_public.")
                 for k in _tables_of(case.input)}
    for v in ((case.context or {}).get("stream_tables") or {}).values():      # a stream's base table is a target name
        table_map[(_DB, _SCHEMA, str(v).split(".")[-1].upper())] = str(v)
    ctx = _unit_context(case, case.engine, table_map)
    try:
        units = asyncio.run(tr.translate_etl(doc, ctx))
        # a procedure the scripting converter cannot take stays one unit per statement: score the one that is NOT
        # converted (the first unit alone would hide the flag)
        unit = next((u for u in units if u.status != "resolved" or u.origin != "mapped"), units[0])
    except Exception as exc:                                   # a crash is a result, not a stop
        return Outcome(case, "error", reasons=[f"{type(exc).__name__}: {str(exc)[:160]}"])
    informative = [c for c in unit.review_caveats if not _NOT_INFORMATIVE.match(c)]
    if unit.status == "resolved" and unit.origin == "mapped":
        out = Outcome(case, "mapped", sql=unit.sql, review=informative, caveats=list(unit.caveats))
        out.residue = rsd.scan(unit.sql, ctx.conversion.capabilities).tokens
        if case.sql:
            out.sql_match = sql_equal(unit.sql, case.sql)
        return out
    out = Outcome(case, "escalated", sql=unit.suggested_code, review=informative, caveats=list(unit.caveats),
                  reasons=list(unit.reasons))
    out.residue = [r for r in unit.caveats if r == rsd.RESIDUE_CAVEAT]
    if case.sql:
        out.sql_match = False                                   # escalated: the expected text was not produced
    return out


# ------------------------------------------------------------------------------------------------ comparison
def normalize_sql(sql: str) -> str:
    """Databricks text -> a canonical form: parsed, unquoted identifiers lower-cased, table qualifiers dropped (the
    benchmark maps names to a synthetic catalogue), formatted by sqlglot. Falls back to collapsed lower case."""
    try:
        tree = sqlglot.parse_one(sql, read="databricks")
    except SqlglotError:
        return re.sub(r"\s+", " ", sql.strip().rstrip(";")).lower()
    for ident in tree.find_all(exp.Identifier):
        if not ident.args.get("quoted"):
            ident.set("this", str(ident.this).lower())
    for t in tree.find_all(exp.Table):
        t.set("catalog", None)
        t.set("db", None)
    return tree.sql(dialect="databricks")


def sql_equal(actual: str, expected: str) -> bool:
    return normalize_sql(actual) == normalize_sql(expected)


# ------------------------------------------------------------------------------------------------ metrics
def _rate(num: int, den: int) -> float | None:
    return None if den == 0 else round(num / den, 4)


def metrics_of(outcomes: list[Outcome]) -> dict[str, Any]:
    ruleish = [o for o in outcomes if o.case.cls in DETERMINISTIC_CLASSES]
    resolved = [o for o in outcomes if o.observed == "mapped"]
    flaggable = [o for o in outcomes if o.case.cls in FLAGGED_CLASSES]
    silent = [o for o in outcomes if o.case.silent]
    with_sql = [o for o in outcomes if o.case.sql]
    return {
        "cases": len(outcomes), "silent_cases": len(silent),
        "deterministic_rate": _rate(sum(o.deterministic for o in ruleish), len(ruleish)),
        "residue_clean_rate": _rate(sum(not o.residue for o in resolved), len(resolved)),
        "flag_correct_rate": _rate(sum(o.flagged for o in flaggable), len(flaggable)),
        "silent_safe_rate": _rate(sum(o.silent_safe for o in silent), len(silent)),
        "sql_match_rate": _rate(sum(o.sql_match is True for o in with_sql), len(with_sql)),
        "denominators": {"deterministic_rate": len(ruleish), "residue_clean_rate": len(resolved),
                         "flag_correct_rate": len(flaggable), "silent_safe_rate": len(silent),
                         "sql_match_rate": len(with_sql)},
    }


def run_all(cases: list[Case] | None = None) -> list[Outcome]:
    return [run_case(c) for c in (cases if cases is not None else load_corpus())]


def evaluate(outcomes: list[Outcome]) -> dict[str, Any]:
    return {"overall": metrics_of(outcomes),
            "sections": {s: metrics_of([o for o in outcomes if o.case.section == s]) for s in SECTIONS
                         if any(o.case.section == s for o in outcomes)}}


# ------------------------------------------------------------------------------------------------ gates
def load_gates(root: pathlib.Path | str | None = None) -> dict[str, Any]:
    base = pathlib.Path(root) if root else DEFAULT_DIR
    return dict(yaml.safe_load((base / "gates.yaml").read_text(encoding="utf-8")))


def check_gates(result: dict[str, Any], gates: dict[str, Any]) -> list[str]:
    """Failures (empty = pass). A threshold is ``metric >= value``; a metric with no cases is skipped."""
    fails: list[str] = []

    def check(scope: str, m: dict[str, Any], limits: dict[str, float]) -> None:
        for name, floor in limits.items():
            got = m.get(name)
            if got is not None and got + 1e-9 < float(floor):
                fails.append(f"{scope}: {name} {got:.4f} < {float(floor):.4f}")

    check("overall", result["overall"], gates.get("overall") or {})
    for sec, limits in (gates.get("sections") or {}).items():
        if str(sec) in result["sections"]:
            check(f"section {sec}", result["sections"][str(sec)], limits)
    if "min_cases" in gates and result["overall"]["cases"] < int(gates["min_cases"]):
        fails.append(f"corpus shrank: {result['overall']['cases']} < {gates['min_cases']} cases")
    return fails


# ------------------------------------------------------------------------------------------------ report
def _pct(v: float | None) -> str:
    return "n/a" if v is None else f"{v * 100:.1f}%"


def report_markdown(result: dict[str, Any], outcomes: list[Outcome], gate_failures: list[str] | None = None) -> str:
    titles = {"deterministic_rate": "deterministic", "residue_clean_rate": "residue-clean",
              "flag_correct_rate": "correctly flagged", "silent_safe_rate": "silent-safe",
              "sql_match_rate": "SQL match"}
    lines = ["# Snowflake conversion benchmark", "",
             f"Cases: {result['overall']['cases']} ({result['overall']['silent_cases']} silent). Tier 0 only (no "
             "Lakebridge, no model).", "",
             "| scope | cases | " + " | ".join(titles.values()) + " |", "|---|---|" + "---|" * len(titles)]
    rows = [("overall", result["overall"])] + [(f"section {s}", m) for s, m in result["sections"].items()]
    for name, m in rows:
        lines.append(f"| {name} | {m['cases']} | " + " | ".join(_pct(m[k]) for k in titles) + " |")
    lines += ["", "## Not yet handled deterministically", ""]
    for o in outcomes:
        if o.case.cls in DETERMINISTIC_CLASSES and not o.deterministic:
            lines.append(f"- `{o.case.id}` ({o.observed}): {o.case.title}")
    lines += ["", "## Silent rows that would convert without anyone being told", ""]
    unsafe = [o for o in outcomes if o.case.silent and not o.silent_safe]
    lines += [f"- `{o.case.id}`: {o.case.title}" for o in unsafe] or ["- none"]
    if SKIPPED:
        lines += ["", "## Skipped (a required module is not installed)", ""] + [f"- `{x}`" for x in SKIPPED]
    if gate_failures is not None:
        lines += ["", "## Gates", ""] + ([f"- FAIL {f}" for f in gate_failures] or ["- all gates pass"])
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run the Snowflake conversion benchmark (S15).")
    ap.add_argument("--corpus", default=str(DEFAULT_DIR))
    ap.add_argument("--report", help="write the Markdown report here")
    ap.add_argument("--json", help="write the metrics JSON here")
    ap.add_argument("--gate", action="store_true", help="exit 1 when a gate in gates.yaml fails")
    args = ap.parse_args(argv)
    cases = load_corpus(args.corpus)
    bad = validate_corpus(cases)
    if bad:
        print("\n".join(bad), file=sys.stderr)
        return 2
    outcomes = run_all(cases)
    result = evaluate(outcomes)
    fails = check_gates(result, load_gates(args.corpus)) if args.gate else None
    text = report_markdown(result, outcomes, fails)
    if args.report:
        pathlib.Path(args.report).write_text(text, encoding="utf-8")
    else:
        print(text)
    if args.json:
        pathlib.Path(args.json).write_text(json.dumps(result, indent=1), encoding="utf-8")
    return 1 if fails else 0


__all__ = ["Case", "Outcome", "check_gates", "evaluate", "load_corpus", "load_gates", "metrics_of", "normalize_sql",
           "report_markdown", "run_all", "run_case", "sql_equal", "validate_corpus"]


if __name__ == "__main__":
    raise SystemExit(main())
