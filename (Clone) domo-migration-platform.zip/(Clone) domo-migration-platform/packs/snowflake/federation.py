"""packs.snowflake.federation - X8: Lakehouse Federation fallback (catalogue row X8, ADR 037).

An object the engine cannot convert (a construct without a rule, a refused procedure) must not block a wave. Routed
``federated`` it is queried IN PLACE: a view in the target catalog selects from the foreign catalog that Lakehouse
Federation exposes over the Snowflake account (``<foreign_catalog>.<schema>.<name>``). Nothing is migrated: the data
stays in Snowflake, every read costs a Snowflake query, and the object is reported under its own route so the cutover
plan counts it. Only relations (tables, views, dynamic tables, materialized views) can federate; a callable (procedure,
UDF, task) cannot, and is ``unsupported`` with that reason.

Opt in per ETL row (``disposition: federate`` or ``route: federated``) and name the foreign catalog in the manifest
(``target.federation_catalog``) or ``MIGRATOR_FEDERATION_CATALOG``. Without a catalog name the artifact is a placeholder
that says so (never a guessed name).
"""
from __future__ import annotations

import os
from typing import Any

from packs.snowflake import contract as ct

ROUTE_FEDERATED = "federated"
RELATION_ENGINES = frozenset({"sql_view", "materialized_view", "dynamic_table", "view", "table"})
REASON = ("routed federated: queried in place through the Lakehouse Federation foreign catalog; the data stays in "
          "Snowflake (every read runs a Snowflake query) and the object is not migrated")


def wants_federation(row: dict) -> bool:
    return str(row.get("disposition") or "").lower() == "federate" or str(row.get("route") or "") == ROUTE_FEDERATED


def foreign_catalog(manifest_target: dict | None = None) -> str:
    return str((manifest_target or {}).get("federation_catalog") or os.environ.get("MIGRATOR_FEDERATION_CATALOG") or "")


def federated_view(doc: dict, target: str, catalog: str) -> dict[str, Any]:
    """``{status, text, review, reasons}``: the view that reads the foreign table, or why it cannot be built."""
    engine = str(doc.get("engine") or "")
    if engine not in RELATION_ENGINES:
        return {"status": "unsupported", "text": "", "review": [],
                "reasons": [f"engine {engine!r} is a callable or a job: only relations can be queried in place"]}
    p = ct.parse_native_id(str(doc.get("asset_id") or ""))
    if not (p["schema"] and p["name"]):
        return {"status": "unsupported", "text": "", "review": [],
                "reasons": ["the object's schema and name are not in its asset id: nothing to federate"]}
    fc = catalog or "<foreign_catalog>"
    text = f"CREATE OR REPLACE VIEW {target} AS SELECT * FROM {fc}.{p['schema'].lower()}.{p['name'].lower()}"
    reasons = [REASON] + ([] if catalog else ["set target.federation_catalog (or MIGRATOR_FEDERATION_CATALOG) to the "
                                              "foreign catalog name: the text holds a placeholder"])
    return {"status": "awaiting_review", "text": text, "review": ["SNW-FEDERATED"], "reasons": reasons}


__all__ = ["REASON", "ROUTE_FEDERATED", "federated_view", "foreign_catalog", "wants_federation"]
