"""packs.snowflake.validators - per-artifact-kind validators and the column check (ADR 032 sections 2-3, P3-08).

``validate(kind, text)`` returns a list of problems (empty = valid). Kinds: ``cte_chain``, ``statement``, ``script``,
``pipeline``, ``job``, ``python``, ``file_load``, ``governance``. Databricks features marked dagger in the ADR
(``CREATE PROCEDURE``, ``AUTO CDC``, table-update triggers, ABAC) are accepted here and carry a ``review`` reason at
the handler, never a silent pass.

The column check is offline first: ``column_check(sql, catalogue)`` where ``catalogue`` is
``{"cat.schema.table": {column: type}}`` from ONE ``information_schema.columns`` query per batch
(``packs.snowflake.columns``) or the bundle's source ``columns`` records. It reports ``ok`` / ``failed`` /
``unverifiable`` - never a vacuous pass.
"""
from __future__ import annotations

import ast
import json
import re
from dataclasses import dataclass, field

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.optimizer.qualify import qualify

from packs.snowflake.scripting import extract_body, split_scripting

DB = "databricks"
_READ_TYPES = (exp.Select, exp.Union, exp.Subquery)
_STATEMENT_TYPES = (exp.Merge, exp.Insert, exp.Update, exp.Delete, exp.TruncateTable)
_FORBIDDEN_IMPORTS = {"subprocess", "socket", "requests", "urllib", "http", "ftplib", "smtplib", "os", "shutil"}
_JOB_RUN_IF = {"ALL_SUCCESS", "ALL_DONE", "AT_LEAST_ONE_SUCCESS", "NONE_FAILED", "AT_LEAST_ONE_FAILED", "ALL_FAILED"}
_FILE_LOAD = (re.compile(r"^\s*COPY\s+INTO\s+\S+\s+FROM\s+'[^']+'.*\bFILEFORMAT\s*=", re.I | re.S),
              re.compile(r"^\s*CREATE\s+OR\s+REFRESH\s+STREAMING\s+TABLE\s+\S+.*\bAS\s+SELECT\b.*"
                         r"\bFROM\s+STREAM\s+read_files\s*\(\s*'[^']+'", re.I | re.S))
_PIPELINE = re.compile(r"^\s*CREATE\s+OR\s+(?:REFRESH|REPLACE)\s+(?:STREAMING\s+TABLE|MATERIALIZED\s+VIEW)\s+"
                       r"(?P<name>[\w.`-]+)(?P<mid>.*?)\bAS\b\s*(?P<query>.+)$", re.I | re.S)
_AUTO_CDC = re.compile(r"^\s*(?:CREATE\s+OR\s+REFRESH\s+STREAMING\s+TABLE\s+\S+\s*;\s*)?AUTO\s+CDC\s+INTO\b", re.I)
_PROC = re.compile(r"^\s*CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\b.*?\bLANGUAGE\s+SQL\b", re.I | re.S)
_GOVERNANCE = [re.compile(p, re.I | re.S) for p in (
    r"^\s*CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\b", r"^\s*ALTER\s+TABLE\s+\S+\s+ALTER\s+COLUMN\s+\S+\s+SET\s+MASK\b",
    r"^\s*ALTER\s+TABLE\s+\S+\s+SET\s+ROW\s+FILTER\b", r"^\s*ALTER\s+TABLE\s+\S+\s+(?:ALTER\s+COLUMN\s+\S+\s+)?SET\s+TAGS\b",  # noqa: E501
    r"^\s*GRANT\b", r"^\s*CREATE\s+POLICY\b")]
_EXEC_IMMEDIATE = re.compile(r"\bEXECUTE\s+IMMEDIATE\b(?!\s*(?:'|\$\$))", re.I)


def _parse_one(sql: str) -> tuple[exp.Expr | None, str]:
    try:
        return sqlglot.parse_one(sql, read=DB), ""
    except SqlglotError as exc:
        return None, f"not valid Databricks SQL: {str(exc)[:160]}"


def _statements(sql: str) -> tuple[list[exp.Expr], str]:
    try:
        return [t for t in sqlglot.parse(sql, read=DB) if t is not None], ""
    except SqlglotError as exc:
        return [], f"not valid Databricks SQL: {str(exc)[:160]}"


def v_cte_chain(sql: str) -> list[str]:
    stmts, err = _statements(sql)
    if err:
        return [err]
    if len(stmts) != 1:
        return [f"expected exactly one SELECT, got {len(stmts)} statements"]
    tree = stmts[0]
    if not isinstance(tree, _READ_TYPES):
        return [f"only SELECT / WITH is allowed, got {type(tree).__name__}"]
    return [f"{type(n).__name__} is not allowed in a read-only chain"
            for n in tree.find_all(exp.Insert, exp.Update, exp.Delete, exp.Merge, exp.Create, exp.Drop)][:1]


def v_statement(sql: str) -> list[str]:
    stmts, err = _statements(sql)
    if err:
        return [err]
    if len(stmts) != 1:
        return [f"exactly one statement expected, got {len(stmts)}"]
    t = stmts[0]
    if isinstance(t, _STATEMENT_TYPES):
        return []
    if isinstance(t, exp.Create) and str(t.args.get("kind") or "").upper() in ("TABLE", "VIEW", "FUNCTION"):
        return []
    if isinstance(t, exp.Command) and re.match(r"\s*CREATE\s+(?:OR\s+REPLACE\s+)?MATERIALIZED\s+VIEW", sql, re.I):
        return []
    return [f"{type(t).__name__} is not an allowed statement (MERGE, INSERT, UPDATE, DELETE, CTAS, CREATE VIEW)"]


def v_script(text: str) -> list[str]:
    if not _PROC.match(text):
        return ["a script must be CREATE [OR REPLACE] PROCEDURE ... LANGUAGE SQL"]
    problems = []
    if _EXEC_IMMEDIATE.search(text):
        problems.append("EXECUTE IMMEDIATE of a non-literal is not allowed on Databricks")
    m = re.search(r"\bBEGIN\b(?P<body>.*)\bEND\b\s*;?\s*$", text, re.I | re.S)
    if not m:
        return problems + ["procedure body is not a BEGIN ... END block"]
    nodes = split_scripting("BEGIN " + m.group("body") + " END")
    for n in nodes:
        if n.kind == "statement":
            _, err = _parse_one(n.text)
            if err and not re.match(r"\s*(?:CREATE|ALTER|TRUNCATE|SET|USE|COMMIT)\b", n.text, re.I):
                problems.append(f"statement {n.statement_index}: {err}")
    if not nodes or any(n.text.upper().startswith("END") for n in nodes):
        problems.append("unbalanced BEGIN / END in the procedure body (checked by the splitter)")
    return problems


def v_pipeline(text: str) -> list[str]:
    if _AUTO_CDC.match(text):
        return []
    m = _PIPELINE.match(text)
    if not m:
        return ["a pipeline artifact must be CREATE OR REFRESH [STREAMING TABLE | MATERIALIZED VIEW] ... AS <query>"]
    return v_cte_chain(m.group("query").strip().rstrip(";"))


def v_job(text: str) -> list[str]:
    try:
        job = json.loads(text) if isinstance(text, str) else dict(text)
    except (ValueError, TypeError) as exc:
        return [f"job spec is not JSON: {exc}"]
    problems = []
    if not job.get("name"):
        problems.append("job needs a name")
    tasks = job.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        return problems + ["job needs a non-empty tasks list"]
    keys = [t.get("task_key") for t in tasks]
    if len(set(keys)) != len(keys) or not all(keys):
        problems.append("task_key values must be present and unique")
    for t in tasks:
        for d in t.get("depends_on") or []:
            if d.get("task_key") not in keys:
                problems.append(f"task {t.get('task_key')!r} depends on unknown task {d.get('task_key')!r}")
        if t.get("run_if") and t["run_if"] not in _JOB_RUN_IF:
            problems.append(f"task {t.get('task_key')!r}: run_if {t['run_if']!r} is not a Jobs API value")
        if not any(k in t for k in ("sql_task", "notebook_task", "spark_python_task", "run_job_task", "pipeline_task")):
            problems.append(f"task {t.get('task_key')!r} has no task body")
    return problems


def v_python(text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [f"python does not parse: {exc.msg} (line {exc.lineno})"]
    problems = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("exec", "eval"):
            problems.append(f"{n.func.id}() is not allowed")
        mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""] if isinstance(n, ast.ImportFrom) else []  # noqa: E501
        problems += [f"import of {m} is not allowed" for m in mods if m.split(".")[0] in _FORBIDDEN_IMPORTS]
    return problems


def v_file_load(text: str) -> list[str]:
    stmts = [s for s in re.split(r";\s*(?=\S)", text.strip().rstrip(";")) if s.strip()]
    if len(stmts) != 1:
        return [f"exactly one COPY INTO / Auto Loader statement expected, got {len(stmts)}"]
    if not any(rx.match(stmts[0]) for rx in _FILE_LOAD):
        return ["a file_load is COPY INTO <t> FROM '<path>' FILEFORMAT = ..., or CREATE OR REFRESH STREAMING TABLE "
                "... AS SELECT ... FROM STREAM read_files('<path>', ...)"]
    return []


def v_governance(text: str) -> list[str]:
    stmts = [s for s in re.split(r";\s*(?=\S)", text.strip().rstrip(";")) if s.strip()]
    if len(stmts) != 1:
        return [f"one statement per governance artifact, got {len(stmts)}"]
    return [] if any(rx.match(stmts[0]) for rx in _GOVERNANCE) else ["statement is not in the governance allow-list"]


def v_expression(text: str) -> list[str]:
    """A scalar expression (a SQL UDF body): it must parse."""
    try:
        sqlglot.parse_one(text, read=DB)
    except SqlglotError as exc:
        return [f"not a valid Databricks expression: {str(exc)[:160]}"]
    return []


def sniff_kind(sql: str) -> str:
    """The validator kind for a translated text, from its first keyword (the chain validates mixed units)."""
    text = re.sub(r"--[^\n]*\n|/\*.*?\*/", " ", sql or "", flags=re.S)
    head = re.sub(r"^[\s(]+", "", text)[:80].upper()
    if re.match(r"(SELECT|WITH|VALUES)\b", head):
        return "cte_chain"
    if re.match(r"CREATE\s+(OR\s+REPLACE\s+)?PROCEDURE\b", head):
        return "script"
    if re.match(r"CREATE\s+OR\s+(REFRESH|REPLACE)\s+(STREAMING\s+TABLE|MATERIALIZED)", head):
        return "pipeline"
    if re.match(r"(MERGE|INSERT|UPDATE|DELETE|CREATE|TRUNCATE|DROP|ALTER)\b", head):
        if ";" in text.strip().rstrip(";") and len(_statements(text)[0]) > 1:
            return "statements"          # L10: several statements, each validated by its own kind
        return "statement"
    if re.match(r"CALL\b", head):
        return "call"
    return "expression"


def v_statements(text: str) -> list[str]:
    """A multi-statement unit (L10): every statement passes the validator of its own kind, so a reviewer's edit of a
    unit that the engine split into several statements (temp view + inserts, DDL + DML) is revalidated whole."""
    stmts, err = _statements(text)
    if err:
        return [err]
    if not stmts:
        return ["no statement found"]
    problems: list[str] = []
    for i, t in enumerate(stmts, 1):
        one = t.sql(dialect=DB)
        kind = sniff_kind(one)
        if kind == "statements":                       # a single statement never sniffs as multi: guard recursion
            kind = "statement"
        if kind == "expression":
            problems.append(f"statement {i}: not an allowed statement (MERGE, INSERT, UPDATE, DELETE, CREATE, SELECT, "
                            "CALL, TRUNCATE, DROP, ALTER)")
            continue
        problems += [f"statement {i}: {p}" for p in validate(kind, one)]
    return problems


def v_call(text: str) -> list[str]:
    return [] if re.match(r"\s*CALL\s+[\w.`]+\s*\(", text, re.I) else ["not a CALL statement"]


VALIDATORS = {"cte_chain": v_cte_chain, "statement": v_statement, "script": v_script, "pipeline": v_pipeline,
              "job": v_job, "expression": v_expression, "call": v_call, "python": v_python,
              "file_load": v_file_load, "governance": v_governance, "statements": v_statements}


def validate(kind: str, text: str) -> list[str]:
    fn = VALIDATORS.get(kind)
    if fn is None:
        return [f"no validator for artifact kind {kind!r}"]
    return fn(text)


@dataclass
class ColumnCheck:
    status: str                       # ok | failed | unverifiable
    missing: list[str] = field(default_factory=list)
    reason: str = ""


def column_check(sql: str, catalogue: dict[str, dict[str, str]] | None) -> ColumnCheck:
    """Every column of a read exists in the landed catalogue. ``unverifiable`` (never ok) when the catalogue is
    missing or a read table is not in it; a miss on an upstream CTE is only resolvable with a live probe."""
    if not catalogue:
        return ColumnCheck("unverifiable", reason="no column catalogue for this batch")
    tree, err = _parse_one(sql)
    if tree is None:
        return ColumnCheck("failed", reason=err)
    ctes = {str(c.alias).lower() for c in tree.find_all(exp.CTE)}
    known = {k.lower(): {c.lower(): t for c, t in v.items()} for k, v in catalogue.items()}
    refs = [t for t in tree.find_all(exp.Table) if t.name and t.name.lower() not in ctes]
    absent = sorted({".".join(p for p in (t.catalog, t.db, t.name) if p) for t in refs
                     if ".".join(p for p in (t.catalog, t.db, t.name) if p).lower() not in known})
    if absent:
        return ColumnCheck("unverifiable", reason=f"table(s) not in the catalogue: {', '.join(absent)}")
    schema: dict = {}
    for name, cols in known.items():
        parts = name.split(".")
        node = schema
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        node[parts[-1]] = dict.fromkeys(cols, "string")
    try:
        qualify(tree.copy(), schema=schema, dialect=DB, validate_qualify_columns=True)
    except Exception as exc:  # sqlglot raises OptimizeError for an unknown column
        msg = str(exc)
        if "Unknown column" in msg or "could not be resolved" in msg:
            return ColumnCheck("failed", [msg[:160]], "column not in the landed table")
        return ColumnCheck("unverifiable", reason=f"could not resolve columns: {msg[:120]}")
    return ColumnCheck("ok")


__all__ = ["ColumnCheck", "VALIDATORS", "column_check", "extract_body", "sniff_kind", "validate"]
