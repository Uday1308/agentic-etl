"""packs.snowflake.vocabulary - the Snowflake SQL node as logic parity needs it (ADR 032 section 2).

``columns_read`` / ``reads_in_order`` come from ``sqlglot.lineage`` over the qualified statement. A SQL node with no
derivable column lineage is ``unverifiable`` (``lineage_status``), never passed vacuously.
"""
from __future__ import annotations

from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.lineage import lineage

SOURCE_OPS = frozenset({"SOURCE"})
SINK_OPS = frozenset({"TARGET"})


def _sql_of(node: dict) -> str:
    p = node.get("properties") or node.get("logic") or {}
    return str(p.get("sql") or "")


def _tree(node: dict) -> exp.Expr | None:
    sql = _sql_of(node)
    if not sql:
        return None
    try:
        return sqlglot.parse_one(sql, read="snowflake")
    except SqlglotError:
        return None


def column_lineage(sql: str, dialect: str = "snowflake") -> dict[str, set[str]] | None:
    """``{output column: {source columns}}`` through ``sqlglot.lineage``; None when it cannot be derived (``SELECT *``
    without a schema, a parse error, a statement that is not a query)."""
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
        query = tree.find(exp.Select) if not isinstance(tree, exp.Select) else tree
        if query is None:
            return None
        out: dict[str, set[str]] = {}
        for proj in query.expressions:
            name = proj.alias_or_name
            if not name or isinstance(proj, exp.Star) or name == "*":
                return None
            node = lineage(name, sql, None, dialect=dialect)
            out[name] = {leaf.name.split(".")[-1].upper() for leaf in node.walk() if not leaf.downstream}
        return out
    except Exception:
        return None


class SnowflakeVocabulary:
    source_ops = SOURCE_OPS
    sink_ops = SINK_OPS
    passthrough_ops: frozenset[str] = frozenset()
    dynamic_column_ops: frozenset[str] = frozenset()
    schema_aware_ops: frozenset[str] = frozenset()

    @staticmethod
    def op_of(node: dict) -> str:
        t = str(node.get("type") or "").upper()
        return {"SQL": "SQL", "SOURCE": "SOURCE", "TARGET": "TARGET"}.get(t, t)

    @staticmethod
    def output_columns(node: dict, upstream: list[list[str] | None]) -> list[str] | None:
        lin = column_lineage(_sql_of(node))
        return list(lin) if lin is not None else None

    @staticmethod
    def columns_read(node: dict) -> set[str]:
        lin = column_lineage(_sql_of(node))
        return set().union(*lin.values()) if lin else set()

    @staticmethod
    def lineage_status(node: dict) -> str:
        """``verifiable`` or ``unverifiable`` (parity must not report lineage as passed for the latter)."""
        return "verifiable" if column_lineage(_sql_of(node)) is not None else "unverifiable"

    @staticmethod
    def reads_in_order(node: dict) -> list[tuple[set[str], str]]:
        lin = column_lineage(_sql_of(node))
        return [(cols, name) for name, cols in (lin or {}).items()]


VOCABULARY: Any = SnowflakeVocabulary()

__all__ = ["VOCABULARY", "SnowflakeVocabulary", "column_lineage"]
