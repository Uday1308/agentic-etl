"""packs.snowflake.columns - the per-batch column catalogue (ADR 032 section 3, P3-08).

ONE ``information_schema.columns`` query per batch over the ``table_map`` targets, chunked at 500 table names per
``IN`` list and read through the injected ``query`` port (the existing SQL warehouse port); cached by the caller for
the run. With no port it falls back to the source ``columns`` raw records shipped in the bundle. Landed column types
are kept (the ``SNW-VARIANT-PATH`` rewrite needs them).
"""
from __future__ import annotations

from collections.abc import Callable, Iterable

CHUNK = 500


def information_schema_sql(tables: Iterable[str]) -> list[str]:
    """The statements (one per 500 tables). Table names are ``catalog.schema.table`` (backticks not needed)."""
    names = sorted({t.lower() for t in tables if t})
    out = []
    for i in range(0, len(names), CHUNK):
        quoted = ", ".join("'" + n.replace("'", "''") + "'" for n in names[i:i + CHUNK])
        out.append("SELECT table_catalog, table_schema, table_name, column_name, data_type "
                   "FROM system.information_schema.columns "
                   f"WHERE lower(concat_ws('.', table_catalog, table_schema, table_name)) IN ({quoted})")
    return out


def build_catalogue(tables: Iterable[str], query: Callable[[str], list[dict]] | None = None, *,
                    source_columns: dict[str, dict[str, str]] | None = None) -> dict[str, dict[str, str]]:
    """``{"cat.schema.table": {column: type}}``. ``query`` returns dict rows; ``source_columns`` is the offline
    fallback (already keyed by the target table name)."""
    cat: dict[str, dict[str, str]] = {}
    if query is not None:
        for stmt in information_schema_sql(tables):
            for r in query(stmt) or []:
                key = ".".join(str(r[k]) for k in ("table_catalog", "table_schema", "table_name")).lower()
                cat.setdefault(key, {})[str(r["column_name"]).lower()] = str(r.get("data_type") or "")
    for key, cols in (source_columns or {}).items():
        cat.setdefault(key.lower(), {}).update({c.lower(): t for c, t in cols.items()})
    return cat


__all__ = ["CHUNK", "build_catalogue", "information_schema_sql"]
