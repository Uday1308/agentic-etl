"""packs.snowflake.conversion - the ConversionContext the Snowflake translator receives (conversion engine v2,
ADR 037 sections 3-5; catalogue X1, X2, X4).

    ConversionContext
      parameters    SessionParameters   the source account's parameters (TIMEZONE, WEEK_START, ...) from the handoff
                                        manifest's ``source_parameters``; each one ``provided`` or ``unavailable``
      capabilities  CapabilityProfile   the target's flags (``capabilities.yaml``), selected per environment
      column_types  {table: {col: type}} the columns (and SOURCE types) of every table the batch references, from the
                                        manifest's ``source_columns`` or the landed catalogue

An unavailable parameter is never silently replaced by Snowflake's documented default (hard rule 6): ``param()``
returns a ``ParamValue`` whose ``state`` is ``unavailable``; a rule that needs it either escalates or records that it
assumed the default (``ParamValue.value_or_default`` returns ``(value, assumed)``). ``digest`` changes whenever
anything a rule may read changes, so it goes into the unit fingerprint (a cached tier-1 draft or an approval made
under other parameters is not reused).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

HERE = Path(__file__).parent
CAPABILITIES_FILE = HERE / "capabilities.yaml"
ENV_PROFILE = "MIGRATOR_CAPABILITY_PROFILE"
ENV_FILE = "MIGRATOR_CAPABILITIES_FILE"

#: Snowflake's documented defaults, used ONLY when a rule explicitly asks for ``value_or_default`` and says so.
SNOWFLAKE_DEFAULTS: dict[str, str] = {
    "TIMEZONE": "America/Los_Angeles", "WEEK_START": "0", "WEEK_OF_YEAR_POLICY": "0",
    "TIMESTAMP_TYPE_MAPPING": "TIMESTAMP_NTZ", "TIMESTAMP_INPUT_FORMAT": "AUTO", "DATE_INPUT_FORMAT": "AUTO",
    "TIME_INPUT_FORMAT": "AUTO", "QUOTED_IDENTIFIERS_IGNORE_CASE": "false",
    "ERROR_ON_NONDETERMINISTIC_MERGE": "true",
}
PARAMETER_NAMES = tuple(SNOWFLAKE_DEFAULTS)


@dataclass(frozen=True)
class ParamValue:
    name: str
    state: str                     # provided | unavailable
    value: str | None = None       # the account's value when provided
    level: str = ""                # account | default | ... as Snowflake reported it
    reason: str = ""

    @property
    def known(self) -> bool:
        return self.state == "provided" and self.value is not None

    def value_or_default(self) -> tuple[str, bool]:
        """``(value, assumed)``: Snowflake's documented default with ``assumed=True`` when the account's value is
        unknown. The caller records the assumption (a review caveat); nothing is hidden."""
        if self.known:
            return str(self.value), False
        return SNOWFLAKE_DEFAULTS[self.name], True


@dataclass(frozen=True)
class SessionParameters:
    values: Mapping[str, ParamValue] = field(default_factory=dict)

    @classmethod
    def from_manifest(cls, raw: Mapping[str, Any] | None) -> SessionParameters:
        """``{NAME: {value, default, level, state}}`` (``Source.parameters``) -> typed values. A name absent from the
        input (an older extraction, or a non-Snowflake source) is ``unavailable`` with the reason."""
        raw = raw or {}
        out: dict[str, ParamValue] = {}
        for name in PARAMETER_NAMES:
            entry = raw.get(name) or raw.get(name.lower())
            if isinstance(entry, Mapping) and entry.get("state") == "provided" and entry.get("value") is not None:
                out[name] = ParamValue(name, "provided", str(entry["value"]), str(entry.get("level") or ""))
            else:
                why = entry.get("reason") if isinstance(entry, Mapping) else None
                out[name] = ParamValue(name, "unavailable", None, "", str(why or "not extracted for this source"))
        return cls(out)

    def get(self, name: str) -> ParamValue:
        key = name.upper()
        return self.values.get(key) or ParamValue(key, "unavailable", None, "", "not extracted for this source")

    @property
    def known(self) -> list[str]:
        return sorted(n for n, v in self.values.items() if v.known)

    def as_dict(self) -> dict[str, Any]:
        return {n: {"state": v.state, "value": v.value, "level": v.level} for n, v in sorted(self.values.items())}


@dataclass(frozen=True)
class CapabilityProfile:
    name: str
    flags: Mapping[str, bool]
    verified: str = "unverified"

    def has(self, flag: str) -> bool:
        if flag not in self.flags:
            raise KeyError(f"unknown capability flag {flag!r} (see capabilities.yaml)")
        return bool(self.flags[flag])

    def as_dict(self) -> dict[str, Any]:
        return {"name": self.name, "verified": self.verified, "flags": dict(sorted(self.flags.items()))}


def load_profiles(path: str | Path | None = None) -> tuple[str, dict[str, CapabilityProfile]]:
    raw = yaml.safe_load(Path(path or os.environ.get(ENV_FILE) or CAPABILITIES_FILE).read_text(encoding="utf-8"))
    flag_names = list(raw["flags"])
    default_name = str(raw["default_profile"])
    base = {k: v for k, v in raw["profiles"][default_name].items() if k != "verified"}
    profiles: dict[str, CapabilityProfile] = {}
    for name, body in raw["profiles"].items():
        merged = {**base, **{k: v for k, v in body.items() if k != "verified"}}
        unknown = set(merged) - set(flag_names)
        missing = [f for f in flag_names if f not in merged]
        if unknown or missing:
            raise ValueError(f"capability profile {name}: unknown flags {sorted(unknown)}, missing {missing}")
        profiles[str(name)] = CapabilityProfile(str(name), {k: bool(merged[k]) for k in flag_names},
                                                str(body.get("verified") or "unverified"))
    return default_name, profiles


def select_profile(name: str | None = None, *, path: str | Path | None = None) -> CapabilityProfile:
    """The profile named by ``name``, else ``MIGRATOR_CAPABILITY_PROFILE``, else the file's default."""
    default_name, profiles = load_profiles(path)
    wanted = name or os.environ.get(ENV_PROFILE) or default_name
    if wanted not in profiles:
        raise ValueError(f"unknown capability profile {wanted!r}; known: {sorted(profiles)}")
    return profiles[wanted]


_TYPE_FAMILIES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("variant", re.compile(r"^(VARIANT|OBJECT|ARRAY|MAP|STRUCT)\b", re.I)),
    ("timestamp_tz", re.compile(r"^TIMESTAMP_TZ\b", re.I)),
    ("timestamp_ltz", re.compile(r"^TIMESTAMP_LTZ\b", re.I)),
    ("timestamp_ntz", re.compile(r"^(TIMESTAMP_NTZ|DATETIME)\b", re.I)),
    ("timestamp", re.compile(r"^TIMESTAMP\b", re.I)),             # alias: NTZ or LTZ by TIMESTAMP_TYPE_MAPPING
    ("date", re.compile(r"^DATE\b", re.I)),
    ("time", re.compile(r"^TIME\b", re.I)),
    ("boolean", re.compile(r"^BOOL(EAN)?\b", re.I)),
    ("numeric", re.compile(r"^(NUMBER|NUMERIC|DECIMAL|DEC|INT|INTEGER|BIGINT|SMALLINT|TINYINT|BYTEINT|FLOAT|FLOAT4|"
                           r"FLOAT8|DOUBLE|REAL|LONG|SHORT|BYTE)\b", re.I)),
    ("string", re.compile(r"^(VARCHAR|CHAR|CHARACTER|STRING|TEXT|NVARCHAR|NCHAR)\b", re.I)),
    ("binary", re.compile(r"^(BINARY|VARBINARY)\b", re.I)),
    ("geo", re.compile(r"^(GEOGRAPHY|GEOMETRY)\b", re.I)),
)


def type_family(type_text: str | None) -> str | None:
    """Coarse family of a SQL type text (Snowflake or Databricks spelling); None when the type is unknown."""
    if not type_text:
        return None
    t = str(type_text).strip()
    for fam, rx in _TYPE_FAMILIES:
        if rx.match(t):
            return fam
    return "other"


def sequences_of(source_objects: Mapping[str, Any] | None) -> dict[str, dict[str, Any]]:
    """``{FQN upper: {start, increment, ordered}}`` of the manifest's ``source_objects["sequences"]``. A sequence whose
    next value or interval was not extracted is left out (never defaulted: rule 6)."""
    out: dict[str, dict[str, Any]] = {}
    for s in (source_objects or {}).get("sequences") or []:
        if s.get("next_value") is None or s.get("interval") is None:
            continue
        spec = {"start": int(s["next_value"]), "increment": int(s["interval"]), "ordered": bool(s.get("ordered"))}
        fqn = str(s.get("id") or f"{s.get('database')}.{s.get('schema')}.{s.get('name')}").upper()
        out[fqn] = spec
        out.setdefault(str(s.get("name") or "").upper(), spec)
    return out


@dataclass(frozen=True)
class ConversionContext:
    parameters: SessionParameters = field(default_factory=SessionParameters)
    capabilities: CapabilityProfile = field(default_factory=lambda: select_profile())
    #: lower-case ``catalog.schema.table`` -> {lower-case column: type, or None when the type is unknown}
    column_types: Mapping[str, Mapping[str, str | None]] = field(default_factory=dict)
    source_dialect: str = "snowflake"
    #: ``COLUMN_UPPER`` -> the values a dynamic PIVOT (``IN (ANY)`` / subquery) is frozen to at build time (2.17); from
    #: the manifest's ``pivot_values``. Empty = a dynamic PIVOT is flagged (escalate), never guessed
    pivot_values: Mapping[str, tuple] = field(default_factory=dict)
    #: lower-case ``catalog.schema.table`` -> {lower-case column: {min, max, ...}} from the data lens (X7): lets a rule
    #: decide BIGINT vs DECIMAL or an epoch scale from observed values. Absent = the rule flags, never guesses
    profiles: Mapping[str, Mapping[str, Mapping[str, Any]]] = field(default_factory=dict)
    #: SEQUENCE FQN (UPPER, also the bare name) -> ``{start, increment, ordered}`` from the manifest's ``source_objects``  # noqa: E501
    #: (L9), for ``DEFAULT seq.NEXTVAL`` -> identity (objects.default_to_identity)
    sequences: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)

    # ------------------------------------------------------------------ what a rule asks
    def param(self, name: str) -> ParamValue:
        return self.parameters.get(name)

    def has(self, flag: str) -> bool:
        return self.capabilities.has(flag)

    def table_columns(self, table: str) -> Mapping[str, str | None] | None:
        """The columns of a referenced table, or None when the table is not in the catalogue (never ``{}``)."""
        return self.column_types.get(table.lower())

    def column_type(self, table: str, column: str) -> str | None:
        cols = self.table_columns(table)
        return None if cols is None else cols.get(column.lower())

    def column_family(self, table: str, column: str) -> str | None:
        return type_family(self.column_type(table, column))

    # ------------------------------------------------------------------ identity
    @property
    def digest(self) -> str:
        typed = {t: sorted((c, ty or "") for c, ty in cols.items()) for t, cols in sorted(self.column_types.items())}
        body: dict[str, Any] = {"p": self.parameters.as_dict(), "c": self.capabilities.as_dict(), "t": typed}
        if self.pivot_values:
            body["pv"] = {k: list(v) for k, v in sorted(self.pivot_values.items())}
        if self.sequences:
            body["sq"] = {k: dict(v) for k, v in sorted(self.sequences.items())}
        if self.profiles:
            body["pr"] = {t: sorted(c) for t, c in sorted(self.profiles.items())}
        return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:12]

    def summary(self) -> dict[str, Any]:
        """Small, persistable, carries no names: for run records and a unit's evidence."""
        return {"capability_profile": self.capabilities.name, "parameters_known": self.parameters.known,
                "tables_typed": len(self.column_types), "digest": self.digest}

    @classmethod
    def build(cls, *, source_parameters: Mapping[str, Any] | None = None,
              catalogue: Mapping[str, Mapping[str, str | None]] | None = None,
              capability_profile: str | None = None, capabilities_file: str | Path | None = None,
              pivot_values: Mapping[str, Any] | None = None, profiles: Mapping[str, Any] | None = None,
              source_objects: Mapping[str, Any] | None = None) -> ConversionContext:
        return cls(SessionParameters.from_manifest(source_parameters),
                   select_profile(capability_profile, path=capabilities_file),
                   {k.lower(): {c.lower(): t for c, t in v.items()} for k, v in (catalogue or {}).items()},
                   pivot_values={str(k).upper(): tuple(v) for k, v in (pivot_values or {}).items()},
                   profiles={str(t).lower(): {str(c).lower(): dict(p) for c, p in (cols or {}).items()}
                             for t, cols in (profiles or {}).items()},
                   sequences=sequences_of(source_objects))


__all__ = ["CAPABILITIES_FILE", "CapabilityProfile", "ConversionContext", "PARAMETER_NAMES", "ParamValue",
           "SNOWFLAKE_DEFAULTS", "SessionParameters", "load_profiles", "select_profile", "type_family"]
