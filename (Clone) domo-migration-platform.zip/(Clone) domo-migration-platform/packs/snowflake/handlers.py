"""packs.snowflake.handlers - object handlers and routing (ADR 032 section 5, P3-09).

``route_of(row)`` decides who builds an ETL's output: ``translate`` (this module: views, dynamic tables, procedures,
UDFs, task bodies), ``file_load`` (pipes and other file loads, built by the ``file_load`` unit, P3-18) or
``statement`` (recurring ``query`` writers, built by the ``statement`` unit, P3-19). The two later routes get a unit
STUB here (``unit_stub``) that ends the ETL ``awaiting_review``; the later tracks install their builders in
``BUILDERS`` instead of the stub. An engine the pack does not know, and a dbt-written ``query``, are ``unsupported``.
"""
from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from sqlglot import exp
from sqlglot.errors import SqlglotError

from packs.snowflake import contract as ct
from packs.snowflake.scripting_convert import RET_SUFFIX
from packs.snowflake.translate import UnitResult, split_args

ROUTE_TRANSLATE, ROUTE_FILE_LOAD, ROUTE_STATEMENT, ROUTE_UNSUPPORTED = "translate", "file_load", "statement", "unsupported"  # noqa: E501
ROUTE_FEDERATED = "federated"      # X8 (federation.py): an unconverted relation queried in place
#: later tracks (P3-18 / P3-19) replace the stubs: ``BUILDERS["file_load"] = fn(row, doc, hctx) -> list[Artifact]``
BUILDERS: dict[str, Callable[..., list[Artifact]]] = {}
#: engines that are callable objects: named by themselves, never by an output table
CALLABLE_ENGINES = frozenset({"sql_procedure", "javascript_procedure", "snowpark_python", "snowpark_java",
                              "snowpark_scala", "udf_sql", "udf_js", "udf_python", "udf_java", "udf_scala", "task"})


@dataclass
class Artifact:
    kind: str                       # cte_chain | statement | script | pipeline | job | python | file_load | governance
    name: str
    text: str = field(repr=False, default="")
    origin: str = "mapped"
    etl_id: str = ""
    unit_ids: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    review_reasons: list[str] = field(default_factory=list)
    spec: dict | None = None        # task bodies carry their job-task fragment here


@dataclass
class HandlerContext:
    target_map: dict[str, str] = field(default_factory=dict)       # asset_id -> catalog.schema.table
    default_catalog: str = "main"
    default_schema: str = "default"
    #: ``fn(doc, etl_key) -> UnitContext``: set by ``run_etl`` so async builders (statements) can run the chain
    unit_ctx_factory: Callable[..., Any] | None = None
    #: 6.12: asset_id -> function name renamed by signature (overloads.plan)
    overloads: dict[str, str] = field(default_factory=dict)


ADMIN_REASON = ("account/security administration - recreate as Databricks secrets / Unity Catalog storage "
                "credentials and grants, not migrated as logic")
_ADMIN_RX = re.compile(
    r"^\s*(?:"
    r"(?:ALTER|CREATE(?:\s+OR\s+REPLACE)?|DROP)\s+(?:USER|ROLE|DATABASE\s+ROLE|ACCOUNT|NETWORK\s+POLICY|"
    r"(?:API\s+|SECURITY\s+|NOTIFICATION\s+|STORAGE\s+)?INTEGRATION|SECRET|PASSWORD\s+POLICY|SESSION\s+POLICY)\b"
    r"|(?:GRANT|REVOKE)\b"
    r"|(?:ALTER|CREATE(?:\s+OR\s+REPLACE)?)\s+(?:TEMPORARY\s+)?STAGE\b"
    r"(?=[\s\S]*\b(?:CREDENTIALS|ENCRYPTION|STORAGE_INTEGRATION)\b)"
    r")", re.IGNORECASE)
_WRAPPERS = re.compile(r"^\s*(?:BEGIN|END|RETURN\b[\s\S]*|COMMIT|DECLARE)?\s*$", re.IGNORECASE)


def admin_only_body(body: Any) -> bool:
    """True when a procedure body is only account/security administration statements (no data logic at all)."""
    if not isinstance(body, str) or not body.strip():
        return False
    text = re.sub(r"--[^\n]*|/\*[\s\S]*?\*/", " ", body).replace("$$", " ")
    text = re.sub(r"'(?:[^']|'')*'", "''", text)             # a literal may hold ';' (and is secret material)
    parts = [p.strip() for p in text.split(";")]
    stmts = [re.sub(r"^\s*BEGIN\b", "", p, flags=re.IGNORECASE).strip() for p in parts]
    stmts = [re.sub(r"\bEND\s*$", "", p, flags=re.IGNORECASE).strip() for p in stmts]
    stmts = [p for p in stmts if p and not _WRAPPERS.match(p)]
    return bool(stmts) and all(_ADMIN_RX.match(p) for p in stmts)


def route_of(row: dict, payload: Any = None) -> tuple[str, str]:
    """``(route, reason)`` for a manifest ETL row. Checked BEFORE the definition check (section 5).

    A SQL procedure whose body (from ``payload`` or ``row['payload']``, when present) is only account/security
    administration is ``unsupported``: it becomes Databricks secrets / grants, not logic."""
    engine = str(row.get("engine") or "")
    if engine not in ct.ENGINES:
        return ROUTE_UNSUPPORTED, f"engine {engine!r} is not in the Snowflake pack's handler table"
    pl = payload if payload is not None else row.get("payload")
    if engine == "sql_procedure" and pl is not None:
        doc_body = ct.unit_doc(row, pl).get("definition")
        if admin_only_body(doc_body):
            return ROUTE_UNSUPPORTED, ADMIN_REASON
    if str(row.get("disposition") or "").lower() == "federate" or str(row.get("route") or "") == ROUTE_FEDERATED:
        return ROUTE_FEDERATED, "queried in place through a Lakehouse Federation foreign catalog (X8)"
    if engine == "query" and (str(row.get("tool_key") or row.get("writer") or "").lower().startswith("dbt")):
        return ROUTE_UNSUPPORTED, "dbt writer: Phase 4 (dbt-databricks adapter)"
    if row.get("unit_kind") == "file_load" or engine == "snowpipe":
        return ROUTE_FILE_LOAD, "file loads are generated by the file_load unit"
    if row.get("unit_kind") == "statement" or engine == "query":
        return ROUTE_STATEMENT, "recurring query texts are generated by statement units"
    return ROUTE_TRANSLATE, ""        # tasks translate their body here; the job is built by assemble_batch


def unit_stub(route: str, row: dict) -> dict:
    """The routed unit before its builder exists: visible to the reviewer, never silently dropped."""
    unit = {"file_load": "file_load", "statement": "statement"}[route]
    return {"unit_kind": unit, "etl_id": row.get("etl_id"), "name": row.get("name"), "engine": row.get("engine"),
            "pending_builder": True, "outputs": list(row.get("outputs") or []),
            "statements": list(row.get("statements") or []),
            "reason": f"the {unit} unit builder is not installed yet ({'P3-18' if unit == 'file_load' else 'P3-19'})"}


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_") or "x"


def target_name(doc: dict, h: HandlerContext) -> str:
    """The Databricks name of the object an ETL produces: its first output table, else ``target_map``, else derived."""
    # a callable's outputs are tables it writes, not its own name
    callable_object = str(doc.get("engine") or "") in CALLABLE_ENGINES
    for o in doc.get("outputs") or []:
        if o.get("table") and not callable_object:
            return str(o["table"])
    aid = str(doc.get("asset_id") or "")
    if aid in h.target_map:
        return h.target_map[aid]
    p = ct.parse_native_id(aid)
    if p["db"]:
        renamed = h.overloads.get(aid)
        return ct.derived_target(h.default_catalog, p["db"], p["schema"],
                                 renamed or p["name"] or str(doc.get("name") or "object"))
    return f"{h.default_catalog}.{h.default_schema}.{slug(p['name'] or doc.get('name') or 'object')}"


def _db_type(t: str) -> str:
    try:
        return exp.DataType.build(t, dialect="snowflake").sql("databricks")
    except (SqlglotError, ValueError):
        return "STRING"


def _args(doc: dict) -> str:
    """``name TYPE`` list: the real parameter names when the extraction carried ``ARGUMENT_SIGNATURE``
    (``(P_MODE VARCHAR)``), else ``argN`` over the types in the asset id."""
    return ", ".join(f"{n} {_db_type(t)}" for n, t in ct.signature_pairs(doc))


def _lag_clause(lag: object) -> tuple[str, list[str]]:
    """``target_lag`` -> a pipeline SCHEDULE clause; DOWNSTREAM and unknown lags are review reasons (SNW-DT-LAG)."""
    if not isinstance(lag, str) or not lag.strip():
        return "", ["target lag unavailable: schedule not set"]
    m = re.match(r"\s*(\d+)\s*(second|minute|hour|day)s?\s*$", lag, re.I)
    if not m:
        return "", [f"target lag {lag.strip().upper()!r} has no pipeline schedule equivalent"]
    n, unit = int(m.group(1)), m.group(2).upper()
    return f" SCHEDULE EVERY {n} {unit if n == 1 else unit + 'S'}", []


def _indent(text: str, n: int = 1) -> str:
    pad = "  " * n
    return "\n".join(pad + line if line else line for line in text.splitlines())


def _scripted_procedure(doc: dict, results: list[UnitResult], name: str, origin: str, etl_id: str, caveats: list[str],
                        reasons: list[str]) -> list[Artifact]:
    """The artifacts of a procedure converted by the scripting converter (``params["procedure"]``).

    form ``procedure`` (profile has ``sql_procedures``): ``CREATE PROCEDURE`` (invoker rights); a scalar RETURN also
    gets the ``<name>__ret`` OUT-parameter twin that holds the body, and ``<name>`` calls it and returns the one-row
    ``return_value`` result. form ``notebook`` (``sql_scripting`` only): an anonymous compound statement for a notebook
    cell, parameters bound from widgets / job parameters of the same names."""
    res = results[0]
    proc = res.params["procedure"]
    units = [r.unit_id for r in results]
    reasons += [n["note"] for n in res.params.get("scripting_notes") or [] if n["note"] not in reasons]
    caveats = sorted(set(caveats) | set(res.review_caveats))
    execute_as = str(proc.get("execute_as") or (doc.get("params") or {}).get("execute_as") or "").upper()
    if execute_as in ("OWNER", "RESTRICTED CALLER"):
        reasons.append(f"EXECUTE AS {execute_as}: Databricks procedures run as invoker (SNW-EXEC-AS)")
        caveats = sorted(set(caveats) | {"SNW-EXEC-AS"})
    args, names = _args(doc), list(proc.get("param_names") or [])
    scalar, rtype, body = proc["returns"] == "scalar", str(proc.get("return_type") or "STRING"), res.sql
    if proc["form"] == "notebook":
        reasons.append("the target profile has no CREATE PROCEDURE (sql_procedures is false): the body is an anonymous "
                       "compound statement for a notebook cell; bind the parameters as widgets / job parameters")
        lines = [f"DECLARE {a.split(None, 1)[0]} {a.split(None, 1)[1]} DEFAULT :{a.split(None, 1)[0]};"
                 for a in split_args(args)]
        lines += [f"DECLARE return_value {rtype};"] if scalar else []
        text = "\n".join(["BEGIN", _indent("\n".join(lines + [body]))]
                          + ([_indent("SELECT return_value AS return_value;")] if scalar else []) + ["END;"])
        return [Artifact("task_body", name, text, origin, etl_id, units, caveats, reasons,
                         spec={"form": "notebook_cell", "parameters": names})]
    head = "LANGUAGE SQL\nSQL SECURITY INVOKER\nAS BEGIN"
    if not scalar:
        return [Artifact("script", name, f"CREATE OR REPLACE PROCEDURE {name}({args})\n{head}\n{_indent(body)}\nEND",
                         origin, etl_id, units, caveats, reasons)]
    out_args = ", ".join(filter(None, [args, f"OUT return_value {rtype}"]))
    twin = Artifact("script", name + RET_SUFFIX,
                    f"CREATE OR REPLACE PROCEDURE {name}{RET_SUFFIX}({out_args})\n{head}\n{_indent(body)}\nEND",
                    origin, etl_id, units, caveats, reasons)
    call_args = ", ".join([*names, "return_value"])
    wrapper = (f"CREATE OR REPLACE PROCEDURE {name}({args})\n{head}\n"
               f"  DECLARE return_value {rtype};\n  CALL {name}{RET_SUFFIX}({call_args});\n"
               "  SELECT return_value AS return_value;\nEND")
    return [twin, Artifact("script", name, wrapper, origin, etl_id, units, caveats, reasons)]


def _joined(results: list[UnitResult]) -> str:
    return ";\n".join(r.sql for r in results if r.sql)


def build_artifacts(doc: dict, results: list[UnitResult], h: HandlerContext) -> list[Artifact]:
    """The artifacts of one translated ETL. Empty when a unit is unresolved (the ETL waits for a reviewer)."""
    engine, etl_id = str(doc.get("engine") or ""), str(doc.get("etl_id") or "")
    if not results or any(r.status != "resolved" or not r.sql for r in results):
        return []
    name = target_name(doc, h)
    origin = _worst_origin(results)
    caveats = sorted({c for r in results for c in r.caveats})
    reasons: list[str] = []
    units = [r.unit_id for r in results]
    cdf = [r.params["change_data_feed"] for r in results if r.params.get("change_data_feed")]
    for c in cdf:       # a stream read became table_changes(): a documented job parameter and one review reason
        reasons.append(c["note"])

    def art(kind: str, text: str, **kw) -> list[Artifact]:
        return [Artifact(kind, name, text, origin, etl_id, units, caveats, reasons, **kw)]

    params = doc.get("params") or {}
    if engine == "sql_view" and params.get("secure"):
        reasons.append("secure view: confirm the access model on Databricks")
    if engine == "sql_view":
        return art("statement", f"CREATE OR REPLACE VIEW {name} AS\n{results[0].sql}")
    if engine == "materialized_view":
        return art("statement", f"CREATE MATERIALIZED VIEW {name} AS\n{results[0].sql}")
    if engine == "dynamic_table":
        clause, why = _lag_clause(params.get("target_lag"))
        reasons += why
        caveats = sorted(set(caveats) | {"SNW-DT-LAG"})
        return art("pipeline", f"CREATE OR REFRESH MATERIALIZED VIEW {name}{clause} AS\n{results[0].sql}")
    if engine == "udf_sql":
        rtype = _db_type(str(params.get("data_type"))) if params.get("data_type") else "STRING"
        if not params.get("data_type"):
            reasons.append("return type unavailable: STRING assumed")
        return art("statement", f"CREATE OR REPLACE FUNCTION {name}({_args(doc)}) RETURNS {rtype} RETURN {results[0].sql}")  # noqa: E501
    code = results[0].params.get("code")
    if code:             # S2: converted JavaScript / Snowpark Python (code_units): a notebook or a UDF statement
        reasons += [n["note"] for n in code.get("notes") or [] if n["note"] not in reasons]
        caveats = sorted(set(caveats) | set(results[0].review_caveats))
        return [Artifact(results[0].kind, name, results[0].sql, origin, etl_id, units, caveats, reasons)]
    if engine == "sql_procedure" and results[0].params.get("procedure"):
        return _scripted_procedure(doc, results, name, origin, etl_id, caveats, reasons)
    if engine in ("sql_procedure", "javascript_procedure", "snowpark_java", "snowpark_scala"):
        if str(params.get("execute_as") or "").upper() == "OWNER":
            reasons.append("EXECUTE AS OWNER: Databricks procedures run as invoker (SNW-EXEC-AS)")
            caveats = sorted(set(caveats) | {"SNW-EXEC-AS"})
        dropped = str(results[0].params.get("dropped_return") or "")
        if dropped:
            reasons.append(f"{dropped!r} was dropped: Databricks procedures return no value (callers must not use it)")
        body = _joined(results)
        return art("script", f"CREATE OR REPLACE PROCEDURE {name}({_args(doc)})\nLANGUAGE SQL\nSQL SECURITY INVOKER\n"
                             f"AS BEGIN\n{body};\nEND")
    if engine in ("snowpark_python", "udf_python"):
        return art("statement" if results[0].sql.lstrip().upper().startswith("CREATE") else "python", results[0].sql)
    if engine in ("udf_js", "udf_java", "udf_scala"):
        return art("statement", results[0].sql)
    if engine == "task":
        spec: dict = {"params": dict(params), "name": doc.get("name"), "asset_id": doc.get("asset_id")}
        job_task = _job_task_of(results)
        if job_task:
            spec["job_task"] = job_task
        if cdf:
            spec["parameters"] = {c["parameter"]: "0" for c in cdf}
        return [Artifact("task_body", name, _joined(results), origin, etl_id, units, caveats, reasons, spec=spec)]
    return []


def _job_task_of(results: list[UnitResult]) -> dict | None:
    """The Lakeflow job-task fragment of a task whose body is one deterministic ``CALL`` (the procedure's notebook,
    run with the call's arguments) or ``EXECUTE TASK`` (a run-job task); None for a SQL body."""
    if len(results) != 1:
        return None
    call, ex = results[0].params.get("call"), results[0].params.get("execute_task")
    if call:
        names = call.get("notebook_params") or []
        base = {(names[i] if i < len(names) else f"arg{i + 1}"): a.strip("'\"") for i, a in enumerate(call["args"])}
        return {"notebook_task": {"notebook_path": f"${{var.notebook_root}}/{call['target'].replace('.', '/')}",
                                  "base_parameters": base},
                "callee": call["target"]}
    if ex:
        return {"run_job_task": {"job_id": f"${{var.job_{slug(ex['name'])}}}"}, "callee": ex["name"]}
    return None


_RANK = {"mapped": 0, "transpiled": 1, "ai": 2, "manual": 3, "unresolved": 4}


def _worst_origin(results: list[UnitResult]) -> str:
    return max((r.origin for r in results), key=lambda o: _RANK.get(o, 4), default="mapped")


__all__ = ["Artifact", "BUILDERS", "HandlerContext", "ROUTE_FILE_LOAD", "ROUTE_STATEMENT", "ROUTE_TRANSLATE",
           "ROUTE_UNSUPPORTED", "build_artifacts", "route_of", "slug", "target_name", "unit_stub"]
