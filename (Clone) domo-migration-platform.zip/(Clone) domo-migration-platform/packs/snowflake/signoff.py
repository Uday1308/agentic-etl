# Ported from SNF2DBX-main/migration/signoff.py (LatentView internal): the checks table, the runbook and the workbook,
# rewired from the old run service to the migrator's batch report.
"""packs.snowflake.signoff - the sign-off pack and cut-over runbook of one batch (S12).

Built ONLY from evidence the batch recorded: the report (counts, rows, assembly, verify, parity), each unit's
``run.json`` (verify / equivalence / judges evidence) and the review decisions on file. A step with no evidence is
listed as ``not run`` and never as passed: the migrator does not deploy or load data, so ``deploy`` stays ``not run``
unless the report carries a ``deploy`` section (``{"status": "passed" | "failed" | ...}``, written by a deploy step).
No source text, SQL text or row value is read or written: names, statuses, caveat ids and aggregates only.

Files (``write``): ``cutover_runbook.md`` always; ``signoff.xlsx`` when ``openpyxl`` is importable, else one CSV per
sheet under ``csv/`` and ``signoff.md`` (the same tables); ``signoff.json`` (the checks, for the UI).
"""
from __future__ import annotations

import csv
import json
import pathlib
from datetime import UTC, datetime

NOT_RUN = "not run"
_PASS = {"passed", "passed with advisory differences"}


def _units_evidence(report: dict) -> list[dict]:
    """One record per translated unit: the evidence of its ``run.json`` (verify, equivalence, judges)."""
    out: list[dict] = []
    for row in report.get("etls", []):
        run_dir = row.get("run_dir")
        path = pathlib.Path(run_dir) / "run.json" if run_dir else None
        try:
            units = json.loads(path.read_text(encoding="utf-8")).get("units", []) if path and path.exists() else []
        except (OSError, ValueError):
            units = []
        for u in units:
            ev = u.get("evidence") or {}
            out.append({"asset": row.get("name") or row.get("etl_id"), "unit": u.get("unit_id"),
                        "origin": u.get("origin"), "status": u.get("status"),
                        "verify": (ev.get("verify") or {}), "equivalence": ev.get("equivalence") or {},
                        "judges": ev.get("judges") or [], "caveats": sorted({*(u.get("caveats") or [])})})
    return out


def decisions_of(rows: list[dict], feedback: pathlib.Path) -> list[dict]:
    """Review decisions on file for the gates the rows held (``<feedback>/<gate>.approval.json``)."""
    out: list[dict] = []
    for r in rows:
        for g in r.get("review_gates") or []:
            f = pathlib.Path(feedback) / f"{g.get('gate_id')}.approval.json"
            try:
                doc = json.loads(f.read_text(encoding="utf-8")) if f.exists() else None
            except (OSError, ValueError):
                doc = None
            if doc:
                out.append({"asset": r.get("name") or r.get("etl_id"), "gate": g.get("gate_id"),
                            "decision": "approved" if doc.get("approve") else "changes requested",
                            "reviewer": doc.get("reviewer") or "not recorded",
                            "decision_id": doc.get("decision_id") or ""})
    return out


def _state(label: str, status: str, detail: str = "") -> dict:
    return {"check": label, "status": status, "detail": detail}


def checks_of(report: dict, evidence: list[dict]) -> list[dict]:
    counts = report.get("counts") or {}
    bad = sum(int(counts.get(k) or 0) for k in ("failed", "unsupported", "blocked", "skipped"))
    waiting = int(counts.get("awaiting_review") or 0)
    out = [_state("Code converted", "passed" if not bad else f"{bad} unit(s) not converted",
                  f"{(report.get('summary') or {}).get('units_total', 0)} unit(s)"),
           _state("Reviews decided by a person", "passed" if not waiting else f"{waiting} pending")]
    ver = report.get("verify")
    if ver and ver.get("enabled"):
        by = ver.get("by_status") or {}
        st = "failed" if by.get("failed") else "passed" if by.get("passed") and not by.get("unverifiable") else \
            "unverifiable" if not by.get("passed") else "partly verified"
        out.append(_state("Converted code checked on Databricks (EXPLAIN / schema)", st,
                          ", ".join(f"{k} {v}" for k, v in sorted(by.items()))))
    else:
        out.append(_state("Converted code checked on Databricks (EXPLAIN / schema)", NOT_RUN))
    eq = [e["equivalence"].get("status") for e in evidence if e["equivalence"]]
    if eq:
        st = "differs (unexplained)" if "differs_unexplained" in eq else "passed"
        out.append(_state("Source / output equivalence (offline)", st,
                          ", ".join(f"{s} {eq.count(s)}" for s in sorted(set(eq)))))
    else:
        out.append(_state("Source / output equivalence (offline)", NOT_RUN))
    par = report.get("parity")
    if par:
        out.append(_state("Data parity (counts, checksums, column profiles)", str(par.get("status")),
                          par.get("reason") or ", ".join(f"{k} {v}" for k, v in (par.get("summary") or {}).items())))
    else:
        out.append(_state("Data parity (counts, checksums, column profiles)", NOT_RUN))
    dep = report.get("deploy") or {}
    out.append(_state("Deployed to Databricks", str(dep.get("status") or NOT_RUN)))
    known = (par or {}).get("boundaries_known", 0)
    out.append(_state("Data loaded", f"per ingestX record: boundary known for {known} table(s)" if known else NOT_RUN))
    gov = [r for r in report.get("rows", []) if r.get("route") == "governance"]
    out.append(_state("Protections attached (masks, row filters)",
                      "proposed to the access framework, not applied" if gov else "none in scope"))
    out.append(_state("Business sign-off", "pending - sign below"))
    return out


def ready(checks: list[dict]) -> bool:
    need = [c for c in checks if c["check"] not in ("Business sign-off", "Protections attached (masks, row filters)")]
    return all(c["status"] in _PASS or c["status"].startswith("per ingestX") for c in need)


def _sheets(report: dict, evidence: list[dict], decisions: list[dict], checks: list[dict]) -> dict[str, list[dict]]:
    par = report.get("parity") or {}
    return {
        "Summary": [{"Check": c["check"], "Status": c["status"], "Detail": c["detail"]} for c in checks]
                   + [{"Check": "Ready for cut-over", "Status": "yes" if ready(checks) else "no", "Detail": ""}],
        "Units": [{"Asset": r.get("name"), "Kind": r.get("kind"), "Route": r.get("route"), "Status": r.get("status"),
                   "Target": r.get("target") or "", "Reason": str(r.get("reason") or "")[:300]}
                  for r in report.get("rows", [])],
        "Verify": [{"Asset": e["asset"], "Unit": e["unit"], "Status": e["verify"].get("status", NOT_RUN),
                    "EXPLAIN": (e["verify"].get("explain") or {}).get("status", ""),
                    "Schema": (e["verify"].get("schema") or {}).get("status", ""),
                    "Reason": e["verify"].get("reason", "")} for e in evidence],
        "Equivalence and judges": [{"Asset": e["asset"], "Unit": e["unit"],
                                    "Equivalence": e["equivalence"].get("status", NOT_RUN),
                                    "Judges": ", ".join(sorted({j.get("id", "") for j in e["judges"]})),
                                    "Caveats": ", ".join(e["caveats"])} for e in evidence],
        "Parity": [{"Table": t["source"], "Target": t["target"], "Column": m["column"], "Metric": m["metric"],
                    "Blocking": "yes" if m["blocking"] else "advisory", "Snowflake": m["source"],
                    "Databricks": m["target"], "Match": "yes" if m["match"] else "NO"}
                   for t in par.get("tables", []) for m in t.get("metrics", [])]
                  + [{"Table": t["source"], "Target": t["target"], "Column": "", "Metric": t["status"],
                      "Blocking": "", "Snowflake": "", "Databricks": "", "Match": t.get("reason", "")}
                     for t in par.get("tables", []) if not t.get("metrics")],
        "Decisions": [{"Asset": d["asset"], "Gate": d["gate"], "Decision": d["decision"], "Reviewer": d["reviewer"]}
                      for d in decisions],
        "Not run": [{"Step": c["check"], "Detail": "no evidence recorded for this batch"} for c in checks
                    if c["status"] == NOT_RUN],
    }


def runbook(report: dict, checks: list[dict], created: str) -> str:
    key = (report.get("selection") or {}).get("key") or report.get("batch_run_id")
    lines = [f"# Cut-over runbook: {key}", "", f"Batch run `{report.get('batch_run_id')}` · prepared {created} UTC", "",
             "## Status", ""]
    lines += [f"- {c['check']}: **{c['status']}**" + (f" ({c['detail']})" if c["detail"] else "") for c in checks]
    is_ready = ready(checks)
    lines += ["", "Ready for cut-over." if is_ready else
              "**Not ready for cut-over.** Every check above must have run and passed, and the business owner "
              "must sign off.", ""]
    jobs = ((report.get("assembly") or {}).get("jobs")) or []
    lines += ["## Cut-over steps", "",
              "1. Freeze changes on the Snowflake objects in scope (pause Snowflake tasks and alerts).",
              "2. Run a final data load and re-run the parity check; every blocking metric must match.",
              "3. Grant Databricks access to the consuming groups (access proposals are approved in Governance).",
              "4. Unpause the Databricks jobs from this batch (see the assembly output).",
              "5. Repoint reports and downstream consumers to the Unity Catalog names.",
              "6. Keep Snowflake read-only until the agreed hyper-care period ends, then decommission.", ""]
    if jobs:
        lines += [f"Jobs in the batch assembly: {len(jobs)}", ""]
    notrun = [c for c in checks if c["status"] == NOT_RUN]
    if notrun:
        lines += ["## Steps with no evidence (not run)", ""] + [f"- {c['check']}" for c in notrun] + [""]
    pending = [r for r in report.get("rows", []) if r.get("status") == "awaiting_review"]
    if pending:
        lines += ["## Reviews still pending", ""] + [f"- {r.get('name')}" for r in pending] + [""]
    held = [t for t in (report.get("parity") or {}).get("tables", []) if t.get("status") in ("mismatched", "error")]
    if held:
        lines += ["## Parity differences", ""] + [f"- {t['source']}: {t['status']}" for t in held] + [""]
    lines += ["## Rollback", "", "Pause the Databricks jobs, repoint consumers back to Snowflake and resume the "
              "Snowflake tasks. Nothing in this pack drops data.", "",
              "## Sign-off", "", "| Role | Name | Date | Signature |", "|---|---|---|---|",
              "| Business owner |  |  |  |", "| Data owner |  |  |  |", "| Platform owner |  |  |  |", ""]
    return "\n".join(lines)


def _xlsx(sheets: dict[str, list[dict]], path: pathlib.Path) -> bool:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        return False
    wb = Workbook()
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name[:31])
        if not rows:
            ws.append(["Nothing recorded."])
            continue
        heads = list(rows[0])
        ws.append(heads)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in rows:
            ws.append(["" if r.get(h) is None else (r[h] if isinstance(r[h], (int, float)) else str(r[h]))
                       for h in heads])
        ws.freeze_panes = "A2"
    wb.save(path)
    return True


def write(report: dict, out_dir: pathlib.Path, decisions: list[dict] | None = None) -> dict:
    """Write the pack to ``out_dir`` and return ``{"files": [...], "checks": [...], "ready": bool, "format": ...}``."""
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    evidence = _units_evidence(report)
    checks = checks_of(report, evidence)
    created = datetime.now(UTC).isoformat(timespec="seconds")
    sheets = _sheets(report, evidence, decisions or [], checks)
    files = ["cutover_runbook.md"]
    (out / "cutover_runbook.md").write_text(runbook(report, checks, created), encoding="utf-8")
    if _xlsx(sheets, out / "signoff.xlsx"):
        files.append("signoff.xlsx")
        fmt = "xlsx"
    else:
        (out / "csv").mkdir(exist_ok=True)
        md = ["# Sign-off pack", ""]
        for name, rows in sheets.items():
            if rows:
                target = out / "csv" / f"{name.replace(' ', '_').lower()}.csv"
                with target.open("w", newline="", encoding="utf-8") as f:
                    w = csv.DictWriter(f, fieldnames=list(rows[0]))
                    w.writeheader()
                    w.writerows(rows)
                files.append(f"csv/{name.replace(' ', '_').lower()}.csv")
            md += [f"## {name}", ""] + ([" | ".join(rows[0]), " | ".join("---" for _ in rows[0])]
                                        + [" | ".join(str(r.get(h, "")) for h in rows[0]) for r in rows]
                                        if rows else ["Nothing recorded."]) + [""]
        (out / "signoff.md").write_text("\n".join(md), encoding="utf-8")
        files.append("signoff.md")
        fmt = "csv+markdown"
    info = {"files": files, "checks": checks, "ready": ready(checks), "format": fmt, "created": created,
            "dir": str(out)}
    (out / "signoff.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    return {k: v for k, v in info.items() if k != "dir"} | {"dir": str(out)}


__all__ = ["checks_of", "decisions_of", "ready", "runbook", "write"]
