"""packs.snowflake.assembly - ``assemble_batch`` (ADR 032 section 5, P3-09).

After the per-ETL runs, ``assemble_batch(pack, outcomes, manifest)`` builds, for the whole batch:

* ONE Lakeflow job per ROOT task graph (D-20): ``predecessors`` -> ``depends_on``, a finalizer -> ``run_if:
  ALL_DONE`` after every other task, a CRON / interval schedule -> a quartz schedule, a predecessor outside the batch
  -> an ``other_batch`` input (``external_predecessors``), ``WHEN SYSTEM$STREAM_HAS_DATA`` -> a table-update trigger
  with a review reason;
* the UDF / procedure registration order (callee before caller; the manifest order already follows ADR 030's
  ``feeds`` edges, this verifies it and repairs it);
* the governance artifacts from the manifest's ``governance[]`` (never applied here, always reviewed).

The result carries its own ``batch_assembly`` gate: never auto-approved when it holds governance artifacts or any
non-``mapped`` unit or review reason. Written as ``<volume>/batches/<key>/<run>/assembly/``.
"""
from __future__ import annotations

import json
import pathlib
import re
from dataclasses import dataclass, field
from typing import Any

from core.review import may_auto_approve, payload_hash
from packs.snowflake.handlers import Artifact, slug
from packs.snowflake.validators import validate

UDF_ENGINES = {"udf_sql", "udf_js", "udf_python", "udf_java", "udf_scala", "sql_procedure", "javascript_procedure",
               "snowpark_python", "snowpark_java", "snowpark_scala"}


@dataclass
class EtlOutcome:
    """What one translated ETL leaves for assembly (the runner builds it)."""

    etl_id: str
    etl_key: str
    engine: str
    name: str = ""
    asset_id: str = ""
    order: int = 0
    params: dict = field(default_factory=dict)
    status: str = "migrated"
    units: list[Any] = field(default_factory=list)          # translate.UnitResult
    artifacts: list[Artifact] = field(default_factory=list)


@dataclass
class _Unit:
    """The few unit facts assembly reads, rebuilt from a stored outcome (a resume does not re-run migrated ETLs)."""

    origin: str = "mapped"
    status: str = "resolved"
    review_caveats: list[str] = field(default_factory=list)
    calls: list[str] = field(default_factory=list)      # callee names only: a report never keeps SQL text

    @property
    def source_text(self) -> str:
        return " ".join(f"{c}(" for c in self.calls)


_CALL = re.compile(r"(\w+)\s*\(")


def outcome_to_dict(o: EtlOutcome) -> dict:
    """The JSON a report row keeps so a later ``--resume`` can still assemble this ETL (jobs, UDF order)."""
    return {"etl_id": o.etl_id, "etl_key": o.etl_key, "engine": o.engine, "name": o.name, "asset_id": o.asset_id,
            "order": o.order, "params": json.loads(json.dumps(o.params, default=str)), "status": o.status,
            "units": [{"origin": u.origin, "status": u.status, "review_caveats": list(u.review_caveats),
                       "calls": sorted(set(_CALL.findall(getattr(u, "source_text", "") or "")))} for u in o.units],
            "artifact_specs": [{"kind": a.kind, "name": a.name, "spec": a.spec} for a in o.artifacts if a.spec]}


def outcome_from_dict(d: dict) -> EtlOutcome:
    return EtlOutcome(str(d["etl_id"]), str(d["etl_key"]), str(d["engine"]), str(d.get("name") or ""),
                      str(d.get("asset_id") or ""), int(d.get("order") or 0), dict(d.get("params") or {}),
                      str(d.get("status") or "migrated"), [_Unit(**u) for u in d.get("units") or []],
                      [Artifact(a["kind"], a["name"], "", spec=a.get("spec")) for a in d.get("artifact_specs") or []])


@dataclass
class Assembly:
    jobs: list[dict] = field(default_factory=list)
    udf_order: list[str] = field(default_factory=list)
    governance: list[Artifact] = field(default_factory=list)
    review_reasons: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    origins: list[str] = field(default_factory=list)
    review_caveats: list[str] = field(default_factory=list)

    @property
    def auto_approvable(self) -> bool:
        if self.governance or self.review_reasons:
            return False
        ok, _ = may_auto_approve("sql", origins=self.origins, review_caveats=self.review_caveats)
        return ok

    def gate(self) -> dict:
        """The ``batch_assembly`` gate payload. ``auto_approvable`` False means a human must approve."""
        body = {"jobs": self.jobs, "udf_order": self.udf_order, "governance": [g.text for g in self.governance]}
        return {"kind": "batch_assembly", "payload_hash": payload_hash(body), "auto_approvable": self.auto_approvable,
                "jobs": [j["name"] for j in self.jobs], "udf_order": self.udf_order,
                "governance_count": len(self.governance), "review_reasons": self.review_reasons,
                "warnings": self.warnings}

    def write(self, directory: pathlib.Path | str) -> pathlib.Path:
        d = pathlib.Path(directory)
        (d / "jobs").mkdir(parents=True, exist_ok=True)
        for j in self.jobs:
            (d / "jobs" / f"{slug(j['name'])}.json").write_text(json.dumps(j, indent=1), encoding="utf-8")
        (d / "udf_order.json").write_text(json.dumps(self.udf_order, indent=1), encoding="utf-8")
        (d / "governance.sql").write_text(";\n".join(g.text for g in self.governance), encoding="utf-8")
        (d / "gate.json").write_text(json.dumps(self.gate(), indent=1), encoding="utf-8")
        return d


# ------------------------------------------------------------------------------------------- schedule helpers
def cron_to_quartz(expr: str) -> str | None:
    """Snowflake ``m h dom mon dow`` -> quartz ``0 m h dom mon dow`` with one of dom / dow as ``?``."""
    f = expr.split()
    if len(f) != 5:
        return None
    m, h, dom, mon, dow = f
    if dom == "*" and dow != "*":
        dom = "?"
    else:
        dow = "?" if dow == "*" else dow
    if dom == "?" and dow == "?":
        dow = "?"
    return f"0 {m} {h} {dom} {mon} {dow}"


def schedule_of(text: Any) -> tuple[dict | None, list[str]]:
    if not text or not isinstance(text, str):
        return None, []
    m = re.match(r"\s*USING\s+CRON\s+(.+?)\s+(\S+)\s*$", text, re.I)
    if m:
        q = cron_to_quartz(m.group(1))
        return ({"quartz_cron_expression": q, "timezone_id": m.group(2), "pause_status": "UNPAUSED"}, []) if q \
            else (None, [f"schedule {text!r} could not be converted to a cron expression"])
    m = re.match(r"\s*(\d+)\s*(?:M|MINUTES?)\s*$", text, re.I)
    if m:
        n = int(m.group(1))
        q = "0 0 * * * ?" if n == 60 else f"0 0/{n} * * * ?" if n < 60 else None
        return ({"quartz_cron_expression": q, "timezone_id": "UTC", "pause_status": "UNPAUSED"}, []) if q \
            else (None, [f"interval {text!r} has no cron equivalent"])
    return None, [f"schedule {text!r} is not CRON or a minute interval"]


def _as_list(v: Any) -> list[str]:
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            v = [x for x in re.split(r"[,\s]+", v) if x]
    return [str(x) for x in (v or [])]


def _simple(name: str) -> str:
    return str(name).split(".")[-1].strip('"').upper()


# ------------------------------------------------------------------------------------------- task graphs
def build_jobs(tasks: list[EtlOutcome]) -> tuple[list[dict], list[str], list[str]]:
    by_name = {_simple(t.name): t for t in tasks}
    info: dict[str, dict] = {}
    for t in tasks:
        rel = t.params.get("task_relations")
        rel = json.loads(rel) if isinstance(rel, str) and rel.strip().startswith("{") else (rel or {})
        preds = _as_list(t.params.get("predecessors") or rel.get("Predecessors"))
        fin_root = rel.get("FinalizedRootTaskName") or rel.get("FinalizedRootTask") or t.params.get("finalizer")
        info[_simple(t.name)] = {"preds": [_simple(p) for p in preds],
                                 "finalizes": _simple(fin_root) if isinstance(fin_root, str) and fin_root else None}
    roots: dict[str, str] = {}

    def root_of(n: str, seen: tuple = ()) -> str:
        i = info[n]
        if i["finalizes"]:
            return i["finalizes"] if i["finalizes"] in info else n
        for p in i["preds"]:
            if p in info and p not in seen:
                return root_of(p, (*seen, n))
        return n

    for n in info:
        roots[n] = root_of(n)
    jobs, reasons, warnings = [], [], []
    for root in sorted({r for r in roots.values()}):
        members = [n for n in info if roots[n] == root]
        members.sort(key=lambda n: by_name[n].order)
        ext: list[str] = []
        entries = []
        for n in members:
            t, i = by_name[n], info[n]
            deps = [p for p in i["preds"] if p in members]
            ext += [p for p in i["preds"] if p not in info]
            spec = next((a.spec["job_task"] for a in t.artifacts if a.spec and a.spec.get("job_task")), None)
            task_params = next((a.spec["parameters"] for a in t.artifacts if a.spec and a.spec.get("parameters")), None)
            body = ({k: v for k, v in spec.items() if k != "callee"} if spec else
                    {"sql_task": {"file": {"path": f"{t.etl_key}/{slug(n)}.sql"},
                                  "warehouse_id": "${var.warehouse_id}",
                                  **({"parameters": dict(task_params)} if task_params else {})}})
            entry: dict[str, Any] = {"task_key": slug(n), **body}
            if i["finalizes"]:
                entry["run_if"] = "ALL_DONE"
                deps = [m for m in members if m != n and not info[m]["finalizes"]]
            if deps:
                entry["depends_on"] = [{"task_key": slug(d)} for d in deps]
            entries.append(entry)
        rparams = by_name[root].params
        job: dict[str, Any] = {"name": by_name[root].name or root, "tasks": entries, "max_concurrent_runs": 1}
        sched, why = schedule_of(rparams.get("schedule"))
        if sched:
            job["schedule"] = sched
        job_reasons = list(why)
        cond = str(rparams.get("condition_text") or rparams.get("when") or "")
        if "STREAM_HAS_DATA" in cond.upper():
            wanted = [_simple(m) for m in re.findall(r"STREAM_HAS_DATA\s*\(\s*'([^']+)'", cond, re.I)]
            known = {k.upper(): v for k, v in (rparams.get("stream_tables") or {}).items()}
            tables = sorted({known[w] for w in wanted if w in known})
            job["trigger"] = {"table_update": {"table_names": tables, "condition": "ANY_UPDATED"}}
            if tables and len(tables) == len(set(wanted)):
                job_reasons.append("WHEN SYSTEM$STREAM_HAS_DATA -> table-update trigger (preview) on the stream's base "
                                   f"table(s) {tables}: confirm")
            else:
                job_reasons.append("WHEN SYSTEM$STREAM_HAS_DATA -> table-update trigger (preview): set the table names")
        if ext:
            job["external_predecessors"] = sorted(set(ext))
            job_reasons.append(f"predecessor(s) {sorted(set(ext))} are outside this batch (other_batch input)")
        problems = validate("job", json.dumps(job))
        job_reasons += [f"job spec: {p}" for p in problems]
        job["review_reasons"] = job_reasons
        reasons += [f"{job['name']}: {r}" for r in job_reasons]
        jobs.append(job)
    return jobs, reasons, warnings


# ------------------------------------------------------------------------------------------- UDF order
def udf_order(outcomes: list[EtlOutcome]) -> tuple[list[str], list[str]]:
    """Callee-first order of UDFs and procedures; ``warnings`` name every manifest-order violation that was repaired
    and every cycle."""
    objs = [o for o in sorted(outcomes, key=lambda x: x.order) if o.engine in UDF_ENGINES]
    names = {o.etl_id: _simple(o.name) for o in objs}
    text = {o.etl_id: " ".join(getattr(u, "source_text", "") for u in o.units).upper() for o in outcomes}
    deps = {o.etl_id: [p.etl_id for p in objs if p.etl_id != o.etl_id
                       and re.search(rf"\b{re.escape(names[p.etl_id])}\s*\(", text.get(o.etl_id, ""))]
            for o in objs}
    pos = {o.etl_id: i for i, o in enumerate(objs)}
    out: list[str] = []
    state: dict[str, int] = {}
    warnings: list[str] = []

    def visit(e: str) -> None:
        if state.get(e) == 2:
            return
        if state.get(e) == 1:
            warnings.append(f"cycle through {names[e]}")
            return
        state[e] = 1
        for d in deps[e]:
            if pos[d] > pos[e]:
                warnings.append(f"{names[d]} registered before its caller {names[e]} (manifest order repaired)")
            visit(d)
        state[e] = 2
        out.append(e)

    for o in objs:
        visit(o.etl_id)
    return out, sorted(set(warnings))


# ------------------------------------------------------------------------------------------- governance
def governance_artifacts(entries: list[dict]) -> tuple[list[Artifact], list[str]]:
    """Governance entries (masking / row access policies, tags, grants) never become pass-through statements (S7,
    ADR 034): the migrator emits NO governance SQL. Each entry is a PROPOSAL: the platform's deterministic translator
    (`srcintel.platform.governance.translate`) turns it into access intents (role predicates through the role
    mappings, tag-based policies expanded, projection policy -> mask to NULL, aggregation policy -> needs review,
    a table with a policy that cannot be translated -> blocked) and an approver applies them. A manifest `statement`
    is ignored here and reported, so nothing is ever deployed unprotected or unreviewed."""
    problems = []
    for e in entries or []:
        name = e.get("id") or e.get("name")
        stmt = str(e.get("statement") or e.get("databricks") or "").strip()
        extra = " (its statement was not run by the migrator)" if stmt else ""
        problems.append(f"governance entry {name} is proposed to the access framework{extra} (ADR 034)")
    return [], problems


def assemble_batch(pack: Any, outcomes: list[EtlOutcome], manifest: dict) -> Assembly:
    """Build the batch-level artifacts. ``pack`` is the Snowflake pack (kept for the ADR signature and future
    per-pack options)."""
    asm = Assembly()
    tasks = [o for o in outcomes if o.engine == "task" and o.status != "unsupported"]
    if tasks:
        asm.jobs, reasons, warns = build_jobs(tasks)
        asm.review_reasons += reasons
        asm.warnings += warns
    for entry in manifest.get("alerts") or []:          # S8 / catalogue 6.7: an alert is a PAUSED job + a SQL alert
        from packs.snowflake.objects import alert_job
        job, why = alert_job(entry)
        job["review_reasons"] = why
        asm.jobs.append(job)
        asm.review_reasons += [f"{job['name']}: {r}" for r in why]
    asm.udf_order, warns = udf_order(outcomes)
    asm.warnings += warns
    seen: dict[str, int] = {}
    for o in outcomes:
        if o.engine in UDF_ENGINES and o.status != "unsupported":
            key = re.sub(r"\(.*$", "", _simple(o.name)).upper()
            seen[key] = seen.get(key, 0) + 1
    asm.review_reasons += [f"{n.lower()}: {c} overloads share one Databricks routine name: rename them or merge the "
                           "bodies (the last one created replaces the others)"
                           for n, c in sorted(seen.items()) if c > 1]
    asm.governance, gprob = governance_artifacts(list(manifest.get("governance") or []))
    asm.warnings += gprob
    for o in outcomes:
        asm.origins += [u.origin if u.status == "resolved" else "unresolved" for u in o.units]
        asm.review_caveats += [c for u in o.units for c in u.review_caveats]
    asm.review_caveats = sorted(set(asm.review_caveats))
    return asm


__all__ = ["Assembly", "EtlOutcome", "assemble_batch", "build_jobs", "cron_to_quartz", "governance_artifacts",
           "outcome_from_dict", "outcome_to_dict", "schedule_of", "udf_order"]
