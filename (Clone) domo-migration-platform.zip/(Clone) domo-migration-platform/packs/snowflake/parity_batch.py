"""packs.snowflake.parity_batch - the batch-level parity gate (Q10, ADR 035 / 037).

After a batch whose tables were loaded (ingestX), ``scripts/run_batch.py`` compares source and target aggregates per
table (``packs.snowflake.parity``; no row data leaves either platform). This module is the glue:

* ``table_specs`` - which tables, with SOURCE column types (the batch catalogue), limited to the tables the data
  accelerator LANDED (``manifest["table_map"]``): outputs of rebuilt logic are not loaded data.
* the LOAD BOUNDARY - ``manifest["load_boundaries"]`` is ``{target table (lower): ISO instant}``, written by Discovery
  from the ingestX load record (``last_success_at`` of a published landing target). The Snowflake side is read AT that
  instant (time travel) so both sides describe the same data. A table with no boundary is ``unverifiable`` with the
  reason (never compared at "now", never a pass: hard rule 6).
* ``make_hook`` - the ``parity(batch_ctx)`` callable ``run_batch`` takes.
* the GATE - a table that ``mismatched`` or errored adds the escalate caveat ``SNW-PARITY-MISMATCH`` to the units that
  read or write it and holds the batch for review: a pseudo run ``__parity__`` with one ``validation`` gate whose id
  carries a hash of the mismatch set (a different set is a new review; an approved identical set is reused on resume).
  ``unverifiable`` / ``inconclusive`` hold nothing (nothing was claimed) but are listed in the report and the sign-off.

Quality hook (NOT built now): a ``parity`` rule type in ``packages/srcintel-quality`` wraps ``parity.run_parity`` with
the params documented in ``packs.snowflake.parity``; this module's ``make_hook`` is the only migrator-specific part.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
from collections.abc import Callable
from typing import Any

from core.review import AWAITING_REVIEW
from core.runner import GateDecision, HarnessGates, RunRecord
from packs.snowflake import parity as pr
from packs.snowflake.run import BatchContext, short_key

PARITY_ETL_ID = "__parity__"
MISMATCHED, ERROR = pr.MISMATCHED, pr.ERROR


def _lower(t: Any) -> str:
    return str(t).lower()


def table_specs(manifest: dict, batch: BatchContext) -> list[dict]:
    """Parity specs of the LANDED tables (those ingestX loaded). A landed table the catalogue does not describe is
    still listed (no columns) so the report can say it is unverifiable instead of dropping it."""
    landed = {_lower(v) for v in (manifest.get("table_map") or {}).values() if v}
    described = {_lower(s["target"]): s for s in pr.tables_from_context(batch.conversion, batch.table_map)}
    out: list[dict] = []
    for (db, schema, name), tgt in sorted(batch.table_map.items()):
        if _lower(tgt) not in landed:
            continue
        out.append(described.get(_lower(tgt)) or {"source": f"{db}.{schema}.{name}", "target": tgt, "columns": []})
    return out


def _unverifiable(t: dict, why: str) -> dict:
    return {"source": t["source"], "target": t["target"], "status": "unverifiable", "reason": why, "metrics": []}


def run_for_batch(manifest: dict, batch: BatchContext, source: Any, target: Any, config: pr.ParityConfig | None = None,
                  *, reason: str = "", record: Callable[[str, str, str], None] | None = None) -> dict:
    """The batch parity report: ``pr.run_parity`` over the tables whose load boundary AND columns are known; every
    other landed table is ``unverifiable`` with its reason."""
    specs = table_specs(manifest, batch)
    if not specs:
        return {"status": "unverifiable", "tables": [],
                "reason": "no landed table with a recorded target (nothing was loaded for this batch)"}
    bounds = {_lower(k): v for k, v in (manifest.get("load_boundaries") or {}).items() if v}
    ready: list[dict] = []
    skipped: list[dict] = []
    for t in specs:
        if not t["columns"]:
            skipped.append(_unverifiable(t, "no column types are described for this table"))
        elif _lower(t["target"]) not in bounds:
            skipped.append(_unverifiable(t, "the load boundary is unknown (no ingestX load record with a time)"))
        else:
            ready.append(t)
    if source is None or target is None:
        rep = pr.run_parity(source, target, specs, reason=reason)
    else:
        rep = pr.run_parity(source, target, ready, {t["source"]: bounds[_lower(t["target"])] for t in ready}, config,
                            record=record)
        rep["tables"] = [*rep["tables"], *skipped]
        got = {t["status"] for t in rep["tables"]}
        if MISMATCHED in got:
            rep["status"] = MISMATCHED
        elif got <= {pr.PASSED, pr.ADVISORY}:
            rep["status"] = "passed"
        elif got == {"unverifiable"}:
            rep["status"] = "unverifiable"
            rep["reason"] = "; ".join(sorted({t["reason"] for t in skipped}))
        else:
            rep["status"] = "inconclusive"
        rep["summary"] = {s: sum(1 for t in rep["tables"] if t["status"] == s) for s in sorted(got)}
    return {**rep, "boundaries_known": len(bounds)}


def make_hook(manifest: dict, source: Any, target: Any, config: pr.ParityConfig | None = None, *, reason: str = ""
              ) -> Callable[[BatchContext], dict]:
    return lambda batch: run_for_batch(manifest, batch, source, target, config, reason=reason)


# ---------------------------------------------------------------------------------------------------- evidence
def held_tables(report: dict | None) -> list[dict]:
    return [t for t in (report or {}).get("tables", []) if t.get("status") in (MISMATCHED, ERROR)]


def attach_to_rows(results: list[dict], units_by_id: dict[str, dict], report: dict | None) -> None:
    """Attach ``parity`` evidence to each unit row that reads or writes a checked table; a mismatch adds the escalate
    caveat ``SNW-PARITY-MISMATCH`` to its ``caveats`` (aggregates only, never values)."""
    ev = pr.evidence_by_target(report or {})
    for r in results:
        e = units_by_id.get(str(r.get("etl_id")))
        if not e:
            continue
        ios = (*(e.get("inputs") or []), *(e.get("outputs") or []))
        tables = {_lower(io["table"]) for io in ios if io.get("table")}
        mine = {t: ev[t] for t in sorted(tables) if t in ev}
        if not mine:
            continue
        r["parity"] = mine
        if any(v["status"] in (MISMATCHED, ERROR) for v in mine.values()):
            r["caveats"] = sorted({*(r.get("caveats") or []), pr.CAV_PARITY})


# ------------------------------------------------------------------------------------------------------- gate
def gate_payload(report: dict) -> dict:
    held = held_tables(report)
    rows = [{"name": t["source"], "target": t["target"], "status": "failed",
             "detail": (t.get("error_class") and f"error: {t['error_class']}")
             or ", ".join(f"{m['column']} {m['metric']}" for m in t.get("metrics", []) if not m["match"])[:300]}
            for t in held]
    reviewed = {"tables": [(t["source"], t["status"], t.get("boundary")) for t in held]}
    return {"results": rows, "judges": [], "reviewed": reviewed, "origins": ["manual"],
            "summary": {"kind": "parity", "held": len(held), "checked": len(report.get("tables", []))}}


def parity_unit(report: dict | None, *, volume: pathlib.Path, key: str, batch_run_id: str, gates: HarnessGates,
                accepted_by: str = "") -> dict | None:
    """The batch's ``__parity__`` unit row when a table mismatched / errored, else None. The row is
    ``awaiting_review`` (open gate) or ``migrated`` (the same mismatch set was approved earlier: ``gates`` carries the
    approval; ``accepted_by`` names the reviewer)."""
    if not held_tables(report):
        return None
    payload = gate_payload(report or {})
    digest = hashlib.sha256(json.dumps(payload["reviewed"], sort_keys=True, default=str).encode()).hexdigest()[:8]
    short = short_key(key)
    gid = f"gate-validation-parity-{short}-{digest}"
    run_id = f"run-parity-{short}-{batch_run_id.rsplit('-', 1)[-1]}"
    art = pathlib.Path(volume) / f"__parity__{short}" / run_id
    art.mkdir(parents=True, exist_ok=True)
    rec = RunRecord(PARITY_ETL_ID, f"__parity__{short}", run_id, art)
    decision: GateDecision = gates.decide("validation", payload, origins=["manual"],
                                          review_caveats=[pr.CAV_PARITY], gate_id=gid)
    rec.gate("validation", payload, decision)
    rec.completed.append("validation")
    rec.write_record()
    held = decision.status != "approved"
    n = len(held_tables(report))
    reason = (f"{n} table(s) differ between Snowflake and Databricks: a person decides (aggregates only, no values)"
              if held else f"{n} table(s) differ between source and target; accepted"
              + (f" by {accepted_by}" if accepted_by else ""))
    return {"order": 10 ** 6 + 1, "etl_id": PARITY_ETL_ID, "asset_id": None, "name": "Data parity (batch)",
            "batch_id": None, "status": AWAITING_REVIEW if held else "migrated", "reason": reason, "route": "parity",
            "kind": "parity", "unit_id": run_id, "run_id": run_id, "run_dir": str(art),
            "gate_id": gid if held else None,
            "review_gates": list(rec.held), "agents_completed": list(rec.completed), "failures": [], "artifacts": [],
            "inputs": [], "outputs": [], "target": None,
            **({"reused_approvals": ["validation"]} if not held else {})}


__all__ = ["PARITY_ETL_ID", "attach_to_rows", "gate_payload", "held_tables", "make_hook", "parity_unit",
           "run_for_batch", "table_specs"]
