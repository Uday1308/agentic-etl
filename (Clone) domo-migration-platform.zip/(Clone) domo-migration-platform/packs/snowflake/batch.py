"""packs.snowflake.batch - the batch-level steps ``scripts/run_batch.py`` calls for this pack (ADR 032 sections 5-6).

``prepare_batch`` is PHASE A of the two-phase batch: pure (no gate, no LLM): for every translatable ETL it runs the
same tier-0 function phase B runs, collects the units tier 0 could not resolve, makes ONE ``Transpiler`` call over
their union and stores each result in the tier-1 cache. It returns the ``BatchContext`` every phase-B run reads
(tier 1 comes ONLY from that cache; a unit not in it is ``skipped``). Lakebridge absent -> tier 1 ``unavailable``.

``finish_batch`` runs ``assemble_batch`` over the phase-B outcomes and writes ``<run>/assembly/`` with its
``batch_assembly`` gate (never auto-approved when it holds governance or any non-``mapped`` unit).
"""
from __future__ import annotations

import json
import pathlib
from typing import Any

from agents.cd_codegen.translate.chain import TranslationSettings
from agents.cd_codegen.translate.ports import SqlUnit, Transpiler
from agents.cd_codegen.translate.twophase import run_phase_a
from core.runner import GateDecision, HarnessGates
from packs.snowflake import contract as ct
from packs.snowflake import translate as tr
from packs.snowflake.assembly import EtlOutcome, assemble_batch
from packs.snowflake.code_units import procedure_return_type
from packs.snowflake.columns import build_catalogue
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.federation import foreign_catalog
from packs.snowflake.handlers import ROUTE_TRANSLATE, route_of
from packs.snowflake.overloads import plan as plan_overloads
from packs.snowflake.run import BatchContext, build_table_map, etl_key_of, make_unit_context, short_key


def load_payload(bundle: pathlib.Path, etl: dict) -> Any:
    ref = etl.get("definition")
    if not ref or not (bundle / ref).exists():
        return None
    return json.loads((bundle / ref).read_text(encoding="utf-8"))


def collect_procedure_returns(manifest: dict, bundle: pathlib.Path) -> dict[str, str]:
    """L4, the pre-pass: ``SOURCE FQN -> scalar RETURNS type`` of every SQL procedure in the batch that the scripting
    converter turns into a ``<name>__ret`` twin. A caller's ``v := (CALL p(..))`` converts only when ``p`` is here (it
    needs ``p``'s type and the OUT-parameter twin); every procedure is read BEFORE any is translated, so the order of
    the batch does not matter. A procedure that is unreadable, returns a table or returns nothing is simply absent."""
    out: dict[str, str] = {}
    for e in manifest.get("etls", []):
        if str(e.get("engine") or "") != "sql_procedure" or route_of(e)[0] != ROUTE_TRANSLATE:
            continue
        payload = load_payload(bundle, e)
        if payload is None:
            continue
        try:
            doc = ct.unit_doc(e, payload)
        except (ValueError, KeyError):
            continue
        found = procedure_return_type(doc)
        if found:
            out[found[0]] = found[1]
    return out


def collect_notebook_procedures(manifest: dict, bundle: pathlib.Path) -> dict[str, list[str]]:
    """L12, the pre-pass: ``SOURCE FQN (upper) -> parameter names`` of every JavaScript / Snowpark Python
    procedure of the batch. Those become NOTEBOOKS (their parameters are notebook widgets named like the procedure's
    parameters): a task that CALLs one is wired as a notebook task with its arguments under those names, and a SQL
    procedure that CALLs one is
    escalated (a SQL script cannot run a notebook). Unreadable definitions are simply absent."""
    out: dict[str, list[str]] = {}
    for e in manifest.get("etls", []):
        if str(e.get("engine") or "") not in ("javascript_procedure", "snowpark_python"):
            continue
        if "/proc" not in str(e.get("asset_id") or "").lower() and str(e.get("engine")) == "snowpark_python" \
                and "/func" in str(e.get("asset_id") or "").lower():
            continue
        payload = load_payload(bundle, e)
        if payload is None:
            continue
        try:
            doc = ct.unit_doc(e, payload)
        except (ValueError, KeyError):
            continue
        p = ct.parse_native_id(str(doc.get("asset_id") or ""))
        if p["db"] and p["name"]:
            out[f"{p['db']}.{p['schema']}.{p['name']}".upper()] = ct.param_names(doc)
    return out


def prepare_batch(manifest: dict, bundle: pathlib.Path, work: pathlib.Path, *, source_id: str = "",
                  transpiler: Transpiler | None = None, settings: TranslationSettings | None = None,
                  query: Any = None, source_columns: dict | None = None, default_catalog: str = "main",
                  capability_profile: str | None = None, verify: Any = None) -> BatchContext:
    settings = settings or TranslationSettings()
    table_map, target_map = build_table_map(manifest)
    # the handoff manifest carries the columns (and source types) of the tables it references: reuse them as the
    # catalogue when the caller gives none (X2); an explicit ``query`` / ``source_columns`` still wins
    columns = source_columns if source_columns is not None else (manifest.get("source_columns") or None)
    catalogue = build_catalogue(set(target_map.values()), query, source_columns=columns) \
        if (query is not None or columns) else None
    profile = capability_profile or (manifest.get("target") or {}).get("capability_profile")
    conversion = ConversionContext.build(source_parameters=manifest.get("source_parameters"), catalogue=catalogue,
                                         capability_profile=profile, pivot_values=manifest.get("pivot_values"),
                                         profiles=manifest.get("source_profiles"),
                                         source_objects=manifest.get("source_objects"))
    batch = BatchContext(table_map=table_map, target_map=target_map, catalogue=catalogue, settings=settings,
                         default_catalog=default_catalog, conversion=conversion, verify=verify)
    units: list[SqlUnit] = []
    batch.procedure_returns = collect_procedure_returns(manifest, bundle)
    batch.overloads = plan_overloads(manifest)
    batch.notebook_procs = collect_notebook_procedures(manifest, bundle)
    batch.federation_catalog = foreign_catalog(manifest.get("target"))
    batch.dynamic_sql_shim = str((manifest.get("target") or {}).get("dynamic_sql_shim") or "")
    for e in manifest.get("etls", []):
        if route_of(e)[0] != ROUTE_TRANSLATE:
            continue
        payload = load_payload(bundle, e)
        if payload is None:
            continue
        try:
            doc = ct.unit_doc(e, payload)
            ctx = make_unit_context(doc, short_key(etl_key_of(e, source_id)), batch)
            units += tr.phase_a_units(doc, ctx)
        except (ValueError, KeyError):       # a contract error surfaces at the ETL's standardization step (phase B)
            continue
    batch.tier1 = run_phase_a(transpiler, units, source_dialect=ct.SOURCE_DIALECT, work=work,
                              enabled=settings.lakebridge_enabled and "lakebridge" in settings.tiers,
                              batch_budget_s=settings.lakebridge_batch_budget_s)
    return batch


def finish_batch(manifest: dict, outcomes: list[EtlOutcome], out_dir: pathlib.Path, *,
                 gates: HarnessGates | None = None, pack: Any = None) -> dict:
    """Assemble, write ``assembly/`` and decide the ``batch_assembly`` gate (open unless auto-approvable)."""
    asm = assemble_batch(pack, outcomes, manifest)
    asm.write(pathlib.Path(out_dir) / "assembly")
    gate = asm.gate()
    gates = gates or HarnessGates()
    origins = ["mapped"] if asm.auto_approvable else ["manual"]
    d: GateDecision = gates.decide("cd_codegen", {"reviewed": {"hash": gate["payload_hash"]}}, origins=origins,
                                   review_caveats=[] if asm.auto_approvable else ["batch_assembly"],
                                   gate_id="gate-batch_assembly")
    return {**gate, "status": "approved" if d.status == "approved" else "open", "reason": d.reason,
            "path": str(pathlib.Path(out_dir) / "assembly")}


__all__ = ["finish_batch", "load_payload", "prepare_batch"]
