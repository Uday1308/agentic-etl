"""packs.snowflake.overloads - 6.12: overloaded UDFs (Unity Catalog has no overloading).

Snowflake allows ``F(NUMBER)`` and ``F(VARCHAR, NUMBER)`` side by side; Unity Catalog allows one function per name. The
batch pre-pass groups the UDFs of the manifest by ``(DB, SCHEMA, NAME)``; a group with several signatures is renamed BY
SIGNATURE (``f__number``, ``f__varchar_number``) and every call site is rewritten to the member whose argument count
matches. Two members with the same argument count cannot be told apart without the argument types: a call to such a
group is a validation problem (escalated), never a guess. Source names stay as they are; only the derived Databricks
names change.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from packs.snowflake import contract as ct

UDF_ENGINES = frozenset({"udf_sql", "udf_js", "udf_python", "udf_java", "udf_scala"})


@dataclass(frozen=True)
class Overloads:
    #: asset_id -> the renamed function name (only members of an overloaded group)
    by_asset: dict[str, str] = field(default_factory=dict)
    #: (DB, SCHEMA, NAME) upper -> {argument count: renamed name, or None when two members share the count}
    by_call: dict[tuple[str, str, str], dict[int, str | None]] = field(default_factory=dict)

    def __bool__(self) -> bool:
        return bool(self.by_asset)


def _base(type_text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", re.sub(r"\(.*", "", type_text.strip().lower())) or "x"


def suffix(types: list[str]) -> str:
    return "_".join(_base(t) for t in types) or "noargs"


def plan(manifest: dict) -> Overloads:
    groups: dict[tuple[str, str, str], list[tuple[str, list[str]]]] = {}
    for e in manifest.get("etls", []):
        if str(e.get("engine") or "") not in UDF_ENGINES:
            continue
        aid = str(e.get("asset_id") or "")
        p = ct.parse_native_id(aid)
        if not p["name"]:
            continue
        key = (p["db"].upper(), p["schema"].upper(), p["name"].upper())
        groups.setdefault(key, []).append((aid, [s.strip() for s in p["signature"].split(",") if s.strip()]))
    by_asset: dict[str, str] = {}
    by_call: dict[tuple[str, str, str], dict[int, str | None]] = {}
    for key, members in groups.items():
        if len({tuple(t) for _, t in members}) < 2:
            continue
        seen: dict[str, int] = {}
        arity: dict[int, str | None] = {}
        for aid, types in sorted(members):
            name = f"{key[2].lower()}__{suffix(types)}"
            seen[name] = seen.get(name, 0) + 1
            if seen[name] > 1:
                name = f"{name}_{seen[name]}"
            by_asset[aid] = name
            arity[len(types)] = None if len(types) in arity else name
        by_call[key] = arity
    return Overloads(by_asset, by_call)


__all__ = ["Overloads", "UDF_ENGINES", "plan", "suffix"]
