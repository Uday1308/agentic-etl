"""cd_codegen.md_extract — extract already-translated PySpark from an MD plan.

The MD Plan agent (blueprint §9.4) now emits fully-formed PySpark per step inside
the plan document. When that is the case, CD Codegen does not need to transpile from
the discovery table at all — it extracts the code the plan already contains, and only
falls back to the LLM for steps the plan left as prose instead of code.

This module is the deterministic parser for that plan format. It is pure (text in,
structured data out) so it is unit-testable without Spark, an LLM, or the filesystem.

Plan format (produced by build_static_sections_v2 / render_node_from_registry):

    ## 5. Step-by-Step PySpark Instructions

    ### Step s03 | `Add Formula 1` | `FORMULA`
    - **In:** `x_df` | **Out:** `df_add_formula_1_s03` | **Confidence:** `HIGH`

    ```python
    df_add_formula_1_s03 = ( ... )
    ```

    **Expressions:** | ... |          <- optional metadata tables, ignored

    ## 6. Output / Write Instructions

    - **Target:** `NAME` | mode=`overwrite`

    ```python
    ( df_x.write ... .saveAsTable('cat.sch.name') )
    ```

A step whose body contains no ```python block is "explanation instead of code" — it
is captured as prose and marked ``needs_llm`` for the AI fallback.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# ── plan grammar ───────────────────────────────────────────────────────────── #
_SECTION_RE = re.compile(r"^##\s+(\d+)\.\s", re.MULTILINE)
_STEP_HEADER_RE = re.compile(
    r"^###\s+Step\s+(?P<step>s\d+)\s*\|\s*`(?P<name>[^`]+)`\s*\|\s*`(?P<type>[^`]+)`\s*$",
    re.MULTILINE,
)
_OUT_RE = re.compile(r"\*\*Out:\*\*\s*`(?P<df>[^`]+)`")
_CONF_RE = re.compile(r"\*\*Confidence:\*\*\s*`(?P<conf>[^`]+)`")
_IN_RE = re.compile(r"\*\*In:\*\*\s*(?P<ins>.+?)\s*\|\s*\*\*Out:")
_PYBLOCK_RE = re.compile(r"```python\s*\n(?P<code>.*?)\n```", re.DOTALL)
_TARGET_RE = re.compile(
    r"^-\s*\*\*Target:\*\*\s*`(?P<name>[^`]+)`\s*\|\s*mode=`(?P<mode>[^`]+)`\s*$",
    re.MULTILINE,
)
# Section 2 rows: | `df_var` | `Dataset Name (may contain | pipes)` | `dataset_id` |
# parsed by backtick spans so pipes inside the name cell don't break it.
_SOURCE_ROW_RE = re.compile(r"\|\s*`([^`]+)`\s*\|\s*`([^`]+)`\s*\|\s*`([^`]+)`\s*\|")
_SAVE_RE = re.compile(r"\.saveAsTable\(\s*'(?P<table>[^']+)'\s*\)")
_SRCDF_RE = re.compile(r"^\s*(?P<df>[A-Za-z_]\w*)\s*$", re.MULTILINE)
_COVERAGE_RE = re.compile(
    r"\*\*(?P<py>\d+)/(?P<total>\d+)\s+transformations\s+Python-resolved\s*\(([\d.]+)%\)\*\*"
)


@dataclass(frozen=True)
class MdSource:
    df_var: str               # 'na_f_a_..._df'  (node-addressable key)
    dataset_name: str         # 'NA | F&A | ... | FEED'
    dataset_id: str           # DOMO dataSourceId


@dataclass(frozen=True)
class MdStep:
    step: str                 # 's03'
    name: str                 # 'Add Formula 1'
    node_type: str            # 'FORMULA'
    df_var: str               # 'df_add_formula_1_s03'  (node-addressable key)
    confidence: str           # 'HIGH' | 'MEDIUM' | 'LOW'
    inputs: tuple[str, ...]   # upstream df_vars
    code: str | None          # extracted PySpark, or None if the plan gave prose only
    prose: str                # body text (used as the LLM source when code is None)

    @property
    def needs_llm(self) -> bool:
        return self.code is None


@dataclass(frozen=True)
class MdWrite:
    target: str               # 'NA | F&A | ... | PROD'
    mode: str                 # 'overwrite' | 'append'
    source_df: str | None     # df_var being written
    table: str | None         # fully-qualified saveAsTable target
    code: str                 # the write block


@dataclass(frozen=True)
class MdExtract:
    dataflow_id: str
    sources: tuple[MdSource, ...]
    steps: tuple[MdStep, ...]
    writes: tuple[MdWrite, ...]
    coverage: str | None      # the raw "X/Y ... (Z%)" line, if present

    @property
    def llm_steps(self) -> list[MdStep]:
        return [s for s in self.steps if s.needs_llm]

    @property
    def code_steps(self) -> list[MdStep]:
        return [s for s in self.steps if not s.needs_llm]


class MdExtractError(RuntimeError):
    """Raised when the plan document can't be parsed into any steps."""


def _snake(name: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", name).strip("_").lower()
    return re.sub(r"_+", "_", s)


_IMPORTS_CELL = "\n".join([
    "from pyspark.sql import SparkSession",
    "from pyspark.sql import functions as F",
    "from pyspark.sql.types import (",
    "    DecimalType, DateType, DoubleType, LongType, StringType, TimestampType,",
    ")",
    "",
    "spark = SparkSession.builder.getOrCreate()",
])

_CELL_SEP = "\n\n# COMMAND ----------\n\n"


def _node_cell(nid: str, op: str, origin: str, code: str) -> str:
    return f"# [node: {nid}] op={op} origin={origin}\n{code}\n# [/node: {nid}]"


def assemble_artifact(ex: MdExtract, *, llm_code: dict[str, str] | None = None,
                      notebook: bool = True, source_catalog: str | None = None,
                      source_schema: str | None = None) -> str:
    """Emit the node-addressable artifact from an extract.

    The plan documents its **sources** in Section 2 but never emits read code, so
    each source becomes a synthesized ``origin=md op=SOURCE`` cell that reads the
    ingested table. The table is ``<source_catalog>.<source_schema>.<snake(name)>``
    (the mirror of how Section 6 names write targets); if catalog/schema are omitted
    the bare ``snake(name)`` is used and a TODO is left. Without these the generated
    steps would reference undefined dataframes.

    Each step then becomes a ``# [node: <df_var>] op=<type> origin=<md|ai>`` section,
    followed by the write blocks. ``llm_code`` supplies code for any prose-only step
    (keyed by step id); a prose-only step with no entry raises.

    ``notebook=True`` (default) emits Databricks notebook source format so the file
    imports into the workspace as a runnable notebook.
    """
    llm_code = llm_code or {}
    cells: list[str] = [_IMPORTS_CELL]

    for src in ex.sources:
        if source_catalog and source_schema:
            table = f"{source_catalog}.{source_schema}.{_snake(src.dataset_name)}"
            todo = ""
        else:
            table = _snake(src.dataset_name)
            todo = "  # TODO: qualify with your source catalog.schema"
        read = (f'{src.df_var} = spark.read.table("{table}"){todo}'
                f"\n# DOMO dataset: {src.dataset_name} ({src.dataset_id})")
        cells.append(_node_cell(src.df_var, "SOURCE", "md", read))

    for s in ex.steps:
        if s.code is not None:
            code, origin = s.code, "md"
        elif s.step in llm_code and llm_code[s.step].strip():
            code, origin = llm_code[s.step].strip(), "ai"
        else:
            raise MdExtractError(
                f"step {s.step} ({s.name}) is prose-only and no LLM code was supplied"
            )
        cells.append(_node_cell(s.df_var, s.node_type, origin, code))
    for w in ex.writes:
        cells.append(_node_cell(f"write_{_snake(w.target)}", "WRITE", "md", w.code))

    if notebook:
        header = (
            "# Databricks notebook source\n"
            "# MAGIC %md\n"
            f"# MAGIC # Generated PySpark — DOMO dataflow {ex.dataflow_id}\n"
            "# MAGIC Node-addressable: each cell is delimited by "
            "`# [node: <id>]` markers for the Classifier."
        )
        return header + _CELL_SEP + _CELL_SEP.join(cells) + "\n"

    # plain module
    preamble = (
        f'"""Generated PySpark for DOMO dataflow {ex.dataflow_id}. Node-addressable:\n'
        'each section is delimited by "# [node: <id>]" markers for the Classifier."""\n'
        + _IMPORTS_CELL
    )
    return "\n\n".join([preamble] + cells[1:]) + "\n"


def _section_bounds(md: str, number: int) -> tuple[int, int] | None:
    """Return (start, end) char offsets of the body of '## <number>. ...'."""
    start = None
    for m in _SECTION_RE.finditer(md):
        if int(m.group(1)) == number:
            start = m.end()
            # end = next top-level '## N.' section
            nxt = _SECTION_RE.search(md, m.end())
            end = nxt.start() if nxt else len(md)
            return start, end
    return None


def _first_python_block(text: str) -> str | None:
    m = _PYBLOCK_RE.search(text)
    return m.group("code").strip() if m else None


def extract_md_plan(md: str, dataflow_id: str = "") -> MdExtract:
    """Parse an MD plan document into sources + steps + write blocks. Deterministic."""
    sources: list[MdSource] = []
    sec2 = _section_bounds(md, 2)
    if sec2:
        # stop at the '## Dataset Schemas' subsection so schema fences aren't scanned
        body = md[sec2[0]:sec2[1]]
        cut = body.find("## Dataset Schemas")
        if cut != -1:
            body = body[:cut]
        for df_var, name, dsid in _SOURCE_ROW_RE.findall(body):
            if df_var == "df_var":            # skip the header row if it were backticked
                continue
            sources.append(MdSource(df_var=df_var, dataset_name=name, dataset_id=dsid))

    steps: list[MdStep] = []
    sec5 = _section_bounds(md, 5)
    if sec5:
        body = md[sec5[0]:sec5[1]]
        headers = list(_STEP_HEADER_RE.finditer(body))
        for i, h in enumerate(headers):
            region = body[h.end(): headers[i + 1].start() if i + 1 < len(headers) else len(body)]
            out_m = _OUT_RE.search(region)
            conf_m = _CONF_RE.search(region)
            in_m = _IN_RE.search(region)
            inputs: tuple[str, ...] = ()
            if in_m:
                inputs = tuple(re.findall(r"`([^`]+)`", in_m.group("ins")))
            code = _first_python_block(region)
            steps.append(MdStep(
                step=h.group("step"),
                name=h.group("name"),
                node_type=h.group("type"),
                df_var=(out_m.group("df") if out_m else h.group("step")),
                confidence=(conf_m.group("conf") if conf_m else "UNKNOWN"),
                inputs=inputs,
                code=code,
                prose="" if code else region.strip(),
            ))

    writes: list[MdWrite] = []
    sec6 = _section_bounds(md, 6)
    if sec6:
        body = md[sec6[0]:sec6[1]]
        targets = list(_TARGET_RE.finditer(body))
        for i, t in enumerate(targets):
            region = body[t.end(): targets[i + 1].start() if i + 1 < len(targets) else len(body)]
            code = _first_python_block(region) or ""
            save_m = _SAVE_RE.search(code)
            # source df = the bare-identifier line inside the write block (the df before .write)
            src = None
            for line in code.splitlines():
                s = line.strip()
                if s and s.isidentifier():
                    src = s
                    break
            writes.append(MdWrite(
                target=t.group("name"),
                mode=t.group("mode"),
                source_df=src,
                table=(save_m.group("table") if save_m else None),
                code=code,
            ))

    cov_m = _COVERAGE_RE.search(md)
    if not steps and not writes:
        raise MdExtractError(
            "no steps or write blocks found — is this an MD plan in the expected format? "
            "(expected a '## 5. Step-by-Step PySpark Instructions' section)"
        )
    return MdExtract(
        dataflow_id=dataflow_id,
        sources=tuple(sources),
        steps=tuple(steps),
        writes=tuple(writes),
        coverage=(cov_m.group(0).strip("* ") if cov_m else None),
    )
