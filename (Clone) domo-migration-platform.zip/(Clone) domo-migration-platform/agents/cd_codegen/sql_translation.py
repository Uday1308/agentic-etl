"""cd_codegen.sql_translation — the AI tail for tiles the SQL registry cannot render.

DOMO's tile vocabulary is closed and finite, so ``core.domo.tiles`` transpiles almost
all of it in plain Python. What is left is the genuine tail: a tile type nobody has
written a renderer for, or one whose configuration the renderer explicitly declined to
guess at. Those are the only calls made here, and each is asked about exactly one step.

One step per call, not a batch. The PySpark tail batches *expressions* — many short,
independent lines that merge by index. A SQL step is one whole CTE body with its own
input names and column contract; batching them would enlarge the model's job and make
one bad step poison its neighbours. One call per step keeps the blast radius to a
single CTE, and a step that still fails is left as the loud passthrough it already was
rather than filled with a guess.

Everything returned is marked ``origin=ai`` in the artifact's node marker, so a
reviewer can always tell which CTEs a model wrote.

On rejecting model output: every check here has to earn its place twice over, because a
false rejection is as damaging as a false acceptance. It silently drops the step back to
a passthrough, which looks identical to the model never having been asked. So the
structural checks run against MASKED sql (see ``_mask``) — a column called
``Update Date`` and a comment mentioning "create" are content, not DDL — and every
rejection records its reason.

Only ``core.domo.llm.LLMClient`` is used — never a raw endpoint (guide §14).
"""
from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass

from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.prompts import PromptLayers
from core.domo.schemas import HumanFeedback, Issue

POOL = "cd_translation"

#: Statements that must never appear in a CTE body — the artifact's whole promise is
#: that it only reads. Matched against masked sql so content cannot trip it.
_FORBIDDEN = re.compile(
    r"(?is)\b(insert|update|delete|merge|create|drop|alter|truncate|grant|revoke|copy)\b")

_FENCE = re.compile(r"```([A-Za-z0-9_+-]*)[^\S\r\n]*\r?\n(.*?)```", re.DOTALL)
_SQL_LANGS = {"", "sql", "sparksql", "spark-sql", "spark_sql", "hiveql", "postgresql"}
_REFUSAL = re.compile(r"^\s*--\s*CANNOT TRANSLATE:?\s*(.*)$", re.IGNORECASE | re.MULTILINE)
_STATEMENT_START = re.compile(r"^\s*(select|with|\()", re.IGNORECASE)

#: What each escalating tile type actually DOES, in plain English.
#:
#: Without this the model has to reverse-engineer DOMO's semantics from raw config
#: keys, and the keys mislead: ``keyField``/``valueField`` on a NormalizeAll read as
#: "the input column holding the key", when they are the names of columns the unpivot
#: CREATES. A model given only the JSON produces a plain projection that selects two
#: columns which do not exist — well-formed, confident, and the exact inverse of the
#: tile. The deterministic renderer already knows these semantics; this shares them.
TILE_SEMANTICS: dict[str, str] = {
    "NORMALIZEALL": (
        "DOMO 'Dynamic Unpivot'. Keeps the columns listed in `idFields` unchanged and "
        "UNPIVOTS EVERY OTHER COLUMN of the input into two NEW columns:\n"
        "  - a column named by `keyField`   holding the ORIGINAL COLUMN NAME\n"
        "  - a column named by `valueField` holding that column's VALUE\n"
        "`keyField` and `valueField` are OUTPUT names the tile creates. They are NOT "
        "columns of the input — do not select them from the input.\n"
        "One input row becomes one row per unpivoted column. Use `stack(n, 'ColA', "
        "`ColA`, 'ColB', `ColB`, ...) AS (`<keyField>`, `<valueField>`)`, enumerating "
        "every input column that is NOT in `idFields`."
    ),
    "UNPIVOT": "See NORMALIZEALL — same operation with an explicit column list.",
    "DYNAMICUNPIVOT": "See NORMALIZEALL.",
}


def semantics_for(op_type: str) -> str:
    return TILE_SEMANTICS.get(str(op_type or "").strip().upper().replace(" ", ""), "")


SQL_TRANSLATOR_BASE_PROMPT = """\
You translate ONE DOMO Magic ETL tile into ONE Spark SQL SELECT statement.

The statement becomes the body of a CTE in a larger query, so:
- Return a bare SELECT. Do NOT name the CTE, do NOT wrap it in parentheses, do NOT end
  with a semicolon, and do NOT return more than one statement.
- Read only from the input CTE names given below. They already exist in the query.
- Never invent a column that is not referenced in the tile configuration or produced
  by an input. If a needed column is not there, say so (see FAILURE below).
- Quote identifiers containing spaces or punctuation with backticks: `Period End Date`.
- Spark SQL dialect. Prefer explicit column lists over `SELECT *` when the tile
  changes the schema; use `SELECT *` when it does not.

Put the final answer in a ```sql fenced block. If you show your working first, put the
working in a separate block — the LAST sql block is taken as the answer.

FAILURE: if the tile configuration does not give you enough to translate it faithfully,
return a ```sql block containing exactly:
-- CANNOT TRANSLATE: <one line saying what is missing>
That is a useful answer. A plausible guess is not — this pipeline is compared against
DOMO row by row, and a wrong translation reads as a data bug, not as a bad translation.
"""


@dataclass
class TailTranslation:
    """One step a model translated, declined, or failed on."""
    step_id: str
    sql: str = ""
    refused: str = ""          # the model's stated reason, when it declined
    error: str = ""            # a transport or validation failure on our side
    raw: str = ""              # what the model actually said, for diagnosing a rejection

    @property
    def usable(self) -> bool:
        return bool(self.sql)

    @property
    def why_not(self) -> str:
        """One line explaining a non-answer, for a report."""
        if self.usable:
            return ""
        if self.refused:
            return f"model declined: {self.refused}"
        return self.error or "no answer"


class SqlTailTranslator:
    """Asks a model about each step the SQL tile registry could not render."""

    def __init__(self, llm: LLMClient, *, pool: str = POOL, schema_probe=None) -> None:
        """``schema_probe(cte_name) -> list[str] | None`` reports the columns an
        upstream CTE actually produces.

        Optional, but it is the difference between a translation and a guess for any
        tile whose escalation reason IS the unknown column set. Nothing in the tile
        configuration says what a dynamic unpivot has to unpivot; only the data does.
        Injected rather than imported because answering it needs a live engine, which
        this layer must not depend on.
        """
        self._llm = llm
        self._pool = pool
        self._schema_probe = schema_probe

    async def resolve_tail(
        self, build, *, config, user_prompt: str = "",
        feedback: list[HumanFeedback] | None = None,
        issues: list[Issue] | None = None,
        hard: list[str] | None = None,
    ) -> dict[str, TailTranslation]:
        """Translate every unresolved step in ``build``. Returns step_id -> result.

        Calls run concurrently; ``LLMClient.complete`` acquires the translation pool,
        so the fan-out is bounded without this code managing it.
        """
        pending = list(build.unresolved or [])
        if not pending:
            return {}
        results = await asyncio.gather(*(
            self._one(item, config=config, user_prompt=user_prompt,
                      feedback=feedback or [], issues=issues or [], hard=hard or [])
            for item in pending
        ))
        return {r.step_id: r for r in results}

    def build_prompt(self, item: dict) -> str:
        """The P4 base layer for one unresolved step. Exposed so a notebook can show
        exactly what was asked when an answer comes back unusable."""
        node = item.get("node") or {}
        op_type = str(node.get("type") or node.get("operation_type") or "unknown")
        props = json.dumps(node.get("properties") or {}, indent=2, default=str)[:3000]
        inputs = list(item.get("inputs") or [])

        parts = [
            SQL_TRANSLATOR_BASE_PROMPT,
            f"\n\nTile type : {op_type}",
            f"\nTile name : {item.get('name', '')}",
            f"\nInput CTEs: {', '.join(inputs) or '(none — this step has no upstream)'}",
            f"\nWhy the deterministic transpiler could not do it: "
            f"{'; '.join(item.get('reasons') or []) or 'unknown'}",
        ]

        meaning = semantics_for(op_type)
        if meaning:
            parts.append(f"\n\nWHAT THIS TILE DOES:\n{meaning}\n")

        schema = self._schema_of(inputs)
        if schema:
            parts.append(
                "\n\nCOLUMNS AVAILABLE IN THE INPUT (exact names, already sanitized to "
                "match the source tables — use these spellings verbatim):\n" + schema
                + "\nEvery column you reference must appear above, or be one this tile "
                  "creates. There is no other column.\n")
        else:
            parts.append(
                "\n\nThe input's column list could not be determined. If the translation "
                "depends on knowing it, say so via CANNOT TRANSLATE rather than guessing "
                "at column names.\n")

        parts.append(f"\nTile configuration:\n{props}\n")
        return "".join(parts)

    def _schema_of(self, inputs: list[str]) -> str:
        if not self._schema_probe:
            return ""
        blocks = []
        for cte in inputs:
            try:
                cols = self._schema_probe(cte)
            except Exception:                                # noqa: BLE001
                cols = None
            if cols:
                listed = "\n".join(f"    - `{c}`" for c in cols)
                blocks.append(f"  {cte} ({len(cols)} columns):\n{listed}")
        return "\n".join(blocks)

    async def _one(self, item: dict, *, config, user_prompt: str,
                   feedback: list[HumanFeedback], issues: list[Issue],
                   hard: list[str]) -> TailTranslation:
        step_id = str(item.get("step") or "")
        layers = PromptLayers(base=self.build_prompt(item), user_prompt=user_prompt,
                              human_feedback=feedback, agent_feedback=issues,
                              hard_constraints=hard)
        try:
            result = await self._llm.complete(Role.GENERATOR, layers,
                                              pool=self._pool, config=config)
        except Exception as exc:                            # noqa: BLE001
            return TailTranslation(step_id=step_id, error=f"{type(exc).__name__}: {exc}")
        out = _validate(step_id, extract_sql(result.raw_text))
        out.raw = result.raw_text or ""
        return out


def _mask(sql: str) -> str:
    """Blank out comments, string literals and backtick-quoted identifiers.

    Keyword checks must see SQL *structure*, not content. Without this, a column named
    ``Update Date`` or a trailing comment saying "create one row per currency" reads as
    DDL, and a correct translation is thrown away — silently, because the step just
    falls back to a passthrough.
    """
    out: list[str] = []
    i, n = 0, len(sql)
    while i < n:
        two = sql[i:i + 2]
        if two == "--":
            nl = sql.find("\n", i)
            i = n if nl == -1 else nl
            continue
        if two == "/*":
            end = sql.find("*/", i)
            i = n if end == -1 else end + 2
            continue
        c = sql[i]
        if c in "\"'`":
            j = i + 1
            while j < n:
                if sql[j] == "\\":
                    j += 2
                    continue
                if sql[j] == c:
                    break
                j += 1
            out.append(" ")
            i = j + 1
            continue
        out.append(c)
        i += 1
    return "".join(out)


def _looks_like_a_statement(body: str) -> bool:
    return bool(_STATEMENT_START.match(_mask(body).strip()))


def extract_sql(text: str) -> str:
    """Pull the SQL out of a model response.

    Reasoning models routinely show a shape, an example, or their working in one fenced
    block and the answer in another, so every block is considered and the LAST one that
    parses as a statement wins. Taking the first block blindly is how a good answer gets
    read as prose and discarded.
    """
    text = text or ""
    blocks = _FENCE.findall(text)
    if not blocks:
        return text.strip()

    for _lang, body in blocks:                  # a refusal anywhere is the answer
        if _REFUSAL.search(body):
            return body.strip()

    tagged = [b for lang, b in blocks if lang.lower() in _SQL_LANGS]
    candidates = tagged or [b for _, b in blocks]
    for body in reversed(candidates):
        if _looks_like_a_statement(body):
            return body.strip()
    return candidates[-1].strip()


def _validate(step_id: str, sql: str) -> TailTranslation:
    """Accept only something that can serve as a CTE body; always say why not.

    A single statement beginning with SELECT is read-only in Spark SQL, so the start
    check plus the single-statement check are what actually enforce the read-only
    promise. The keyword scan is defence in depth on top of those, not the primary
    guard — which is why it can afford to run on masked text.
    """
    if not sql:
        return TailTranslation(step_id=step_id, error="model returned nothing usable")

    refusal = _REFUSAL.search(sql)
    if refusal:
        return TailTranslation(step_id=step_id,
                               refused=refusal.group(1).strip() or "no reason given")

    masked = _mask(sql).strip()
    if not masked:
        return TailTranslation(step_id=step_id, error="response contained only comments")
    if not _STATEMENT_START.match(masked):
        first = (masked.splitlines() or [masked])[0][:60]
        return TailTranslation(step_id=step_id,
                               error=f"not a SELECT — starts with {first!r}")
    body = masked.rstrip().rstrip(";")
    if ";" in body:
        return TailTranslation(step_id=step_id, error="contains more than one statement")
    hit = _FORBIDDEN.search(body)
    if hit:
        return TailTranslation(
            step_id=step_id,
            error=f"contains a forbidden {hit.group(1).upper()} statement")
    return TailTranslation(step_id=step_id, sql=sql.rstrip().rstrip(";").rstrip())


__all__ = [
    "POOL",
    "TILE_SEMANTICS",
    "SQL_TRANSLATOR_BASE_PROMPT",
    "SqlTailTranslator",
    "TailTranslation",
    "extract_sql",
    "semantics_for",
]
