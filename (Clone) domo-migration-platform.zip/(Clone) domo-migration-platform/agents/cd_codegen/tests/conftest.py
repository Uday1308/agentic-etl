"""Re-export the shared core test fixtures for the co-located agent tests.

Agent tests live beside their agent (blueprint §7) but build on the same fakes as
the core contract suite — one source of truth in tests/conftest.py.
"""
from conftest import FakeObservability, TrackingConcurrency, cfg, make_caller, obs, ts_iso  # noqa: F401
