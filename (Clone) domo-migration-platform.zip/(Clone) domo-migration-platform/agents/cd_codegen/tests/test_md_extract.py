"""Contract tests for the MD-plan code extractor and the MD-sourced generator."""
from __future__ import annotations

import ast

import pytest

from agents.cd_codegen.assembly import CodeAssembler
from agents.cd_codegen.md_extract import (
    MdExtractError,
    assemble_artifact,
    extract_md_plan,
)
from agents.cd_codegen.md_generator import MdPlanCodeGenerator
from agents.cd_codegen.translation import ExpressionTranslator
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from tests.conftest import cfg  # type: ignore

# a compact but faithful slice of the real plan format
_PLAN = """\
# ETL Migration: demo — DataFlow 42

## 2. Source Tables

| df_var | Dataset Name | Dataset ID |
|---|---|---|
| `a_df` | `NA | F&A | Alpha | FEED` | `id-aaa` |
| `b_df` | `NA | F&A | Beta | TEMP` | `id-bbb` |
## Dataset Schemas

### `NA | F&A | Alpha | FEED` (`id-aaa`)

```StructType([StructField('k', StringType(), True)])
```

## 5. Step-by-Step PySpark Instructions

### Step s01 | `Join Data 2` | `JOIN`
- **In:** `a_df`, `b_df` | **Out:** `df_join_data_2_s01` | **Confidence:** `HIGH`

```python
df_join_data_2_s01 = a_df.join(b_df, on='k', how='left')
```

**Join Keys:**

| Left | Right |
|---|---|
| k | k |

### Step s02 | `Add Formula 1` | `FORMULA`
- **In:** `df_join_data_2_s01` | **Out:** `df_add_formula_1_s02` | **Confidence:** `HIGH`

```python
df_add_formula_1_s02 = df_join_data_2_s01.withColumn('Period End Date', F.last_day(F.col('Date')))
```

## 6. Output / Write Instructions

- **Target:** `NA | F&A | Demo Out | PROD` | mode=`overwrite`

```python
(
    df_add_formula_1_s02
    .write
    .format('delta')
    .mode('overwrite')
    .saveAsTable('dev_test.migrated_output.na_f_a_demo_out_prod')
)
```

## 9. Python vs. LLM Coverage Report

**2/2 transformations Python-resolved (100.0%)**
"""

# a plan where one step is prose-only (no python block) -> needs LLM
_PLAN_WITH_PROSE = """\
## 5. Step-by-Step PySpark Instructions

### Step s01 | `Add Formula 1` | `FORMULA`
- **In:** `src_df` | **Out:** `df_add_formula_1_s01` | **Confidence:** `HIGH`

```python
df_add_formula_1_s01 = src_df.withColumn('x', F.lit(1))
```

### Step s02 | `Weird Tile` | `CUSTOM`
- **In:** `df_add_formula_1_s01` | **Out:** `df_weird_s02` | **Confidence:** `LOW`
- ⚠ Complex expression/logic — verify output carefully

This node applies a proprietary scoring transform that could not be auto-translated.
Assign the scored result to df_weird_s02 using the upstream dataframe.
"""


def test_extract_parses_sources_with_pipes_in_names():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    assert [s.df_var for s in ex.sources] == ["a_df", "b_df"]
    assert ex.sources[0].dataset_name == "NA | F&A | Alpha | FEED"   # pipes preserved
    assert ex.sources[0].dataset_id == "id-aaa"


def test_assemble_synthesizes_source_reads():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    art = assemble_artifact(ex, source_catalog="cat", source_schema="bronze")
    assert 'a_df = spark.read.table("cat.bronze.na_f_a_alpha_feed")' in art
    assert 'b_df = spark.read.table("cat.bronze.na_f_a_beta_temp")' in art
    # sources are node-addressable and precede the steps that use them
    sections = CodeAssembler.split_sections(art)
    assert "a_df" in sections and "b_df" in sections
    assert art.index("# [node: a_df]") < art.index("# [node: df_join_data_2_s01]")
    assert ast.parse(art) is not None


def test_assemble_source_reads_todo_when_unqualified():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    art = assemble_artifact(ex)              # no catalog/schema
    assert 'a_df = spark.read.table("na_f_a_alpha_feed")  # TODO' in art
    assert ast.parse(art) is not None


def test_extract_parses_steps_writes_and_coverage():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    assert [s.step for s in ex.steps] == ["s01", "s02"]
    assert [s.df_var for s in ex.steps] == ["df_join_data_2_s01", "df_add_formula_1_s02"]
    assert ex.steps[0].node_type == "JOIN" and ex.steps[0].inputs == ("a_df", "b_df")
    assert ex.steps[0].code.startswith("df_join_data_2_s01 = a_df.join")
    assert len(ex.writes) == 1
    assert ex.writes[0].source_df == "df_add_formula_1_s02"
    assert ex.writes[0].table == "dev_test.migrated_output.na_f_a_demo_out_prod"
    assert "100.0%" in ex.coverage
    assert ex.llm_steps == []            # every step had code


def test_extract_flags_prose_only_step_for_llm():
    ex = extract_md_plan(_PLAN_WITH_PROSE)
    assert [s.needs_llm for s in ex.steps] == [False, True]
    prose_step = ex.llm_steps[0]
    assert prose_step.step == "s02" and prose_step.code is None
    assert "proprietary scoring" in prose_step.prose


def test_assemble_emits_databricks_notebook_source():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    art = assemble_artifact(ex)                               # notebook=True by default
    assert art.splitlines()[0] == "# Databricks notebook source"   # workspace notebook marker
    assert "\n# COMMAND ----------\n" in art                 # cell separators present
    assert ast.parse(art) is not None                        # still valid Python
    sections = CodeAssembler.split_sections(art)             # still node-addressable
    assert "df_join_data_2_s01" in sections and "df_add_formula_1_s02" in sections
    # one cell per node + imports cell + header cell
    assert art.count("# COMMAND ----------") == len(ex.sources) + len(ex.steps) + len(ex.writes) + 1


def test_assemble_plain_module_when_notebook_false():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    art = assemble_artifact(ex, notebook=False)
    assert not art.startswith("# Databricks notebook source")
    assert "# COMMAND ----------" not in art
    assert ast.parse(art) is not None


def test_assemble_is_node_addressable_and_valid_python():
    ex = extract_md_plan(_PLAN, dataflow_id="42")
    art = assemble_artifact(ex)
    assert ast.parse(art) is not None                         # syntactically valid
    sections = CodeAssembler.split_sections(art)              # Classifier's own splitter
    assert "df_join_data_2_s01" in sections and "df_add_formula_1_s02" in sections
    assert any(k.startswith("write_") for k in sections)      # write block addressable
    assert "origin=md" in art


def test_assemble_raises_if_prose_step_has_no_llm_code():
    ex = extract_md_plan(_PLAN_WITH_PROSE)
    with pytest.raises(MdExtractError, match="prose-only"):
        assemble_artifact(ex)                                 # s02 has no code and none supplied


def test_extract_rejects_non_plan_text():
    with pytest.raises(MdExtractError, match="no steps"):
        extract_md_plan("# Just a heading\n\nsome prose, no sections")


# --- generator wiring ------------------------------------------------------- #
def _llm(obs, caller):
    return LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="gen"),
                                        "evaluator": EndpointSpec(endpoint="eval")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=__import__("tests.conftest", fromlist=["TrackingConcurrency"]).TrackingConcurrency(),
        observability=obs, caller=caller,
    )


class _Store:
    def __init__(self):
        self.writes = []

    def write(self, dataflow_id, iteration, content):
        self.writes.append((dataflow_id, iteration, content))
        return f"/fake/{dataflow_id}/cd/etl_{dataflow_id}_v{iteration}.py"


async def test_md_generator_all_code_no_llm(obs):
    """The happy path (like cms_8099): every step has code -> zero model calls."""
    calls = []

    def caller(spec, prompt, response_schema, timeout_s):
        calls.append(prompt)
        return RawCompletion(text="{}")
    store = _Store()
    gen = MdPlanCodeGenerator(ExpressionTranslator(_llm(obs, caller)), store)
    state = {"dataflow_id": "42", "feedback": {}, "md_plan": {"gen": {"artifact": _PLAN}}}
    res = await gen.generate(state, cfg(dataflow_id="42"))

    assert res.meta["counts"] == {"sources": 2, "steps": 2, "writes": 1, "from_md": 2, "from_llm": 0}
    assert calls == []                                        # no LLM used at all
    assert set(res.node_keys) == {"a_df", "b_df", "df_join_data_2_s01", "df_add_formula_1_s02"}
    assert ast.parse(res.artifact) is not None
    assert store.writes and store.writes[0][0] == "42"


async def test_md_generator_llm_fills_prose_step(obs):
    """A prose-only step is filled via the LLM fallback and marked origin=ai."""
    def caller(spec, prompt, response_schema, timeout_s):
        if '"verdict"' in prompt:
            return RawCompletion(text='{"verdict":"pass","confidence":0.9,"issues":[],"summary":"ok"}')
        # single prose step -> one pending line; return code positionally
        return RawCompletion(text="## Step 0\n```python\ndf_weird_s02 = df_add_formula_1_s01\n```")
    gen = MdPlanCodeGenerator(ExpressionTranslator(_llm(obs, caller)), _Store())
    state = {"dataflow_id": "9", "feedback": {}, "md_plan": {"gen": {"artifact": _PLAN_WITH_PROSE}}}
    res = await gen.generate(state, cfg(dataflow_id="9"))

    assert res.meta["counts"]["from_llm"] == 1 and res.meta["counts"]["from_md"] == 1
    assert res.meta["origins"]["df_weird_s02"] == "ai"
    assert "df_weird_s02 = df_add_formula_1_s01" in res.artifact
    assert ast.parse(res.artifact) is not None


async def test_md_generator_requires_a_plan(obs):
    gen = MdPlanCodeGenerator(ExpressionTranslator(_llm(obs, lambda *a: RawCompletion(text="{}"))), _Store())
    with pytest.raises(MdExtractError, match="no MD plan"):
        await gen.generate({"dataflow_id": "1", "feedback": {}}, cfg(dataflow_id="1"))
