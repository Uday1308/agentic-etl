"""SQL generation contracts (agents.cd_codegen.sql_generator).

This path had no tests at all while it lived in scripts/local_dryrun.py. The two that
matter most are the ones about *not lying*: an untranslatable tile must be impossible
to mistake for a translation, and a target that cannot be assembled must be reported
rather than dropped. A silent stand-in produces plausible wrong numbers, which is the
failure mode this platform exists to prevent.
"""
from __future__ import annotations

import json
import pathlib

import pytest

from agents.cd_codegen.sql_generator import (
    FailedArtifact,
    SourceSchemaError,
    build_sql,
    generate_sql,
    source_columns_from_spark,
    source_coverage,
)
from core.contracts.standardized import to_planner_dataflow

REPO = pathlib.Path(__file__).resolve().parents[3]
EXPORT = REPO / "8099_standardized.json"


def dataflow(**over) -> dict:
    """A three-tile flow: source -> formula -> sink."""
    body = {
        "dataflow_id": "1",
        "nodes": [
            {"id": "n1", "name": "feed", "type": "source", "category": "SOURCE",
             "properties": {"datasetName": "feed", "dataSourceId": "d1"}},
            {"id": "n2", "name": "Add Formula", "type": "formula",
             "category": "TRANSFORMATION",
             "properties": {"expressions": [{"outputColumn": "up",
                                             "expression": "UPPER(`a`)"}]}},
            {"id": "n3", "name": "out", "type": "sink", "category": "TARGET",
             "properties": {"datasetName": "out", "write_mode": "REPLACE"}},
        ],
        "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
    }
    body.update(over)
    return body


def test_one_artifact_per_target_ending_in_a_select():
    gen = generate_sql(dataflow(), dataflow_id="1", dataflow_name="demo",
                       materialize=False)
    assert len(gen.artifacts) == 1
    sql = gen.succeeded[0].sql
    assert "WITH" in sql and "CREATE OR REPLACE TABLE" not in sql
    assert not sql.rstrip().endswith(";")


def test_materialize_adds_the_create_prefix():
    gen = generate_sql(dataflow(), dataflow_id="1", materialize=True)
    assert "CREATE OR REPLACE TABLE" in gen.succeeded[0].sql


def test_every_step_is_node_addressable():
    """The Classifier partitions on these markers; without them it cannot split
    the artifact into layers."""
    gen = generate_sql(dataflow(), dataflow_id="1", materialize=False)
    sql = gen.succeeded[0].sql
    assert "-- [node:" in sql
    assert gen.succeeded[0].node_keys


def test_an_untranslatable_tile_is_shouted_about_not_guessed():
    df = dataflow(nodes=dataflow()["nodes"][:1] + [
        {"id": "n2", "name": "Mystery", "type": "SomeUnknownTile",
         "category": "TRANSFORMATION", "properties": {"whatever": 1}},
        dataflow()["nodes"][2]])
    gen = generate_sql(df, dataflow_id="1", materialize=False)
    sql = gen.succeeded[0].sql
    assert "UNRESOLVED STEP — DO NOT TRUST RESULTS DOWNSTREAM" in sql
    assert "NOT a translation" in sql
    assert gen.escalated_steps == ["s01"]


def test_an_unassemblable_target_is_reported_not_dropped():
    """A target whose final CTE does not exist cannot produce SQL. The artifact must
    still come back carrying the error, or the run looks like it emitted fewer targets
    than the dataflow has."""
    df = dataflow(edges=[{"from": "n1", "to": "n2"}])      # n3 has no input
    gen = generate_sql(df, dataflow_id="1", materialize=False)
    assert len(gen.artifacts) == 1
    failed = gen.failed
    assert len(failed) == 1 and isinstance(failed[0], FailedArtifact)
    assert failed[0].error and failed[0].target == "out"


def test_steps_are_matched_to_tiles_by_id_not_name():
    """DOMO permits two tiles to share a display name. Matching on name renders one
    tile's logic under the other's id — silently, and with plausible output."""
    df = dataflow(nodes=[
        dataflow()["nodes"][0],
        {"id": "n2", "name": "Same Name", "type": "formula", "category": "TRANSFORMATION",
         "properties": {"expressions": [{"outputColumn": "first", "expression": "1"}]}},
        {"id": "n4", "name": "Same Name", "type": "formula", "category": "TRANSFORMATION",
         "properties": {"expressions": [{"outputColumn": "second", "expression": "2"}]}},
        dataflow()["nodes"][2],
    ], edges=[{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n4"},
              {"from": "n4", "to": "n3"}])
    sql = generate_sql(df, dataflow_id="1", materialize=False).succeeded[0].sql
    assert "first" in sql and "second" in sql      # both tiles rendered, not one twice


def test_an_as_of_cutoff_is_applied_at_the_sources():
    """Clamping only at the end would leave later batches contributing to every
    intermediate aggregate."""
    sql = generate_sql(dataflow(), dataflow_id="1", materialize=False,
                       as_of="2026-01-01 00:00:00").succeeded[0].sql
    assert "as-of cutoff" in sql
    assert "`_BATCH_LAST_RUN_` IS NULL OR" in sql   # null-safe: nulls are KEPT


def test_a_custom_as_of_column_is_honoured():
    sql = generate_sql(dataflow(), dataflow_id="1", materialize=False,
                       as_of="2026-01-01 00:00:00",
                       as_of_column="ingested_at").succeeded[0].sql
    assert "`ingested_at` IS NULL OR" in sql


def test_catalogs_and_schemas_route_the_reads_and_writes():
    gen = generate_sql(dataflow(), dataflow_id="1", materialize=True,
                       source_catalog="src_cat", source_schema="src_sch",
                       target_catalog="tgt_cat", target_schema="tgt_sch")
    sql = gen.succeeded[0].sql
    assert "src_cat.src_sch.feed" in sql
    assert "tgt_cat.tgt_sch.out" in sql


def test_a_dataflow_with_no_nodes_fails_loud():
    with pytest.raises(ValueError, match="no nodes"):
        generate_sql({"nodes": [], "edges": []}, dataflow_id="1")


def test_build_sql_takes_its_nodes_explicitly():
    """The nodes used to be smuggled onto the build object as an attribute, which made
    the dependency invisible and easy to forget. Passing none must degrade loudly (every
    step escalates), not render silently wrong SQL."""
    from agents.md_plan.render import PlanRenderer
    build = PlanRenderer(dialect="sql").build(dataflow(), dataflow_id="1")
    arts = build_sql(build, "1", [], materialize=False)
    assert "UNRESOLVED STEP" in arts[0].sql


@pytest.mark.skipif(not EXPORT.exists(), reason="checked-in DOMO export not present")
def test_the_real_dataflow_generates_one_artifact_per_target():
    """Pinned against 8099: 6 targets, 55 steps, and — since the column tracer landed —
    NO step left needing a model. The dynamic unpivot used to be the one escalation."""
    doc = json.loads(EXPORT.read_text(encoding="utf-8"))
    gen = generate_sql(to_planner_dataflow(doc, "8099"), dataflow_id="8099",
                       dataflow_name="cms", materialize=True)
    assert len(gen.artifacts) == 6
    assert len(gen.failed) == 0
    assert len(gen.build.steps) == 55
    assert gen.escalated_steps == []
    assert gen.needed_a_model == []
    assert all("UNRESOLVED STEP" not in a.sql for a in gen.succeeded)
    for a in gen.succeeded:
        assert a.sql.lstrip().startswith("-- Generated from DOMO dataflow 8099")
        assert "CREATE OR REPLACE TABLE" in a.sql
        assert a.node_keys


# --------------------------------------------------------------------------- #
# the dynamic unpivot: a column set DOMO resolves at run time, recovered statically
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not EXPORT.exists(), reason="checked-in DOMO export not present")
def test_the_dynamic_unpivot_is_resolved_without_a_model():
    """8099's Dynamic Unpivot escalated because SQL must enumerate what DOMO decides at
    run time. The set is (upstream declared columns) - (idFields), which the graph
    states outright — no engine, no model, no guess."""
    doc = json.loads(EXPORT.read_text(encoding="utf-8"))
    gen = generate_sql(to_planner_dataflow(doc, "8099"), dataflow_id="8099",
                       dataflow_name="cms", materialize=False)
    sql = next(a.sql for a in gen.succeeded if "df_dynamic_unpivot_s22" in a.sql)
    cte = sql[sql.index("df_dynamic_unpivot_s22 AS ("):]
    cte = cte[:cte.index("-- [/node:")]

    assert "stack(9," in cte                       # nine currency columns
    assert "origin=mapped" in sql                  # deterministic, not origin=ai
    for cur in ("USD", "CAD", "MXN", "JPY", "EUR", "GBP", "AUD", "THB"):
        assert f"'{cur}', `{cur}`" in cte
    # the key literal keeps DOMO's ORIGINAL spelling — it becomes data, and a
    # downstream join matches on it
    assert "'RMB/CNY'" in cte
    # idFields are kept as-is, not unpivoted
    for keep in ("`_BATCH_LAST_RUN_`", "`_BATCH_ID_`", "`_FILE_NAME_`", "`Base_Currency`"):
        assert keep in cte
    assert "`Exchange_Currency`, `Oracle_Exchange_Rate`" in cte


def test_an_unpivot_whose_upstream_cannot_be_traced_still_escalates():
    """Guessing a column set is worse than escalating. Only a traceable upstream
    resolves; anything else keeps the loud passthrough."""
    df = {
        "dataflow_id": "1",
        "nodes": [
            {"id": "n1", "name": "feed", "type": "source", "category": "SOURCE",
             "properties": {"datasetName": "feed"}},
            {"id": "n2", "name": "Dynamic Unpivot", "type": "NormalizeAll",
             "category": "TRANSFORMATION",
             "properties": {"idFields": ["a"], "keyField": "k", "valueField": "v"}},
            {"id": "n3", "name": "out", "type": "sink", "category": "TARGET",
             "properties": {"datasetName": "out"}},
        ],
        "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
    }
    gen = generate_sql(df, dataflow_id="1", materialize=False)
    assert gen.escalated_steps == ["s01"]
    assert "UNRESOLVED STEP" in gen.succeeded[0].sql

# --------------------------------------------------------------------------- #
# source cleaning — DOMO's leading-apostrophe export artifact
#
# The artifact had been patched in six places, each fixing one place a value is READ.
# None fixed the value a projection CARRIES, because `SELECT *` cannot name a column.
# These are about the generic fix: strip it once, in the source CTE, naming every
# column — and about the two ways that could go quietly wrong (retyping a number, or
# a source the catalog misses).
# --------------------------------------------------------------------------- #

FEED_COLUMNS = {"feed_df": {"a": "string", "amt": "string", "n": "double"}}


def _sql(**kw) -> str:
    return generate_sql(dataflow(), dataflow_id="1", materialize=False,
                        **kw).succeeded[0].sql


def test_without_a_catalog_the_sources_are_read_unchanged():
    """Cleaning is opt-in: an offline run has no schema to read, and inventing one
    would be worse than the artifact."""
    sql = _sql()
    assert "SELECT * FROM dev_test.domo_input.feed" in sql
    assert "regexp_replace" not in sql


def test_every_text_column_of_a_source_is_stripped_in_its_cte():
    sql = _sql(source_columns=FEED_COLUMNS)
    assert "regexp_replace(`a`, \"^'\", '') AS `a`" in sql
    assert "regexp_replace(`amt`, \"^'\", '') AS `amt`" in sql


def test_a_non_text_column_is_carried_through_untouched():
    """regexp_replace returns STRING. Applying it to a double would retype the column
    for everything downstream — a worse bug than the apostrophe it removes."""
    sql = _sql(source_columns=FEED_COLUMNS)
    assert "regexp_replace(`n`" not in sql
    assert "`n`," in sql or "`n`\n" in sql        # still projected, just not touched


def test_the_strip_does_not_bring_the_exponent_rule_with_it():
    """tiles._CLEAN also strips a trailing E-<digits>, which is right for a string
    comparison and catastrophic for a value: 1.5E-05 would become 1.5."""
    assert "E-" not in _sql(source_columns=FEED_COLUMNS)


def test_a_source_the_catalog_misses_is_marked_not_silently_skipped():
    sql = _sql(source_columns={"some_other_table": {"x": "string"}})
    assert "No column list was supplied for this source" in sql
    assert "regexp_replace" not in sql


def test_cleaning_and_the_as_of_cutoff_compose_in_one_select():
    sql = _sql(source_columns=FEED_COLUMNS, as_of="2026-01-01 00:00:00")
    assert "regexp_replace(`a`" in sql
    assert "`_BATCH_LAST_RUN_` IS NULL OR" in sql
    # one subquery, not the strip nested inside the cutoff or vice versa
    assert sql.count("FROM dev_test.domo_input.feed") == 1


def test_the_catalog_is_keyed_by_whatever_name_the_caller_has():
    """Spark keys it by df_var, a hand-written file by the table or the dataset name.
    A key that silently fails to match is a source that silently is not cleaned."""
    for key in ("feed_df", "dev_test.domo_input.feed", "feed", "FEED"):
        assert "regexp_replace(`a`" in _sql(source_columns={key: {"a": "string"}}), key


def test_dtypes_pairs_are_accepted_as_json_gives_them_back():
    """`spark.table(t).dtypes` is a list of pairs, and JSON round-trips it as lists."""
    assert "regexp_replace(`a`" in _sql(source_columns={"feed_df": [["a", "string"]]})


def test_a_bare_list_of_column_names_is_refused():
    """Without types the strip would be applied blind, retyping every number."""
    with pytest.raises(ValueError, match="column name to Spark type"):
        _sql(source_columns={"feed_df": ["a", "amt"]})


def test_source_coverage_reports_the_gap_before_any_sql_exists():
    gen = generate_sql(dataflow(), dataflow_id="1", materialize=False)
    covered, uncovered = source_coverage(gen.build, {"feed_df": {"a": "string"}})
    assert [s["df_var"] for s in covered] == ["feed_df"]
    assert uncovered == []
    covered, uncovered = source_coverage(gen.build, {})
    assert covered == [] and [s["df_var"] for s in uncovered] == ["feed_df"]


def test_source_columns_from_spark_names_every_table_it_could_not_read():
    class Spark:
        def table(self, name):
            raise RuntimeError("TABLE_OR_VIEW_NOT_FOUND: " + name)

    gen = generate_sql(dataflow(), dataflow_id="1", materialize=False)
    with pytest.raises(SourceSchemaError) as exc:
        source_columns_from_spark(Spark(), gen.build)
    assert "dev_test.domo_input.feed" in str(exc.value)
    assert exc.value.columns == {}                 # partial result stays reachable


def test_the_real_dataflow_cleans_every_source_it_is_given_columns_for():
    if not EXPORT.exists():
        pytest.skip("8099_standardized.json not present")
    flow = to_planner_dataflow(json.loads(EXPORT.read_text(encoding="utf-8")), "8099")
    gen = generate_sql(flow, dataflow_id="8099", materialize=False)
    catalog = {s["table"]: {"Amount": "string", "Plant": "string", "Qty": "double"}
               for s in gen.build.sources}
    out = generate_sql(flow, dataflow_id="8099", materialize=False,
                       source_columns=catalog)
    for art in out.succeeded:
        assert "No column list was supplied" not in art.sql
        assert "regexp_replace(`Amount`" in art.sql
