"""SQL AI-tail contracts (agents.cd_codegen.sql_translation).

The tail is the only place a model writes SQL that will be compared against DOMO row
by row, so most of these tests are about what must be REJECTED. Every rejection
degrades to the loud passthrough, which is safe; every wrong acceptance ships a data
bug wearing the costume of a translation.
"""
from __future__ import annotations

import pytest
from conftest import FakeObservability, cfg

from agents.cd_codegen.sql_generator import generate_sql, generate_sql_with_tail
from agents.cd_codegen.sql_translation import SqlTailTranslator, extract_sql
from agents.md_plan.render import PlanRenderer
from core.domo.concurrency import ConcurrencyManager
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler


def dataflow(tile_type: str = "SomeUnknownTile") -> dict:
    return {
        "dataflow_id": "1",
        "nodes": [
            {"id": "n1", "name": "feed", "type": "source", "category": "SOURCE",
             "properties": {"datasetName": "feed", "dataSourceId": "d1"}},
            {"id": "n2", "name": "Mystery", "type": tile_type,
             "category": "TRANSFORMATION",
             "properties": {"keyField": "k", "valueField": "v", "idFields": ["a"]}},
            {"id": "n3", "name": "out", "type": "sink", "category": "TARGET",
             "properties": {"datasetName": "out"}},
        ],
        "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
    }


def make_llm(text: str, *, prompts: list | None = None, fail: bool = False):
    def caller(spec, prompt, schema, timeout):
        if prompts is not None:
            prompts.append(prompt)
        if fail:
            raise RuntimeError("endpoint exploded")
        return RawCompletion(text=text, tokens_in=10, tokens_out=5)

    return LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="g"),
                                        "evaluator": EndpointSpec(endpoint="e")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=ConcurrencyManager({"cd_translation": 4}, global_ceiling=8),
        observability=FakeObservability(), caller=caller, max_retries=0)


async def run_tail(text: str, *, prompts=None, fail: bool = False):
    tr = SqlTailTranslator(make_llm(text, prompts=prompts, fail=fail))
    build = PlanRenderer(dialect="sql").build(dataflow(), dataflow_id="1")
    assert build.unresolved, "fixture must have an unresolvable tile"
    return await tr.resolve_tail(build, config=cfg(dataflow_id="1"))


# --------------------------------------------------------------------------- #
# extraction
# --------------------------------------------------------------------------- #
def test_sql_is_pulled_out_of_a_fenced_block():
    assert extract_sql("Sure!\n```sql\nSELECT 1\n```\nHope that helps") == "SELECT 1"


def test_a_bare_response_is_taken_as_is():
    assert extract_sql("SELECT * FROM x") == "SELECT * FROM x"


def test_an_unlabelled_fence_still_works():
    assert extract_sql("```\nSELECT 2\n```") == "SELECT 2"


# --------------------------------------------------------------------------- #
# what must be accepted
# --------------------------------------------------------------------------- #
async def test_a_clean_select_is_accepted():
    out = await run_tail("```sql\nSELECT `a`, `k`, `v` FROM feed_df\n```")
    assert out["s01"].usable
    assert out["s01"].sql == "SELECT `a`, `k`, `v` FROM feed_df"


async def test_a_trailing_semicolon_is_stripped():
    """A semicolon would terminate the enclosing query mid-CTE."""
    out = await run_tail("```sql\nSELECT 1 FROM feed_df;\n```")
    assert out["s01"].usable and not out["s01"].sql.endswith(";")


async def test_leading_comments_do_not_hide_the_select():
    out = await run_tail("```sql\n-- unpivot the value columns\nSELECT 1 FROM feed_df\n```")
    assert out["s01"].usable


# --------------------------------------------------------------------------- #
# what must be rejected — each becomes the loud passthrough
# --------------------------------------------------------------------------- #
async def test_an_explicit_refusal_is_recorded_not_treated_as_sql():
    """Saying 'I cannot' is a useful answer; a plausible guess is not."""
    out = await run_tail("```sql\n-- CANNOT TRANSLATE: no column list given\n```")
    r = out["s01"]
    assert not r.usable and r.refused == "no column list given"


@pytest.mark.parametrize("body, why", [
    ("INSERT INTO t SELECT 1", "insert"),
    ("CREATE TABLE t AS SELECT 1", "create"),
    ("DROP TABLE t", "drop"),
    ("SELECT 1; DELETE FROM t", "second statement"),
])
async def test_ddl_and_dml_are_refused(body, why):
    """The artifact's whole promise is that it only reads."""
    out = await run_tail(f"```sql\n{body}\n```")
    assert not out["s01"].usable, why
    assert out["s01"].error


async def test_prose_that_is_not_sql_is_refused():
    out = await run_tail("I'd be happy to help! Could you share the column names?")
    assert not out["s01"].usable and "not a SELECT" in out["s01"].error


async def test_an_empty_response_is_refused():
    out = await run_tail("")
    assert not out["s01"].usable and out["s01"].error


async def test_an_endpoint_failure_is_captured_not_raised():
    """One bad step must not take down the other 54."""
    out = await run_tail("irrelevant", fail=True)
    assert not out["s01"].usable and "endpoint exploded" in out["s01"].error


# --------------------------------------------------------------------------- #
# the prompt
# --------------------------------------------------------------------------- #
async def test_the_prompt_carries_the_tile_context_the_model_needs():
    prompts: list[str] = []
    await run_tail("```sql\nSELECT 1\n```", prompts=prompts)
    p = prompts[0]
    assert "Tile type" in p and "Tile name : Mystery" in p
    assert "Input CTEs" in p and "feed_df" in p
    assert "keyField" in p                      # the tile configuration itself
    assert "could not do it" in p               # why the transpiler declined
    assert "```sql" in p and "bare SELECT" in p


# --------------------------------------------------------------------------- #
# end to end through the generator
# --------------------------------------------------------------------------- #
async def test_an_ai_answer_replaces_the_passthrough_and_is_marked_as_ai():
    tr = SqlTailTranslator(make_llm("```sql\nSELECT `a` FROM feed_df\n```"))
    gen = await generate_sql_with_tail(
        dataflow(), translator=tr, config=cfg(dataflow_id="1"),
        dataflow_id="1", materialize=False)
    sql = gen.succeeded[0].sql
    assert "UNRESOLVED STEP" not in sql
    assert "origin=ai" in sql                   # provenance survives into the artifact
    assert gen.ai_steps == ["s01"] and gen.escalated_steps == []


async def test_a_refused_step_keeps_the_passthrough():
    tr = SqlTailTranslator(make_llm("```sql\n-- CANNOT TRANSLATE: not enough info\n```"))
    gen = await generate_sql_with_tail(
        dataflow(), translator=tr, config=cfg(dataflow_id="1"),
        dataflow_id="1", materialize=False)
    assert "UNRESOLVED STEP" in gen.succeeded[0].sql
    assert gen.ai_steps == [] and gen.escalated_steps == ["s01"]


async def test_a_model_never_overrides_a_tile_python_could_render():
    """Deterministic first. If the registry rendered it, the model's answer is ignored
    even when one is supplied — Python is reproducible and free; the model is neither."""
    df = dataflow(tile_type="formula")
    df["nodes"][1]["properties"] = {"expressions": [{"outputColumn": "up",
                                                     "expression": "UPPER(`a`)"}]}
    gen = generate_sql(df, dataflow_id="1", materialize=False,
                       ai_resolved={"s01": "SELECT 'HIJACKED' AS up"})
    assert "HIJACKED" not in gen.succeeded[0].sql
    assert "origin=mapped" in gen.succeeded[0].sql


async def test_no_model_is_asked_when_everything_transpiles():
    """The endpoint here raises on any call, so a green test proves none was made."""
    df = dataflow(tile_type="formula")
    df["nodes"][1]["properties"] = {"expressions": [{"outputColumn": "up",
                                                     "expression": "UPPER(`a`)"}]}
    tr = SqlTailTranslator(make_llm("unused", fail=True))
    gen = await generate_sql_with_tail(df, translator=tr, config=cfg(dataflow_id="1"),
                                       dataflow_id="1", materialize=False)
    assert gen.escalated_steps == [] and gen.ai_steps == []


async def test_coverage_reports_all_three_provenances():
    tr = SqlTailTranslator(make_llm("```sql\nSELECT `a` FROM feed_df\n```"))
    gen = await generate_sql_with_tail(
        dataflow(), translator=tr, config=cfg(dataflow_id="1"),
        dataflow_id="1", materialize=False)
    assert gen.coverage == "0/1 deterministic, 1 by model, 0 unresolved"


# --------------------------------------------------------------------------- #
# false positives — each of these is VALID SQL that an earlier, blunter validator
# rejected, silently dropping the step back to a passthrough
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("body, why", [
    ("SELECT `Update Date`, `Base Currency` FROM df_x",
     "a backticked column may legitimately contain a keyword word"),
    ("SELECT * FROM df_x  -- create one row per currency",
     "a trailing comment is content, not a statement"),
    ("-- unpivot the Alter Columns 8 output\nSELECT `a` FROM df_alter_columns_8_s21",
     "a leading comment may name a tile called 'Alter Columns'"),
    ("SELECT 'we DROP nothing here' AS note FROM df_x",
     "a string literal is content, not a statement"),
])
async def test_valid_sql_is_not_mistaken_for_ddl(body, why):
    out = await run_tail(f"```sql\n{body}\n```")
    assert out["s01"].usable, f"{why}: {out['s01'].error}"


async def test_the_last_sql_block_wins_when_a_model_shows_its_working():
    """Reasoning models put a shape or an example in one block and the answer in
    another. Taking the first block reads the answer as prose and discards it."""
    out = await run_tail(
        "First, the target shape:\n```text\nid | key | val\n```\n"
        "Now the query:\n```sql\nSELECT `a` FROM df_x\n```")
    assert out["s01"].usable and out["s01"].sql == "SELECT `a` FROM df_x"


async def test_a_refusal_wins_over_any_other_block():
    out = await run_tail("```sql\nSELECT 1\n```\n```sql\n-- CANNOT TRANSLATE: no columns\n```")
    assert not out["s01"].usable and out["s01"].refused == "no columns"


async def test_a_nested_with_is_allowed_and_left_for_explain_to_judge():
    """Rejecting it here would discard a possibly-correct answer for a dialect question
    EXPLAIN can settle definitively."""
    out = await run_tail("```sql\nWITH t AS (SELECT 1 AS a) SELECT a FROM t\n```")
    assert out["s01"].usable


# --------------------------------------------------------------------------- #
# a rejection must always be explicable
# --------------------------------------------------------------------------- #
async def test_a_rejected_answer_records_what_the_model_said():
    """Without this the coverage line reads '0 by model' and there is no way to tell a
    rejected answer from a call that was never made."""
    out = await run_tail("I'd love to help but I need the column names.")
    r = out["s01"]
    assert not r.usable
    assert "not a SELECT" in r.why_not
    assert "I'd love to help" in r.raw


async def test_the_generation_exposes_why_each_step_was_not_translated():
    tr = SqlTailTranslator(make_llm("no fence, no sql, just chatter"))
    gen = await generate_sql_with_tail(
        dataflow(), translator=tr, config=cfg(dataflow_id="1"),
        dataflow_id="1", materialize=False)
    assert gen.ai_steps == [] and gen.escalated_steps == ["s01"]
    assert "not a SELECT" in gen.why_not("s01")
    assert gen.tail_results["s01"].raw == "no fence, no sql, just chatter"


async def test_tail_results_survive_even_when_every_answer_is_rejected():
    tr = SqlTailTranslator(make_llm("garbage"))
    gen = await generate_sql_with_tail(
        dataflow(), translator=tr, config=cfg(dataflow_id="1"),
        dataflow_id="1", materialize=False)
    assert gen.tail_results and gen.why_not("s01")


# --------------------------------------------------------------------------- #
# tile semantics — the model must not have to reverse-engineer DOMO from JSON keys
# --------------------------------------------------------------------------- #
UNPIVOT_ITEM = {
    "step": "s22", "name": "Dynamic Unpivot", "inputs": ["df_prev"],
    "reasons": ["dynamic unpivot: the value columns are resolved at run time"],
    "node": {"type": "NormalizeAll", "properties": {
        "idFields": ["_BATCH_ID_", "Base Currency"],
        "keyField": "Exchange Currency", "valueField": "Oracle Exchange Rate"}},
}


def translator(**kw):
    return SqlTailTranslator(make_llm("unused"), **kw)


def test_the_prompt_explains_what_the_tile_does():
    """`keyField`/`valueField` read as input columns. They are outputs. A model given
    only the JSON produces the exact inverse of the tile — confidently."""
    p = translator().build_prompt(UNPIVOT_ITEM)
    assert "WHAT THIS TILE DOES" in p
    assert "OUTPUT names the tile creates" in p
    assert "NOT columns of the input" in p
    assert "stack(" in p


def test_an_unknown_tile_type_gets_no_invented_semantics():
    item = {**UNPIVOT_ITEM, "node": {"type": "SomethingNobodyHasSeen", "properties": {}}}
    assert "WHAT THIS TILE DOES" not in translator().build_prompt(item)


def test_semantics_lookup_is_forgiving_about_spelling():
    from agents.cd_codegen.sql_translation import semantics_for
    assert semantics_for("normalizeall") == semantics_for("NormalizeAll")
    assert semantics_for("Dynamic Unpivot") == semantics_for("DYNAMICUNPIVOT")
    assert semantics_for("Filter") == ""


# --------------------------------------------------------------------------- #
# schema probe — the escalation reason IS the unknown column set
# --------------------------------------------------------------------------- #
def test_the_prompt_lists_the_real_upstream_columns_when_they_can_be_probed():
    cols = ["_BATCH_ID_", "Base_Currency", "USD", "EUR", "GBP"]
    p = translator(schema_probe=lambda cte: cols).build_prompt(UNPIVOT_ITEM)
    assert "COLUMNS AVAILABLE IN THE INPUT" in p
    assert "df_prev (5 columns)" in p
    for c in cols:
        assert f"`{c}`" in p
    assert "There is no other column" in p


def test_probed_names_are_the_sanitized_ones_the_sql_must_use():
    """delta_safe turns `Base Currency` into `Base_Currency`. The tile config still
    says `Base Currency`, so without the probe the model picks the wrong spelling."""
    p = translator(schema_probe=lambda cte: ["Base_Currency"]).build_prompt(UNPIVOT_ITEM)
    assert "`Base_Currency`" in p
    assert "use these spellings verbatim" in p


def test_without_a_probe_the_model_is_told_to_refuse_rather_than_guess():
    p = translator().build_prompt(UNPIVOT_ITEM)
    assert "column list could not be determined" in p
    assert "CANNOT TRANSLATE rather than guessing" in p


def test_a_probe_that_raises_degrades_to_the_no_schema_wording():
    def boom(cte):
        raise RuntimeError("table not found")
    p = translator(schema_probe=boom).build_prompt(UNPIVOT_ITEM)
    assert "column list could not be determined" in p


def test_a_probe_returning_nothing_is_treated_as_unknown():
    p = translator(schema_probe=lambda cte: []).build_prompt(UNPIVOT_ITEM)
    assert "column list could not be determined" in p


async def test_the_answer_the_corrected_prompt_should_produce_is_accepted():
    """A real stack() unpivot over the probed columns must survive validation."""
    good = ("```sql\nSELECT `_BATCH_ID_`, `Base_Currency`,\n"
            "  stack(3, 'USD', `USD`, 'EUR', `EUR`, 'GBP', `GBP`)\n"
            "    AS (`Exchange Currency`, `Oracle Exchange Rate`)\n"
            "FROM df_prev\n```")
    out = await run_tail(good)
    assert out["s01"].usable and "stack(3" in out["s01"].sql
