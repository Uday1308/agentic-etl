"""Contract tests for the CD Codegen agent (blueprint §9.5 checklist).

  * known ops are mapped WITHOUT an LLM call
  * unknown ops are routed to AI
  * translations merge by line index (out-of-order safe; gaps fail loudly)
  * output is node-keyed (addressable sections; the Classifier's hard dependency)
  * per-issue apply/keep works
  * artifact writes are versioned by iteration (idempotent key)
  * regeneration layers human feedback (P1) + hard constraints into prompts
  * no hardcoded inputs — divergent fixtures
  * full loop integration: generate -> evaluate -> HITL pause -> resume

All LLM traffic goes through core.domo.llm.LLMClient with a fake endpoint caller; no
Spark, no volume. Fast; gates CI.
"""
from __future__ import annotations

import json
import re

import pytest
from conftest import TrackingConcurrency, cfg, ts_iso
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from agents.cd_codegen.assembly import AssemblyError, CodeAssembler
from agents.cd_codegen.graph import build_cd_codegen_graph
from agents.cd_codegen.ir import DataflowIR, IRNode, Origin
from agents.cd_codegen.mapping import MapperRegistry, MappingContext
from agents.cd_codegen.ports import ArtifactStore, DiscoveryReader
from agents.cd_codegen.strategies import (
    CdCodeEvaluator,
    CdCodeGenerator,
    CdFeedbackApplier,
    IssueLedger,
)
from agents.cd_codegen.translation import ExpressionTranslator, TranslationError
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.schemas import GenResult, HumanFeedback

# --------------------------------------------------------------------------- #
# fixtures & doubles
# --------------------------------------------------------------------------- #


def _ir(dataflow_id="8842", with_unknown=False) -> DataflowIR:
    nodes = [
        IRNode(node_id="src", op_type="DataSet", config={"table": "bronze.orders"}),
        IRNode(node_id="flt", op_type="Filter", inputs=("src",),
               config={"conditions": [{"column": "status", "operator": "EQUALS", "value": "OPEN"}]}),
        IRNode(node_id="fx", op_type="AddFormula", inputs=("flt",),
               config={"formulas": [{"name": "margin", "formula": "(`rev` - `cost`) / `rev`"}]}),
        IRNode(node_id="agg", op_type="GroupBy", inputs=("fx",),
               config={"groupBy": ["region"],
                       "aggregations": [{"column": "margin", "function": "AVG", "alias": "avg_margin"}]}),
    ]
    if with_unknown:
        nodes.append(IRNode(node_id="myst", op_type="MysteryTile", inputs=("agg",),
                            config={"weird": True}))
    return DataflowIR(dataflow_id=dataflow_id, nodes=tuple(nodes))


class FakeDiscovery(DiscoveryReader):
    def __init__(self, ir: DataflowIR):
        self._ir = ir
        self.reads: list[str] = []

    def read(self, dataflow_id: str) -> DataflowIR:
        self.reads.append(dataflow_id)
        return self._ir


class FakeStore(ArtifactStore):
    def __init__(self):
        self.writes: list[tuple[str, int, str]] = []

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        self.writes.append((dataflow_id, iteration, content))
        return f"/fake/{dataflow_id}/cd/etl_{dataflow_id}_v{iteration}.py"


def _translation_caller():
    """Fake endpoint: answers translation chunks by echoing indices, and evaluator
    reviews with a PASS. Records every prompt for assertions."""
    prompts: list[str] = []

    def caller(spec, prompt, response_schema, timeout_s):
        prompts.append(prompt)
        if '"verdict"' in prompt or "reviewing generated PySpark" in prompt:
            return RawCompletion(text=json.dumps(
                {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "lgtm"}))
        # translation chunk: parse the [n] markers back out of the CHUNK section only
        # (the worked examples in the base prompt use the same [n] format)
        chunk_part = prompt.split("Translate EACH numbered line below", 1)[-1]
        idxs = []
        for line in chunk_part.split("\n"):
            s = line.strip()
            if s.startswith("[") and "] kind=" in s:
                idxs.append(int(s[1:s.index("]")]))
        lines = [{"index": i, "pyspark": f"F.lit({i})"} for i in idxs]
        return RawCompletion(text=json.dumps({"lines": lines, "confidence": 0.95}))

    caller.prompts = prompts  # type: ignore[attr-defined]
    return caller


def _llm(obs, caller):
    return LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="gen"),
                                        "evaluator": EndpointSpec(endpoint="eval")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=TrackingConcurrency(), observability=obs, caller=caller,
    )


def _generator(obs, ir=None, caller=None, store=None, chunk_size=8):
    caller = caller or _translation_caller()
    store = store or FakeStore()
    llm = _llm(obs, caller)
    gen = CdCodeGenerator(
        discovery=FakeDiscovery(ir or _ir()),
        translator=ExpressionTranslator(llm, chunk_size=chunk_size),
        store=store,
    )
    return gen, caller, store, llm


# --------------------------------------------------------------------------- #
# 1. known ops mapped WITHOUT an LLM call
# --------------------------------------------------------------------------- #
async def test_known_ops_mapped_without_llm(obs):
    ir = DataflowIR(dataflow_id="1", nodes=(
        IRNode(node_id="src", op_type="DataSet", config={"table": "t"}),
        IRNode(node_id="sel", op_type="SelectValues", inputs=("src",),
               config={"fields": [{"name": "a"}, {"name": "b", "rename": "bb"}]}),
        IRNode(node_id="srt", op_type="Sort", inputs=("sel",),
               config={"orderBy": [{"column": "a", "direction": "desc"}]}),
    ))
    gen, caller, store, _ = _generator(obs, ir=ir)
    result = await gen.generate({"dataflow_id": "1", "feedback": {}}, cfg(dataflow_id="1"))

    assert caller.prompts == []                      # ZERO model calls
    assert obs.llm_calls == []                       # and zero obs llm rows
    assert result.meta["counts"]["mapped"] == 3 and result.meta["counts"]["ai"] == 0
    assert 'spark.table("t")' in result.artifact
    assert '.alias("bb")' in result.artifact


# --------------------------------------------------------------------------- #
# 2. unknown ops routed to AI; hybrid formulas routed as fragments
# --------------------------------------------------------------------------- #
async def test_unknown_and_hybrid_ops_routed_to_ai(obs):
    gen, caller, _, _ = _generator(obs, ir=_ir(with_unknown=True))
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))

    assert len(caller.prompts) >= 1                              # the model WAS used
    assert result.meta["origins"]["myst"] == Origin.AI.value     # unknown tile -> AI
    assert result.meta["origins"]["fx"] == Origin.HYBRID.value   # formula fragment -> AI
    assert result.meta["origins"]["src"] == Origin.MAPPED.value  # known stays python
    assert "__PENDING_" not in result.artifact                   # everything spliced


# --------------------------------------------------------------------------- #
# 3. merge by line index — out-of-order safe, gaps fail loudly
# --------------------------------------------------------------------------- #
async def test_translations_merge_by_index_across_chunks(obs):
    # chunk_size=1 forces one call per pending unit -> real fan-out + merge
    ir = DataflowIR(dataflow_id="2", nodes=(
        IRNode(node_id="src", op_type="DataSet", config={"table": "t"}),
        IRNode(node_id="fx", op_type="AddFormula", inputs=("src",),
               config={"formulas": [{"name": f"c{i}", "formula": f"`a` + {i}"} for i in range(5)]}),
    ))
    gen, caller, _, _ = _generator(obs, ir=ir, chunk_size=1)
    result = await gen.generate({"dataflow_id": "2", "feedback": {}}, cfg(dataflow_id="2"))

    assert len(caller.prompts) == 5                          # fanned out per chunk
    for i in range(5):
        assert f'withColumn("c{i}", F.lit({i}))' in result.artifact   # each index landed home


async def test_missing_translation_index_fails_loudly(obs):
    def dropping_caller(spec, prompt, response_schema, timeout_s):
        # returns nothing -> merge must detect the gap, not ship a slot
        return RawCompletion(text=json.dumps({"lines": []}))

    gen, _, _, _ = _generator(obs, caller=dropping_caller)
    with pytest.raises(TranslationError, match="no usable lines|missing"):
        await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))


# --------------------------------------------------------------------------- #
# 4. output is node-keyed (the Classifier's hard dependency)
# --------------------------------------------------------------------------- #
async def test_output_is_node_addressable(obs):
    gen, _, _, _ = _generator(obs)
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))

    sections = CodeAssembler.split_sections(result.artifact)
    assert set(result.node_keys) == {"src", "flt", "fx", "agg"}
    assert set(sections) == set(result.node_keys)            # every node has a section
    # sections are individually replaceable (what the Classifier / applier rely on)
    patched = CodeAssembler.replace_section(result.artifact, "flt", "df_flt = df_src  # patched")
    assert "# patched" in CodeAssembler.split_sections(patched)["flt"]


def test_unresolved_slot_never_reaches_emit():
    ctx = MappingContext()
    ir = DataflowIR(dataflow_id="3", nodes=(
        IRNode(node_id="src", op_type="DataSet", config={"table": "t"}),
        IRNode(node_id="fx", op_type="AddFormula", inputs=("src",),
               config={"formulas": [{"name": "c", "formula": "`a`"}]}),
    ))
    codes = MapperRegistry().map_all(ir.ordered(), ctx)
    with pytest.raises(AssemblyError):
        CodeAssembler().splice(codes, translations={})       # no translations -> loud


# --------------------------------------------------------------------------- #
# 5. per-issue apply / keep
# --------------------------------------------------------------------------- #
async def test_per_issue_apply_and_keep(obs):
    gen, _, _, llm = _generator(obs)
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))

    ledger = IssueLedger()
    evaluator = CdCodeEvaluator(llm, ai_review=False, ledger=ledger)
    ev = await evaluator.evaluate(result, {"dataflow_id": "8842"})
    assert ev.passed                                          # static checks fine

    # simulate a review round: evaluator recorded issues for THIS artifact
    from core.domo.schemas import Issue, Severity
    fix = 'df_flt = df_src.filter(F.col("status") == "OPEN")  # fixed'
    ledger.record(result.artifact, [
        Issue(id="i-flt", severity=Severity.WARN, ref="node:flt",
              message="prefer explicit lit", suggested_fix=fix),
        Issue(id="i-agg", severity=Severity.WARN, ref="node:agg",
              message="consider approx", suggested_fix="df_agg = None  # bad idea"),
    ])
    applier = CdFeedbackApplier(ledger=ledger)
    fb = HumanFeedback(accepted_issue_ids=["i-flt"], rejected_issue_ids=["i-agg"], ts=ts_iso())
    applied = applier.apply(result, [fb])

    assert "# fixed" in CodeAssembler.split_sections(applied.artifact)["flt"]   # accepted -> applied
    assert "# bad idea" not in applied.artifact                                  # rejected -> kept
    assert applied.meta["applied_issue_ids"] == ["i-flt"]


# --------------------------------------------------------------------------- #
# 6. idempotent versioned writes + P1 feedback layering on regeneration
# --------------------------------------------------------------------------- #
async def test_artifact_versioned_by_iteration(obs):
    store = FakeStore()
    gen, _, _, _ = _generator(obs, store=store)
    await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842", iteration=1))
    await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842", iteration=2))
    keys = [(d, i) for d, i, _ in store.writes]
    assert keys == [("8842", 1), ("8842", 2)]        # keyed (dataflow, iteration): no clobber


async def test_regeneration_layers_human_feedback_and_hard_constraints(obs):
    gen, caller, _, _ = _generator(obs)
    fb = HumanFeedback(freeform="always use unionByName", ts=ts_iso(),
                       hard_constraints=["collect()"])
    state = {"dataflow_id": "8842", "feedback": {"cd_codegen": [fb]}}
    await gen.generate(state, cfg(dataflow_id="8842", iteration=2))

    joined = "\n".join(caller.prompts)
    assert "always use unionByName" in joined        # P1 human feedback reached the prompt
    assert "collect()" in joined                     # hard constraints forwarded
    assert "P1" in joined                            # precedence declared by the assembler


# --------------------------------------------------------------------------- #
# 7. evaluator: deterministic checks dominate; issues are node-addressed
# --------------------------------------------------------------------------- #
async def test_evaluator_static_checks_dominate(obs):
    llm = _llm(obs, _translation_caller())
    evaluator = CdCodeEvaluator(llm, ai_review=True)
    bad = GenResult(artifact="# [node: x] op=Filter origin=mapped\ndf = (\n# [/node: x]",
                    node_keys=["x"])
    ev = await evaluator.evaluate(bad, {"dataflow_id": "8842"})
    assert not ev.passed
    assert any(i.id == "static-syntax" for i in ev.issues)
    assert obs.llm_calls == []                        # broken code never wastes a model call


async def test_evaluator_flags_missing_node_sections(obs):
    llm = _llm(obs, _translation_caller())
    evaluator = CdCodeEvaluator(llm, ai_review=False)
    partial = GenResult(artifact="# [node: a] op=DataSet origin=mapped\nx = 1\n# [/node: a]",
                        node_keys=["a", "b"])
    ev = await evaluator.evaluate(partial, {})
    assert any(i.ref == "node:b" and i.severity.value == "error" for i in ev.issues)


# --------------------------------------------------------------------------- #
# 8. full loop integration on the real core machinery
# --------------------------------------------------------------------------- #
async def test_full_loop_generate_evaluate_hitl_resume(obs):
    caller = _translation_caller()
    llm = _llm(obs, caller)
    app = build_cd_codegen_graph(
        llm=llm, discovery=FakeDiscovery(_ir()), store=FakeStore(),
        hitl=True, ai_review=True, max_iters=3,
    ).compile(checkpointer=MemorySaver())

    rc = cfg(thread_id="cd-run-1", dataflow_id="8842", observability=obs)
    await app.ainvoke({"cd_codegen": {}, "feedback": {}, "dataflow_id": "8842"}, rc)

    st = app.get_state(rc)
    assert st.next, "run should park at HITL"
    payload = st.tasks[0].interrupts[0].value
    assert payload["agent"] == "cd_codegen"
    assert set(payload["artifact"]["node_keys"]) == {"src", "flt", "fx", "agg"}
    assert payload["eval"]["verdict"] == "pass"

    await app.ainvoke(Command(resume={"accepted_issue_ids": [], "rejected_issue_ids": [],
                                      "freeform": "", "hard_constraints": [], "ts": ts_iso()}), rc)
    st2 = app.get_state(rc)
    assert not st2.next                                             # accepted -> completed
    assert len(st2.values["feedback"]["cd_codegen"]) == 1           # feedback accumulated


# --------------------------------------------------------------------------- #
# 10. MD plan contract: AI path only (team decision)
# --------------------------------------------------------------------------- #
class SpyPlan:
    def __init__(self, text: str | None = "PLAN: prefer explicit null handling"):
        self.text = text
        self.reads: list[str] = []

    def read(self, dataflow_id: str) -> str | None:
        self.reads.append(dataflow_id)
        return self.text


async def test_plan_reaches_ai_translation_prompts(obs):
    """When AI translation happens, the approved plan must be in the prompt."""
    plan = SpyPlan()
    caller = _translation_caller()
    llm = _llm(obs, caller)
    gen = CdCodeGenerator(discovery=FakeDiscovery(_ir()), store=FakeStore(),
                          translator=ExpressionTranslator(llm), plan=plan)
    await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))

    assert plan.reads == ["8842"]                              # consulted for the AI path
    joined = "\n".join(caller.prompts)
    assert "APPROVED MIGRATION PLAN" in joined
    assert "prefer explicit null handling" in joined


async def test_plan_never_read_on_fully_deterministic_dataflow(obs):
    """A dataflow with zero pending units must not touch the plan at all."""
    plan = SpyPlan()
    ir = DataflowIR(dataflow_id="1", nodes=(
        IRNode(node_id="src", op_type="DataSet", config={"table": "t"}),
        IRNode(node_id="srt", op_type="Sort", inputs=("src",),
               config={"orderBy": [{"column": "a"}]}),
    ))
    caller = _translation_caller()
    gen = CdCodeGenerator(discovery=FakeDiscovery(ir), store=FakeStore(),
                          translator=ExpressionTranslator(_llm(obs, caller)), plan=plan)
    await gen.generate({"dataflow_id": "1", "feedback": {}}, cfg(dataflow_id="1"))

    assert plan.reads == []                                    # deterministic path: plan untouched
    assert caller.prompts == []                                # and no model calls either


async def test_in_run_state_plan_preferred_over_port(obs):
    """In a master-graph run, the plan the human just approved (state['md_plan'])
    wins over the injected port."""
    plan = SpyPlan(text="PORT PLAN — should not be used")
    caller = _translation_caller()
    gen = CdCodeGenerator(discovery=FakeDiscovery(_ir()), store=FakeStore(),
                          translator=ExpressionTranslator(_llm(obs, caller)), plan=plan)
    state = {"dataflow_id": "8842", "feedback": {},
             "md_plan": {"gen": {"artifact": "STATE PLAN: cast dates to DATE"}}}
    await gen.generate(state, cfg(dataflow_id="8842"))

    joined = "\n".join(caller.prompts)
    assert "STATE PLAN: cast dates to DATE" in joined
    assert "PORT PLAN" not in joined
    assert plan.reads == []                                    # port never consulted


async def test_ai_path_works_without_any_plan(obs):
    """Decoupling: no state plan, no port -> translation still proceeds."""
    caller = _translation_caller()
    gen = CdCodeGenerator(discovery=FakeDiscovery(_ir()), store=FakeStore(),
                          translator=ExpressionTranslator(_llm(obs, caller)))
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))
    assert "__PENDING_" not in result.artifact
    assert "APPROVED MIGRATION PLAN" not in "\n".join(caller.prompts)


async def test_human_feedback_still_outranks_plan_in_prompt(obs):
    """Priority contract holds: plan is base-layer context; P1 human feedback is
    declared above it by the assembler."""
    caller = _translation_caller()
    gen = CdCodeGenerator(discovery=FakeDiscovery(_ir()), store=FakeStore(),
                          translator=ExpressionTranslator(_llm(obs, caller)),
                          plan=SpyPlan(text="use lowercase column names"))
    fb = HumanFeedback(freeform="use UPPERCASE column names", ts=ts_iso())
    state = {"dataflow_id": "8842", "feedback": {"cd_codegen": [fb]}}
    await gen.generate(state, cfg(dataflow_id="8842"))

    prompt = caller.prompts[0]
    p1 = prompt.index("use UPPERCASE column names")
    p4 = prompt.index("use lowercase column names")
    assert "[P1 HUMAN FEEDBACK" in prompt and p1 < p4          # P1 rendered above base/plan


# --------------------------------------------------------------------------- #
# 12. discovery reader: schema-flexible column mapping (no Spark)
# --------------------------------------------------------------------------- #
def test_discovery_reader_resolves_column_aliases():
    from agents.cd_codegen.ports import SparkDiscoveryReader as R
    # a table that uses 'type'/'id'/'upstream' instead of the default names
    cols = ["id", "type", "label", "config", "upstream"]
    colmap = R.resolve_columns(cols, overrides={})
    assert colmap["node_id"] == "id" and colmap["op_type"] == "type"
    assert colmap["name"] == "label" and colmap["config"] == "config" and colmap["inputs"] == "upstream"


def test_discovery_reader_missing_required_column_fails_loudly():
    from agents.cd_codegen.ports import SparkDiscoveryReader as R
    with pytest.raises(ValueError, match="op_type"):
        R.resolve_columns(["id", "label"], overrides={})   # no op_type-like column


def test_discovery_reader_override_wins():
    from agents.cd_codegen.ports import SparkDiscoveryReader as R
    colmap = R.resolve_columns(["nid", "tile", "cfg"], overrides={"node_id": "nid", "op_type": "tile", "config": "cfg"})
    assert colmap["node_id"] == "nid" and colmap["op_type"] == "tile" and colmap["config"] == "cfg"


def test_discovery_reader_parses_json_and_structured_rows():
    from agents.cd_codegen.ports import SparkDiscoveryReader as R
    colmap = {"node_id": "id", "op_type": "type", "name": "label", "config": "config", "inputs": "upstream"}
    rows = [
        # JSON-string columns (typical Delta text columns)
        {"id": "a", "type": "DataSet", "label": "src", "config": '{"table": "t"}', "upstream": "[]"},
        # already-structured columns (Spark struct/array) + missing/empty handled
        {"id": "b", "type": "Filter", "label": None, "config": {"formula": "x"}, "upstream": ["a"]},
    ]
    ir = R.rows_to_ir("df1", rows, colmap)
    assert [n.node_id for n in ir.nodes] == ["a", "b"]
    assert ir.by_id()["a"].config == {"table": "t"} and ir.by_id()["a"].inputs == ()
    assert ir.by_id()["b"].config == {"formula": "x"} and ir.by_id()["b"].inputs == ("a",)
    assert ir.by_id()["b"].name == ""            # None name -> empty, not the string "None"


def test_dataflow_ir_rejects_duplicate_node_ids():
    """Duplicate node_ids (e.g. multiple discovery runs pulled at once) must fail with
    a clear message, not the misleading 'cycle involving []'."""
    with pytest.raises(Exception, match="duplicate node_id"):
        DataflowIR(dataflow_id="df", nodes=(
            IRNode(node_id="n1", op_type="DataSet", config={"table": "t"}),
            IRNode(node_id="n1", op_type="Filter", inputs=("n1",)),   # dup id
        ))


def test_discovery_reader_skips_edge_rows_in_combined_table():
    """A combined node+edge table (record_type discriminator) yields only node rows;
    edge rows have an empty node_id and must be dropped even without a where filter."""
    from agents.cd_codegen.ports import SparkDiscoveryReader as R
    colmap = {"node_id": "node_id", "op_type": "operation_type", "name": "node_name",
              "config": "properties", "inputs": "input_node_ids"}
    rows = [
        {"node_id": "n1", "operation_type": "DataSet", "node_name": "src",
         "properties": {"table": "t"}, "input_node_ids": []},
        # edge row from a combined table: no node_id
        {"node_id": None, "operation_type": None, "node_name": None,
         "properties": None, "input_node_ids": None},
        {"node_id": "n2", "operation_type": "Filter", "node_name": "flt",
         "properties": {"conditions": []}, "input_node_ids": ["n1"]},
    ]
    ir = R.rows_to_ir("df", rows, colmap)
    assert [n.node_id for n in ir.nodes] == ["n1", "n2"]     # the edge row is dropped
    assert ir.by_id()["n2"].inputs == ("n1",)


async def test_discovery_reader_output_feeds_generator(obs):
    """End-to-end: reader output drives the generator with no schema assumptions."""
    from agents.cd_codegen.ports import SparkDiscoveryReader as R

    class MappedDiscovery(DiscoveryReader):
        def read(self, dataflow_id):
            rows = [{"id": "src", "type": "DataSet", "config": '{"table": "bronze.t"}', "upstream": "[]"}]
            colmap = R.resolve_columns(["id", "type", "config", "upstream"], {})
            return R.rows_to_ir(dataflow_id, rows, colmap)

    gen = CdCodeGenerator(discovery=MappedDiscovery(), store=FakeStore(),
                          translator=ExpressionTranslator(_llm(obs, _translation_caller())))
    result = await gen.generate({"dataflow_id": "df1", "feedback": {}}, cfg(dataflow_id="df1"))
    assert 'spark.table("bronze.t")' in result.artifact and result.node_keys == ["src"]


# --------------------------------------------------------------------------- #
# 11. no hardcoded inputs — divergent fixtures
# --------------------------------------------------------------------------- #
async def test_translator_tolerates_per_line_object_envelope(obs):
    """Regression for real gpt-oss output: prose + one fenced {index,pyspark} object
    per line, WITHOUT the {"lines": [...]} wrapper. All lines must still resolve."""
    def messy_caller(spec, prompt, response_schema, timeout_s):
        if '"verdict"' in prompt or "reviewing generated PySpark" in prompt:
            return RawCompletion(text=json.dumps(
                {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "ok"}))
        sec = prompt.split("Translate EACH numbered line below", 1)[-1]
        idxs = [int(m.group(1)) for m in re.finditer(r"\[(\d+)\]\s+kind=", sec)]
        blocks = [f'**{i}.**\n```json\n{{"index": {i}, "pyspark": "F.lit({i})"}}\n```' for i in idxs]
        return RawCompletion(text="Here are the translations for each line:\n\n" + "\n\n".join(blocks))

    gen, _, _, _ = _generator(obs, caller=messy_caller)
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))
    assert "__PENDING_" not in result.artifact          # every fragment resolved despite the envelope


def test_parse_translations_handles_mixed_envelopes():
    from agents.cd_codegen.translation import _parse_translations
    # wrapper form
    assert _parse_translations('{"lines":[{"index":0,"pyspark":"a"},{"index":1,"pyspark":"b"}]}') == {0: "a", 1: "b"}
    # bare list
    assert _parse_translations('[{"index":2,"pyspark":"c"}]') == {2: "c"}
    # scattered objects with prose + fences
    scattered = 'pre **3.**\n```json\n{"index":3,"pyspark":"d"}\n```\nmid {"index":4,"pyspark":"e"} end'
    assert _parse_translations(scattered) == {3: "d", 4: "e"}


def test_parse_translations_handles_step_header_code_blocks():
    """Real gpt-oss shape: '## Step N' headers with ```python code blocks, no JSON."""
    from agents.cd_codegen.translation import _parse_translations
    text = (
        "Here are the translations:\n\n"
        "## Step 48\n```python\ndf_a = df_b.unionByName(df_c, allowMissingColumns=True)\n```\n\n"
        "## Step 49\n```python\ndf_d = df_a.dropDuplicates(['id'])\n```\n"
    )
    out = _parse_translations(text)
    assert out[48] == "df_a = df_b.unionByName(df_c, allowMissingColumns=True)"
    assert out[49] == "df_d = df_a.dropDuplicates(['id'])"


async def test_translator_tolerates_step_header_code_envelope(obs):
    """End-to-end: the generator's AI tail resolves even when the model returns code
    blocks with step headers instead of JSON."""
    def step_caller(spec, prompt, response_schema, timeout_s):
        if '"verdict"' in prompt or "reviewing generated PySpark" in prompt:
            return RawCompletion(text=json.dumps(
                {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "ok"}))
        sec = prompt.split("Translate EACH numbered line below", 1)[-1]
        idxs = [int(m.group(1)) for m in re.finditer(r"\[(\d+)\]\s+kind=", sec)]
        blocks = [f"## Step {i}\n```python\nF.lit({i})\n```" for i in idxs]
        return RawCompletion(text="Sure, here you go:\n\n" + "\n\n".join(blocks))
    gen, _, _, _ = _generator(obs, caller=step_caller)
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))
    assert "__PENDING_" not in result.artifact


async def test_translator_reports_missing_lines_loudly(obs):
    def dropping_caller(spec, prompt, response_schema, timeout_s):
        if '"verdict"' in prompt or "reviewing generated PySpark" in prompt:
            return RawCompletion(text=json.dumps(
                {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "ok"}))
        return RawCompletion(text="Here are the translations:\n(none)")   # no objects at all
    gen, _, _, _ = _generator(obs, caller=dropping_caller)
    with pytest.raises(TranslationError):
        await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))


async def test_translator_positional_fallback_when_labels_missing(obs):
    """Model returns unlabeled/renumbered code blocks; when the count matches the
    requested lines, map positionally so the run still succeeds."""
    def renumbering_caller(spec, prompt, response_schema, timeout_s):
        if '"verdict"' in prompt or "reviewing generated PySpark" in prompt:
            return RawCompletion(text=json.dumps(
                {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "ok"}))
        sec = prompt.split("Translate EACH numbered line below", 1)[-1]
        n = len(re.findall(r"\[(\d+)\]\s+kind=", sec))
        # emit N code blocks but renumber them 1..N (NOT the real indices)
        blocks = [f"## Step {k + 1}\n```python\nF.lit({k})\n```" for k in range(n)]
        return RawCompletion(text="\n\n".join(blocks))
    gen, _, _, _ = _generator(obs, caller=renumbering_caller, chunk_size=8)
    result = await gen.generate({"dataflow_id": "8842", "feedback": {}}, cfg(dataflow_id="8842"))
    assert "__PENDING_" not in result.artifact          # positional mapping filled every slot


async def test_no_hardcoded_inputs_divergent_fixtures(obs):
    ir_a = DataflowIR(dataflow_id="AAA", nodes=(
        IRNode(node_id="na", op_type="DataSet", config={"table": "schema_a.t1"}),))
    ir_b = DataflowIR(dataflow_id="BBB", nodes=(
        IRNode(node_id="nb", op_type="DataSet", config={"table": "schema_b.t2"}),))

    store_a, store_b = FakeStore(), FakeStore()
    gen_a, _, _, _ = _generator(obs, ir=ir_a, store=store_a)
    gen_b, _, _, _ = _generator(obs, ir=ir_b, store=store_b)
    ra = await gen_a.generate({"dataflow_id": "AAA", "feedback": {}}, cfg(dataflow_id="AAA"))
    rb = await gen_b.generate({"dataflow_id": "BBB", "feedback": {}}, cfg(dataflow_id="BBB"))

    assert "schema_a.t1" in ra.artifact and "schema_a.t1" not in rb.artifact
    assert ra.node_keys == ["na"] and rb.node_keys == ["nb"]         # keys from input, not literals
    assert store_a.writes[0][0] == "AAA" and store_b.writes[0][0] == "BBB"
