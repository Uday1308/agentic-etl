"""cd_codegen.assembly — splice translations and emit node-addressable PySpark.

Blueprint §9.5 hard constraint: "The output must be node-addressable — keyed per
source node or table — so the Classifier can partition it."

The emitted artifact therefore has one clearly delimited section per node:

    # [node: <node_id>] op=<op_type> origin=<mapped|hybrid|ai>
    <code>
    # [/node: <node_id>]

The Classifier splits on these markers; the evaluator's issues and the per-issue
HITL reference nodes through them (``ref="node:<id>"``); and ``FeedbackApplier``
patches individual sections by marker. ``split_sections`` is the shared parser so
patching and splitting can never drift from emission.
"""
from __future__ import annotations

import re

from agents.cd_codegen.ir import DataflowIR, NodeCode

_HEADER = "# [node: {nid}] op={op} origin={origin}"
_FOOTER = "# [/node: {nid}]"
_SECTION_RE = re.compile(
    r"^# \[node: (?P<nid>[^\]]+)\] op=(?P<op>\S+) origin=(?P<origin>\S+)\n"
    r"(?P<body>.*?)"
    r"^# \[/node: (?P=nid)\]$",
    re.DOTALL | re.MULTILINE,
)


class AssemblyError(RuntimeError):
    """Raised when splicing leaves unresolved slots or sections are malformed."""


class CodeAssembler:
    """Pure service: NodeCode list + translations -> the final artifact string."""

    def splice(self, node_codes: list[NodeCode], translations: dict[int, str]) -> list[NodeCode]:
        """Replace every pending slot with its translation. Fails loudly if any slot
        has no translation — a slot token must never reach the artifact."""
        out: list[NodeCode] = []
        for nc in node_codes:
            code = nc.code
            for p in nc.pending:
                if p.index not in translations:
                    raise AssemblyError(f"no translation for slot {p.slot} (node {nc.node_id})")
                code = code.replace(p.slot, translations[p.index])
            if "__PENDING_" in code:
                raise AssemblyError(f"unresolved slot remains in node {nc.node_id}")
            out.append(nc.model_copy(update={"code": code, "pending": ()}))
        return out

    def emit(self, ir: DataflowIR, node_codes: list[NodeCode]) -> str:
        """Emit the full node-addressable artifact, nodes in the given order."""
        lines = [
            f'"""Generated PySpark for DOMO dataflow {ir.dataflow_id}. Node-addressable:',
            'each section is delimited by "# [node: <id>]" markers for the Classifier."""',
            "from pyspark.sql import SparkSession",
            "from pyspark.sql import functions as F",
            "",
            "spark = SparkSession.builder.getOrCreate()",
            "",
        ]
        for nc in node_codes:
            if "__PENDING_" in nc.code:
                raise AssemblyError(f"emit called with unresolved slot in node {nc.node_id}")
            lines.append(_HEADER.format(nid=nc.node_id, op=nc.op_type, origin=nc.origin.value))
            lines.append(nc.code)
            lines.append(_FOOTER.format(nid=nc.node_id))
            lines.append("")
        return "\n".join(lines)

    # -- shared marker parsing (used by FeedbackApplier and, later, the Classifier) - #
    @staticmethod
    def split_sections(artifact: str) -> dict[str, str]:
        """node_id -> full section text (header..footer inclusive)."""
        return {m.group("nid"): m.group(0) for m in _SECTION_RE.finditer(artifact)}

    @staticmethod
    def replace_section(artifact: str, node_id: str, new_body: str) -> str:
        """Replace the body of one node's section, keeping its markers."""
        sections = CodeAssembler.split_sections(artifact)
        if node_id not in sections:
            raise AssemblyError(f"no section for node {node_id!r} in artifact")
        old = sections[node_id]
        m = _SECTION_RE.match(old)
        header_line = old.split("\n", 1)[0]
        footer_line = _FOOTER.format(nid=node_id)
        rebuilt = f"{header_line}\n{new_body.rstrip()}\n{footer_line}"
        assert m is not None
        return artifact.replace(old, rebuilt)
