"""agents.cd_codegen.sql_assembly — compose tile SQL into a runnable artifact.

Composition is the thing SQL forces on you that the DataFrame API did not. PySpark is
sequential: every step assigns a variable and node-addressability falls out for free.
SQL is declarative, so a 55-step dataflow has to become *something*. This assembler
picks: **one CTE per step, one artifact per target, ending in a plain SELECT.**

Why that shape:

* a CTE per step keeps the 1:1 mapping to DOMO tiles, so a reviewer can point at any
  step and the Validation agent can check a single node's output;
* one artifact per target keeps each output independently runnable and independently
  promotable;
* **no ``CREATE OR REPLACE TABLE`` prefix and no semicolon** — the artifact is a
  readable SELECT you can run as-is, and materialization stays a deliberate human
  decision made when the numbers are trusted.

Node addressability uses SQL comments — ``-- [node: <id>] op=<type> origin=<...>`` —
so the Classifier's section parser works unchanged from the PySpark era.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_NODE_OPEN = re.compile(r"^--\s*\[node:\s*([^\]]+?)\]\s*(.*)$", re.MULTILINE)


@dataclass
class SqlStep:
    """One CTE: a step's identifier, its body, and where the body came from."""
    node_id: str
    cte_name: str
    op_type: str
    body: str                       # a bare SELECT; no trailing comma or semicolon
    origin: str = "mapped"          # mapped | hybrid | ai
    inputs: tuple[str, ...] = ()


@dataclass
class SqlArtifact:
    target: str
    table: str                      # the table a human would materialize into
    sql: str
    node_keys: list[str] = field(default_factory=list)
    final_cte: str = ""


class SqlAssemblyError(RuntimeError):
    pass


class SqlAssembler:
    """Builds the CTE chain for one target.

    ``dependencies_of`` decides which steps are included: only the transitive inputs of
    the target are emitted, so an artifact never carries CTEs it does not use. That
    keeps each target's SQL as small as it can be, which matters a lot at 55 steps.
    """

    HEADER = (
        "-- Generated from DOMO dataflow {dataflow_id}\n"
        "-- Target: {target}\n"
        "-- Node-addressable: each CTE is delimited by `-- [node: <id>]` markers.\n"
        "-- Column style: {style}\n"
        "{note}"
    )

    #: only needed when DOMO's column names are preserved verbatim; sanitized
    #: names are already legal, so the table stays on the default protocol.
    COLUMN_MAPPING_TBLPROPERTIES = (
        "TBLPROPERTIES (\n"
        "    'delta.columnMapping.mode' = 'name',\n"
        "    'delta.minReaderVersion'   = '2',\n"
        "    'delta.minWriterVersion'   = '5'\n"
        ")\n"
    )

    NOTE_PRESERVE = (
        "-- Column names are preserved verbatim, so the table is created with Delta\n"
        "-- column mapping. That raises the table protocol version irreversibly.\n"
    )
    NOTE_SAFE = (
        "-- Column names are sanitized to match the source tables, so no column\n"
        "-- mapping and no protocol upgrade is needed.\n"
    )

    def debug_sql(self, artifact: "SqlArtifact") -> str:
        """A row-count probe for an artifact that returns nothing.

        An empty result is almost never the final SELECT's fault — some upstream step
        filtered everything away, and with a 55-CTE chain you cannot tell which by
        reading it. This re-emits the same CTEs and counts rows at every stage, so the
        step where the count drops to zero is the step to look at.

        Reads only. Run it, find the first zero, then open that CTE.
        """
        sections = self.split_sections(artifact.sql)
        names = [n for n in artifact.node_keys if n in sections]
        if not names:
            return "-- no node sections found in this artifact\n"

        # reuse the CTEs verbatim — a paraphrase would make the counts lie. The
        # materialization header is dropped: it is guidance for the real artifact and
        # only noise in a diagnostic query.
        body = artifact.sql.split("\nSELECT *\nFROM ")[0]
        with_at = body.find("WITH\n")
        if with_at != -1:
            body = body[with_at:]
        probes = "\nUNION ALL\n".join(
            f"SELECT {i:>3} AS step, {name!r} AS cte, COUNT(*) AS rows FROM {name}"
            for i, name in enumerate(names, start=1)
        )
        return (
            "-- Row counts per CTE. Find the FIRST step where rows drops to 0 — that is\n"
            "-- where the data is being lost, and the step to inspect.\n"
            "--\n"
            "-- Usual causes, in the order they actually happen:\n"
            "--   * a filter comparing against a value that no longer occurs (a pinned\n"
            "--     `_BATCH_LAST_RUN_` timestamp is the classic one)\n"
            "--   * conditions combined with AND where DOMO combined them with OR\n"
            "--   * a join key whose values differ by case, padding or a leading quote\n"
            "--   * an empty source table upstream of everything\n"
            f"{body}\n"
            f"{probes}\n"
            "ORDER BY step\n"
        )

    def assemble(self, *, dataflow_id: str, target: str, table: str,
                 steps: list[SqlStep], final_cte: str,
                 sources: dict[str, str] | None = None,
                 materialize: bool = True) -> SqlArtifact:
        by_name = {s.cte_name: s for s in steps}
        if final_cte not in by_name:
            raise SqlAssemblyError(
                f"final CTE {final_cte!r} is not among the steps "
                f"({', '.join(sorted(by_name)[:6])}…)")

        needed = self._dependencies_of(final_cte, by_name)
        ordered = [s for s in steps if s.cte_name in needed]

        unresolved = [s.cte_name for s in ordered if "__PENDING_" in s.body]
        if unresolved:
            raise SqlAssemblyError(
                f"{len(unresolved)} step(s) still contain unresolved placeholders "
                f"({', '.join(unresolved[:4])}) — resolve or escalate them before assembly")

        from core.domo.naming import policy as _policy

        style = _policy().mode
        note = self.NOTE_SAFE if style == "delta_safe" else self.NOTE_PRESERVE
        parts: list[str] = [self.HEADER.format(dataflow_id=dataflow_id, target=target,
                                               style=style, note=note)]
        if materialize:
            ddl = f"CREATE OR REPLACE TABLE {table}\n"
            if style != "delta_safe":
                ddl += self.COLUMN_MAPPING_TBLPROPERTIES
            parts.append(ddl + "AS")

        # Source CTEs first: they make the artifact self-contained and give the reader
        # one place to see every table it touches.
        src_ctes: list[str] = []
        for cte, tbl in (sources or {}).items():
            if cte in needed or not needed:
                src_ctes.append(self._cte(cte, f"SELECT * FROM {tbl}",
                                          node_id=cte, op_type="SOURCE", origin="mapped"))

        step_ctes = [self._cte(s.cte_name, s.body, node_id=s.node_id,
                               op_type=s.op_type, origin=s.origin) for s in ordered]

        all_ctes = src_ctes + step_ctes
        if all_ctes:
            # each CTE begins on its own line so the `-- [node: …]` marker is always
            # line-anchored — split_sections (and the Classifier) depend on that.
            parts.append("WITH\n" + "\n,\n".join(all_ctes))
        parts.append(f"\nSELECT *\nFROM {final_cte}\n")

        sql = "\n".join(parts)
        keys = [c for c in (sources or {}) if c in needed or not needed]
        keys += [s.node_id for s in ordered]
        return SqlArtifact(target=target, table=table, sql=sql, node_keys=keys,
                           final_cte=final_cte)

    # -- helpers ---------------------------------------------------------- #
    @staticmethod
    def _cte(name: str, body: str, *, node_id: str, op_type: str, origin: str) -> str:
        indented = "\n".join("    " + ln if ln.strip() else ln for ln in body.splitlines())
        return (f"-- [node: {node_id}] op={op_type} origin={origin}\n"
                f"{name} AS (\n{indented}\n)\n-- [/node: {node_id}]")

    @staticmethod
    def _dependencies_of(final: str, by_name: dict[str, SqlStep]) -> set[str]:
        """Transitive inputs of ``final``, so unused branches are not emitted."""
        needed: set[str] = set()
        stack = [final]
        while stack:
            name = stack.pop()
            if name in needed:
                continue
            needed.add(name)
            step = by_name.get(name)
            if step:
                stack.extend(i for i in step.inputs if i not in needed)
        return needed

    # -- shared section parser (the Classifier's contract) ---------------- #
    @staticmethod
    def split_sections(sql: str) -> dict[str, str]:
        """Parse ``-- [node: …]`` sections. Same grammar as the PySpark assembler, so
        the Classifier's splitter is dialect-agnostic."""
        out: dict[str, str] = {}
        matches = list(_NODE_OPEN.finditer(sql or ""))
        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(sql)
            out[m.group(1).strip()] = sql[m.start():end].rstrip() + "\n"
        return out
