"""cd_codegen.graph — assemble the agent's subgraph from the core loop.

The loop (generate -> evaluate -> HITL -> regenerate) is ``core.domo.nodes.
build_gen_eval_hitl``; this module only constructs and injects the agent's three
strategies (guide §12: "agents inject their three functions and never reimplement
the loop"). All dependencies arrive through the constructor — no globals, no
in-node construction (guide §1).

Wiring example (done once at startup by the platform's assembly point):

    graph = build_cd_codegen_graph(
        llm=services.llm,
        discovery=SparkDiscoveryReader(table=resolve_discovery_table(run)),
        store=VolumeArtifactStore(volume_root=cfg.md_cd_root, dataflow_name=run.dataflow_name),
    )
"""
from __future__ import annotations

from langgraph.graph import StateGraph

from agents.cd_codegen.assembly import CodeAssembler
from agents.cd_codegen.mapping import MapperRegistry
from agents.cd_codegen.ports import ArtifactStore, DiscoveryReader, PlanReader
from agents.cd_codegen.strategies import (
    AGENT,
    CdCodeEvaluator,
    CdCodeGenerator,
    CdFeedbackApplier,
    IssueLedger,
)
from agents.cd_codegen.translation import ExpressionTranslator
from core.domo.llm import LLMClient
from core.domo.nodes import build_gen_eval_hitl


def build_cd_codegen_graph(
    *,
    llm: LLMClient,
    discovery: DiscoveryReader | None = None,
    store: ArtifactStore,
    plan: PlanReader | None = None,
    registry: MapperRegistry | None = None,
    chunk_size: int = 8,
    hitl: bool = True,
    ai_review: bool = True,
    max_iters: int = 3,
) -> StateGraph:
    """Build the CD Codegen subgraph. Per blueprint §2/§9.5: AI generation +
    evaluation + human review are ON for this agent by default.

    ``source`` selects the generation path:
      * ``"discovery"`` (default): deterministic transpile from the discovery table,
        LLM only for the ambiguous tail. Requires ``discovery``.
      * ``"md"``: extract already-translated PySpark from the approved MD plan, LLM
        only for prose-only steps. Uses ``state['md_plan']`` (or the ``plan`` port).

    ``plan`` (optional): the approved-MD-plan source for standalone runs. In a full
    master-graph run the in-run approved plan on state['md_plan'] takes precedence.
    For the ``"discovery"`` path the plan influences the AI translation path only;
    deterministic mapping uses the discovery table exclusively."""
    assembler = CodeAssembler()
    ledger = IssueLedger()
    translator = ExpressionTranslator(llm, chunk_size=chunk_size)
    if discovery is None:
        raise ValueError("build_cd_codegen_graph requires a discovery reader")
    generator = CdCodeGenerator(
        discovery=discovery,
        translator=translator,
        store=store,
        registry=registry or MapperRegistry(),
        assembler=assembler,
        plan=plan,
    )
    evaluator = CdCodeEvaluator(llm, ai_review=ai_review, ledger=ledger)
    applier = CdFeedbackApplier(assembler=assembler, ledger=ledger)
    return build_gen_eval_hitl(
        name=AGENT,
        generator=generator,
        evaluator=evaluator,
        feedback_applier=applier,
        hitl=hitl,
        max_iters=max_iters,
    )
