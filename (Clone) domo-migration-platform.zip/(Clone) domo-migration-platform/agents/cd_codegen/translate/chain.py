"""The translation fallback chain, tiers 1-3 (ADR 032 section 3).

Tier 0 is the pack's registry, not a chain member: ``generate_sql_with_tail`` renders
through ``pack.registry``, sends only ``PlanBuild.unresolved`` here, and re-renders with
the answers spliced in. ``ChainTranslator`` is that ``translator``:

    tier 1  lakebridge  origin=transpiled  state=derived   deterministic transpilers only (allow-list)
    tier 2  llm         origin=ai          state=inferred  SqlTailTranslator; confidence >= min_confidence
    tier 3  human       (drafting origin)  confirmed / provided   -> the ETL ends awaiting_review

Every tier reports a ``TranslationAttempt`` per unit; ``unavailable`` / ``skipped`` never
count as a failure of the unit and are never hidden. Every tier's draft passes the same
post-pass and validator before it is accepted. A later tier never overrides an earlier
tier that succeeded. A unit with a ``block`` caveat goes straight to tier 3.
"""
from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

from agents.cd_codegen.translate.attempt import (
    FAILED,
    OK,
    SKIPPED,
    TIER_PROVENANCE,
    UNAVAILABLE,
    Resolution,
    TranslationAttempt,
)

#: rule-based Lakebridge transpilers (names to verify at the pinned version, D-17)
DETERMINISTIC_TRANSPILERS = frozenset({"bladebridge", "morpheus"})
KNOWN_TIERS = ("lakebridge", "llm", "human")


class TranslationConfigError(ValueError):
    pass


@dataclass(frozen=True)
class TranslationSettings:
    """``translation.*`` settings. Tier 0 always runs and is not listed."""

    tiers: tuple[str, ...] = KNOWN_TIERS
    lakebridge_enabled: bool = False
    lakebridge_mode: str = "cli"
    lakebridge_transpilers: tuple[str, ...] = tuple(sorted(DETERMINISTIC_TRANSPILERS))
    lakebridge_timeout_s: int = 600
    lakebridge_batch_budget_s: int = 3600
    min_confidence: float = 0.7
    unverified_cap: float = 0.5

    def __post_init__(self) -> None:
        unknown = [t for t in self.tiers if t not in KNOWN_TIERS]
        if unknown:
            raise TranslationConfigError(f"unknown translation tier(s) {unknown}; known: {list(KNOWN_TIERS)}")
        if list(self.tiers) != sorted(self.tiers, key=KNOWN_TIERS.index):
            raise TranslationConfigError("translation.tiers must keep the order lakebridge, llm, human")
        if self.lakebridge_mode not in ("cli", "job"):
            raise TranslationConfigError(f"lakebridge.mode must be cli or job, not {self.lakebridge_mode!r}")
        llm_backed = sorted(set(t.lower() for t in self.lakebridge_transpilers) - DETERMINISTIC_TRANSPILERS)
        if llm_backed:
            raise TranslationConfigError(
                f"lakebridge.transpilers {llm_backed} are not on the deterministic allow-list "
                f"{sorted(DETERMINISTIC_TRANSPILERS)}; tier 1 is deterministic or it is not tier 1")
        if not 0.0 <= self.unverified_cap <= self.min_confidence <= 1.0:
            raise TranslationConfigError("need 0 <= unverified_cap <= min_confidence <= 1")

    @classmethod
    def from_dict(cls, raw: dict | None) -> TranslationSettings:
        raw = dict(raw or {})
        if "review_transpiled" in raw:
            raise TranslationConfigError("translation.review_transpiled was removed: transpiled units are "
                                         "always reviewed (ADR 032 section 3)")
        lb = dict(raw.get("lakebridge") or {})
        kw: dict[str, Any] = {}
        if "tiers" in raw:
            kw["tiers"] = tuple(raw["tiers"])
        for src, dst in (("enabled", "lakebridge_enabled"), ("mode", "lakebridge_mode"),
                         ("timeout_s", "lakebridge_timeout_s"), ("batch_budget_s", "lakebridge_batch_budget_s")):
            if src in lb:
                kw[dst] = lb[src]
        if "transpilers" in lb:
            kw["lakebridge_transpilers"] = tuple(lb["transpilers"])
        for k in ("min_confidence", "unverified_cap"):
            if k in raw:
                kw[k] = float(raw[k])
        return cls(**kw)


@dataclass
class TierOutcome:
    attempt: TranslationAttempt
    sql: str = ""
    confidence: float | None = None
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass
class ChainContext:
    config: Any = None
    user_prompt: str = ""
    feedback: list = field(default_factory=list)
    issues: list = field(default_factory=list)
    hard: list = field(default_factory=list)
    #: step_id -> attempts so far (tier 2's prompt carries the earlier tiers' reasons)
    prior: dict[str, list[TranslationAttempt]] = field(default_factory=dict)


class Tier(Protocol):
    tier: int
    name: str

    async def run(self, items: list[dict], ctx: ChainContext) -> dict[str, TierOutcome]: ...


def _step(item: dict) -> str:
    return str(item.get("step") or item.get("step_id") or "")


class LakebridgeTier:
    """Tier 1: reads the batch's tier-1 cache filled by phase A (section 6, P3-12).

    ``cache`` maps a unit fingerprint or step id to ``{sql, tool, tool_version, warnings,
    error}``. With no cache (Lakebridge disabled or not installed) every unit reports
    ``unavailable``. Units with no SQL text (DOMO Magic ETL tiles) are ``skipped``.
    """

    tier, name = 1, "lakebridge"

    def __init__(self, cache: dict[str, dict] | None = None, *,
                 allowed_tools: Iterable[str] = DETERMINISTIC_TRANSPILERS, reason: str = "") -> None:
        self.cache = cache
        self.allowed = frozenset(t.lower() for t in allowed_tools)
        self.reason = reason or "Lakebridge is not enabled for this run"

    async def run(self, items: list[dict], ctx: ChainContext) -> dict[str, TierOutcome]:
        out: dict[str, TierOutcome] = {}
        for item in items:
            sid = _step(item)
            if self.cache is None:
                out[sid] = TierOutcome(TranslationAttempt(1, UNAVAILABLE, [self.reason]))
                continue
            if not item.get("source_text"):
                out[sid] = TierOutcome(TranslationAttempt(1, SKIPPED, ["unit has no SQL text to transpile"]))
                continue
            entry = self.cache.get(str(item.get("fingerprint") or "")) or self.cache.get(sid)
            if entry is None:
                out[sid] = TierOutcome(TranslationAttempt(1, SKIPPED, ["unit is not in the tier-1 cache"]))
                continue
            tool = str(entry.get("tool") or "").lower()
            att = TranslationAttempt(1, OK, tool=tool, tool_version=str(entry.get("tool_version") or ""),
                                     duration_ms=int(entry.get("duration_ms") or 0))
            if tool not in self.allowed:
                att.status, att.reasons = FAILED, [f"transpiler {tool or '(unnamed)'!r} is not allow-listed"]
            elif entry.get("error") or entry.get("warnings"):
                att.status = FAILED
                att.reasons = [str(entry.get("error") or "")] if entry.get("error") else []
                att.reasons += [f"warning: {w}" for w in entry.get("warnings") or []]
            elif not entry.get("sql"):
                att.status, att.reasons = FAILED, ["transpiler returned no SQL"]
            out[sid] = TierOutcome(att, sql=str(entry.get("sql") or "") if att.status == OK else "")
        return out


class LlmTier:
    """Tier 2: the pack's model translator (``SqlTailTranslator`` or a scripted fake)."""

    tier, name = 2, "llm"

    def __init__(self, translator: Any, *, default_confidence: float = 0.7) -> None:
        self.translator = translator
        self.default_confidence = default_confidence

    async def run(self, items: list[dict], ctx: ChainContext) -> dict[str, TierOutcome]:
        if self.translator is None:
            return {_step(i): TierOutcome(TranslationAttempt(2, UNAVAILABLE, ["no model translator configured"]))
                    for i in items}
        enriched = []
        for item in items:
            earlier = [r for a in ctx.prior.get(_step(item), []) for r in a.reasons]
            enriched.append({**item, "reasons": list(item.get("reasons") or []) + earlier})
        started = time.monotonic()
        answers = await self.translator.resolve_tail(
            _SubBuild(enriched), config=ctx.config, user_prompt=ctx.user_prompt,
            feedback=ctx.feedback, issues=ctx.issues, hard=ctx.hard)
        ms = int((time.monotonic() - started) * 1000)
        out: dict[str, TierOutcome] = {}
        for item in items:
            sid = _step(item)
            t = answers.get(sid)
            if t is None or not getattr(t, "usable", False):
                why = getattr(t, "why_not", "") if t is not None else "the model was not asked"
                out[sid] = TierOutcome(TranslationAttempt(2, FAILED, [why or "no answer"], duration_ms=ms))
                continue
            conf = getattr(t, "confidence", None)
            out[sid] = TierOutcome(TranslationAttempt(2, OK, duration_ms=ms), sql=t.sql,
                                   confidence=float(conf) if conf is not None else self.default_confidence)
        return out


class HumanTier:
    """Tier 3: a ``translation`` review item. Produces no SQL; the ETL ends awaiting_review."""

    tier, name = 3, "human"

    async def run(self, items: list[dict], ctx: ChainContext) -> dict[str, TierOutcome]:
        return {_step(i): TierOutcome(TranslationAttempt(3, SKIPPED, ["queued for human review"])) for i in items}


@dataclass
class _SubBuild:
    """The slice of ``PlanBuild`` a tail translator reads."""

    unresolved: list[dict]


@dataclass
class ChainResult:
    """One unit's answer. Duck-types ``TailTranslation`` (``sql``, ``usable``, ``why_not``)."""

    step_id: str
    attempts: list[TranslationAttempt] = field(default_factory=list)
    resolution: Resolution | None = None
    awaiting_review: bool = False

    @property
    def sql(self) -> str:
        return self.resolution.sql if self.resolution else ""

    @property
    def usable(self) -> bool:
        return bool(self.sql)

    @property
    def why_not(self) -> str:
        if self.usable:
            return ""
        reasons = [f"tier {a.tier} {a.status}: {'; '.join(a.reasons)}" for a in self.attempts if a.reasons]
        return " | ".join(reasons) or "no tier produced SQL"


class ChainTranslator:
    """``translator`` for ``generate_sql_with_tail``: tiers 1-3 in order, first success wins."""

    def __init__(self, tiers: Sequence[Tier], *, postpass: Callable[[str], str] | None = None,
                 validate: Callable[[str], list[str]] | None = None, min_confidence: float = 0.7,
                 block_caveats: Iterable[str] = ()) -> None:
        numbers = [t.tier for t in tiers]
        if any(n not in (1, 2, 3) for n in numbers) or numbers != sorted(set(numbers)):
            raise TranslationConfigError(f"chain tiers must be distinct, ascending, within 1-3; got {numbers}")
        self.tiers = list(tiers)
        self.postpass = postpass or (lambda sql: sql)
        self.validate = validate or (lambda sql: [])
        self.min_confidence = min_confidence
        self.block_caveats = frozenset(block_caveats)

    @classmethod
    def from_settings(cls, settings: TranslationSettings, *, translator: Any = None,
                      lakebridge_cache: dict | None = None, **kw: Any) -> ChainTranslator:
        tiers: list[Tier] = []
        if "lakebridge" in settings.tiers:
            tiers.append(LakebridgeTier(lakebridge_cache if settings.lakebridge_enabled else None,
                                        allowed_tools=settings.lakebridge_transpilers))
        if "llm" in settings.tiers:
            tiers.append(LlmTier(translator))
        if "human" in settings.tiers:
            tiers.append(HumanTier())
        return cls(tiers, min_confidence=settings.min_confidence, **kw)

    def _blocked(self, item: dict) -> list[str]:
        return sorted(set(item.get("caveats") or ()) & self.block_caveats)

    async def resolve_tail(self, build: Any, *, config: Any = None, user_prompt: str = "",
                           feedback: list | None = None, issues: list | None = None,
                           hard: list | None = None) -> dict[str, ChainResult]:
        items = list(getattr(build, "unresolved", None) or [])
        results: dict[str, ChainResult] = {}
        for item in items:
            sid = _step(item)
            results[sid] = ChainResult(sid, [TranslationAttempt(0, FAILED, list(item.get("reasons") or []),
                                                                caveats=list(item.get("caveats") or []))])
        ctx = ChainContext(config=config, user_prompt=user_prompt, feedback=list(feedback or []),
                           issues=list(issues or []), hard=list(hard or []),
                           prior={sid: r.attempts for sid, r in results.items()})
        pending = [i for i in items]
        for tier in self.tiers:
            if not pending:
                break
            runnable = []
            for item in pending:
                blocked = self._blocked(item)
                if blocked and tier.tier in (1, 2):
                    results[_step(item)].attempts.append(TranslationAttempt(
                        tier.tier, SKIPPED, [f"block caveat {', '.join(blocked)}: straight to review"],
                        caveats=blocked))
                else:
                    runnable.append(item)
            outcomes = await tier.run(runnable, ctx) if runnable else {}
            still: list[dict] = [i for i in pending if i not in runnable]
            for item in runnable:
                sid = _step(item)
                oc = outcomes.get(sid) or TierOutcome(TranslationAttempt(tier.tier, FAILED, ["tier gave no answer"]))
                res = results[sid]
                if oc.attempt.status == OK and oc.sql:
                    sql = self.postpass(oc.sql)
                    problems = list(self.validate(sql))
                    if not problems and tier.tier == 2 and (oc.confidence or 0.0) < self.min_confidence:
                        problems = [f"confidence {oc.confidence} below min_confidence {self.min_confidence}"]
                    if problems:
                        oc.attempt.status, oc.attempt.reasons = FAILED, oc.attempt.reasons + problems
                    else:
                        res.attempts.append(oc.attempt)
                        origin, state = TIER_PROVENANCE[tier.tier]
                        res.resolution = Resolution(
                            origin=origin, state=state, sql=sql, trace=list(res.attempts),
                            confidence=oc.confidence if tier.tier == 2 else None,
                            evidence={**oc.evidence,
                                      "earlier_reasons": [r for a in res.attempts[:-1] for r in a.reasons],
                                      "caveats": sorted({c for a in res.attempts for c in a.caveats})},
                            fingerprint=str(item.get("fingerprint") or ""))
                        continue
                res.attempts.append(oc.attempt)
                if tier.tier == 3:
                    res.awaiting_review = True
                still.append(item)
            pending = [i for i in items if i in still]
        return results


def coverage_of(origins: Iterable[str]) -> dict:
    """``{mapped, transpiled, ai, manual, unresolved}`` unit counts plus each share (%)."""
    keys = ("mapped", "transpiled", "ai", "manual", "unresolved")
    counts = dict.fromkeys(keys, 0)
    for o in origins:
        k = "mapped" if o == "hybrid" else o
        counts[k if k in counts else "unresolved"] += 1
    total = sum(counts.values())
    share = {k: (round(100.0 * v / total, 1) if total else 0.0) for k, v in counts.items()}
    return {**counts, "total": total, "share": share}


__all__ = ["ChainContext", "ChainResult", "ChainTranslator", "DETERMINISTIC_TRANSPILERS", "HumanTier",
           "LakebridgeTier", "LlmTier", "Tier", "TierOutcome", "TranslationConfigError", "TranslationSettings",
           "coverage_of"]
