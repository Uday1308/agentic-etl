"""The ``Transpiler`` port and ``FakeTranspiler`` (ADR 032 section 6, P3-12).

``transpile(units, source_dialect)`` is called ONCE per batch (phase A). ``available()`` returns None when the tool
can run, else the reason (reported as tier 1 ``unavailable``, never as a failure of a unit). Real implementations
live in ``core/lakebridge.py``, the only module with ``databricks`` imports. Only transpilers on the deterministic
allow-list (``translate.chain.DETERMINISTIC_TRANSPILERS``) may produce tier-1 output.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from agents.cd_codegen.translate.chain import DETERMINISTIC_TRANSPILERS, TranslationConfigError


@dataclass(frozen=True)
class SqlUnit:
    """One unit's tier-0 leftover: written as ``<etl_key>/<unit_id>.sql`` into the transpiler's input folder."""

    etl_key: str
    unit_id: str
    sql: str
    fingerprint: str

    @property
    def path(self) -> str:
        return f"{self.etl_key}/{self.unit_id}.sql"


@dataclass
class TranspileResult:
    fingerprint: str
    sql: str = ""
    tool: str = ""
    tool_version: str = ""
    warnings: list[str] = field(default_factory=list)
    error: str = ""
    duration_ms: int = 0

    def as_cache_entry(self) -> dict:
        return {"sql": self.sql, "tool": self.tool, "tool_version": self.tool_version, "warnings": list(self.warnings),
                "error": self.error, "duration_ms": self.duration_ms}


@runtime_checkable
class Transpiler(Protocol):
    name: str

    def transpile(self, units: list[SqlUnit], source_dialect: str) -> list[TranspileResult]: ...

    def available(self) -> str | None: ...


def assert_allowed(tool: str, allowed: Iterable[str] = DETERMINISTIC_TRANSPILERS) -> None:
    """Refuse a transpiler that is not on the rule-based allow-list (tier 1 is deterministic or it is not tier 1)."""
    allowed = list(allowed)
    if tool.lower() not in {a.lower() for a in allowed}:
        raise TranslationConfigError(f"transpiler {tool!r} is not on the deterministic allow-list "
                                     f"{sorted(allowed)}; an LLM-backed transpiler would be tier 2 (origin=ai)")


class FakeTranspiler:
    """Fixture outputs keyed by unit fingerprint or ``<etl_key>/<unit_id>.sql``; a unit not listed gets an error
    result. ``unavailable_reason`` makes ``available()`` report why (Lakebridge not installed)."""

    def __init__(self, outputs: dict[str, str] | None = None, *, name: str = "bladebridge", version: str = "fake-1",
                 unavailable_reason: str | None = None, warnings: dict[str, list[str]] | None = None) -> None:
        self.outputs = dict(outputs or {})
        self.name, self.version = name, version
        self.unavailable_reason = unavailable_reason
        self.warnings = dict(warnings or {})
        self.calls: list[list[SqlUnit]] = []

    def available(self) -> str | None:
        return self.unavailable_reason

    def transpile(self, units: list[SqlUnit], source_dialect: str) -> list[TranspileResult]:
        self.calls.append(list(units))
        out = []
        for u in units:
            sql = self.outputs.get(u.fingerprint) or self.outputs.get(u.path) or ""
            out.append(TranspileResult(u.fingerprint, sql, self.name, self.version,
                                       warnings=list(self.warnings.get(u.path, [])),
                                       error="" if sql else "no fixture output for this unit"))
        return out


__all__ = ["FakeTranspiler", "SqlUnit", "TranspileResult", "Transpiler", "assert_allowed"]
