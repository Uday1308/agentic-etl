"""The records every translation tier reports (ADR 032 section 3).

``TranslationAttempt`` is one tier's answer about one unit; ``Resolution`` is what the unit
finally resolved to, with the full trace. Hard rule 9: an ``ai`` resolution is
``state="inferred"`` with a confidence and evidence; evidence holds offsets and reasons,
never source text (hard rule 11: Snowflake literals may hold personal data).
"""
from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any

#: ``TranslationAttempt.status``
OK, PARTIAL, FAILED, UNAVAILABLE, SKIPPED = "ok", "partial", "failed", "unavailable", "skipped"
ATTEMPT_STATUSES = (OK, PARTIAL, FAILED, UNAVAILABLE, SKIPPED)

#: ``SqlStep.origin`` / ``Resolution.origin``. ``escalated`` is the unresolved passthrough.
ORIGINS = ("mapped", "hybrid", "transpiled", "ai", "manual")
#: ``Resolution.state`` (the canonical model's provenance words)
STATES = ("derived", "inferred", "confirmed", "provided")

#: tier number -> (origin, state) of what that tier produces
TIER_PROVENANCE = {0: ("mapped", "derived"), 1: ("transpiled", "derived"),
                   2: ("ai", "inferred"), 3: ("manual", "provided")}


def sha256_text(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


@dataclass
class TranslationAttempt:
    tier: int
    status: str
    reasons: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    tool: str = ""
    tool_version: str = ""
    duration_ms: int = 0

    def __post_init__(self) -> None:
        if self.status not in ATTEMPT_STATUSES:
            raise ValueError(f"unknown attempt status {self.status!r}")

    @property
    def counts_as_failure(self) -> bool:
        """``unavailable`` / ``skipped`` are never a failure of the unit (section 3)."""
        return self.status in (FAILED, PARTIAL)

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class Resolution:
    """How one unit was resolved past tier 0. ``sql`` is in memory only; records carry
    ``sql_ref`` + ``sha256`` (+ a masked preview, ``translate.artifacts``)."""

    origin: str
    state: str
    sql: str = ""
    sql_ref: str = ""
    sha256: str = ""
    trace: list[TranslationAttempt] = field(default_factory=list)
    confidence: float | None = None
    evidence: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""
    reviewed_by: str = ""

    def __post_init__(self) -> None:
        if self.origin not in ORIGINS:
            raise ValueError(f"unknown origin {self.origin!r}")
        if self.state not in STATES:
            raise ValueError(f"unknown state {self.state!r}")
        if self.sql and not self.sha256:
            self.sha256 = sha256_text(self.sql)
        if self.origin == "ai" and self.state == "inferred" and self.confidence is None:
            raise ValueError("an inferred (ai) resolution must carry a confidence (hard rule 9)")

    @property
    def needs_review(self) -> bool:
        """Every non-mapped origin is reviewed; only a reviewer's decision clears it."""
        return self.origin in ("transpiled", "ai", "manual") and self.state not in ("confirmed", "provided")

    def confirm(self, reviewer: str, *, sha256: str) -> Resolution:
        """Tier 3 accepted a lower tier's draft: provenance is kept, the reviewer added."""
        if sha256 != self.sha256:
            raise ValueError("refusing to confirm: the artifact changed since it was reviewed")
        return Resolution(origin=self.origin, state="confirmed", sql=self.sql, sql_ref=self.sql_ref,
                          sha256=self.sha256, trace=list(self.trace), confidence=self.confidence,
                          evidence=dict(self.evidence), fingerprint=self.fingerprint, reviewed_by=reviewer)

    def to_record(self) -> dict:
        """The persisted form: no SQL text."""
        return {"origin": self.origin, "state": self.state, "sql_ref": self.sql_ref, "sha256": self.sha256,
                "trace": [a.as_dict() for a in self.trace], "confidence": self.confidence,
                "evidence": dict(self.evidence), "fingerprint": self.fingerprint, "reviewed_by": self.reviewed_by}


def unit_fingerprint(source_text: str, *, source_dialect: str, engine: str = "", pack_version: str = "") -> str:
    """hash(normalized source text + source_dialect + engine + pack version), section 3 "Resume"."""
    normalized = " ".join((source_text or "").split())
    return sha256_text("\x1f".join((normalized, source_dialect, engine, pack_version)))


__all__ = ["ATTEMPT_STATUSES", "FAILED", "OK", "ORIGINS", "PARTIAL", "SKIPPED", "STATES", "TIER_PROVENANCE",
           "UNAVAILABLE", "Resolution", "TranslationAttempt", "sha256_text", "unit_fingerprint"]
