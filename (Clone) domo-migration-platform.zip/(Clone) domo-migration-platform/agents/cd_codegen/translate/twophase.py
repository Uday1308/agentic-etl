"""Phase A of the two-phase batch (ADR 032 section 6, P3-12).

Phase A is pure: every ETL's tier-0 render collects the units left unresolved; ONE ``Transpiler`` call covers their
union; each result is stored in the tier-1 cache ``<work>/translate_cache/<fingerprint>.json``. Phase B (the per-ETL
run) reads tier 1 ONLY from that cache (``LakebridgeTier``): a unit not in it is ``skipped``. ``--resume`` repeats
phase A and hits the cache, so Lakebridge is not called again for unchanged units.
"""
from __future__ import annotations

import json
import pathlib
import time
from dataclasses import dataclass, field

from agents.cd_codegen.translate.ports import SqlUnit, Transpiler, TranspileResult, assert_allowed


@dataclass
class TierOneReport:
    status: str = "unavailable"                  # ok | unavailable
    reason: str = ""
    submitted: int = 0
    cached: int = 0
    tool: str = ""
    tool_version: str = ""
    duration_ms: int = 0
    #: fingerprint -> cache entry; None when tier 1 is unavailable (LakebridgeTier then reports ``unavailable``)
    cache: dict[str, dict] | None = field(default=None)

    def as_dict(self) -> dict:
        return {"status": self.status, "reason": self.reason, "submitted": self.submitted, "cached": self.cached,
                "tool": self.tool, "tool_version": self.tool_version, "duration_ms": self.duration_ms}


def cache_dir(work: pathlib.Path | str) -> pathlib.Path:
    return pathlib.Path(work) / "translate_cache"


def read_cache(work: pathlib.Path | str, fingerprints: list[str]) -> dict[str, dict]:
    out = {}
    for fp in fingerprints:
        p = cache_dir(work) / f"{fp}.json"
        if p.exists():
            out[fp] = json.loads(p.read_text(encoding="utf-8"))
    return out


def write_cache(work: pathlib.Path | str, results: list[TranspileResult]) -> None:
    d = cache_dir(work)
    d.mkdir(parents=True, exist_ok=True)
    for r in results:
        (d / f"{r.fingerprint}.json").write_text(json.dumps(r.as_cache_entry()), encoding="utf-8")


def run_phase_a(transpiler: Transpiler | None, units: list[SqlUnit], *, source_dialect: str,
                work: pathlib.Path | str, enabled: bool = True, batch_budget_s: int = 3600) -> TierOneReport:
    """ONE transpiler call over the units not yet cached. Tier 1 absent, disabled or unavailable -> ``unavailable``
    with the reason (never a unit failure, never hidden)."""
    if not enabled or transpiler is None:
        return TierOneReport(reason="Lakebridge is not enabled for this run")
    why = transpiler.available()
    if why:
        return TierOneReport(reason=str(why))
    assert_allowed(transpiler.name)
    cache = read_cache(work, [u.fingerprint for u in units])
    todo = [u for u in units if u.fingerprint not in cache]
    t0 = time.monotonic()
    if todo:
        try:
            results = transpiler.transpile(todo, source_dialect)
        except Exception as exc:  # timeout or a crashed CLI: every unit gets the reason
            results = [TranspileResult(u.fingerprint, error=f"{type(exc).__name__}: {exc}"[:300],
                                       tool=transpiler.name) for u in todo]
        if (time.monotonic() - t0) > batch_budget_s:
            results = [TranspileResult(r.fingerprint, error="lakebridge.batch_budget_s exceeded", tool=r.tool)
                       for r in results]
        write_cache(work, results)
        cache.update({r.fingerprint: r.as_cache_entry() for r in results})
    tool = next((e.get("tool", "") for e in cache.values()), transpiler.name)
    version = next((e.get("tool_version", "") for e in cache.values()), "")
    return TierOneReport("ok", "", len(todo), len(units) - len(todo), tool, version,
                         int((time.monotonic() - t0) * 1000), cache)


__all__ = ["TierOneReport", "cache_dir", "read_cache", "run_phase_a", "write_cache"]
