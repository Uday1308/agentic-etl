"""The translation tier framework (ADR 032 section 3): attempts, resolutions, the chain, artifacts."""
from agents.cd_codegen.translate.attempt import Resolution, TranslationAttempt, sha256_text, unit_fingerprint
from agents.cd_codegen.translate.chain import (
    ChainResult,
    ChainTranslator,
    HumanTier,
    LakebridgeTier,
    LlmTier,
    TranslationSettings,
    coverage_of,
)

__all__ = ["ChainResult", "ChainTranslator", "HumanTier", "LakebridgeTier", "LlmTier", "Resolution",
           "TranslationAttempt", "TranslationSettings", "coverage_of", "sha256_text", "unit_fingerprint"]
