"""Where generated SQL text lives (ADR 032 section 3, "Where SQL text lives (literals)").

The unmasked SQL is the deliverable and is kept only on the restricted volume, under
``<volume>/<etl_key>/artifacts/<sha256>.sql``. Run records, batch reports and gate payloads
hold an ``artifact_ref``, its ``sha256`` and a MASKED preview (string literals as
``'***'``). The API serves the real text through ``GET /api/artifacts/{ref}`` after an
access check; approval records ``(artifact_ref, sha256, reviewer)`` and a changed artifact
is refused (``verify``).
"""
from __future__ import annotations

import json
import pathlib
import re
from dataclasses import dataclass

from agents.cd_codegen.translate.attempt import sha256_text
from core.literals import mask_literals

_KEY = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$")
_SHA = re.compile(r"^[0-9a-f]{64}$")
PREVIEW_CHARS = 2000


def masked_preview(text: str, limit: int = PREVIEW_CHARS) -> str:
    masked = mask_literals(text)
    return masked if len(masked) <= limit else masked[:limit] + "\n-- ... (truncated)"


class ArtifactError(ValueError):
    pass


@dataclass(frozen=True)
class ArtifactRecord:
    artifact_ref: str
    sha256: str
    preview: str

    def as_dict(self) -> dict:
        return {"artifact_ref": self.artifact_ref, "sha256": self.sha256, "preview": self.preview}


def _parse_ref(ref: str) -> tuple[str, str]:
    key, _, sha = (ref or "").partition("/")
    if not _KEY.match(key) or ".." in key or not _SHA.match(sha):
        raise ArtifactError(f"not an artifact ref: {ref!r}")
    return key, sha


def _paths(volume: pathlib.Path | str, ref: str) -> tuple[pathlib.Path, pathlib.Path]:
    key, sha = _parse_ref(ref)
    base = pathlib.Path(volume) / key / "artifacts"
    return base / f"{sha}.sql", base / f"{sha}.json"


def write_artifact(volume: pathlib.Path | str, etl_key: str, text: str, *, source_id: str = "",
                   kind: str = "sql") -> ArtifactRecord:
    """Store ``text`` content-addressed under the ETL's folder; idempotent."""
    if not _KEY.match(etl_key or "") or ".." in etl_key:
        raise ArtifactError(f"unsafe etl_key {etl_key!r}")
    sha = sha256_text(text)
    ref = f"{etl_key}/{sha}"
    sql_path, meta_path = _paths(volume, ref)
    sql_path.parent.mkdir(parents=True, exist_ok=True)
    if not sql_path.exists():
        sql_path.write_text(text, encoding="utf-8")
    meta_path.write_text(json.dumps({"etl_key": etl_key, "source_id": source_id, "kind": kind,
                                     "sha256": sha}), encoding="utf-8")
    return ArtifactRecord(ref, sha, masked_preview(text))


def artifact_meta(volume: pathlib.Path | str, ref: str) -> dict:
    _, meta_path = _paths(volume, ref)
    if not meta_path.exists():
        raise FileNotFoundError(ref)
    return json.loads(meta_path.read_text(encoding="utf-8"))


def read_artifact(volume: pathlib.Path | str, ref: str) -> str:
    sql_path, _ = _paths(volume, ref)
    if not sql_path.exists():
        raise FileNotFoundError(ref)
    return sql_path.read_text(encoding="utf-8")


def current_sha256(volume: pathlib.Path | str, ref: str) -> str:
    return sha256_text(read_artifact(volume, ref))


def verify(volume: pathlib.Path | str, ref: str, approved_sha256: str) -> None:
    """Refuse an artifact whose current hash differs from the approved one."""
    now = current_sha256(volume, ref)
    if now != approved_sha256:
        raise ArtifactError(f"artifact {ref} changed since it was approved "
                            f"(approved {approved_sha256[:12]}, now {now[:12]}); review it again")


__all__ = ["ArtifactError", "ArtifactRecord", "artifact_meta", "current_sha256", "mask_literals",
           "masked_preview", "read_artifact", "verify", "write_artifact"]
