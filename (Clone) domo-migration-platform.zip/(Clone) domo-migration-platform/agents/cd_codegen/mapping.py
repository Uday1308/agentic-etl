"""cd_codegen.mapping — deterministic Python mapping for the known tile vocabulary.

Blueprint §9.5: "Known operations are mapped in Python with no LLM call; only unknown
operations are sent to the model." This module is that first half.

Design (guide §1): **Strategy** — each tile family is an ``OpMapper`` with
``can_map``/``map``; **Registry** — ``MapperRegistry`` resolves op_type -> mapper and
is the single place the known vocabulary is declared. Mappers are pure: IRNode +
naming context in, ``NodeCode`` out. A mapper may return *hybrid* code containing
``PendingTranslation`` slots when the tile is known but an embedded expression is not
(the classic Beast-Mode formula case) — that keeps the deterministic scaffold
deterministic while routing only the genuinely ambiguous fragment to the model.

No LLM imports here, by construction.
"""
from __future__ import annotations

import abc
import json
import re

from agents.cd_codegen.ir import IRNode, NodeCode, Origin, PendingTranslation


def sanitize_var(node_id: str) -> str:
    v = re.sub(r"\W+", "_", node_id).strip("_").lower()
    return f"df_{v or 'node'}"


class MappingContext:
    """Naming + pending-slot allocation shared across one generation pass."""

    def __init__(self) -> None:
        self._vars: dict[str, str] = {}
        self._pending_counter = 0

    def var(self, node_id: str) -> str:
        if node_id not in self._vars:
            base = sanitize_var(node_id)
            candidate, i = base, 1
            while candidate in self._vars.values():
                candidate = f"{base}_{i}"
                i += 1
            self._vars[node_id] = candidate
        return self._vars[node_id]

    def next_pending(self, node_id: str, source: str, kind: str, context: str = "") -> PendingTranslation:
        p = PendingTranslation(index=self._pending_counter, node_id=node_id,
                               slot=f"__PENDING_{self._pending_counter}__",
                               source=source, kind=kind, context=context)
        self._pending_counter += 1
        return p


class OpMapper(abc.ABC):
    """Strategy interface: one tile family, deterministically mapped."""

    op_types: tuple[str, ...] = ()

    def can_map(self, node: IRNode) -> bool:
        return node.op_type in self.op_types

    @abc.abstractmethod
    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode: ...

    # -- shared helpers ------------------------------------------------------ #
    @staticmethod
    def _in(node: IRNode, ctx: MappingContext, idx: int = 0) -> str:
        if len(node.inputs) <= idx:
            raise ValueError(f"node {node.node_id!r} ({node.op_type}) expects input #{idx + 1}")
        return ctx.var(node.inputs[idx])


class DatasetInputMapper(OpMapper):
    op_types = ("LoadFromVault", "DataSet", "Input")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        table = node.config.get("table") or node.config.get("dataSourceName") or node.name
        if not table:
            raise ValueError(f"input node {node.node_id!r} has no table/dataSourceName")
        code = f'{ctx.var(node.node_id)} = spark.table("{table}")'
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class SelectValuesMapper(OpMapper):
    """Select / rename columns. config: {"fields": [{"name": ..., "rename": ...?}]}"""

    op_types = ("SelectValues", "Select")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        fields = node.config.get("fields") or []
        if not fields:
            raise ValueError(f"SelectValues {node.node_id!r} has no fields")
        cols = []
        for f in fields:
            name, rename = f.get("name"), f.get("rename")
            cols.append(f'F.col("{name}").alias("{rename}")' if rename else f'F.col("{name}")')
        code = f"{ctx.var(node.node_id)} = {self._in(node, ctx)}.select({', '.join(cols)})"
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class FilterMapper(OpMapper):
    """Structured filters map deterministically; a raw formula becomes a pending slot.

    config either {"conditions":[{"column","operator","value"}], "match":"all|any"}
    or {"formula": "<raw expression>"} (hybrid).
    """

    op_types = ("Filter",)
    _OPS = {"EQUALS": "==", "NOT_EQUALS": "!=", "GREATER_THAN": ">", "LESS_THAN": "<",
            "GREATER_THAN_EQUALS": ">=", "LESS_THAN_EQUALS": "<="}

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        var, src = ctx.var(node.node_id), self._in(node, ctx)
        formula = node.config.get("formula")
        if formula:
            p = ctx.next_pending(node.node_id, formula, kind="filter",
                                 context=f"filter condition for tile {node.name or node.node_id}")
            code = f"{var} = {src}.filter({p.slot})"
            return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.HYBRID,
                            var=var, code=code, pending=(p,))
        conds = node.config.get("conditions") or []
        if not conds:
            raise ValueError(f"Filter {node.node_id!r} has neither conditions nor formula")
        parts: list[str] = []
        pendings: list[PendingTranslation] = []
        for c in conds:
            col, op, val = c.get("column"), c.get("operator"), c.get("value")
            if op in self._OPS:
                parts.append(f'(F.col("{col}") {self._OPS[op]} F.lit({json.dumps(val)}))')
            elif op == "IS_NULL":
                parts.append(f'(F.col("{col}").isNull())')
            elif op == "NOT_NULL":
                parts.append(f'(F.col("{col}").isNotNull())')
            elif op == "CONTAINS":
                parts.append(f'(F.col("{col}").contains({json.dumps(val)}))')
            else:
                # known tile, unknown operator -> route just this fragment to the model
                p = ctx.next_pending(node.node_id, json.dumps(c), kind="filter",
                                     context="single filter condition as JSON")
                pendings.append(p)
                parts.append(p.slot)
        joiner = " & " if (node.config.get("match", "all") == "all") else " | "
        code = f"{var} = {src}.filter({joiner.join(parts)})"
        origin = Origin.HYBRID if pendings else Origin.MAPPED
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=origin,
                        var=var, code=code, pending=tuple(pendings))


class JoinMapper(OpMapper):
    """config: {"joinType": "inner|left|right|outer", "on": [{"left","right"}]}"""

    op_types = ("Join", "MergeJoin")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        left, right = self._in(node, ctx, 0), self._in(node, ctx, 1)
        jt = (node.config.get("joinType") or "inner").lower()
        on = node.config.get("on") or []
        if not on:
            raise ValueError(f"Join {node.node_id!r} has no join keys")
        conds = " & ".join(f'({left}["{p["left"]}"] == {right}["{p["right"]}"])' for p in on)
        code = f'{ctx.var(node.node_id)} = {left}.join({right}, on={conds}, how="{jt}")'
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class GroupByMapper(OpMapper):
    """config: {"groupBy": [cols], "aggregations": [{"column","function","alias"?}]}"""

    op_types = ("GroupBy", "Aggregate")
    _FUNCS = {"SUM": "sum", "COUNT": "count", "AVG": "avg", "MIN": "min", "MAX": "max",
              "COUNT_DISTINCT": "countDistinct"}

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        keys = node.config.get("groupBy") or []
        aggs = node.config.get("aggregations") or []
        if not aggs:
            raise ValueError(f"GroupBy {node.node_id!r} has no aggregations")
        parts = []
        for a in aggs:
            fn = self._FUNCS.get((a.get("function") or "").upper())
            if fn is None:
                raise ValueError(f"GroupBy {node.node_id!r}: unknown aggregation {a.get('function')!r}")
            alias = a.get("alias") or f'{fn}_{a["column"]}'
            parts.append(f'F.{fn}("{a["column"]}").alias("{alias}")')
        key_expr = ", ".join(f'"{k}"' for k in keys)
        code = (f"{ctx.var(node.node_id)} = {self._in(node, ctx)}"
                f".groupBy({key_expr}).agg({', '.join(parts)})")
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class AppendMapper(OpMapper):
    op_types = ("Append", "Union")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        if len(node.inputs) < 2:
            raise ValueError(f"Append {node.node_id!r} needs >= 2 inputs")
        expr = self._in(node, ctx, 0)
        for i in range(1, len(node.inputs)):
            expr = f"{expr}.unionByName({self._in(node, ctx, i)}, allowMissingColumns=True)"
        code = f"{ctx.var(node.node_id)} = {expr}"
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class SortMapper(OpMapper):
    """config: {"orderBy": [{"column", "direction": "asc|desc"}]}"""

    op_types = ("Sort", "OrderBy")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        order = node.config.get("orderBy") or []
        if not order:
            raise ValueError(f"Sort {node.node_id!r} has no orderBy")
        parts = [f'F.col("{o["column"]}").{"desc" if (o.get("direction", "asc").lower() == "desc") else "asc"}()'
                 for o in order]
        code = f"{ctx.var(node.node_id)} = {self._in(node, ctx)}.orderBy({', '.join(parts)})"
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.MAPPED,
                        var=ctx.var(node.node_id), code=code)


class AddFormulaMapper(OpMapper):
    """Known tile whose expressions are the canonical unknown fragment (Beast-Mode
    style). The scaffold (withColumn chain) is deterministic; each formula becomes a
    pending slot for the translator. config: {"formulas": [{"name", "formula"}]}"""

    op_types = ("AddFormula", "Formula", "BeastMode")

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        formulas = node.config.get("formulas") or []
        if not formulas:
            raise ValueError(f"AddFormula {node.node_id!r} has no formulas")
        var, src = ctx.var(node.node_id), self._in(node, ctx)
        pendings: list[PendingTranslation] = []
        expr = src
        for f in formulas:
            p = ctx.next_pending(node.node_id, f["formula"], kind="formula",
                                 context=f'target column "{f["name"]}"')
            pendings.append(p)
            expr = f'{expr}.withColumn("{f["name"]}", {p.slot})'
        code = f"{var} = {expr}"
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.HYBRID,
                        var=var, code=code, pending=tuple(pendings))


class UnknownOpMapper(OpMapper):
    """Fallback for tiles outside the known vocabulary: the whole operation is one
    AI unit. Still deterministic scaffolding — the produced variable and the slot
    are fixed; only the slot's content comes from the model."""

    def can_map(self, node: IRNode) -> bool:  # matches anything (registry uses it last)
        return True

    def map(self, node: IRNode, ctx: MappingContext) -> NodeCode:
        var = ctx.var(node.node_id)
        inputs = ", ".join(ctx.var(i) for i in node.inputs) or "(no inputs)"
        p = ctx.next_pending(
            node.node_id,
            json.dumps({"op_type": node.op_type, "name": node.name, "config": node.config}),
            kind="operation",
            context=f"inputs available as: {inputs}; must assign the result to {var}",
        )
        return NodeCode(node_id=node.node_id, op_type=node.op_type, origin=Origin.AI,
                        var=var, code=p.slot, pending=(p,))


class MapperRegistry:
    """Registry (guide §1): the single declaration of the known vocabulary. Resolution
    is first-match over the registered mappers, with the unknown-op fallback last."""

    def __init__(self, mappers: list[OpMapper] | None = None) -> None:
        self._mappers = mappers if mappers is not None else [
            DatasetInputMapper(), SelectValuesMapper(), FilterMapper(), JoinMapper(),
            GroupByMapper(), AppendMapper(), SortMapper(), AddFormulaMapper(),
        ]
        self._fallback = UnknownOpMapper()

    def resolve(self, node: IRNode) -> OpMapper:
        for m in self._mappers:
            if m.can_map(node):
                return m
        return self._fallback

    def map_all(self, ordered_nodes: list[IRNode], ctx: MappingContext) -> list[NodeCode]:
        return [self.resolve(n).map(n, ctx) for n in ordered_nodes]
