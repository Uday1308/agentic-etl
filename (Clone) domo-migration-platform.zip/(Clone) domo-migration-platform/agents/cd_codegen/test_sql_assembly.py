"""SQL assembly: CTE composition, node addressability, no materialization."""
from __future__ import annotations

import pytest

from agents.cd_codegen.sql_assembly import SqlAssembler, SqlAssemblyError, SqlStep


def _steps():
    return [
        SqlStep(node_id="s01", cte_name="s01", op_type="JOIN",
                body="SELECT * FROM src_a", inputs=("src_a",)),
        SqlStep(node_id="s02", cte_name="s02", op_type="FORMULA",
                body="SELECT *, 1 AS x\nFROM s01", inputs=("s01",)),
        SqlStep(node_id="s99", cte_name="s99", op_type="FILTER",
                body="SELECT * FROM s01 WHERE 1=0", inputs=("s01",)),   # unused branch
    ]


def _assemble(**kw):
    args = dict(dataflow_id="8099", target="T", table="cat.sch.t",
                steps=_steps(), final_cte="s02", sources={"src_a": "bronze.a"})
    args.update(kw)
    return SqlAssembler().assemble(**args)


def test_emits_the_create_table_statement():
    sql = _assemble().sql
    assert "CREATE OR REPLACE TABLE cat.sch.t" in sql
    assert "\nAS\nWITH" in sql
    assert sql.rstrip().endswith("FROM s02") and ";" not in sql


def test_materialization_can_be_turned_off():
    """--no-materialize still gives a runnable plain SELECT for checking numbers
    before committing to a table."""
    sql = _assemble(materialize=False).sql
    assert "CREATE OR REPLACE TABLE" not in sql
    assert sql.lstrip().startswith("--") and "\nWITH\n" in sql


def test_every_cte_is_node_addressable():
    art = _assemble()
    sections = SqlAssembler.split_sections(art.sql)
    assert set(sections) == {"src_a", "s01", "s02"}
    assert art.node_keys == ["src_a", "s01", "s02"]


def test_markers_are_line_anchored_so_the_classifier_can_parse_them():
    for line in _assemble().sql.splitlines():
        if "[node:" in line:
            assert line.startswith("--"), f"marker not line-anchored: {line!r}"


def test_only_the_targets_dependencies_are_emitted():
    """An artifact should not carry CTEs it never uses — at 55 steps that matters."""
    art = _assemble()
    assert "s99" not in art.sql and "s99" not in art.node_keys


def test_source_ctes_come_first():
    sql = _assemble().sql
    assert sql.index("[node: src_a]") < sql.index("[node: s01]")


def test_unknown_final_cte_fails_loud():
    with pytest.raises(SqlAssemblyError, match="not among the steps"):
        _assemble(final_cte="nope")


def test_unresolved_placeholder_never_reaches_an_artifact():
    steps = _steps()
    steps[1] = SqlStep(node_id="s02", cte_name="s02", op_type="FORMULA",
                       body="SELECT *, __PENDING_0__ AS x FROM s01", inputs=("s01",))
    with pytest.raises(SqlAssemblyError, match="unresolved placeholders"):
        _assemble(steps=steps)


def test_origin_is_recorded_per_node():
    steps = _steps()
    steps[1] = SqlStep(node_id="s02", cte_name="s02", op_type="CUSTOM",
                       body="SELECT * FROM s01", origin="ai", inputs=("s01",))
    assert "origin=ai" in _assemble(steps=steps).sql


def test_split_sections_shares_the_pyspark_grammar():
    """Same `[node: …]` contract, different comment character — the Classifier's
    splitter stays dialect-agnostic."""
    sections = SqlAssembler.split_sections(
        "-- [node: a] op=X origin=mapped\na AS (SELECT 1)\n-- [/node: a]\n")
    assert list(sections) == ["a"]


def test_column_mapping_only_when_names_are_preserved():
    """Sanitized names are already legal, so the DDL must NOT enable column mapping —
    that raises the table protocol version irreversibly for no benefit."""
    from core.domo.naming import IdentifierPolicy, set_policy

    sql = _assemble().sql
    assert "Column style: delta_safe" in sql
    assert "delta.columnMapping.mode" not in sql

    previous = set_policy(IdentifierPolicy(mode="preserve"))
    try:
        preserved = _assemble().sql
        # preserving DOMO's spaces DOES require it, and the DDL sets it
        assert "delta.columnMapping.mode" in preserved
        assert "minWriterVersion" in preserved
    finally:
        set_policy(previous)


def test_debug_sql_counts_every_cte():
    """An empty result is almost never the final SELECT's fault. The probe re-emits
    the same CTEs and counts rows at each stage so the losing step is obvious."""
    art = _assemble()
    dbg = SqlAssembler().debug_sql(art)
    for name in art.node_keys:
        assert f"COUNT(*) AS rows FROM {name}" in dbg
    assert "ORDER BY step" in dbg
    assert dbg.rstrip().count("UNION ALL") == len(art.node_keys) - 1


def test_debug_sql_is_read_only():
    dbg = SqlAssembler().debug_sql(_assemble())
    for word in ("CREATE ", "INSERT ", "DELETE ", "UPDATE ", "MERGE ", "DROP "):
        assert word not in dbg.upper()


def test_debug_sql_reuses_the_real_ctes():
    """It must probe the SAME definitions, not a paraphrase, or the counts lie."""
    art = _assemble()
    dbg = SqlAssembler().debug_sql(art)
    assert "-- [node: s01]" in dbg and "s01 AS (" in dbg
