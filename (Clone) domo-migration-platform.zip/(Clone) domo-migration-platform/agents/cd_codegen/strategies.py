"""cd_codegen.strategies — the three behaviours injected into the shared loop.

These are the agent's implementations of the core Strategy interfaces (guide §12);
``core.domo.nodes.build_gen_eval_hitl`` owns the loop, the HITL pause, and iteration —
nothing here reimplements any of that.

* ``CdCodeGenerator``  — IR -> mapping (deterministic) -> translation (AI tail,
  fan-out merged by index) -> assembly (node-addressable) -> versioned write.
* ``CdCodeEvaluator``  — two-stage: deterministic static checks first (syntax,
  node coverage, unresolved slots), then an LLM review; deterministic errors
  dominate the verdict.
* ``CdFeedbackApplier`` — per-issue apply/keep: accepted issues with a suggested
  fix are patched into the exact node section they reference; everything else
  flows back into regeneration via the accumulated feedback (P1) that the
  generator layers into its prompts.
"""
from __future__ import annotations

import ast
import json

from agents.cd_codegen.assembly import CodeAssembler
from agents.cd_codegen.ir import DataflowIR, Origin
from agents.cd_codegen.mapping import MapperRegistry, MappingContext
from agents.cd_codegen.ports import ArtifactStore, DiscoveryReader, PlanReader
from agents.cd_codegen.prompts import EVALUATOR_BASE_PROMPT
from agents.cd_codegen.translation import ExpressionTranslator
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.nodes import Evaluator, FeedbackApplier, Generator
from core.domo.prompts import PromptLayers
from core.domo.schemas import EvalResult, GenResult, HumanFeedback, Issue, Severity, Verdict

AGENT = "cd_codegen"


def _cfg(config) -> dict:
    return dict((config or {}).get("configurable", {}) or {})


def _artifact_key(artifact: str) -> str:
    import hashlib
    return hashlib.sha256(artifact.encode("utf-8")).hexdigest()[:16]


class IssueLedger:
    """Bridges evaluator -> feedback applier within the frozen core contract.

    ``FeedbackApplier.apply(result, feedback)`` receives ids the human accepted but
    not the issue bodies. The evaluator records each round's issues here, keyed by
    the hash of the artifact they were raised against; the applier looks them up by
    the same hash. Deterministic, thread-safe, bounded (per-run graphs are built per
    wiring, and keys are content-addressed, so concurrent runs cannot collide)."""

    def __init__(self, max_entries: int = 64) -> None:
        import threading
        self._lock = threading.Lock()
        self._max = max_entries
        self._entries: dict[str, list[dict]] = {}

    def record(self, artifact: str, issues: list[Issue]) -> None:
        with self._lock:
            if len(self._entries) >= self._max:
                self._entries.pop(next(iter(self._entries)))
            self._entries[_artifact_key(artifact)] = [i.model_dump(mode="json") for i in issues]

    def lookup(self, artifact: str) -> list[dict]:
        with self._lock:
            return list(self._entries.get(_artifact_key(artifact), []))


class CdCodeGenerator(Generator):
    """Deterministic-first generation with an AI tail, per blueprint §9.5."""

    def __init__(self, discovery: DiscoveryReader, translator: ExpressionTranslator,
                 store: ArtifactStore, registry: MapperRegistry | None = None,
                 assembler: CodeAssembler | None = None,
                 plan: PlanReader | None = None) -> None:
        self._discovery = discovery
        self._translator = translator
        self._store = store
        self._registry = registry or MapperRegistry()
        self._assembler = assembler or CodeAssembler()
        self._plan = plan

    async def generate(self, state, config) -> GenResult:
        c = _cfg(config)
        dataflow_id = state.get("dataflow_id") or c.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("cd_codegen: dataflow_id missing from state and config")
        iteration = int(c.get("iteration", 1) or 1)

        # 1) IR from discovery (typed, ordered, validated)
        ir: DataflowIR = self._discovery.read(dataflow_id)
        ordered = ir.ordered()

        # 2) deterministic mapping — known ops produce code with NO model involvement
        ctx = MappingContext()
        node_codes = self._registry.map_all(ordered, ctx)
        pending = [p for nc in node_codes for p in nc.pending]

        # 3) AI tail — only the unknown fragments, chunk fan-out, merge by index.
        #    CONTRACT (team decision): the human-approved MD plan is consulted HERE
        #    and only here — the deterministic mapping above never sees it. Resolved
        #    lazily so a fully-deterministic dataflow never reads the plan at all.
        #    Prompt priority: accumulated human feedback (P1) + hard constraints,
        #    the run's user prompt (P2), evaluator issues from the last round (P3),
        #    plan as approved context in the base (P4).
        translations: dict[int, str] = {}
        if pending:
            feedback: list[HumanFeedback] = list((state.get("feedback") or {}).get(AGENT, []))
            hard = [h for fb in feedback for h in fb.hard_constraints]
            prior_eval = (state.get(AGENT) or {}).get("eval") or {}
            agent_issues = [Issue(**i) for i in prior_eval.get("issues", [])]
            user_prompt = str((state.get("prompt_layers") or {}).get(AGENT, "") or "")
            plan_context = self._resolve_plan(state, dataflow_id)
            translations = await self._translator.translate(
                pending, config=config, user_prompt=user_prompt,
                human_feedback=feedback, agent_feedback=agent_issues,
                hard_constraints=hard, plan_context=plan_context,
            )

        # 4) splice + emit node-addressable artifact
        spliced = self._assembler.splice(node_codes, translations)
        artifact = self._assembler.emit(ir, spliced)

        # 5) durable write, versioned by iteration (idempotent key: dataflow/node/iteration)
        path = self._store.write(dataflow_id, iteration, artifact)

        origins = {nc.node_id: nc.origin.value for nc in spliced}
        return GenResult(
            artifact=artifact,
            node_keys=[nc.node_id for nc in spliced],
            meta={
                "artifact_path": path,
                "iteration": iteration,
                "origins": origins,
                "counts": {
                    "nodes": len(spliced),
                    "mapped": sum(1 for v in origins.values() if v == Origin.MAPPED.value),
                    "hybrid": sum(1 for v in origins.values() if v == Origin.HYBRID.value),
                    "ai": sum(1 for v in origins.values() if v == Origin.AI.value),
                    "llm_lines": len(pending),
                },
            },
        )

    def _resolve_plan(self, state, dataflow_id: str) -> str:
        """Resolution order: (1) the in-run approved plan on state['md_plan'] (the
        artifact the human just approved in the master graph), (2) the injected
        PlanReader port (standalone runs), (3) none — the AI path proceeds with the
        source expressions alone. Called only when pending units exist, so a fully
        deterministic dataflow never reads the plan at all."""
        gen = ((state.get("md_plan") or {}).get("gen") or {})
        artifact = gen.get("artifact")
        if isinstance(artifact, str) and artifact.strip():
            return artifact
        if self._plan is not None:
            return self._plan.read(dataflow_id) or ""
        return ""


class CdCodeEvaluator(Evaluator):
    """Static checks first (cheap, deterministic, non-negotiable), then LLM review."""

    def __init__(self, llm: LLMClient, *, ai_review: bool = True,
                 ledger: IssueLedger | None = None) -> None:
        self._llm = llm
        self._ai_review = ai_review
        self._ledger = ledger

    async def evaluate(self, result: GenResult, state) -> EvalResult:
        static_issues = self._static_checks(result)
        has_error = any(i.severity == Severity.ERROR for i in static_issues)

        llm_eval: EvalResult | None = None
        if self._ai_review and not has_error:
            llm_eval = await self._llm_review(result, state)

        issues = static_issues + (list(llm_eval.issues) if llm_eval else [])
        if has_error:
            verdict, confidence = Verdict.REVISE, 0.0
            summary = "deterministic checks failed; regeneration required"
        elif llm_eval is not None:
            verdict, confidence, summary = llm_eval.verdict, llm_eval.confidence, llm_eval.summary
        else:
            verdict, confidence, summary = Verdict.PASS, 1.0, "static checks passed (AI review off)"
        if self._ledger is not None:
            self._ledger.record(result.artifact, issues)
        return EvalResult(verdict=verdict, confidence=confidence, issues=issues, summary=summary)

    # -- deterministic layer -------------------------------------------------- #
    def _static_checks(self, result: GenResult) -> list[Issue]:
        issues: list[Issue] = []
        artifact = result.artifact

        try:
            ast.parse(artifact)
        except SyntaxError as e:
            issues.append(Issue(id="static-syntax", severity=Severity.ERROR,
                                ref=f"node:{self._node_at_line(artifact, e.lineno)}",
                                message=f"generated code does not parse: {e.msg} (line {e.lineno})"))

        sections = CodeAssembler.split_sections(artifact)
        for nid in result.node_keys:
            if nid not in sections:
                issues.append(Issue(id=f"static-missing-{nid}", severity=Severity.ERROR,
                                    ref=f"node:{nid}",
                                    message="node has no addressable section in the artifact"))
        if "__PENDING_" in artifact:
            issues.append(Issue(id="static-slot", severity=Severity.ERROR, ref="node:unknown",
                                message="unresolved translation slot left in artifact"))
        return issues

    @staticmethod
    def _node_at_line(artifact: str, lineno: int | None) -> str:
        if not lineno:
            return "unknown"
        current = "unknown"
        for i, line in enumerate(artifact.split("\n"), start=1):
            if line.startswith("# [node: "):
                current = line.split("# [node: ", 1)[1].split("]", 1)[0]
            if i >= lineno:
                break
        return current

    # -- AI layer -------------------------------------------------------------- #
    async def _llm_review(self, result: GenResult, state) -> EvalResult:
        layers = PromptLayers(
            base=EVALUATOR_BASE_PROMPT
            + "\n\nNODE KEYS: " + json.dumps(result.node_keys)
            + "\n\nCODE:\n" + result.artifact,
        )
        res = await self._llm.complete(Role.EVALUATOR, layers, pool="evaluation",
                                       response_schema=EvalResult, config=self._config_of(state))
        if res.parsed is None:
            # An unusable review must not silently pass code (guide §1: fail loud-ish,
            # but an eval outage shouldn't crash the run) -> demand another round.
            return EvalResult(verdict=Verdict.REVISE, confidence=0.0,
                              summary="evaluator response unparseable; requiring another pass")
        return res.parsed

    @staticmethod
    def _config_of(state) -> dict:
        # evaluator runs inside the loop's evaluate node; core tags obs context via
        # config injected there. State carries the run identifiers for fallback.
        return {"configurable": {
            "environment": state.get("environment", "dev"),
            "thread_id": state.get("thread_id", ""),
            "dataflow_id": state.get("dataflow_id", ""),
            "obs_run_id": state.get("obs_run_id", ""),
            "agent": AGENT, "node": "evaluate",
            "iteration": (state.get(AGENT) or {}).get("iteration", 0),
        }}


class CdFeedbackApplier(FeedbackApplier):
    """Per-issue apply/keep (blueprint §9.5): accepted issues that carry a suggested
    fix and an addressable ref are patched deterministically into that node's
    section. Rejected issues are kept only as history (the loop already accumulates
    feedback; the generator layers it at P1 on regeneration)."""

    def __init__(self, assembler: CodeAssembler | None = None,
                 ledger: IssueLedger | None = None) -> None:
        self._assembler = assembler or CodeAssembler()
        self._ledger = ledger

    def apply(self, result: GenResult, feedback: list[HumanFeedback]) -> GenResult:
        if not feedback:
            return result
        latest = feedback[-1]
        if not latest.accepted_issue_ids:
            return result

        # The human accepted issue IDs; the bodies come from the ledger the evaluator
        # recorded against exactly this artifact (content-addressed by hash).
        recorded = self._ledger.lookup(result.artifact) if self._ledger else []
        issues_by_id = {i["id"]: i for i in recorded}
        issues_by_id.update({i["id"]: i for i in result.meta.get("eval_issues", [])})
        artifact = result.artifact
        applied: list[str] = []
        for iid in latest.accepted_issue_ids:
            issue = issues_by_id.get(iid)
            if not issue or not issue.get("suggested_fix"):
                continue
            ref = issue.get("ref", "")
            if not ref.startswith("node:"):
                continue
            node_id = ref.split("node:", 1)[1]
            try:
                artifact = self._assembler.replace_section(artifact, node_id, issue["suggested_fix"])
                applied.append(iid)
            except Exception:
                # not addressable after all -> leave for regeneration, don't corrupt
                continue

        meta = dict(result.meta)
        meta["applied_issue_ids"] = applied
        return result.model_copy(update={"artifact": artifact, "meta": meta})
