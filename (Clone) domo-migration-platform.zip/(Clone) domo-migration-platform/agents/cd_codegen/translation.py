"""cd_codegen.translation — the AI tail for expressions the mappers can't handle.

Blueprint §9.5: "multiple lines are batched into a chunk and translated line by line
with worked examples, fanned out over the translation pool and merged by line index."

Design:
  * ``ChunkTranslationResponse`` is a structured response schema — the model must
    return each line with its **global index**, which is what makes the merge exact
    and order-independent (fan-out results can arrive in any order).
  * ``ExpressionTranslator`` batches pending units into chunks (size from config),
    issues one ``LLMClient.complete`` per chunk concurrently with ``asyncio.gather``
    — bounded automatically because ``complete`` acquires the ``cd_translation``
    pool — and merges results **by index** into ``dict[int, str]``.
  * Missing or duplicate indices fail loudly (guide §1): a silent gap here would
    ship a slot token into generated code.
  * Prompt-priority layering is honoured: base + worked examples are P4, evaluator
    issues arrive as P3, the run's user prompt as P2, and accumulated human feedback
    as P1 with hard constraints (core assembler enforces the order).

Only ``core.domo.llm.LLMClient`` is used — never a raw endpoint (guide §14).
"""
from __future__ import annotations

import asyncio
import json
import re

from pydantic import BaseModel, Field

from agents.cd_codegen.ir import PendingTranslation
from agents.cd_codegen.prompts import TRANSLATOR_BASE_PROMPT
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.prompts import PromptLayers
from core.domo.schemas import HumanFeedback, Issue

POOL = "cd_translation"


class TranslatedLine(BaseModel):
    index: int = Field(description="the global index of the source line, echoed back")
    pyspark: str = Field(description="the PySpark expression/statement for this line")


class ChunkTranslationResponse(BaseModel):
    lines: list[TranslatedLine]
    confidence: float | None = None


class TranslationError(RuntimeError):
    """A chunk came back unusable (missing/duplicate indices or unparseable)."""


class ExpressionTranslator:
    """Translates pending units in chunks. DI: the sanctioned ``LLMClient`` only."""

    def __init__(self, llm: LLMClient, *, chunk_size: int = 8,
                 base_prompt: str = TRANSLATOR_BASE_PROMPT) -> None:
        if chunk_size < 1:
            raise ValueError("chunk_size must be >= 1")
        self._llm = llm
        self._chunk_size = chunk_size
        self._base_prompt = base_prompt

    async def translate(
        self,
        pending: list[PendingTranslation],
        *,
        config,
        user_prompt: str = "",
        human_feedback: list[HumanFeedback] | None = None,
        agent_feedback: list[Issue] | None = None,
        hard_constraints: list[str] | None = None,
        plan_context: str = "",
    ) -> dict[int, str]:
        """Fan out chunk translations; return ``{global_index: pyspark}``.

        ``plan_context`` is the human-approved MD plan (contract: consulted by the
        AI path only). It rides in the base layer, so explicit human feedback (P1)
        and the run's user prompt (P2) still override it on conflict."""
        if not pending:
            return {}
        chunks = [pending[i:i + self._chunk_size] for i in range(0, len(pending), self._chunk_size)]
        results = await asyncio.gather(*(
            self._translate_chunk(chunk, config=config, user_prompt=user_prompt,
                                  human_feedback=human_feedback or [],
                                  agent_feedback=agent_feedback or [],
                                  hard_constraints=hard_constraints or [],
                                  plan_context=plan_context)
            for chunk in chunks
        ))
        # merge by index — order-independent, loss-detected
        merged: dict[int, str] = {}
        for part in results:
            for idx, code in part.items():
                if idx in merged:
                    raise TranslationError(f"duplicate translation for index {idx}")
                merged[idx] = code
        expected = {p.index for p in pending}
        missing = expected - set(merged)
        if missing:
            raise TranslationError(f"translations missing for indices {sorted(missing)}")
        return merged

    async def _translate_chunk(self, chunk: list[PendingTranslation], *, config,
                               user_prompt: str, human_feedback: list[HumanFeedback],
                               agent_feedback: list[Issue],
                               hard_constraints: list[str],
                               plan_context: str = "") -> dict[int, str]:
        base = self._base_prompt
        if plan_context:
            base += ("\n\nAPPROVED MIGRATION PLAN (human-reviewed; follow its intent for "
                     "naming, semantics, and edge-case handling where the source is "
                     "ambiguous):\n" + plan_context)
        layers = PromptLayers(
            base=base + "\n\n" + self._render_chunk(chunk),
            user_prompt=user_prompt,
            human_feedback=human_feedback,
            agent_feedback=agent_feedback,
            hard_constraints=hard_constraints,
        )
        # No response_schema on purpose: models emit the per-line objects in varied
        # envelopes -- a {"lines": [...]} wrapper, a bare list, or one fenced object
        # per line, often with prose and per-line headers. We collect every
        # {index, pyspark} object wherever it appears and keep this chunk's indices.
        result = await self._llm.complete(Role.GENERATOR, layers, pool=POOL, config=config)
        valid = {p.index for p in chunk}
        parsed = _parse_translations(result.raw_text)
        out = {i: c for i, c in parsed.items() if i in valid and c}
        # positional fallback: if labels didn't line up but the response has exactly one
        # code block per requested line, map them in order (handles models that renumber
        # or omit indices entirely).
        if any(p.index not in out for p in chunk):
            blocks = _ordered_code_blocks(result.raw_text)
            if len(blocks) == len(chunk):
                for p, block in zip(chunk, blocks):
                    if p.index not in out and block:
                        out[p.index] = block
        if not out:
            raise TranslationError(
                f"translator produced no usable lines for indices {sorted(valid)}. "
                f"Model returned (first 300 chars): {result.raw_text[:300]!r}"
            )
        return out

    @staticmethod
    def _render_chunk(chunk: list[PendingTranslation]) -> str:
        lines = ["Translate EACH numbered line below. Echo each line's index back exactly."]
        for p in chunk:
            ctx = f"  (context: {p.context})" if p.context else ""
            lines.append(f"[{p.index}] kind={p.kind}{ctx}\n    SOURCE: {p.source}")
        return "\n".join(lines)


#: a line carrying a number (## Step 48, **48.**, [48], 48:) followed by a fenced
#: code block — the shape reasoning models use when they emit code instead of JSON.
_FENCED_WITH_INDEX = re.compile(
    r"(?:^|\n)[^\n]*?(\d+)[^\n`]*\n+```[a-zA-Z]*\n(.*?)```",
    re.DOTALL,
)

#: any fenced code block, in order (for positional fallback)
_FENCE = re.compile(r"```[a-zA-Z]*\n(.*?)```", re.DOTALL)


def _ordered_code_blocks(text: str) -> list[str]:
    """All fenced code-block contents, in document order."""
    return [m.group(1).strip() for m in _FENCE.finditer(text or "")]


def _iter_json_blocks(text: str):
    """Yield every balanced {...} / [...] substring in ``text`` (strings/escapes
    respected). Lets us recover JSON whether the model emits one wrapper, a bare
    list, or many separate objects interleaved with prose and ```fences```."""
    i, n = 0, len(text)
    while i < n:
        if text[i] in "{[":
            depth = 0
            in_str = False
            esc = False
            start = i
            while i < n:
                c = text[i]
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == '"':
                    in_str = not in_str
                elif not in_str:
                    if c in "{[":
                        depth += 1
                    elif c in "}]":
                        depth -= 1
                        if depth == 0:
                            yield text[start:i + 1]
                            break
                i += 1
        i += 1


def _parse_translations(text: str) -> dict[int, str]:
    """Collect every {index -> pyspark} pair from the model output, regardless of the
    envelope it arrived in:
      * JSON: ``{"lines": [...]}`` wrapper, a bare list, or scattered objects, and
      * fenced code: a step/line number followed by a ```python/```sql/``` block
        (e.g. ``## Step 48\\n```python\\n<code>\\n``` ``), which reasoning models emit
        when they ignore the JSON instruction.
    JSON matches win; the fenced-code scan only fills indices JSON didn't provide.
    """
    text = text or ""
    results: dict[int, str] = {}

    def ingest(obj) -> None:
        if isinstance(obj, dict):
            if isinstance(obj.get("lines"), list):
                for item in obj["lines"]:
                    ingest(item)
            elif "index" in obj and "pyspark" in obj:
                try:
                    results[int(obj["index"])] = str(obj["pyspark"]).strip()
                except (TypeError, ValueError):
                    pass
        elif isinstance(obj, list):
            for item in obj:
                ingest(item)

    for block in _iter_json_blocks(text):
        try:
            ingest(json.loads(block))
        except Exception:
            continue

    # fallback: "<header with a number>\n```lang\n<code>\n```" (e.g. "## Step 48")
    for m in _FENCED_WITH_INDEX.finditer(text):
        idx, code = int(m.group(1)), m.group(2).strip()
        if code and idx not in results:
            results[idx] = code
    return results
