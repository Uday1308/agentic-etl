"""agents.cd_codegen.sql_generator — drive the SQL path end to end.

The three pieces of the SQL path already existed separately: ``tile_registry("sql")``
renders one tile, ``PlanRenderer(dialect="sql")`` builds the reviewable plan, and
``SqlAssembler`` composes CTEs into one artifact per target. What was missing was the
thing that runs them in order — that lived in ``scripts/local_dryrun.py``, a file whose
own docstring calls it standalone and deletable. Production logic in a throwaway script
is logic nobody tests, so it lives here now and the script imports it.

    dataflow (folded)  ->  PlanRenderer  ->  [AI tail]  ->  build_sql  ->  one SqlArtifact per target

Deterministic first, model only for the real tail: ``generate_sql`` alone asks nothing
of a model, and ``generate_sql_with_tail`` asks about exactly the steps the tile
registry could not render. A step with no Python renderer AND no usable model answer
becomes a loudly-marked passthrough rather than a guess — a silent stand-in produces
plausible wrong numbers, which is the failure mode this platform exists to prevent. A
target that cannot be assembled at all is returned as a ``FailedArtifact`` — reported,
never silently dropped.

``source_columns`` turns on the one generic repair of DOMO's export artifacts. Given a
``{source: {column: type}}`` catalog — ``source_columns_from_spark`` reads it off the
tables — each source CTE becomes a named projection with the leading apostrophe
stripped from every text column, instead of a bare ``SELECT *``. See
``core.contracts.landing`` for what the artifact is and why one strip at the source
beats the per-tile ones: those fix values that are read, this also fixes values that
are merely carried through to the target.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from agents.cd_codegen.sql_assembly import SqlArtifact, SqlAssembler, SqlAssemblyError, SqlStep
from agents.cd_codegen.translate.attempt import Resolution
from agents.cd_codegen.translate.chain import coverage_of
from agents.md_plan.render import PlanBuild, PlanRenderer, resolve_dynamic_columns
from core.contracts.landing import normalize_projection

#: DOMO's own batch-watermark column, used when an as-of cutoff is requested.
DEFAULT_AS_OF_COLUMN = "_BATCH_LAST_RUN_"


class FailedArtifact:
    """A target that could not be assembled. Carries the error instead of the SQL so
    a caller iterating artifacts sees the failure rather than a missing entry."""

    def __init__(self, target: str, table: str, error: str) -> None:
        self.target = target
        self.table = table
        self.error = error
        self.sql = ""
        self.node_keys: list[str] = []
        self.final_cte = ""


@dataclass
class SqlGeneration:
    """Everything one SQL run produced: the reviewable plan and the artifacts."""
    build: PlanBuild
    artifacts: list[Any] = field(default_factory=list)
    #: step_id -> Resolution for every step resolved past tier 0 (transpiled / ai / manual),
    #: ADR 032 section 3. ``ai_resolved`` below is the read alias of the ``ai`` entries.
    resolved: dict[str, Resolution] = field(default_factory=dict)
    #: step_id -> TailTranslation for EVERY step a model was asked about, including the
    #: ones whose answer was rejected. A rejection nobody can explain is indistinguishable
    #: from the model never having been asked, and that is exactly how a passthrough
    #: survives unnoticed.
    tail_results: dict = field(default_factory=dict)

    @property
    def ai_resolved(self) -> dict[str, str]:
        """step_id -> SQL for steps a model translated (read alias of ``resolved``)."""
        return {sid: r.sql for sid, r in self.resolved.items() if r.origin == "ai"}

    @property
    def origins(self) -> dict[str, str]:
        """step_id -> mapped | transpiled | ai | manual | unresolved, one per unit."""
        out: dict[str, str] = {}
        for st in self.build.steps:
            r = self.resolved.get(st.step_id)
            out[st.step_id] = ("mapped" if st.result.resolved
                               else (r.origin if r is not None and r.sql else "unresolved"))
        return out

    @property
    def coverage_split(self) -> dict:
        """``{mapped, transpiled, ai, manual, unresolved}`` counts and shares (section 3)."""
        return coverage_of(self.origins.values())

    @property
    def plan_document(self) -> str:
        return self.build.document

    @property
    def succeeded(self) -> list[SqlArtifact]:
        return [a for a in self.artifacts if a.sql]

    @property
    def failed(self) -> list[FailedArtifact]:
        return [a for a in self.artifacts if not a.sql]

    @property
    def needed_a_model(self) -> list[str]:
        """Steps the deterministic registry could not render, regardless of whether a
        model went on to answer for them."""
        return [s.step_id for s in self.build.steps if not s.result.resolved]

    @property
    def ai_steps(self) -> list[str]:
        """Steps a model translated. These are real SQL, but nobody has checked them."""
        return sorted(sid for sid in self.ai_resolved if self.ai_resolved[sid])

    @property
    def escalated_steps(self) -> list[str]:
        """Steps left as untranslated passthroughs — no Python renderer and no usable
        model answer. Any number computed through one of these is meaningless."""
        done = {sid for sid, r in self.resolved.items() if r.sql}
        return [sid for sid in self.needed_a_model if sid not in done]

    def why_not(self, step_id: str) -> str:
        """Why a step a model was asked about did not produce usable SQL."""
        r = self.tail_results.get(step_id)
        return getattr(r, "why_not", "") if r else "no model was asked"

    @property
    def coverage_text(self) -> str:
        """The pre-ADR-032 one-line summary, derived from ``coverage_split``."""
        c = self.coverage_split
        text = f"{c['mapped']}/{c['total']} deterministic, {c['ai']} by model, {c['unresolved']} unresolved"
        if c["transpiled"] or c["manual"]:
            text += f", {c['transpiled']} transpiled, {c['manual']} manual"
        return text

    @property
    def coverage(self) -> str:
        """Read-only alias of ``coverage_text`` (DataflowCard and the DOMO goldens read it)."""
        return self.coverage_text


class SourceSchemaError(RuntimeError):
    """Raised when the source column catalog could not be read in full.

    ``columns`` holds what WAS read and ``missing`` maps each table that failed to why,
    so a caller who would rather generate with partial cleaning can catch this and pass
    ``exc.columns`` on. Raising rather than quietly returning a short catalog is
    deliberate: a source left uncleaned without anyone noticing is the exact failure
    this cleaning exists to prevent.
    """

    def __init__(self, columns: dict, missing: dict) -> None:
        self.columns = dict(columns)
        self.missing = dict(missing)
        shown = "; ".join(f"{t} ({why})" for t, why in list(self.missing.items())[:4])
        super().__init__(
            f"could not read the schema of {len(self.missing)} source table(s): {shown}"
            f"{' …' if len(self.missing) > 4 else ''}. Pass source_columns explicitly, "
            f"or catch SourceSchemaError and use .columns to generate without them.")


def source_columns_from_spark(spark: Any, build: PlanBuild) -> dict[str, dict[str, str]]:
    """Read every source table's schema into the catalog ``source_columns`` expects.

    The landed table is the only thing that knows its own columns. DOMO's export does
    not carry them — a ``source`` action holds a dataset name and id and nothing else —
    and ``tiles.output_columns`` deliberately returns None at a SOURCE rather than
    guess. So the catalog is read here, from the very tables the SQL is about to read.

    Names come back exactly as ingestion wrote them, which is what the source CTE must
    emit: putting them through the naming policy would rename columns that already
    exist under their own names.
    """
    columns: dict[str, dict[str, str]] = {}
    missing: dict[str, str] = {}
    for s in build.sources:
        try:
            columns[s["df_var"]] = dict(spark.table(s["table"]).dtypes)
        except Exception as exc:            # noqa: BLE001 — reported, never swallowed
            missing[s["table"]] = str(exc).splitlines()[0][:120]
    if missing:
        raise SourceSchemaError(columns, missing)
    return columns


def _as_column_map(value: Any) -> dict[str, str]:
    """One source's columns as ``{name: type}``, from any shape a caller has to hand.

    ``DataFrame.dtypes`` is a list of pairs and survives a JSON round trip as a list of
    lists, so both are taken. A bare list of names is refused: without the type the
    strip would be applied blind, and applying it to a numeric column retypes that
    column to STRING — a worse bug than the apostrophe it removes.
    """
    if isinstance(value, dict):
        return {str(k): str(v) for k, v in value.items()}
    pairs = list(value or [])
    if pairs and all(isinstance(p, (list, tuple)) and len(p) == 2 for p in pairs):
        return {str(n): str(t) for n, t in pairs}
    raise ValueError(
        "source_columns entries must map column name to Spark type — "
        "`dict(spark.table(t).dtypes)` is the shape. A bare list of names cannot be "
        "used: without types the artifact strip cannot tell text from a number.")


def _columns_for(source: dict, catalog: dict) -> dict[str, str] | None:
    """This source's catalog entry, under any of the names a caller would key it by.

    A caller building the catalog from Spark keys it by ``df_var``; one writing it by
    hand keys it by the table or the DOMO dataset name. All of them resolve, because a
    catalog that silently fails to match is a catalog that silently does not clean.
    """
    table = str(source.get("table") or "")
    bare = table.rsplit(".", 1)[-1]
    keys = [source.get("df_var"), table, bare,
            source.get("dataset_name"), source.get("dataset_id")]
    for key in keys:
        if key and key in catalog:
            return _as_column_map(catalog[key])
    lowered = {str(k).lower(): v for k, v in catalog.items()}
    for key in keys:
        if key and str(key).lower() in lowered:
            return _as_column_map(lowered[str(key).lower()])
    return None


def source_coverage(build: PlanBuild, source_columns: dict | None) -> tuple[list, list]:
    """``(covered, uncovered)`` sources for a catalog, without generating anything.

    A caller needs this before it has SQL to read: knowing that three of ten sources
    will go out uncleaned is the sort of thing to say up front, not to leave for
    whoever notices the marker in the artifact.
    """
    catalog = dict(source_columns or {})
    covered, uncovered = [], []
    for s in build.sources:
        (covered if catalog and _columns_for(s, catalog) else uncovered).append(s)
    return covered, uncovered


#: Put on a source the caller supplied no columns for, when it supplied some for others.
#: Silence there would be indistinguishable from a source that needed no cleaning.
UNCLEANED_NOTE = (
    "-- !!! No column list was supplied for this source, so DOMO's leading-apostrophe\n"
    "-- !!! export artifact is NOT stripped here and reaches the target as exported.\n"
    "-- !!! Add this table to source_columns, or point source_schema at a clean view.")


def _source_expressions(sources: list[dict], source_columns: dict | None,
                        as_of: str, as_of_column: str) -> dict[str, str]:
    """``df_var -> the expression each source CTE selects FROM``.

    A bare table name when there is nothing to apply, a subquery when there is. Both
    the artifact strip and the as-of clamp live here because both belong in the same
    SELECT, and both are applied at the SOURCE for the same reason: everything
    downstream then sees one consistent value.

    Cleaning at the source is the thing the six per-tile strips could not do. Each of
    those repairs one place a value is *read*; none repairs the value a projection
    *carries*, because ``SELECT *`` cannot name a column to fix it. Naming every column
    once, here, covers reads and carries alike — filters, casts, arithmetic, aggregates,
    join keys, and the columns that pass untouched into the target.
    """
    catalog = dict(source_columns or {})
    cutoff = ""
    if as_of:
        col = as_of_column or DEFAULT_AS_OF_COLUMN
        cutoff = ("\n  -- as-of cutoff: keep rows strictly older than this\n"
                  f"  WHERE `{col}` IS NULL OR `{col}` < TIMESTAMP '{as_of}'")

    out: dict[str, str] = {}
    for s in sources:
        var, table = s["df_var"], s["table"]
        cols = _columns_for(s, catalog) if catalog else None
        if cols:
            projection = ",\n    ".join(normalize_projection(cols))
            out[var] = ("(\n"
                        "  -- DOMO export artifacts stripped once, here, so every CTE\n"
                        "  -- downstream and every value written to the target is clean\n"
                        "  -- — including the columns nothing downstream ever names.\n"
                        "  SELECT\n"
                        f"    {projection}\n"
                        f"  FROM {table}{cutoff}\n"
                        ")")
        elif cutoff:
            out[var] = f"(\n  SELECT * FROM {table}{cutoff}\n)"
        else:
            out[var] = table
        if catalog and not cols:
            out[var] += "\n" + UNCLEANED_NOTE
    return out


def _escalation_body(step, reasons: str) -> str:
    upstream = step.inputs[0] if step.inputs else "/* NO INPUT */"
    return ("-- !!! UNRESOLVED STEP — DO NOT TRUST RESULTS DOWNSTREAM !!!\n"
            f"-- tile: {step.name} ({step.node_type})\n"
            f"-- reason: {reasons}\n"
            "-- This is a passthrough placeholder, NOT a translation. Replace it\n"
            "-- with the real logic before comparing anything against DOMO.\n"
            f"SELECT * FROM {upstream}")


def _pack(pack=None):
    if pack is not None:
        return pack
    from core.packs import default_pack

    return default_pack()


def _registry_of(pack, dialect: str, conversion=None):
    """``pack.registry(dialect)``; a pack that takes conversion state (the Snowflake pack: account parameters,
    capability profile, column types) also gets the ``ConversionContext`` (L13). Packs without the keyword are called
    as before."""
    if conversion is None:
        return pack.registry(dialect)
    return pack.registry(dialect, conversion=conversion)


def _merge_resolved(resolved: dict[str, Resolution] | None,
                    ai_resolved: dict[str, str] | None) -> dict[str, Resolution]:
    """``resolved`` plus the legacy ``ai_resolved`` (step_id -> SQL) as ``ai`` resolutions."""
    out = dict(resolved or {})
    for sid, sql in (ai_resolved or {}).items():
        if sql and sid not in out:
            out[sid] = Resolution(origin="ai", state="inferred", sql=sql, confidence=0.0)
    return out


def build_steps(build: PlanBuild, nodes: list[dict], *,
                ai_resolved: dict[str, str] | None = None,
                as_of: str = "", as_of_column: str = "",
                source_columns: dict | None = None,
                dialect: str = "sql", registry=None, pack=None,
                resolved: dict[str, Resolution] | None = None,
                conversion=None) -> tuple[list[SqlStep], dict[str, str]]:
    """The CTE steps and the source map — everything ``SqlAssembler`` needs.

    Split out of ``build_sql`` so the same chain can be assembled for a different
    purpose without duplicating the render/escalate/splice decision: ``probe_query``
    uses it to ask Spark what an intermediate CTE's columns actually are.
    """
    reg = registry or _registry_of(_pack(pack), dialect, conversion)
    resolved = _merge_resolved(resolved, ai_resolved)
    by_id = {str(n.get("id")): n for n in (nodes or []) if n.get("id") is not None}
    sources = _source_expressions(build.sources, source_columns, as_of, as_of_column)

    steps: list[SqlStep] = []
    for st in build.steps:
        node = by_id.get(str(st.node_id), {})
        r = reg.render(node, list(st.inputs), st.df_var)
        if r.resolved:
            body, origin = r.code, "mapped"
        elif resolved.get(st.step_id) is not None and resolved[st.step_id].sql:
            # a later tier never overrides tier 0; transpiled / ai / manual mark the CTE
            body, origin = resolved[st.step_id].sql, resolved[st.step_id].origin
        else:
            body, origin = _escalation_body(st, "; ".join(r.unresolved)), "escalated"
        steps.append(SqlStep(node_id=st.df_var, cte_name=st.df_var,
                             op_type=st.node_type, body=body,
                             origin=origin, inputs=tuple(st.inputs)))
    return steps, sources


def probe_query(build: PlanBuild, dataflow_id: str, nodes: list[dict], cte_name: str,
                **kwargs) -> str:
    """A runnable SELECT ending at ``cte_name``, for asking Spark its schema.

    A dynamic unpivot is unresolvable precisely because DOMO decides its value columns
    at run time. Spark can answer that question — but only if something assembles the
    chain up to that point and asks. This is that something.
    """
    steps, sources = build_steps(build, nodes, **kwargs)
    art = SqlAssembler().assemble(
        dataflow_id=str(dataflow_id), target=f"probe::{cte_name}", table="probe",
        steps=steps, final_cte=cte_name, sources=sources, materialize=False)
    return art.sql


def build_sql(build: PlanBuild, dataflow_id: str, nodes: list[dict], *,
              ai_resolved: dict[str, str] | None = None,
              as_of: str = "", as_of_column: str = "",
              source_columns: dict | None = None,
              materialize: bool = True, dialect: str = "sql", registry=None, pack=None,
              resolved: dict[str, Resolution] | None = None, conversion=None) -> list[Any]:
    """One artifact per output target, each a CTE chain ending in a plain SELECT.

    ``nodes`` are the merged tile dicts the plan was built from — the renderer keeps
    only its own ``Step`` view, and the tile registry needs the raw ``properties`` to
    render from. They are passed explicitly rather than smuggled onto ``build`` as an
    attribute, so the dependency is visible in the signature.

    Steps are matched to their tile by ``node_id``, never by name: DOMO permits two
    tiles to share a display name, and matching on name silently renders one tile's
    logic under another tile's id.

    ``ai_resolved`` maps ``step_id -> SQL`` for steps a model translated (see
    ``sql_translation``). It is applied only where the deterministic registry failed —
    a model never overrides a tile Python could render — and the resulting CTE is
    marked ``origin=ai`` so a reviewer can see which bodies a model wrote. Steps with
    no AI answer keep the loud passthrough.
    """
    steps, sources = build_steps(build, nodes, ai_resolved=ai_resolved,
                                 as_of=as_of, as_of_column=as_of_column,
                                 source_columns=source_columns, dialect=dialect,
                                 registry=registry, pack=pack, resolved=resolved, conversion=conversion)

    assembler = SqlAssembler()
    artifacts: list[Any] = []
    for t in build.targets:
        try:
            artifacts.append(assembler.assemble(
                dataflow_id=dataflow_id, target=t["target"], table=t["table"],
                steps=steps, final_cte=t["source_df"], sources=sources,
                materialize=materialize))
        except SqlAssemblyError as exc:
            artifacts.append(FailedArtifact(t["target"], t["table"], str(exc)))
    return artifacts


def generate_sql(dataflow: dict, *, dataflow_id: str, dataflow_name: str = "",
                 raw: dict | None = None, dialect: str = "sql",
                 ai_resolved: dict[str, str] | None = None,
                 source_catalog: str = "dev_test", source_schema: str = "domo_input",
                 target_catalog: str = "dev_test", target_schema: str = "migrated_output",
                 as_of: str = "", as_of_column: str = "",
                 source_columns: dict | None = None,
                 materialize: bool = True, pack=None,
                 resolved: dict[str, Resolution] | None = None, conversion=None) -> SqlGeneration:
    """Render the plan and assemble the SQL in one call.

    ``dataflow`` is the folded ``{"dataflow_id", "nodes", "edges"}`` shape — fold a
    standardized document with ``core.contracts.standardized.to_planner_dataflow`` or a
    discovery export with ``core.contracts.discovery.to_dataflow`` first, so this
    function has exactly one input contract regardless of which upstream produced it.
    """
    # Recover run-time-resolved column sets ONCE, so the plan and the SQL render from
    # the same enriched tiles. Doing it only inside PlanRenderer would leave build_sql
    # re-rendering the raw node and escalating a step the plan shows as resolved.
    pack = _pack(pack)
    registry = _registry_of(pack, dialect, conversion)       # one registry for the plan and the CTEs
    nodes = resolve_dynamic_columns(list(dataflow.get("nodes") or []),
                                    list(dataflow.get("edges") or []), pack=pack)
    dataflow = {**dataflow, "nodes": nodes}
    if not nodes:
        raise ValueError(
            f"cd_codegen: dataflow {dataflow_id} has no nodes, so there is nothing to "
            f"generate. Fold the standardized document or discovery export first.")

    renderer = PlanRenderer(registry, dialect=dialect, pack=pack,
                            source_catalog=source_catalog, source_schema=source_schema,
                            target_catalog=target_catalog, target_schema=target_schema)
    build = renderer.build(dataflow, raw, dataflow_id=str(dataflow_id),
                           dataflow_name=dataflow_name)
    merged = _merge_resolved(resolved, ai_resolved)
    artifacts = build_sql(build, str(dataflow_id), nodes, resolved=merged,
                          as_of=as_of, as_of_column=as_of_column,
                          source_columns=source_columns,
                          materialize=materialize, dialect=dialect, registry=registry)
    return SqlGeneration(build=build, artifacts=artifacts, resolved=merged)


async def generate_sql_with_tail(dataflow: dict, *, translator, config,
                                 dataflow_id: str, dataflow_name: str = "",
                                 user_prompt: str = "", feedback=None, issues=None,
                                 hard=None, **kwargs) -> SqlGeneration:
    """``generate_sql``, plus a model pass over the steps Python could not render.

    Two renders rather than one: the first establishes which steps are unresolved (that
    is the renderer's job, and it is the same determination ``build_sql`` makes), then
    the translator is asked about exactly those, then the artifacts are rebuilt with the
    answers spliced in. Rendering is pure and cheap; the alternative is duplicating the
    registry's resolve/unresolved logic here, where it would drift.

    ``translator`` is anything with ``resolve_tail(build, config=..., ...)`` returning
    ``step_id -> TailTranslation`` — normally ``sql_translation.SqlTailTranslator``.
    Injected rather than constructed so this stays testable without an endpoint.
    """
    first = generate_sql(dataflow, dataflow_id=dataflow_id,
                         dataflow_name=dataflow_name, **kwargs)
    if not first.build.unresolved:
        return first

    tail = await translator.resolve_tail(
        first.build, config=config, user_prompt=user_prompt,
        feedback=feedback or [], issues=issues or [], hard=hard or [])
    usable = {sid: t for sid, t in tail.items() if getattr(t, "usable", False)}
    if not usable:
        # Nothing was accepted, but the run still has to be able to say why.
        first.tail_results = tail
        return first
    # A chain result carries its own Resolution (origin transpiled / ai); a plain
    # TailTranslation is a model answer, recorded as origin=ai, state=inferred.
    resolved = {sid: (t.resolution if getattr(t, "resolution", None) is not None
                      else Resolution(origin="ai", state="inferred", sql=t.sql,
                                      confidence=getattr(t, "confidence", None) or 0.0))
                for sid, t in usable.items()}
    kwargs.pop("ai_resolved", None)
    kwargs.pop("resolved", None)
    out = generate_sql(dataflow, dataflow_id=dataflow_id, dataflow_name=dataflow_name,
                       resolved=resolved, **kwargs)
    out.tail_results = tail
    return out


__all__ = [
    "DEFAULT_AS_OF_COLUMN",
    "UNCLEANED_NOTE",
    "FailedArtifact",
    "SourceSchemaError",
    "source_columns_from_spark",
    "source_coverage",
    "SqlGeneration",
    "build_sql",
    "build_steps",
    "probe_query",
    "generate_sql",
    "generate_sql_with_tail",
]
