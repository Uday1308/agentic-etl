"""cd_codegen.md_generator — Generator that sources code from the approved MD plan.

This is the alternate CD Codegen generation path (team decision): when the MD Plan
agent has already produced fully-formed PySpark per step inside the plan document,
CD Codegen extracts that code rather than transpiling from the discovery table. Steps
the plan left as prose (no code block) fall back to the LLM, reusing the same
tolerant translation path as the discovery-based generator.

It plugs into the identical gen/eval/HITL loop (``build_gen_eval_hitl``), so the
evaluator (ast.parse + node coverage + LLM review), the per-issue HITL, and the
versioned artifact store are all unchanged. Output is node-addressable, so the
Classifier consumes it exactly as it does the transpiler's output.
"""
from __future__ import annotations

from agents.cd_codegen.ir import PendingTranslation
from agents.cd_codegen.md_extract import MdExtractError, assemble_artifact, extract_md_plan
from agents.cd_codegen.ports import ArtifactStore, PlanReader
from agents.cd_codegen.translation import ExpressionTranslator
from core.domo.nodes import Generator
from core.domo.schemas import GenResult, HumanFeedback, Issue

AGENT = "cd_codegen"


def _cfg(config) -> dict:
    return (config or {}).get("configurable", {}) if isinstance(config, dict) else {}


class MdPlanCodeGenerator(Generator):
    """Extract PySpark from the approved MD plan; LLM-fill only prose-only steps."""

    def __init__(self, translator: ExpressionTranslator, store: ArtifactStore,
                 plan: PlanReader | None = None, *, source_catalog: str | None = None,
                 source_schema: str | None = None) -> None:
        self._translator = translator
        self._store = store
        self._plan = plan
        self._source_catalog = source_catalog
        self._source_schema = source_schema

    async def generate(self, state, config) -> GenResult:
        c = _cfg(config)
        dataflow_id = state.get("dataflow_id") or c.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("cd_codegen(md): dataflow_id missing from state and config")
        iteration = int(c.get("iteration", 1) or 1)

        md_text = self._resolve_plan(state, dataflow_id)
        if not md_text.strip():
            raise MdExtractError(
                "cd_codegen(md): no MD plan available on state['md_plan'] or via the "
                "PlanReader port — this generator requires the approved plan as its source."
            )
        ex = extract_md_plan(md_text, dataflow_id=dataflow_id)

        # LLM fallback ONLY for prose-only steps. Reuse the tolerant translation path:
        # build one pending unit per prose step, translate, map results back by step.
        llm_code: dict[str, str] = {}
        if ex.llm_steps:
            feedback: list[HumanFeedback] = list((state.get("feedback") or {}).get(AGENT, []))
            hard = [h for fb in feedback for h in fb.hard_constraints]
            prior_eval = (state.get(AGENT) or {}).get("eval") or {}
            agent_issues = [Issue(**i) for i in prior_eval.get("issues", [])]
            user_prompt = str((state.get("prompt_layers") or {}).get(AGENT, "") or "")

            pending, idx_to_step = [], {}
            for i, s in enumerate(ex.llm_steps):
                idx_to_step[i] = s.step
                ctx = (f"produce a full PySpark statement assigning the result to {s.df_var}; "
                       f"upstream dataframes: {', '.join(s.inputs) or '(none)'}")
                pending.append(PendingTranslation(
                    index=i, node_id=s.df_var, slot=f"__PENDING_{i}__",
                    source=s.prose, kind="operation", context=ctx,
                ))
            translations = await self._translator.translate(
                pending, config=config, user_prompt=user_prompt,
                human_feedback=feedback, agent_feedback=agent_issues, hard_constraints=hard,
            )
            llm_code = {idx_to_step[i]: code for i, code in translations.items()}

        artifact = assemble_artifact(
            ex, llm_code=llm_code,
            source_catalog=self._source_catalog, source_schema=self._source_schema,
        )
        path = self._store.write(dataflow_id, iteration, artifact)

        node_keys = [s.df_var for s in ex.sources] + [s.df_var for s in ex.steps]
        origins = {s.df_var: "md" for s in ex.sources}
        origins.update({s.df_var: ("md" if not s.needs_llm else "ai") for s in ex.steps})
        return GenResult(
            artifact=artifact,
            node_keys=node_keys,
            meta={
                "artifact_path": path,
                "iteration": iteration,
                "source": "md_plan",
                "origins": origins,
                "coverage": ex.coverage,
                "counts": {
                    "sources": len(ex.sources),
                    "steps": len(ex.steps),
                    "writes": len(ex.writes),
                    "from_md": len(ex.code_steps),
                    "from_llm": len(ex.llm_steps),
                },
            },
        )

    def _resolve_plan(self, state, dataflow_id: str) -> str:
        """The approved plan on state['md_plan'] wins (what the human approved in the
        master graph); otherwise the injected PlanReader port (standalone runs)."""
        gen = ((state.get("md_plan") or {}).get("gen") or {})
        artifact = gen.get("artifact")
        if isinstance(artifact, str) and artifact.strip():
            return artifact
        if self._plan is not None:
            return self._plan.read(dataflow_id) or ""
        return ""
