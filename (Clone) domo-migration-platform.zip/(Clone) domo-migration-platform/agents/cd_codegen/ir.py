"""cd_codegen.ir — typed intermediate representation for code generation.

Value objects only (guide §1): frozen pydantic models, validation, no I/O.

The IR is what decouples the three phases of the generator:
  discovery rows  ->  DataflowIR  ->  (mapping + translation)  ->  NodeCode  ->  assembly

``PendingTranslation`` is the unit of AI work: a single source expression (e.g. a
Beast-Mode-style formula) with a stable ``index`` (global, for merge-by-index) and a
``slot`` token that the assembler splices the translation back into. Known operations
never produce pending units; hybrid operations (known tile, unknown embedded
expression) produce code plus pending units; unknown operations are fully pending.
"""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, field_validator, model_validator


class Origin(str, Enum):
    MAPPED = "mapped"        # fully deterministic Python mapping
    HYBRID = "hybrid"        # deterministic scaffold + AI-translated expression(s)
    AI = "ai"                # whole operation translated by the model


class IRNode(BaseModel):
    """One discovered dataflow operation (a Magic ETL tile)."""

    model_config = ConfigDict(frozen=True)

    node_id: str
    op_type: str                       # tile type as discovered (e.g. 'Filter', 'Join')
    name: str = ""                     # human label from the dataflow
    config: dict = {}                  # tile configuration as discovered
    inputs: tuple[str, ...] = ()       # upstream node_ids (order matters for joins)

    @field_validator("node_id")
    @classmethod
    def _non_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("node_id must be non-empty")
        return v


class DataflowIR(BaseModel):
    """The whole dataflow: nodes + edges implied by ``IRNode.inputs``.

    ``ordered()`` yields nodes in a deterministic topological order (Kahn), which is
    what makes generation idempotent for the same discovery input. A cycle or a
    dangling input reference fails loudly (guide §1: no silent fallbacks).
    """

    model_config = ConfigDict(frozen=True)

    dataflow_id: str
    nodes: tuple[IRNode, ...]

    @model_validator(mode="after")
    def _unique_node_ids(self) -> "DataflowIR":
        seen: set[str] = set()
        dupes: list[str] = []
        for n in self.nodes:
            if n.node_id in seen and n.node_id not in dupes:
                dupes.append(n.node_id)
            seen.add(n.node_id)
        if dupes:
            raise ValueError(
                f"duplicate node_id(s) {dupes} in dataflow {self.dataflow_id!r}. The discovery "
                f"input likely spans multiple dataflows or discovery runs — scope the read to a "
                f"single dataflow_id and a single run (e.g. filter by discovery_run_id)."
            )
        return self

    def by_id(self) -> dict[str, IRNode]:
        return {n.node_id: n for n in self.nodes}

    def ordered(self) -> list[IRNode]:
        by_id = self.by_id()
        for n in self.nodes:
            for up in n.inputs:
                if up not in by_id:
                    raise ValueError(f"node {n.node_id!r} references unknown input {up!r}")
        remaining_deps = {n.node_id: set(n.inputs) for n in self.nodes}
        # deterministic: stable sort by node_id at every step
        ready = sorted([nid for nid, deps in remaining_deps.items() if not deps])
        out: list[IRNode] = []
        while ready:
            nid = ready.pop(0)
            out.append(by_id[nid])
            newly = []
            for other, deps in remaining_deps.items():
                if nid in deps:
                    deps.discard(nid)
                    if not deps and other not in {n.node_id for n in out} and other not in ready:
                        newly.append(other)
            ready = sorted(ready + newly)
        if len(out) != len(self.nodes):
            unresolved = sorted(set(by_id) - {n.node_id for n in out})
            raise ValueError(f"dataflow has a cycle involving {unresolved}")
        return out


class PendingTranslation(BaseModel):
    """One expression the deterministic layer could not map — the AI's unit of work.

    ``index`` is the global line index used for chunk fan-out and merge-by-index;
    ``slot`` is the unique token the assembler replaces with the translation.
    """

    model_config = ConfigDict(frozen=True)

    index: int
    node_id: str
    slot: str                          # e.g. '__PENDING_3__'
    source: str                        # the source expression / config to translate
    kind: str                          # 'formula' | 'filter' | 'operation'
    context: str = ""                  # schema/columns hints for the model


class NodeCode(BaseModel):
    """Generated PySpark for one node — the node-addressable unit (blueprint §9.5)."""

    model_config = ConfigDict(frozen=True)

    node_id: str
    op_type: str
    origin: Origin
    var: str                           # the DataFrame variable this node produces
    code: str                          # body lines (may contain pending slots pre-splice)
    pending: tuple[PendingTranslation, ...] = ()
