"""cd_codegen.ports — the agent's I/O boundaries (Repository/Adapter, guide §1).

Two ports keep Spark and the volume filesystem out of the agent's logic (and out of
its contract tests):

  * ``DiscoveryReader`` — reads the Discovery agent's node/edge table for one
    dataflow and returns the typed IR. Spark implementation lazy-imports pyspark.
  * ``ArtifactStore`` — writes the generated artifact, **versioned by iteration**
    per the idempotency contract (guide §5.2): key (dataflow_id, node, iteration),
    same key -> same path -> pure overwrite; a new iteration never clobbers an
    approved earlier version.

Fakes for both live in the tests; production impls are constructed at wiring time
and injected (never inside a node).
"""
from __future__ import annotations

import abc
from typing import Any

from agents.cd_codegen.ir import DataflowIR, IRNode


class DiscoveryReader(abc.ABC):
    @abc.abstractmethod
    def read(self, dataflow_id: str) -> DataflowIR: ...


class PlanReader(abc.ABC):
    """Reads the human-approved MD plan for a dataflow, or None if unavailable.

    Contract (team decision): the plan influences ONLY the AI translation path.
    The deterministic mapping never consults it — the discovery table is the sole
    structural source of truth. The generator resolves the plan lazily, only when
    pending (AI) units exist, and prefers the in-run approved plan on state over
    this port."""

    @abc.abstractmethod
    def read(self, dataflow_id: str) -> str | None: ...


class ArtifactStore(abc.ABC):
    @abc.abstractmethod
    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        """Write the artifact for (dataflow, iteration); return its path/URI."""


class SparkDiscoveryReader(DiscoveryReader):
    """Reads a Discovery node/edge table into the typed IR.

    The Discovery agent owns that table's schema, which varies, so this reader does
    not hard-assume column names. It resolves each IR field from a set of common
    aliases (overridable via ``columns``) and reads rows as dicts — never ``row[key]``
    membership, which on a Spark ``Row`` checks *values*, not column names.

    ``columns`` overrides the mapping, e.g. ``{"op_type": "tile_type"}``.
    ``node_id`` and ``op_type`` are required; a missing one fails loudly, listing the
    columns that were actually present.
    """

    #: IR field -> candidate column names (first match wins)
    ALIASES: dict[str, tuple[str, ...]] = {
        "node_id": ("node_id", "id", "nodeid", "node", "node_key"),
        "op_type": ("op_type", "type", "operation", "optype", "tile_type", "tiletype", "op"),
        "name": ("name", "label", "display_name", "title"),
        "config": ("config_json", "config", "configuration", "properties", "params"),
        "inputs": ("inputs_json", "inputs", "upstream", "parents", "depends_on", "sources"),
    }

    def __init__(self, table: str, *, spark: Any | None = None,
                 columns: dict[str, str] | None = None, where: str | None = None,
                 dataflow_column: str | None = "dataflow_id") -> None:
        self._table = table
        self._spark = spark
        self._overrides = columns or {}
        self._where = where
        self._dataflow_column = dataflow_column

    def _session(self) -> Any:
        if self._spark is None:
            from pyspark.sql import SparkSession
            self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def read(self, dataflow_id: str) -> DataflowIR:
        df = self._session().table(self._table)
        # scope to THIS dataflow — the discovery table typically holds many dataflows
        if self._dataflow_column and self._dataflow_column in df.columns:
            df = df.filter(df[self._dataflow_column].cast("string") == str(dataflow_id))
        if self._where:
            df = df.where(self._where)      # e.g. "record_type = 'node' AND discovery_run_id = '...'"
        available = list(df.columns)
        colmap = self.resolve_columns(available, self._overrides)
        rows = [r.asDict(recursive=True) for r in df.collect()]   # recursive: structs -> dicts
        return self.rows_to_ir(dataflow_id, rows, colmap)

    # -- pure helpers (unit-testable without Spark) ------------------------- #
    @classmethod
    def resolve_columns(cls, available: list[str], overrides: dict[str, str]) -> dict[str, str | None]:
        lower = {c.lower(): c for c in available}
        resolved: dict[str, str | None] = {}
        for field, aliases in cls.ALIASES.items():
            if field in overrides:
                col = overrides[field]
                if col not in available:
                    raise ValueError(f"discovery column {col!r} for {field!r} not in table: {available}")
                resolved[field] = col
                continue
            resolved[field] = next((lower[a] for a in aliases if a in lower), None)
        for required in ("node_id", "op_type"):
            if resolved[required] is None:
                raise ValueError(
                    f"discovery table is missing a column for {required!r}. "
                    f"Columns present: {available}. Pass columns={{'{required}': '<your column>'}}."
                )
        return resolved

    @staticmethod
    def rows_to_ir(dataflow_id: str, rows: list[dict], colmap: dict[str, str | None]) -> DataflowIR:
        import json

        def _obj(value: Any, empty: Any) -> Any:
            if value is None or value == "":
                return empty
            if isinstance(value, str):
                return json.loads(value)
            return value            # already structured (Spark struct/array -> dict/list)

        nodes = []
        for r in rows:
            nid = r.get(colmap["node_id"])
            if nid is None or str(nid).strip() == "":
                continue        # e.g. edge rows in a combined node+edge discovery table
            name_col = colmap.get("name")
            cfg_col = colmap.get("config")
            in_col = colmap.get("inputs")
            nodes.append(IRNode(
                node_id=str(nid),
                op_type=str(r[colmap["op_type"]]),
                name=str(r.get(name_col) or "") if name_col else "",
                config=_obj(r.get(cfg_col), {}) if cfg_col else {},
                inputs=tuple(_obj(r.get(in_col), []) if in_col else []),
            ))
        return DataflowIR(dataflow_id=dataflow_id, nodes=tuple(nodes))


class VolumePlanReader(PlanReader):
    """Reads the approved plan from the md-cd volume layout:
    <root>/<dataflow_name>/md/plan_{id}_v{iteration}.py — highest iteration wins
    (the latest version is the one that carried human approval)."""

    def __init__(self, volume_root: str, dataflow_name: str) -> None:
        self._root = volume_root.rstrip("/")
        self._dataflow_name = dataflow_name

    def read(self, dataflow_id: str) -> str | None:
        import glob
        import os
        import re
        pattern = f"{self._root}/{self._dataflow_name}/md/plan_{dataflow_id}_v*.md"
        candidates = glob.glob(pattern)
        if not candidates:
            return None

        def _version(path: str) -> int:
            m = re.search(r"_v(\d+)\.md$", os.path.basename(path))
            return int(m.group(1)) if m else -1

        latest = max(candidates, key=_version)
        with open(latest, encoding="utf-8") as fh:
            return fh.read()


class VolumeArtifactStore(ArtifactStore):
    """Writes to the md-cd volume layout: <root>/<dataflow_name>/cd/etl_{id}_v{iter}.py"""

    def __init__(self, volume_root: str, dataflow_name: str) -> None:
        self._root = volume_root.rstrip("/")
        self._dataflow_name = dataflow_name

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return f"{self._root}/{self._dataflow_name}/cd/etl_{dataflow_id}_v{iteration}.py"

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        path = self.path_for(dataflow_id, iteration)
        import os
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)
        return path
