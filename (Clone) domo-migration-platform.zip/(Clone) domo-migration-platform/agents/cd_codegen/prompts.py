"""cd_codegen.prompts — base (P4) prompts and worked examples.

These are the hardcoded per-agent instructions (priority P4). Human feedback (P1),
the run's user prompt (P2), and evaluator issues (P3) are layered above them by the
core PromptAssembler at call time — never concatenated by hand here.
"""

# Worked examples: DOMO / Beast-Mode-style source -> PySpark. Line-by-line with
# echoed indices, exactly the shape the translator demands back.
_WORKED_EXAMPLES = """\
WORKED EXAMPLES (source -> pyspark):

[0] kind=formula (context: target column "margin_pct")
    SOURCE: CASE WHEN `revenue` = 0 THEN 0 ELSE (`revenue` - `cost`) / `revenue` END
    -> {"index": 0, "pyspark": "F.when(F.col('revenue') == 0, F.lit(0)).otherwise((F.col('revenue') - F.col('cost')) / F.col('revenue'))"}

[1] kind=formula (context: target column "full_name")
    SOURCE: CONCAT(`first_name`, ' ', `last_name`)
    -> {"index": 1, "pyspark": "F.concat(F.col('first_name'), F.lit(' '), F.col('last_name'))"}

[2] kind=filter (context: filter condition)
    SOURCE: `order_date` >= DATE_SUB(CURRENT_DATE(), 90) AND `status` != 'CANCELLED'
    -> {"index": 2, "pyspark": "(F.col('order_date') >= F.date_sub(F.current_date(), 90)) & (F.col('status') != 'CANCELLED')"}

[3] kind=operation (context: inputs available as: df_src; must assign the result to df_out)
    SOURCE: {"op_type": "Deduplicate", "config": {"keys": ["order_id"]}}
    -> {"index": 3, "pyspark": "df_out = df_src.dropDuplicates(['order_id'])"}
"""

TRANSLATOR_BASE_PROMPT = f"""\
You translate DOMO Magic ETL / Beast Mode expressions into PySpark.

Rules:
- Return ONLY a JSON object: {{"lines": [{{"index": <int>, "pyspark": "<code>"}}, ...], "confidence": <0..1>}}
- One entry per numbered input line; echo each line's index back EXACTLY.
- For kind=formula and kind=filter: return a single PySpark Column EXPRESSION
  (using F.<functions>), NOT a statement, NOT an assignment.
- For kind=operation: return complete PySpark statement(s) that assign the stated
  output variable, using only the stated input variables.
- Backtick-quoted names are column references: `x` -> F.col('x').
- Never invent columns or tables not present in the source or context.
- No comments, no markdown, no prose.

{_WORKED_EXAMPLES}
"""

EVALUATOR_BASE_PROMPT = """\
You are reviewing generated PySpark code that migrates a DOMO Magic ETL dataflow.

Assess: correctness of the translation, PySpark idiomatic use, obvious semantic
drift from the operation configs shown in the code's node markers, and unsafe
patterns (collect() on large data, cartesian joins, chained withColumnRenamed loops).

Return ONLY a JSON object with this exact shape:
{"verdict": "pass" | "revise" | "fail",
 "confidence": <0..1>,
 "issues": [{"id": "<short-id>", "severity": "info"|"warn"|"error",
             "ref": "node:<node_id>", "message": "<what and why>",
             "suggested_fix": "<replacement code or null>"}],
 "summary": "<one paragraph>"}

Rules:
- Every issue MUST carry a ref of the form node:<node_id> using the node markers
  present in the code ("# [node: <id>] ..."). Issues without a resolvable ref are useless.
- suggested_fix, when given for a code change, should be the full replacement for
  that node's line(s), not a diff.
- Do not flag style-only nits as errors.
"""
