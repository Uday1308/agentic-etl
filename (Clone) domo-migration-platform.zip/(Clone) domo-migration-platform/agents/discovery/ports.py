"""Ports for the Discovery agent (3). Structural only — no LLM anywhere."""
from __future__ import annotations

import abc
from typing import Any


class StandardJsonReader(abc.ABC):
    @abc.abstractmethod
    def read(self, dataflow_id: str) -> dict[str, Any]: ...


class DiscoveryTableWriter(abc.ABC):
    """Creates the dataflow's discovery table, or overwrites it if it exists."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, rows: list[dict[str, Any]]) -> str: ...


class SourceProbe(abc.ABC):
    """Probes an ingested source table to DISCOVER incremental properties rather
    than assume them: does a batch carry one period or many, which column carries
    the period, and how late do rows arrive.

    Recording these per source is what lets codegen emit the right scoping filter
    deterministically instead of guessing.
    """

    @abc.abstractmethod
    def period_profile(self, table: str) -> dict[str, Any]:
        """Return e.g. {"period_source": "data"|"batch", "period_column": "Date",
        "max_periods_per_batch": 3, "observed_lateness_days": 62}."""


class SparkDiscoveryReader:
    """Reads the discovery table into normalized rows.

    Column resolution and value coercion come from ``core.contracts.discovery`` — the
    same code the offline runner uses — so a table this reader accepts is a table the
    dry-run accepts, and vice versa.
    """

    def __init__(self, table: str, *, spark: Any = None,
                 columns: dict[str, str] | None = None, where: str | None = None,
                 run_id: str = "") -> None:
        self._table = table
        self._spark = spark
        self._overrides = columns or {}
        self._where = where
        self._run_id = run_id

    def _session(self) -> Any:
        if self._spark is None:
            from pyspark.sql import SparkSession
            self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def read_rows(self, dataflow_id: str) -> list:
        from core.contracts.discovery import normalize_rows

        df = self._session().table(self._table)
        if self._where:
            df = df.where(self._where)
        rows = [r.asDict(recursive=True) for r in df.collect()]
        return normalize_rows(rows, dataflow_id=dataflow_id,
                              overrides=self._overrides, run_id=self._run_id)

    def read(self, dataflow_id: str) -> dict:
        """The standardized dataflow shape the planner consumes."""
        from core.contracts.discovery import to_dataflow
        return to_dataflow(self.read_rows(dataflow_id), dataflow_id)
