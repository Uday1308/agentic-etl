"""Discovery agent contracts (skill: every node and connection present; create and
overwrite both work; structural check fails on loss; never calls the LLM)."""
from __future__ import annotations

import pytest

from agents.discovery.ports import DiscoveryTableWriter, SourceProbe, StandardJsonReader
from agents.discovery.strategies import DiscoveryBuilder, DiscoveryError

DOC = {
    "dataflow_id": "8099",
    "nodes": [
        {"id": "src", "name": "Feed", "type": "DataSet",
         "properties": {"source_table": "bronze.feed"}, "inputs": []},
        {"id": "flt", "name": "Filter Rows", "type": "Filter", "inputs": ["src"]},
        {"id": "out", "name": "Write", "type": "Target", "inputs": ["flt"]},
    ],
    "edges": [{"from": "src", "to": "flt"}, {"from": "flt", "to": "out"}],
}


class Reader(StandardJsonReader):
    def __init__(self, doc=None):
        self.doc = doc or DOC

    def read(self, dataflow_id):
        return self.doc


class Writer(DiscoveryTableWriter):
    def __init__(self):
        self.calls = []

    def write(self, dataflow_id, rows):
        self.calls.append((dataflow_id, rows))
        return f"dev.discovery.dataflow_{dataflow_id}"


class Probe(SourceProbe):
    def period_profile(self, table):
        return {"period_source": "data", "period_column": "Date",
                "max_periods_per_batch": 3, "observed_lateness_days": 62}


def test_every_node_and_edge_appears_in_the_table():
    w = Writer()
    out = DiscoveryBuilder(Reader(), w).run({"dataflow_id": "8099"})
    rows = w.calls[0][1]
    assert out["nodes"] == 3 and out["edges"] == 2
    assert sum(1 for r in rows if r["record_type"] == "NODE") == 3
    assert sum(1 for r in rows if r["record_type"] == "LINEAGE") == 2


def test_terminal_and_intermediate_positions_are_recorded():
    """The LOCAL label codegen needs (CTE vs materialized). Medallion layer is a
    separate, estate-level decision made later."""
    w = Writer()
    DiscoveryBuilder(Reader(), w).run({"dataflow_id": "8099"})
    pos = {r["node_id"]: r["position"] for r in w.calls[0][1] if r["record_type"] == "NODE"}
    assert pos["out"] == "terminal" and pos["src"] == "intermediate"


def test_create_and_overwrite_paths_both_work():
    w = Writer()
    b = DiscoveryBuilder(Reader(), w)
    b.run({"dataflow_id": "8099"})
    b.run({"dataflow_id": "8099"})
    assert len(w.calls) == 2 and w.calls[0][0] == w.calls[1][0]


def test_structural_check_fails_when_a_node_id_is_missing():
    doc = {"dataflow_id": "1", "nodes": [{"id": "", "name": "ghost"}], "edges": []}
    with pytest.raises(DiscoveryError, match="empty node_id"):
        DiscoveryBuilder(Reader(doc), Writer()).run({"dataflow_id": "1"})


def test_period_profile_is_discovered_not_assumed():
    """With ~200 dataflows nobody can hand-check whether a batch carries one period
    or many, so it is probed and recorded."""
    out = DiscoveryBuilder(Reader(), Writer(), Probe()).run({"dataflow_id": "8099"})
    prof = out["period_profiles"]["bronze.feed"]
    assert prof["max_periods_per_batch"] == 3 and prof["period_source"] == "data"


def test_never_touches_the_llm_wrapper():
    """No AI at all. Assert on the module's actual imports rather than its text, so a
    docstring mentioning core.domo.llm cannot fail the test — or hide a real import."""
    import ast
    import pathlib as _p

    src = _p.Path("agents/discovery/strategies.py").read_text()
    tree = ast.parse(src)
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {a.name for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module)
    assert not any(m.startswith("core.domo.llm") or m.startswith("core.domo.prompts") for m in imported)
