"""Discovery agent (3). Standardized JSON -> the discovery table.

Deterministic and LLM-free. Beyond extracting nodes and lineage it records two
properties the rest of the pipeline needs and cannot derive later:

* terminal vs intermediate — a node with no downstream is a sink. This is the LOCAL
  label codegen needs to choose CTE vs materialized table. (Medallion layer is a
  different, ESTATE-level label decided at promotion — see the classifier.)
* per-source period profile — whether a batch carries one period or many, which
  drives the incremental scoping filter.
"""
from __future__ import annotations

from typing import Any

from agents.discovery.ports import DiscoveryTableWriter, SourceProbe, StandardJsonReader

AGENT = "discovery"


class DiscoveryError(RuntimeError):
    """Raised when the structural check finds the table does not round-trip."""


class DiscoveryBuilder:
    def __init__(self, reader: StandardJsonReader, writer: DiscoveryTableWriter,
                 probe: SourceProbe | None = None) -> None:
        self._reader = reader
        self._writer = writer
        self._probe = probe

    def run(self, state: dict, config: dict | None = None) -> dict:
        dataflow_id = state.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("discovery: dataflow_id missing from state")
        doc = self._reader.read(dataflow_id)

        nodes = list(doc.get("nodes", []) or [])
        edges = list(doc.get("edges", doc.get("connections", [])) or [])

        downstream = {e.get("from") for e in edges}
        rows: list[dict[str, Any]] = []
        for n in nodes:
            nid = str(n.get("id") or n.get("node_id") or "")
            rows.append({
                "record_type": "NODE",
                "dataflow_id": dataflow_id,
                "node_id": nid,
                "node_name": n.get("name", ""),
                "operation_type": n.get("type") or n.get("operation_type") or "",
                "properties": n.get("properties", {}),
                "input_node_ids": n.get("inputs", []),
                # LOCAL label only. Medallion layer is decided estate-wide later.
                "position": "terminal" if nid not in downstream else "intermediate",
            })
        for e in edges:
            rows.append({
                "record_type": "LINEAGE",
                "dataflow_id": dataflow_id,
                "from_node_id": e.get("from"),
                "to_node_id": e.get("to"),
                "relationship_type": e.get("type", "data"),
            })

        self._structural_check(nodes, edges, rows)
        path = self._writer.write(dataflow_id, rows)

        profiles = {}
        if self._probe:
            for n in nodes:
                tbl = (n.get("properties") or {}).get("source_table")
                if tbl:
                    profiles[tbl] = self._probe.period_profile(tbl)

        return {"table": path, "nodes": len(nodes), "edges": len(edges),
                "rows": len(rows), "period_profiles": profiles}

    @staticmethod
    def _structural_check(nodes: list, edges: list, rows: list) -> None:
        """Every node and every connection must survive into the table. Loud on loss —
        a silently dropped node is the failure this agent exists to prevent."""
        got_nodes = sum(1 for r in rows if r["record_type"] == "NODE")
        got_edges = sum(1 for r in rows if r["record_type"] == "LINEAGE")
        if got_nodes != len(nodes) or got_edges != len(edges):
            raise DiscoveryError(
                f"discovery table does not round-trip: {len(nodes)} nodes/{len(edges)} edges in, "
                f"{got_nodes}/{got_edges} out")
        blank = [r["node_id"] for r in rows if r["record_type"] == "NODE" and not r["node_id"]]
        if blank:
            raise DiscoveryError(f"{len(blank)} node rows have an empty node_id")
