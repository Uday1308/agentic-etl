"""Ports for the Connection agent (1). No AI — pure I/O behind injected seams."""
from __future__ import annotations

import abc
from typing import Any


class DomoClient(abc.ABC):
    """Reads from DOMO. The only place the DOMO API is touched for this agent."""

    @abc.abstractmethod
    def fetch_dataflow(self, dataflow_id: str) -> dict[str, Any]:
        """Return the raw DOMO dataflow JSON."""

    @abc.abstractmethod
    def fetch_execution_history(self, dataflow_id: str, limit: int = 20) -> list[dict]:
        """Recent executions. Used to derive real refresh cadence for scheduling.
        Only called when the run opted into the DOMO API."""


class JsonStore(abc.ABC):
    """Writes the raw JSON to its volume path. Pure overwrite — no iteration axis."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, payload: dict[str, Any]) -> str: ...


class EtlMasterStore(abc.ABC):
    """The ETL master status table.

    Connection is the ONLY agent that writes connection/standardization status, and
    the flip must be idempotent: a re-run must not create duplicate rows or
    double-flip.
    """

    @abc.abstractmethod
    def flip(self, dataflow_id: str, *, done: str, active: str) -> bool:
        """Return True if this call changed state, False if it was already applied."""
