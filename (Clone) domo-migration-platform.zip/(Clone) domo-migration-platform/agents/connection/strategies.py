"""Connection agent (1). No AI, no evaluator, no HITL.

Fetch the DOMO dataflow JSON, write it, flip ETL master, stop. The flip is the
agent's single status write and must be idempotent.
"""
from __future__ import annotations

from typing import Any

from agents.connection.ports import DomoClient, EtlMasterStore, JsonStore

AGENT = "connection"


class ConnectionRunner:
    """Deterministic. Never touches core.domo.llm — there is no prompts/ folder here."""

    def __init__(self, domo: DomoClient, store: JsonStore, master: EtlMasterStore,
                 *, use_domo_api: bool = False) -> None:
        self._domo = domo
        self._store = store
        self._master = master
        self._use_api = use_domo_api

    def run(self, state: dict, config: dict | None = None) -> dict:
        dataflow_id = state.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("connection: dataflow_id missing from state")

        payload: dict[str, Any] = self._domo.fetch_dataflow(dataflow_id)
        history = (self._domo.fetch_execution_history(dataflow_id)
                   if self._use_api else [])
        path = self._store.write(dataflow_id, payload)

        # LAST action, and the only status write this agent makes.
        flipped = self._master.flip(dataflow_id, done=AGENT, active="standardization")

        return {
            "artifact_path": path,
            "nodes_in_payload": len(payload.get("nodes", []) or []),
            "execution_history": history,
            "status_flipped": flipped,
            "used_domo_api": self._use_api,
        }
