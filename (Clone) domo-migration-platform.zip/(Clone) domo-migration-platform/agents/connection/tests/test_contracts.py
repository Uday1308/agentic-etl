"""Connection agent contracts (skill: writes JSON to the right path; flips ETL master
exactly once, idempotently; re-run overwrites cleanly; never calls the LLM)."""
from __future__ import annotations

import pytest

from agents.connection.ports import DomoClient, EtlMasterStore, JsonStore
from agents.connection.strategies import ConnectionRunner


class FakeDomo(DomoClient):
    def __init__(self):
        self.fetches = 0
        self.history_calls = 0

    def fetch_dataflow(self, dataflow_id):
        self.fetches += 1
        return {"dataflow_id": dataflow_id, "nodes": [{"id": "n1"}, {"id": "n2"}]}

    def fetch_execution_history(self, dataflow_id, limit=20):
        self.history_calls += 1
        return [{"run": 1, "state": "SUCCESS"}]


class FakeStore(JsonStore):
    def __init__(self):
        self.writes = []

    def write(self, dataflow_id, payload):
        self.writes.append((dataflow_id, payload))
        return f"/Volumes/dev/raw/{dataflow_id}.json"


class FakeMaster(EtlMasterStore):
    def __init__(self):
        self.flips = []
        self._state = {}

    def flip(self, dataflow_id, *, done, active):
        key = (dataflow_id, done, active)
        if self._state.get(dataflow_id) == key:
            return False                      # already applied — idempotent
        self._state[dataflow_id] = key
        self.flips.append(key)
        return True


def _runner(**kw):
    domo, store, master = FakeDomo(), FakeStore(), FakeMaster()
    return ConnectionRunner(domo, store, master, **kw), domo, store, master


def test_writes_json_to_the_volume_path():
    r, _, store, _ = _runner()
    out = r.run({"dataflow_id": "8099"})
    assert out["artifact_path"] == "/Volumes/dev/raw/8099.json"
    assert store.writes[0][0] == "8099" and out["nodes_in_payload"] == 2


def test_flips_etl_master_exactly_once_and_is_idempotent():
    r, _, _, master = _runner()
    assert r.run({"dataflow_id": "8099"})["status_flipped"] is True
    assert r.run({"dataflow_id": "8099"})["status_flipped"] is False   # re-run
    assert len(master.flips) == 1
    assert master.flips[0] == ("8099", "connection", "standardization")


def test_rerun_overwrites_json_and_leaves_master_consistent():
    r, _, store, master = _runner()
    r.run({"dataflow_id": "8099"})
    r.run({"dataflow_id": "8099"})
    assert len(store.writes) == 2            # pure overwrite, no iteration axis
    assert len(master.flips) == 1            # no duplicate status rows


def test_domo_api_is_opt_in():
    off, domo_off, _, _ = _runner()
    off.run({"dataflow_id": "8099"})
    assert domo_off.history_calls == 0 and off.run({"dataflow_id": "8099"})["execution_history"] == []

    on, domo_on, _, _ = _runner(use_domo_api=True)
    out = on.run({"dataflow_id": "8099"})
    assert domo_on.history_calls == 1 and out["execution_history"]


def test_never_touches_the_llm_wrapper():
    """No AI at all. Assert on the module's actual imports rather than its text, so a
    docstring mentioning core.domo.llm cannot fail the test — or hide a real import."""
    import ast
    import pathlib as _p

    src = _p.Path("agents/connection/strategies.py").read_text()
    tree = ast.parse(src)
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {a.name for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module)
    assert not any(m.startswith("core.domo.llm") or m.startswith("core.domo.prompts") for m in imported)
def test_missing_dataflow_id_fails_loud():
    r, _, _, _ = _runner()
    with pytest.raises(ValueError, match="dataflow_id"):
        r.run({})
