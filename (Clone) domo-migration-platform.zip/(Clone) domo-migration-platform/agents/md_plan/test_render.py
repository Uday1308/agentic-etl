"""The plan document — intent, mappings and caveats. No generated code."""
from __future__ import annotations

import pytest

from agents.md_plan.render import PlanRenderer, snake

# -- plan document ---------------------------------------------------------- #

STD = {
    "dataflow_id": "8099",
    "nodes": [
        {"id": "n1", "name": "Feed", "category": "SOURCE", "type": "DataSet",
         "properties": {"dataset_name": "NA | F&A | Feed | FEED", "dataSourceId": "abc"}},
        {"id": "n2", "name": "Add Formula 1", "type": "formula", "properties": {
            "expressions": [{"name": "Period End Date", "expression": "LAST_DAY(`Date`)"}]}},
        {"id": "n3", "name": "Out PROD", "category": "TARGET", "type": "Target",
         "properties": {"dataset_name": "NA | F&A | Out | PROD", "write_mode": "REPLACE"}},
    ],
    "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
}


def test_plan_has_every_section():
    doc = PlanRenderer().build(STD, dataflow_id="8099", dataflow_name="cms").document
    for section in ("## 1. Pipeline Overview", "## 2. Source Tables", "## 3. Execution DAG",
                    "## 4. DataFrame Variable Map", "## 5. Transformation Plan",
                    "## 6. Output Targets", "## 8. Review Checklist",
                    "## 9. Python vs. LLM Coverage Report"):
        assert section in doc


def test_plan_contains_intent_not_code():
    """The decided contract: a reviewer approves semantics, not generated SQL. There
    must be no fenced code block anywhere in the plan."""
    doc = PlanRenderer().build(STD, dataflow_id="8099", dataflow_name="cms").document
    # the only fenced block permitted is the section-3 DAG diagram, which is not code
    assert "```python" not in doc and "```sql" not in doc
    assert doc.count("```") == 2
    assert "## 5. Transformation Plan" in doc
    assert "**Column mappings:**" in doc


def test_plan_states_the_mapping_a_human_reviews():
    doc = PlanRenderer().build(STD, dataflow_id="8099", dataflow_name="cms").document
    sec5 = doc.split("## 5. Transformation Plan")[1].split("## 6.")[0]
    assert "LAST_DAY(`Date`)" in sec5              # the DOMO expression
    assert "last_day(`Date`)" in sec5              # the proposed SQL
    assert "`HIGH`" in sec5                        # and the confidence


def test_topological_order_is_deterministic():
    """Two runs of the same dataflow must produce byte-identical plans."""
    a = PlanRenderer().build(STD, dataflow_id="8099").document
    b = PlanRenderer().build(STD, dataflow_id="8099").document
    assert a == b


def test_cycle_is_rejected_loudly():
    bad = {"nodes": [{"id": "a", "type": "filter"}, {"id": "b", "type": "filter"}],
           "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "a"}]}
    with pytest.raises(ValueError, match="cycle or dangling"):
        PlanRenderer().build(bad, dataflow_id="1")


def test_unresolved_step_becomes_an_escalation_block_not_fake_code():
    std = {**STD, "nodes": STD["nodes"] + [
        {"id": "n4", "name": "Risk Score", "type": "RiskScore", "properties": {}}],
        "edges": STD["edges"] + [{"from": "n2", "to": "n4"}]}
    build = PlanRenderer().build(std, dataflow_id="8099")
    assert len(build.unresolved) == 1
    assert "Cannot be translated from the tile vocabulary" in build.document
    assert build.coverage_pct == 50.0


def test_coverage_report_states_the_real_split():
    build = PlanRenderer().build(STD, dataflow_id="8099")
    assert "1/1 transformations resolved deterministically (100.0%)" in build.document


def test_risk_register_lists_flagged_steps():
    std = {**STD, "nodes": [
        STD["nodes"][0],
        {"id": "n2", "name": "Group By 1", "type": "groupBy", "properties": {
            "groupBy": ["k"], "aggregations": [
                {"function": "FIRST", "column": "rate", "alias": "rate"}]}},
        STD["nodes"][2]]}
    doc = PlanRenderer().build(std, dataflow_id="8099").document
    checklist = doc.split("## 8. Review Checklist")[1]
    assert "Group By 1" in checklist and "LOW" in checklist
    assert "order-dependent" in checklist


def test_overview_names_the_structural_risks():
    std = {**STD, "nodes": [
        STD["nodes"][0],
        {"id": "n2", "name": "G", "type": "groupBy", "properties": {
            "groupBy": ["k"], "aggregations": [{"function": "FIRST", "column": "r"}]}},
        STD["nodes"][2]]}
    doc = PlanRenderer().build(std, dataflow_id="8099").document
    overview = doc.split("## 2.")[0]
    assert "order-dependent aggregations" in overview


def test_snake_is_stable_for_domo_pipe_names():
    assert snake("NA | F&A | CMS Summary | PROD") == "na_f_a_cms_summary_prod"
