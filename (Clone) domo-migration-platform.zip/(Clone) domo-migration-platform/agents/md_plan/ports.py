"""Ports for the MD Plan agent (4)."""
from __future__ import annotations

import abc
from typing import Any


class JsonPairReader(abc.ABC):
    """The generator reads BOTH the standardized JSON and the original DOMO JSON —
    the original carries tile detail the standardizer normalizes away."""

    @abc.abstractmethod
    def read_standardized(self, dataflow_id: str) -> dict[str, Any]: ...

    @abc.abstractmethod
    def read_raw(self, dataflow_id: str) -> dict[str, Any]: ...


class PlanStore(abc.ABC):
    """Versioned BY ITERATION. A plan regenerated after human feedback is a new
    version, never an overwrite of the approved prior."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, iteration: int, content: str) -> str: ...

    @abc.abstractmethod
    def path_for(self, dataflow_id: str, iteration: int) -> str: ...
