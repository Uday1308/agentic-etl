"""Real adapters for the MD Plan agent — volume-backed readers and store."""
from __future__ import annotations

import json
from typing import Any

from agents.md_plan.ports import JsonPairReader, PlanStore


def _read_text(path: str) -> str:
    """Read from a UC Volume. Uses the SDK Files API for /Volumes paths — dbutils.fs
    treats a scheme-less path as DBFS, and os-level reads hit the FUSE mount which
    rejects some operations."""
    if path.startswith("/Volumes/"):
        from databricks.sdk import WorkspaceClient
        return WorkspaceClient().files.download(path).contents.read().decode("utf-8")
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _write_text(path: str, content: str) -> str:
    if path.startswith("/Volumes/"):
        import io

        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient()
        try:
            w.files.create_directory(path.rsplit("/", 1)[0])
        except Exception:
            pass
        w.files.upload(path, io.BytesIO(content.encode("utf-8")), overwrite=True)
        return path
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return path


class VolumeJsonPairReader(JsonPairReader):
    """Reads the standardized JSON and the original DOMO JSON from volume paths."""

    def __init__(self, standardized_root: str, raw_root: str) -> None:
        self._std = standardized_root.rstrip("/")
        self._raw = raw_root.rstrip("/")

    def read_standardized(self, dataflow_id: str) -> dict[str, Any]:
        return json.loads(_read_text(f"{self._std}/{dataflow_id}.json"))

    def read_raw(self, dataflow_id: str) -> dict[str, Any]:
        return json.loads(_read_text(f"{self._raw}/{dataflow_id}.json"))


class VolumePlanStore(PlanStore):
    """Versioned by iteration: plan_{id}_v{n}.md. A regenerated plan never overwrites
    an approved prior version."""

    def __init__(self, volume_root: str, dataflow_name: str) -> None:
        self._root = volume_root.rstrip("/")
        self._name = dataflow_name

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return f"{self._root}/{self._name}/md/plan_{dataflow_id}_v{iteration}.md"

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        return _write_text(self.path_for(dataflow_id, iteration), content)
