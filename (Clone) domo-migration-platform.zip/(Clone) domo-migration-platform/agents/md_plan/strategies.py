"""MD Plan agent (4). generate -> evaluate -> HITL -> regenerate.

This is the plan a human actually reviews, so it carries INTENT and CAVEATS rather
than a wall of generated code: per-node semantics, expression mappings with their
confidence and semantic risks, join-key assumptions, source bindings, materialization
and incremental decisions, and a risk register. That is reviewable in fifteen
minutes; nine hundred lines of SQL is not.

The plan is also the reasoning artifact. If the generator reasons before it writes,
that reasoning is externalized here — reasoning nobody can review is reasoning not
worth paying for.
"""
from __future__ import annotations

import json
import re
from typing import Any

from agents.md_plan.ports import JsonPairReader, PlanStore
from agents.md_plan.render import PlanBuild, PlanRenderer
from core.contracts.standardized import StandardizedSchemaError, to_planner_dataflow
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.nodes import Evaluator, FeedbackApplier, Generator
from core.domo.prompts import PromptLayers
from core.domo.schemas import EvalResult, GenResult, HumanFeedback, Issue, Verdict

AGENT = "md_plan"


def _cfg(config) -> dict:
    return (config or {}).get("configurable", {}) if isinstance(config, dict) else {}


class SourceBinding:
    """How a source table is currently wired. Tracking this is what stops a
    silently-frozen estate: a workflow reading a snapshot forever because nobody
    re-pointed it once its real producer was migrated."""
    EXTERNAL = "external"     # a genuine outside feed; needs its own ingestion
    SNAPSHOT = "snapshot"     # temporary copy; a future migrated workflow will produce it
    MIGRATED = "migrated"     # live, produced by a migrated workflow


def _fold_raw(raw: Any, dataflow_id: str) -> tuple[dict, str]:
    """Best-effort fold of the original DOMO export, plus why it failed if it did.

    The renderer merges raw tile detail onto the standardized node by id, so the raw
    document has to present its tiles under ``nodes`` or the merge silently contributes
    nothing. Unlike the standardized read this is tolerant — the original export is
    whatever DOMO handed back, it enriches rather than defines, and a plan without it is
    degraded but still correct — so the reason is *returned* rather than raised, and
    surfaced on ``meta`` where a run can be judged on it. A raw document that folds to
    nothing means half the documented contract is contributing nothing; that must be
    visible, not inferred from a zero.
    """
    if not isinstance(raw, dict):
        return {"nodes": []}, f"raw export is a {type(raw).__name__}, expected an object"
    try:
        folded = to_planner_dataflow(raw, str(dataflow_id))
    except StandardizedSchemaError as e:
        if "nodes" in raw:
            return raw, ""
        return {"nodes": []}, str(e)
    if not folded.get("nodes"):
        return folded, "raw export folded to zero tiles"
    return folded, ""


def _fold_standardized(standardized: Any, dataflow_id: str) -> dict:
    """Normalize the standardized document into the shape the renderer reads.

    The standardizer writes an id-keyed document whose tiles live under ``actions``
    (see ``core.contracts.standardized``); the renderer reads ``nodes``/``edges``.
    Folding here rather than in the renderer keeps the renderer to one input contract
    while both of its upstreams — a standardized document and a discovery table —
    normalize through their own module.

    Failing loudly matters more than it looks: the renderer is total, so a document it
    finds no tiles in yields the nine section headings with every table empty and a
    coverage report reading 100%. That is indistinguishable from a real plan to every
    check downstream, so a mis-shaped input has to die here, at the read, where the
    error can still name what was wrong with it.
    """
    try:
        folded = to_planner_dataflow(standardized, str(dataflow_id))
    except StandardizedSchemaError as e:
        raise ValueError(f"md_plan: standardized JSON for {dataflow_id} is unusable: {e}") from e
    if not folded.get("nodes"):
        raise ValueError(
            f"md_plan: standardized JSON for {dataflow_id} yielded no nodes, so the plan "
            f"would be an empty skeleton. Every tile was dropped as disabled, or the "
            f"document is not in the standardized shape.")
    return folded


class PlanGenerator(Generator):
    """Build the migration plan. Deterministic first, model only for the real tail.

    DOMO's tile vocabulary and formula language are closed and finite, so both are
    transpiled in plain Python (see ``core/domo/tiles.py`` and ``core/domo/expr.py``). A model is
    asked only about steps the transpiler explicitly could not resolve — and it is
    asked about exactly those, with the surrounding context, never the whole plan.

    Human feedback (P1) is layered above the base prompt on regeneration, and the plan
    is versioned per iteration so an approved prior is never overwritten.
    """

    def __init__(self, reader: JsonPairReader, store: PlanStore, llm: LLMClient,
                 renderer: PlanRenderer | None = None) -> None:
        self._reader = reader
        self._store = store
        self._llm = llm
        self._renderer = renderer or PlanRenderer()

    async def generate(self, state, config) -> GenResult:
        c = _cfg(config)
        dataflow_id = state.get("dataflow_id") or c.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("md_plan: dataflow_id missing from state and config")
        iteration = int(c.get("iteration", 1) or 1)

        standardized = self._reader.read_standardized(dataflow_id)
        raw = self._reader.read_raw(dataflow_id)          # BOTH, per the contract
        folded = _fold_standardized(standardized, dataflow_id)
        folded_raw, raw_note = _fold_raw(raw, dataflow_id)

        build = self._renderer.build(
            folded, folded_raw, dataflow_id=str(dataflow_id),
            dataflow_name=state.get("dataflow_name", "") or c.get("dataflow_name", ""))

        feedback: list[HumanFeedback] = list((state.get("feedback") or {}).get(AGENT, []))
        hard = [h for fb in feedback for h in fb.hard_constraints]
        prior = (state.get(AGENT) or {}).get("eval") or {}
        issues = [Issue(**i) for i in prior.get("issues", [])]
        user_prompt = str((state.get("prompt_layers") or {}).get(AGENT, "") or "")

        # The AI tail: only steps the transpiler could not resolve.
        ai_resolved: dict[str, str] = {}
        if build.unresolved:
            ai_resolved = await self._resolve_tail(
                build, config=config, user_prompt=user_prompt, feedback=feedback,
                issues=issues, hard=hard)
            document = self._splice(build, ai_resolved)
        else:
            document = build.document

        path = self._store.write(dataflow_id, iteration, document)
        return GenResult(
            artifact=document,
            node_keys=[s.df_var for s in build.steps],
            meta={
                "artifact_path": path,
                "iteration": iteration,
                "read_standardized": True,
                "read_raw": True,                        # the read happened
                "raw_node_count": len(folded_raw.get("nodes") or []),
                # ...and whether it actually contributed. A raw document that folds to
                # nothing leaves the plan built from the standardized JSON alone.
                "raw_merged": bool(folded_raw.get("nodes")),
                "raw_fold_note": raw_note,
                "sources": len(build.sources),
                "targets": len(build.targets),
                "steps": len(build.steps),
                "resolved_deterministically": build.resolved_count,
                "needed_a_model": len(build.unresolved),
                "coverage_pct": round(build.coverage_pct, 1),
                "ai_resolved_steps": sorted(ai_resolved),
                "risk_steps": [s.step_id for s in build.steps
                               if s.result.confidence in ("LOW", "MEDIUM")],
            },
        )

    async def _resolve_tail(self, build: PlanBuild, *, config, user_prompt: str,
                            feedback: list[HumanFeedback], issues: list[Issue],
                            hard: list[str]) -> dict[str, str]:
        """Ask a model about each unresolved step, one call per step.

        One step per call keeps the model's job small and the failure blast radius to a
        single step. A step that still fails is left unresolved in the plan rather than
        filled with a guess.
        """
        out: dict[str, str] = {}
        for item in build.unresolved:
            node = item["node"]
            props = json.dumps(node.get("properties", {}) or {}, indent=2, default=str)[:2500]
            base = (
                "Translate ONE DOMO Magic ETL tile into a PySpark statement.\n"
                f"Tile type : {node.get('type') or node.get('operation_type')}\n"
                f"Tile name : {item['name']}\n"
                f"Inputs    : {', '.join(item['inputs']) or '(none)'}\n"
                f"Assign the result to: {item['df_var']}\n"
                f"Why it could not be auto-translated: {'; '.join(item['reasons'])}\n"
                f"Tile properties:\n{props}\n\n"
                "Return ONLY the PySpark statement in a ```python block. Use F for "
                "pyspark.sql.functions. Do not invent columns that are not referenced."
            )
            layers = PromptLayers(
                base=base, user_prompt=user_prompt, human_feedback=feedback,
                agent_feedback=issues, hard_constraints=hard,
            )
            try:
                result = await self._llm.complete(Role.GENERATOR, layers,
                                                  pool="md_translation", config=config)
                code = _extract_code(result.raw_text)
            except Exception:
                code = ""
            if code:
                out[item["step"]] = code
        return out

    @staticmethod
    def _splice(build: PlanBuild, ai_resolved: dict[str, str]) -> str:
        """Replace the escalation block of each AI-resolved step with its code, and
        mark the source as ``llm`` so the coverage report stays honest."""
        doc = build.document
        for step in build.steps:
            code = ai_resolved.get(step.step_id)
            if not code:
                continue
            header = f"### Step {step.step_id} | `{step.name}` |"
            start = doc.find(header)
            if start == -1:
                continue
            nxt = doc.find("### Step ", start + 1)
            end = nxt if nxt != -1 else doc.find("## 6. Output", start)
            block = doc[start:end]
            replacement = re.sub(
                r"\*\*Could not be translated deterministically\.\*\*.*?(?=\n\*\*|$)",
                f"```python\n{code}\n```\n\n_Resolved by a model — review before approval._\n",
                block, flags=re.DOTALL)
            doc = doc[:start] + replacement + doc[end:]
        resolved_now = build.resolved_count + len(ai_resolved)
        doc = re.sub(r"\*\*\d+/\d+ transformations Python-resolved \([\d.]+%\)\*\*",
                     f"**{build.resolved_count}/{len(build.steps)} transformations "
                     f"Python-resolved ({build.coverage_pct:.1f}%)** · "
                     f"{len(ai_resolved)} resolved by a model · "
                     f"{len(build.steps) - resolved_now} still unresolved", doc)
        return doc


def _extract_code(text: str) -> str:
    """Pull a python block out of a model response, tolerating prose around it."""
    m = re.search(r"```(?:python)?\s*\n(.*?)```", text or "", re.DOTALL)
    if m:
        return m.group(1).strip()
    stripped = (text or "").strip()
    return stripped if "=" in stripped and "\n" not in stripped[:200] else ""


EVALUATOR_BASE_PROMPT = """Review this migration plan for semantic fidelity and unstated assumptions.

The plan describes how a DOMO Magic ETL dataflow is being migrated to PySpark.
Assess: does each step preserve the intent of the DOMO tile it came from; are
join-key and source-binding assumptions stated rather than assumed; are the
expression mappings plausible; is anything materially missing or contradictory.

Return ONLY a JSON object with this exact shape, and nothing else — no prose
before or after, no markdown fence:
{"verdict": "pass" | "revise" | "fail",
 "confidence": <0..1>,
 "issues": [{"id": "<short-id>", "severity": "info"|"warn"|"error",
             "ref": "step:<step_id>", "message": "<what and why>",
             "detail": "<supporting detail>", "suggested_fix": "<replacement prose>"}],
 "summary": "<one paragraph>"}

Rules:
- The plan is supplied below under PLAN. Review that text; never ask for it.
- Every issue MUST carry a ref of the form step:<step_id> using the step headers
  present in the plan ("### Step <id> | ..."). Issues without a resolvable ref
  cannot be routed to a reviewer and are useless.
- Do not flag style-only nits as errors.
"""

# The reviewed plan is pasted into the prompt. Cap it so one oversized dataflow
# cannot silently blow the endpoint's context window mid-run.
_REVIEW_CHAR_BUDGET = 60_000


class PlanEvaluator(Evaluator):
    def __init__(self, llm: LLMClient, *, ai_review: bool = True) -> None:
        self._llm = llm
        self._ai_review = ai_review

    async def evaluate(self, gen: GenResult, state, config=None) -> EvalResult:
        if not gen.artifact.strip():
            return EvalResult(verdict=Verdict.FAIL, confidence=1.0,
                              summary="plan is empty")
        if not self._ai_review:
            return EvalResult(verdict=Verdict.PASS, confidence=1.0,
                              summary="static checks only")

        plan = gen.artifact
        truncated = len(plan) > _REVIEW_CHAR_BUDGET
        if truncated:
            plan = plan[:_REVIEW_CHAR_BUDGET] + "\n\n[... plan truncated for review ...]"

        layers = PromptLayers(
            base=EVALUATOR_BASE_PROMPT
            + "\n\nSTEP KEYS: " + json.dumps(gen.node_keys)
            + "\n\nPLAN:\n" + plan,
        )
        try:
            result = await self._llm.complete(
                Role.EVALUATOR, layers, pool="evaluation",
                response_schema=EvalResult, config=config)
        except ValueError as e:
            # Unparseable review. An eval outage must not crash the run, and must not
            # silently pass an unreviewed plan (guide §1) -> demand another round.
            return EvalResult(verdict=Verdict.REVISE, confidence=0.0,
                              summary=f"evaluator response unparseable: {e}")
        if result.parsed is None:
            return EvalResult(verdict=Verdict.REVISE, confidence=0.0,
                              summary="evaluator returned nothing")
        if truncated:
            return result.parsed.model_copy(update={
                "summary": f"[reviewed first {_REVIEW_CHAR_BUDGET} chars of the plan] "
                           f"{result.parsed.summary}"})
        return result.parsed


class PlanFeedbackApplier(FeedbackApplier):
    """Per-issue apply/keep. Rejected issues leave the plan untouched."""

    def apply(self, gen: GenResult, feedback: list[HumanFeedback]) -> GenResult:
        accepted = [i for fb in feedback for i in fb.accepted_issue_ids]
        meta: dict[str, Any] = dict(gen.meta)
        meta["applied_issue_ids"] = accepted
        return GenResult(artifact=gen.artifact, node_keys=gen.node_keys, meta=meta)
