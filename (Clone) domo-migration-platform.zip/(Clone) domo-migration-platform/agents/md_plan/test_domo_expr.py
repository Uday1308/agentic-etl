"""The DOMO expression transpiler — the deterministic core of the platform.

Fixtures are real expressions lifted from the cms_8099 plan, so a regression here is
a regression against production data.
"""
from __future__ import annotations

import pytest

from agents.md_plan.domo_expr import (
    Binary,
    Case,
    Col,
    DomoParseError,
    InList,
    PySparkEmitter,
    detect_functions,
    parse,
    tokenize,
    translate,
)

# -- tokenizer -------------------------------------------------------------- #

def test_tokenizes_backticked_columns_and_strings():
    toks = tokenize("`Period End Date` = 'CMS Worksheet'")
    assert toks[0].value == "Period End Date" and toks[2].value == "CMS Worksheet"


def test_doubled_quote_escape():
    assert tokenize("'it''s'")[0].value == "it's"


def test_block_comments_are_ignored():
    """DOMO users leave /* ... */ inside formulas — cms_8099 s55 does exactly this."""
    toks = tokenize("`a` /* WHEN x THEN y */ + 1")
    assert [t.value for t in toks if t.value] == ["a", "+", "1"]


def test_unterminated_column_is_a_clear_error():
    with pytest.raises(DomoParseError, match="unterminated column"):
        tokenize("`Never closed")


# -- parser ----------------------------------------------------------------- #

def test_operator_precedence_is_correct():
    """Regex translation gets this wrong; a real parser cannot."""
    ast = parse("1 + 2 * 3")
    assert isinstance(ast, Binary) and ast.op == "+"
    assert isinstance(ast.right, Binary) and ast.right.op == "*"


def test_and_binds_tighter_than_or():
    ast = parse("a = 1 OR b = 2 AND c = 3")
    assert ast.op == "OR" and ast.right.op == "AND"


def test_nested_case_parses():
    ast = parse("CASE WHEN a = 1 THEN CASE WHEN b = 2 THEN 'x' ELSE 'y' END ELSE 'z' END")
    assert isinstance(ast, Case) and isinstance(ast.whens[0][1], Case)


def test_simple_case_form_expands_to_comparisons():
    ast = parse("CASE `Currency` WHEN 'GBP' THEN 1 ELSE 0 END")
    cond = ast.whens[0][0]
    assert isinstance(cond, Binary) and cond.op == "=" and isinstance(cond.left, Col)


def test_case_without_when_is_rejected():
    with pytest.raises(DomoParseError, match="CASE with no WHEN"):
        parse("CASE ELSE 1 END")


def test_trailing_input_is_rejected_rather_than_silently_dropped():
    with pytest.raises(DomoParseError, match="trailing input"):
        parse("`a` + 1 garbage garbage")


def test_in_like_isnull_and_between():
    assert isinstance(parse("`m` IN (1,2,3)"), InList)
    assert parse("`d` NOT IN ('X')").negated is True
    assert parse("`d` LIKE '%FX%'").pattern.value == "%FX%"
    assert parse("`d` IS NOT NULL").negated is True
    assert parse("`n` BETWEEN 1 AND 5").op == "AND"


# -- emitter ---------------------------------------------------------------- #

REAL = {
    "LAST_DAY(`Date`)": "F.last_day(F.col('Date'))",
    "MONTH(`Period End Date`)": "F.month(F.col('`Period End Date`'))",
    "`Invoice Amount` / `Exchange Rate`":
        "(F.col('`Invoice Amount`') / F.col('`Exchange Rate`'))",
}


@pytest.mark.parametrize("domo,expected", list(REAL.items()))
def test_real_expressions_emit_expected_pyspark(domo, expected):
    assert translate(domo).code == expected


def test_every_cms_8099_expression_resolves_deterministically():
    """The whole point: no model needed for DOMO's own vocabulary."""
    exprs = [
        "LAST_DAY(`Date`)",
        "MONTH(`Period End Date`)",
        "YEAR(`Period End Date`)",
        "'CMS Worksheet'",
        "IFNULL(`Debit Accounted Amount`,0)-IFNULL(`Credit Accounted Amount`,0)",
        "`CMS Matrix Amount`*-1",
        "IFNULL(`Amount`/`Oracle Exchange Rate`,0)",
        "CASE WHEN `Month Number` IN (1,2,3) THEN CONCAT(MONTHNAME(`Period End Date`),'-',"
        "LEFT(YEAR(`Period End Date`)-1,4)) ELSE CONCAT(MONTHNAME(`Period End Date`),'-',"
        "YEAR(`Period End Date`)) END",
        "CASE WHEN `_BATCH_ID_` = 2 THEN '2025-05-31' WHEN DAY(`_BATCH_LAST_RUN_`) >= 15 "
        "THEN LAST_DAY(`_BATCH_LAST_RUN_`) ELSE LAST_DAY(DATE_SUB(`_BATCH_LAST_RUN_`, "
        "INTERVAL 1 MONTH)) END",
        "CASE WHEN `Description` LIKE('%FX%') AND `Source` NOT IN ('GLOPIP') THEN "
        "'FX Current Month' ELSE `Source` END",
        "CASE WHEN `Currency` = 'GBP' THEN `Invoice Amount` * `Exchange Rate` "
        "ELSE `Invoice Amount` / `Exchange Rate` END",
    ]
    unresolved = [e for e in exprs if not translate(e).resolved]
    assert unresolved == [], f"{len(unresolved)} expressions needed a model"


def test_date_sub_with_interval_becomes_add_months():
    out = translate("DATE_SUB(`d`, INTERVAL 1 MONTH)")
    assert out.code == "F.add_months(F.col('d'), -1)"


def test_date_sub_with_plain_days():
    assert translate("DATE_SUB(`d`, 7)").code == "F.date_sub(F.col('d'), 7)"


def test_left_casts_before_substring():
    """LEFT(YEAR(x)-1, 4) must cast to string first or Spark returns null."""
    code = translate("LEFT(YEAR(`d`)-1,4)").code
    assert ".cast('string')" in code and "F.substring(" in code


def test_negative_multiplier_is_handled():
    assert translate("`Amount`*-1").code == "(F.col('Amount') * F.lit(-1))"


def test_not_in_is_negated_correctly():
    assert translate("`Source` NOT IN ('GLOPIP')").code.startswith("(~(")


def test_dotted_column_names_are_rewritten():
    """A dot is a struct path to Spark, so DOMO's dotted names become __."""
    assert "a__b" in translate("`a.b` + 1").code


# -- semantic caveats ------------------------------------------------------- #

def test_concat_null_semantics_are_flagged():
    """DOMO CONCAT ignores nulls; Spark returns null if any argument is null."""
    out = translate("CONCAT(`a`,'-',`b`)")
    assert out.resolved and any("CONCAT" in n for n in out.notes)
    assert out.confidence == "MEDIUM"


def test_division_semantics_are_flagged():
    assert any("integer division" in n for n in translate("`a` / `b`").notes)


def test_case_without_else_is_flagged():
    out = translate("CASE WHEN `a` = 1 THEN 'x' END")
    assert out.resolved and any("without ELSE" in n for n in out.notes)


def test_clean_expression_is_high_confidence():
    assert translate("LAST_DAY(`Date`)").confidence == "HIGH"


# -- escalation ------------------------------------------------------------- #

def test_unknown_function_escalates_precisely():
    """Only the genuinely unknown fragment goes to a model — and it is named."""
    out = translate("WEIRD_DOMO_FUNC(`a`, 2)")
    assert not out.resolved and out.unsupported == ["WEIRD_DOMO_FUNC"]
    assert out.confidence == "LOW" and out.code == ""


def test_parse_failure_never_half_translates():
    out = translate("CASE WHEN `a` THEN")
    assert not out.resolved and out.code == ""


def test_empty_expression_is_null_not_an_error():
    assert translate("   ").code == "F.lit(None)"


# -- metadata for the plan -------------------------------------------------- #

def test_columns_and_functions_are_reported():
    out = translate("CONCAT(MONTHNAME(`Period End Date`),'-',YEAR(`Period End Date`))")
    assert out.columns_used == {"Period End Date"}
    assert {"CONCAT", "MONTHNAME", "YEAR"} <= out.functions_used


def test_detect_functions_survives_unparseable_input():
    assert "LAST_DAY" in detect_functions("LAST_DAY(`a` +++")


def test_emitter_is_reusable_and_stateless_across_calls():
    em = PySparkEmitter()
    a = translate("MONTH(`x`)", emitter=em)
    b = translate("YEAR(`y`)", emitter=em)
    assert a.functions_used == {"MONTH"} and b.functions_used == {"YEAR"}


# -- SQL dialect ------------------------------------------------------------ #

SQL_REAL = {
    "LAST_DAY(`Date`)": "last_day(`Date`)",
    "MONTH(`Period End Date`)": "month(`Period End Date`)",
    "IFNULL(`a`,0)": "coalesce(`a`, 0)",
    "`d` IS NOT NULL": "(`d` IS NOT NULL)",
    "`s` NOT IN ('X','Y')": "(`s` NOT IN ('X', 'Y'))",
    "`d` LIKE '%FX%'": "(`d` LIKE '%FX%')",
    "DATE_SUB(`d`, INTERVAL 1 MONTH)": "add_months(`d`, -1)",
}


@pytest.mark.parametrize("domo,expected", list(SQL_REAL.items()))
def test_sql_emits_expected(domo, expected):
    assert translate(domo, dialect="sql").code == expected


def test_sql_keeps_case_when_native():
    """SQL is a closer target than the DataFrame API: CASE WHEN passes through instead
    of becoming a method chain, so there is less to get wrong."""
    code = translate("CASE WHEN `a` = 1 THEN 'x' ELSE 'y' END", dialect="sql").code
    assert code == "(CASE WHEN (`a` = 1) THEN 'x' ELSE 'y' END)"


def test_sql_escapes_embedded_quotes():
    assert translate("'it''s'", dialect="sql").code == "'it''s'"


def test_sql_casts_before_left():
    """DOMO applies LEFT to numbers; SQL left() needs a string."""
    assert "cast(" in translate("LEFT(YEAR(`d`)-1,4)", dialect="sql").code


def test_sql_dotted_columns_are_rewritten():
    assert "`a__b`" in translate("`a.b` + 1", dialect="sql").code


def test_every_cms_8099_expression_resolves_in_sql_too():
    exprs = [
        "LAST_DAY(`Date`)", "MONTH(`Period End Date`)", "YEAR(`Period End Date`)",
        "'CMS Worksheet'", "`CMS Matrix Amount`*-1",
        "IFNULL(`Debit Accounted Amount`,0)-IFNULL(`Credit Accounted Amount`,0)",
        "IFNULL(`Amount`/`Oracle Exchange Rate`,0)",
        "CASE WHEN `Month Number` IN (1,2,3) THEN CONCAT(MONTHNAME(`Period End Date`),'-',"
        "LEFT(YEAR(`Period End Date`)-1,4)) ELSE CONCAT(MONTHNAME(`Period End Date`),'-',"
        "YEAR(`Period End Date`)) END",
        "CASE WHEN `_BATCH_ID_` = 2 THEN '2025-05-31' WHEN DAY(`_BATCH_LAST_RUN_`) >= 15 "
        "THEN LAST_DAY(`_BATCH_LAST_RUN_`) ELSE LAST_DAY(DATE_SUB(`_BATCH_LAST_RUN_`, "
        "INTERVAL 1 MONTH)) END",
        "CASE WHEN `Description` LIKE('%FX%') AND `Source` NOT IN ('GLOPIP') THEN "
        "'FX Current Month' ELSE `Source` END",
        "CASE WHEN `Currency` = 'GBP' THEN `Invoice Amount` * `Exchange Rate` "
        "ELSE `Invoice Amount` / `Exchange Rate` END",
    ]
    unresolved = [e for e in exprs if not translate(e, dialect="sql").resolved]
    assert unresolved == []


def test_both_dialects_share_the_same_semantic_caveats():
    """One AST, one set of DOMO-vs-engine divergences. Notes must not drift."""
    py = translate("CONCAT(`a`,`b`)", dialect="pyspark")
    sql = translate("CONCAT(`a`,`b`)", dialect="sql")
    assert py.notes == sql.notes and py.confidence == sql.confidence == "MEDIUM"


def test_unknown_function_escalates_in_sql_too():
    out = translate("WEIRD_FN(`a`)", dialect="sql")
    assert not out.resolved and out.unsupported == ["WEIRD_FN"] and out.code == ""


def test_empty_expression_is_sql_null():
    assert translate("  ", dialect="sql").code == "NULL"


def test_unknown_dialect_is_rejected():
    with pytest.raises(ValueError, match="unknown dialect"):
        translate("`a`", dialect="tsql")
