"""MD Plan subgraph. Uses build_gen_eval_hitl — the loop is never hand-rolled."""
from __future__ import annotations

from agents.md_plan.ports import JsonPairReader, PlanStore
from agents.md_plan.strategies import PlanEvaluator, PlanFeedbackApplier, PlanGenerator
from core.domo.llm import LLMClient
from core.domo.nodes import build_gen_eval_hitl

AGENT = "md_plan"


def build_md_plan_graph(*, llm: LLMClient, reader: JsonPairReader, store: PlanStore,
                        hitl: bool = True, ai_review: bool = True, max_iters: int = 3):
    """Per blueprint §2: AI generation + evaluation + human review are ON here."""
    return build_gen_eval_hitl(
        # keyword names are the factory's, not this module's: core.domo.nodes takes
        # `name` and `feedback_applier`. They disagreed until now, which made this
        # graph impossible to construct at all.
        name=AGENT,
        generator=PlanGenerator(reader=reader, store=store, llm=llm),
        evaluator=PlanEvaluator(llm, ai_review=ai_review),
        feedback_applier=PlanFeedbackApplier(),
        hitl=hitl,
        max_iters=max_iters,
    )
