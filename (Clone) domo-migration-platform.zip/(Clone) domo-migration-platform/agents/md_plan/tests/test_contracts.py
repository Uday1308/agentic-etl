"""MD Plan contracts (skill: generator consumes BOTH JSONs; evaluator returns a valid
EvalResult; P1 feedback overrides P4 base; outputs versioned per iteration)."""
from __future__ import annotations

import pytest
from conftest import FakeObservability, TrackingConcurrency, cfg, ts_iso

from agents.md_plan.ports import JsonPairReader, PlanStore
from agents.md_plan.strategies import PlanEvaluator, PlanFeedbackApplier, PlanGenerator
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.schemas import GenResult, HumanFeedback, Verdict


class Pair(JsonPairReader):
    """Both documents in the shape they really arrive in: id-keyed, tiles under
    ``actions``, edges under ``connections`` (core.contracts.standardized)."""

    def __init__(self):
        self.std_reads = 0
        self.raw_reads = 0

    def read_standardized(self, dataflow_id):
        self.std_reads += 1
        return {str(dataflow_id): {
            "id": dataflow_id, "name": "cms",
            "actions": [{"id": "s01", "name": "Filter Rows", "type": "filter",
                         "logic": {"filterGroups": []}},
                        {"id": "s02", "name": "Add Formula", "type": "formula",
                         "logic": {"expressions": [{"outputColumn": "c",
                                                    "expression": "UPPER(`a`)"}]}}],
            "connections": [{"from": "s01", "to": "s02"}],
            "inputs": [], "outputs": [], "disabled_skipped": []}}

    def read_raw(self, dataflow_id):
        self.raw_reads += 1
        return {str(dataflow_id): {
            "id": dataflow_id,
            "actions": [{"id": "s01", "name": "Filter Rows", "type": "filter",
                         "logic": {"filterGroups": [], "tile": "Filter"}}],
            "connections": [], "inputs": [], "outputs": [], "disabled_skipped": []}}


class Store(PlanStore):
    def __init__(self):
        self.writes = []

    def path_for(self, dataflow_id, iteration):
        return f"/Volumes/dev/md/plan_{dataflow_id}_v{iteration}.md"

    def write(self, dataflow_id, iteration, content):
        p = self.path_for(dataflow_id, iteration)
        self.writes.append((p, content))
        return p


def _llm(obs, conc, text="# Migration plan\n\n- intent: ..."):
    caller_prompts = []

    def caller(spec, prompt, schema, timeout):
        caller_prompts.append(prompt)
        if '"verdict"' in prompt or "Review this migration plan" in prompt:
            return RawCompletion(text='{"verdict":"pass","confidence":0.9,"issues":[],"summary":"ok"}')
        return RawCompletion(text=text)

    client = LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="g"),
                                        "evaluator": EndpointSpec(endpoint="e")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=conc, observability=obs, caller=caller)
    return client, caller_prompts


async def test_generator_consumes_both_jsons():
    """The original DOMO JSON carries tile detail the standardizer normalizes away."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)
    reader, store = Pair(), Store()
    res = await PlanGenerator(reader, store, llm).generate(
        {"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099"))
    assert reader.std_reads == 1 and reader.raw_reads == 1
    assert res.meta["read_standardized"] and res.meta["read_raw"]
    # node_keys are the df_vars the plan defines — the handle cd_codegen uses
    assert all(k.startswith("df_") for k in res.node_keys)
    assert res.meta["steps"] == len(res.node_keys)


async def test_a_raw_export_that_contributes_nothing_says_so():
    """Raw tile detail is an enrichment, so a raw document the fold cannot use must
    not abort the run — but it must not be reported as a satisfied contract either.
    `read_raw` records the read; `raw_merged` records whether it mattered."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)

    class OddRaw(Pair):
        def read_raw(self, dataflow_id):
            self.raw_reads += 1
            return {"dataflow": {"tiles": []}}          # a shape the fold cannot use

    reader = OddRaw()
    res = await PlanGenerator(reader, Store(), llm).generate(
        {"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099"))
    assert reader.raw_reads == 1 and res.meta["read_raw"] is True
    assert res.meta["raw_merged"] is False and res.meta["raw_node_count"] == 0
    assert res.meta["raw_fold_note"]                    # names what went wrong
    assert res.meta["steps"] == 2                       # plan still built, from std alone


async def test_outputs_are_versioned_per_iteration():
    """A plan regenerated after feedback is a NEW version, never an overwrite of the
    approved prior."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)
    store = Store()
    gen = PlanGenerator(Pair(), store, llm)
    await gen.generate({"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099", iteration=1))
    await gen.generate({"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099", iteration=2))
    assert [p for p, _ in store.writes] == [
        "/Volumes/dev/md/plan_8099_v1.md", "/Volumes/dev/md/plan_8099_v2.md"]


async def test_p1_human_feedback_outranks_the_base_prompt():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, prompts = _llm(obs, conc)
    fb = HumanFeedback(freeform="keep the DOMO union order",
                       hard_constraints=["Never rename source columns"], ts=ts_iso())
    await PlanGenerator(Pair(), Store(), llm).generate(
        {"dataflow_id": "8099", "feedback": {"md_plan": [fb]}}, cfg(dataflow_id="8099"))
    prompt = prompts[0]
    assert "[P1 HUMAN FEEDBACK" in prompt
    assert prompt.index("keep the DOMO union order") < prompt.index("[P4 TASK")


async def test_feedback_accumulates_across_iterations():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, prompts = _llm(obs, conc)
    fbs = [HumanFeedback(freeform="round one note", ts=ts_iso()),
           HumanFeedback(freeform="round two note", ts=ts_iso())]
    await PlanGenerator(Pair(), Store(), llm).generate(
        {"dataflow_id": "8099", "feedback": {"md_plan": fbs}}, cfg(dataflow_id="8099", iteration=2))
    assert "round one note" in prompts[0] and "round two note" in prompts[0]


async def test_mis_shaped_standardized_json_fails_loud():
    """A document the fold finds no tiles in must not become an empty skeleton plan:
    the renderer is total, so it would emit all nine sections with every table empty
    and a coverage report reading 100% — indistinguishable from a real plan."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)

    class Empty(Pair):
        def read_standardized(self, dataflow_id):
            return {"id": 8099, "name": "cms", "inputs": [], "outputs": []}

    with pytest.raises(ValueError, match="unusable|no nodes"):
        await PlanGenerator(Empty(), Store(), llm).generate(
            {"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099"))


async def test_discovery_row_export_is_rejected_with_a_pointer():
    """A discovery-table export is a list of rows, not a dataflow document. It has a
    real fold of its own — say so rather than failing on an AttributeError."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)

    class Rows(Pair):
        def read_standardized(self, dataflow_id):
            return [{"node_id": "s01", "record_type": "NODE"}]

    with pytest.raises(ValueError, match="discovery"):
        await PlanGenerator(Rows(), Store(), llm).generate(
            {"dataflow_id": "8099", "feedback": {}}, cfg(dataflow_id="8099"))


async def test_evaluator_returns_a_valid_eval_result():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)
    ev = await PlanEvaluator(llm).evaluate(GenResult(artifact="# plan"), {}, cfg())
    assert ev.verdict in (Verdict.PASS, Verdict.REVISE, Verdict.FAIL)
    assert 0.0 <= ev.confidence <= 1.0


async def test_empty_plan_fails_without_asking_a_model():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, prompts = _llm(obs, conc)
    ev = await PlanEvaluator(llm).evaluate(GenResult(artifact="   "), {}, cfg())
    assert ev.verdict is Verdict.FAIL and prompts == []


def test_per_issue_apply_and_keep():
    fb = HumanFeedback(accepted_issue_ids=["i1"], rejected_issue_ids=["i2"], ts=ts_iso())
    out = PlanFeedbackApplier().apply(GenResult(artifact="# plan"), [fb])
    assert out.meta["applied_issue_ids"] == ["i1"]


async def test_missing_dataflow_id_fails_loud():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm, _ = _llm(obs, conc)
    with pytest.raises(ValueError, match="dataflow_id"):
        await PlanGenerator(Pair(), Store(), llm).generate({}, {"configurable": {}})
