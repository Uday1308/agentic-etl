"""Tile renderers and the plan document — the deterministic half of MD Plan.

Ported (ADR 032 §8, P3-01) off the stale ``agents/md_plan/tiles.py`` copy onto the
shared registries in ``core.domo.tiles``: tile tests use ``tile_registry("pyspark")``,
plan tests ``PlanRenderer(registry=tile_registry("sql"))``. Goldens are pinned on the
plan text the SQL path emits today, not on the retired PySpark plan wording.
"""
from __future__ import annotations

import ast
from types import SimpleNamespace

import pytest

from agents.cd_codegen.md_extract import extract_md_plan
from agents.md_plan.render import PlanRenderer, snake
from core.domo.tiles import TileRegistry, tile_registry
from judges.rules import PlanSectionsPresent, PlanStepsExtractable

REG = tile_registry("pyspark")


def _plan() -> PlanRenderer:
    return PlanRenderer(registry=tile_registry("sql"))


def _render(node, inputs=("src_df",), out="df_out"):
    return REG.render(node, list(inputs), out)


def _valid_python(code: str) -> bool:
    ast.parse(code.replace("__PENDING_0__", "None"))
    return True


# -- tiles ------------------------------------------------------------------ #

def test_formula_tile_emits_valid_pyspark_with_domo_comments():
    r = _render({"type": "formula", "properties": {"expressions": [
        {"name": "Period End Date", "expression": "LAST_DAY(`Date`)"}]}})
    assert r.resolved and _valid_python(r.code)
    assert "# DOMO : LAST_DAY(`Date`)" in r.code
    assert r.expressions[0]["source"] == "python"


def test_formula_tile_escalates_only_the_bad_expression():
    r = _render({"type": "formula", "properties": {"expressions": [
        {"name": "good", "expression": "MONTH(`d`)"},
        {"name": "bad", "expression": "WEIRD_FN(`d`)"}]}})
    assert not r.resolved and r.unresolved == ["WEIRD_FN"]
    assert r.expressions[0]["source"] == "python"
    assert r.expressions[1]["source"] == "llm"


def test_join_tile_aliases_both_sides():
    """DOMO tolerates duplicate column names across inputs; Spark does not."""
    r = _render({"type": "join", "properties": {
        "joinKeys": [{"left": "Supplier", "right": "Company Name"}], "joinType": "left"}},
        inputs=("a_df", "b_df"))
    assert r.resolved and _valid_python(r.code)
    assert "_left = a_df.alias('left')" in r.code and "'left')" in r.code
    assert r.join_keys == [{"left": "Supplier", "right": "Company Name"}]


def test_join_without_keys_escalates_unless_cross():
    assert not _render({"type": "join", "properties": {}}, inputs=("a", "b")).resolved
    cross = _render({"type": "join", "properties": {"joinType": "cross"}}, inputs=("a", "b"))
    assert cross.resolved and any("cross join" in n for n in cross.notes)


def test_decimal_cast_always_states_precision():
    """A bare DecimalType() truncates to (10,0) — the SEM001 failure class."""
    r = _render({"type": "alterColumns", "properties": {"column_changes": [
        {"name": "Invoice Amount", "type": "DECIMAL"}]}})
    assert "DecimalType(18, 2)" in r.code
    assert any("truncates to (10,0)" in n for n in r.notes)
    assert r.confidence == "MEDIUM"


def test_first_aggregation_is_flagged_low_confidence():
    """The DET001 failure class: non-deterministic across runs."""
    r = _render({"type": "groupBy", "properties": {
        "groupBy": ["k"], "aggregations": [
            {"function": "FIRST", "column": "rate", "alias": "rate"}]}})
    assert r.confidence == "LOW"
    assert any("order-dependent" in n for n in r.notes)


def test_sum_aggregation_is_high_confidence():
    r = _render({"type": "groupBy", "properties": {
        "groupBy": ["k"], "aggregations": [
            {"function": "SUM", "column": "amt", "alias": "total"}]}})
    assert r.confidence == "HIGH" and r.resolved and _valid_python(r.code)


def test_filter_strips_domo_quote_artifact():
    r = _render({"type": "filter", "properties": {"conditions": [
        {"column": "Paying Company", "operator": "NOT_EQUALS", "value": "DIAM"}]}})
    assert "regexp_replace" in r.code and _valid_python(r.code)


def test_union_flags_permissive_column_handling():
    r = _render({"type": "append", "properties": {}}, inputs=("a", "b", "c"))
    assert r.resolved and any("schema drift" in n for n in r.notes)


def test_unknown_tile_escalates_rather_than_guessing():
    r = _render({"type": "RiskScore", "properties": {}})
    assert not r.resolved and "RiskScore" in r.unresolved[0] and r.confidence == "LOW"


def test_a_broken_renderer_escalates_instead_of_crashing():
    class Boom:
        op_types = ("BOOM",)

        def render(self, node, inputs, out_var):
            raise RuntimeError("kaboom")

    reg = TileRegistry([Boom()])
    r = reg.render({"type": "BOOM"}, [], "df")
    assert not r.resolved and "kaboom" in r.unresolved[0]


@pytest.mark.parametrize("tile", [
    {"type": "select", "properties": {"columns": [{"name": "C4", "alias": "Settlement Date"}]}},
    {"type": "sort", "properties": {"orderBy": [{"column": "d", "direction": "desc"}]}},
    {"type": "dataSet", "properties": {"source_table": "b.src"}},
])
def test_remaining_tiles_emit_valid_python(tile):
    r = _render(tile)
    assert r.resolved and _valid_python(r.code)


# -- plan document ---------------------------------------------------------- #

STD = {
    "dataflow_id": "8099",
    "nodes": [
        {"id": "n1", "name": "Feed", "category": "SOURCE", "type": "DataSet",
         "properties": {"dataset_name": "NA | F&A | Feed | FEED", "dataSourceId": "abc"}},
        {"id": "n2", "name": "Add Formula 1", "type": "formula", "properties": {
            "expressions": [{"name": "Period End Date", "expression": "LAST_DAY(`Date`)"}]}},
        {"id": "n3", "name": "Out PROD", "category": "TARGET", "type": "Target",
         "properties": {"dataset_name": "NA | F&A | Out | PROD", "write_mode": "REPLACE"}},
    ],
    "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
}


def test_plan_has_every_section_the_extractor_needs():
    doc = _plan().build(STD, dataflow_id="8099", dataflow_name="cms").document
    for section in ("## 1. Pipeline Overview", "## 2. Source Tables", "## 3. Execution DAG",
                    "## 4. DataFrame Variable Map", "## 5. Transformation Plan",
                    "## 6. Output Targets", "## 8. Review Checklist",
                    "## 9. Python vs. LLM Coverage Report"):
        assert section in doc


def test_plan_round_trips_through_the_cd_codegen_extractor():
    """The hard contract between agent 4 and agent 5."""
    doc = _plan().build(STD, dataflow_id="8099", dataflow_name="cms").document
    ex = extract_md_plan(doc, dataflow_id="8099")
    # writes come from PlanBuild.writes on the SQL path; section 6 is a table now
    assert len(ex.sources) == 1 and len(ex.steps) == 1
    assert ex.steps[0].step == "s01" and ex.steps[0].node_type == "FORMULA"
    assert ex.steps[0].df_var == "df_add_formula_1_s01"
    assert ex.steps[0].confidence == "HIGH"
    build = _plan().build(STD, dataflow_id="8099", dataflow_name="cms")
    assert [w["table"] for w in build.targets] == ["dev_test.migrated_output.na_f_a_out_prod"]
    subject = SimpleNamespace(artifact=doc, node_ids=[], meta={})
    assert PlanSectionsPresent().run(subject).verdict.value == "pass"
    assert PlanStepsExtractable().run(subject).verdict.value == "pass"


def test_topological_order_is_deterministic():
    """Two runs of the same dataflow must produce byte-identical plans."""
    a = _plan().build(STD, dataflow_id="8099").document
    b = _plan().build(STD, dataflow_id="8099").document
    assert a == b


def test_cycle_is_rejected_loudly():
    bad = {"nodes": [{"id": "a", "type": "filter"}, {"id": "b", "type": "filter"}],
           "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "a"}]}
    with pytest.raises(ValueError, match="cycle or dangling"):
        _plan().build(bad, dataflow_id="1")


def test_unresolved_step_becomes_an_escalation_block_not_fake_code():
    std = {**STD, "nodes": STD["nodes"] + [
        {"id": "n4", "name": "Risk Score", "type": "RiskScore", "properties": {}}],
        "edges": STD["edges"] + [{"from": "n2", "to": "n4"}]}
    build = _plan().build(std, dataflow_id="8099")
    assert len(build.unresolved) == 1
    assert "Cannot be translated from the tile vocabulary." in build.document
    assert build.coverage_pct == 50.0


def test_coverage_report_states_the_real_split():
    build = _plan().build(STD, dataflow_id="8099")
    assert "1/1 transformations resolved deterministically (100.0%)" in build.document


def test_risk_register_lists_flagged_steps():
    std = {**STD, "nodes": [
        STD["nodes"][0],
        {"id": "n2", "name": "Group By 1", "type": "groupBy", "properties": {
            "groupBy": ["k"], "aggregations": [
                {"function": "FIRST", "column": "rate", "alias": "rate"}]}},
        STD["nodes"][2]]}
    doc = _plan().build(std, dataflow_id="8099").document
    checklist = doc.split("## 8. Review Checklist")[1]
    assert "Group By 1" in checklist and "LOW" in checklist
    assert "order-dependent" in checklist


def test_overview_names_the_structural_risks():
    std = {**STD, "nodes": [
        STD["nodes"][0],
        {"id": "n2", "name": "G", "type": "groupBy", "properties": {
            "groupBy": ["k"], "aggregations": [{"function": "FIRST", "column": "r"}]}},
        STD["nodes"][2]]}
    doc = _plan().build(std, dataflow_id="8099").document
    overview = doc.split("## 2.")[0]
    assert "order-dependent aggregations" in overview


def test_snake_is_stable_for_domo_pipe_names():
    assert snake("NA | F&A | CMS Summary | PROD") == "na_f_a_cms_summary_prod"
