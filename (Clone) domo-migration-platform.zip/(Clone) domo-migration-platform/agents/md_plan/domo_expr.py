"""agents.md_plan.domo_expr — parse DOMO Beast Mode expressions, emit PySpark or SQL.

This is the core deterministic asset of the whole platform. DOMO's formula language is
SQL-flavoured and closed, so it is parsed properly — tokenizer, Pratt parser, AST,
emitter — rather than pattern-matched with regexes. Regexes cannot handle nested
``CASE WHEN`` or operator precedence, and getting those subtly wrong in a financial
reconciliation pipeline is the expensive kind of bug.

What falls out of a real parser that a regex cannot give you:

* precedence and associativity are correct by construction;
* an expression either parses or raises — there is no silent half-translation;
* unsupported functions are identified precisely (name + position), so only the
  genuinely unknown fragment escalates to a model;
* the same AST emits PySpark today and SQL tomorrow without re-parsing.

Semantic decisions are recorded, not assumed. DOMO and Spark disagree about integer
division, decimal precision and null handling in CONCAT, so those become explicit
``notes`` on the result for the plan's risk register.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

# --------------------------------------------------------------------------- #
# tokens
# --------------------------------------------------------------------------- #


class T(str, Enum):
    NUM = "num"
    STR = "str"
    COL = "col"          # `Column Name` or bare identifier used as a column
    IDENT = "ident"      # function name / keyword
    OP = "op"
    LPAREN = "("
    RPAREN = ")"
    COMMA = ","
    END = "end"


@dataclass(frozen=True)
class Token:
    kind: T
    value: str
    pos: int


class DomoParseError(ValueError):
    """Raised when an expression cannot be parsed. Carries the offset so the plan can
    point a human at the exact character."""

    def __init__(self, message: str, pos: int, source: str) -> None:
        super().__init__(f"{message} at offset {pos}: {source[max(0, pos - 25):pos + 25]!r}")
        self.pos = pos
        self.source = source


_KEYWORDS = {"CASE", "WHEN", "THEN", "ELSE", "END", "AND", "OR", "NOT", "IN", "LIKE",
             "IS", "NULL", "INTERVAL", "AS", "DISTINCT", "BETWEEN"}

_MULTI_OPS = ("<=", ">=", "<>", "!=", "||")
_SINGLE_OPS = "+-*/%=<>"

_NUM_RE = re.compile(r"\d+\.\d+|\.\d+|\d+")
_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def tokenize(src: str) -> list[Token]:
    """Turn an expression into tokens. Handles backticked columns, single/double
    quoted strings with doubled-quote escapes, and /* block comments */ which DOMO
    users leave inside formulas."""
    out: list[Token] = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c in " \t\r\n":
            i += 1
            continue
        if src.startswith("/*", i):                      # block comment
            end = src.find("*/", i + 2)
            i = n if end == -1 else end + 2
            continue
        if src.startswith("--", i):                      # line comment
            end = src.find("\n", i)
            i = n if end == -1 else end + 1
            continue
        if c == "`":
            end = src.find("`", i + 1)
            if end == -1:
                raise DomoParseError("unterminated column reference", i, src)
            out.append(Token(T.COL, src[i + 1:end], i))
            i = end + 1
            continue
        if c in "'\"":
            quote, j, buf = c, i + 1, []
            while j < n:
                if src[j] == quote:
                    if j + 1 < n and src[j + 1] == quote:  # '' escape
                        buf.append(quote)
                        j += 2
                        continue
                    break
                buf.append(src[j])
                j += 1
            else:
                raise DomoParseError("unterminated string literal", i, src)
            out.append(Token(T.STR, "".join(buf), i))
            i = j + 1
            continue
        m = _NUM_RE.match(src, i)
        if m and (c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit())):
            out.append(Token(T.NUM, m.group(0), i))
            i = m.end()
            continue
        m = _IDENT_RE.match(src, i)
        if m:
            word = m.group(0)
            kind = T.IDENT if word.upper() in _KEYWORDS else T.IDENT
            out.append(Token(kind, word, i))
            i = m.end()
            continue
        two = src[i:i + 2]
        if two in _MULTI_OPS:
            out.append(Token(T.OP, two, i))
            i += 2
            continue
        if c == "(":
            out.append(Token(T.LPAREN, c, i))
            i += 1
            continue
        if c == ")":
            out.append(Token(T.RPAREN, c, i))
            i += 1
            continue
        if c == ",":
            out.append(Token(T.COMMA, c, i))
            i += 1
            continue
        if c in _SINGLE_OPS:
            out.append(Token(T.OP, c, i))
            i += 1
            continue
        raise DomoParseError(f"unexpected character {c!r}", i, src)
    out.append(Token(T.END, "", n))
    return out


# --------------------------------------------------------------------------- #
# AST
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class Node:
    pass


@dataclass(frozen=True)
class Lit(Node):
    value: Any
    is_string: bool = False


@dataclass(frozen=True)
class NullLit(Node):
    pass


@dataclass(frozen=True)
class Col(Node):
    name: str


@dataclass(frozen=True)
class Unary(Node):
    op: str
    operand: Node


@dataclass(frozen=True)
class Binary(Node):
    op: str
    left: Node
    right: Node


@dataclass(frozen=True)
class Func(Node):
    name: str
    args: tuple[Node, ...]


@dataclass(frozen=True)
class Case(Node):
    whens: tuple[tuple[Node, Node], ...]
    otherwise: Node | None


@dataclass(frozen=True)
class InList(Node):
    target: Node
    items: tuple[Node, ...]
    negated: bool = False


@dataclass(frozen=True)
class Like(Node):
    target: Node
    pattern: Node
    negated: bool = False


@dataclass(frozen=True)
class IsNull(Node):
    target: Node
    negated: bool = False


@dataclass(frozen=True)
class Interval(Node):
    amount: Node
    unit: str


# --------------------------------------------------------------------------- #
# parser (Pratt / precedence climbing)
# --------------------------------------------------------------------------- #

#: higher binds tighter
_PRECEDENCE = {
    "OR": 1, "AND": 2,
    "=": 4, "<>": 4, "!=": 4, "<": 4, "<=": 4, ">": 4, ">=": 4,
    "+": 6, "-": 6, "||": 6,
    "*": 8, "/": 8, "%": 8,
}


class Parser:
    def __init__(self, src: str) -> None:
        self.src = src
        self.toks = tokenize(src)
        self.i = 0

    # -- helpers ---------------------------------------------------------- #
    @property
    def cur(self) -> Token:
        return self.toks[self.i]

    def advance(self) -> Token:
        t = self.toks[self.i]
        self.i += 1
        return t

    def at_word(self, *words: str) -> bool:
        return self.cur.kind is T.IDENT and self.cur.value.upper() in words

    def eat_word(self, *words: str) -> Token:
        if not self.at_word(*words):
            raise DomoParseError(f"expected {' or '.join(words)}, got {self.cur.value!r}",
                                 self.cur.pos, self.src)
        return self.advance()

    def eat(self, kind: T) -> Token:
        if self.cur.kind is not kind:
            raise DomoParseError(f"expected {kind.value}, got {self.cur.value!r}",
                                 self.cur.pos, self.src)
        return self.advance()

    # -- entry ------------------------------------------------------------ #
    def parse(self) -> Node:
        node = self.expression(0)
        if self.cur.kind is not T.END:
            raise DomoParseError(f"unexpected trailing input {self.cur.value!r}",
                                 self.cur.pos, self.src)
        return node

    def expression(self, min_prec: int) -> Node:
        left = self.unary()
        while True:
            op = self._peek_binary()
            if op is None or _PRECEDENCE[op] < min_prec:
                break
            self._consume_binary(op)
            right = self.expression(_PRECEDENCE[op] + 1)
            left = Binary(op=op, left=left, right=right)
        return self.postfix(left)

    def _peek_binary(self) -> str | None:
        if self.cur.kind is T.OP and self.cur.value in _PRECEDENCE:
            return self.cur.value
        if self.cur.kind is T.IDENT and self.cur.value.upper() in ("AND", "OR"):
            return self.cur.value.upper()
        return None

    def _consume_binary(self, op: str) -> None:
        self.advance()

    def unary(self) -> Node:
        if self.cur.kind is T.OP and self.cur.value in ("-", "+"):
            op = self.advance().value
            return Unary(op=op, operand=self.unary())
        if self.at_word("NOT"):
            self.advance()
            return Unary(op="NOT", operand=self.unary())
        return self.postfix(self.primary())

    def postfix(self, node: Node) -> Node:
        """IN / LIKE / IS NULL / BETWEEN bind after the primary."""
        while True:
            negated = False
            save = self.i
            if self.at_word("NOT"):
                self.advance()
                negated = True
            if self.at_word("IN"):
                self.advance()
                self.eat(T.LPAREN)
                items: list[Node] = []
                if self.cur.kind is not T.RPAREN:
                    items.append(self.expression(0))
                    while self.cur.kind is T.COMMA:
                        self.advance()
                        items.append(self.expression(0))
                self.eat(T.RPAREN)
                node = InList(target=node, items=tuple(items), negated=negated)
                continue
            if self.at_word("LIKE"):
                self.advance()
                # DOMO writes both `LIKE '%x%'` and `LIKE('%x%')`
                if self.cur.kind is T.LPAREN:
                    self.advance()
                    pattern = self.expression(0)
                    self.eat(T.RPAREN)
                else:
                    pattern = self.expression(_PRECEDENCE["="] + 1)
                node = Like(target=node, pattern=pattern, negated=negated)
                continue
            if self.at_word("BETWEEN"):
                self.advance()
                lo = self.expression(_PRECEDENCE["AND"] + 1)
                self.eat_word("AND")
                hi = self.expression(_PRECEDENCE["AND"] + 1)
                cmp_lo = Binary(op=">=", left=node, right=lo)
                cmp_hi = Binary(op="<=", left=node, right=hi)
                both = Binary(op="AND", left=cmp_lo, right=cmp_hi)
                node = Unary(op="NOT", operand=both) if negated else both
                continue
            if self.at_word("IS"):
                self.advance()
                inner_neg = negated
                if self.at_word("NOT"):
                    self.advance()
                    inner_neg = not inner_neg
                self.eat_word("NULL")
                node = IsNull(target=node, negated=inner_neg)
                continue
            self.i = save
            break
        return node

    def primary(self) -> Node:
        tok = self.cur
        if tok.kind is T.NUM:
            self.advance()
            v = float(tok.value) if "." in tok.value else int(tok.value)
            return Lit(value=v)
        if tok.kind is T.STR:
            self.advance()
            return Lit(value=tok.value, is_string=True)
        if tok.kind is T.COL:
            self.advance()
            return Col(name=tok.value)
        if tok.kind is T.LPAREN:
            self.advance()
            node = self.expression(0)
            self.eat(T.RPAREN)
            return node
        if tok.kind is T.IDENT:
            word = tok.value.upper()
            if word == "CASE":
                return self.case_expr()
            if word == "NULL":
                self.advance()
                return NullLit()
            if word == "INTERVAL":
                self.advance()
                amount = self.expression(_PRECEDENCE["*"])
                unit = self.eat(T.IDENT).value.upper()
                return Interval(amount=amount, unit=unit)
            self.advance()
            if self.cur.kind is T.LPAREN:                # function call
                self.advance()
                args: list[Node] = []
                if self.cur.kind is not T.RPAREN:
                    if self.at_word("DISTINCT"):
                        self.advance()
                    args.append(self.expression(0))
                    while self.cur.kind is T.COMMA:
                        self.advance()
                        args.append(self.expression(0))
                self.eat(T.RPAREN)
                return Func(name=word, args=tuple(args))
            return Col(name=tok.value)                   # bare identifier == column
        raise DomoParseError(f"unexpected token {tok.value!r}", tok.pos, self.src)

    def case_expr(self) -> Node:
        self.eat_word("CASE")
        # CASE <operand> WHEN v THEN ... (simple form) or CASE WHEN cond THEN ...
        operand: Node | None = None
        if not self.at_word("WHEN"):
            if self.at_word("ELSE", "END", "THEN"):
                raise DomoParseError("CASE with no WHEN branch", self.cur.pos, self.src)
            operand = self.expression(0)
            if not self.at_word("WHEN"):
                raise DomoParseError("CASE with no WHEN branch", self.cur.pos, self.src)
        whens: list[tuple[Node, Node]] = []
        while self.at_word("WHEN"):
            self.advance()
            cond = self.expression(0)
            if operand is not None:
                cond = Binary(op="=", left=operand, right=cond)
            self.eat_word("THEN")
            whens.append((cond, self.expression(0)))
        otherwise: Node | None = None
        if self.at_word("ELSE"):
            self.advance()
            otherwise = self.expression(0)
        self.eat_word("END")
        if not whens:
            raise DomoParseError("CASE with no WHEN branch", self.cur.pos, self.src)
        return Case(whens=tuple(whens), otherwise=otherwise)


def parse(expression: str) -> Node:
    return Parser(expression).parse()


# --------------------------------------------------------------------------- #
# emission
# --------------------------------------------------------------------------- #


@dataclass
class Emitted:
    """The translated expression plus everything the plan's risk register needs."""
    code: str
    functions_used: set[str] = field(default_factory=set)
    columns_used: set[str] = field(default_factory=set)
    notes: list[str] = field(default_factory=list)      # semantic caveats for a human
    unsupported: list[str] = field(default_factory=list)

    @property
    def resolved(self) -> bool:
        return not self.unsupported

    @property
    def confidence(self) -> str:
        if self.unsupported:
            return "LOW"
        return "MEDIUM" if self.notes else "HIGH"


class UnsupportedFunction(ValueError):
    pass


def _col_ref(name: str) -> str:
    """Backtick a column when it needs it. Dots become __ because a dotted name is
    read as a struct path by Spark."""
    safe = name.replace(".", "__")
    needs = not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", safe)
    return f"F.col('`{safe}`')" if needs else f"F.col('{safe}')"


class PySparkEmitter:
    """AST -> PySpark column expression.

    Every function is mapped explicitly. Anything not in the table is reported as
    unsupported rather than guessed at — a wrong guess in a reconciliation pipeline
    is worse than an escalation to a human.
    """

    #: DOMO function -> (emitter, note). The note is a semantic caveat worth a human's
    #: attention, recorded in the plan rather than silently accepted.
    SIMPLE: dict[str, str] = {
        "ABS": "F.abs", "CEIL": "F.ceil", "CEILING": "F.ceil", "FLOOR": "F.floor",
        "LOWER": "F.lower", "UPPER": "F.upper", "TRIM": "F.trim", "LTRIM": "F.ltrim",
        "RTRIM": "F.rtrim", "LENGTH": "F.length", "REVERSE": "F.reverse",
        "YEAR": "F.year", "MONTH": "F.month", "DAY": "F.dayofmonth",
        "DAYOFMONTH": "F.dayofmonth", "DAYOFWEEK": "F.dayofweek",
        "DAYOFYEAR": "F.dayofyear", "WEEKOFYEAR": "F.weekofyear",
        "HOUR": "F.hour", "MINUTE": "F.minute", "SECOND": "F.second",
        "LAST_DAY": "F.last_day", "SQRT": "F.sqrt", "EXP": "F.exp", "LN": "F.log",
        "SIGN": "F.signum", "MD5": "F.md5", "SHA1": "F.sha1",
        "CURRENT_DATE": "F.current_date", "CURRENT_TIMESTAMP": "F.current_timestamp",
        "SUM": "F.sum", "MIN": "F.min", "MAX": "F.max", "AVG": "F.avg", "COUNT": "F.count",
    }

    NOTES: dict[str, str] = {
        "CONCAT": "DOMO CONCAT ignores nulls; Spark concat returns null if any argument "
                  "is null. Wrap arguments in coalesce if null inputs are possible.",
        "DIVIDE": "integer division differs between DOMO and Spark; cast to double if "
                  "fractional results are expected",
        "ROUND": "DOMO rounds half away from zero; Spark rounds half up. Results can "
                 "differ on exact .5 values.",
        "AVG": "aggregate inside a formula tile — confirm the intended grouping",
    }

    def emit(self, node: Node, out: Emitted | None = None) -> Emitted:
        out = out or Emitted(code="")
        out.code = self._emit(node, out)
        return out

    # -- dispatch --------------------------------------------------------- #
    def _emit(self, n: Node, o: Emitted) -> str:
        if isinstance(n, Lit):
            return f"F.lit({n.value!r})" if n.is_string else f"F.lit({n.value})"
        if isinstance(n, NullLit):
            return "F.lit(None)"
        if isinstance(n, Col):
            o.columns_used.add(n.name)
            return _col_ref(n.name)
        if isinstance(n, Unary):
            return self._unary(n, o)
        if isinstance(n, Binary):
            return self._binary(n, o)
        if isinstance(n, Case):
            return self._case(n, o)
        if isinstance(n, InList):
            items = ", ".join(self._literal_or_code(a, o) for a in n.items)
            expr = f"{self._emit(n.target, o)}.isin([{items}])"
            return f"(~({expr}))" if n.negated else f"({expr})"
        if isinstance(n, Like):
            pat = n.pattern.value if isinstance(n.pattern, Lit) else None
            code = (f"{self._emit(n.target, o)}.like({pat!r})" if pat is not None
                    else f"{self._emit(n.target, o)}.like({self._emit(n.pattern, o)})")
            return f"(~({code}))" if n.negated else f"({code})"
        if isinstance(n, IsNull):
            t = self._emit(n.target, o)
            return f"({t}.isNotNull())" if n.negated else f"({t}.isNull())"
        if isinstance(n, Interval):
            raise UnsupportedFunction("INTERVAL outside a date function")
        if isinstance(n, Func):
            return self._func(n, o)
        raise UnsupportedFunction(f"cannot emit node {type(n).__name__}")

    def _literal_or_code(self, n: Node, o: Emitted) -> str:
        if isinstance(n, Lit):
            return repr(n.value)
        return self._emit(n, o)

    def _unary(self, n: Unary, o: Emitted) -> str:
        inner = self._emit(n.operand, o)
        if n.op == "NOT":
            return f"(~({inner}))"
        if n.op == "-":
            return f"(-1 * {inner})" if not isinstance(n.operand, Lit) else f"F.lit({-n.operand.value})"
        return inner

    _BIN = {"=": "==", "<>": "!=", "!=": "!=", "<": "<", "<=": "<=", ">": ">", ">=": ">=",
            "+": "+", "-": "-", "*": "*", "/": "/", "%": "%"}

    def _binary(self, n: Binary, o: Emitted) -> str:
        left, right = self._emit(n.left, o), self._emit(n.right, o)
        if n.op == "AND":
            return f"({left} & {right})"
        if n.op == "OR":
            return f"({left} | {right})"
        if n.op == "||":
            o.functions_used.add("CONCAT")
            o.notes.append(self.NOTES["CONCAT"])
            return f"F.concat({left}, {right})"
        if n.op == "/":
            o.notes.append(self.NOTES["DIVIDE"])
        return f"({left} {self._BIN[n.op]} {right})"

    def _case(self, n: Case, o: Emitted) -> str:
        o.functions_used.add("CASE WHEN")
        parts = []
        for i, (cond, val) in enumerate(n.whens):
            fn = "F.when" if i == 0 else ".when"
            parts.append(f"{fn}({self._emit(cond, o)}, {self._emit(val, o)})")
        code = "".join(parts)
        if n.otherwise is not None:
            code += f".otherwise({self._emit(n.otherwise, o)})"
        else:
            o.notes.append("CASE without ELSE returns null for unmatched rows — "
                           "confirm that is intended")
        return code

    def _func(self, n: Func, o: Emitted) -> str:
        name = n.name.upper()
        o.functions_used.add(name)
        if name in self.NOTES:
            o.notes.append(self.NOTES[name])
        args = list(n.args)

        if name in self.SIMPLE:
            rendered = ", ".join(self._emit(a, o) for a in args)
            return f"{self.SIMPLE[name]}({rendered})"

        if name in ("IFNULL", "NVL", "COALESCE"):
            rendered = ", ".join(self._emit(a, o) for a in args)
            return f"F.coalesce({rendered})"
        if name == "CONCAT":
            rendered = ", ".join(self._emit(a, o) for a in args)
            return f"F.concat({rendered})"
        if name == "MONTHNAME":
            return f"F.date_format({self._emit(args[0], o)}, 'MMMM')"
        if name == "DAYNAME":
            return f"F.date_format({self._emit(args[0], o)}, 'EEEE')"
        if name == "LEFT":
            length = self._literal_or_code(args[1], o)
            return f"F.substring({self._cast_str(args[0], o)}, 1, {length})"
        if name == "RIGHT":
            length = self._literal_or_code(args[1], o)
            return f"F.substring({self._cast_str(args[0], o)}, -{length}, {length})"
        if name in ("SUBSTR", "SUBSTRING", "MID"):
            start = self._literal_or_code(args[1], o)
            ln = self._literal_or_code(args[2], o) if len(args) > 2 else "2147483647"
            return f"F.substring({self._cast_str(args[0], o)}, {start}, {ln})"
        if name == "REPLACE":
            return (f"F.regexp_replace({self._emit(args[0], o)}, "
                    f"{self._literal_or_code(args[1], o)}, {self._literal_or_code(args[2], o)})")
        if name == "ROUND":
            scale = self._literal_or_code(args[1], o) if len(args) > 1 else "0"
            return f"F.round({self._emit(args[0], o)}, {scale})"
        if name in ("POW", "POWER"):
            return f"F.pow({self._emit(args[0], o)}, {self._emit(args[1], o)})"
        if name in ("DATE_SUB", "DATE_ADD"):
            return self._date_shift(name, args, o)
        if name == "DATEDIFF":
            return f"F.datediff({self._emit(args[0], o)}, {self._emit(args[1], o)})"
        if name == "DATE_FORMAT":
            return f"F.date_format({self._emit(args[0], o)}, {self._literal_or_code(args[1], o)})"
        if name in ("DATE", "TO_DATE"):
            fmt = self._literal_or_code(args[1], o) if len(args) > 1 else "'yyyy-MM-dd'"
            return f"F.to_date({self._emit(args[0], o)}, {fmt})"
        if name == "CAST":
            raise UnsupportedFunction("CAST(x AS type) — handled by the alter-columns tile")
        raise UnsupportedFunction(name)

    def _cast_str(self, n: Node, o: Emitted) -> str:
        code = self._emit(n, o)
        return code if ".cast(" in code else f"{code}.cast('string')"

    def _date_shift(self, name: str, args: list[Node], o: Emitted) -> str:
        """DATE_SUB(x, INTERVAL 1 MONTH) and DATE_SUB(x, 7) are both legal DOMO."""
        base = self._emit(args[0], o)
        sign = -1 if name == "DATE_SUB" else 1
        if len(args) < 2:
            raise UnsupportedFunction(f"{name} with a single argument")
        second = args[1]
        if isinstance(second, Interval):
            amount = second.amount
            if not isinstance(amount, Lit):
                raise UnsupportedFunction(f"{name} with a non-literal interval")
            n_units = sign * int(amount.value)
            unit = second.unit
            if unit in ("MONTH", "MONTHS"):
                return f"F.add_months({base}, {n_units})"
            if unit in ("YEAR", "YEARS"):
                return f"F.add_months({base}, {n_units * 12})"
            if unit in ("DAY", "DAYS"):
                return f"F.date_add({base}, {n_units})"
            if unit in ("WEEK", "WEEKS"):
                return f"F.date_add({base}, {n_units * 7})"
            raise UnsupportedFunction(f"{name} INTERVAL unit {unit}")
        days = self._literal_or_code(second, o)
        return (f"F.date_sub({base}, {days})" if sign < 0 else f"F.date_add({base}, {days})")


class SqlEmitter:
    """AST -> Databricks SQL.

    SQL is a *closer* target than the DataFrame API: DOMO's formula language is already
    SQL-flavoured, so ``CASE WHEN``, ``IN``, ``LIKE``, ``IS NULL`` and the arithmetic
    operators pass through natively instead of becoming method chains. That means less
    surface to get wrong, not more.

    The same semantic caveats still apply — Databricks SQL and DOMO disagree about
    CONCAT nulls, integer division and ROUND tie-breaking — so the notes are shared
    with the PySpark emitter rather than restated.
    """

    #: DOMO function -> Databricks SQL function, where the name simply differs
    RENAMED: dict[str, str] = {
        "IFNULL": "coalesce", "NVL": "coalesce", "COALESCE": "coalesce",
        "DAY": "dayofmonth", "LN": "ln", "SIGN": "signum",
        "CEILING": "ceil", "MID": "substring", "SUBSTR": "substring",
        "POW": "power",
    }

    #: DOMO functions whose SQL spelling is identical (lower-cased)
    PASSTHROUGH: frozenset[str] = frozenset({
        "ABS", "CEIL", "FLOOR", "LOWER", "UPPER", "TRIM", "LTRIM", "RTRIM", "LENGTH",
        "REVERSE", "YEAR", "MONTH", "DAYOFMONTH", "DAYOFWEEK", "DAYOFYEAR", "WEEKOFYEAR",
        "HOUR", "MINUTE", "SECOND", "LAST_DAY", "SQRT", "EXP", "MD5", "SHA1",
        "CURRENT_DATE", "CURRENT_TIMESTAMP", "SUM", "MIN", "MAX", "AVG", "COUNT",
        "CONCAT", "REPLACE", "ROUND", "DATEDIFF", "DATE_FORMAT", "POWER", "SUBSTRING",
        "LEFT", "RIGHT",
    })

    NOTES = PySparkEmitter.NOTES

    def emit(self, node: Node, out: Emitted | None = None) -> Emitted:
        out = out or Emitted(code="")
        out.code = self._emit(node, out)
        return out

    def _emit(self, n: Node, o: Emitted) -> str:
        if isinstance(n, Lit):
            if n.is_string:
                return "'" + str(n.value).replace("'", "''") + "'"
            return str(n.value)
        if isinstance(n, NullLit):
            return "NULL"
        if isinstance(n, Col):
            o.columns_used.add(n.name)
            return f"`{n.name.replace('.', '__')}`"
        if isinstance(n, Unary):
            inner = self._emit(n.operand, o)
            if n.op == "NOT":
                return f"(NOT {inner})"
            return f"(-{inner})" if n.op == "-" else inner
        if isinstance(n, Binary):
            return self._binary(n, o)
        if isinstance(n, Case):
            o.functions_used.add("CASE WHEN")
            parts = ["CASE"]
            for cond, val in n.whens:
                parts.append(f"WHEN {self._emit(cond, o)} THEN {self._emit(val, o)}")
            if n.otherwise is not None:
                parts.append(f"ELSE {self._emit(n.otherwise, o)}")
            else:
                o.notes.append("CASE without ELSE returns null for unmatched rows — "
                               "confirm that is intended")
            parts.append("END")
            return "(" + " ".join(parts) + ")"
        if isinstance(n, InList):
            items = ", ".join(self._emit(a, o) for a in n.items)
            kw = "NOT IN" if n.negated else "IN"
            return f"({self._emit(n.target, o)} {kw} ({items}))"
        if isinstance(n, Like):
            kw = "NOT LIKE" if n.negated else "LIKE"
            return f"({self._emit(n.target, o)} {kw} {self._emit(n.pattern, o)})"
        if isinstance(n, IsNull):
            kw = "IS NOT NULL" if n.negated else "IS NULL"
            return f"({self._emit(n.target, o)} {kw})"
        if isinstance(n, Interval):
            raise UnsupportedFunction("INTERVAL outside a date function")
        if isinstance(n, Func):
            return self._func(n, o)
        raise UnsupportedFunction(f"cannot emit node {type(n).__name__}")

    _BIN = {"=": "=", "<>": "<>", "!=": "<>", "<": "<", "<=": "<=", ">": ">", ">=": ">=",
            "+": "+", "-": "-", "*": "*", "/": "/", "%": "%"}

    def _binary(self, n: Binary, o: Emitted) -> str:
        left, right = self._emit(n.left, o), self._emit(n.right, o)
        if n.op in ("AND", "OR"):
            return f"({left} {n.op} {right})"
        if n.op == "||":
            o.functions_used.add("CONCAT")
            o.notes.append(self.NOTES["CONCAT"])
            return f"concat({left}, {right})"
        if n.op == "/":
            o.notes.append(self.NOTES["DIVIDE"])
        return f"({left} {self._BIN[n.op]} {right})"

    def _func(self, n: Func, o: Emitted) -> str:
        name = n.name.upper()
        o.functions_used.add(name)
        if name in self.NOTES:
            o.notes.append(self.NOTES[name])
        args = list(n.args)

        if name == "MONTHNAME":
            return f"date_format({self._emit(args[0], o)}, 'MMMM')"
        if name == "DAYNAME":
            return f"date_format({self._emit(args[0], o)}, 'EEEE')"
        if name in ("DATE", "TO_DATE"):
            fmt = self._emit(args[1], o) if len(args) > 1 else "'yyyy-MM-dd'"
            return f"to_date({self._emit(args[0], o)}, {fmt})"
        if name in ("DATE_SUB", "DATE_ADD"):
            return self._date_shift(name, args, o)
        if name == "LEFT":
            # cast first: DOMO applies LEFT to numbers, SQL left() wants a string
            return f"left(cast({self._emit(args[0], o)} AS STRING), {self._emit(args[1], o)})"
        if name == "RIGHT":
            return f"right(cast({self._emit(args[0], o)} AS STRING), {self._emit(args[1], o)})"
        if name == "CAST":
            raise UnsupportedFunction("CAST(x AS type) — handled by the alter-columns tile")

        target = self.RENAMED.get(name) or (name.lower() if name in self.PASSTHROUGH else None)
        if target is None:
            raise UnsupportedFunction(name)
        rendered = ", ".join(self._emit(a, o) for a in args)
        return f"{target}({rendered})" if rendered else f"{target}()"

    def _date_shift(self, name: str, args: list[Node], o: Emitted) -> str:
        base = self._emit(args[0], o)
        sign = -1 if name == "DATE_SUB" else 1
        if len(args) < 2:
            raise UnsupportedFunction(f"{name} with a single argument")
        second = args[1]
        if isinstance(second, Interval):
            if not isinstance(second.amount, Lit):
                raise UnsupportedFunction(f"{name} with a non-literal interval")
            n_units, unit = sign * int(second.amount.value), second.unit
            if unit in ("MONTH", "MONTHS"):
                return f"add_months({base}, {n_units})"
            if unit in ("YEAR", "YEARS"):
                return f"add_months({base}, {n_units * 12})"
            if unit in ("DAY", "DAYS"):
                return f"date_add({base}, {n_units})"
            if unit in ("WEEK", "WEEKS"):
                return f"date_add({base}, {n_units * 7})"
            raise UnsupportedFunction(f"{name} INTERVAL unit {unit}")
        days = self._emit(second, o)
        return f"date_sub({base}, {days})" if sign < 0 else f"date_add({base}, {days})"


#: dialects available to callers. ``translate(..., dialect="sql")`` picks one.
EMITTERS = {"pyspark": PySparkEmitter, "sql": SqlEmitter}


def translate(expression: str, *, emitter: Any | None = None,
              dialect: str = "pyspark") -> Emitted:
    """Parse and emit one DOMO expression in the requested dialect.

    Never partially succeeds: either the whole expression translates, or the result
    carries what was unsupported so the caller can escalate exactly that fragment.
    """
    src = (expression or "").strip()
    empty = "NULL" if dialect == "sql" else "F.lit(None)"
    if not src:
        return Emitted(code=empty, notes=["empty expression"])
    if emitter is None:
        if dialect not in EMITTERS:
            raise ValueError(f"unknown dialect {dialect!r}; expected one of {sorted(EMITTERS)}")
        emitter = EMITTERS[dialect]()
    out = Emitted(code="")
    try:
        ast = parse(src)
    except DomoParseError as exc:
        out.unsupported.append(f"parse error: {exc}")
        out.code = ""
        return out
    try:
        out.code = emitter._emit(ast, out)
    except UnsupportedFunction as exc:
        out.unsupported.append(str(exc))
        out.code = ""
    return out


def detect_functions(expression: str) -> set[str]:
    """Function names used, for the plan's function-reference section. Tolerant: a
    formula that will not parse still reports the names it mentions."""
    try:
        out = translate(expression)
        if out.functions_used:
            return out.functions_used
    except Exception:
        pass
    return {m.group(1).upper() for m in re.finditer(r"([A-Za-z_]\w*)\s*\(", expression or "")}
