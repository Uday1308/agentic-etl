"""agents.md_plan.render — build the plan document (intent, not code).

The plan is what a human approves, so it is written to be read: intent, the DOMO
expression next to its translation, the confidence and the semantic caveat, and a risk
register naming the things that will silently go wrong after migration.

Section layout is stable because the downstream extractor parses it:

    1 Pipeline Overview        6 Output / Write Instructions
    2 Source Tables            7 DOMO -> PySpark Function Reference
    3 Execution DAG            8 Review Checklist
    4 DataFrame Variable Map   9 Coverage Report
    5 Transformation Plan

Section 5 carries **intent, not code**: per-step semantics, the DOMO expression next
to its proposed SQL, the confidence, and the semantic caveats. Approving a plan means
approving those semantics. CD Codegen then generates the artifact from this plan plus
the discovery table — it does not extract code from here, because there is none.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from core.common.naming import column as _sanitize

if TYPE_CHECKING:
    from core.domo.tiles import RenderResult, TileRegistry


def _pack(pack: Any = None) -> Any:
    """The source pack the plan is rendered for; DOMO when none is given (ADR 032 §1:
    no module-level DOMO pin here, the vocabulary and registry come from the pack)."""
    if pack is not None:
        return pack
    from core.packs import default_pack

    return default_pack()

FUNC_REFERENCE = {
    "CASE WHEN": "CASE WHEN cond THEN v ... ELSE default END",
    "CONCAT": "concat(a, b)",
    "IFNULL": "coalesce(x, default)",
    "LAST_DAY": "last_day(x)",
    "MONTH": "month(x)",
    "YEAR": "year(x)",
    "MONTHNAME": "date_format(x, 'MMMM')",
    "DAY": "dayofmonth(x)",
    "LEFT": "left(cast(x AS STRING), n)",
    "DATE_SUB": "add_months(x, -n) / date_sub(x, n)",
    "DATE": "to_date(x, 'yyyy-MM-dd')",
    "REPLACE": "replace(x, from, to)",
    "ROUND": "round(x, scale)",
    "UPPER": "upper(x)",
    "LOWER": "lower(x)",
    "TRIM": "trim(x)",
}


def snake(name: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", name or "").strip("_").lower()
    return re.sub(r"_+", "_", s) or "unnamed"


def resolve_dynamic_columns(nodes: list[dict], edges: list[dict], *, pack: Any = None) -> list[dict]:
    """Fill in the column set a dynamic unpivot needs, by tracing the graph.

    DOMO's dynamic unpivot decides its value columns at run time: everything that is
    not an ``idField``. SQL has to state them, which is why the tile escalates. But the
    set is not unknowable — it is (the upstream tile's output columns) minus
    (idFields), and most tiles' output columns can be derived from their input's, back
    to a tile that states them outright. No engine, no model, no guess.

    Doing this here rather than in the renderer means the PLAN shows the resolved
    unpivot too, so a human reviews real semantics instead of an escalation notice.

    Where the trace bottoms out at a SOURCE the answer is genuinely unavailable — only
    the table itself knows its columns — and the tile is left to escalate, to the
    schema probe or the AI tail. Guessing there would produce wrong data with no
    symptom, which is strictly worse than escalating.
    """
    voc = _pack(pack).vocabulary
    op_of, output_columns = voc.op_of, voc.output_columns
    by_id = {str(n.get("id")): n for n in nodes}
    inputs: dict[str, list[str]] = {}
    for e in edges or []:
        inputs.setdefault(str(e.get("to")), []).append(str(e.get("from")))

    memo: dict[str, list[str] | None] = {}

    def columns_of(nid: str, stack: frozenset[str] = frozenset()) -> list[str] | None:
        if nid in memo:
            return memo[nid]
        if nid in stack or nid not in by_id:      # a cycle, or a node we do not have
            return None
        node = by_id[nid]
        ups = [columns_of(u, stack | {nid}) for u in inputs.get(nid, [])]
        result = output_columns(node, ups)
        memo[nid] = result
        return result

    out: list[dict] = []
    for n in nodes:
        node = n
        op = op_of(n)

        if op in voc.schema_aware_ops:
            # Some tiles cannot be rendered correctly from their configuration alone.
            # An append needs every branch's columns to project them onto one shape
            # (UNION ALL matches by position, DOMO by name). A formula needs its input's
            # columns to tell "add a column" from "replace a column" — DOMO writes both
            # identically, and guessing wrong yields a duplicate name.
            ups = inputs.get(str(n.get("id"))) or []
            per_input = [columns_of(u) for u in ups]
            if ups and all(per_input):
                p = n.get("properties") or {}
                if not p.get("input_columns"):
                    node = {**n, "properties": {**p, "input_columns": per_input}}
            out.append(node)
            continue

        if op in voc.dynamic_column_ops:
            p = n.get("properties") or {}
            if not (p.get("value_columns") or p.get("valueColumns")):
                ups = inputs.get(str(n.get("id"))) or []
                upstream = columns_of(ups[0]) if ups else None
                if upstream:
                    ids = {_sanitize(c) for c in
                           (p.get("idFields") or p.get("id_columns") or p.get("keep") or [])}
                    values = [c for c in upstream if _sanitize(c) not in ids]
                    if values:
                        node = {**n, "properties": {**p, "value_columns": values}}
        out.append(node)
    return out


@dataclass
class Step:
    """One transformation, ready to render."""
    index: int
    node_id: str
    name: str
    node_type: str
    df_var: str
    inputs: list[str]
    result: "RenderResult"

    @property
    def step_id(self) -> str:
        return f"s{self.index:02d}"


@dataclass
class PlanBuild:
    """Everything the renderer produced, plus the coverage the report needs."""
    document: str = ""
    steps: list[Step] = field(default_factory=list)
    sources: list[dict] = field(default_factory=list)
    targets: list[dict] = field(default_factory=list)
    unresolved: list[dict] = field(default_factory=list)   # what must escalate to a model

    @property
    def resolved_count(self) -> int:
        return sum(1 for s in self.steps if s.result.resolved)

    @property
    def coverage_pct(self) -> float:
        return (self.resolved_count / len(self.steps) * 100) if self.steps else 100.0


class PlanRenderer:
    """Turns a standardized dataflow into the plan document. Fully deterministic."""

    def __init__(self, registry: "TileRegistry | None" = None, *, dialect: str = "sql",
                 pack: Any = None,
                 target_catalog: str = "dev_test", target_schema: str = "migrated_output",
                 source_catalog: str = "dev_test", source_schema: str = "domo_input") -> None:
        self._pack = _pack(pack)
        self._tiles = registry or self._pack.registry(dialect)
        self._dialect = dialect
        self._tc, self._ts = target_catalog, target_schema
        self._sc, self._ss = source_catalog, source_schema

    # -- graph ------------------------------------------------------------ #
    @staticmethod
    def _topo(nodes: list[dict], edges: list[dict]) -> list[dict]:
        """Deterministic topological order. Ties break on node id so two runs of the
        same dataflow produce byte-identical plans."""
        by_id = {str(n.get("id")): n for n in nodes}
        incoming: dict[str, set[str]] = {k: set() for k in by_id}
        for e in edges:
            src, dst = str(e.get("from")), str(e.get("to"))
            if dst in incoming and src in by_id:
                incoming[dst].add(src)
        ordered, ready = [], sorted(k for k, v in incoming.items() if not v)
        seen: set[str] = set()
        while ready:
            nid = ready.pop(0)
            if nid in seen:
                continue
            seen.add(nid)
            ordered.append(by_id[nid])
            newly = []
            for other, deps in incoming.items():
                if other not in seen and nid in deps:
                    deps.discard(nid)
                    if not deps:
                        newly.append(other)
            ready = sorted(set(ready) | set(newly))
        if len(ordered) != len(by_id):
            missing = sorted(set(by_id) - seen)
            raise ValueError(f"dataflow has a cycle or dangling nodes: {missing[:6]}")
        return ordered

    @staticmethod
    def _category(node: dict) -> str:
        cat = (node.get("category") or "").upper()
        if cat in ("SOURCE", "TARGET", "TRANSFORMATION"):
            return cat
        t = (node.get("type") or node.get("operation_type") or "").upper()
        if t in ("DATASET", "DATA", "SOURCE", "INPUT", "DATASOURCE"):
            return "SOURCE"
        # DOMO's discovery export writes 'sink' for outputs
        if t in ("TARGET", "OUTPUT", "WRITE", "PUBLISH", "SINK"):
            return "TARGET"
        return "TRANSFORMATION"

    # -- build ------------------------------------------------------------ #
    def build(self, standardized: dict, raw: dict | None = None, *,
              dataflow_id: str = "", dataflow_name: str = "") -> PlanBuild:
        nodes = list(standardized.get("nodes", []) or [])
        edges = list(standardized.get("edges", standardized.get("connections", [])) or [])
        # Recover column sets DOMO resolves at run time, before anything renders.
        nodes = resolve_dynamic_columns(nodes, edges)
        raw_by_id = {str(n.get("id")): n for n in (raw or {}).get("nodes", []) or []}

        # merge raw tile detail into the standardized node — the raw export carries
        # properties the standardizer normalizes away
        merged = []
        for n in nodes:
            nid = str(n.get("id"))
            r = raw_by_id.get(nid, {})
            props = {**(r.get("properties") or {}), **(n.get("properties") or {})}
            merged.append({**r, **n, "id": nid, "properties": props})

        ordered = self._topo(merged, edges)
        inputs_of: dict[str, list[str]] = {}
        for e in edges:
            inputs_of.setdefault(str(e.get("to")), []).append(str(e.get("from")))

        build = PlanBuild()
        var_of: dict[str, str] = {}
        step_no = 0

        for node in ordered:
            nid = str(node.get("id"))
            cat = self._category(node)
            name = node.get("name") or node.get("dataset_name") or nid
            if cat == "SOURCE":
                sp = node.get("properties") or {}
                ds = sp.get("dataset_name") or sp.get("datasetName") or name
                var = f"{snake(ds)}_df"
                var_of[nid] = var
                build.sources.append({
                    "df_var": var, "dataset_name": ds, "node_id": nid,
                    "dataset_id": sp.get("dataSourceId", ""),
                    "table": f"{self._sc}.{self._ss}.{snake(ds)}",
                })
                continue
            if cat == "TARGET":
                ins = [var_of.get(i, "df_final") for i in inputs_of.get(nid, [])]
                p = node.get("properties") or {}
                ds = p.get("dataset_name") or p.get("datasetName") or name
                build.targets.append({
                    "target": ds, "node_id": nid,
                    "source_df": ins[0] if ins else "df_final",
                    "mode": "overwrite" if "REPLACE" in str(p.get("write_mode", "REPLACE")).upper()
                            else "append",
                    "table": f"{self._tc}.{self._ts}.{snake(ds)}",
                })
                continue

            step_no += 1
            ins = [var_of.get(i, f"df_missing_{i}") for i in inputs_of.get(nid, [])]
            df_var = f"df_{snake(name)}_s{step_no:02d}"
            var_of[nid] = df_var
            result = self._tiles.render(node, ins, df_var)
            step = Step(index=step_no, node_id=nid, name=name,
                        node_type=(node.get("type") or node.get("operation_type") or "").upper(),
                        df_var=df_var, inputs=ins, result=result)
            build.steps.append(step)
            if not result.resolved:
                build.unresolved.append({
                    "step": step.step_id, "node_id": nid, "name": name,
                    "df_var": df_var, "inputs": ins,
                    "reasons": list(result.unresolved),
                    "node": node,
                })

        build.document = self._render(build, dataflow_id, dataflow_name)
        return build

    # -- document --------------------------------------------------------- #
    def _render(self, b: PlanBuild, dataflow_id: str, dataflow_name: str) -> str:
        out: list[str] = [
            f"# ETL Migration: {dataflow_name or 'dataflow'} — DataFlow {dataflow_id}",
            "",
            "## 1. Pipeline Overview",
            "",
            self._overview(b, dataflow_name, dataflow_id),
            "",
            "## 2. Source Tables",
            "",
            "| df_var | Dataset Name | Dataset ID |",
            "|---|---|---|",
        ]
        for s in b.sources:
            out.append(f"| `{s['df_var']}` | `{s['dataset_name']}` | `{s['dataset_id']}` |")

        out += ["", "## 3. Execution DAG", "", "```"]
        for step in b.steps:
            for i in step.inputs:
                out.append(f"{i}  ->  {step.df_var}  ({step.name})")
        for t in b.targets:
            # The destination table, not the literal string "None". Every write in
            # the DAG used to render as `-> None`, so the one section that shows a
            # reader where the data ENDS UP named none of the six places it goes.
            out.append(f"{t['source_df']}  ->  {t['table']}  ({t['target']})")
        out += ["```", "", "## 4. DataFrame Variable Map", "",
                "| Step | df_var | Node Name | Type |", "|---|---|---|---|"]
        for s in b.sources:
            out.append(f"| `src` | `{s['df_var']}` | `{s['dataset_name']}` | `source` |")
        for step in b.steps:
            out.append(f"| `{step.step_id}` | `{step.df_var}` | `{step.name}` | "
                       f"`{step.node_type.lower()}` |")
        for t in b.targets:
            out.append(f"| `sink` | `-` | `{t['target']}` | `sink` |")

        out += ["", "## 5. Transformation Plan", "",
                "One entry per DOMO tile, in execution order. This section states *what each",
                "step must do and how it will be translated* — it deliberately contains no",
                "generated code. Approving a plan means approving these semantics; the",
                "artifact is produced by CD Codegen from this plan plus the discovery table.",
                ""]
        for step in b.steps:
            r = step.result
            ins = ", ".join(f"`{i}`" for i in step.inputs) or "*(no inputs)*"
            out.append(f"### Step {step.step_id} | `{step.name}` | `{step.node_type}`")
            out.append(f"- **In:** {ins} | **Out:** `{step.df_var}` | "
                       f"**Confidence:** `{r.confidence}`")
            out.append(f"- **Translation:** "
                       f"{'deterministic' if r.resolved else 'needs a model'}")
            if r.confidence == "LOW":
                out.append("- ⚠ Verify this step carefully before approving")
            elif r.confidence == "MEDIUM":
                out.append("- ⚠ Review the caveats below")
            out.append("")
            if not r.resolved:
                out.append("**Cannot be translated from the tile vocabulary.** A model must "
                           "resolve it, guided by this plan.")
                out.append("")
                for reason in r.unresolved:
                    out.append(f"- unresolved: {reason}")
                out.append(f"- inputs available as: {', '.join(step.inputs) or '(none)'}")
                out.append(f"- the result must be addressable as `{step.df_var}`")
                out.append("")
            if r.expressions:
                out += ["**Column mappings:**", "",
                        "| Output Column | DOMO Expression | Proposed SQL | Confidence | Source |",
                        "|---|---|---|---|---|"]
                for e in r.expressions:
                    domo = " ".join(str(e["domo"]).split())
                    sql = " ".join(str(e.get("sql") or e.get("pyspark") or "").split())
                    out.append(f"| `{e['column']}` | `{domo}` | `{sql}` | "
                               f"`{e['confidence']}` | `{e['source']}` |")
                out.append("")
            if r.join_keys:
                out += ["**Join keys:**", "", "| Left Column | Right Column |", "|---|---|"]
                for k in r.join_keys:
                    out.append(f"| `{k['left']}` | `{k['right']}` |")
                out.append("")
            if r.notes:
                out.append("**Semantic caveats — these are what approval is really about:**")
                out.append("")
                for n in dict.fromkeys(r.notes):
                    out.append(f"- {n}")
                out.append("")

        out += ["## 6. Output Targets", "",
                "| Target | Source Step | Mode | Destination Table |", "|---|---|---|---|"]
        for t in b.targets:
            out.append(f"| `{t['target']}` | `{t['source_df']}` | `{t['mode']}` | "
                       f"`{t['table']}` |")
        out += ["",
                "Materialization is a human decision: CD Codegen emits a plain SELECT per",
                "target so it can be run and checked before anyone adds a",
                "`CREATE OR REPLACE TABLE` prefix.", ""]

        used: set[str] = set()
        for step in b.steps:
            used |= step.result.functions_used
            for e in step.result.expressions:
                used |= self._pack.expressions.detect_functions(str(e.get("domo", "")))
        out += ["## 7. DOMO -> SQL Function Reference", "",
                "| DOMO Function | PySpark Equivalent |", "|---|---|"]
        for f in sorted(used):
            if f in FUNC_REFERENCE:
                out.append(f"| `{f}` | `{FUNC_REFERENCE[f]}` |")

        out += ["", "## 8. Review Checklist", ""]
        flagged = [s for s in b.steps if s.result.confidence in ("LOW", "MEDIUM")]
        if not flagged:
            out.append("_No steps flagged._")
        for s in flagged:
            reason = "; ".join(dict.fromkeys(s.result.notes)) or "review translation"
            out.append(f"- [ ] **{s.name}** (`{s.df_var}`) — `{s.result.confidence}` — {reason}")

        out += ["", "## 9. Python vs. LLM Coverage Report", "",
                f"**{b.resolved_count}/{len(b.steps)} transformations resolved "
                f"deterministically ({b.coverage_pct:.1f}%)**", "",
                "| Operation Type | Ratio |", "|---|---|"]
        by_type: dict[str, list[int]] = {}
        for s in b.steps:
            e = by_type.setdefault(s.node_type.lower() or "unknown", [0, 0])
            e[1] += 1
            if s.result.resolved:
                e[0] += 1
        for t, (ok, total) in sorted(by_type.items()):
            out.append(f"| `{t}` | {ok}/{total} deterministic |")
        return "\n".join(out) + "\n"

    @staticmethod
    def _overview(b: PlanBuild, name: str, dataflow_id: str) -> str:
        risks: list[str] = []
        if any("order-dependent" in n for s in b.steps for n in s.result.notes):
            risks.append("order-dependent aggregations whose result is not stable across runs")
        if any("precision pinned" in n for s in b.steps for n in s.result.notes):
            risks.append("decimal columns whose precision DOMO did not state")
        if any("cross join" in n for s in b.steps for n in s.result.notes):
            risks.append("a cross join that silently multiplies rows if cardinality changes")
        if any("allowMissingColumns" in n for s in b.steps for n in s.result.notes):
            risks.append("permissive unions that hide upstream schema drift")
        risk_text = ("Risks to review before approval: " + "; ".join(risks) + "."
                     if risks else "No structural risks were detected.")
        return (
            f"This plan migrates DOMO dataflow {dataflow_id} (`{name}`) to Databricks. "
            f"It reads {len(b.sources)} source dataset(s), applies {len(b.steps)} "
            f"transformation step(s), and writes {len(b.targets)} output table(s). "
            f"{b.resolved_count} of {len(b.steps)} steps were translated deterministically "
            f"from DOMO's own tile vocabulary; the remainder need a model. {risk_text}"
        )
