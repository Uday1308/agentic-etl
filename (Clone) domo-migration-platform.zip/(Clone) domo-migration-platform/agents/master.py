"""The master graph: the seven agents in order, with the estate-level passes named.

Ordering follows the blueprint. Two things are deliberately NOT per-run stages:

* the PORTFOLIO planner (which dataflow migrates before which, and which snapshot
  tables must be re-pointed once their real producer is migrated) — that is an
  estate-level pass above this graph;
* MEDALLION classification, which can only be settled once the estate is known.
  The Classifier stage here does the per-dataflow split; the estate-wide assignment
  happens at promotion.

Each stage is injected, so a caller can run a subset (a single agent, or discovery
through codegen) without rebuilding the graph.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

AGENT_ORDER = (
    "connection",
    "standardization",
    "discovery",
    "md_plan",
    "cd_codegen",
    "validation",
    "classifier",
)

#: Per blueprint §2 — which agents use a model, which get an LLM review, and where a
#: human is asked. Defaults only: a run's config overrides them per agent.
AGENT_DEFAULTS: dict[str, dict[str, bool]] = {
    "connection":      {"ai_gen": False, "ai_review": False, "hitl": False},
    "standardization": {"ai_gen": True,  "ai_review": True,  "hitl": False},
    "discovery":       {"ai_gen": False, "ai_review": False, "hitl": True},
    "md_plan":         {"ai_gen": True,  "ai_review": True,  "hitl": True},
    "cd_codegen":      {"ai_gen": True,  "ai_review": True,  "hitl": True},
    "validation":      {"ai_gen": True,  "ai_review": True,  "hitl": True},
    "classifier":      {"ai_gen": True,  "ai_review": True,  "hitl": True},
}


@dataclass
class Stage:
    """One agent's place in the pipeline."""
    agent: str
    runner: Any                      # a Runner, or a compiled subgraph
    ai_gen: bool = False
    ai_review: bool = False
    hitl: bool = False

    @property
    def phases(self) -> tuple[str, ...]:
        return AGENT_PHASES.get(self.agent, ())


#: The phase vocabulary each agent reports as it works. The UI renders these
#: verbatim — it never invents or guesses what an agent is doing.
AGENT_PHASES: dict[str, tuple[str, ...]] = {
    "connection": ("Authenticating", "Listing datasets", "Caching metadata"),
    "standardization": ("Reading raw artifacts", "Normalizing schema", "Deduplicating revisions"),
    "discovery": ("Understanding dataflow", "Extracting nodes", "Resolving lineage",
                  "Writing discovery table"),
    "md_plan": ("Understanding tiles", "Context engineering", "Translating expressions",
                "Rendering plan", "Evaluating"),
    "cd_codegen": ("Reading approved plan", "Extracting code", "Context engineering",
                   "Assembling notebook", "Evaluating"),
    "validation": ("Submitting job", "Waiting for the pipeline", "Running row parity",
                   "Comparing schemas", "Diagnosing"),
    "classifier": ("Reading node sections", "Classifying layers", "Splitting code",
                   "Launching pipelines"),
}


class MasterPipeline:
    """Holds the ordered stages. Sequential by construction: a stage only starts once
    the previous one is approved, which is what makes the HITL gates meaningful."""

    def __init__(self, stages: list[Stage]) -> None:
        order = {a: i for i, a in enumerate(AGENT_ORDER)}
        unknown = [s.agent for s in stages if s.agent not in order]
        if unknown:
            raise ValueError(f"unknown agents: {unknown}")
        self.stages = sorted(stages, key=lambda s: order[s.agent])

    def stage(self, agent: str) -> Stage | None:
        return next((s for s in self.stages if s.agent == agent), None)

    @property
    def hitl_gates(self) -> list[str]:
        return [s.agent for s in self.stages if s.hitl]

    def next_after(self, agent: str) -> Stage | None:
        names = [s.agent for s in self.stages]
        if agent not in names:
            return None
        i = names.index(agent)
        return self.stages[i + 1] if i + 1 < len(self.stages) else None

    def describe(self) -> list[dict]:
        return [{"agent": s.agent, "ai_gen": s.ai_gen, "ai_review": s.ai_review,
                 "hitl": s.hitl, "phases": list(s.phases)} for s in self.stages]
