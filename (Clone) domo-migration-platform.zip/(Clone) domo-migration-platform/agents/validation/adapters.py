"""Real adapters for the Validation agent. Spark and the SDK are imported lazily so
this module stays importable (and unit-testable) without a cluster.
"""
from __future__ import annotations

import time
from typing import Any

from agents.validation.ports import JobRunner, ResultStore, TableReader


class SparkTableReader(TableReader):
    """Measures a Delta/Unity table.

    ``checksum`` is an order-independent multiset hash: these DOMO feeds have no
    primary keys (``C``, ``C2``..``C8``, ``column_59``), so rows cannot be joined
    one-to-one. Hashing each row and summing the hashes compares the two tables as
    multisets, which is the only sound option without keys.

    Values are normalized before hashing — trailing whitespace stripped and decimals
    rounded to ``scale`` — because otherwise the DecimalType(10,0) truncation issue
    and stray spaces generate a flood of false diffs.
    """

    def __init__(self, spark: Any, *, decimal_scale: int = 2) -> None:
        self._spark = spark
        self._scale = decimal_scale

    def _df(self, table: str):
        return self._spark.table(table)

    def row_count(self, table: str) -> int:
        return self._df(table).count()

    def schema(self, table: str) -> dict[str, str]:
        return {f.name: f.dataType.simpleString() for f in self._df(table).schema.fields}

    def _normalized(self, table: str):
        from pyspark.sql import functions as F
        from pyspark.sql.types import DecimalType, DoubleType, FloatType, StringType

        df = self._df(table)
        cols = []
        for f in df.schema.fields:
            c = F.col(f"`{f.name}`")
            if isinstance(f.dataType, StringType):
                c = F.trim(c)
            elif isinstance(f.dataType, (DecimalType, DoubleType, FloatType)):
                c = F.round(c.cast("double"), self._scale)
            cols.append(c.cast("string").alias(f.name))
        return df.select(*cols)

    def checksum(self, table: str) -> str:
        from pyspark.sql import functions as F

        df = self._normalized(table)
        row_hash = F.xxhash64(F.concat_ws("\u0001", *[F.coalesce(F.col(f"`{c}`"), F.lit("\u0000"))
                                                      for c in df.columns]))
        agg = df.select(row_hash.alias("h")).agg(
            F.sum(F.col("h").cast("decimal(38,0)")).alias("s"), F.count("*").alias("n")).first()
        return f"{agg['s']}:{agg['n']}"

    def column_stats(self, table: str, column: str) -> dict[str, Any]:
        from pyspark.sql import functions as F
        from pyspark.sql.types import (
            DecimalType,
            DoubleType,
            FloatType,
            IntegerType,
            LongType,
            StringType,
        )

        df = self._df(table)
        field = next((f for f in df.schema.fields if f.name == column), None)
        if field is None:
            return {}
        col = F.col(f"`{column}`")
        aggs = [F.sum(F.when(col.isNull(), 1).otherwise(0)).alias("null_count"),
                F.countDistinct(col).alias("distinct_count")]

        numeric = isinstance(field.dataType, (DecimalType, DoubleType, FloatType,
                                              IntegerType, LongType))
        if numeric:
            aggs += [F.round(F.sum(col.cast("double")), self._scale).alias("sum"),
                     F.min(col).alias("min"), F.max(col).alias("max")]
        elif isinstance(field.dataType, StringType):
            # A DOMO money column very often arrives as text, sometimes with DOMO's
            # leading-apostrophe export artifact ("'-92866.56"). Skipping it because the
            # declared type is STRING means the statistical profile silently omits the
            # columns it exists to check - the amounts. Profile it as a number anyway.
            #
            # try_cast, not cast: a genuinely non-numeric column yields nulls instead of
            # failing the whole comparison, and `unparsed` says how many values did not
            # convert - which is itself worth seeing on a column that should be money.
            n = F.try_cast(F.regexp_replace(col, "^'", ""), "double")
            aggs += [F.round(F.sum(n), self._scale).alias("sum"),
                     F.min(n).alias("min"), F.max(n).alias("max"),
                     F.sum(F.when(col.isNotNull() & n.isNull(), 1)
                            .otherwise(0)).alias("unparsed")]

        row = df.agg(*aggs).first().asDict()
        return {k: (float(v) if k in ("sum",) and v is not None else v) for k, v in row.items()}


class DatabricksJobRunner(JobRunner):
    """Creates a one-off Job from the generated notebook, launches it, and polls to
    completion. The node blocks here; the Job owns Spark.

    Submission is guarded by ``(dataflow_id, iteration)``: a re-run reuses the existing
    handle rather than launching the pipeline twice.
    """

    TERMINAL = {"TERMINATED", "SKIPPED", "INTERNAL_ERROR", "SUCCESS", "FAILED", "CANCELED"}

    def __init__(self, workspace_client: Any = None, *, cluster_spec: dict | None = None,
                 poll_s: int = 10) -> None:
        self._w = workspace_client
        self._cluster = cluster_spec or {}
        self._poll = poll_s
        self._handles: dict[tuple[str, int], str] = {}

    def _client(self):
        if self._w is None:
            from databricks.sdk import WorkspaceClient
            self._w = WorkspaceClient()
        return self._w

    def submit(self, dataflow_id: str, iteration: int, artifact_path: str) -> str:
        key = (dataflow_id, int(iteration))
        if key in self._handles:
            return self._handles[key]                 # guarded: never double-runs
        from databricks.sdk.service import jobs as j

        run = self._client().jobs.submit(
            run_name=f"validate_{dataflow_id}_v{iteration}",
            tasks=[j.SubmitTask(
                task_key="run_migrated",
                notebook_task=j.NotebookTask(notebook_path=artifact_path),
                **({"new_cluster": j.ClusterSpec(**self._cluster)} if self._cluster else {}),
            )],
        )
        handle = str(run.run_id)
        self._handles[key] = handle
        return handle

    def wait(self, handle: str, *, timeout_s: int = 3600) -> dict[str, Any]:
        deadline = time.time() + timeout_s
        client = self._client()
        while time.time() < deadline:
            run = client.jobs.get_run(run_id=int(handle))
            state = run.state
            life = getattr(state.life_cycle_state, "value", str(state.life_cycle_state))
            if life in self.TERMINAL or getattr(state, "result_state", None) is not None:
                result = getattr(state.result_state, "value", str(state.result_state or ""))
                return {"state": result or life, "life_cycle": life,
                        "error": getattr(state, "state_message", "") or "", "handle": handle}
            time.sleep(self._poll)
        return {"state": "TIMEOUT", "life_cycle": "RUNNING",
                "error": f"did not finish within {timeout_s}s", "handle": handle}


class DeltaResultStore(ResultStore):
    """Overwrites the results for one (dataflow_id, iteration)."""

    def __init__(self, spark: Any, table: str) -> None:
        self._spark = spark
        self._table = table

    def write(self, dataflow_id: str, iteration: int, report: Any) -> str:
        rows = [{
            "dataflow_id": dataflow_id, "iteration": int(iteration),
            "target": t.target, "table": t.table,
            "checks_run": len(t.ran),
            "checks_passed": sum(1 for c in t.ran if not c.failed),
            "blocking_failures": len(t.blocking_failures),
            "exact": t.exact, "passed": t.passed,
        } for t in report.parity.targets]
        if not rows:
            rows = [{"dataflow_id": dataflow_id, "iteration": int(iteration), "target": "",
                     "table": "", "checks_run": 0, "checks_passed": 0,
                     "blocking_failures": 0, "exact": False, "passed": False}]
        df = self._spark.createDataFrame(rows)
        (df.write.format("delta").mode("overwrite")
           .option("replaceWhere", f"dataflow_id = '{dataflow_id}' AND iteration = {int(iteration)}")
           .saveAsTable(self._table))
        return f"{self._table}/{dataflow_id}/{iteration}"
