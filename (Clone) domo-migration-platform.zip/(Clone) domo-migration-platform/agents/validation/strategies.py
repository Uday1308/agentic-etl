"""Validation agent (6). Execute via a Job, compare against DOMO, then diagnose.

Row count alone is not validation — equal counts with wrong values is the failure
that matters in a reconciliation pipeline. Every target gets schema, row count,
per-column aggregates and an order-independent checksum, and the accuracy arithmetic
lives in core.contracts.validation so the dashboard and the client report cannot
drift apart.

On failure the LLM produces a DIAGNOSIS with a category, because each category routes
to a different owner: an expression bug goes back to md_plan, an assembly bug to
cd_codegen, an ingestion mismatch upstream of both.
"""
from __future__ import annotations

from agents.validation.ports import JobRunner, ResultStore, TableReader
from core.contracts.validation import (
    BatchRef,
    DataflowParity,
    Diagnosis,
    FailureCategory,
    Metric,
    TargetParity,
    ValidationReport,
    compare,
)
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.prompts import PromptLayers
from core.domo.schemas import EvalResult, GenResult, Verdict

AGENT = "validation"

#: sum/min/max drift in the last bits is legitimate float accumulation order.
NUMERIC_TOLERANCE = 1e-9


def _cfg(config) -> dict:
    return (config or {}).get("configurable", {}) if isinstance(config, dict) else {}


class ParityChecker:
    """Pure comparison logic. No Spark, no LLM — fully unit-testable."""

    def __init__(self, reader: TableReader, *, tolerance: float = NUMERIC_TOLERANCE) -> None:
        self._r = reader
        self._tol = tolerance

    def compare_target(self, target: str, expected_table: str, actual_table: str,
                       *, expected_ref: BatchRef | None = None,
                       inputs: tuple[BatchRef, ...] = ()) -> TargetParity:
        checks = []
        try:
            exp_schema = self._r.schema(expected_table)
            act_schema = self._r.schema(actual_table)
            checks.append(compare(Metric.SCHEMA, sorted(exp_schema), sorted(act_schema)))
            checks.append(compare(Metric.ROW_COUNT, self._r.row_count(expected_table),
                                  self._r.row_count(actual_table)))
            checks.append(compare(Metric.CHECKSUM, self._r.checksum(expected_table),
                                  self._r.checksum(actual_table)))
            for col in sorted(set(exp_schema) & set(act_schema)):
                e = self._r.column_stats(expected_table, col)
                a = self._r.column_stats(actual_table, col)
                checks.append(compare(Metric.NULL_COUNT, e.get("null_count"),
                                      a.get("null_count"), column=col))
                checks.append(compare(Metric.DISTINCT_COUNT, e.get("distinct_count"),
                                      a.get("distinct_count"), column=col))
                if e.get("sum") is not None:
                    checks.append(compare(Metric.SUM, e.get("sum"), a.get("sum"),
                                          column=col, tolerance=self._tol))
        except Exception as exc:
            return TargetParity(target=target, table=actual_table,
                                error=f"{type(exc).__name__}: {exc}")
        return TargetParity(target=target, table=actual_table, checks=tuple(checks),
                            expected_ref=expected_ref, inputs=inputs)


class ValidationRunner:
    def __init__(self, jobs: JobRunner, checker: ParityChecker, store: ResultStore,
                 llm: LLMClient | None = None, *, ai_troubleshoot: bool = True) -> None:
        self._jobs = jobs
        self._checker = checker
        self._store = store
        self._llm = llm
        self._ai = ai_troubleshoot

    async def run(self, state, config=None) -> ValidationReport:
        c = _cfg(config)
        dataflow_id = state.get("dataflow_id") or c.get("dataflow_id")
        iteration = int(c.get("iteration", 1) or 1)
        gen = (state.get("cd_codegen") or {}).get("gen") or {}
        artifact_path = gen.get("meta", {}).get("artifact_path") or gen.get("artifact_path", "")

        # Jobs-as-a-tool: block until the entire pipeline has finished.
        handle = self._jobs.submit(dataflow_id, iteration, artifact_path)
        terminal = self._jobs.wait(handle)
        if terminal.get("state") not in ("SUCCESS", "TERMINATED", "COMPLETED"):
            report = ValidationReport(
                parity=DataflowParity(dataflow_id=dataflow_id, targets=()),
                diagnoses=(Diagnosis(
                    category=FailureCategory.ASSEMBLY, owner_agent="cd_codegen",
                    explanation=f"job did not complete: {terminal.get('state')} "
                                f"{terminal.get('error', '')}".strip(), confidence=0.9),))
            self._store.write(dataflow_id, iteration, report)
            return report

        targets = tuple(
            self._checker.compare_target(t["target"], t["expected_table"], t["actual_table"],
                                         expected_ref=t.get("expected_ref"))
            for t in (state.get("targets") or [])
        )
        parity = DataflowParity(dataflow_id=dataflow_id,
                                dataflow_name=state.get("dataflow_name", ""),
                                run_id=c.get("obs_run_id", ""), targets=targets)

        diagnoses: tuple[Diagnosis, ...] = ()
        if not parity.passed and self._ai and self._llm is not None:
            diagnoses = await self._diagnose(parity, config)

        self._store.write(dataflow_id, iteration, ValidationReport(parity=parity,
                                                                   diagnoses=diagnoses))
        return ValidationReport(parity=parity, diagnoses=diagnoses)

    async def _diagnose(self, parity: DataflowParity, config) -> tuple[Diagnosis, ...]:
        failing = [t for t in parity.targets if not t.passed]
        detail = "\n".join(
            f"{t.target}: " + ", ".join(
                f"{c.metric.value}{'/' + c.column if c.column else ''} expected={c.expected} actual={c.actual}"
                for c in t.blocking_failures)
            for t in failing)
        # TEAMMATE-OWNED: the real prompt carries the plan, the code and the failure
        # context so the explanation can point at specific steps.
        await self._llm.complete(
            Role.EVALUATOR,
            PromptLayers(base="Diagnose these parity failures. Name the category "
                              "(ingestion/expression/composition/assembly/incremental/"
                              f"source_drift/nondeterminism) and the nodes.\n{detail}"),
            pool="evaluation", config=config)
        return tuple(
            Diagnosis(category=FailureCategory.UNKNOWN, owner_agent="",
                      nodes=(t.target,), explanation="needs triage", confidence=0.0)
            for t in failing)


class ValidationEvaluator:
    """Wraps the parity outcome as an EvalResult so the HITL gate is the same shape
    as every other agent's."""

    async def evaluate(self, gen: GenResult, state, config=None) -> EvalResult:
        report: ValidationReport | None = (state.get(AGENT) or {}).get("report")
        if report is None:
            return EvalResult(verdict=Verdict.FAIL, confidence=1.0,
                              summary="no validation report produced")
        if report.passed:
            return EvalResult(verdict=Verdict.PASS, confidence=1.0,
                              summary=f"{report.parity.targets_exact}/"
                                      f"{len(report.parity.targets)} targets exact")
        return EvalResult(verdict=Verdict.REVISE, confidence=0.8,
                          summary="parity failed; see diagnoses")
