"""Ports for the Validation agent (6). Jobs-as-a-tool: the node owns control flow,
the Job owns Spark."""
from __future__ import annotations

import abc
from typing import Any


class JobRunner(abc.ABC):
    """Creates a Databricks Job from the generated code, launches it, and polls to
    completion. The node BLOCKS until the whole pipeline finishes before validating.

    Launching must be guarded by ``(dataflow_id, iteration)`` so a re-run does not
    double-run the pipeline.
    """

    @abc.abstractmethod
    def submit(self, dataflow_id: str, iteration: int, artifact_path: str) -> str:
        """Return a run handle. Idempotent per (dataflow_id, iteration)."""

    @abc.abstractmethod
    def wait(self, handle: str, *, timeout_s: int = 3600) -> dict[str, Any]:
        """Block until the job terminates. Return its terminal state."""


class TableReader(abc.ABC):
    """Reads measurements off a table. Both sides of every comparison come through
    here so the comparison logic stays pure and testable."""

    @abc.abstractmethod
    def row_count(self, table: str) -> int: ...

    @abc.abstractmethod
    def schema(self, table: str) -> dict[str, str]: ...

    @abc.abstractmethod
    def column_stats(self, table: str, column: str) -> dict[str, Any]:
        """sum / min / max / null_count / distinct_count for one column."""

    @abc.abstractmethod
    def checksum(self, table: str) -> str:
        """Order-independent multiset hash of all rows. No primary keys exist in
        these feeds, so rows cannot be joined one-to-one."""


class ResultStore(abc.ABC):
    """Writes results to Delta keyed by (dataflow_id, iteration); overwrite on re-run."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, iteration: int, report: Any) -> str: ...
