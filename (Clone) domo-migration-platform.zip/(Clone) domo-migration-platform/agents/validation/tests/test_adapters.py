"""Validation adapters. Spark/SDK are faked — these assert wiring and guard logic,
not Spark itself (that belongs in tests/integration/)."""
from __future__ import annotations

from agents.validation.adapters import DatabricksJobRunner


class FakeRun:
    def __init__(self, run_id):
        self.run_id = run_id


class FakeState:
    def __init__(self, life, result=None, msg=""):
        self.life_cycle_state = life
        self.result_state = result
        self.state_message = msg


class FakeJobs:
    def __init__(self, states):
        self._states = list(states)
        self.submits = 0

    def submit(self, **kw):
        self.submits += 1
        return FakeRun(run_id=1234)

    def get_run(self, run_id):
        state = self._states.pop(0) if len(self._states) > 1 else self._states[0]

        class R:
            pass

        r = R()
        r.state = state
        return r


class FakeWorkspace:
    def __init__(self, states):
        self.jobs = FakeJobs(states)


def test_submit_is_guarded_per_dataflow_and_iteration():
    """A re-run must reuse the handle, never launch the pipeline twice."""
    w = FakeWorkspace([FakeState("TERMINATED", "SUCCESS")])
    runner = DatabricksJobRunner(w, poll_s=0)
    a = runner.submit("8099", 1, "/v/etl.py")
    b = runner.submit("8099", 1, "/v/etl.py")
    assert a == b and w.jobs.submits == 1


def test_different_iterations_submit_separately():
    w = FakeWorkspace([FakeState("TERMINATED", "SUCCESS")])
    runner = DatabricksJobRunner(w, poll_s=0)
    runner.submit("8099", 1, "/v/etl.py")
    runner.submit("8099", 2, "/v/etl.py")
    assert w.jobs.submits == 2


def test_wait_blocks_until_a_terminal_state():
    w = FakeWorkspace([FakeState("PENDING"), FakeState("RUNNING"),
                       FakeState("TERMINATED", "SUCCESS")])
    runner = DatabricksJobRunner(w, poll_s=0)
    out = runner.wait(runner.submit("8099", 1, "/v/etl.py"))
    assert out["state"] == "SUCCESS"


def test_wait_reports_failure_message():
    w = FakeWorkspace([FakeState("TERMINATED", "FAILED", "NameError: df_x undefined")])
    runner = DatabricksJobRunner(w, poll_s=0)
    out = runner.wait(runner.submit("8099", 1, "/v/etl.py"))
    assert out["state"] == "FAILED" and "NameError" in out["error"]


def test_wait_times_out_rather_than_hanging():
    w = FakeWorkspace([FakeState("RUNNING")])
    runner = DatabricksJobRunner(w, poll_s=0)
    out = runner.wait(runner.submit("8099", 1, "/v/etl.py"), timeout_s=0)
    assert out["state"] == "TIMEOUT"
