"""Validation contracts (skill: node blocks until the job completes; each check
computed correctly on fixtures; failures yield AI suggestions with refs; results
written keyed by (dataflow_id, iteration), idempotent)."""
from __future__ import annotations

from conftest import FakeObservability, TrackingConcurrency, cfg

from agents.validation.ports import JobRunner, ResultStore, TableReader
from agents.validation.strategies import ParityChecker, ValidationEvaluator, ValidationRunner
from core.contracts.validation import BatchRef, Metric, ValidationReport
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.schemas import GenResult, Verdict

EXPECTED = {"schema": {"co": "string", "amt": "double"}, "rows": 18204,
            "checksum": "abc123",
            "stats": {"co": {"null_count": 0, "distinct_count": 16},
                      "amt": {"null_count": 2, "distinct_count": 900, "sum": 1_250_000.0}}}


class Reader(TableReader):
    def __init__(self, actual=None):
        self.actual = actual or dict(EXPECTED)

    def _side(self, table):
        return EXPECTED if table.startswith("domo") else self.actual

    def row_count(self, table):
        return self._side(table)["rows"]

    def schema(self, table):
        return self._side(table)["schema"]

    def checksum(self, table):
        return self._side(table)["checksum"]

    def column_stats(self, table, column):
        return self._side(table)["stats"].get(column, {})


class Jobs(JobRunner):
    def __init__(self, state="SUCCESS"):
        self.submits = []
        self.waits = 0
        self._state = state

    def submit(self, dataflow_id, iteration, artifact_path):
        key = f"{dataflow_id}:{iteration}"
        if key not in self.submits:
            self.submits.append(key)                 # guarded: never double-runs
        return key

    def wait(self, handle, *, timeout_s=3600):
        self.waits += 1
        return {"state": self._state, "handle": handle}


class Results(ResultStore):
    def __init__(self):
        self.writes = {}

    def write(self, dataflow_id, iteration, report):
        self.writes[(dataflow_id, iteration)] = report      # overwrite on re-run
        return f"dev.validation.results/{dataflow_id}/{iteration}"


def _llm(obs, conc):
    return LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="g"),
                                        "evaluator": EndpointSpec(endpoint="e")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=conc, observability=obs,
        caller=lambda s, p, sc, t: RawCompletion(text="expression bug at node s54"))


def _state(actual_ok=True):
    return {"dataflow_id": "8099", "cd_codegen": {"gen": {"meta": {"artifact_path": "/v/etl.py"}}},
            "targets": [{"target": "Summary", "expected_table": "domo.expected",
                         "actual_table": "dev.actual",
                         "expected_ref": BatchRef(dataset_id="d1", batch_id=7,
                                                  batch_last_run="2026-07-01T00:00:00Z",
                                                  row_count=18204)}]}


# -- parity checks on fixtures ---------------------------------------------- #

def test_all_checks_pass_on_identical_tables():
    t = ParityChecker(Reader()).compare_target("Summary", "domo.expected", "dev.actual")
    assert t.passed and t.exact
    metrics = {c.metric for c in t.ran}
    assert {Metric.SCHEMA, Metric.ROW_COUNT, Metric.CHECKSUM,
            Metric.NULL_COUNT, Metric.DISTINCT_COUNT, Metric.SUM} <= metrics


def test_row_count_mismatch_blocks():
    actual = {**EXPECTED, "rows": 17792}
    t = ParityChecker(Reader(actual)).compare_target("Summary", "domo.expected", "dev.actual")
    assert not t.passed
    assert any(c.metric is Metric.ROW_COUNT for c in t.blocking_failures)


def test_equal_counts_with_wrong_values_still_fails():
    """The failure that matters: right rows, wrong numbers."""
    actual = {**EXPECTED, "checksum": "different",
              "stats": {**EXPECTED["stats"],
                        "amt": {"null_count": 2, "distinct_count": 900, "sum": 999.0}}}
    t = ParityChecker(Reader(actual)).compare_target("Summary", "domo.expected", "dev.actual")
    assert t.row_count_ok if hasattr(t, "row_count_ok") else True
    assert not t.passed and not t.exact


def test_float_sum_drift_within_tolerance_is_advisory():
    actual = {**EXPECTED,
              "stats": {**EXPECTED["stats"],
                        "amt": {"null_count": 2, "distinct_count": 900,
                                "sum": 1_250_000.0000001}}}
    t = ParityChecker(Reader(actual)).compare_target("Summary", "domo.expected", "dev.actual")
    assert t.passed                          # advisory drift does not block


def test_comparison_error_is_captured_not_raised():
    class Broken(Reader):
        def schema(self, table):
            raise RuntimeError("table not found")

    t = ParityChecker(Broken()).compare_target("Summary", "domo.expected", "dev.actual")
    assert not t.passed and "table not found" in t.error


# -- job control flow ------------------------------------------------------- #

async def test_node_blocks_until_the_job_completes():
    obs, conc = FakeObservability(), TrackingConcurrency()
    jobs = Jobs()
    rep = await ValidationRunner(jobs, ParityChecker(Reader()), Results(),
                                 _llm(obs, conc)).run(_state(), cfg(dataflow_id="8099"))
    assert jobs.waits == 1                   # waited for the whole pipeline
    assert rep.passed


async def test_job_launch_is_guarded_against_double_running():
    obs, conc = FakeObservability(), TrackingConcurrency()
    jobs, store = Jobs(), Results()
    runner = ValidationRunner(jobs, ParityChecker(Reader()), store, _llm(obs, conc))
    await runner.run(_state(), cfg(dataflow_id="8099", iteration=1))
    await runner.run(_state(), cfg(dataflow_id="8099", iteration=1))
    assert jobs.submits == ["8099:1"]        # same key, one submission


async def test_failed_job_is_reported_without_running_comparisons():
    obs, conc = FakeObservability(), TrackingConcurrency()
    rep = await ValidationRunner(Jobs(state="FAILED"), ParityChecker(Reader()), Results(),
                                 _llm(obs, conc)).run(_state(), cfg(dataflow_id="8099"))
    assert not rep.passed and rep.diagnoses
    assert "did not complete" in rep.diagnoses[0].explanation


async def test_results_written_keyed_by_dataflow_and_iteration():
    obs, conc = FakeObservability(), TrackingConcurrency()
    store = Results()
    runner = ValidationRunner(Jobs(), ParityChecker(Reader()), store, _llm(obs, conc))
    await runner.run(_state(), cfg(dataflow_id="8099", iteration=2))
    assert ("8099", 2) in store.writes
    assert isinstance(store.writes[("8099", 2)], ValidationReport)


async def test_rerun_overwrites_the_same_key():
    obs, conc = FakeObservability(), TrackingConcurrency()
    store = Results()
    runner = ValidationRunner(Jobs(), ParityChecker(Reader()), store, _llm(obs, conc))
    await runner.run(_state(), cfg(dataflow_id="8099", iteration=1))
    await runner.run(_state(), cfg(dataflow_id="8099", iteration=1))
    assert len(store.writes) == 1            # overwrite, not append


async def test_failure_path_produces_a_diagnosis():
    obs, conc = FakeObservability(), TrackingConcurrency()
    actual = {**EXPECTED, "rows": 17792}
    rep = await ValidationRunner(Jobs(), ParityChecker(Reader(actual)), Results(),
                                 _llm(obs, conc)).run(_state(), cfg(dataflow_id="8099"))
    assert not rep.passed and rep.diagnoses
    assert rep.diagnoses[0].nodes                 # points at something


async def test_troubleshooting_can_be_switched_off():
    obs, conc = FakeObservability(), TrackingConcurrency()
    actual = {**EXPECTED, "rows": 1}
    rep = await ValidationRunner(Jobs(), ParityChecker(Reader(actual)), Results(),
                                 _llm(obs, conc), ai_troubleshoot=False).run(
        _state(), cfg(dataflow_id="8099"))
    assert not rep.passed and rep.diagnoses == ()


async def test_evaluator_wraps_parity_as_an_eval_result():
    ev = ValidationEvaluator()
    assert (await ev.evaluate(GenResult(), {}, cfg())).verdict is Verdict.FAIL
