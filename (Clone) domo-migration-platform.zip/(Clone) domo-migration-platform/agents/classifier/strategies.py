"""Classifier agent (7). Medallion assignment -> evaluate -> HITL -> split -> run.

Two labels exist and they are decided at different times, which is easy to conflate:

* POSITION (terminal vs intermediate) is local and already known from Discovery's
  lineage. Codegen needs it to choose CTE vs materialized table.
* MEDALLION LAYER is an ESTATE-level property. A table that is gold for one workflow
  is bronze for another, so it can only be settled once the estate is known. This
  agent decides it, governed by config rather than hardcoded prose.

Splitting depends on the CD output being node-addressable — that is the hard contract
with agent 5. Missing keys fail loud rather than silently dropping code.
"""
from __future__ import annotations

from agents.classifier.ports import LayerStore, PipelineRunner, RulesLoader, SplitStore
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.prompts import PromptLayers
from core.domo.schemas import EvalResult, GenResult, HumanFeedback, Verdict

AGENT = "classifier"
LAYERS = ("bronze", "silver", "gold")


class ClassifierError(RuntimeError):
    pass


def _cfg(config) -> dict:
    return (config or {}).get("configurable", {}) if isinstance(config, dict) else {}


class SectionSplitter:
    """Parses ``[node: <id>]`` sections and partitions them strictly by layer.

    Shares the marker grammar with cd_codegen's assembler — if that changes, both
    change together, which is why the contract is documented on both sides.

    Both comment styles are accepted because both assemblers are real: the PySpark
    path writes ``# [node: ...]`` and the SQL path writes ``-- [node: ...]``. This
    matched only ``#`` until an end-to-end run put a SQL artifact through it and got
    zero sections back — which does not raise, it just silently classifies nothing.
    """
    import re as _re
    _OPEN = _re.compile(r"^(?:#|--)\s*\[node:\s*([^\]]+?)\]\s*(.*)$", _re.MULTILINE)

    def sections(self, artifact: str) -> dict[str, str]:
        out: dict[str, str] = {}
        matches = list(self._OPEN.finditer(artifact or ""))
        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(artifact)
            out[m.group(1).strip()] = artifact[m.start():end].rstrip() + "\n"
        return out

    def split(self, artifact: str, assignment: dict[str, str], *,
              table_of=None, dataflow_id: str = "") -> dict[str, str]:
        """One RUNNABLE script per layer.

        Not a concatenation of CTE bodies, which is what this produced before: no
        ``WITH``, no ``CREATE``, no statement terminators, and dangling commas
        between fragments. Something unrunnable presented as the medallion split is
        worse than nothing, because it looks like a deliverable.

        See ``core.domo.materialize``: a materialized node becomes a table, an
        ``unmaterialized`` one stays an inlined CTE, and the walk back stops at any
        other materialized node — which is what makes bronze, silver and gold a
        pipeline rather than three copies of the same query.
        """
        from core.domo.materialize import UNMATERIALIZED, render_all

        secs = self.sections(artifact)
        missing = [n for n in assignment if n not in secs]
        if missing:
            raise ClassifierError(
                f"cannot split: {len(missing)} assigned nodes are absent from the CD output "
                f"({', '.join(missing[:5])}). CD output must be node-addressable.")
        unassigned = [n for n in secs if n not in assignment]
        if unassigned:
            raise ClassifierError(
                f"{len(unassigned)} node sections have no layer assignment "
                f"({', '.join(unassigned[:5])})")
        allowed = set(LAYERS) | {UNMATERIALIZED}
        bad = sorted({layer for layer in assignment.values() if layer not in allowed})
        if bad:
            raise ClassifierError(
                f"unknown layer(s) {bad}; expected one of {sorted(allowed)}")
        namer = table_of or (lambda node: node)
        return render_all(secs, assignment, table_of=namer, dataflow_id=dataflow_id)


class LayerClassifier:
    """LLM-driven assignment, governed by the config file.

    Config decides; the model applies. Orgs differ, so a swapped config must change
    the outcome without a code change.
    """

    def __init__(self, llm: LLMClient, rules: RulesLoader, splitter: SectionSplitter | None = None) -> None:
        self._llm = llm
        self._rules = rules
        self._splitter = splitter or SectionSplitter()

    async def assign(self, artifact: str, state, config) -> dict[str, str]:
        rules = self._rules.load()
        nodes = list(self._splitter.sections(artifact))
        if not nodes:
            raise ClassifierError("CD output contains no node sections to classify")

        # TEAMMATE-OWNED: the real classifier prompts with the rules and the node
        # metadata. The deterministic fallback below applies the config's explicit
        # overrides and position rules so the contract tests are meaningful.
        await self._llm.complete(
            Role.CLASSIFIER,
            PromptLayers(base=f"Assign each node to a medallion layer using these rules:\n{rules}",
                         user_prompt=str((state.get("prompt_layers") or {}).get(AGENT, "") or "")),
            pool="classification", config=config)

        overrides: dict[str, str] = dict(rules.get("overrides", {}) or {})
        source_ops = set(rules.get("bronze_ops", ["SOURCE"]))
        sink_ops = set(rules.get("gold_ops", ["WRITE"]))
        assignment: dict[str, str] = {}
        for node in nodes:
            if node in overrides:
                assignment[node] = overrides[node]
                continue
            header = self._splitter.sections(artifact)[node].splitlines()[0]
            op = ""
            if "op=" in header:
                op = header.split("op=", 1)[1].split()[0]
            assignment[node] = ("bronze" if op in source_ops
                                else "gold" if op in sink_ops else "silver")
        return assignment


class ClassifierRunner:
    def __init__(self, classifier: LayerClassifier, layers: LayerStore, splits: SplitStore,
                 pipelines: PipelineRunner, *, grouping: str = "single",
                 splitter: SectionSplitter | None = None,
                 table_of=None) -> None:
        #: node -> the table it materializes into. Defaults to the node's own name,
        #: which is obviously wrong in a warehouse and obviously wrong on sight -
        #: better than a plausible default that silently writes to the wrong schema.
        self._table_of = table_of or (lambda node: node)
        self._classifier = classifier
        self._layers = layers
        self._splits = splits
        self._pipelines = pipelines
        self._grouping = grouping
        self._splitter = splitter or SectionSplitter()

    async def run(self, state, config=None) -> dict:
        c = _cfg(config)
        dataflow_id = state.get("dataflow_id") or c.get("dataflow_id")
        iteration = int(c.get("iteration", 1) or 1)
        gen = (state.get("cd_codegen") or {}).get("gen") or {}
        artifact = gen.get("artifact", "")
        if not artifact:
            raise ClassifierError("classifier: no CD codegen artifact on state")

        assignment = await self._classifier.assign(artifact, state, config)
        # The table each materialized node writes. Injected rather than assumed:
        # catalog, schema and any medallion prefix are deployment policy, and a
        # layer script that writes to the wrong place is worse than one that fails.
        files = self._splitter.split(artifact, assignment,
                                     table_of=self._table_of,
                                     dataflow_id=str(dataflow_id))

        table = self._layers.write(dataflow_id, iteration, assignment)
        paths = {layer: self._splits.write_layer(dataflow_id, iteration, layer, body)
                 for layer, body in files.items()}
        handles = self._pipelines.launch(dataflow_id, iteration, paths, grouping=self._grouping)

        counts = {layer: sum(1 for v in assignment.values() if v == layer) for layer in LAYERS}
        # The assignment itself, not just its counts: a reviewer is asked which
        # layer a node landed in, and recomputing that downstream could disagree
        # with the files this call just wrote.
        return {"assignment_table": table, "assignment": dict(assignment),
                "layer_paths": paths, "counts": counts,
                "pipeline_handles": handles, "grouping": self._grouping,
                "iteration": iteration}


class ClassifierEvaluator:
    async def evaluate(self, gen: GenResult, state, config=None) -> EvalResult:
        counts = (state.get(AGENT) or {}).get("counts") or {}
        if counts and not counts.get("gold"):
            return EvalResult(verdict=Verdict.REVISE, confidence=0.7,
                              summary="no node assigned to gold; check the rules config")
        return EvalResult(verdict=Verdict.PASS, confidence=0.9, summary="layers assigned")


class ClassifierFeedbackApplier:
    """Per-issue apply/keep on the classification itself."""

    def apply(self, gen: GenResult, feedback: list[HumanFeedback]) -> GenResult:
        accepted = [i for fb in feedback for i in fb.accepted_issue_ids]
        meta = dict(gen.meta)
        meta["applied_issue_ids"] = accepted
        return GenResult(artifact=gen.artifact, node_keys=gen.node_keys, meta=meta)
