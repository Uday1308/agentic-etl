"""Ports for the Classifier agent (7)."""
from __future__ import annotations

import abc
from typing import Any


class RulesLoader(abc.ABC):
    """Loads the medallion-rules config.

    The format is TBD by internal teams, so node logic codes against THIS interface
    and never against a file shape. Swapping the config must change the result
    without touching the agent.
    """

    @abc.abstractmethod
    def load(self) -> dict[str, Any]: ...


class LayerStore(abc.ABC):
    """Writes the layer assignment to Delta, keyed by (dataflow_id, iteration)."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, iteration: int, assignment: dict[str, str]) -> str: ...


class SplitStore(abc.ABC):
    """Writes the three layer files to the volume, keyed by (dataflow_id, iteration)."""

    @abc.abstractmethod
    def write_layer(self, dataflow_id: str, iteration: int, layer: str, content: str) -> str: ...


class PipelineRunner(abc.ABC):
    """Runs the layer files. Grouping comes from user config — all three layers under
    one job, or separate jobs with separate schedules.

    DLT vs multi-task Job is an open decision, so this is the abstraction the node
    codes against rather than a specific runner.
    """

    @abc.abstractmethod
    def launch(self, dataflow_id: str, iteration: int, layer_paths: dict[str, str],
               *, grouping: str = "single") -> list[str]: ...
