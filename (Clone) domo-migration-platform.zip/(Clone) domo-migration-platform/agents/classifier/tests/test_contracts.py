"""Classifier contracts (skill: consumes node-keyed CD output and fails loud on
missing keys; config rules drive assignment; per-issue HITL; splits into exactly 3
files; grouping config honoured; versioned per iteration)."""
from __future__ import annotations

import pytest
from conftest import FakeObservability, TrackingConcurrency, cfg, ts_iso

from agents.classifier.ports import LayerStore, PipelineRunner, RulesLoader, SplitStore
from agents.classifier.strategies import (
    ClassifierError,
    ClassifierEvaluator,
    ClassifierFeedbackApplier,
    ClassifierRunner,
    LayerClassifier,
    SectionSplitter,
)
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.schemas import GenResult, HumanFeedback, Verdict

ARTIFACT = (
    "# [node: src_df] op=SOURCE origin=md\nsrc_df = spark.read.table('b.src')\n# [/node: src_df]\n"
    "# [node: df_flt_s01] op=FILTER origin=md\ndf_flt_s01 = src_df.filter('x')\n# [/node: df_flt_s01]\n"
    "# [node: write_out] op=WRITE origin=md\ndf_flt_s01.write.saveAsTable('g.out')\n# [/node: write_out]\n"
)


class Rules(RulesLoader):
    def __init__(self, payload=None):
        self.payload = payload or {"bronze_ops": ["SOURCE"], "gold_ops": ["WRITE"],
                                   "overrides": {}}

    def load(self):
        return self.payload


class Layers(LayerStore):
    def __init__(self):
        self.writes = {}

    def write(self, dataflow_id, iteration, assignment):
        self.writes[(dataflow_id, iteration)] = assignment
        return f"dev.classifier.layers/{dataflow_id}/{iteration}"


class Splits(SplitStore):
    def __init__(self):
        self.files = {}

    def write_layer(self, dataflow_id, iteration, layer, content):
        p = f"/Volumes/dev/cd/{dataflow_id}/v{iteration}/{layer}.py"
        self.files[p] = content
        return p


class Pipelines(PipelineRunner):
    def __init__(self):
        self.calls = []

    def launch(self, dataflow_id, iteration, layer_paths, *, grouping="single"):
        self.calls.append((dataflow_id, iteration, grouping, dict(layer_paths)))
        return ["job-1"] if grouping == "single" else [f"job-{k}" for k in layer_paths]


def _llm(obs, conc):
    return LLMClient(
        registry=ModelRegistry({"dev": {"classifier": EndpointSpec(endpoint="c"),
                                        "generator": EndpointSpec(endpoint="g"),
                                        "evaluator": EndpointSpec(endpoint="e")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=conc, observability=obs,
        caller=lambda s, p, sc, t: RawCompletion(text='{"src_df":"bronze"}'))


def _runner(rules=None, grouping="single"):
    obs, conc = FakeObservability(), TrackingConcurrency()
    layers, splits, pipes = Layers(), Splits(), Pipelines()
    r = ClassifierRunner(LayerClassifier(_llm(obs, conc), rules or Rules()),
                         layers, splits, pipes, grouping=grouping)
    return r, layers, splits, pipes, conc


def _state():
    return {"dataflow_id": "8099", "cd_codegen": {"gen": {"artifact": ARTIFACT}}}


def test_splitter_reads_node_keyed_output():
    secs = SectionSplitter().sections(ARTIFACT)
    assert set(secs) == {"src_df", "df_flt_s01", "write_out"}


def test_missing_node_keys_fail_loud():
    """Splitting depends on CD output being node-addressable — the hard contract
    with agent 5."""
    with pytest.raises(ClassifierError, match="absent from the CD output"):
        SectionSplitter().split(ARTIFACT, {"src_df": "bronze", "ghost_node": "silver"})


def test_unassigned_sections_fail_loud():
    with pytest.raises(ClassifierError, match="no layer assignment"):
        SectionSplitter().split(ARTIFACT, {"src_df": "bronze"})


async def test_config_rules_drive_layer_assignment():
    r, layers, _, _, _ = _runner()
    out = await r.run(_state(), cfg(dataflow_id="8099"))
    assign = layers.writes[("8099", 1)]
    assert assign == {"src_df": "bronze", "df_flt_s01": "silver", "write_out": "gold"}
    assert out["counts"] == {"bronze": 1, "silver": 1, "gold": 1}


async def test_swapping_the_config_changes_the_result():
    """Orgs differ, so rules come from config — not hardcoded prose."""
    override = Rules({"bronze_ops": ["SOURCE"], "gold_ops": ["WRITE"],
                      "overrides": {"df_flt_s01": "gold"}})
    r, layers, _, _, _ = _runner(rules=override)
    await r.run(_state(), cfg(dataflow_id="8099"))
    assert layers.writes[("8099", 1)]["df_flt_s01"] == "gold"


async def test_code_splits_into_exactly_three_layer_files():
    r, _, splits, _, _ = _runner()
    out = await r.run(_state(), cfg(dataflow_id="8099"))
    assert set(out["layer_paths"]) == {"bronze", "silver", "gold"}
    assert len(splits.files) == 3
    assert "src_df = spark.read" in splits.files[out["layer_paths"]["bronze"]]
    assert "saveAsTable" in splits.files[out["layer_paths"]["gold"]]


async def test_layer_files_are_versioned_per_iteration():
    r, _, splits, _, _ = _runner()
    await r.run(_state(), cfg(dataflow_id="8099", iteration=1))
    await r.run(_state(), cfg(dataflow_id="8099", iteration=2))
    assert any("/v1/" in p for p in splits.files) and any("/v2/" in p for p in splits.files)


async def test_pipeline_grouping_config_is_honoured():
    single, _, _, pipes_single, _ = _runner(grouping="single")
    await single.run(_state(), cfg(dataflow_id="8099"))
    assert len(pipes_single.calls[0][3]) == 3 and pipes_single.calls[0][2] == "single"

    per, _, _, pipes_per, _ = _runner(grouping="per_layer")
    out = await per.run(_state(), cfg(dataflow_id="8099"))
    assert len(out["pipeline_handles"]) == 3


async def test_classification_uses_its_named_pool():
    r, _, _, _, conc = _runner()
    await r.run(_state(), cfg(dataflow_id="8099"))
    assert "classification" in conc.acquired


async def test_missing_cd_artifact_fails_loud():
    r, _, _, _, _ = _runner()
    with pytest.raises(ClassifierError, match="no CD codegen artifact"):
        await r.run({"dataflow_id": "8099"}, cfg(dataflow_id="8099"))


async def test_evaluator_flags_an_empty_gold_layer():
    ev = ClassifierEvaluator()
    bad = await ev.evaluate(GenResult(), {"classifier": {"counts": {"bronze": 2, "silver": 1, "gold": 0}}})
    assert bad.verdict is Verdict.REVISE
    good = await ev.evaluate(GenResult(), {"classifier": {"counts": {"gold": 1}}})
    assert good.verdict is Verdict.PASS


def test_per_issue_apply_and_keep():
    fb = HumanFeedback(accepted_issue_ids=["c1"], rejected_issue_ids=["c2"], ts=ts_iso())
    out = ClassifierFeedbackApplier().apply(GenResult(artifact=ARTIFACT), [fb])
    assert out.meta["applied_issue_ids"] == ["c1"]
