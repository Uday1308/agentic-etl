"""Classifier subgraph. evaluate -> HITL -> finalize."""
from __future__ import annotations

from agents.classifier.ports import LayerStore, PipelineRunner, RulesLoader, SplitStore
from agents.classifier.strategies import (
    ClassifierEvaluator,
    ClassifierFeedbackApplier,
    ClassifierRunner,
    LayerClassifier,
)
from core.domo.llm import LLMClient

AGENT = "classifier"


def build_classifier(*, llm: LLMClient, rules: RulesLoader, layers: LayerStore,
                     splits: SplitStore, pipelines: PipelineRunner,
                     grouping: str = "single") -> ClassifierRunner:
    return ClassifierRunner(
        classifier=LayerClassifier(llm, rules),
        layers=layers, splits=splits, pipelines=pipelines, grouping=grouping,
    )


__all__ = ["build_classifier", "ClassifierEvaluator", "ClassifierFeedbackApplier", "AGENT"]
