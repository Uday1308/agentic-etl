"""Standardization agent (2). AI + Python, no HITL.

Chunk -> standardize (fan-out over pool ``standardization_chunks``) -> evaluator AND
deterministic JSON validator -> write.

The quality gate is BOTH: an LLM evaluator returning EvalResult, and a separate
deterministic validator that checks shape and that no data was lost. Both must pass.
A model cannot vouch for its own losslessness, which is exactly why the validator
is not an LLM.

Why this agent still exists alongside Discovery: it is the tool adapter seam. It
normalizes any ETL tool's export (DOMO today, Informatica or Alteryx later) into the
common shape, so Discovery stays tool-agnostic.
"""
from __future__ import annotations

import asyncio
from typing import Any

from agents.standardization.ports import RawJsonReader, StandardStore
from core.contracts.standardized import (
    StandardizedSchemaError,
    unwrap,
    validate_standardized,
)
from core.domo.llm import LLMClient
from core.domo.models import Role
from core.domo.prompts import PromptLayers
from core.domo.schemas import EvalResult, GenResult, Verdict

AGENT = "standardization"
POOL = "standardization_chunks"


class JsonValidationError(RuntimeError):
    pass


class DeterministicJsonValidator:
    """Shape + data-intact check. No LLM, no judgement calls.

    Both halves live in ``core.contracts.standardized`` so the producer here and the
    consumers in Discovery (3) and MD Plan (4) cannot drift apart: losslessness is
    checked by counting — every action and connection in the raw export must survive
    into the standardized document. Renaming is allowed, dropping is not.
    """

    def validate(self, raw: dict[str, Any], standardized: dict[str, Any]) -> list[str]:
        return validate_standardized(standardized, raw=raw)


class ChunkStandardizer:
    """Fans chunks out over the pool and merges results BY INDEX.

    Merge-not-overwrite is the contract: under concurrency, chunk results must be
    keyed by index and combined, or chunks are silently lost.
    """

    def __init__(self, llm: LLMClient, *, chunk_size: int = 25) -> None:
        self._llm = llm
        self._chunk_size = chunk_size

    async def standardize(self, raw: dict[str, Any], *, config) -> dict[str, Any]:
        """Chunk the tiles, fan out, merge by index, re-emit the document.

        Output is the id-keyed standardized shape defined in
        ``core.contracts.standardized`` — the form Discovery and MD Plan read. Fields
        this agent does not touch (``inputs``, ``outputs``, ``name``, ...) are carried
        through verbatim rather than reconstructed, so standardizing is additive.
        """
        try:
            df_id, flow = unwrap(raw)
        except StandardizedSchemaError as e:
            raise JsonValidationError(f"standardization: unusable raw export: {e}") from e

        actions = list(flow.get("actions") or flow.get("nodes") or [])
        chunks = [actions[i:i + self._chunk_size]
                  for i in range(0, len(actions), self._chunk_size)]
        results = await asyncio.gather(*(
            self._one_chunk(idx, chunk, config=config) for idx, chunk in enumerate(chunks)
        ))
        merged: dict[int, list] = {}
        for idx, out in results:
            merged[idx] = out
        ordered = [n for idx in sorted(merged) for n in merged[idx]]

        body = {k: v for k, v in flow.items() if k not in ("actions", "connections", "nodes", "edges")}
        body["actions"] = ordered
        body["connections"] = list(flow.get("connections") or flow.get("edges") or [])
        body.setdefault("id", df_id)
        body.setdefault("disabled_skipped", [])
        return {str(df_id): body}

    async def _one_chunk(self, idx: int, chunk: list, *, config) -> tuple[int, list]:
        # TEAMMATE-OWNED: replace with the standalone chunk-processing standardizer.
        # The scaffold keeps the fan-out, pool and merge-by-index contract intact so
        # the surrounding tests stay meaningful while the body is filled in.
        await self._llm.complete(
            Role.GENERATOR,
            PromptLayers(base=f"Standardize chunk {idx} of the DOMO dataflow export."),
            pool=POOL, config=config,
        )
        return idx, chunk


class StandardizationEvaluator:
    """LLM quality gate. Runs alongside — never instead of — the JSON validator."""

    def __init__(self, llm: LLMClient) -> None:
        self._llm = llm

    async def evaluate(self, gen: GenResult, state: dict, *, config) -> EvalResult:
        result = await self._llm.complete(
            Role.EVALUATOR,
            PromptLayers(base="Review the standardized DOMO JSON for fidelity."),
            pool="evaluation", response_schema=EvalResult, config=config,
        )
        return result.parsed or EvalResult(verdict=Verdict.PASS, confidence=0.0,
                                           summary="evaluator returned nothing")


class StandardizationRunner:
    def __init__(self, reader: RawJsonReader, store: StandardStore,
                 standardizer: ChunkStandardizer, evaluator: StandardizationEvaluator,
                 validator: DeterministicJsonValidator | None = None) -> None:
        self._reader = reader
        self._store = store
        self._std = standardizer
        self._eval = evaluator
        self._validator = validator or DeterministicJsonValidator()

    async def run(self, state: dict, config: dict | None = None) -> dict:
        dataflow_id = state.get("dataflow_id")
        if not dataflow_id:
            raise ValueError("standardization: dataflow_id missing from state")
        raw = self._reader.read(dataflow_id)
        standardized = await self._std.standardize(raw, config=config)

        problems = self._validator.validate(raw, standardized)
        if problems:
            raise JsonValidationError(
                "standardized output failed the deterministic validator: " + "; ".join(problems))

        _, flow = unwrap(standardized, str(dataflow_id))
        actions = list(flow.get("actions") or [])
        ev = await self._eval.evaluate(
            GenResult(artifact="", node_keys=[a.get("id", "") for a in actions]),
            state, config=config)
        path = self._store.write(dataflow_id, standardized)
        return {"artifact_path": path, "nodes": len(actions),
                "validator_problems": problems, "verdict": ev.verdict.value}
