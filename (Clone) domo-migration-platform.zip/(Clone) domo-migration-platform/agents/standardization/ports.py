"""Ports for the Standardization agent (2)."""
from __future__ import annotations

import abc
from typing import Any


class RawJsonReader(abc.ABC):
    @abc.abstractmethod
    def read(self, dataflow_id: str) -> dict[str, Any]: ...


class StandardStore(abc.ABC):
    """Idempotent overwrite per dataflow/file — no iteration axis."""

    @abc.abstractmethod
    def write(self, dataflow_id: str, payload: dict[str, Any]) -> str: ...
