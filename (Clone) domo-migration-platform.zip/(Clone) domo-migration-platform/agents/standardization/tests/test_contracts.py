"""Standardization contracts (skill: chunk fan-out merges by index; the deterministic
validator rejects lossy output; evaluator returns a valid EvalResult; idempotent)."""
from __future__ import annotations

import pytest
from conftest import FakeObservability, TrackingConcurrency, cfg

from agents.standardization.ports import RawJsonReader, StandardStore
from agents.standardization.strategies import (
    ChunkStandardizer,
    DeterministicJsonValidator,
    JsonValidationError,
    StandardizationEvaluator,
    StandardizationRunner,
)
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry
from core.domo.prompts import HardConstraintChecker, PromptAssembler

#: The DOMO export as it really arrives: keyed by dataflow id, tiles under
#: ``actions``, edges under ``connections`` (core.contracts.standardized).
RAW = {"8099": {"id": 8099,
                "name": "cms",
                "inputs": [{"dataSourceId": "d0", "dataSourceName": "feed"}],
                "outputs": [{"dataSourceId": "d1", "dataSourceName": "out"}],
                "actions": [{"id": f"n{i}", "name": f"Filter {i}", "type": "filter",
                             "logic": {"filterGroups": []}} for i in range(60)],
                "connections": [{"from": "n0", "to": "n1"}],
                "disabled_skipped": []}}
FLOW = RAW["8099"]


class Reader(RawJsonReader):
    def read(self, dataflow_id):
        return RAW


class Store(StandardStore):
    def __init__(self):
        self.writes = []

    def write(self, dataflow_id, payload):
        self.writes.append(payload)
        return f"/Volumes/dev/std/{dataflow_id}.json"


def _llm(obs, conc):
    return LLMClient(
        registry=ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="g"),
                                        "evaluator": EndpointSpec(endpoint="e")}}),
        assembler=PromptAssembler(), checker=HardConstraintChecker(),
        concurrency=conc, observability=obs,
        caller=lambda spec, prompt, schema, timeout: RawCompletion(
            text='{"verdict":"pass","confidence":0.9,"issues":[],"summary":"ok"}'),
    )


async def test_chunk_fanout_merges_by_index_without_losing_chunks():
    obs, conc = FakeObservability(), TrackingConcurrency()
    std = ChunkStandardizer(_llm(obs, conc), chunk_size=25)
    out = await std.standardize(RAW, config=cfg())
    assert list(out) == ["8099"]                         # id-keyed, as documented
    actions = out["8099"]["actions"]
    assert len(actions) == 60                            # 3 chunks, nothing lost
    assert [a["id"] for a in actions] == [f"n{i}" for i in range(60)]  # order held


async def test_chunking_carries_untouched_fields_through():
    """Standardizing is additive: fields this agent does not rewrite survive verbatim,
    or downstream loses the source/target detail it needs."""
    obs, conc = FakeObservability(), TrackingConcurrency()
    out = await ChunkStandardizer(_llm(obs, conc), chunk_size=25).standardize(RAW, config=cfg())
    flow = out["8099"]
    assert flow["inputs"] == FLOW["inputs"] and flow["outputs"] == FLOW["outputs"]
    assert flow["name"] == "cms"
    assert flow["connections"] == FLOW["connections"]


async def test_chunk_fanout_uses_its_named_pool():
    obs, conc = FakeObservability(), TrackingConcurrency()
    await ChunkStandardizer(_llm(obs, conc), chunk_size=25).standardize(RAW, config=cfg())
    assert set(conc.acquired) == {"standardization_chunks"}


def _std(**over):
    return {"8099": {**FLOW, **over}}


def test_validator_rejects_lossy_output():
    """The model cannot vouch for its own losslessness — this check is deterministic."""
    v = DeterministicJsonValidator()
    problems = v.validate(RAW, _std(actions=FLOW["actions"][:59]))
    assert any("action count changed" in p for p in problems)


def test_validator_rejects_malformed_output():
    v = DeterministicJsonValidator()
    assert any("missing required key" in p
               for p in v.validate(RAW, {"8099": {"id": 8099, "actions": []}}))
    dupes = _std(actions=[{"id": "a"}, {"id": "a"}])
    assert any("duplicate action ids" in p for p in v.validate(RAW, dupes))


def test_validator_rejects_an_empty_tile_list():
    """An empty document is structurally valid and produces a plan with no steps —
    the failure mode that must never pass silently."""
    v = DeterministicJsonValidator()
    assert any("actions is empty" in p for p in v.validate(RAW, _std(actions=[])))


def test_validator_rejects_dangling_connections():
    v = DeterministicJsonValidator()
    bad = _std(connections=[{"from": "n0", "to": "nowhere"}])
    assert any("unknown action ids" in p for p in v.validate(RAW, bad))


def test_validator_accepts_faithful_output():
    v = DeterministicJsonValidator()
    assert v.validate(RAW, _std()) == []


async def test_runner_raises_when_the_validator_rejects():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm = _llm(obs, conc)

    class Lossy(ChunkStandardizer):
        async def standardize(self, raw, *, config):
            return {"8099": {**FLOW, "actions": FLOW["actions"][:1], "connections": []}}

    runner = StandardizationRunner(Reader(), Store(), Lossy(llm),
                                   StandardizationEvaluator(llm))
    with pytest.raises(JsonValidationError, match="deterministic validator"):
        await runner.run({"dataflow_id": "8099"}, cfg())


async def test_runner_is_idempotent_and_returns_a_verdict():
    obs, conc = FakeObservability(), TrackingConcurrency()
    llm = _llm(obs, conc)
    store = Store()
    runner = StandardizationRunner(Reader(), store, ChunkStandardizer(llm, chunk_size=25),
                                   StandardizationEvaluator(llm))
    a = await runner.run({"dataflow_id": "8099"}, cfg())
    b = await runner.run({"dataflow_id": "8099"}, cfg())
    assert a["artifact_path"] == b["artifact_path"] and len(store.writes) == 2
    assert a["verdict"] == "pass" and a["nodes"] == 60


async def test_no_hitl_gate_on_this_agent():
    """Quality gate is evaluator + validator; a human is never asked here."""
    from agents.master import AGENT_DEFAULTS
    assert AGENT_DEFAULTS["standardization"]["hitl"] is False
