"""core.llm_budget - per-run LLM budget, pricing and the usage ledger (S14, ADR 037).

Ported in part from SNF2DBX-main/migration/usage.py and config/pricing.yaml (LatentView internal): the
per-attempt ledger,
nullable cost, summary numbers. Here the provider is a Databricks serving endpoint.

* ``config/llm_budget.yaml``: tokens / cost / calls per run and attempts per unit. ``0`` or ``null`` = no limit.
* ``config/pricing.yaml``: estimated cost per million tokens by serving endpoint. No rate means an UNKNOWN
  cost (``None``), never zero; a cost budget then cannot be enforced and says so.
* ``UsageLedger``: one JSON line per model call: run, unit, endpoint, attempt, status, tokens, cost, error CLASS.
  Never prompts, source text or answers (hard rule 11).
"""
from __future__ import annotations

import json
import pathlib
import threading
import time
from dataclasses import dataclass
from typing import Any

import yaml

# Ported from SNF2DBX-main/migration/usage.py (LatentView internal)
CONFIG = pathlib.Path(__file__).resolve().parents[1] / "config"
_LOCK = threading.Lock()


@dataclass(frozen=True)
class BudgetConfig:
    max_tokens: int = 0
    max_cost: float | None = None
    max_calls: int = 0
    attempts_per_unit: int = 3


def _num(v: Any, cast: Any, default: Any) -> Any:
    try:
        return cast(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


def load_budget(path: pathlib.Path | str | None = None, env: dict[str, str] | None = None) -> BudgetConfig:
    env = env or {}
    try:
        raw = yaml.safe_load(pathlib.Path(path or CONFIG / "llm_budget.yaml").read_text(encoding="utf-8")) or {}
    except (OSError, ValueError):
        raw = {}
    b = raw.get("budget") or {}
    cost = _num(env.get("MIGRATOR_LLM_MAX_COST") or b.get("max_cost_per_run"), float, None)
    return BudgetConfig(
        max_tokens=_num(env.get("MIGRATOR_LLM_MAX_TOKENS") or b.get("max_tokens_per_run"), int, 0),
        max_cost=cost if cost else None, max_calls=_num(b.get("max_calls_per_run"), int, 0),
        attempts_per_unit=max(1, _num(env.get("MIGRATOR_LLM_ATTEMPTS") or raw.get("attempts_per_unit"), int, 3)))


class Pricing:
    def __init__(self, endpoints: dict[str, dict], currency: str = "USD") -> None:
        self.endpoints, self.currency = endpoints, currency

    def rate(self, endpoint: str) -> dict:
        return self.endpoints.get(endpoint) or self.endpoints.get("default") or {}

    def cost(self, endpoint: str, tokens_in: int, tokens_out: int) -> float | None:
        r = self.rate(endpoint)
        if r.get("input_per_m") is None or r.get("output_per_m") is None:
            return None
        return (tokens_in * float(r["input_per_m"]) + tokens_out * float(r["output_per_m"])) / 1_000_000


def load_pricing(path: pathlib.Path | str | None = None) -> Pricing:
    try:
        raw = yaml.safe_load(pathlib.Path(path or CONFIG / "pricing.yaml").read_text(encoding="utf-8")) or {}
    except (OSError, ValueError):
        raw = {}
    return Pricing(dict(raw.get("endpoints") or {}), str(raw.get("currency") or "USD"))


class UsageLedger:
    """Append-only JSONL, one file per run (``<volume>/_usage/<run>.jsonl``)."""

    def __init__(self, path: pathlib.Path | str) -> None:
        self.path = pathlib.Path(path)

    def record(self, **row: Any) -> dict:
        row = {"ts": time.time(), **row}
        with _LOCK:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, sort_keys=True, default=str) + "\n")
        return row

    def rows(self) -> list[dict]:
        out: list[dict] = []
        try:
            for line in self.path.read_text(encoding="utf-8").splitlines():
                try:
                    out.append(json.loads(line))
                except ValueError:
                    continue
        except OSError:
            pass
        return out


def ledger_for(volume: pathlib.Path | str, run_id: str) -> UsageLedger:
    safe = "".join(c for c in run_id if c.isalnum() or c in "._-") or "run"
    return UsageLedger(pathlib.Path(volume) / "_usage" / f"{safe}.jsonl")


def summarize(rows: list[dict]) -> dict:
    """Headline numbers. ``cost`` is None unless EVERY call had a rate (a partial sum would understate)."""
    costs = [r.get("cost") for r in rows]
    priced = [c for c in costs if c is not None]
    done = [r for r in rows if r.get("status") == "completed"]
    classes: dict[str, int] = {}
    for r in rows:
        if r.get("error_class"):
            classes[r["error_class"]] = classes.get(r["error_class"], 0) + 1
    return {"calls": len(rows), "completed": len(done), "failed": sum(r.get("status") == "failed" for r in rows),
            "refused_by_budget": sum(r.get("status") == "budget" for r in rows),
            "tokens_in": sum(int(r.get("tokens_in") or 0) for r in rows),
            "tokens_out": sum(int(r.get("tokens_out") or 0) for r in rows),
            "cost": sum(priced) if rows and len(priced) == len(rows) else None,
            "cost_known_calls": len(priced), "error_classes": classes,
            "units": len({r.get("unit") for r in rows if r.get("unit")})}


class RunBudget:
    """Counts one run's calls, tokens and cost against the limits."""

    def __init__(self, cfg: BudgetConfig, pricing: Pricing | None = None) -> None:
        self.cfg, self.pricing = cfg, pricing or Pricing({})
        self.calls = self.tokens = 0
        self.cost: float | None = 0.0

    def exhausted(self) -> str:
        c = self.cfg
        if c.max_calls and self.calls >= c.max_calls:
            return f"call limit {c.max_calls} reached"
        if c.max_tokens and self.tokens >= c.max_tokens:
            return f"token limit {c.max_tokens} reached"
        if c.max_cost is not None and self.cost is not None and self.cost >= c.max_cost:
            return f"cost limit {c.max_cost} {self.pricing.currency} reached"
        return ""

    def reserve(self) -> None:
        """Count a call BEFORE it is awaited, so concurrent units cannot all slip under the call limit."""
        self.calls += 1

    def add(self, endpoint: str, tokens_in: int, tokens_out: int) -> float | None:
        self.tokens += tokens_in + tokens_out
        cost = self.pricing.cost(endpoint, tokens_in, tokens_out)
        self.cost = None if cost is None or self.cost is None else self.cost + cost
        return cost

    def cost_unenforceable(self, endpoint: str) -> bool:
        return self.cfg.max_cost is not None and self.pricing.cost(endpoint, 1, 1) is None


__all__ = ["BudgetConfig", "Pricing", "RunBudget", "UsageLedger", "ledger_for", "load_budget", "load_pricing",
           "summarize"]
