"""core.deploy - dry-run plan, digest, approval-bound executor and rollback script for a migrated batch (S13, ADR 037).

Ported in part from SNF2DBX-main/migration/deploy.py (LatentView internal): plan in dependency order, digest, idempotent
steps, jobs paused, rollback script that is reviewed and never run automatically.

* ``build_plan`` is pure: it reads the batch report, the stored artifacts (through ``read_text``) and the assembly
  folder, and returns the ordered steps. Order: schemas, tables, functions (callee first), views, materialized views,
  procedures, notebooks, jobs (created PAUSED). Statements are made idempotent (``IF NOT EXISTS`` / ``OR REPLACE``
  where that cannot lose data); a ``CREATE OR REPLACE TABLE`` becomes ``IF NOT EXISTS``. Nothing is ever dropped.
* ``plan['digest']`` covers every step; ``execute_plan`` runs only a plan whose digest equals the approved one.
* The ``Deployer`` port is the ONLY thing that touches a workspace (rules 4 and 5): ``FakeDeployer`` for tests,
  ``DatabricksDeployer`` over the existing connector callable. Step results carry the error CLASS only.
* After the run, ``verify.check_deployed`` checks that each created object exists.
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import pathlib
import re
from collections.abc import Callable
from typing import Any, Protocol

from packs.snowflake.warehouse import Warehouse, WarehouseError, error_class_of

# Ported from SNF2DBX-main/migration/deploy.py (LatentView internal)
RANK = {"schema": 0, "table": 1, "function": 2, "view": 3, "materialized_view": 4, "procedure": 5, "notebook": 6,
        "job": 7}
_HEAD = re.compile(
    r"^\s*CREATE\s+(?P<replace>OR\s+REPLACE\s+)?(?P<kind>MATERIALIZED\s+VIEW|TABLE|VIEW|FUNCTION|PROCEDURE)\s+"
    r"(?P<ine>IF\s+NOT\s+EXISTS\s+)?(?P<name>[`\w.\"-]+)", re.I | re.S)
_COMMENTS = re.compile(r"^(?:\s*--[^\n]*\n|\s*/\*.*?\*/)+", re.S)
_DESTRUCTIVE = re.compile(r"^\s*(DROP|TRUNCATE|DELETE|ALTER\s+TABLE\s+\S+\s+DROP)\b", re.I)
_VAR = re.compile(r"\$\{var\.([A-Za-z0-9_]+)\}")
JOB_ONLY_KEYS = ("review_reasons", "external_predecessors")


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_") or "x"


class DeployError(Exception):
    """A deploy action failed. ``error_class`` is all a result keeps (no statement text, no message)."""

    def __init__(self, error_class: str, message: str = "") -> None:
        super().__init__(f"{error_class}: {message[:200]}")
        self.error_class = error_class


# ------------------------------------------------------------------------------------------------ the port
class Deployer(Protocol):
    def execute(self, sql: str) -> None: ...
    def exists(self, kind: str, name: str) -> bool | None: ...
    def import_notebook(self, path: str, text: str) -> None: ...
    def upsert_job(self, spec: dict) -> str: ...
    def warehouse(self) -> Warehouse | None: ...


class FakeDeployer:
    """Offline deployer. ``fail_on``: statement substring -> error class. ``existing``: names that already exist."""

    def __init__(self, *, fail_on: dict[str, str] | None = None, existing: set[str] | None = None,
                 warehouse: Warehouse | None = None) -> None:
        self.fail_on = dict(fail_on or {})
        self.existing = {e.lower() for e in (existing or set())}
        self.calls: list[tuple[str, Any]] = []
        self._wh = warehouse
        self.jobs: dict[str, dict] = {}

    def execute(self, sql: str) -> None:
        self.calls.append(("sql", sql))
        for needle, cls in self.fail_on.items():
            if needle.lower() in sql.lower():
                raise DeployError(cls, "scripted")
        m = _HEAD.match(sql)
        if m:
            self.existing.add(m["name"].replace("`", "").lower())

    def exists(self, kind: str, name: str) -> bool | None:
        return name.replace("`", "").lower() in self.existing

    def import_notebook(self, path: str, text: str) -> None:
        self.calls.append(("notebook", path))

    def upsert_job(self, spec: dict) -> str:
        self.calls.append(("job", spec["name"]))
        self.jobs[spec["name"]] = spec
        return str(len(self.jobs))

    def warehouse(self) -> Warehouse | None:
        return self._wh


class DatabricksDeployer:
    """Over the existing connector: ``query(statement) -> list[dict]`` (``connect_databricks()[0]``) and,
    for notebooks and jobs, ``api(method, path, body, query)`` (``core.lakebridge.workspace_api_from_env()``)."""

    def __init__(self, query: Callable[..., list[dict]], api: Callable[..., dict] | None = None) -> None:
        self._query, self._api = query, api

    def execute(self, sql: str) -> None:
        try:
            self._query(sql)
        except WarehouseError as exc:
            raise DeployError(exc.error_class) from exc
        except Exception as exc:  # noqa: BLE001 - the connector raises its own types
            raise DeployError(error_class_of(str(exc))) from exc

    def exists(self, kind: str, name: str) -> bool | None:
        what = {"function": "FUNCTION", "procedure": "PROCEDURE"}.get(kind, "TABLE")
        q = ".".join("`" + p + "`" for p in name.replace("`", "").split("."))
        try:
            self._query(f"DESCRIBE {what} {q}")
            return True
        except Exception as exc:  # noqa: BLE001
            return False if error_class_of(str(exc)) in {"TABLE_OR_VIEW_NOT_FOUND", "ROUTINE_NOT_FOUND",
                                                         "SCHEMA_NOT_FOUND"} else None

    def _need_api(self) -> Callable[..., dict]:
        if self._api is None:
            raise DeployError("WORKSPACE_API_UNAVAILABLE")
        return self._api

    def import_notebook(self, path: str, text: str) -> None:
        api = self._need_api()
        try:
            api("POST", "/api/2.0/workspace/mkdirs", {"path": path.rsplit("/", 1)[0]})
            api("POST", "/api/2.0/workspace/import", {"path": path, "format": "SOURCE", "language": "PYTHON",
                                                      "overwrite": True,
                                                      "content": base64.b64encode(text.encode()).decode("ascii")})
        except DeployError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise DeployError(error_class_of(str(exc))) from exc

    def upsert_job(self, spec: dict) -> str:
        api = self._need_api()
        try:
            found = [j for j in (api("GET", "/api/2.2/jobs/list", query={"name": spec["name"]}).get("jobs") or [])
                     if (j.get("settings") or {}).get("name") == spec["name"]]
            if found:
                api("POST", "/api/2.2/jobs/reset", {"job_id": found[0]["job_id"], "new_settings": spec})
                return str(found[0]["job_id"])
            return str(api("POST", "/api/2.2/jobs/create", spec)["job_id"])
        except DeployError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise DeployError(error_class_of(str(exc))) from exc

    def warehouse(self) -> Warehouse | None:
        from packs.snowflake.warehouse import QueryWarehouse

        return QueryWarehouse(self._query)


# ------------------------------------------------------------------------------------------------ plan
def classify(text: str) -> tuple[str, str, str] | None:
    """``(kind, name, why_not)``: the DDL kind and target name of an artifact, or ``None`` when it is not a CREATE."""
    body = _COMMENTS.sub("", text or "", count=1)
    if _DESTRUCTIVE.match(body):
        return "", "", "destructive statement: a deploy never drops or deletes"
    m = _HEAD.match(body)
    if not m:
        return None
    return re.sub(r"\s+", "_", m["kind"].lower()), m["name"].replace('"', "").replace("`", ""), ""


def idempotent(kind: str, sql: str) -> tuple[str, str]:
    """``(sql, note)``: the statement rewritten so a second run changes nothing and loses nothing."""
    body = sql.strip().rstrip(";").strip()
    lead = _COMMENTS.match(body)
    head_at = lead.end() if lead else 0
    m = _HEAD.match(body[head_at:])
    if not m:
        return body, ""
    name_end = head_at + m.end()
    word = {"table": "TABLE", "materialized_view": "MATERIALIZED VIEW", "view": "VIEW", "function": "FUNCTION",
            "procedure": "PROCEDURE"}[kind]
    if kind in ("table", "materialized_view"):
        note = "OR REPLACE rewritten to IF NOT EXISTS: an existing object is never replaced" if m["replace"] else ""
        head = f"CREATE {word} IF NOT EXISTS {m['name']}"
    else:
        note = ""
        head = f"CREATE OR REPLACE {word} {m['name']}"
    return body[:head_at] + head + body[name_end:], note


def _order_key(kind: str, row: dict, udf_pos: dict[str, int], name: str) -> tuple:
    pos = udf_pos.get(str(row.get("etl_id")), 10**6) if kind in ("function", "procedure") else 0
    return (RANK[kind], pos, int(row.get("order") or 0), name)


def build_plan(report: dict, read_text: Callable[[str], str], *, assembly_dir: pathlib.Path | str | None = None,
               workspace_root: str = "/Shared/migration", warehouse_id: str = "") -> dict:
    """The dry-run plan of one batch report. Pure: no workspace calls."""
    rows = [r for r in report.get("etls") or [] if isinstance(r, dict)]
    steps: list[dict] = []
    excluded: list[dict] = []
    problems: list[str] = []
    udf_pos: dict[str, int] = {}
    adir = pathlib.Path(assembly_dir) if assembly_dir else None
    if adir and (adir / "udf_order.json").exists():
        try:
            udf_pos = {str(e): i for i, e in enumerate(json.loads((adir / "udf_order.json").read_text("utf-8")))}
        except ValueError:
            pass
    for row in rows:
        label = str(row.get("name") or row.get("etl_id"))
        status = str(row.get("status") or "")
        if status != "migrated":
            if row.get("artifacts") or status in ("awaiting_review", "blocked", "failed"):
                excluded.append({"name": label, "reason": f"status {status or 'unknown'}: not deployed until migrated"})
            continue
        for a in row.get("artifacts") or []:
            ref, akind, aname = str(a.get("ref")), str(a.get("kind") or ""), str(a.get("name") or label)
            try:
                text = read_text(ref)
            except (OSError, KeyError):
                excluded.append({"name": aname, "reason": "artifact is not on the volume"})
                continue
            if akind == "python":
                steps.append({"kind": "notebook", "object": aname, "action": "notebook", "source_ref": ref,
                              "path": f"{workspace_root}/{slug(aname)}", "text_sha256": sha(text),
                              "_key": _order_key("notebook", row, udf_pos, aname)})
                continue
            if akind == "governance":
                excluded.append({"name": aname, "reason": "governance is proposed to the access framework (ADR 034)"})
                continue
            cls = classify(text)
            if cls is None:
                excluded.append({"name": aname, "reason": "not a CREATE statement: it runs in a job, not at deploy"})
                continue
            kind, obj, why = cls
            if why:
                excluded.append({"name": aname, "reason": why})
                continue
            sql, note = idempotent(kind, text)
            steps.append({"kind": kind, "object": obj, "action": "sql", "source_ref": ref, "sql": sql,
                          "text_sha256": sha(text), **({"note": note} if note else {}),
                          "_key": _order_key(kind, row, udf_pos, obj)})
    schemas = sorted({".".join(s["object"].split(".")[:2]) for s in steps if s["action"] == "sql"
                      and s["object"].count(".") == 2})
    jobs_ok = str((report.get("assembly") or {}).get("status") or "") == "approved"
    if adir and (adir / "jobs").is_dir():
        for p in sorted((adir / "jobs").glob("*.json")):
            try:
                spec = json.loads(p.read_text("utf-8"))
            except ValueError:
                continue
            if not jobs_ok:
                excluded.append({"name": str(spec.get("name")), "reason": "the batch assembly is not approved yet"})
                continue
            spec = {k: v for k, v in spec.items() if k not in JOB_ONLY_KEYS}
            text = json.dumps(spec).replace("${var.warehouse_id}", warehouse_id) if warehouse_id else json.dumps(spec)
            spec = json.loads(text)
            if spec.get("schedule"):
                spec["schedule"]["pause_status"] = "PAUSED"
            if spec.get("trigger"):
                spec["trigger"]["pause_status"] = "PAUSED"
            steps.append({"kind": "job", "object": str(spec["name"]), "action": "job", "spec": spec,
                          "_key": (RANK["job"], 0, 0, str(spec["name"]))})
        if any("${var.warehouse_id}" in json.dumps(s.get("spec", {})) for s in steps):
            problems.append("jobs need a SQL warehouse id: set DATABRICKS_WAREHOUSE_ID")
    steps.sort(key=lambda s: s["_key"])
    out = [{"kind": "schema", "object": s, "action": "sql", "sql": f"CREATE SCHEMA IF NOT EXISTS {s}"}
           for s in schemas]
    for s in steps:
        s.pop("_key")
        out.append(s)
    for i, s in enumerate(out):
        s["index"] = i + 1
    if not out:
        problems.append("nothing to deploy: no migrated CREATE statement, notebook or approved job in this batch")
    plan = {"batch_run_id": report.get("batch_run_id"), "workspace_root": workspace_root, "steps": out,
            "excluded": excluded, "problems": problems, "summary": _summary(out)}
    plan["rollback"] = rollback_script(out)
    plan["digest"] = digest({k: v for k, v in plan.items() if k != "digest"})
    return plan


def _summary(steps: list[dict]) -> dict[str, int]:
    out: dict[str, int] = {}
    for s in steps:
        out[s["kind"]] = out.get(s["kind"], 0) + 1
    return out


_DROP = {"table": "TABLE", "view": "VIEW", "materialized_view": "MATERIALIZED VIEW", "function": "FUNCTION",
         "procedure": "PROCEDURE"}


def rollback_script(steps: list[dict], created: set[str] | None = None) -> str:
    """Reverse-order cleanup for review; NEVER run by the platform. With ``created`` (objects this deploy made and that
    did not exist before) only those are live DROP lines; the rest are comments. Without it all are comments."""
    lines = ["-- Rollback for this deployment. Review before running; the platform never runs it.",
             "-- Dropping a table deletes its data. Only objects created by this deploy are live lines."]
    for s in reversed(steps):
        if s["action"] == "sql" and s["kind"] in _DROP:
            stmt = f"DROP {_DROP[s['kind']]} IF EXISTS {s['object']};"
            lines.append(stmt if created is not None and s["object"] in created else
                         f"-- {stmt}  (existed before, or not confirmed created)")
        elif s["action"] == "job":
            lines.append(f"-- Delete job '{s['object']}' in Workflows (it was created paused).")
        elif s["action"] == "notebook":
            lines.append(f"-- Delete the notebook {s['path']} from the workspace.")
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------------------------------------ execute
def approved(plan: dict, approved_digest: str) -> None:
    """Raises unless the plan is unchanged since ``approved_digest`` and has no problems."""
    body = {k: v for k, v in plan.items() if k != "digest"}
    if plan.get("problems") or approved_digest != plan.get("digest") or digest(body) != approved_digest:
        raise ValueError("the deploy plan is blocked or changed since it was approved: rebuild and approve it again")


def execute_plan(plan: dict, approved_digest: str, deployer: Deployer, read_text: Callable[[str], str],
                 *, now: Callable[[], str] | None = None) -> dict:
    """Run an approved plan step by step; stop at the first failure. Results hold the error class only."""
    approved(plan, approved_digest)
    stamp = now or (lambda: dt.datetime.now(dt.UTC).isoformat())
    results: list[dict] = []
    created: set[str] = set()
    job_ids: dict[str, str] = {}
    stopped = False
    for s in plan["steps"]:
        base = {"index": s["index"], "kind": s["kind"], "object": s["object"]}
        if stopped:
            results.append({**base, "status": "skipped"})
            continue
        try:
            checks = s["action"] == "sql" and s["kind"] != "schema"
            existed = deployer.exists(s["kind"], s["object"]) if checks else None
            if s["action"] == "sql":
                deployer.execute(s["sql"])
            elif s["action"] == "notebook":
                text = read_text(s["source_ref"])
                if sha(text) != s["text_sha256"]:
                    raise DeployError("ARTIFACT_CHANGED")
                deployer.import_notebook(s["path"], text)
            else:
                spec_text = json.dumps(s["spec"])
                for var in _VAR.findall(spec_text):
                    if var.startswith("job_") and var[4:] in job_ids:
                        spec_text = spec_text.replace("${var.%s}" % var, job_ids[var[4:]])
                if _VAR.search(spec_text):
                    raise DeployError("UNRESOLVED_VARIABLE")
                job_ids[slug(s["object"])] = deployer.upsert_job(json.loads(spec_text))
            if s["action"] == "sql" and s["kind"] in _DROP and existed is False:
                created.add(s["object"])
            extra = {"existed_before": existed} if existed is not None else {}
            results.append({**base, "status": "succeeded", **extra})
        except (DeployError, WarehouseError) as exc:
            results.append({**base, "status": "failed", "error_class": getattr(exc, "error_class", "UNKNOWN")})
            stopped = True
        except (OSError, KeyError):
            results.append({**base, "status": "failed", "error_class": "ARTIFACT_MISSING"})
            stopped = True
    from packs.snowflake.verify import check_deployed

    objs = [{"name": r["object"], "kind": "materialized_view" if r["kind"] == "materialized_view" else r["kind"]}
            for r in results if r["status"] == "succeeded" and r["kind"] in _DROP]
    verified = check_deployed(deployer.warehouse(), objs) if objs else {"status": "not_applicable", "objects": []}
    status = ("failed" if any(r["status"] == "failed" for r in results)
              else "passed" if all(r["status"] == "succeeded" for r in results) else "inconclusive")
    return {"status": status, "plan_digest": plan["digest"], "ts": stamp(), "steps": results, "verified": verified,
            "rollback": rollback_script(plan["steps"], created)}


__all__ = ["DatabricksDeployer", "DeployError", "Deployer", "FakeDeployer", "approved", "build_plan", "classify",
           "digest", "execute_plan", "idempotent", "rollback_script"]
