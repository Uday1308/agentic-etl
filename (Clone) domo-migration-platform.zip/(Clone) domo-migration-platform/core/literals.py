"""core.literals - the one literal masker (ADR 032 section 3).

String literals become ``'***'``: in gate previews, batch reports and, for packs with
``literals_sensitive: true`` (Snowflake), in every prompt and inference log, in every
environment. Snowflake SQL often holds personal data in literals (hard rule 11).
"""
from __future__ import annotations

import re

#: '...' with '' and \' escapes, and $$...$$ (Snowflake) bodies
_LITERAL = re.compile(r"'(?:[^'\\]|\\.|'')*'|\$\$.*?\$\$", re.DOTALL)


def mask_literals(text: str | None) -> str:
    return _LITERAL.sub("'***'", text or "")


__all__ = ["mask_literals"]
