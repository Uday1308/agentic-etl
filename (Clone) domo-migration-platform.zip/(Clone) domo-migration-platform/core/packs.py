"""core.packs - the ``SourcePack`` protocol and the pack registry (ADR 032 section 1).

A pack is a directory ``packs/<platform>/`` whose ``pack.py`` exports ``PACK``, one object
satisfying ``SourcePack``. The pipeline asks the pack - its contract, vocabulary,
expressions, tile registry, caveats, collaborators and profile - and never imports
``core.domo.*`` to learn what a source means.

Dispatch is per ETL from the bundle (``manifest.source.platform``): ``get_pack(platform)``.
A platform with no pack raises ``UnknownSourcePlatform``; the batch runner turns that into
an ``unsupported`` ETL row rather than guessing with the DOMO pack.

Packs are loaded lazily by import path, so importing this module never imports a pack and
a DOMO-only install pays nothing for packs it does not use.
"""
from __future__ import annotations

import importlib
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

#: The default pack when a manifest or request names no platform: today's behaviour.
DEFAULT_PLATFORM = "domo"


@runtime_checkable
class PackContract(Protocol):
    """Raw export -> the standardized document the planner folds."""

    def is_raw_export(self, doc: Any) -> bool: ...

    def to_standardized(self, doc: Any, dataflow_id: str = "") -> dict: ...


@runtime_checkable
class PackVocabulary(Protocol):
    """The source's op vocabulary, as logic parity and the plan renderer need it."""

    source_ops: frozenset[str]
    sink_ops: frozenset[str]
    passthrough_ops: frozenset[str]
    dynamic_column_ops: frozenset[str]
    schema_aware_ops: frozenset[str]

    def op_of(self, node: dict) -> str: ...

    def output_columns(self, node: dict, upstream: list[list[str] | None]) -> list[str] | None: ...

    def columns_read(self, node: dict) -> set[str]: ...

    def reads_in_order(self, node: dict) -> list[tuple[set[str], str]]: ...


@runtime_checkable
class PackExpressions(Protocol):
    """The source expression language: parse, emit for a target dialect, list functions."""

    def translate(self, expression: str, *, dialect: str = "sql") -> Any: ...

    def detect_functions(self, expression: str) -> set[str]: ...


@dataclass(frozen=True)
class PackCaveats:
    """Catalogue entries, prompts and flags a pack contributes (section 3 / 4).

    ``literals_sensitive`` packs (Snowflake) mask string literals in prompts and
    inference logs in every environment; DOMO is not literal-sensitive today.
    """

    literals_sensitive: bool = False
    as_of_column: str = ""
    judge_ids: tuple[str, ...] = ()
    #: caveat ids by action: ``escalate`` / ``block`` / ``review`` (section 4)
    escalate: frozenset[str] = frozenset()
    block: frozenset[str] = frozenset()
    review: frozenset[str] = frozenset()
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class PackProfile:
    """User-facing wording (``api/profile.py`` serves it)."""

    label: str
    unit: str
    units: str
    step: str
    steps: str
    ready: bool = True

    def as_dict(self) -> dict:
        return {"label": self.label, "unit": self.unit, "units": self.units,
                "step": self.step, "steps": self.steps, "ready": self.ready}


@dataclass
class Collaborators:
    """A run's I/O ports. Each declares whether it needs source credentials (section 7)."""

    source_connection: Any = None
    standardizer: Any = None
    table_reader: Any = None
    pipeline_runner: Any = None
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def needs_source_credentials(self) -> bool:
        return any(bool(getattr(p, "needs_source_credentials", False))
                   for p in (self.source_connection, self.standardizer, self.table_reader,
                             self.pipeline_runner, *self.extra.values()) if p is not None)


@runtime_checkable
class SourcePack(Protocol):
    platform: str
    source_dialect: str
    version: str
    contract: PackContract
    vocabulary: PackVocabulary
    expressions: PackExpressions
    caveats: PackCaveats
    profile: PackProfile

    def registry(self, target_dialect: str = "sql") -> Any:
        """The tile/statement renderer registry for ``target_dialect`` (``sql`` / ``pyspark``)."""
        ...

    def collaborators(self, mode: str = "mock") -> Collaborators: ...


class UnknownSourcePlatform(LookupError):
    """No pack is registered for the platform a bundle or request names."""


#: platform -> import path of the module exporting ``PACK``
_PACK_MODULES: dict[str, str] = {"domo": "packs.domo.pack", "snowflake": "packs.snowflake.pack"}
_LOADED: dict[str, SourcePack] = {}
_FACTORIES: dict[str, Callable[[], SourcePack]] = {}


def register_pack(platform: str, factory: Callable[[], SourcePack] | str) -> None:
    """Register a pack by import path (``"packs.x.pack"``) or by factory (tests)."""
    key = platform.strip().lower()
    _LOADED.pop(key, None)
    if isinstance(factory, str):
        _PACK_MODULES[key] = factory
        _FACTORIES.pop(key, None)
    else:
        _FACTORIES[key] = factory


def unregister_pack(platform: str) -> None:
    key = platform.strip().lower()
    _LOADED.pop(key, None)
    _FACTORIES.pop(key, None)
    if key != DEFAULT_PLATFORM:
        _PACK_MODULES.pop(key, None)


def known_platforms() -> list[str]:
    return sorted(set(_PACK_MODULES) | set(_FACTORIES))


def get_pack(platform: str | None = None) -> SourcePack:
    key = (platform or DEFAULT_PLATFORM).strip().lower()
    if key in _LOADED:
        return _LOADED[key]
    if key in _FACTORIES:
        pack = _FACTORIES[key]()
    elif key in _PACK_MODULES:
        pack = importlib.import_module(_PACK_MODULES[key]).PACK
    else:
        raise UnknownSourcePlatform(
            f"no source pack for platform {key!r}; known: {', '.join(known_platforms())}")
    if not isinstance(pack, SourcePack):
        raise TypeError(f"pack for {key!r} does not satisfy SourcePack")
    _LOADED[key] = pack
    return pack


def default_pack() -> SourcePack:
    return get_pack(DEFAULT_PLATFORM)


def missing_parts(pack: Any, parts: Iterable[str] = (
        "platform", "source_dialect", "version", "contract", "vocabulary", "expressions",
        "caveats", "profile", "registry", "collaborators")) -> list[str]:
    """Which protocol members an object lacks (a readable failure for a half-built pack)."""
    return [p for p in parts if not hasattr(pack, p)]


__all__ = ["DEFAULT_PLATFORM", "Collaborators", "PackCaveats", "PackContract", "PackExpressions",
           "PackProfile", "PackVocabulary", "SourcePack", "UnknownSourcePlatform", "default_pack",
           "get_pack", "known_platforms", "missing_parts", "register_pack", "unregister_pack"]
