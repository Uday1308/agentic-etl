"""core.domo.materialize — turn one CTE chain into runnable per-layer scripts.

The classifier decides which nodes become tables. This decides what that means as
SQL, and the difference is not cosmetic: a layer file is something somebody runs.

The rule, stated once
---------------------
A node assigned to bronze, silver or gold becomes a **table**. A node assigned to
``unmaterialized`` never does — it stays a CTE, inlined into whichever materialized
statement needs it, as many times as needed.

So for each materialized node the statement is:

    CREATE OR REPLACE TABLE <its table> AS
    WITH <every unmaterialized ancestor, in dependency order>
    <the node's own body>;

and the walk back **stops at any other materialized node**, which is referenced by
its table name instead of being re-derived. That is what makes the layers a
pipeline rather than three copies of the same query: bronze runs first and writes
tables, silver reads those tables, gold reads silver's.

What was here before
--------------------
The previous output concatenated CTE bodies per layer into a file with no ``WITH``,
no ``CREATE``, no statement terminators and dangling commas between fragments — 70
lines that could not be run, parsed, or explained. Producing something unrunnable
and calling it the medallion split is worse than producing nothing, because it
looks like a deliverable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

#: Materialized layers, in the order they must run. Anything not in here does not
#: become a table.
LAYER_ORDER = ("bronze", "silver", "gold")
UNMATERIALIZED = "unmaterialized"


@dataclass
class Materialized:
    """One node that becomes a table."""
    node: str
    layer: str
    table: str
    inlined: list[str] = field(default_factory=list)     # CTEs folded into it
    reads: list[str] = field(default_factory=list)       # tables it selects from


class MaterializeError(RuntimeError):
    pass


def references(body: str, names) -> set[str]:
    """Which of ``names`` this CTE body reads.

    Matched on word boundaries so ``df_join_1`` does not look like a reference from
    inside ``df_join_10``. Comments are stripped first: the assembler writes the
    node's own name into a ``-- [node: ...]`` marker, and counting that as a
    self-reference would make every node depend on itself.
    """
    stripped = re.sub(r"--[^\n]*", "", body or "")
    return {n for n in names
            if n and re.search(r"(?<![A-Za-z0-9_])" + re.escape(n) + r"(?![A-Za-z0-9_])",
                               stripped)}


@dataclass
class Violation:
    """A node placed below something it reads."""
    node: str
    layer: str
    depends_on: str
    depends_layer: str

    @property
    def message(self) -> str:
        return (f"Downstream cannot be placed over upstream: {self.node} is "
                f"{self.layer}, but it reads {self.depends_on} which is "
                f"{self.depends_layer}.")


def rank(layer: str) -> int:
    """Where a layer sits in run order. Unmaterialized nodes are inlined into
    whoever reads them, so they never constrain anything and rank lowest."""
    return LAYER_ORDER.index(layer) if layer in LAYER_ORDER else -1


def violations(sections: dict[str, str], assignment: dict[str, str]) -> list[Violation]:
    """Every place the assignment contradicts the lineage.

    The invariant: **a node's layer must be at least the layer of everything it
    reads.** Bronze runs, then silver, then gold, so a silver table reading a gold
    table references something that does not exist yet — the script does not fail
    at generation, it fails at 3am on the cluster.

    Unmaterialized nodes are transparent: they are inlined, so a node reading one
    inherits that CTE's own dependencies rather than depending on it.
    """
    names = set(sections)
    deps = {n: references(b, names) - {n} for n, b in sections.items()}

    def materialized_deps(node: str, seen: frozenset = frozenset()) -> set[str]:
        """Through unmaterialized nodes, to the tables actually read."""
        out: set[str] = set()
        for parent in deps.get(node, ()):
            if parent in seen:
                continue
            if assignment.get(parent) in LAYER_ORDER:
                out.add(parent)
            else:
                out |= materialized_deps(parent, seen | {node, parent})
        return out

    found: list[Violation] = []
    for node, layer in sorted(assignment.items()):
        if layer not in LAYER_ORDER:
            continue
        for dep in sorted(materialized_deps(node)):
            if rank(assignment[dep]) > rank(layer):
                found.append(Violation(node, layer, dep, assignment[dep]))
    return found


def promote(sections: dict[str, str], assignment: dict[str, str]) -> dict[str, str]:
    """The nearest assignment that satisfies the invariant, by raising layers only.

    Raising rather than lowering, because a node was put in a layer for a reason
    and demoting its dependency would silently undo that. Repeated to a fixpoint:
    promoting one node can push its own readers up too.
    """
    fixed = dict(assignment)
    for _ in range(len(fixed) + 1):
        bad = violations(sections, fixed)
        if not bad:
            return fixed
        for v in bad:
            fixed[v.node] = LAYER_ORDER[max(rank(v.layer), rank(v.depends_layer))]
    raise MaterializeError(
        "could not satisfy the layer invariant; the CTE graph may contain a cycle")


def _topo(selected: set[str], deps: dict[str, set[str]]) -> list[str]:
    """Dependency order within one statement. Deterministic, so re-running the
    generator produces byte-identical SQL and a diff means something changed."""
    out, seen = [], set()

    def visit(name: str, stack: frozenset = frozenset()) -> None:
        if name in seen or name not in selected:
            return
        if name in stack:
            raise MaterializeError(
                f"cycle through {name!r}; a CTE chain cannot be circular")
        for parent in sorted(deps.get(name, ())):
            visit(parent, stack | {name})
        seen.add(name)
        out.append(name)

    for name in sorted(selected):
        visit(name)
    return out


def plan(sections: dict[str, str], assignment: dict[str, str], *,
         table_of, dataflow_id: str = "") -> dict[str, list[Materialized]]:
    """Which nodes become tables, what each inlines, and what each reads.

    ``table_of(node) -> str`` names the table a materialized node writes. Injected
    because naming is a policy decision (catalog, schema, medallion prefix) and
    this module should not own one.
    """
    names = set(sections)
    unknown = sorted(n for n in assignment if n not in names)
    if unknown:
        raise MaterializeError(
            f"{len(unknown)} assigned node(s) are not in the SQL: {unknown[:4]}. "
            f"An assignment that names a node nothing emitted cannot be materialized.")

    bad = violations(sections, assignment)
    if bad:
        raise MaterializeError(
            f"{len(bad)} layer-order violation(s); the scripts would reference "
            f"tables that do not exist yet. First: {bad[0].message}")

    deps = {name: references(body, names) - {name}
            for name, body in sections.items()}
    materialized = {n for n, layer in assignment.items() if layer in LAYER_ORDER}

    out: dict[str, list[Materialized]] = {layer: [] for layer in LAYER_ORDER}
    for node in sorted(materialized):
        # Walk back, stopping at any OTHER materialized node - that one is a table
        # by the time this statement runs, so it is read rather than re-derived.
        inline: set[str] = set()
        reads: set[str] = set()
        stack = list(deps.get(node, ()))
        while stack:
            parent = stack.pop()
            if parent in materialized:
                reads.add(parent)
                continue
            if parent in inline:
                continue
            inline.add(parent)
            stack.extend(deps.get(parent, ()))
        out[assignment[node]].append(Materialized(
            node=node, layer=assignment[node], table=table_of(node),
            inlined=_topo(inline, deps), reads=sorted(reads)))

    # Within a layer, a table that reads another table of the SAME layer must be
    # written second. Across layers the file order already guarantees it.
    for layer, items in out.items():
        by_node = {m.node: m for m in items}
        order = _topo({m.node for m in items},
                      {m.node: {r for r in m.reads if r in by_node} for m in items})
        out[layer] = [by_node[n] for n in order]
    return out


def render_layer(layer: str, items: list[Materialized], sections: dict[str, str],
                 assignment: dict[str, str], *, table_of,
                 dataflow_id: str = "") -> str:
    """One runnable script for one layer.

    Statement-terminated, in dependency order, with the CTE references that point
    at a materialized node rewritten to that node's table name. Running this file
    top to bottom after the previous layer's is the whole contract.
    """
    if not items:
        return (f"-- {layer}: nothing is assigned to this layer for dataflow "
                f"{dataflow_id}.\n")

    lower = LAYER_ORDER[:LAYER_ORDER.index(layer)]
    head = [
        f"-- Medallion layer: {layer.upper()}  ·  DOMO dataflow {dataflow_id}",
        f"-- {len(items)} table(s), in dependency order. Run top to bottom"
        + (f", after the {' and '.join(lower)} script(s)." if lower else "."),
        "--",
        "-- Each statement inlines only the CTEs that are NOT materialized; every",
        "-- materialized dependency is read as a table, which is what makes these",
        "-- layers a pipeline rather than three copies of the same query.",
        "",
    ]

    body: list[str] = []
    for m in items:
        rewrite = {n: table_of(n) for n in m.reads}
        # A section already reads `name AS ( ... )`, which is exactly what a WITH
        # clause needs - so it is used as-is rather than wrapped a second time.
        ctes = [_rewrite(sections[name], rewrite) for name in m.inlined]
        stmt = [f"-- {m.node}"]
        if m.reads:
            stmt.append(f"--   reads: {', '.join(rewrite[r] for r in m.reads)}")
        stmt.append(f"CREATE OR REPLACE TABLE {m.table} AS")
        if ctes:
            stmt.append("WITH " + "\n, ".join(ctes))
        # ...but the node being materialized is the statement's own SELECT, so
        # its CTE wrapper comes off. Leaving it on produced
        # `CREATE TABLE t AS x AS ( SELECT ... )`, which is not SQL.
        stmt.append(_unwrap(m.node, _rewrite(sections[m.node], rewrite)))
        body.append("\n".join(stmt) + "\n;")
    return "\n".join(head) + "\n\n".join(body) + "\n"


def _rewrite(body: str, rewrite: dict[str, str]) -> str:
    """Point a CTE reference at a table instead. Also drops the node markers: they
    address a CTE inside one artifact, and this is a different statement.

    The trailing separator goes too. A section is the text between one ``[node:]``
    marker and the next, so it carries the comma that separated it from the
    following CTE **in the original artifact** - and this statement has its own,
    different CTE list. Leaving it produced ``)\\n,\\n, next AS (`` between every
    pair and a ``,`` immediately before the closing ``SELECT``: two syntax errors
    per statement, in a file whose entire purpose is being runnable.
    """
    out = re.sub(r"^--\s*\[/?node:[^\]]*\][^\n]*\n?", "", body or "", flags=re.MULTILINE)
    for name, table in rewrite.items():
        out = re.sub(r"(?<![A-Za-z0-9_])" + re.escape(name) + r"(?![A-Za-z0-9_])",
                     table, out)
    return out.strip().rstrip(",").rstrip()


def _unwrap(name: str, body: str) -> str:
    """``name AS ( <select> )`` -> ``<select>``, dedented.

    Scans for the BALANCED closing paren rather than assuming the text ends with
    one. The final CTE's section runs to end of file, so it carries the
    artifact's closing ``SELECT * FROM <final>`` after the wrapper - trailing
    text that has to be dropped, not treated as proof the wrapper is absent.

    Unwrapped text passes through untouched.
    """
    text = body.strip()
    opener = re.match(re.escape(name) + r"\s+AS\s*\(", text)
    if not opener:
        return text
    depth, i = 1, opener.end()
    while i < len(text) and depth:
        depth += (text[i] == "(") - (text[i] == ")")
        i += 1
    if depth:
        return text                      # unbalanced; leave it visibly wrong
    inner = text[opener.end():i - 1].strip("\n").rstrip()
    rows = inner.splitlines()
    pad = min((len(r) - len(r.lstrip()) for r in rows if r.strip()), default=0)
    return "\n".join(r[pad:] if r.strip() else r for r in rows).strip()


def _indent(text: str) -> str:
    return "\n".join("    " + line if line.strip() else line
                     for line in text.splitlines())


def render_all(sections: dict[str, str], assignment: dict[str, str], *, table_of,
               dataflow_id: str = "") -> dict[str, str]:
    """``{layer: script}`` for every materialized layer."""
    planned = plan(sections, assignment, table_of=table_of, dataflow_id=dataflow_id)
    return {layer: render_layer(layer, items, sections, assignment,
                                table_of=table_of, dataflow_id=dataflow_id)
            for layer, items in planned.items()}


__all__ = ["LAYER_ORDER", "UNMATERIALIZED", "Materialized", "MaterializeError",
           "Violation", "promote", "rank", "violations",
           "plan", "references", "render_all", "render_layer"]
