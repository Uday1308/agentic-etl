"""core.domo.observability — Delta telemetry writers (guide §8).

>>> PLACEHOLDER <<<  Owned by the observability author. Interface + concrete Delta
writer; the ABC is what lets tests inject an in-memory fake. Replace the concrete
writer with the real implementation.
"""
from __future__ import annotations

import abc
from datetime import datetime

from pydantic import BaseModel


class LlmCallRow(BaseModel):
    obs_run_id: str
    thread_id: str
    dataflow_id: str
    agent: str
    node: str
    role: str
    model: str
    pool: str
    prompt_hash: str
    prompt_text: str | None = None
    response_text: str | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: int = 0
    retries: int = 0
    cost: float | None = None
    confidence: float | None = None
    iteration: int = 0
    status: str = "ok"
    ts: datetime = datetime(2024, 1, 1)


class NodeRow(BaseModel):
    obs_run_id: str
    thread_id: str
    agent: str
    node: str
    iteration: int = 0
    status: str = "success"
    duration_ms: int = 0
    hitl_wait_ms: int = 0
    ts: datetime = datetime(2024, 1, 1)


class ObservabilityWriter(abc.ABC):
    @abc.abstractmethod
    def record_llm_call(self, row: LlmCallRow) -> None: ...
    @abc.abstractmethod
    def record_node(self, row: NodeRow) -> None: ...


class DeltaObservabilityWriter(ObservabilityWriter):
    """Concrete Delta writer. Two responsibilities kept deliberately separate so the
    first is testable without Spark:

    1. **Redaction (pure).** ``_persistable`` applies the ``capture_text`` flag —
       full prompt/response text on (default dev), blanked in prod — while the
       ``prompt_hash`` is *always* kept so calls can still be correlated.
    2. **Append (side effect).** ``_append`` writes one row to Delta. It goes through
       an injectable ``sink`` seam: production leaves ``sink=None`` and a real Spark
       Delta append is used (lazy import); tests inject a recording sink and assert
       the redaction contract with no cluster involved.

    Keep this seam in the real implementation — it is what makes the writer unit
    testable.
    """

    def __init__(self, *, capture_text: bool = True,
                 llm_table: str = "obs_llm_calls", node_table: str = "obs_nodes",
                 sink=None, spark=None, mask_literals: bool = False) -> None:
        self._capture_text = capture_text
        #: ADR 032 section 3: packs with ``literals_sensitive`` mask string literals in
        #: prompt/response text in EVERY environment; capture_text then only decides
        #: whether the masked text is kept.
        self._mask_literals = mask_literals
        self._llm_table = llm_table
        self._node_table = node_table
        self._sink = sink            # callable(table: str, row: dict) -> None
        self._spark = spark

    @classmethod
    def for_pack(cls, pack, **kwargs) -> "DeltaObservabilityWriter":
        """The writer for a run of ``pack``: literal masking follows ``pack.caveats.literals_sensitive``."""
        caveats = getattr(pack, "caveats", None)
        kwargs.setdefault("mask_literals", bool(getattr(caveats, "literals_sensitive", False)))
        return cls(**kwargs)

    # -- pure: the redaction contract (no Spark) --------------------------- #
    def _persistable(self, row: LlmCallRow) -> dict:
        d = row.model_dump(mode="json")
        if self._mask_literals:
            from core.literals import mask_literals

            for k in ("prompt_text", "response_text"):
                if d.get(k):
                    d[k] = mask_literals(d[k])
        if not self._capture_text:
            d["prompt_text"] = None
            d["response_text"] = None      # hash is always retained for correlation
        return d

    def record_llm_call(self, row: LlmCallRow) -> None:
        self._append(self._llm_table, self._persistable(row))

    def record_node(self, row: NodeRow) -> None:
        self._append(self._node_table, row.model_dump(mode="json"))

    # -- side effect behind a seam ----------------------------------------- #
    def _append(self, table: str, row: dict) -> None:
        if self._sink is not None:
            self._sink(table, row)
            return
        spark = self._session()
        spark.createDataFrame([row]).write.format("delta").mode("append").saveAsTable(table)

    def _session(self):
        if self._spark is not None:
            return self._spark
        from pyspark.sql import SparkSession
        self._spark = SparkSession.builder.getOrCreate()
        return self._spark
