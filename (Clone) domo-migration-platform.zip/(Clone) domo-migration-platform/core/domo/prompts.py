""">>> PLACEHOLDER <<<  core.domo.prompts

Owned by the core team. Priority-layered prompt assembly and hard-constraint checking.

Layer priority, highest first:
    P1  human feedback + hard constraints   (a person said this)
    P2  the run's user prompt
    P3  evaluator issues from the previous iteration
    P4  the agent's base prompt (and any approved plan context)
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from core.domo.schemas import HumanFeedback, Issue


class PromptLayers(BaseModel):
    model_config = ConfigDict(frozen=True)

    base: str = ""
    user_prompt: str = ""
    human_feedback: list[HumanFeedback] = Field(default_factory=list)
    agent_feedback: list[Issue] = Field(default_factory=list)
    hard_constraints: list[str] = Field(default_factory=list)


class PromptAssembler:
    """Renders layers into one prompt, highest priority first so later layers cannot
    quietly override what a human asked for."""

    def assemble(self, layers: PromptLayers) -> str:
        parts: list[str] = []
        if layers.hard_constraints or layers.human_feedback:
            parts.append("[P1 HUMAN FEEDBACK — highest precedence, overrides every layer below]")
            for c in layers.hard_constraints:
                parts.append(f"  HARD CONSTRAINT: {c}")
            for fb in layers.human_feedback:
                if fb.freeform:
                    parts.append(f"  {fb.freeform}")
                for c in fb.hard_constraints:
                    parts.append(f"  HARD CONSTRAINT: {c}")
        if layers.user_prompt:
            parts.append(f"[P2 USER PROMPT]\n{layers.user_prompt}")
        if layers.agent_feedback:
            parts.append("[P3 ISSUES FROM THE PREVIOUS ITERATION]")
            for i in layers.agent_feedback:
                parts.append(f"  ({i.severity.value}) {i.message} — {i.detail} [{i.ref}]")
        if layers.base:
            parts.append(f"[P4 TASK — lowest precedence]\n{layers.base}")
        return "\n\n".join(parts)


class HardConstraintChecker:
    """Reports which declared hard constraints the output appears to violate.

    Violations are RETURNED on the result, never raised — the caller decides whether
    a violation blocks or feeds the next iteration.
    """

    def check(self, text: str, constraints: list[str]) -> list[str]:
        """Return the constraints the output appears to violate.

        A constraint is treated as a forbidden token: if the literal token appears in
        the output, the constraint is violated. Returned, never raised — the caller
        decides whether that blocks or feeds the next iteration.
        """
        low = (text or "").lower()
        return [c for c in (constraints or []) if c.lower() in low]
