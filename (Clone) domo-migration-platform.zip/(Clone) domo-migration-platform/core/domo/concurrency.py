""">>> PLACEHOLDER <<<  core.domo.concurrency

Owned by the core team. Named semaphore pools with a global ceiling, so one agent
fanning out cannot starve the rest of the graph.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager


class ConcurrencyManager:
    def __init__(self, pools: dict[str, int], global_ceiling: int = 32) -> None:
        self._limits = dict(pools)
        self._ceiling = global_ceiling
        self._sems: dict[str, asyncio.Semaphore] = {}
        self._global: asyncio.Semaphore | None = None
        self.in_flight: dict[str, int] = {}
        self.peak: dict[str, int] = {}

    def _sem(self, pool: str) -> asyncio.Semaphore:
        if pool not in self._sems:
            self._sems[pool] = asyncio.Semaphore(self._limits.get(pool, self._ceiling))
        return self._sems[pool]

    @asynccontextmanager
    async def acquire(self, pool: str = "default"):
        if self._global is None:
            self._global = asyncio.Semaphore(self._ceiling)
        async with self._global, self._sem(pool):
            self.in_flight[pool] = self.in_flight.get(pool, 0) + 1
            self.peak[pool] = max(self.peak.get(pool, 0), self.in_flight[pool])
            try:
                yield
            finally:
                self.in_flight[pool] -= 1
