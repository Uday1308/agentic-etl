""">>> PLACEHOLDER <<<  core.domo.models

Owned by the core team. Reproduces the documented role/endpoint registry interface.

NOTE for the core owner: the real ModelRegistry.resolve does ``EndpointSpec(**binding)``
and raises if handed an EndpointSpec. Making it tolerant —
``spec if isinstance(spec, EndpointSpec) else EndpointSpec(**spec)`` — removes a sharp
edge callers keep hitting.
"""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Role(str, Enum):
    GENERATOR = "generator"
    EVALUATOR = "evaluator"
    CLASSIFIER = "classifier"


class EndpointSpec(BaseModel):
    """Where a role's calls go, plus any per-endpoint parameters forwarded to the
    serving client (temperature, response_format, ...)."""
    model_config = ConfigDict(frozen=True)

    endpoint: str
    params: dict[str, Any] = Field(default_factory=dict)
    timeout_s: int = 120


class ModelRegistry:
    """Resolves (role, environment) -> EndpointSpec from a nested binding map."""

    def __init__(self, bindings: dict[str, dict[str, Any]]) -> None:
        self._b = bindings

    def resolve(self, role: Role | str, environment: str) -> EndpointSpec:
        key = role.value if isinstance(role, Role) else str(role)
        env = self._b.get(environment)
        if env is None:
            raise KeyError(f"no model bindings for environment {environment!r}")
        spec = env.get(key)
        if spec is None:
            raise KeyError(f"no binding for role {key!r} in environment {environment!r}")
        return spec if isinstance(spec, EndpointSpec) else EndpointSpec(**spec)
