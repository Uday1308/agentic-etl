"""core.domo.tiles — render one DOMO tile, in either dialect.

The SQL renderers emit **CTE bodies**: a bare ``SELECT ... FROM ...`` with no
``CREATE OR REPLACE TABLE`` prefix and no trailing semicolon. Composition is the
assembler's job, and materialization is a deliberate human decision — the generated
artifact is a readable chain of CTEs ending in a final SELECT, so it can be run as-is,
inspected, and given a materialization prefix when someone is ready.

Every renderer is deterministic. An unrecognised tile produces an unresolved
``RenderResult`` rather than a guess, so only the genuinely unknown escalates.

Defensive choices, each earned from a real failure:

* casts always state precision — a bare ``DECIMAL`` truncates like ``DecimalType()``;
* joins alias both sides and drop the duplicated right-hand keys, because DOMO
  tolerates duplicate column names across inputs and SQL does not;
* string comparisons strip DOMO's exported leading-quote artifact;
* ``FIRST``/``LAST`` without an explicit order is flagged LOW, not silently emitted.
"""
from __future__ import annotations

import re
from typing import Any

from core.domo.expr import Emitted, numeric_operand, translate
from core.domo.naming import column as _san
from core.domo.naming import quoted
from core.domo.tiles_pyspark import (  # noqa: F401  (re-exported for the PySpark path)
    DEFAULT_RENDERERS as PYSPARK_RENDERERS,
)
from core.domo.tiles_pyspark import RenderResult, TileRegistry

#: DOMO exports carry a leading apostrophe on some values and scientific-notation
#: suffixes. Comparisons must strip both or nothing matches.
_CLEAN = "regexp_replace(regexp_replace(CAST({col} AS STRING), \"^'\", ''), 'E-\\\\d+$', '')"


def first_of(d: dict, *keys, default=None):
    """Read the first key present with a non-empty value.

    DOMO's discovery export uses several spellings for the same thing depending on the
    tile and the exporter version — ``selectedColumns`` vs ``columns``, ``joinKeys``
    with ``leftColumn`` vs ``left``, ``groupByColumns`` vs ``group_by``, ``fields`` vs
    ``columns``. Reading through this helper keeps the renderers tolerant of all of
    them instead of guessing one.
    """
    for k in keys:
        v = (d or {}).get(k)
        if v not in (None, "", [], {}):
            return v
    return default


def q(name: str) -> str:
    """Quote a column for the target, honouring the active identifier policy.

    See ``core.domo.naming``: in ``delta_safe`` mode the name is sanitized the same
    way your ingestion sanitized it, so the generated SQL references columns that
    actually exist. Quoting happens exactly once either way.
    """
    return quoted(name)


def lit(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, str):
        return "'" + v.replace("'", "''") + "'"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return str(v)


#: A value DOMO stores as an ISO datetime, with or without the T separator.
_TS_VALUE = re.compile(
    r"^\s*\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?"
    r"(Z|[+-]\d{2}:?\d{2})?\s*$"
)


def looks_like_timestamp(value) -> bool:
    """Whether a filter's comparison value is an ISO datetime."""
    return isinstance(value, str) and bool(_TS_VALUE.match(value))


def ts_literal(value: str) -> str:
    """A SQL TIMESTAMP literal built from a DOMO datetime string.

    DOMO writes the ISO form with a T separator; Spark's TIMESTAMP literal wants
    a space. Any trailing zone marker is dropped, matching how the value was
    rendered when DOMO evaluated the filter.

    This exists because comparing a timestamp column as TEXT does not work:
    CAST(ts AS STRING) renders '2026-03-30 14:18:07' while the DOMO literal says
    '2026-03-30T14:18:07', so the two never match and the filter silently does
    nothing. Comparing natively is both correct and faster.
    """
    text = str(value).strip()
    text = re.sub(r"^(\d{4}-\d{2}-\d{2})T", r"\1 ", text)
    text = re.sub(r"(Z|[+-]\d{2}:?\d{2})$", "", text).strip()
    return "TIMESTAMP " + lit(text)


def sql_type(domo_type: str) -> tuple[str, str | None]:
    """Map a DOMO type to a Databricks SQL type. Decimal ALWAYS carries precision."""
    t = (domo_type or "").upper()
    if t in ("DECIMAL", "NUMERIC", "MONEY", "CURRENCY"):
        # DOMO's own output table renders a DECIMAL-cast column as DOUBLE, verified
        # against dev_test.domo_output. Emitting DECIMAL(18,2) instead is a type
        # mismatch AND changes max/sum comparisons, so DOUBLE is the faithful mapping.
        # Use extra precision deliberately if you want exact decimal arithmetic —
        # but then expect a type difference against DOMO.
        return "DOUBLE", None
    if t in ("DOUBLE", "FLOAT", "REAL"):
        return "DOUBLE", None
    if t in ("LONG", "BIGINT", "INTEGER", "INT"):
        return "BIGINT", None
    if t == "DATE":
        return "DATE", None
    if t in ("DATETIME", "TIMESTAMP"):
        return "TIMESTAMP", None
    return "STRING", None


def op_of(node: dict) -> str:
    """A tile's type, normalized exactly as ``TileRegistry.find`` normalizes it.

    Same rule, deliberately: DOMO writes ``alter_columns``, ``ALTER COLUMNS`` and
    ``AlterColumns`` for one tile. If this normalized differently from the registry,
    a tile would render one way and be classified another — which is how the column
    tracer silently skipped every ``alter_columns`` tile until this was aligned.
    """
    raw = str(node.get("type") or node.get("operation_type") or "")
    return raw.upper().replace("_", "").replace(" ", "")


#: Tiles that change rows but never the column set, so their output columns are their
#: input's. Enough to trace a schema back to the last tile that states one outright.
PASSTHROUGH_OPS = frozenset({
    "FILTER", "FILTERROWS", "SORT", "ORDERBY", "ORDER",
    # Row filters and in-place edits: the column set survives untouched. Leaving
    # these out did not make the tracer cautious, it made it BLIND - a tile whose
    # columns cannot be derived stops the walk for everything downstream of it.
    "DEDUPE", "UNIQUE", "REMOVEDUPLICATES",
    "TEXT", "TEXTFORMATTING",
    "SINK", "WRITE", "OUTPUT", "PUBLISHTOVAULT",
})

#: Tiles whose escalation reason is a column set DOMO resolves at run time.
DYNAMIC_COLUMN_OPS = frozenset({"UNPIVOT", "NORMALIZEALL", "DYNAMICUNPIVOT"})

#: Tiles DOMO matches by column NAME where SQL matches by POSITION. They need each
#: branch's column list to be projected onto a common shape.
NAME_ALIGNED_OPS = frozenset({"UNION", "APPEND", "APPENDROWS"})

#: Tiles that cannot be rendered correctly without knowing their input's columns.
#: The tracer injects ``properties["input_columns"]`` (one list per input) for these.
#: A formula needs it to tell "add a column" from "replace a column": DOMO allows both
#: and writes them identically, and emitting the wrong one yields two columns with one
#: name - legal at that step, AMBIGUOUS_REFERENCE at the next.
SCHEMA_AWARE_OPS = NAME_ALIGNED_OPS | frozenset({"FORMULA", "ADDFORMULA", "CALCULATOR"})


def _dedup(names: list[str]) -> list[str]:
    return list(dict.fromkeys(n for n in names if n))


def output_columns(node: dict, upstream: list[list[str] | None]) -> list[str] | None:
    """The columns a tile emits, in DOMO's ORIGINAL spelling, or None if unknowable.

    ``upstream`` is each input's own column list (None where that input is itself
    unknown). Most tiles only know their output relative to their input, so this is
    recursive by nature — see ``render.resolve_dynamic_columns`` for the walk.

    Original spelling matters and is the reason this returns DOMO names rather than
    ingested identifiers: a dynamic unpivot writes the column NAME into its key column,
    so that name becomes *data*. DOMO calls it ``RMB/CNY``; ingestion may have stored
    the identifier differently. Emit the wrong one and every downstream join on that key
    silently misses — 8099 joins on exactly that.

    None means "escalate". A guess here becomes wrong data with no symptom, so every
    branch that cannot be derived says so instead.
    """
    op = op_of(node)
    p = node.get("properties") or {}
    first = upstream[0] if upstream else None

    # -- tiles that state their output outright, whatever the input ------------
    if op in ("SELECT", "SELECTCOLUMNS", "PROJECT"):
        out: list[str] = []
        for c in first_of(p, "selectedColumns", "columns", default=[]) or []:
            if isinstance(c, str):
                out.append(c)
                continue
            name = first_of(c, "column_normalised", "column", "name", default="")
            alias = first_of(c, "rename", "output_name", "alias")
            out.append(alias or name)
        return _dedup(out) or None

    if op in ("GROUPBY", "AGGREGATE", "SUMMARIZE"):
        group = first_of(p, "groupByColumns_normalised", "groupByColumns",
                         "group_by_normalised", "group_by", "groupBy", "keys",
                         default=[]) or []
        aggs = first_of(p, "aggregations", "aggs", default=[]) or []
        if not aggs:
            return None
        names = list(group)
        for a in aggs:
            col = first_of(a, "inputColumn_normalised", "inputColumn", "column", default="")
            names.append(first_of(a, "outputColumn_normalised", "outputColumn", "alias",
                                  default=col))
        return _dedup(names) or None

    # -- tiles whose output is their input, unchanged ---------------------------
    if op in PASSTHROUGH_OPS:
        return first
    if op in ("UNION", "APPEND", "APPENDROWS"):
        # DOMO's append matches by NAME, so the output is the union of every input's
        # columns, ordered by first appearance. Approximating it with the first input
        # would under-report whenever the branches differ — which is the normal case.
        if not upstream or any(u is None for u in upstream):
            return None
        return _dedup([c for cols in upstream for c in cols]) or None

    # -- tiles that transform their input's column list -------------------------
    if first is None:
        return None

    if op in ("FORMULA", "ADDFORMULA", "CALCULATOR"):
        names = list(first)
        for e in p.get("expressions") or []:
            name = first_of(e, "outputColumn_normalised", "outputColumn", "fieldName",
                            "name", "column", default="")
            if name:
                names.append(name)          # _dedup keeps an in-place overwrite single
        return _dedup(names) or None

    if op in ("ALTERCOLUMNS", "ALTER", "CHANGECOLUMNS", "CAST"):
        changes = first_of(p, "fields", "column_changes", "changes", "columns",
                           default=[]) or []
        renames = {}
        for c in changes:
            name = first_of(c, "name", "column", default="")
            renames[name] = first_of(c, "rename", "new_name", "output_name", default=name)
        # the renderer emits `* EXCEPT (touched)` then the touched ones, in that order
        untouched = [c for c in first if c not in renames]
        return _dedup(untouched + [renames[c] for c in renames]) or None

    if op in DYNAMIC_COLUMN_OPS:
        # An unpivot's output is stated outright: the id columns it keeps, plus the
        # two it creates. The VALUE columns it consumes are the run-time-resolved
        # part (see resolve_dynamic_columns); what it EMITS never was.
        ids = first_of(p, "idFields", "id_columns", "keep", default=[]) or []
        key = first_of(p, "keyField", "key_column", default="")
        value = first_of(p, "valueField", "value_column", default="")
        return _dedup([*ids, key, value]) or None

    if op in ("RANK", "RANKWINDOW", "WINDOWACTION", "WINDOW"):
        added = [first_of(a, "name", "outputColumn", default="")
                 for a in first_of(p, "additions", "windows", default=[]) or []]
        return _dedup(list(first) + added) or None

    if op in ("STRINGCALCULATOR", "STRINGCALC"):
        made = [first_of(c, "fieldName", "outputColumn", "name", default="")
                for c in first_of(p, "calculations", "calcs", default=[]) or []]
        return _dedup(list(first) + made) or None

    if op in ("JOIN", "JOINDATA", "MERGE"):
        right = upstream[1] if len(upstream) > 1 else None
        if right is None:
            return None
        changes = first_of(p, "columnChanges", "removed_cols", default=[]) or []
        drops = {first_of(c, "actual_name", "name", default="") for c in changes
                 if c.get("remove") is True or "actual_name" in c}
        if not any(drops):
            keys = first_of(p, "joinKeys", "keys", default=[]) or []
            drops = {first_of(k, "rightColumn_normalised", "rightColumn", "right",
                              default="") for k in keys}
        return _dedup(list(first) + [c for c in right if c not in drops]) or None

    return None


def declared_output_columns(node: dict) -> list[str] | None:
    """Columns a tile states without needing to know its input. Kept for callers that
    have no upstream context."""
    return output_columns(node, [])


class SqlTileRenderer:
    """Base class. ``render`` returns the CTE body for this tile."""
    op_types: tuple[str, ...] = ()

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        raise NotImplementedError

    @staticmethod
    def _expr(raw: str, r: RenderResult) -> str:
        e: Emitted = translate(raw, dialect="sql")
        r.notes.extend(e.notes)
        r.functions_used |= e.functions_used
        r.unresolved.extend(e.unsupported)
        return e.code


class SqlDatasetTile(SqlTileRenderer):
    op_types = ("DATASET", "DATA", "SOURCE", "INPUT")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        p = node.get("properties", {}) or {}
        table = first_of(p, "source_table", "table", "dataset_name", "datasetName",
                         default="")
        if not table:
            r.notes.append("source table not stated in the tile; bind it before running")
            r.confidence = "MEDIUM"
        r.code = f"SELECT * FROM {table}"
        return r


class SqlFilterTile(SqlTileRenderer):
    op_types = ("FILTER", "FILTERROWS", "FILTER ROWS")

    #: DOMO's real operator codes, as they appear in discovery properties
    OPS = {
        "EQ": "=", "EQUALS": "=", "EQUAL": "=", "=": "=",
        "NE": "<>", "NEQ": "<>", "NOT_EQUALS": "<>", "NOT_EQUAL": "<>", "!=": "<>", "<>": "<>",
        "GT": ">", "GREATER_THAN": ">", ">": ">",
        "GTE": ">=", "GE": ">=", "GREATER_OR_EQUAL": ">=", ">=": ">=",
        "LT": "<", "LESS_THAN": "<", "<": "<",
        "LTE": "<=", "LE": "<=", "LESS_OR_EQUAL": "<=", "<=": "<=",
    }
    #: operators that are not a simple binary comparison
    SPECIAL = {"CT": "contains", "CONTAINS": "contains",
               "NCT": "not_contains", "NOT_CONTAINS": "not_contains",
               "SW": "starts", "STARTS_WITH": "starts",
               "EW": "ends", "ENDS_WITH": "ends",
               "IN": "in", "IS_IN": "in", "NOT_IN": "not_in", "NIN": "not_in",
               "IS_NULL": "null", "IS_EMPTY": "null", "EMPTY": "null",
               "NL": "null", "IS_NOT_NULL": "not_null", "NOT_EMPTY": "not_null",
               "NN": "not_null"}

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}

        # A "raw" filter carries a Beast Mode expression instead of structured
        # conditions — cms_8099's Filter Rows 1 is exactly this shape.
        raw = p.get("raw") or {}
        raw_exprs = [f.get("expression") for f in (raw.get("filterList") or [])
                     if f.get("expression")]
        inline = first_of(p, "formula", "expression")
        if inline:
            raw_exprs.append(inline)
        if raw_exprs:
            parts = [self._expr(e, r) for e in raw_exprs]
            parts = [x for x in parts if x]
            if parts:
                r.code = f"SELECT *\nFROM {src}\nWHERE " + "\n  AND ".join(parts)
                return r

        # structured conditions live either at the top level or inside filterGroups
        conds = list(first_of(p, "conditions", "filters", default=[]) or [])
        combine = (p.get("topLevelCombinator") or p.get("combine") or "AND").upper()
        if not conds:
            groups = p.get("filterGroups") or []
            for g in groups:
                conds.extend(g.get("conditions") or [])
                combine = (g.get("groupCombinator") or combine).upper()
        if not conds:
            r.unresolved.append("filter tile has neither conditions nor a raw expression")
            return r
        parts = []
        for c in conds:
            col = first_of(c, "column_normalised", "column", default="")
            op = str(c.get("operator") or "EQ").upper()
            val = c.get("value")

            # A timestamp column has to be compared as a timestamp. Rendering it
            # as text puts a space where DOMO's literal has a T, so a text
            # comparison never matches and the filter quietly does nothing.
            native_ts = looks_like_timestamp(val)
            operand = q(col) if native_ts else _CLEAN.format(col=q(col))
            rhs = ts_literal(val) if native_ts else lit(val)

            if op in self.OPS:
                sql_op = self.OPS[op]
                if sql_op == "<>":
                    # DOMO keeps rows where the value is null on a "not equal"
                    # filter. SQL does not: NULL <> x is NULL, so the row is
                    # dropped. Without this guard one not-equals can empty a table.
                    parts.append(f"({q(col)} IS NULL OR {operand} <> {rhs})")
                    r.notes.append(
                        f"{col}: not-equals is null-safe — DOMO retains null rows, "
                        f"plain SQL <> would drop them")
                else:
                    parts.append(f"{operand} {sql_op} {rhs}")
                if native_ts:
                    r.notes.append(
                        f"{col}: compared as a TIMESTAMP, not as text — the column "
                        f"must actually be a timestamp in the source table")
                continue

            kind = self.SPECIAL.get(op)
            cleaned = _CLEAN.format(col=q(col))
            if kind == "contains":
                parts.append(f"{cleaned} LIKE {lit('%' + str(val) + '%')}")
            elif kind == "not_contains":
                parts.append(f"({q(col)} IS NULL OR "
                             f"{cleaned} NOT LIKE {lit('%' + str(val) + '%')})")
                r.notes.append(f"{col}: not-contains is null-safe, matching DOMO")
            elif kind == "starts":
                parts.append(f"{cleaned} LIKE {lit(str(val) + '%')}")
            elif kind == "ends":
                parts.append(f"{cleaned} LIKE {lit('%' + str(val))}")
            elif kind == "in":
                items = val if isinstance(val, (list, tuple)) else [val]
                rendered = ", ".join(
                    ts_literal(v) if looks_like_timestamp(v) else lit(v) for v in items
                )
                parts.append(f"{q(col)} IN ({rendered})")
            elif kind == "not_in":
                items = val if isinstance(val, (list, tuple)) else [val]
                rendered = ", ".join(
                    ts_literal(v) if looks_like_timestamp(v) else lit(v) for v in items
                )
                parts.append(f"({q(col)} IS NULL OR {q(col)} NOT IN ({rendered}))")
                r.notes.append(f"{col}: NOT IN is null-safe, matching DOMO")
            elif kind == "null":
                parts.append(f"{q(col)} IS NULL")
            elif kind == "not_null":
                parts.append(f"{q(col)} IS NOT NULL")
            else:
                r.unresolved.append(f"filter operator {op}")
        if r.unresolved:
            return r
        joiner = "\n   OR " if combine == "OR" else "\n  AND "
        r.code = f"SELECT *\nFROM {src}\nWHERE {joiner.join(parts)}"
        return r


class SqlFormulaTile(SqlTileRenderer):
    op_types = ("FORMULA", "ADDFORMULA", "ADD FORMULA", "CALCULATOR")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        exprs = (node.get("properties", {}) or {}).get("expressions") or []
        if not exprs:
            r.unresolved.append("formula tile with no expressions")
            return r

        # Translate first, so we know each expression's text before deciding layout.
        prepared: list[tuple[str, str, str]] = []      # (output name, domo, sql)
        for e in exprs:
            # `fieldName` is DOMO's own spelling; without it every expression in a
            # raw payload aliases to the same placeholder and collides downstream.
            name = first_of(e, "outputColumn_normalised", "outputColumn", "fieldName",
                            "name", "column", default="new_column")
            raw = first_of(e, "expression_normalised", "expression", "formula", default="")
            emitted = translate(raw, dialect="sql")
            r.notes.extend(emitted.notes)
            r.functions_used |= emitted.functions_used
            code = emitted.code
            r.expressions.append({
                "column": name, "domo": raw, "sql": code or "(unresolved)",
                "confidence": emitted.confidence,
                "source": "python" if emitted.resolved else "llm",
            })
            if not emitted.resolved:
                r.unresolved.extend(emitted.unsupported)
                code = f"__PENDING_{len(r.unresolved) - 1}__"
            prepared.append((name, raw, code))

        # DOMO evaluates a formula tile's expressions in order, so a later one may use
        # an earlier one's output. A single SELECT cannot express that portably: the
        # alias either does not resolve, or — worse — silently binds to a same-named
        # column already on the input. So split into layers and nest them.
        layers: list[list[tuple[str, str, str]]] = []
        produced: set[str] = set()
        for item in prepared:
            name, _raw, code = item
            # compare against the SANITIZED name: that is what the emitted SQL uses
            uses_prior = any(q(p) in code for p in produced)
            if uses_prior or not layers:
                layers.append([item])
                if uses_prior:
                    r.notes.append(
                        f"{name} references a column this tile just created — emitted as "
                        f"a nested SELECT so it resolves in order, as DOMO evaluates it")
            else:
                layers[-1].append(item)
            produced.add(name)

        # What the input actually provides, when the tracer could work it out. Without
        # it the only detectable overwrite is a self-referencing expression, which misses
        # a constant assigned to an existing column entirely.
        per_input = (node.get("properties", {}) or {}).get("input_columns") or []
        available = list(per_input[0]) if per_input and per_input[0] else None

        sql = src
        for layer in layers:
            # A formula tile usually ADDS columns, so `*` is right and a blanket
            # `* EXCEPT (...)` would fail on a column that does not exist yet.
            #
            # The exception is an expression that READS the column it writes
            # (```CMS Matrix Amount` * -1`` -> ``CMS Matrix Amount``). DOMO treats that as
            # replace-in-place. Emitting plain `*` there produces TWO columns with the
            # same name, which Spark accepts at this step and then fails on downstream
            # as an ambiguous reference — or worse, silently resolves to the stale one.
            # Self-reference is also *proof* the column already exists on the input,
            # which is exactly what makes EXCEPT safe here and nowhere else.
            if available is not None:
                have = {_san(c) for c in available}
                overwritten = [name for name, _raw, _c in layer if _san(name) in have]
                why = "the column already exists on the input"
            else:
                overwritten = [name for name, _raw, code in layer if q(name) in code]
                why = "the expression reads the column it writes"
            star = ("  *" if not overwritten else
                    "  * EXCEPT (" + ", ".join(q(n) for n in overwritten) + ")")
            if overwritten:
                r.notes.append(
                    "replaces " + ", ".join(f"`{n}`" for n in overwritten) +
                    f" in place ({why}), as DOMO does")
            if available is not None:
                seen_now = {_san(c) for c in available}
                available += [nm for nm, _raw, _c in layer if _san(nm) not in seen_now]
            lines = ["SELECT", star]
            for name, raw, code in layer:
                lines.append(f"  -- DOMO : {' '.join(str(raw).split())}")
                lines.append(f"  , {code} AS {q(name)}")
            body = "\n".join(lines)
            if sql == src:
                sql = f"{body}\nFROM {src}"
            else:
                indented = "\n".join("    " + ln for ln in sql.splitlines())
                sql = f"{body}\nFROM (\n{indented}\n)"

        r.code = sql
        r.confidence = "LOW" if r.unresolved else ("MEDIUM" if r.notes else "HIGH")
        return r


class SqlSelectTile(SqlTileRenderer):
    op_types = ("SELECT", "SELECTCOLUMNS", "SELECT COLUMNS", "PROJECT")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        cols = first_of(p, "selectedColumns", "columns", default=[]) or []
        if not cols:
            r.unresolved.append("select tile with no columns")
            return r
        parts = []
        for c in cols:
            if isinstance(c, str):
                parts.append(f"  {q(c)}")
                continue
            name = first_of(c, "column_normalised", "column", "name", default="")
            # DOMO uses rename / output_name; older exports use alias
            alias = first_of(c, "rename", "output_name", "alias")
            parts.append(f"  {q(name)} AS {q(alias)}" if alias and alias != name
                         else f"  {q(name)}")
        r.code = "SELECT\n" + ",\n".join(parts) + f"\nFROM {src}"
        return r


class SqlJoinTile(SqlTileRenderer):
    op_types = ("JOIN", "JOINDATA", "JOIN DATA", "MERGE")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        if len(inputs) < 2:
            r.unresolved.append("join tile needs two inputs")
            return r
        left, right = inputs[0], inputs[1]
        p = node.get("properties", {}) or {}
        keys = first_of(p, "joinKeys", "keys", default=[]) or []
        # DOMO writes 'LEFT OUTER', 'CROSS', 'INNER'; normalize on the first word
        raw_how = str(first_of(p, "joinType", "how", default="left")).strip().lower()
        head = raw_how.split()[0] if raw_how else "left"
        how = {"inner": "INNER JOIN", "left": "LEFT JOIN", "right": "RIGHT JOIN",
               "outer": "FULL OUTER JOIN", "full": "FULL OUTER JOIN",
               "cross": "CROSS JOIN"}.get(head, "LEFT JOIN")

        if how == "CROSS JOIN":
            r.notes.append("cross join: row multiplication is silent if the other side "
                           "returns more than one row — assert cardinality")
            r.confidence = "MEDIUM"
            r.code = (f"SELECT l.*, rt.*\nFROM {left} AS l\nCROSS JOIN {right} AS rt")
            return r
        if not keys:
            r.unresolved.append("join tile with no keys and not a cross join")
            return r

        def kl(k):
            return first_of(k, "leftColumn_normalised", "leftColumn", "left", default="")

        def kr(k):
            return first_of(k, "rightColumn_normalised", "rightColumn", "right", default="")

        on = "\n  AND ".join(f"l.{q(kl(k))} = rt.{q(kr(k))}" for k in keys)
        r.join_keys = [{"left": kl(k), "right": kr(k)} for k in keys]
        # DOMO tolerates duplicate names across inputs; SQL does not. DOMO states the
        # columns it drops in columnChanges/removed_cols — honour that list, and fall
        # back to the right-hand join keys when it is absent.
        changes = first_of(p, "columnChanges", "removed_cols", default=[]) or []
        drops = [first_of(c, "actual_name", "name", default="") for c in changes
                 if c.get("remove") is True or "actual_name" in c]
        drops = [d for d in drops if d] or [kr(k) for k in keys]
        dropped = ", ".join(q(d) for d in dict.fromkeys(drops))
        r.code = (f"SELECT\n  l.*,\n  rt.* EXCEPT ({dropped})\n"
                  f"FROM {left} AS l\n{how} {right} AS rt\n  ON {on}")
        r.notes.append("verify the right-hand key is unique, or the join fans out rows")
        return r


class SqlGroupByTile(SqlTileRenderer):
    op_types = ("GROUPBY", "GROUP BY", "AGGREGATE", "SUMMARIZE")

    #: Aggregates that are numeric by definition. MIN/MAX/COUNT/FIRST/LAST are not —
    #: they are meaningful over text, and coercing them would change the answer.
    _NUMERIC_AGGS = frozenset({"SUM", "AVG", "MEAN", "STDDEV"})

    _AGG = {"SUM": "SUM", "AVG": "AVG", "MEAN": "AVG", "MIN": "MIN", "MAX": "MAX",
            "COUNT": "COUNT", "COUNT_DISTINCT": "COUNT(DISTINCT {})",
            "FIRST": "FIRST", "LAST": "LAST", "STDDEV": "STDDEV"}

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        group = first_of(p, "groupByColumns_normalised", "groupByColumns",
                         "group_by_normalised", "group_by", "groupBy", "keys",
                         default=[]) or []
        aggs = first_of(p, "aggregations", "aggs", default=[]) or []
        if not aggs:
            r.unresolved.append("group-by tile with no aggregations")
            return r
        select: list[str] = []
        for i, g in enumerate(group):
            select.append(f"  {q(g)}" if i == 0 else f"  , {q(g)}")
        for a in aggs:
            fn = str(a.get("function") or "SUM").upper()
            # DOMO writes inputColumn -> outputColumn
            col = first_of(a, "inputColumn_normalised", "inputColumn", "column", default="")
            alias = first_of(a, "outputColumn_normalised", "outputColumn", "alias",
                             default=col)
            if fn not in self._AGG:
                r.unresolved.append(f"aggregate function {fn}")
                continue
            if fn in ("FIRST", "LAST"):
                r.notes.append(f"{fn}({col}) is order-dependent — SQL does not guarantee "
                               "which row wins without an ORDER BY. Recover the DOMO "
                               "tile's ordering or confirm any row is acceptable.")
                r.confidence = "LOW"
            # SUM/AVG/STDDEV are numeric by definition, and DOMO coerces a text column
            # into them. Spark under ANSI does not: SUM over a text column raises
            # CAST_INVALID_INPUT on the first malformed value, and DOMO's export puts a
            # leading apostrophe on some numbers, so "malformed" is the normal case.
            # MIN/MAX/COUNT/FIRST/LAST are left alone — they are meaningful on text and
            # coercing them would change the answer.
            operand = numeric_operand(q(col)) if fn in self._NUMERIC_AGGS else q(col)
            if fn in self._NUMERIC_AGGS:
                r.notes.append(
                    f"{fn}({col}) coerces its input to a number, as DOMO does; a value "
                    f"that will not parse becomes null rather than failing the query")
            tmpl = self._AGG[fn]
            call = tmpl.format(operand) if "{}" in tmpl else f"{tmpl}({operand})"
            prefix = "  " if not select else "  , "
            select.append(f"{prefix}{call} AS {q(alias)}")
        if r.unresolved:
            return r
        body = "SELECT\n" + "\n".join(select) + f"\nFROM {src}"
        if group:
            body += "\nGROUP BY " + ", ".join(q(g) for g in group)
        r.code = body
        return r


class SqlUnionTile(SqlTileRenderer):
    op_types = ("UNION", "APPEND", "APPENDROWS", "APPEND ROWS")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        if not inputs:
            r.unresolved.append("union tile with no inputs")
            return r

        # DOMO's append matches columns by NAME and fills a missing one with null.
        # `UNION ALL` over `SELECT *` matches by POSITION and requires identical counts,
        # so branches that differ fail outright (NUM_COLUMNS_MISMATCH) — or, far worse,
        # line up by accident and silently interleave unrelated columns.
        # ``input_columns`` is injected by the schema tracer when every branch is known;
        # with it, each branch is projected onto the same name-ordered list.
        p = node.get("properties", {}) or {}
        per_input = p.get("input_columns")
        if per_input and len(per_input) == len(inputs) and all(per_input):
            ordered: list[str] = []
            for cols in per_input:
                for c in cols:
                    if c not in ordered:
                        ordered.append(c)
            selects = []
            padded: list[str] = []
            for src, cols in zip(inputs, per_input):
                have = set(cols)
                # a bare NULL keeps Spark's type coercion free to take the type from
                # whichever branch does supply the column; CASTing here would force it
                missing = [c for c in ordered if c not in have]
                if missing:
                    padded.append(f"{src} (+{len(missing)})")
                proj = ",\n  ".join(q(c) if c in have else f"NULL AS {q(c)}"
                                    for c in ordered)
                selects.append(f"SELECT\n  {proj}\nFROM {src}")
            r.code = "\nUNION ALL\n".join(selects)
            if padded:
                r.notes.append(
                    "branches do not share a column set; aligned by name and null-filled "
                    "as DOMO's append does — padded: " + ", ".join(padded))
                r.confidence = "MEDIUM"
            return r

        r.code = "\nUNION ALL\n".join(f"SELECT * FROM {s}" for s in inputs)
        if len(inputs) > 1:
            r.notes.append("UNION ALL requires identical column order across all inputs — "
                           "unlike DOMO's append, which matches by name. The branches' "
                           "columns could not be traced, so they are NOT aligned here: "
                           "assert the column sets match before relying on this.")
            r.confidence = "MEDIUM"
        return r


class SqlAlterColumnsTile(SqlTileRenderer):
    op_types = ("ALTERCOLUMNS", "ALTER COLUMNS", "ALTER", "CHANGECOLUMNS", "CAST")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        # DOMO writes 'fields'; older exports write column_changes / changes
        changes = first_of(p, "fields", "column_changes", "changes", "columns",
                           default=[]) or []
        if not changes:
            r.unresolved.append("alter-columns tile with no changes")
            return r
        touched = [first_of(c, "name", "column", default="") for c in changes]
        lines = ["SELECT", f"  * EXCEPT ({', '.join(q(t) for t in touched)})"]
        for c in changes:
            name = first_of(c, "name", "column", default="")
            rename = first_of(c, "rename", "new_name", "output_name", default=name)
            new_type = first_of(c, "type", "new_type")
            if new_type:
                t, note = sql_type(new_type)
                if note:
                    r.notes.append(f"{rename}: {note}")
                    r.confidence = "MEDIUM"
                cleaned = _CLEAN.format(col=q(name))
                lines.append(f"  , CAST({cleaned} AS {t}) AS {q(rename)}")
            else:
                lines.append(f"  , {q(name)} AS {q(rename)}")
        lines.append(f"FROM {src}")
        r.code = "\n".join(lines)
        return r


class SqlSortTile(SqlTileRenderer):
    op_types = ("SORT", "ORDERBY", "ORDER BY")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        order = (node.get("properties", {}) or {}).get("orderBy") or []
        if not order:
            r.unresolved.append("sort tile with no ordering")
            return r
        parts = []
        for o in order:
            col = o.get("column", "") if isinstance(o, dict) else str(o)
            desc = isinstance(o, dict) and str(o.get("direction", "asc")).lower() == "desc"
            parts.append(f"{q(col)} {'DESC' if desc else 'ASC'}")
        r.code = f"SELECT *\nFROM {src}\nORDER BY {', '.join(parts)}"
        r.notes.append("ORDER BY inside a CTE is not guaranteed to survive into the final "
                       "result — apply the ordering at the outermost SELECT instead")
        r.confidence = "MEDIUM"
        return r


class SqlUnpivotTile(SqlTileRenderer):
    op_types = ("UNPIVOT", "NORMALIZEALL", "DYNAMICUNPIVOT", "DYNAMIC UNPIVOT")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        # DOMO writes idFields / keyField / valueField
        id_cols = list(first_of(p, "idFields", "id_columns", "keep", default=[]) or [])
        value_cols = list(first_of(p, "value_columns", "valueColumns", default=[]) or [])
        name_col = first_of(p, "keyField", "name_column", default="key")
        value_col = first_of(p, "valueField", "value_column", default="value")
        if not value_cols:
            # DOMO's dynamic unpivot resolves the value columns at run time. SQL cannot,
            # so the set has to be stated — escalate rather than guess.
            r.unresolved.append("dynamic unpivot: the value columns are resolved at run "
                                "time in DOMO and must be enumerated for SQL")
            r.confidence = "LOW"
            return r
        pairs = ", ".join(f"{lit(c)}, {q(c)}" for c in value_cols)
        ids = ", ".join(f"  {q(c)}" for c in id_cols)
        r.code = ("SELECT\n" + (ids + ",\n" if ids else "") +
                  f"  stack({len(value_cols)}, {pairs}) AS ({q(name_col)}, {q(value_col)})\n"
                  f"FROM {src}")
        return r


class SqlDedupeTile(SqlTileRenderer):
    """DOMO's Remove Duplicates. One row per key combination.

    ``row_number()`` with no ORDER BY, because DOMO does not state one either:
    the tile keeps whichever row it met first, which is not a property SQL can
    reproduce. That is a real semantic difference, so it is a note and a MEDIUM
    confidence rather than something smoothed over - if duplicate rows differ in
    any column the tile does not key on, the two engines can disagree.
    """
    op_types = ("DEDUPE", "UNIQUE", "REMOVEDUPLICATES", "REMOVE DUPLICATES")

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        r = RenderResult()
        src = inputs[0] if inputs else "/* NO INPUT */"
        p = node.get("properties", {}) or {}
        fields = first_of(p, "fields", "columns", "keys", default=[]) or []
        keys = []
        for f in fields:
            name = f if isinstance(f, str) else first_of(f, "name", "column", default="")
            if not name:
                continue
            insensitive = isinstance(f, dict) and bool(
                first_of(f, "caseInsensitive", "case_insensitive", default=False))
            keys.append(f"lower({q(name)})" if insensitive else q(name))
        if not keys:
            r.unresolved.append("remove-duplicates tile states no key columns")
            return r

        r.code = ("SELECT * EXCEPT (_dedupe_rn)\n"
                  "FROM (\n"
                  "  SELECT\n"
                  "    *,\n"
                  f"    row_number() OVER (PARTITION BY {', '.join(keys)}) AS _dedupe_rn\n"
                  f"  FROM {src}\n"
                  ")\nWHERE _dedupe_rn = 1")
        r.notes.append(
            "DOMO keeps the first row it meets per key and states no ordering, so "
            "which duplicate survives is undefined in both engines. Rows differing "
            "outside the key columns can therefore differ between them.")
        r.confidence = "MEDIUM"
        return r


class SqlRankTile(SqlTileRenderer):
    """DOMO's Rank & Window. One window function per declared addition."""
    op_types = ("RANK", "RANKWINDOW", "WINDOWACTION", "WINDOW")

    #: DOMO operationType -> SQL window function. Anything absent escalates: a
    #: ranking function guessed wrong renumbers every row, silently.
    _FN = {"RANK": "rank", "DENSE_RANK": "dense_rank", "DENSERANK": "dense_rank",
           "ROW_NUMBER": "row_number", "ROWNUMBER": "row_number",
           "PERCENT_RANK": "percent_rank", "CUME_DIST": "cume_dist"}

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        r = RenderResult()
        src = inputs[0] if inputs else "/* NO INPUT */"
        p = node.get("properties", {}) or {}

        order = []
        for rule in first_of(p, "orderRules", "order_rules", "orderBy", default=[]) or []:
            col = first_of(rule, "column", "name", default="")
            if not col:
                continue
            order.append(f"{q(col)} {'ASC' if rule.get('ascending', True) else 'DESC'}")
        parts = []
        for g in first_of(p, "partitionRules", "partition_rules", "partitionBy",
                          default=[]) or []:
            col = first_of(g, "column", "name", default="") if isinstance(g, dict) else g
            if col:
                parts.append(q(col))

        over = []
        if parts:
            over.append("PARTITION BY " + ", ".join(parts))
        if order:
            over.append("ORDER BY " + ", ".join(order))
        clause = " ".join(over)

        additions = first_of(p, "additions", "windows", default=[]) or []
        if not additions:
            r.unresolved.append("rank/window tile declares no output column")
            return r

        lines = ["SELECT", "  *"]
        for add in additions:
            alias = first_of(add, "name", "outputColumn", default="")
            op = add.get("operation") or {}
            kind = str(first_of(op, "operationType", "type", default="")).upper()
            fn = self._FN.get(kind)
            if not fn:
                r.unresolved.append(
                    f"unrecognised window operation {kind!r} producing {alias!r}")
                return r
            if fn != "row_number" and not order:
                # rank() with no ORDER BY is legal SQL that gives every row 1.
                r.unresolved.append(
                    f"{alias!r} uses {fn}() but the tile states no ordering; every "
                    f"row would rank equal")
                return r
            lines.append(f"  , {fn}() OVER ({clause}) AS {q(alias)}")
        lines.append(f"FROM {src}")
        r.code = "\n".join(lines)
        if not parts:
            r.notes.append("no PARTITION BY, matching the tile: the window runs "
                           "across the whole frame")
        return r


class SqlTextFormattingTile(SqlTileRenderer):
    """DOMO's Text Formatting: case and character-class edits, in place."""
    op_types = ("TEXT", "TEXTFORMATTING", "TEXT FORMATTING")

    _CASE = {"UPPER": "upper({c})", "LOWER": "lower({c})",
             "PROPER": "initcap({c})", "TITLE": "initcap({c})"}
    #: ONLY keeps just that character class; REMOVE strips it.
    _NUMBERS = {"ONLY": "regexp_replace({c}, '[^0-9]', '')",
                "REMOVE": "regexp_replace({c}, '[0-9]', '')"}

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        r = RenderResult()
        src = inputs[0] if inputs else "/* NO INPUT */"
        p = node.get("properties", {}) or {}
        fields = first_of(p, "fields", "columns", default=[]) or []

        touched, exprs = [], []
        for f in fields:
            name = first_of(f, "name", "column", default="")
            if not name:
                continue
            base = f"CAST({q(name)} AS STRING)"
            expr = base
            case_mod = str(first_of(f, "letterCaseMod", "letter_case",
                                    default="NONE")).upper()
            num_mod = str(first_of(f, "numberMod", "number_mod", default="NONE")).upper()
            if case_mod not in ("NONE", ""):
                template = self._CASE.get(case_mod)
                if not template:
                    r.unresolved.append(
                        f"unrecognised letter case {case_mod!r} on {name!r}")
                    return r
                expr = template.format(c=expr)
            if num_mod not in ("NONE", ""):
                template = self._NUMBERS.get(num_mod)
                if not template:
                    r.unresolved.append(
                        f"unrecognised number mode {num_mod!r} on {name!r}")
                    return r
                expr = template.format(c=expr)
            if expr == base:
                continue                    # listed by the tile, but changes nothing
            touched.append(name)
            exprs.append(f"  , {expr} AS {q(name)}")

        if not touched:
            r.code = f"SELECT *\nFROM {src}"
            r.notes.append("text-formatting tile makes no changes; passed through")
            return r
        star = "  * EXCEPT (" + ", ".join(q(c) for c in touched) + ")"
        r.code = "\n".join(["SELECT", star, *exprs, f"FROM {src}"])
        return r


class SqlStringCalcTile(SqlTileRenderer):
    """DOMO's String Operations. One calculation per output column."""
    op_types = ("STRINGCALCULATOR", "STRINGCALC", "STRING OPERATIONS")

    _TRIM_SIDE = {"BOTH": "BOTH", "LEADING": "LEADING", "LEFT": "LEADING",
                  "TRAILING": "TRAILING", "RIGHT": "TRAILING"}

    @staticmethod
    def _operand(calc: dict, slot: str):
        """One operand: a column, a literal, or nothing."""
        field = calc.get("field" + slot)
        if field:
            return q(field)
        const = calc.get("constant" + slot)
        if isinstance(const, dict) and const.get("value") is not None:
            return lit(const["value"])
        return None

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        r = RenderResult()
        src = inputs[0] if inputs else "/* NO INPUT */"
        p = node.get("properties", {}) or {}
        calcs = first_of(p, "calculations", "calcs", default=[]) or []
        if not calcs:
            r.unresolved.append("string-operations tile declares no calculations")
            return r

        touched, exprs = [], []
        for calc in calcs:
            alias = first_of(calc, "fieldName", "outputColumn", "name", default="")
            kind = str(first_of(calc, "calcType", "type", default="")).upper()
            a = self._operand(calc, "A")
            b = self._operand(calc, "B")
            c = self._operand(calc, "C")
            if not alias or a is None:
                r.unresolved.append(
                    f"string calculation {kind!r} states no input column")
                return r

            if kind == "TRIM":
                # constantB names the side; DOMO defaults to both.
                side = "BOTH"
                const_b = calc.get("constantB") or {}
                if isinstance(const_b, dict) and const_b.get("value"):
                    side = self._TRIM_SIDE.get(str(const_b["value"]).upper(), "BOTH")
                expr = f"TRIM({side} FROM CAST({a} AS STRING))"
            elif kind in ("CONCAT", "CONCATENATE"):
                pieces = [x for x in (a, b, c) if x is not None]
                expr = ("concat("
                        + ", ".join(f"CAST({x} AS STRING)" for x in pieces) + ")")
            elif kind in ("UPPER", "LOWER"):
                expr = f"{kind.lower()}(CAST({a} AS STRING))"
            elif kind == "REPLACE" and b is not None and c is not None:
                expr = f"replace(CAST({a} AS STRING), {b}, {c})"
            else:
                # Guessing a string operation produces plausible wrong text, which
                # is the hardest kind of wrong to spot in a diff.
                r.unresolved.append(
                    f"unrecognised string operation {kind!r} producing {alias!r}")
                return r

            touched.append(alias)
            exprs.append(f"  , {expr} AS {q(alias)}")

        star = "  * EXCEPT (" + ", ".join(q(c) for c in touched) + ")"
        r.code = "\n".join(["SELECT", star, *exprs, f"FROM {src}"])
        r.notes.append("string operations replace their input column in place, as "
                       "DOMO does")
        return r


SQL_RENDERERS: list[SqlTileRenderer] = [
    SqlDatasetTile(), SqlFilterTile(), SqlFormulaTile(), SqlSelectTile(), SqlJoinTile(),
    SqlGroupByTile(), SqlUnionTile(), SqlAlterColumnsTile(), SqlSortTile(), SqlUnpivotTile(),
    SqlDedupeTile(), SqlRankTile(), SqlTextFormattingTile(), SqlStringCalcTile(),
]


class SqlTileRegistry(TileRegistry):
    """First match wins; unknown tiles produce an unresolved result, never a guess."""

    def __init__(self, renderers: list[SqlTileRenderer] | None = None) -> None:
        super().__init__(renderers or SQL_RENDERERS)


def tile_registry(dialect: str = "sql") -> TileRegistry:
    """Pick a registry by dialect. SQL is the default target."""
    if dialect == "sql":
        return SqlTileRegistry()
    if dialect == "pyspark":
        return TileRegistry(PYSPARK_RENDERERS)
    raise ValueError(f"unknown dialect {dialect!r}; expected 'sql' or 'pyspark'")


__all__ = ["RenderResult", "SqlTileRegistry", "TileRegistry", "tile_registry",
           "SQL_RENDERERS", "q", "lit", "sql_type", "op_of", "declared_output_columns",
           "PASSTHROUGH_OPS", "DYNAMIC_COLUMN_OPS", "NAME_ALIGNED_OPS", "SCHEMA_AWARE_OPS",
           "output_columns"]
