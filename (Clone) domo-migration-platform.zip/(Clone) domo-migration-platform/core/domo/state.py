""">>> PLACEHOLDER <<<  core.domo.state

Owned by the core team. The LangGraph state shape plus its reducers.

``merge_feedback`` accumulates rather than replaces: a human's earlier constraints
must survive later rounds, or P1 priority is meaningless.
"""
from __future__ import annotations

from enum import Enum
from typing import Annotated, Any, TypedDict


class RunStatus(str, Enum):
    RUNNING = "running"
    AWAITING_HUMAN = "awaiting_human"
    DONE = "done"
    FAILED = "failed"


def merge_feedback(left: dict[str, list] | None, right: dict[str, list] | None) -> dict[str, list]:
    """Reducer for state['feedback'] — per-agent lists, appended never replaced."""
    out: dict[str, list] = {k: list(v) for k, v in (left or {}).items()}
    for agent, items in (right or {}).items():
        out.setdefault(agent, []).extend(items)
    return out


def merge_by_index(left: dict[int, Any] | None, right: dict[int, Any] | None) -> dict[int, Any]:
    """Reducer for fan-out results keyed by global index. Later wins on collision."""
    out = dict(left or {})
    out.update(right or {})
    return out


class RunState(TypedDict, total=False):
    """The graph state.

    ``feedback`` and ``prompt_layers`` carry reducers: LangGraph merges concurrent
    writes through them instead of last-write-wins. Feedback in particular MUST
    accumulate — a human's constraint from iteration 1 has to survive iteration 3,
    or P1 priority means nothing.
    """
    run_id: str
    dataflow_id: str
    dataflow_name: str
    status: str
    environment: str
    prompt_layers: dict[str, str]
    feedback: Annotated[dict[str, list], merge_feedback]
    connection: dict[str, Any]
    standardization: dict[str, Any]
    discovery: dict[str, Any]
    md_plan: dict[str, Any]
    cd_codegen: dict[str, Any]
    validation: dict[str, Any]
    classifier: dict[str, Any]
