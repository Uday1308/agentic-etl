"""core.domo.naming — how a DOMO column name becomes an identifier in the target.

There are two defensible ways to handle DOMO's column names, and the choice has to be
made once and applied *everywhere*, or the generated SQL will not match the tables it
runs against.

``delta_safe`` (the default) replaces every character Delta rejects with ``_``
               (``Journal Batch Name`` -> ``Journal_Batch_Name``).

               This is the default because it is what actually runs. Ingestion has to
               sanitize these names to land them in Delta at all, so the migrated
               tables carry the sanitized form — and SQL that references
               ``Journal Batch Name`` would simply not resolve. PySpark could paper
               over this; SQL cannot.

``preserve``   keeps the DOMO name verbatim. Only correct when the tables were
               created with Delta column mapping enabled, which preserves the
               original names but raises the table protocol version irreversibly.

The policy is set once per generation run and consulted by both emitters, so an
expression and a tile can never disagree about what a column is called.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

#: Characters Delta refuses in a column name: space , ; { } ( ) newline tab =
DELTA_INVALID = " ,;{}()\n\t="


@dataclass(frozen=True)
class IdentifierPolicy:
    """How to turn a source column name into a target identifier."""

    mode: str = "delta_safe"                     # delta_safe | preserve
    invalid_chars: str = DELTA_INVALID
    replacement: str = "_"
    collapse_repeats: bool = True                # 'A  B' -> 'A_B', not 'A__B'
    strip_edges: bool = True                     # no leading/trailing separator
    #: characters to additionally replace beyond Delta's list. Ingestion pipelines
    #: often strip dots and slashes too; set this to match yours exactly.
    extra_chars: str = ""
    #: explicit overrides, applied before any rule. Use for the handful of columns
    #: whose ingested name does not follow the general rule.
    overrides: dict[str, str] = field(default_factory=dict)

    def apply(self, name: str) -> str:
        text = unquote(name)
        if text in self.overrides:
            return self.overrides[text]
        if self.mode == "preserve":
            return text
        bad = set(self.invalid_chars) | set(self.extra_chars)
        out = "".join(self.replacement if ch in bad else ch for ch in text)
        if self.collapse_repeats and self.replacement:
            out = re.sub(re.escape(self.replacement) + r"{2,}", self.replacement, out)
        if self.strip_edges and self.replacement:
            # Strip only separators this function INTRODUCED. DOMO's connector columns
            # are genuinely named `_BATCH_ID_`, and stripping those underscores would
            # point the SQL at a column that does not exist.
            lead = not text.startswith(self.replacement)
            trail = not text.endswith(self.replacement)
            if lead:
                out = out.lstrip(self.replacement)
            if trail:
                out = out.rstrip(self.replacement)
        return out or text


def unquote(name: str) -> str:
    """Strip backtick quoting that is already on the name.

    DOMO sometimes stores a column as ``` `Transaction No.` ``` — backticks included.
    Quoting that again yields an identifier whose name literally contains backticks,
    which Delta rejects. A doubled backtick is the SQL escape for one literal
    backtick, so it is preserved.
    """
    text = str(name or "").strip()
    while len(text) >= 2 and text.startswith("`") and text.endswith("`"):
        inner = text[1:-1]
        if "`" in inner.replace("``", ""):
            break                                # ragged quoting; leave it visible
        text = inner.strip()
    return text


#: The active policy. Set once at the start of a generation run; both the expression
#: emitter and the tile renderers read it, so they cannot disagree.
_ACTIVE = IdentifierPolicy()


def set_policy(policy: IdentifierPolicy) -> IdentifierPolicy:
    global _ACTIVE
    previous, _ACTIVE = _ACTIVE, policy
    return previous


def policy() -> IdentifierPolicy:
    return _ACTIVE


def column(name: str) -> str:
    """The identifier for ``name``, unquoted, after the active policy."""
    return _ACTIVE.apply(name)


def quoted(name: str) -> str:
    """The identifier for ``name``, backticked exactly once."""
    return f"`{column(name)}`"


def policy_from_args(mode: str = "delta_safe", extra_chars: str = "",
                     overrides: dict[str, str] | None = None) -> IdentifierPolicy:
    if mode not in ("preserve", "delta_safe"):
        raise ValueError(f"unknown column mode {mode!r}; expected preserve or delta_safe")
    return IdentifierPolicy(mode=mode, extra_chars=extra_chars,
                            overrides=overrides or {})
