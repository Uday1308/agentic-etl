"""core.domo.domo — the shared DOMO transpiler.

Deliberately NOT owned by either agent. Both need it, for different reasons:

* **MD Plan** uses it to document the proposed mapping — DOMO expression next to its
  translation, with confidence and semantic caveats — so a human can review the
  *semantics* without reading generated code.
* **CD Codegen** uses it to emit the actual artifact.

One transpiler, two purposes, no duplication and no drift between what was approved
and what was generated.
"""
from core.domo.expr import (  # noqa: F401
    DomoParseError,
    Emitted,
    PySparkEmitter,
    SqlEmitter,
    UnsupportedFunction,
    detect_functions,
    parse,
    translate,
)
from core.domo.tiles import (  # noqa: F401
    RenderResult,
    SqlTileRegistry,
    TileRegistry,
    tile_registry,
)
