"""core.domo.llm — the single sanctioned entry point to a serving endpoint.

Per the Core Development Guide (§9) and the shared-core skill: **no other module
may call a serving endpoint directly.** Everything goes through ``LLMClient.complete``,
which resolves the role to an endpoint, acquires a named concurrency slot, assembles
the layered prompt, calls the endpoint (with retry/timeout), parses structured output,
runs the deterministic hard-constraint check, and records one observability row.

Design: Facade over the whole LLM concern with every collaborator injected (DI).
The only file allowed to import the serving SDK — and that import is lazy, inside the
default caller, so the rest of the codebase (and the tests) never require it.

RATIFIED OPEN DECISION (guide §9, §15 "hard-constraint surfacing"):
    ``complete`` **returns** violations on ``LlmResult.hard_constraint_violations``
    rather than raising. This matches the documented ``LlmResult`` shape (which carries
    that field) and lets the gen-eval-HITL loop inspect and react. Applied uniformly.
    -> Flag for team ratification.
"""
from __future__ import annotations

import asyncio
import hashlib
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable

from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel, ConfigDict

from core.domo.concurrency import ConcurrencyManager
from core.domo.models import EndpointSpec, ModelRegistry, Role
from core.domo.observability import LlmCallRow, ObservabilityWriter
from core.domo.prompts import HardConstraintChecker, PromptAssembler, PromptLayers


# --------------------------------------------------------------------------- #
# Return shape
# --------------------------------------------------------------------------- #
class LlmResult(BaseModel):
    """The result of one LLM call. ``parsed`` is populated only when a
    ``response_schema`` was requested."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    parsed: BaseModel | None = None
    raw_text: str
    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: int = 0
    retries: int = 0
    confidence: float | None = None
    hard_constraint_violations: list[str] = []


# --------------------------------------------------------------------------- #
# Endpoint caller — the boundary to the serving SDK (injectable for tests)
# --------------------------------------------------------------------------- #
@dataclass
class RawCompletion:
    text: str
    tokens_in: int = 0
    tokens_out: int = 0


@runtime_checkable
class EndpointCaller(Protocol):
    """Synchronous call to a serving endpoint. The default implementation wraps
    the Databricks serving SDK; tests inject a fake with the same shape."""

    def __call__(self, spec: EndpointSpec, prompt: str,
                 response_schema: type[BaseModel] | None, timeout_s: int) -> RawCompletion: ...


def _extract_json(text: str) -> str:
    """Return the first balanced JSON object/array substring in ``text``.

    Models sometimes wrap the JSON in prose or a reasoning preamble; this finds the
    first ``{`` or ``[`` and scans to its matching close, respecting strings/escapes.
    """
    start = next((i for i, c in enumerate(text) if c in "{["), -1)
    if start == -1:
        raise ValueError("no JSON object or array found in model output")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        c = text[i]
        if esc:
            esc = False
            continue
        if c == "\\":
            esc = True
            continue
        if c == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if c in "{[":
            depth += 1
        elif c in "}]":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError("unbalanced JSON in model output")


def _content_to_text(content: Any) -> str:
    """Normalize a serving-endpoint message content into plain text.

    Databricks foundation-model / OpenAI-compatible endpoints may return
    ``message.content`` as a plain string OR as a list of content blocks
    (dicts like ``{"type": "text", "text": "..."}`` or objects with a ``.text``
    attribute). Everything downstream (``_parse``, ``raw_text``) expects a string,
    so we flatten here at the boundary.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                parts.append(str(block.get("text") or block.get("content") or ""))
            else:
                parts.append(str(getattr(block, "text", "") or ""))
        return "".join(parts)
    return str(content)


class DatabricksEndpointCaller:
    """Default caller. Wraps ``WorkspaceClient().serving_endpoints.query`` — the
    project's sanctioned serving path. The SDK is imported lazily so importing
    ``core.domo.llm`` never requires databricks-sdk to be installed."""

    def __call__(self, spec: EndpointSpec, prompt: str,
                 response_schema: type[BaseModel] | None, timeout_s: int) -> RawCompletion:
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.service.serving import ChatMessage, ChatMessageRole

        w = WorkspaceClient()
        resp = w.serving_endpoints.query(
            name=spec.endpoint,
            messages=[ChatMessage(role=ChatMessageRole.USER, content=prompt)],
            **(spec.params or {}),
        )
        text = _content_to_text(resp.choices[0].message.content)
        usage = getattr(resp, "usage", None)
        return RawCompletion(
            text=text or "",
            tokens_in=int(getattr(usage, "prompt_tokens", 0) or 0),
            tokens_out=int(getattr(usage, "completion_tokens", 0) or 0),
        )


# --------------------------------------------------------------------------- #
# The client
# --------------------------------------------------------------------------- #
class LLMClient:
    """Facade over resolution, concurrency, prompt assembly, the call, parsing,
    the hard-constraint check, and observability.

    The five collaborators are the documented contract (guide §9). ``caller`` and
    the retry/timeout knobs are optional injection points with production defaults,
    so the documented surface is unchanged for callers while tests stay hermetic.
    """

    def __init__(
        self,
        registry: ModelRegistry,
        assembler: PromptAssembler,
        checker: HardConstraintChecker,
        concurrency: ConcurrencyManager,
        observability: ObservabilityWriter,
        *,
        caller: EndpointCaller | None = None,
        max_retries: int = 2,
        backoff_s: float = 1.0,
        timeout_s: int = 300,
    ) -> None:
        self._registry = registry
        self._assembler = assembler
        self._checker = checker
        self._concurrency = concurrency
        self._observability = observability
        self._caller: EndpointCaller = caller or DatabricksEndpointCaller()
        self._max_retries = max_retries
        self._backoff_s = backoff_s
        self._timeout_s = timeout_s

    async def complete(
        self,
        role: Role,
        layered_prompt: PromptLayers,
        *,
        pool: str,
        response_schema: type[BaseModel] | None = None,
        config: RunnableConfig,
    ) -> LlmResult:
        ctx = _context(config)
        spec = self._registry.resolve(role, ctx["environment"])
        prompt = self._assembler.assemble(layered_prompt)
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:16]

        start = time.perf_counter()
        retries = 0
        raw: RawCompletion
        # Bounded concurrency: acquire the named pool (which also takes a global slot).
        async with self._concurrency.acquire(pool):
            while True:
                try:
                    raw = await asyncio.to_thread(
                        self._caller, spec, prompt, response_schema, self._timeout_s
                    )
                    break
                except Exception:
                    if retries >= self._max_retries:
                        self._record(ctx, role, spec, pool, prompt, prompt_hash,
                                     response_text="", tokens_in=0, tokens_out=0,
                                     latency_ms=int((time.perf_counter() - start) * 1000),
                                     retries=retries, confidence=None, status="error")
                        raise
                    retries += 1
                    await asyncio.sleep(self._backoff_s * retries)

        latency_ms = int((time.perf_counter() - start) * 1000)
        parsed = self._parse(raw.text, response_schema) if response_schema else None
        confidence = getattr(parsed, "confidence", None) if parsed is not None else None
        violations = self._checker.check(raw.text, list(layered_prompt.hard_constraints or []))

        self._record(ctx, role, spec, pool, prompt, prompt_hash,
                     response_text=raw.text, tokens_in=raw.tokens_in, tokens_out=raw.tokens_out,
                     latency_ms=latency_ms, retries=retries, confidence=confidence, status="ok")

        return LlmResult(
            parsed=parsed,
            raw_text=raw.text,
            tokens_in=raw.tokens_in,
            tokens_out=raw.tokens_out,
            latency_ms=latency_ms,
            retries=retries,
            confidence=confidence,
            hard_constraint_violations=violations,
        )

    # -- internals ---------------------------------------------------------- #
    @staticmethod
    def _parse(text: str, schema: type[BaseModel]) -> BaseModel:
        """Parse a model response into ``schema``, tolerating real-world output:
        ```json fences, prose around the JSON, and reasoning preambles. Raises a
        readable error (with a snippet) instead of a bare JSONDecodeError."""
        cleaned = (text or "").strip()
        if not cleaned:
            raise ValueError("model returned an empty response; expected structured JSON")

        # strip a surrounding ```/```json fence if present
        if cleaned.startswith("```"):
            body = cleaned[3:]
            if body[:4].lower() == "json":
                body = body[4:]
            if "```" in body:
                body = body[: body.rindex("```")]
            cleaned = body.strip()

        # fast path: whole thing is valid JSON
        try:
            return schema.model_validate_json(cleaned)
        except Exception:
            pass
        # tolerant path: pull the first balanced {...} or [...] out of surrounding prose
        try:
            return schema.model_validate_json(_extract_json(cleaned))
        except Exception as e:
            raise ValueError(
                f"could not parse structured output for {schema.__name__}: {e}. "
                f"Model returned (first 300 chars): {cleaned[:300]!r}"
            ) from e

    def _record(self, ctx: dict, role: Role, spec: EndpointSpec, pool: str,
                prompt: str, prompt_hash: str, *, response_text: str,
                tokens_in: int, tokens_out: int, latency_ms: int, retries: int,
                confidence: float | None, status: str) -> None:
        """Build and write the per-call observability row. The writer decides
        whether the full prompt/response text is persisted or hashed-only."""
        self._observability.record_llm_call(LlmCallRow(
            obs_run_id=ctx["obs_run_id"],
            thread_id=ctx["thread_id"],
            dataflow_id=ctx["dataflow_id"],
            agent=ctx["agent"],
            node=ctx["node"],
            role=role.value if isinstance(role, Role) else str(role),
            model=spec.endpoint,
            pool=pool,
            prompt_hash=prompt_hash,
            prompt_text=prompt,
            response_text=response_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            retries=retries,
            cost=None,                       # DECISION (guide §8): pricing not wired yet
            confidence=confidence,
            iteration=ctx["iteration"],
            status=status,
            ts=datetime.now(timezone.utc),
        ))


def _context(config: RunnableConfig | None) -> dict[str, Any]:
    """Pull the run/node context the observability row and registry need out of
    ``config['configurable']`` (populated by the node harness / graph invocation)."""
    cfg = dict((config or {}).get("configurable", {}) or {})
    return {
        "environment": cfg.get("environment", "dev"),
        "thread_id": cfg.get("thread_id", ""),
        "dataflow_id": cfg.get("dataflow_id", ""),
        "obs_run_id": cfg.get("obs_run_id", ""),
        "agent": cfg.get("agent", ""),
        "node": cfg.get("node", ""),
        "iteration": int(cfg.get("iteration", 0) or 0),
    }
