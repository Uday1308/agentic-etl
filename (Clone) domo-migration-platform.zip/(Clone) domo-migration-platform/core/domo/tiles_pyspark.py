"""core.domo.tiles_pyspark — render one DOMO tile into PySpark.

Each tile type gets an explicit renderer. Anything unrecognised produces a
``RenderResult`` marked unresolved rather than a guess, so only genuinely unknown
tiles escalate to a model.

The renderers deliberately emit defensive code where DOMO and Spark disagree:

* joins alias both sides and de-duplicate column names, because DOMO tolerates
  duplicate names across inputs and Spark does not;
* casts always state precision — a bare ``DecimalType()`` silently truncates to
  (10,0), which is the single most expensive bug class in a reconciliation pipeline;
* string comparisons strip DOMO's leading-quote artifact, which appears in exported
  feeds and otherwise breaks every equality test.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from core.domo.expr import Emitted, translate

#: DOMO exports sometimes carry a leading apostrophe on values and scientific-notation
#: suffixes. Comparisons must strip both or nothing matches.
_CLEAN = ("F.regexp_replace(F.regexp_replace({expr}.cast('string'), \"^'\", ''), "
          "'E-\\\\d+$', '')")


@dataclass
class RenderResult:
    code: str = ""
    confidence: str = "HIGH"                      # HIGH | MEDIUM | LOW
    notes: list[str] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
    functions_used: set[str] = field(default_factory=set)
    expressions: list[dict[str, Any]] = field(default_factory=list)
    join_keys: list[dict[str, str]] = field(default_factory=list)

    @property
    def resolved(self) -> bool:
        return not self.unresolved

    def absorb(self, e: Emitted) -> str:
        self.notes.extend(e.notes)
        self.functions_used |= e.functions_used
        self.unresolved.extend(e.unsupported)
        return e.code


def _q(name: str) -> str:
    """Column reference, backticked when needed."""
    safe = name.replace(".", "__")
    return (f"F.col('`{safe}`')" if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", safe)
            else f"F.col('{safe}')")


def _lit(v: Any) -> str:
    return f"F.lit({v!r})" if isinstance(v, str) else f"F.lit({v})"


def _spark_type(domo_type: str) -> tuple[str, str | None]:
    """Map a DOMO column type to a Spark type. Decimal ALWAYS carries precision."""
    t = (domo_type or "").upper()
    if t in ("DECIMAL", "NUMERIC", "MONEY", "CURRENCY"):
        return "DecimalType(18, 2)", ("precision pinned to (18,2); DOMO did not state one and "
                                      "a bare DecimalType() truncates to (10,0)")
    if t in ("DOUBLE", "FLOAT", "REAL"):
        return "DoubleType()", None
    if t in ("LONG", "BIGINT", "INTEGER", "INT"):
        return "LongType()", None
    if t in ("DATE",):
        return "DateType()", None
    if t in ("DATETIME", "TIMESTAMP"):
        return "TimestampType()", None
    return "StringType()", None


class TileRenderer:
    """Base class. ``op_types`` lists the DOMO tile names this renderer claims."""
    op_types: tuple[str, ...] = ()

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        raise NotImplementedError


class DatasetTile(TileRenderer):
    op_types = ("DATASET", "DATA", "SOURCE", "INPUT")

    def render(self, node, inputs, out_var):
        p = node.get("properties", {}) or {}
        table = p.get("source_table") or p.get("table") or p.get("dataset_name") or ""
        r = RenderResult()
        r.code = f"{out_var} = spark.read.table({table!r})"
        if not table:
            r.notes.append("source table not stated in the tile; bind it before running")
            r.confidence = "MEDIUM"
        return r


class FilterTile(TileRenderer):
    op_types = ("FILTER", "FILTERROWS", "FILTER ROWS")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        if p.get("formula") or p.get("expression"):
            code = r.absorb(translate(p.get("formula") or p.get("expression")))
            r.code = f"{out_var} = {src}.filter(\n    {code}\n)"
            r.confidence = "MEDIUM" if r.notes else "HIGH"
            return r

        conds = p.get("conditions") or p.get("filters") or []
        if not conds:
            r.unresolved.append("filter tile with no conditions or formula")
            return r
        parts = []
        for c in conds:
            col, op = c.get("column", ""), (c.get("operator") or "EQUALS").upper()
            val = c.get("value")
            cleaned = _CLEAN.format(expr=_q(col))
            if op in ("EQUALS", "EQUAL", "="):
                parts.append(f"({cleaned} == {val!r})")
            elif op in ("NOT_EQUALS", "NOT_EQUAL", "!=", "<>"):
                parts.append(f"({cleaned} != {val!r})")
            elif op in ("IN", "IS_IN"):
                parts.append(f"({_q(col)}.isin({list(val)!r}))")
            elif op in ("NOT_IN",):
                parts.append(f"(~({_q(col)}.isin({list(val)!r})))")
            elif op in ("CONTAINS",):
                parts.append(f"({cleaned}.contains({val!r}))")
            elif op in ("IS_NULL", "IS_EMPTY"):
                parts.append(f"({_q(col)}.isNull())")
            elif op in ("IS_NOT_NULL",):
                parts.append(f"({_q(col)}.isNotNull())")
            elif op in ("GREATER_THAN", ">"):
                parts.append(f"({_q(col)} > {_lit(val)})")
            elif op in ("GREATER_OR_EQUAL", ">="):
                parts.append(f"({_q(col)} >= {_lit(val)})")
            elif op in ("LESS_THAN", "<"):
                parts.append(f"({_q(col)} < {_lit(val)})")
            elif op in ("LESS_OR_EQUAL", "<="):
                parts.append(f"({_q(col)} <= {_lit(val)})")
            else:
                r.unresolved.append(f"filter operator {op}")
                continue
        joiner = " | " if (p.get("combine") or "AND").upper() == "OR" else " & "
        r.code = f"{out_var} = {src}.filter(\n    ({joiner.join(parts)})\n)"
        return r


class FormulaTile(TileRenderer):
    op_types = ("FORMULA", "ADDFORMULA", "ADD FORMULA", "CALCULATOR")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        exprs = (node.get("properties", {}) or {}).get("expressions") or []
        if not exprs:
            r.unresolved.append("formula tile with no expressions")
            return r
        lines = [f"{out_var} = (", f"    {src}"]
        for e in exprs:
            name = e.get("name") or e.get("column") or "new_column"
            raw = e.get("expression") or e.get("formula") or ""
            emitted = translate(raw)
            code = r.absorb(emitted)
            r.expressions.append({
                "column": name, "domo": raw, "pyspark": code or "(unresolved)",
                "confidence": emitted.confidence,
                "source": "python" if emitted.resolved else "llm",
            })
            if not emitted.resolved:
                code = f"__PENDING_{len(r.unresolved) - 1}__"
            lines.append(f"    .withColumn({name!r},")
            lines.append(f"        # DOMO : {' '.join(raw.split())}")
            lines.append(f"        {code})")
        lines.append(")")
        r.code = "\n".join(lines)
        r.confidence = ("LOW" if r.unresolved else "MEDIUM" if r.notes else "HIGH")
        return r


class SelectTile(TileRenderer):
    op_types = ("SELECT", "SELECTCOLUMNS", "SELECT COLUMNS", "PROJECT")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        cols = (node.get("properties", {}) or {}).get("columns") or []
        if not cols:
            r.unresolved.append("select tile with no columns")
            return r
        parts = []
        for c in cols:
            if isinstance(c, str):
                parts.append(f"    {_q(c)}")
                continue
            name, alias = c.get("name") or c.get("column"), c.get("alias")
            parts.append(f"    {_q(name)}.alias({alias!r})" if alias and alias != name
                         else f"    {_q(name)}")
        r.code = f"{out_var} = {src}.select(\n" + ",\n".join(parts) + "\n)"
        return r


class JoinTile(TileRenderer):
    op_types = ("JOIN", "JOINDATA", "JOIN DATA", "MERGE")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        if len(inputs) < 2:
            r.unresolved.append("join tile needs two inputs")
            return r
        left_src, right_src = inputs[0], inputs[1]
        p = node.get("properties", {}) or {}
        keys = p.get("joinKeys") or p.get("keys") or []
        how = (p.get("joinType") or p.get("how") or "left").lower()
        how = {"inner": "inner", "left": "left", "right": "right", "outer": "outer",
               "full": "outer", "cross": "cross"}.get(how, "left")

        # DOMO tolerates duplicate column names across inputs; Spark does not, so both
        # sides are aliased and de-duplicated before the join.
        pre = [
            f"_left = {left_src}.alias('left')",
            f"_right = {right_src}.alias('right')",
        ]
        if how == "cross":
            r.notes.append("cross join: row multiplication is silent if the other side "
                           "returns more than one row — assert cardinality")
            r.confidence = "MEDIUM"
            cond = "how='cross'"
        else:
            if not keys:
                r.unresolved.append("join tile with no keys and not a cross join")
                return r
            conds = [f"(F.col('left.`{k.get('left')}`') == F.col('right.`{k.get('right')}`'))"
                     for k in keys]
            r.join_keys = [{"left": k.get("left", ""), "right": k.get("right", "")} for k in keys]
            cond = " & \\\n        ".join(conds) + f", '{how}'"
            r.notes.append("verify the right-hand key is unique, or the join fans out rows")
        body = [f"{out_var} = _left.join(_right, {cond})"]
        drop = [k.get("right") for k in keys] if keys else []
        if drop:
            excluded = ", ".join(repr(str(d).upper()) for d in drop)
            body += [
                "",
                "_left_cols  = [F.col(f'left.`{c}`') for c in _left.columns]",
                "_right_cols = [F.col(f'right.`{c}`') for c in _right.columns",
                f"               if c.upper() not in {{{excluded}}}]",
                f"{out_var} = {out_var}.select(*_left_cols, *_right_cols)",
            ]
        r.code = "\n".join(pre + body)
        return r


class GroupByTile(TileRenderer):
    op_types = ("GROUPBY", "GROUP BY", "AGGREGATE", "SUMMARIZE")

    _AGG = {"SUM": "F.sum", "AVG": "F.avg", "MEAN": "F.avg", "MIN": "F.min",
            "MAX": "F.max", "COUNT": "F.count", "COUNT_DISTINCT": "F.countDistinct",
            "FIRST": "F.first", "LAST": "F.last", "STDDEV": "F.stddev"}

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        group = p.get("groupBy") or p.get("keys") or []
        aggs = p.get("aggregations") or p.get("aggs") or []
        if not aggs:
            r.unresolved.append("group-by tile with no aggregations")
            return r
        parts = []
        for a in aggs:
            fn = (a.get("function") or "SUM").upper()
            col, alias = a.get("column", ""), a.get("alias") or a.get("column", "")
            if fn not in self._AGG:
                r.unresolved.append(f"aggregate function {fn}")
                continue
            if fn in ("FIRST", "LAST"):
                # Non-deterministic in Spark without an explicit order. DOMO's tile had
                # one; if it is not in the export a human must supply it.
                r.notes.append(f"{fn}({col}) is order-dependent — Spark does not guarantee "
                               "which row wins. Recover the DOMO tile's ordering or "
                               "confirm any row is acceptable.")
                r.confidence = "LOW"
            parts.append(f"    {self._AGG[fn]}({_q(col)}).alias({alias!r})")
        keys = ", ".join(repr(g) for g in group)
        r.code = (f"{out_var} = {src}.groupBy({keys}).agg(\n" + ",\n".join(parts) + "\n)")
        return r


class UnionTile(TileRenderer):
    op_types = ("UNION", "APPEND", "APPENDROWS", "APPEND ROWS")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        if not inputs:
            r.unresolved.append("union tile with no inputs")
            return r
        head, rest = inputs[0], inputs[1:]
        lines = [f"{out_var} = (", f"    {head}"]
        for s in rest:
            lines.append(f"    .unionByName({s}, allowMissingColumns=True)")
        lines.append(")")
        r.code = "\n".join(lines)
        if rest:
            r.notes.append("allowMissingColumns hides schema drift in any input — assert "
                           "the expected column set before unioning")
            r.confidence = "MEDIUM"
        return r


class AlterColumnsTile(TileRenderer):
    op_types = ("ALTERCOLUMNS", "ALTER COLUMNS", "ALTER", "CHANGECOLUMNS", "CAST")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        changes = (node.get("properties", {}) or {}).get("column_changes") or \
                  (node.get("properties", {}) or {}).get("changes") or []
        if not changes:
            r.unresolved.append("alter-columns tile with no changes")
            return r
        lines = [f"{out_var} = (", f"    {src}"]
        for c in changes:
            name = c.get("name") or c.get("column", "")
            rename = c.get("rename") or c.get("new_name")
            new_type = c.get("type") or c.get("new_type")
            if rename and rename != name:
                lines.append(f"    .withColumnRenamed({name!r}, {rename!r})")
                name = rename
            if new_type:
                spark_type, note = _spark_type(new_type)
                if note:
                    r.notes.append(f"{name}: {note}")
                    r.confidence = "MEDIUM"
                cleaned = _CLEAN.format(expr=_q(name))
                lines.append(f"    .withColumn({name!r}, {cleaned}.cast({spark_type}))")
        lines.append(")")
        r.code = "\n".join(lines)
        return r


class SortTile(TileRenderer):
    op_types = ("SORT", "ORDERBY", "ORDER BY")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        order = (node.get("properties", {}) or {}).get("orderBy") or []
        if not order:
            r.unresolved.append("sort tile with no ordering")
            return r
        parts = []
        for o in order:
            col = o.get("column", "") if isinstance(o, dict) else str(o)
            desc = isinstance(o, dict) and str(o.get("direction", "asc")).lower() == "desc"
            parts.append(f"{_q(col)}.desc()" if desc else f"{_q(col)}.asc()")
        r.code = f"{out_var} = {src}.orderBy({', '.join(parts)})"
        return r


class UnpivotTile(TileRenderer):
    op_types = ("UNPIVOT", "NORMALIZEALL", "DYNAMICUNPIVOT", "DYNAMIC UNPIVOT")

    def render(self, node, inputs, out_var):
        r = RenderResult()
        src = inputs[0] if inputs else "df_in"
        p = node.get("properties", {}) or {}
        id_cols = p.get("id_columns") or p.get("keep") or []
        name_col = p.get("name_column", "key")
        value_col = p.get("value_column", "value")
        r.code = "\n".join([
            f"_id_fields  = {list(id_cols)!r}",
            f"_val_cols   = [c for c in {src}.columns if c not in _id_fields]",
            "_stack_expr = ('stack(' + str(len(_val_cols)) + ', ' +",
            "               ', '.join([f\"'{c}', `{c}`\" for c in _val_cols]) +",
            f"               ') AS (`{name_col}`, `{value_col}`)')",
            f"{out_var} = {src}.select(",
            "    *[F.col(f'`{c}`') for c in _id_fields],",
            "    F.expr(_stack_expr),",
            ")",
        ])
        r.notes.append("the value columns are resolved at runtime — a new column upstream "
                       "will be unpivoted too")
        r.confidence = "MEDIUM"
        return r


class TileRegistry:
    """First match wins; unknown tiles produce an unresolved result rather than a guess."""

    def __init__(self, renderers: list[TileRenderer] | None = None) -> None:
        self._by_op: dict[str, TileRenderer] = {}
        for r in renderers or DEFAULT_RENDERERS:
            self.register(r)

    def register(self, renderer: TileRenderer) -> "TileRegistry":
        for op in renderer.op_types:
            self._by_op[op.upper().replace("_", "")] = renderer
        return self

    def find(self, op_type: str) -> TileRenderer | None:
        return self._by_op.get((op_type or "").upper().replace("_", "").replace(" ", ""))

    def render(self, node: dict, inputs: list[str], out_var: str) -> RenderResult:
        op = node.get("type") or node.get("operation_type") or ""
        renderer = self.find(op)
        if renderer is None:
            r = RenderResult(confidence="LOW")
            r.unresolved.append(f"unrecognised tile type {op!r}")
            return r
        try:
            return renderer.render(node, inputs, out_var)
        except Exception as exc:                       # a broken renderer escalates
            r = RenderResult(confidence="LOW")
            r.unresolved.append(f"{op} renderer raised {type(exc).__name__}: {exc}")
            return r


DEFAULT_RENDERERS: list[TileRenderer] = [
    DatasetTile(), FilterTile(), FormulaTile(), SelectTile(), JoinTile(),
    GroupByTile(), UnionTile(), AlterColumnsTile(), SortTile(), UnpivotTile(),
]
