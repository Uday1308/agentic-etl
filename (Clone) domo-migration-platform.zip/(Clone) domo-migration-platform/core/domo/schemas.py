""">>> PLACEHOLDER <<<  core.domo.schemas

Owned by the core team, not by cd_codegen. This file reproduces the documented
interface faithfully so imports resolve, the graph runs and the contract tests
execute. Replace wholesale with the real module — do not build on top of it.
"""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Verdict(str, Enum):
    PASS = "pass"
    REVISE = "revise"
    FAIL = "fail"


class Severity(str, Enum):
    INFO = "info"
    WARN = "warn"
    ERROR = "error"


class Issue(BaseModel):
    """One problem an evaluator found. ``ref`` is node-addressed so the feedback
    applier can patch exactly one section."""
    model_config = ConfigDict(frozen=True)

    id: str                             # required — the applier keys decisions on it
    severity: Severity = Severity.WARN
    message: str = ""
    detail: str = ""
    ref: str = ""                       # e.g. "node:df_join_data_4_s37"
    suggested_fix: str = ""             # replacement body the applier splices in when
                                        # the human accepts this issue


class EvalResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    verdict: Verdict
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    issues: tuple[Issue, ...] = ()
    summary: str = ""

    @property
    def passed(self) -> bool:
        return self.verdict is Verdict.PASS


class GenResult(BaseModel):
    """What a generator produces. ``node_keys`` is the addressable index into
    ``artifact``; ``meta`` carries agent-specific detail (origins, counts, paths)."""
    model_config = ConfigDict(frozen=True)

    artifact: str = ""
    node_keys: list[str] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)


class HumanFeedback(BaseModel):
    """A human's decision at a HITL gate. Priority P1 — outranks everything else."""
    model_config = ConfigDict(frozen=True)

    accepted_issue_ids: list[str] = Field(default_factory=list)
    rejected_issue_ids: list[str] = Field(default_factory=list)
    freeform: str = ""
    hard_constraints: list[str] = Field(default_factory=list)
    ts: str = ""
    actor: str = ""
