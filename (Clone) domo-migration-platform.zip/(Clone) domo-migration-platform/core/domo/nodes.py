"""core.domo.nodes — the node contract and the build-once generate -> evaluate -> HITL loop.

Per the Core Development Guide (§12):

* ``Node`` is an ABC using the **Template Method** pattern. The base ``__call__``
  does the cross-cutting work — times the node, emits exactly one ``NodeRow``,
  and guards against in-place state mutation — while the subclass implements
  ``run`` and returns a **state delta** (never mutates ``state``). Works for sync
  or async ``run``.
* ``Generator`` / ``Evaluator`` / ``FeedbackApplier`` are **Strategy** interfaces
  the agents inject.
* ``build_gen_eval_hitl`` is the **Factory/Builder** that assembles the shared loop
  as a LangGraph ``StateGraph``. The loop is written once here; agents never
  reimplement it. Human feedback accumulates in ``state['feedback'][agent]`` (the
  reducer-backed store), so priority-layering sees the full history.

Idempotency (guide §5.2): durable writes inside a node are keyed
``(dataflow_id, node, iteration)``. gen-eval-HITL versions by iteration; connection
and discovery overwrite. Iteration lives at ``state[agent]['iteration']``.
"""
from __future__ import annotations

import abc
import copy
import inspect
import time
from datetime import datetime, timezone
from typing import Any

from langchain_core.runnables import RunnableConfig
from langgraph.errors import GraphInterrupt
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from core.domo.observability import NodeRow, ObservabilityWriter
from core.domo.schemas import EvalResult, GenResult, HumanFeedback
from core.domo.state import RunState


# --------------------------------------------------------------------------- #
# Node base — Template Method harness
# --------------------------------------------------------------------------- #
class Node(abc.ABC):
    """Base for every node. Subclasses set ``agent``/``name`` and implement
    ``run(state, config) -> dict`` (a state delta). The base ``__call__`` adds
    timing, the per-node observability row, and the no-mutation guard.

    ``run`` may be sync or async; ``__call__`` returns a coroutine when it is async
    so LangGraph awaits it.
    """

    agent: str = ""
    name: str = ""
    #: deep-copy the input and assert it is unchanged after ``run``. On by default;
    #: disable per-node for very large states where the copy cost is unacceptable.
    strict_mutation_check: bool = True

    @abc.abstractmethod
    def run(self, state: RunState, config: RunnableConfig) -> dict: ...

    async def __call__(self, state: RunState, config: RunnableConfig) -> dict:
        snapshot = copy.deepcopy(state) if self.strict_mutation_check else None
        start = time.perf_counter()
        try:
            delta = self.run(state, config)
            if inspect.isawaitable(delta):
                delta = await delta
        except GraphInterrupt:
            raise                      # HITL pause — not a completion, not a failure
        except Exception:
            self._emit(state, config, start, status="failed")
            raise
        self._verify(state, snapshot, delta)
        self._emit(state, config, start, status="success")
        return delta

    def _verify(self, state: RunState, snapshot: Any, delta: Any) -> None:
        if not isinstance(delta, dict):
            raise TypeError(
                f"Node {self.agent}.{self.name}.run must return a dict delta, got {type(delta)!r}"
            )
        if self.strict_mutation_check and snapshot is not None and state != snapshot:
            raise RuntimeError(
                f"Node {self.agent}.{self.name} mutated state in place; return a delta instead"
            )

    def _emit(self, state: RunState, config: RunnableConfig, start: float, *, status: str) -> None:
        obs = _observability(config)
        if obs is None:
            return
        obs.record_node(NodeRow(
            obs_run_id=_cfg(config).get("obs_run_id", ""),
            thread_id=_cfg(config).get("thread_id", ""),
            agent=self.agent,
            node=self.name,
            iteration=_iteration(state, self.agent),
            status=status,
            duration_ms=int((time.perf_counter() - start) * 1000),
            hitl_wait_ms=0,               # best-effort; HITL wait not measured here
            ts=datetime.now(timezone.utc),
        ))


# --------------------------------------------------------------------------- #
# Strategy interfaces injected into the loop
# --------------------------------------------------------------------------- #
class Generator(abc.ABC):
    @abc.abstractmethod
    async def generate(self, state: RunState, config: RunnableConfig) -> GenResult: ...


class Evaluator(abc.ABC):
    @abc.abstractmethod
    async def evaluate(self, result: GenResult, state: RunState) -> EvalResult: ...


class FeedbackApplier(abc.ABC):
    @abc.abstractmethod
    def apply(self, result: GenResult, feedback: list[HumanFeedback]) -> GenResult: ...


# --------------------------------------------------------------------------- #
# The build-once generate -> evaluate -> HITL loop
# --------------------------------------------------------------------------- #
def build_gen_eval_hitl(
    *,
    name: str,
    generator: Generator,
    evaluator: Evaluator | None,
    feedback_applier: FeedbackApplier,
    hitl: bool,
    max_iters: int = 3,
) -> StateGraph:
    """Assemble the shared loop for one agent as a ``StateGraph`` over ``RunState``.

    Flow: generate -> (evaluate) -> [HITL interrupt -> resume -> apply] -> regenerate,
    until accepted or ``max_iters``. The agent's own state lives under ``state[agent]``
    (a sub-dict carrying ``iteration`` + the current ``GenResult``/``EvalResult``);
    feedback accumulates under ``state['feedback'][agent]``.
    """
    agent_name = name

    class _Generate(Node):
        agent = agent_name
        name = "generate"

        async def run(self, state: RunState, config: RunnableConfig) -> dict:
            sub = dict(state.get(agent_name) or {})
            iteration = int(sub.get("iteration", 0)) + 1
            result = await generator.generate(state, _with(config, agent_name, "generate", iteration))
            # store the artifact as a plain dict (state stays data-only/serializable)
            sub.update(iteration=iteration, gen=result.model_dump(mode="json"))
            return {agent_name: sub}

    class _Evaluate(Node):
        agent = agent_name
        name = "evaluate"

        async def run(self, state: RunState, config: RunnableConfig) -> dict:
            sub = dict(state.get(agent_name) or {})
            gen = GenResult(**sub["gen"])
            eval_result = await evaluator.evaluate(gen, state)  # type: ignore[union-attr]
            sub["eval"] = eval_result.model_dump(mode="json")
            return {agent_name: sub}

    class _Hitl(Node):
        agent = agent_name
        name = "hitl"

        def run(self, state: RunState, config: RunnableConfig) -> dict:
            sub = dict(state.get(agent_name) or {})
            gen = GenResult(**sub["gen"])
            # sub["gen"]/sub["eval"] are already plain dicts -> JSON-native interrupt payload
            raw = interrupt({
                "agent": agent_name,
                "iteration": int(sub.get("iteration", 0)),
                "artifact": sub["gen"],
                "eval": sub.get("eval"),
            })
            fb = raw if isinstance(raw, HumanFeedback) else HumanFeedback(**(raw or {}))
            # feedback field is the contract-typed accumulator (list[HumanFeedback])
            history = list((state.get("feedback") or {}).get(agent_name, [])) + [fb]
            sub["gen"] = feedback_applier.apply(gen, history).model_dump(mode="json")
            sub["last_feedback"] = fb.model_dump(mode="json")
            return {agent_name: sub, "feedback": {agent_name: [fb]}}

    def _after_generate(state: RunState) -> str:
        return "hitl" if hitl else END

    def _after_evaluate(state: RunState) -> str:
        sub = state.get(agent_name) or {}
        if hitl:
            return "hitl"
        ev = sub.get("eval") or {}
        passed = ev.get("verdict") == "pass"
        if passed or int(sub.get("iteration", 0)) >= max_iters:
            return END
        return "generate"

    def _after_hitl(state: RunState) -> str:
        sub = state.get(agent_name) or {}
        fb = sub.get("last_feedback") or {}
        done = (not fb.get("rejected_issue_ids")) and (not (fb.get("freeform") or "").strip())
        if done or int(sub.get("iteration", 0)) >= max_iters:
            return END
        return "generate"

    g: StateGraph = StateGraph(RunState)
    g.add_node("generate", _Generate())
    g.add_edge(START, "generate")

    if evaluator is not None:
        g.add_node("evaluate", _Evaluate())
        g.add_edge("generate", "evaluate")
        eval_targets = {"generate": "generate", END: END}
        if hitl:
            eval_targets["hitl"] = "hitl"
        g.add_conditional_edges("evaluate", _after_evaluate, eval_targets)
    else:
        gen_targets = {END: END}
        if hitl:
            gen_targets["hitl"] = "hitl"
        g.add_conditional_edges("generate", _after_generate, gen_targets)

    if hitl:
        g.add_node("hitl", _Hitl())
        g.add_conditional_edges("hitl", _after_hitl, {"generate": "generate", END: END})

    return g


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _cfg(config: RunnableConfig | None) -> dict[str, Any]:
    return dict((config or {}).get("configurable", {}) or {})


def _observability(config: RunnableConfig | None) -> ObservabilityWriter | None:
    c = _cfg(config)
    services = c.get("services")
    if services is not None and hasattr(services, "observability"):
        return services.observability
    return c.get("observability")


def _iteration(state: RunState, agent: str) -> int:
    return int((state.get(agent) or {}).get("iteration", 0) or 0)


def _with(config: RunnableConfig | None, agent: str, node: str, iteration: int) -> RunnableConfig:
    """Shallow-copy ``config`` with the current node context added so
    ``LLMClient.complete`` can tag observability rows with agent/node/iteration."""
    cfg = dict(config or {})
    configurable = dict(cfg.get("configurable", {}) or {})
    configurable.update(agent=agent, node=node, iteration=iteration)
    cfg["configurable"] = configurable
    return cfg  # type: ignore[return-value]
