"""core.domo.sinks — where telemetry rows go.

Two implementations behind one interface:

* ``InMemorySink`` for notebooks and tests. Collects rows, then answers the questions
  the observability brief asks: what did it cost, what did it do, what did it read,
  was it any good.
* ``DeltaSink`` for real runs. Appends to the audit tables.

Sinks never raise into the caller. Telemetry failing must not fail a migration — a
dropped row is bad, a crashed run because of a dropped row is worse. Failures are
counted on ``.errors`` so a notebook can surface them.
"""
from __future__ import annotations

import abc
import datetime as _dt
from typing import Any

from core.contracts.judges import JudgePanel
from core.contracts.telemetry import (
    DecisionRow,
    IngestionRow,
    JudgeRow,
    LlmCallRow,
    RunSummary,
    StepRow,
    ValidationRow,
    summarize,
)
from core.contracts.validation import DataflowParity, Diagnosis


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


class TelemetrySink(abc.ABC):
    """Every write is best-effort and must not propagate."""

    @abc.abstractmethod
    def llm_call(self, row: LlmCallRow) -> None: ...

    @abc.abstractmethod
    def step(self, row: StepRow) -> None: ...

    @abc.abstractmethod
    def ingestion(self, row: IngestionRow) -> None: ...

    @abc.abstractmethod
    def judge(self, row: JudgeRow) -> None: ...

    @abc.abstractmethod
    def validation(self, row: ValidationRow) -> None: ...

    @abc.abstractmethod
    def decision(self, row: DecisionRow) -> None: ...

    # -- convenience: fold a whole panel / parity result in one call -------- #
    def judge_panel(self, panel: JudgePanel, *, run_id: str, environment: str = "dev") -> None:
        for r in panel.results:
            self.judge(JudgeRow(
                run_id=run_id, ts=utc_now(), environment=environment,
                agent=panel.agent, iteration=panel.iteration, rule_id=r.rule_id,
                title=r.title, kind=r.kind.value, verdict=r.verdict.value,
                findings=len(r.findings), checked=r.checked,
                nodes=tuple(f.node for f in r.findings if f.node), note=r.note,
            ))

    def parity(self, parity: DataflowParity, *, run_id: str, environment: str = "dev",
               diagnoses: tuple[Diagnosis, ...] = ()) -> None:
        by_node = {n: d for d in diagnoses for n in d.nodes}
        for t in parity.targets:
            d = by_node.get(t.target)
            self.validation(ValidationRow(
                run_id=run_id, ts=utc_now(), environment=environment,
                dataflow_id=parity.dataflow_id, target=t.target, table=t.table,
                checks_run=len(t.ran),
                checks_passed=sum(1 for c in t.ran if not c.failed),
                blocking_failures=len(t.blocking_failures),
                advisory_failures=len(t.advisory_failures),
                exact=t.exact, passed=t.passed,
                expected_batch_id=t.expected_ref.batch_id if t.expected_ref else None,
                expected_batch_last_run=t.expected_ref.batch_last_run if t.expected_ref else None,
                failure_category=d.category.value if d else "",
                owner_agent=d.owner_agent if d else "",
                diagnosis=d.explanation if d else "",
            ))


class InMemorySink(TelemetrySink):
    """Collects everything. The notebook harness."""

    def __init__(self) -> None:
        self.llm_calls: list[LlmCallRow] = []
        self.steps: list[StepRow] = []
        self.ingestions: list[IngestionRow] = []
        self.judges: list[JudgeRow] = []
        self.validations: list[ValidationRow] = []
        self.decisions: list[DecisionRow] = []
        self.errors: list[str] = []

    def llm_call(self, row): self.llm_calls.append(row)
    def step(self, row): self.steps.append(row)
    def ingestion(self, row): self.ingestions.append(row)
    def judge(self, row): self.judges.append(row)
    def validation(self, row): self.validations.append(row)
    def decision(self, row): self.decisions.append(row)

    # -- observability answers --------------------------------------------- #
    def summary(self, run_id: str, dataflow_id: str) -> RunSummary:
        return summarize(run_id, dataflow_id, llm=self.llm_calls, steps=self.steps,
                         ingest=self.ingestions, judged=self.judges,
                         validated=self.validations, decisions=self.decisions)

    def cost_by_agent(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for c in self.llm_calls:
            out[c.agent] = round(out.get(c.agent, 0.0) + c.cost_usd, 4)
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    def tokens_by_agent(self) -> dict[str, dict[str, int]]:
        out: dict[str, dict[str, int]] = {}
        for c in self.llm_calls:
            e = out.setdefault(c.agent, {"in": 0, "out": 0, "calls": 0})
            e["in"] += c.tokens_in
            e["out"] += c.tokens_out
            e["calls"] += 1
        return out

    def judge_failures(self) -> list[JudgeRow]:
        return [j for j in self.judges if j.verdict == "fail"]

    def datasets_read(self) -> list[tuple[str, str, int]]:
        """(dataset, purpose, rows) — which DOMO datasets were pulled and why."""
        return [(i.dataset_name or i.dataset_id, i.purpose.value, i.rows_ingested)
                for i in self.ingestions]


class JsonSink(TelemetrySink):
    """Observability as JSON, for a run with no warehouse behind it.

    The mock half of the two-mode pattern the stores use: ``DeltaSink`` appends the
    six audit tables, this writes the same six row types as JSON arrays under
    ``<root>/<kind>.json``. Same models, same field names, same contract - only the
    destination differs, so nothing downstream needs to know which one ran.

    A JSON array rather than JSON Lines because these are meant to be opened and
    read during a dry run. That costs a read-modify-write per row, which is
    irrelevant at a few hundred rows and would not be at a few million: this is a
    dry-run sink and says so.

    Like the others it never raises into the caller — a dropped telemetry row is bad,
    a migration that died because a disk was full is worse. Failures land on
    ``.errors``.
    """

    #: telemetry kind -> filename stem. Matches LocalStore.ROW_TYPES; the two are one
    #: contract read from both ends, so a name changed here must change there.
    FILES = {
        "llm_call": "llm_calls", "step": "steps", "ingestion": "ingestions",
        "judge": "judges", "validation": "validations", "decision": "decisions",
    }

    def __init__(self, root: Any, run_id: str = "") -> None:
        import pathlib

        self._dir = pathlib.Path(root) / run_id if run_id else pathlib.Path(root)
        self._dir.mkdir(parents=True, exist_ok=True)
        self.run_id = run_id
        self.errors: list[str] = []

    def _append(self, kind: str, row) -> None:
        import json as _json

        try:
            path = self._dir / f"{self.FILES[kind]}.json"
            rows = []
            if path.exists():
                try:
                    rows = _json.loads(path.read_text(encoding="utf-8"))
                except ValueError:
                    # A corrupt file must not take the rest of the run's telemetry
                    # with it: keep it aside and start a clean one.
                    path.rename(path.with_suffix(".json.corrupt"))
            rows.append(_json.loads(row.model_dump_json()))
            path.write_text(_json.dumps(rows, indent=1), encoding="utf-8")
        except Exception as exc:                      # never fail the run over telemetry
            self.errors.append(f"{kind}: {type(exc).__name__}: {exc}")

    def llm_call(self, row): self._append("llm_call", row)
    def step(self, row): self._append("step", row)
    def ingestion(self, row): self._append("ingestion", row)
    def judge(self, row): self._append("judge", row)
    def validation(self, row): self._append("validation", row)
    def decision(self, row): self._append("decision", row)



class DeltaSink(TelemetrySink):
    """Appends to the audit tables. Spark is injected so the class stays importable
    (and unit-testable) without a cluster."""

    TABLES = {
        "llm_call": "llm_calls", "step": "steps", "ingestion": "ingestions",
        "judge": "judge_results", "validation": "validation_results", "decision": "decisions",
    }

    def __init__(self, spark: Any, catalog: str, schema: str) -> None:
        self._spark = spark
        self._prefix = f"{catalog}.{schema}"
        self.errors: list[str] = []

    def _append(self, kind: str, row) -> None:
        try:
            table = f"{self._prefix}.{self.TABLES[kind]}"
            df = self._spark.createDataFrame([row.model_dump(mode="json")])
            df.write.format("delta").mode("append").saveAsTable(table)
        except Exception as exc:                      # never fail the run over telemetry
            self.errors.append(f"{kind}: {type(exc).__name__}: {exc}")

    def llm_call(self, row): self._append("llm_call", row)
    def step(self, row): self._append("step", row)
    def ingestion(self, row): self._append("ingestion", row)
    def judge(self, row): self._append("judge", row)
    def validation(self, row): self._append("validation", row)
    def decision(self, row): self._append("decision", row)


class RecordingObservability:
    """Adapts core.domo.llm's observability interface onto a TelemetrySink.

    LLMClient records LlmCallRow/NodeRow; this converts them into telemetry rows so a
    notebook gets cost and step data without the agents having to know about sinks.
    ``rate_card`` is dollars per 1k tokens, applied at write time so historical rows
    stay accurate when prices move.
    """

    def __init__(self, sink: TelemetrySink, *, run_id: str, environment: str = "dev",
                 rate_card: dict[str, tuple[float, float]] | None = None) -> None:
        self._sink = sink
        self._run_id = run_id
        self._env = environment
        self._rates = rate_card or {}
        self.llm_calls: list = []
        self.node_rows: list = []

    def _cost(self, model: str, tin: int, tout: int) -> float:
        rate_in, rate_out = self._rates.get(model, (0.0, 0.0))
        return round((tin / 1000) * rate_in + (tout / 1000) * rate_out, 6)

    def record_llm_call(self, row) -> None:
        self.llm_calls.append(row)
        model = getattr(row, "model", "")
        tin = getattr(row, "tokens_in", 0) or 0
        tout = getattr(row, "tokens_out", 0) or 0
        self._sink.llm_call(LlmCallRow(
            run_id=self._run_id, ts=utc_now(), environment=self._env,
            call_id=getattr(row, "call_id", "") or f"c{len(self.llm_calls)}",
            agent=getattr(row, "agent", "") or "",
            node=getattr(row, "node", "") or "",
            iteration=int(getattr(row, "iteration", 1) or 1),
            role=getattr(row, "role", "") or "",
            model=model, pool=getattr(row, "pool", "default") or "default",
            tokens_in=tin, tokens_out=tout, cost_usd=self._cost(model, tin, tout),
            latency_ms=int(getattr(row, "latency_ms", 0) or 0),
            status=getattr(row, "status", "ok") or "ok",
            prompt_hash=getattr(row, "prompt_hash", "") or "",
        ))

    def record_node(self, row) -> None:
        self.node_rows.append(row)
        self._sink.step(StepRow(
            run_id=self._run_id, ts=utc_now(), environment=self._env,
            step_id=f"s{len(self.node_rows)}",
            agent=getattr(row, "agent", "") or "",
            phase=getattr(row, "node", "") or "",
            iteration=int(getattr(row, "iteration", 1) or 1),
            duration_ms=int(getattr(row, "duration_ms", 0) or 0),
            detail=getattr(row, "status", "") or "",
        ))
