"""core.domo.checkpoint — durable graph state: Postgres live, Delta audit mirror.

Per the Core Development Guide (§10):

* ``DeltaAuditedCheckpointer`` is an **Adapter** to LangGraph's
  ``BaseCheckpointSaver``, composed by **decoration**: it wraps a Postgres saver
  (the authoritative live store that makes ``interrupt`` / ``Command(resume)`` work)
  and, on every checkpoint write, appends one **audit row to Delta** for visibility
  and crash fallback. It reimplements no persistence of its own.
* Because nodes are idempotent, a resume that replays a node whose side effects
  already landed is safe — so the Delta append can sit at the node/checkpoint
  boundary without a fragile cross-store transaction.
* ``DeltaAuditor`` is the append interface (Spark impl injected in prod, fake in tests).
* ``RunStateReader`` is the thin read-side projection the app/UI uses for status.

One node = one super-step = one checkpoint ``put`` = one Delta audit row.

Serde note (integration requirement): the run state's contract-typed ``feedback``
field holds ``core.domo.schemas.HumanFeedback`` value objects. LangGraph's default
serializer will, in a future release, block deserializing unregistered custom types.
Whoever constructs the injected Postgres saver must therefore register the schema
module with its serializer (e.g. LangGraph's ``allowed_msgpack_modules`` /
``JsonPlusSerializer``), so ``core.domo.schemas`` value objects round-trip cleanly. The
gen-eval-HITL loop keeps all other bookkeeping (``gen`` / ``eval``) as plain dicts
to minimise this surface.
"""
from __future__ import annotations

import abc
from typing import Any, AsyncIterator, Iterator, Optional, Sequence

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.base import (
    BaseCheckpointSaver,
    ChannelVersions,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
)

from core.domo.state import RunStatus


# --------------------------------------------------------------------------- #
# Delta audit sink
# --------------------------------------------------------------------------- #
class DeltaAuditor(abc.ABC):
    """Appends a snapshot of run state to the Delta audit table. Concrete impl is
    Spark-backed; tests inject a fake with the same ``append``."""

    @abc.abstractmethod
    def append(self, thread_id: str, snapshot: dict) -> None: ...


class SparkDeltaAuditor(DeltaAuditor):
    """Default Delta implementation. Spark is imported lazily so importing
    ``core.domo.checkpoint`` never requires a Spark session."""

    def __init__(self, table: str, *, spark: Any | None = None) -> None:
        self._table = table
        self._spark = spark

    def _session(self) -> Any:
        if self._spark is not None:
            return self._spark
        from pyspark.sql import SparkSession
        self._spark = SparkSession.builder.getOrCreate()
        return self._spark

    def append(self, thread_id: str, snapshot: dict) -> None:
        import json as _json
        spark = self._session()
        row = {
            "thread_id": thread_id,
            "dataflow_id": str(snapshot.get("dataflow_id", "")),
            "current_agent": str(snapshot.get("current_agent", "")),
            "status": _status_str(snapshot.get("status")),
            "snapshot_json": _json.dumps(snapshot, default=str),
        }
        spark.createDataFrame([row]).write.format("delta").mode("append").saveAsTable(self._table)


# --------------------------------------------------------------------------- #
# The checkpointer — Adapter + Decorator over a Postgres saver
# --------------------------------------------------------------------------- #
class DeltaAuditedCheckpointer(BaseCheckpointSaver):
    """Wrap a Postgres ``BaseCheckpointSaver`` and mirror each write to Delta.

    Every LangGraph read/write is delegated to ``pg_saver`` unchanged; every
    successful ``put`` / ``aput`` additionally appends one Delta audit row.
    """

    def __init__(self, pg_saver: BaseCheckpointSaver, delta_auditor: DeltaAuditor) -> None:
        super().__init__()
        self._pg = pg_saver
        self._audit = delta_auditor

    # -- reads: pure delegation -------------------------------------------- #
    def get_tuple(self, config: RunnableConfig) -> Optional[CheckpointTuple]:
        return self._pg.get_tuple(config)

    def list(self, config: Optional[RunnableConfig], *, filter: Optional[dict[str, Any]] = None,
             before: Optional[RunnableConfig] = None, limit: Optional[int] = None) -> Iterator[CheckpointTuple]:
        return self._pg.list(config, filter=filter, before=before, limit=limit)

    async def aget_tuple(self, config: RunnableConfig) -> Optional[CheckpointTuple]:
        return await self._pg.aget_tuple(config)

    async def alist(self, config: Optional[RunnableConfig], *, filter: Optional[dict[str, Any]] = None,
                    before: Optional[RunnableConfig] = None, limit: Optional[int] = None,
                    ) -> AsyncIterator[CheckpointTuple]:
        async for item in self._pg.alist(config, filter=filter, before=before, limit=limit):
            yield item

    # -- writes: delegate, then audit -------------------------------------- #
    def put(self, config: RunnableConfig, checkpoint: Checkpoint,
            metadata: CheckpointMetadata, new_versions: ChannelVersions) -> RunnableConfig:
        out = self._pg.put(config, checkpoint, metadata, new_versions)
        self._append_audit(config, checkpoint)
        return out

    async def aput(self, config: RunnableConfig, checkpoint: Checkpoint,
                   metadata: CheckpointMetadata, new_versions: ChannelVersions) -> RunnableConfig:
        out = await self._pg.aput(config, checkpoint, metadata, new_versions)
        self._append_audit(config, checkpoint)
        return out

    def put_writes(self, config: RunnableConfig, writes: Sequence[tuple[str, Any]],
                   task_id: str, task_path: str = "") -> None:
        # Intermediate channel writes; the durable snapshot is captured on put().
        return self._pg.put_writes(config, writes, task_id, task_path)

    async def aput_writes(self, config: RunnableConfig, writes: Sequence[tuple[str, Any]],
                          task_id: str, task_path: str = "") -> None:
        return await self._pg.aput_writes(config, writes, task_id, task_path)

    # -- version helper: delegate so id scheme matches the backend --------- #
    def get_next_version(self, current: Optional[Any], channel: Any) -> Any:
        return self._pg.get_next_version(current, channel)

    # -- internals --------------------------------------------------------- #
    def _append_audit(self, config: RunnableConfig, checkpoint: Checkpoint) -> None:
        thread_id = (config or {}).get("configurable", {}).get("thread_id", "")
        snapshot = dict(checkpoint.get("channel_values", {}) or {})
        try:
            self._audit.append(thread_id, snapshot)
        except Exception as e:                      # audit must never break a run
            print(f"[checkpoint] Delta audit append failed for thread {thread_id}: {e}")


# --------------------------------------------------------------------------- #
# Read-side projection for the app / UI
# --------------------------------------------------------------------------- #
class RunStateReader:
    """Reads the latest checkpointed state for a run. Used by the app's API to
    project run status without going through the graph."""

    def __init__(self, saver: BaseCheckpointSaver) -> None:
        self._saver = saver

    def snapshot(self, thread_id: str) -> dict:
        tup = self._saver.get_tuple({"configurable": {"thread_id": thread_id}})
        if tup is None:
            return {}
        return dict(tup.checkpoint.get("channel_values", {}) or {})

    def status(self, thread_id: str) -> Optional[RunStatus]:
        raw = self.snapshot(thread_id).get("status")
        if raw is None or isinstance(raw, RunStatus):
            return raw
        try:
            return RunStatus(raw)
        except ValueError:
            return None


def _status_str(value: Any) -> str:
    if isinstance(value, RunStatus):
        return value.value
    return "" if value is None else str(value)
