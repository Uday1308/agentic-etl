"""Single place for the pipeline definition and all workspace-specific wiring.

Everything workspace-specific is env-driven (Databricks Apps `resources` can
inject it). Each agent has its OWN output location -- some write files to a
volume, some write Delta tables -- so there's a per-agent spec below rather than
one shared folder. If MIGRATION_JOB_ID isn't set the app serves mock data.
"""

from __future__ import annotations

import os


def _flag(name: str) -> bool:
    return os.getenv(name, "").strip().lower() in ("1", "true", "yes", "on")


# ---- The pipeline (canonical). Shared by the mock and live backends. ----
AGENTS = [
    {"key": "connection",      "name": "Connection"},
    {"key": "standardization", "name": "Standardization"},
    {"key": "discovery",       "name": "Discovery"},
    {"key": "plan",            "name": "MD Gen"},
    {"key": "code",            "name": "CD Gen"},
    {"key": "validation",      "name": "Validation"},
]
AGENT_KEYS = [a["key"] for a in AGENTS]

# UI label + how the primary output renders: graph | json | markdown | code | table
OUTPUT_TYPES = {
    "connection":      {"label": "Connections",  "kind": "graph"},
    "standardization": {"label": "Standardized", "kind": "graph"},
    "discovery":       {"label": "Discovery",    "kind": "table"},
    "plan":            {"label": "Plans",        "kind": "markdown"},
    "code":            {"label": "Code",         "kind": "code"},
    "validation":      {"label": "Validation",   "kind": "table"},
}

# ---- Workspace wiring ----
CATALOG = os.getenv("UC_CATALOG", "dev_test")
SCHEMA = os.getenv("UC_SCHEMA", "dev_domo_migration")
VOLUME_ROOT = f"/Volumes/{CATALOG}/{SCHEMA}"

JOB_ID = os.getenv("MIGRATION_JOB_ID")
WAREHOUSE_ID = os.getenv("SQL_WAREHOUSE_ID")

# Job parameters the run is launched with (Connection agent consumes these).
# NOTE: limits_id == dataflow_id (the value the user enters). run_id is separate.
LIMITS_PARAM_NAME = os.getenv("LIMITS_PARAM_NAME", "limits_id")
ENV_PARAM_NAME = os.getenv("ENV_PARAM_NAME", "environment")
DATAFLOW_PARAM_NAME = os.getenv("DATAFLOW_PARAM_NAME", "dataflow_name")

ENVIRONMENTS = ["dev", "ust", "prod"]

# app_name is a constant now ("DOMO"); the per-dataflow identifier lives in the
# discovery table name, which the app resolves by limits_id (see below).
APP_NAME = os.getenv("APP_NAME", "DOMO")

RUN_HISTORY_LIMIT = int(os.getenv("RUN_HISTORY_LIMIT", "40"))
USE_MOCK = _flag("USE_MOCK")
LIVE = bool(JOB_ID) and not USE_MOCK

# ---- Per-agent output location ----
# Placeholders resolved at read time: {limits_id} {app_name} {run_id} {environment}
# File outputs -> (dir, file). Table outputs -> table (catalog.schema.name).
# Some paths depend on {app_name}, which discovery produces mid-run; see
# resolve_app_name() in databricks_client. Filenames for md/cd default to
# {limits_id}.md / .py -- adjust if the notebooks use something else.
OUTPUT_LOCATIONS = {
    "connection": {
        "type": "file",
        "dir": f"{VOLUME_ROOT}/domo_json_src/domo_etl_flow_json",
        "file": "dataflow_{limits_id}.json",
        # Connection also writes the dataset list to this table (shown under the graph).
        "aux_table": f"{CATALOG}.{SCHEMA}.domo_dataset_details",
    },
    "standardization": {
        "type": "file",
        # verbatim from spec -- confirm the spelling "stardardized".
        "dir": f"{VOLUME_ROOT}/domo_json_src/domo_json_stardardized",
        "file": "cleaned_dataflow_{limits_id}.json",
    },
    "discovery": {
        "type": "table",
        # Named with the dataflow name, which is a launch input (job parameter),
        # used directly here — no lookup.
        "table": f"{CATALOG}.{SCHEMA}.discovery_{{dataflow_name}}_{{limits_id}}",
    },
    "plan": {
        "type": "file",
        "dir": f"{VOLUME_ROOT}/md-cd/{{dataflow_name}}/md",
        "file": "{limits_id}.md",
    },
    "code": {
        "type": "file",
        "dir": f"{VOLUME_ROOT}/md-cd/{{dataflow_name}}/cd",
        "file": "{limits_id}.py",
    },
    "validation": {
        "type": "table",
        "table": f"{CATALOG}.{SCHEMA}.validation_result",
    },
}


def resolve(template: str, **ctx) -> str:
    return template.format(**ctx)


def file_path(agent_key: str, **ctx) -> str:
    loc = OUTPUT_LOCATIONS[agent_key]
    return f"{resolve(loc['dir'], **ctx)}/{resolve(loc['file'], **ctx)}"


def table_name(agent_key: str, **ctx) -> str:
    return resolve(OUTPUT_LOCATIONS[agent_key]["table"], **ctx)


# ---- Run-level (per-run viewer) settings. The Explorer is NOT affected by these. ----

# Full paths of the md/cd files shown in the run-level Plan and Code tabs.
# Folder-level distinction is by dataflow_name; filenames carry the dataflow id.
# >>> EDIT THESE LINES to change the full run-level md / cd paths. <<<
RUN_MD_PATH = f"{VOLUME_ROOT}/md-cd/{{dataflow_name}}/md/plan_{{limits_id}}.md"
RUN_CD_PATH = f"{VOLUME_ROOT}/md-cd/{{dataflow_name}}/cd/etl_etl_{{limits_id}}.py"

# Run-level Validation: show the latest (max run_timestamp) row for this
# source_dataset / target_dataset pair. >>> SET THESE to your datasets. <<<
VALIDATION_SOURCE_DATASET = "REPLACE_SOURCE_DATASET"
VALIDATION_TARGET_DATASET = "REPLACE_TARGET_DATASET"

# Columns surfaced in the run-level Validation view (JSON columns are parsed).
VALIDATION_COLUMNS = [
    "schema_check_result",
    "row_count_check",
    "column_accuracy_result",
    "statistical_profile_result",
    "row_reconciliation_result",
    "overall_result_json",
    "overall_status",
]
