"""core.lakebridge - the ONLY migrator module allowed new ``databricks`` imports (ADR 032 sections 1 and 6, P3-12).

``tests/test_lakebridge_boundary.py`` greps the rest of the new code for them. Lakebridge is optional: without the
CLI (or, in job mode, the SDK) ``available()`` returns the reason and tier 1 is reported ``unavailable``. Command
and flags follow the Lakebridge docs at the pinned version (open question 2, D-17: to verify against a real install;
this module is exercised offline only through an injected runner).
"""
from __future__ import annotations

import contextlib
import datetime
import io
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time
from collections.abc import Callable
from typing import Any

from agents.cd_codegen.translate.ports import SqlUnit, TranspileResult, assert_allowed

#: environment the CLI gets: the app's service principal (or a profile) plus PATH / JAVA_HOME; nothing else
ENV_KEYS = ("DATABRICKS_HOST", "DATABRICKS_CLIENT_ID", "DATABRICKS_CLIENT_SECRET", "DATABRICKS_CONFIG_PROFILE",
            "PATH", "JAVA_HOME", "SYSTEMROOT", "HOME", "USERPROFILE")
DEFAULT_TRANSPILER = "bladebridge"
JOB_NAME = "lakebridge_transpile"


def clean_env(environ: dict[str, str] | None = None) -> dict[str, str]:
    src = os.environ if environ is None else environ
    return {k: src[k] for k in ENV_KEYS if k in src}


class LakebridgeCliTranspiler:
    """``subprocess.run([...], shell=False, timeout=...)``; temp folders (they hold source SQL) are made with
    ``mkdtemp`` and deleted in ``finally``. ``runner`` is injectable for tests."""

    def __init__(self, *, command: str = "databricks", transpiler: str = DEFAULT_TRANSPILER, timeout_s: int = 600,
                 runner: Callable[..., subprocess.CompletedProcess] = subprocess.run, version: str = "") -> None:
        assert_allowed(transpiler)
        self.name, self.command, self.timeout_s = transpiler, command, timeout_s
        self.runner, self.version = runner, version

    def available(self) -> str | None:
        return None if shutil.which(self.command) else f"Lakebridge CLI {self.command!r} not found on PATH"

    def transpile(self, units: list[SqlUnit], source_dialect: str) -> list[TranspileResult]:
        src, out = tempfile.mkdtemp(prefix="lbsrc_"), tempfile.mkdtemp(prefix="lbout_")
        started = time.monotonic()
        try:
            for u in units:
                p = pathlib.Path(src) / u.path
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(u.sql, encoding="utf-8")
            cmd = [self.command, "labs", "lakebridge", "transpile", "--input-source", src, "--output-folder", out,
                   "--source-dialect", source_dialect, "--transpiler-config-path", self.name]
            proc = self.runner(cmd, shell=False, timeout=self.timeout_s, env=clean_env(),
                               capture_output=True, text=True)
            ms = int((time.monotonic() - started) * 1000)
            log = str(getattr(proc, "stdout", "")) + "\n" + str(getattr(proc, "stderr", ""))
            rc = getattr(proc, "returncode", 0)
            results = []
            for u in units:
                f = pathlib.Path(out) / u.path
                sql = f.read_text(encoding="utf-8") if f.exists() else ""
                err = "" if sql else (f"no output for {u.path}" if rc == 0 else f"lakebridge exited {rc}")
                warn = [ln.strip() for ln in log.splitlines() if u.path in ln and "warn" in ln.lower()]
                results.append(TranspileResult(u.fingerprint, sql, self.name, self.version, warn, err, ms))
            return results
        finally:
            shutil.rmtree(src, ignore_errors=True)
            shutil.rmtree(out, ignore_errors=True)


class UnavailableTranspiler:
    """Tier 1 is requested but cannot run (allow-list empty, bad config): ``available()`` carries the reason."""

    def __init__(self, reason: str, name: str = DEFAULT_TRANSPILER) -> None:
        self.name, self.reason = name, reason

    def available(self) -> str | None:
        return self.reason

    def transpile(self, units: list[SqlUnit], source_dialect: str) -> list[TranspileResult]:
        raise RuntimeError(self.reason)


class LakebridgeJobTranspiler:
    """Submits the bundle job ``lakebridge_transpile`` (``jobs/lakebridge_transpile.py``) through the Jobs API on
    compute with Java and the pinned Lakebridge install. Protocol over the restricted UC volume path
    ``<volume>/_lakebridge/<batch_run_id>/``: ``request.json`` (statements + source dialect, no secrets) in,
    ``result.json`` (per statement: SQL or error) out; the folder is deleted in ``finally``. ``client`` is injectable
    (tests); the SDK is imported lazily so importing this module never needs it."""

    def __init__(self, *, volume_path: str, batch_run_id: str, transpiler: str = DEFAULT_TRANSPILER,
                 allowlist: tuple[str, ...] = (), job_id: str = "", job_name: str = JOB_NAME,
                 timeout_s: int = 600, client: Any = None) -> None:
        assert_allowed(transpiler)
        self.name, self.volume_path, self.batch_run_id = transpiler, volume_path, batch_run_id
        self.allowlist = tuple(allowlist) or (transpiler,)
        self.job_id, self.job_name, self.timeout_s = job_id, job_name, timeout_s
        self._client = client

    def available(self) -> str | None:
        if self._client is not None:
            return None
        try:
            import databricks.sdk  # noqa: F401,TID251
        except ImportError:
            return "databricks-sdk is not installed (job mode needs it)"
        return None

    def _w(self) -> Any:
        if self._client is not None:
            return self._client
        from databricks.sdk import WorkspaceClient  # noqa: TID251

        return WorkspaceClient()

    def _job_id(self, w: Any) -> int:
        if self.job_id:
            return int(self.job_id)
        job = next(iter(w.jobs.list(name=self.job_name)), None)
        if job is None:
            raise RuntimeError(f"job {self.job_name!r} not found (set MIGRATOR_LAKEBRIDGE_JOB_ID)")
        return int(job.job_id)

    def transpile(self, units: list[SqlUnit], source_dialect: str) -> list[TranspileResult]:
        w = self._w()
        base = f"{self.volume_path.rstrip('/')}/_lakebridge/{self.batch_run_id}"
        request = {"source_dialect": source_dialect, "transpiler": self.name,
                   "units": [{"id": u.fingerprint, "path": u.path, "sql": u.sql} for u in units]}
        started = time.monotonic()
        try:
            w.files.upload(f"{base}/request.json", io.BytesIO(json.dumps(request).encode("utf-8")), overwrite=True)
            params = {"request_path": f"{base}/request.json", "result_path": f"{base}/result.json",
                      "allowlist": ",".join(self.allowlist)}
            waiter = w.jobs.run_now(self._job_id(w), job_parameters=params)
            try:
                waiter.result(timeout=datetime.timedelta(seconds=self.timeout_s))
            except TypeError:  # a waiter without a timeout argument
                waiter.result()
            doc = json.loads(w.files.download(f"{base}/result.json").contents.read().decode("utf-8"))
        finally:
            with contextlib.suppress(Exception):  # best effort; the volume is restricted to the app's principal
                w.files.delete_directory(base)
        ms = int((time.monotonic() - started) * 1000)
        tool, version = str(doc.get("tool") or self.name), str(doc.get("version") or "")
        by_id = {str(r.get("id")): r for r in doc.get("results", [])}
        out = []
        for u in units:
            r = by_id.get(u.fingerprint)
            if r is None:
                out.append(TranspileResult(u.fingerprint, tool=tool, tool_version=version, duration_ms=ms,
                                           error="no result for this statement"))
                continue
            sql = str(r.get("sql") or "")
            err = "" if sql else str(r.get("error") or "no output")[:200]
            out.append(TranspileResult(u.fingerprint, sql, tool, version, list(r.get("warnings") or []), err, ms))
        return out


# ---- configuration ---------------------------------------------------------------------------------------------

MODES = ("off", "job", "cli")
ALLOWLIST_FILE = pathlib.Path(__file__).resolve().parent.parent / "config" / "lakebridge.json"


def load_allowlist(path: pathlib.Path | None = None, environ: dict[str, str] | None = None) -> tuple[str, ...]:
    """Rule-based transpilers allowed to produce tier 1. Ships EMPTY (``config/lakebridge.json``) until the names are
    verified at the pinned version; ``MIGRATOR_LAKEBRIDGE_ALLOWLIST`` (comma list) overrides the file."""
    env = os.environ if environ is None else environ
    if env.get("MIGRATOR_LAKEBRIDGE_ALLOWLIST") is not None:
        raw: Any = env["MIGRATOR_LAKEBRIDGE_ALLOWLIST"].split(",")
    else:
        p = path or ALLOWLIST_FILE
        raw = json.loads(p.read_text(encoding="utf-8")).get("allowlist", []) if p.exists() else []
    return tuple(str(t).strip().lower() for t in raw if str(t).strip())


def tier1_from_env(*, volume: str | pathlib.Path, batch_run_id: str, environ: dict[str, str] | None = None,
                   allowlist_path: pathlib.Path | None = None, client: Any = None) -> tuple[Any, Any, str]:
    """``(transpiler, TranslationSettings | None, mode)`` from ``MIGRATOR_LAKEBRIDGE`` (off | job | cli).
    ``off`` -> ``(None, None, "off")``. Requested but unusable -> an ``UnavailableTranspiler`` carrying the reason.
    LLM-backed (non-deterministic) transpilers on the allow-list are rejected, never run."""
    from agents.cd_codegen.translate.chain import TranslationConfigError, TranslationSettings

    env = os.environ if environ is None else environ
    mode = (env.get("MIGRATOR_LAKEBRIDGE") or "off").strip().lower()
    if mode not in MODES:
        return (UnavailableTranspiler(f"MIGRATOR_LAKEBRIDGE={mode!r} is not off|job|cli"),
                TranslationSettings(lakebridge_enabled=True), mode)
    if mode == "off":
        return None, None, "off"
    allow = load_allowlist(allowlist_path, env)
    try:
        settings = TranslationSettings(lakebridge_enabled=True, lakebridge_mode=mode, lakebridge_transpilers=allow)
    except TranslationConfigError as exc:
        return (UnavailableTranspiler(f"allow-list rejected: {exc}"[:300]),
                TranslationSettings(lakebridge_enabled=True), mode)
    if not allow:
        return UnavailableTranspiler("allow-list empty"), settings, mode
    if mode == "cli":
        return LakebridgeCliTranspiler(transpiler=allow[0]), settings, mode
    return (LakebridgeJobTranspiler(volume_path=str(volume), batch_run_id=batch_run_id, transpiler=allow[0],
                                    allowlist=allow, job_id=env.get("MIGRATOR_LAKEBRIDGE_JOB_ID", ""),
                                    client=client), settings, mode)


def tier1_label(mode: str, tier1: dict) -> str:
    """``on (job)`` / ``off`` / ``unavailable: <reason>`` for the report and Overview."""
    if tier1.get("status") == "ok":
        return f"on ({mode or 'cli'})"
    if mode == "off" or not mode:
        return "off"
    return f"unavailable: {tier1.get('reason') or 'unknown'}"


def workspace_api_from_env() -> Any:
    """``api(method, path, body=None, query=None) -> dict`` over the workspace REST API (S13 deploy: jobs, notebooks).
    The SDK is imported lazily; the default credential chain applies. Kept here with the other Databricks imports."""
    from databricks.sdk import WorkspaceClient  # noqa: TID251

    client = WorkspaceClient().api_client

    def api(method: str, path: str, body: dict | None = None, query: dict | None = None) -> dict:
        return client.do(method, path, body=body, query=query) or {}

    return api


__all__ = ["DEFAULT_TRANSPILER", "ENV_KEYS", "JOB_NAME", "LakebridgeCliTranspiler", "LakebridgeJobTranspiler",
           "UnavailableTranspiler", "clean_env", "load_allowlist", "tier1_from_env", "tier1_label",
           "workspace_api_from_env"]
