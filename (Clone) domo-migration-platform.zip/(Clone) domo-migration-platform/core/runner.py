"""core.runner - the promoted runner (ADR 032 section 3 "Runner, honestly", P3-10).

``run_pipeline(etl, *, pack, collaborators, gates)`` runs ONE ETL through its source pack with injected ports. The
mocked harness (``scripts/e2e_mock_run.py``) is one ``collaborators`` set: a DOMO ETL is delegated to it unchanged
(DOMO plan and SQL goldens do not move); any pack that exports ``run_etl`` (the Snowflake pack) runs through the
generic path below. Real ports (SQL API client, warehouse) are passed by the caller, never built here.

``HarnessGates`` is the review rule as a port: the harness actor approves only ``plan`` / ``sql`` gates of ETLs whose
units are all ``mapped``; ``translation`` items and any ``ai`` / ``transpiled`` / ``manual`` unit (or ``review``
caveat) stay open, whatever the runner (``core.review``). A gate whose payload hash equals an earlier human approval
is re-approved ``reused_from`` that decision (``--resume``).
"""
from __future__ import annotations

import datetime as dt
import json
import pathlib
from dataclasses import dataclass, field
from typing import Any

from core.packs import Collaborators, SourcePack
from core.review import AWAITING_REVIEW, may_auto_approve, payload_hash

#: gate agent -> the payload kind the review rule knows
GATE_KINDS = {"translation": "translation", "cd_codegen": "sql", "md_plan": "plan"}


@dataclass
class GateDecision:
    gate_id: str
    agent: str
    status: str                       # approved | open
    payload_hash: str = ""
    reason: str = ""
    reused_from: str = ""
    reviewer: str = ""


class HarnessGates:
    """The default ``gates`` port: apply the review rule, reuse unchanged human approvals."""

    def __init__(self, reuse: dict[str, dict] | None = None, *, actor: str = "harness", stop_at: str = "",
                 ledger: Any = None) -> None:
        self.ledger = ledger   # core.decision_ledger.DecisionLedger: per-unit carry-over (S11)
        self.reuse = dict(reuse or {})
        self.actor, self.stop_at = actor, stop_at

    def decide(self, agent: str, payload: dict, *, origins: list[str] | tuple = (), review_caveats: list[str] | tuple = (),  # noqa: E501
               gate_id: str = "") -> GateDecision:
        h = payload_hash(payload.get("reviewed", payload))
        gid = gate_id or f"gate-{agent}"
        if self.stop_at == agent:
            return GateDecision(gid, agent, "open", h, f"--stop-at {agent}")
        allowed, why = may_auto_approve(GATE_KINDS.get(agent, agent), origins, review_caveats)
        reuse = self.reuse.get(agent) or {}
        if not allowed and reuse.get("payload_hash") and reuse["payload_hash"] == h:
            return GateDecision(gid, agent, "approved", h, "", reuse.get("decision_id", ""), reuse.get("reviewer", ""))
        if not allowed and self.ledger is not None and agent == "translation":
            hits = self.ledger.carry_over(payload)
            if hits:
                ids = sorted({str(r.get("decision_id")) for r in hits})
                who = sorted({str(r.get("reviewer")) for r in hits})
                return GateDecision(gid, agent, "approved", h, "", "ledger:" + ",".join(ids), ", ".join(who))
        if not allowed:
            return GateDecision(gid, agent, "open", h, why)
        return GateDecision(gid, agent, "approved", h, "", "", self.actor)


@dataclass
class RunRecord:
    """What ``run_batch`` reads from a run: ``run_id``, ``artifacts`` (folder), ``completed``, ``failures``, ``held``,
    ``coverage``, plus the per-unit records and the in-memory outcome for batch assembly."""

    etl_id: str
    etl_key: str
    run_id: str
    artifacts: pathlib.Path
    completed: list[str] = field(default_factory=list)
    failures: list[str] = field(default_factory=list)
    held: list[dict] = field(default_factory=list)
    gates: list[dict] = field(default_factory=list)
    coverage: dict | None = None
    tiers: dict = field(default_factory=dict)
    units: list[dict] = field(default_factory=list)
    outcome: Any = None                       # packs.snowflake.assembly.EtlOutcome (in memory only)
    status_override: str = ""
    reason: str = ""
    #: which translator ran the AI tier: serving | scripted | off (empty for packs without one)
    llm: str = ""
    #: the source SQL / body of the unit, by hash: ``{artifact_ref, sha256}`` (no SQL in the record); the text stays
    #: on the restricted volume (``GET /api/artifacts/{ref}``), so the UI can show source beside generated
    source_definition_ref: dict | None = None
    started: str = field(default_factory=lambda: dt.datetime.now(dt.UTC).isoformat())

    @property
    def awaiting_review(self) -> bool:
        return bool(self.held)

    @property
    def status(self) -> str:
        if self.status_override:
            return self.status_override
        if self.failures:
            return "failed"
        return AWAITING_REVIEW if self.held else "migrated"

    def gate(self, agent: str, payload: dict, decision: GateDecision, **extra: Any) -> dict:
        body = {"gate_id": decision.gate_id, "run_id": self.run_id, "dataflow_id": self.etl_key, "agent": agent,
                "status": "approved" if decision.status == "approved" else "interrupted",
                "payload_hash": decision.payload_hash, **extra, **payload}
        if decision.status != "approved":
            body["review_required"] = decision.reason
            self.held.append({"gate_id": decision.gate_id, "agent": agent, "reason": decision.reason,
                              "payload_hash": decision.payload_hash})
        elif decision.reused_from:
            body["reused_from"] = decision.reused_from
            body["reviewer"] = decision.reviewer
        d = self.artifacts / "gates"
        d.mkdir(parents=True, exist_ok=True)
        (d / f"{decision.gate_id}.json").write_text(json.dumps(body, indent=1, default=str), encoding="utf-8")
        self.gates.append(body)
        return body

    def write_record(self) -> pathlib.Path:
        p = self.artifacts / "run.json"
        p.write_text(json.dumps({
            "etl_id": self.etl_id, "etl_key": self.etl_key, "run_id": self.run_id, "status": self.status,
            "completed": self.completed, "failures": self.failures, "held": self.held, "coverage": self.coverage,
            "tiers": self.tiers, "units": self.units, "reason": self.reason, "llm": self.llm, "started": self.started,
            "source_definition_ref": self.source_definition_ref,
            "ts": dt.datetime.now(dt.UTC).isoformat()}, indent=1, default=str), encoding="utf-8")
        return p


async def run_pipeline(etl: dict, *, pack: SourcePack, collaborators: Collaborators | None = None,
                       gates: HarnessGates | Any | None = None, work: pathlib.Path | str = ".",
                       volume: pathlib.Path | str = "", stop_at: str = "", column_style: str = "delta_safe",
                       naming: dict | None = None, reuse_approvals: dict[str, dict] | None = None,
                       source_id: str = "", batch: Any = None, input_json: str = "") -> Any:
    """Run one ETL. ``etl`` is the manifest row (``etl_id``, ``engine``, ``inputs`` ...) plus ``payload`` (the raw
    definition). Returns a ``RunRecord`` (Snowflake) or the harness ``Run`` (DOMO)."""
    collaborators = collaborators or pack.collaborators("mock")
    runner = getattr(pack, "run_etl", None)
    if runner is None:                                    # DOMO: the mocked harness, unchanged
        from e2e_mock_run import run_pipeline as domo_run  # scripts/ is on sys.path in the batch runner and tests

        return await domo_run(str(etl["etl_id"]), work=pathlib.Path(work), stop_at=stop_at, column_style=column_style,
                              input_json=input_json, volume=volume, naming=naming,
                              reuse_approvals=reuse_approvals, source_id=source_id)
    gates = gates or HarnessGates(reuse_approvals, stop_at=stop_at)
    return await runner(etl, collaborators=collaborators, gates=gates, work=pathlib.Path(work),
                        volume=pathlib.Path(volume) if volume else pathlib.Path(work) / "volume",
                        source_id=source_id, stop_at=stop_at, batch=batch)


__all__ = ["GATE_KINDS", "GateDecision", "HarnessGates", "RunRecord", "run_pipeline"]
