"""core.decision_ledger - review decisions kept per unit, for carry-over and suggestions (S11, ADR 037).

One JSON line per unit decision: ``{ts, gate_id, decision_id, reviewer, decision, scope, fingerprint, origin, caveats,
rationale}``. No source text, no generated SQL. Written by the API after every feedback (``record_feedback``), read by

* ``HarnessGates`` (``carry_over``): a translation gate whose every unit was already approved with the SAME
  caveats on the SAME statement fingerprint (and an origin the policy lists) is approved again, with
  ``reused_from`` naming the decisions.
  Units with no code, edited units and AI-origin units never carry over.
* the review UI (``suggest``): similar past decisions, shown as a hint. Suggest only; nothing is applied from them.
"""
from __future__ import annotations

import json
import pathlib
import threading
from collections import Counter
from typing import Any

from core.review_policy import ReviewPolicy
from core.review_policy import policy as default_policy

LEDGER_NAME = "decision_ledger.jsonl"
_LOCK = threading.Lock()


class DecisionLedger:
    def __init__(self, path: pathlib.Path | str, pol: ReviewPolicy | None = None) -> None:
        self.path = pathlib.Path(path)
        self.pol = pol or default_policy()
        self._rows: list[dict] | None = None

    def rows(self) -> list[dict]:
        if self._rows is None:
            out: list[dict] = []
            try:
                for line in self.path.read_text(encoding="utf-8").splitlines():
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(d, dict):
                        out.append(d)
            except OSError:
                pass
            self._rows = out
        return self._rows

    def append(self, rows: list[dict]) -> None:
        if not rows:
            return
        with _LOCK:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                for r in rows:
                    fh.write(json.dumps(r, sort_keys=True) + "\n")
        self._rows = None

    # ------------------------------------------------------------------ carry-over
    def carry_over(self, payload: dict) -> list[dict] | None:
        """The ledger rows that cover EVERY unit of a translation gate payload, else None (the gate stays open)."""
        if not self.pol.carry_enabled:
            return None
        units = (payload.get("artifact") or {}).get("units") or []
        if not units or payload.get("no_code_unit_ids"):
            return None
        approved = {(r.get("fingerprint"), tuple(r.get("caveats") or []), r.get("origin")): r
                    for r in self.rows() if r.get("decision") == "approve" and r.get("scope") == "translation"
                    and r.get("fingerprint")}
        hits: list[dict] = []
        for u in units:
            if (u.get("no_code") or u.get("edited") or not u.get("fingerprint")
                    or u.get("origin") not in self.pol.carry_origins or str(u.get("status")) != "resolved"):
                return None
            hit = approved.get((u["fingerprint"], tuple(sorted(u.get("review_caveats") or [])), u.get("origin")))
            if hit is None:
                return None
            hits.append(hit)
        return hits

    # ------------------------------------------------------------------ suggestions
    def suggest(self, fingerprint: str, caveats: list[str]) -> list[dict]:
        """Similar past decisions, best match first: same statement, then same caveat set, then overlapping caveats."""
        if not self.pol.suggest_enabled:
            return []
        want = tuple(sorted(caveats))
        groups: dict[tuple[str, str], list[dict]] = {}
        for r in self.rows():
            rc = tuple(r.get("caveats") or [])
            if fingerprint and r.get("fingerprint") == fingerprint and rc == want:
                basis = "same_statement"
            elif want and rc == want:
                basis = "same_caveats"
            elif want and set(rc) & set(want):
                basis = "overlapping_caveats"
            else:
                continue
            groups.setdefault((basis, str(r.get("decision"))), []).append(r)
        order = {"same_statement": 0, "same_caveats": 1, "overlapping_caveats": 2}
        out = []
        for (basis, decision), rs in groups.items():
            last = max(rs, key=lambda r: str(r.get("ts")))
            out.append({"basis": basis, "decision": decision, "count": len(rs),
                        "last_reviewer": last.get("reviewer", ""),
                        "last_ts": last.get("ts", ""), "rationale": str(last.get("rationale") or "")})
        out.sort(key=lambda s: (order[s["basis"]], -s["count"]))
        return out[: self.pol.suggest_max]


def for_store(store: Any) -> DecisionLedger | None:
    """The ledger of a store that keeps its work files on disk (``LocalStore.work``); None for the others."""
    work = getattr(store, "work", None)
    return DecisionLedger(pathlib.Path(work) / "feedback" / LEDGER_NAME) if work is not None else None


def record_feedback(ledger: DecisionLedger | None, gate: dict, *, approve: bool, reviewer: str, decision_id: str,
                    edits: set[str] | frozenset[str] = frozenset(), out_of_scope: dict[str, str] | None = None,
                    rationale: str = "", ts: str = "") -> int:
    """One ledger row per unit (translation gate) or per artifact (sql gate) of ``gate``. Returns the row count."""
    if ledger is None:
        return 0
    out_of_scope = out_of_scope or {}
    art = gate.get("artifact") or {}
    rows: list[dict] = []
    base = {"ts": ts, "gate_id": gate.get("gate_id"), "decision_id": decision_id, "reviewer": reviewer}
    for u in art.get("units") or []:
        uid = str(u.get("unit_id"))
        decision = ("out_of_scope" if uid in out_of_scope else "edited" if uid in edits
                    else "approve" if approve else "changes")
        rows.append({**base, "decision": decision, "scope": "translation", "unit_id": uid,
                     "fingerprint": u.get("fingerprint") or "", "origin": u.get("origin") or "",
                     "caveats": sorted(u.get("review_caveats") or []), "engine": u.get("engine") or "",
                     "rationale": out_of_scope.get(uid) or rationale})
    if not art.get("units"):
        for a in art.get("artifacts") or []:
            rows.append({**base, "decision": "approve" if approve else "changes", "scope": "sql",
                         "fingerprint": a.get("sha256") or "", "origin": a.get("origin") or "",
                         "caveats": sorted(a.get("caveats") or []), "engine": "", "rationale": rationale})
    ledger.append(rows)
    return len(rows)


def summary_counts(ledger: DecisionLedger) -> dict[str, int]:
    return dict(Counter(str(r.get("decision")) for r in ledger.rows()))


__all__ = ["DecisionLedger", "LEDGER_NAME", "for_store", "record_feedback", "summary_counts"]
