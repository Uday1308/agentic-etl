"""core.review - the review rule and the run / batch statuses (ADR 032 section 3).

Review rule (no bot approval): ``translation`` review items, and any unit whose origin is
``ai``, ``transpiled`` or ``manual`` (or that hit a ``review`` caveat), are never
auto-approved, whatever the runner. The harness actor may approve only ``plan`` and
``sql`` gates of ETLs whose units are ALL ``mapped``; otherwise the gate stays open and
the ETL ends ``awaiting_review``, not ``migrated``.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from typing import Any

#: gate payload kinds the harness actor may approve (and only when every unit is mapped)
AUTO_APPROVABLE_KINDS = frozenset({"plan", "sql"})
#: unit origins that always need a human
REVIEW_ORIGINS = frozenset({"ai", "transpiled", "manual"})

AWAITING_REVIEW = "awaiting_review"
#: batch row statuses: today's four, the review ones (section 3), ADR 033's dispositions
BATCH_STATUSES = ("migrated", "stopped", "failed", "skipped", AWAITING_REVIEW, "blocked", "unsupported",
                  "lifted", "retired", "undecided", "proposed")
#: old spelling -> value; readers accept both, writers emit the value
STATUS_ALIASES = {"awaiting review": AWAITING_REVIEW}


def normalize_status(status: str | None) -> str:
    s = (status or "").strip()
    return STATUS_ALIASES.get(s.lower(), s)


def may_auto_approve(kind: str | None, origins: Iterable[str] = (),
                     review_caveats: Iterable[str] = ()) -> tuple[bool, str]:
    """``(allowed, why_not)`` for the harness actor on one gate."""
    origins = list(origins)
    if kind == "translation":
        return False, "translation review items are never auto-approved"
    caveats = sorted(set(review_caveats))
    if caveats:
        return False, f"review caveat(s) {', '.join(caveats)}"
    if kind not in AUTO_APPROVABLE_KINDS:
        # validation / classifier gates are reached only after the plan and SQL were approved
        return True, ""
    not_mapped = sorted({o for o in origins if o != "mapped"})
    if not_mapped:
        return False, f"unit origin(s) {', '.join(not_mapped)} need a human reviewer"
    return True, ""


def payload_hash(obj: Any) -> str:
    """A stable hash of a gate payload's reviewed content (plan document hash, SQL sha256s)."""
    if isinstance(obj, str):
        data = obj
    else:
        data = json.dumps(obj, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def counts_of(rows: Iterable[dict]) -> dict[str, int]:
    rows = list(rows)
    return {s: sum(normalize_status(r.get("status")) == s for r in rows) for s in BATCH_STATUSES}


__all__ = ["AUTO_APPROVABLE_KINDS", "AWAITING_REVIEW", "BATCH_STATUSES", "REVIEW_ORIGINS", "STATUS_ALIASES",
           "counts_of", "may_auto_approve", "normalize_status", "payload_hash"]
