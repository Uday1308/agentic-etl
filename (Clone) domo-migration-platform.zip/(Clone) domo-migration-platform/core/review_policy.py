"""core.review_policy - which review items may be accepted as a group, and the grouping itself (S11, ADR 037).

Ported in part from SNF2DBX-main/migration/review_policy.py (LatentView internal): the YAML policy idea.

Grouping is by caveat family (the SNW00x id) of a gate's most severe caveat. Whether a gate may be group-accepted is
decided HERE, from ``config/review_policy.yaml``; the API recomputes it on every accept and never trusts the client.
Group acceptance only chooses WHICH gates one click submits: each gate still gets its own ``submit_feedback`` call, its
own decision rows and the same artifact-hash and no-code checks.
"""
from __future__ import annotations

import functools
import pathlib
from dataclasses import dataclass, field
from typing import Any

import yaml

# Ported from SNF2DBX-main/migration/review_policy.py (LatentView internal)
POLICY_FILE = pathlib.Path(__file__).resolve().parents[1] / "config" / "review_policy.yaml"
SEVERITY_RANK = {"info": 0, "review": 1, "escalate": 2, "block": 3}
#: never group-accepted, whatever the file says
ALWAYS_INDIVIDUAL_SEVERITIES = frozenset({"escalate", "block"})


@dataclass(frozen=True)
class ReviewPolicy:
    group_enabled: bool = True
    allow_severities: frozenset = frozenset({"info"})
    allow_caveats: frozenset = frozenset()
    individual_caveats: frozenset = frozenset()
    individual_origins: frozenset = frozenset({"ai", "manual", "unresolved"})
    carry_enabled: bool = True
    carry_origins: frozenset = frozenset({"mapped", "transpiled"})
    suggest_enabled: bool = True
    suggest_max: int = 3


def _set(v: Any) -> frozenset:
    return frozenset(str(x) for x in (v or []))


def load_policy(path: pathlib.Path | str | None = None) -> ReviewPolicy:
    try:
        raw = yaml.safe_load(pathlib.Path(path or POLICY_FILE).read_text(encoding="utf-8")) or {}
    except (OSError, ValueError):
        return ReviewPolicy(group_enabled=False, carry_enabled=False)   # no file: nothing is skipped by policy
    g, c, s = raw.get("group_accept") or {}, raw.get("carry_over") or {}, raw.get("suggestions") or {}
    return ReviewPolicy(
        group_enabled=bool(g.get("enabled", True)), allow_severities=_set(g.get("allow_severities", ["info"])),
        allow_caveats=_set(g.get("allow_caveats")), individual_caveats=_set(g.get("individual_caveats")),
        individual_origins=_set(g.get("individual_origins", ["ai", "manual", "unresolved"])),
        carry_enabled=bool(c.get("enabled", True)), carry_origins=_set(c.get("origins", ["mapped", "transpiled"])),
        suggest_enabled=bool(s.get("enabled", True)), suggest_max=int(s.get("max", 3)))


@functools.lru_cache(maxsize=1)
def policy() -> ReviewPolicy:
    return load_policy()


def caveat_info(caveat_id: str) -> tuple[str, str]:
    """``(family, severity)`` from the catalogue; an unknown id is ``("UNKNOWN", "escalate")``: never group-accepted."""
    from packs.snowflake.caveats import load_catalogue

    c = load_catalogue().by_id().get(caveat_id)
    return (c.family, c.severity) if c else ("UNKNOWN", "escalate")


def caveat_allowed(caveat_id: str, pol: ReviewPolicy) -> tuple[bool, str]:
    _, sev = caveat_info(caveat_id)
    if sev in ALWAYS_INDIVIDUAL_SEVERITIES:
        return False, f"{caveat_id} is {sev} severity: always individual"
    if caveat_id in pol.individual_caveats:
        return False, f"{caveat_id} needs individual review (policy)"
    if caveat_id in pol.allow_caveats or sev in pol.allow_severities:
        return True, ""
    return False, f"{caveat_id} is not on the group-accept list"


@dataclass
class GateItems:
    """What one open gate asks a person to look at, reduced to what the policy reads."""

    gate_id: str
    run_id: str = ""
    dataflow_id: str = ""
    name: str = ""
    agent: str = ""
    caveats: list[str] = field(default_factory=list)
    origins: list[str] = field(default_factory=list)
    individual_reason: str = ""        # non-empty: this gate cannot be group-accepted, and why


def gate_items(gate: dict) -> GateItems:
    """Reduce a gate (as a dict) to ``GateItems``. A gate is group-acceptable only if EVERY item in it is."""
    art = gate.get("artifact") or {}
    out = GateItems(str(gate.get("gate_id")), str(gate.get("run_id") or ""), str(gate.get("dataflow_id") or ""),
                    str(gate.get("dataflow_name") or gate.get("dataflow_id") or ""), str(gate.get("agent") or ""))
    from packs.snowflake.caveats import load_catalogue

    cat = load_catalogue()
    known = cat.ids_with("review") | cat.ids_with("escalate") | cat.ids_with("info") | cat.ids_with("block")
    caveats: set[str] = set()
    reasons: list[str] = []
    if art.get("kind") == "translation" or art.get("units"):
        for u in art.get("units") or []:
            caveats |= set(u.get("review_caveats") or [])
            out.origins.append(str(u.get("origin") or "unresolved"))
            if u.get("no_code") or str(u.get("status") or "resolved") != "resolved":
                reasons.append("a unit has no code")
        if gate.get("no_code_unit_ids"):
            reasons.append("a unit has no code")
    else:
        for a in art.get("artifacts") or []:
            caveats |= {c for c in (a.get("caveats") or []) if c in known}
            out.origins.append(str(a.get("origin") or "mapped"))
            if a.get("review_reasons"):
                reasons.append("an artifact carries review reasons")
    out.caveats = sorted(caveats)
    out.individual_reason = "; ".join(sorted(set(reasons)))
    return out


def eligibility(item: GateItems, pol: ReviewPolicy | None = None) -> tuple[bool, str]:
    pol = pol or policy()
    if not pol.group_enabled:
        return False, "group accept is switched off by the review policy"
    if item.individual_reason:
        return False, item.individual_reason
    if not item.caveats:
        return False, "no caveat to group by: review it individually"
    bad = sorted({o for o in item.origins if o in pol.individual_origins})
    if bad:
        return False, f"origin {', '.join(bad)} always needs individual review"
    for c in item.caveats:
        ok, why = caveat_allowed(c, pol)
        if not ok:
            return False, why
    return True, ""


def primary_caveat(caveats: list[str]) -> str:
    return sorted(caveats, key=lambda c: (-SEVERITY_RANK.get(caveat_info(c)[1], 3), c))[0] if caveats else ""


def build_groups(gates: list[dict], pol: ReviewPolicy | None = None) -> list[dict]:
    """Open gates grouped by caveat family. ``acceptable`` gates can be taken in one click, ``individual`` cannot."""
    pol = pol or policy()
    groups: dict[str, dict] = {}
    for g in gates:
        item = gate_items(g)
        prim = primary_caveat(item.caveats)
        fam, sev = caveat_info(prim) if prim else ("NONE", "review")
        grp = groups.setdefault(fam, {"family": fam, "risk": "info", "caveats": set(), "acceptable": [],
                                      "individual": []})
        grp["caveats"] |= set(item.caveats)
        if SEVERITY_RANK.get(sev, 3) > SEVERITY_RANK[grp["risk"]]:
            grp["risk"] = sev
        ok, why = eligibility(item, pol)
        row = {"gate_id": item.gate_id, "run_id": item.run_id, "dataflow_id": item.dataflow_id, "name": item.name,
               "agent": item.agent, "caveats": item.caveats}
        (grp["acceptable"] if ok else grp["individual"]).append(row if ok else {**row, "why": why})
    from packs.snowflake.caveats import load_catalogue

    fams = load_catalogue().families
    return sorted(({**v, "caveats": sorted(v["caveats"]), "title": fams.get(k, "No caveat / other")}
                   for k, v in groups.items()), key=lambda x: (-SEVERITY_RANK[x["risk"]], x["family"]))


__all__ = ["GateItems", "ReviewPolicy", "build_groups", "caveat_allowed", "eligibility", "gate_items", "load_policy",
           "policy"]
