"""core.common.materialize - alias of ``core.domo.materialize`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import materialize as _module

sys.modules[__name__] = _module
