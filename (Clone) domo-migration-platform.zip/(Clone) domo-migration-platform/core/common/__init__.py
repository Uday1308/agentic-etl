"""core.common - the generic machinery, named for what it is (ADR 032 section 1).

``checkpoint``, ``concurrency``, ``llm``, ``observability``, ``naming``, ``sinks``, ``state``
and ``materialize`` are not DOMO-specific. New code imports them from here. Until the
folder rename (P3-17) moves the files, each ``core.common.<m>`` IS ``core.domo.<m>``
(the same module object, so module state such as the active naming policy is shared).
"""
