"""core.common.naming - alias of ``core.domo.naming`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import naming as _module

sys.modules[__name__] = _module
