"""core.common.concurrency - alias of ``core.domo.concurrency`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import concurrency as _module

sys.modules[__name__] = _module
