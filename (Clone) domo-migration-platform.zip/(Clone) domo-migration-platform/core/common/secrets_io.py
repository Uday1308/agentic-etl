"""Source credentials for a batch (ADR 032 section 7, ADR 029 section 6 C9): delivered on stdin, never on the command
line or in the environment; key material goes to owner-only files; PEM text is redacted line by line from logs.

Stdin protocol (`run_batch.py --credentials-stdin`): ONE JSON object `{"<name>": "<value>", ...}`. A value that is a
PEM block is written to a private key file and replaced by its path.
"""

from __future__ import annotations

import json
import logging
import os
import pathlib
import re
import subprocess
import sys
import tempfile
from typing import IO, Any

REDACTED = "[redacted key]"
_BEGIN = re.compile(r"-----BEGIN [A-Z0-9 ]*(PRIVATE KEY|CERTIFICATE|PUBLIC KEY)-----")
_END = re.compile(r"-----END [A-Z0-9 ]*-----")


def redact_pem_lines(text: str) -> str:
    """Replace every PEM block (BEGIN line .. END line, or to the end of the text when it is cut off) by one marker
    line, keeping the other lines. Line-aware: a block split across read chunks is handled by `PemRedactor`."""
    out: list[str] = []
    inside = False
    for line in text.splitlines():
        if inside:
            if _END.search(line):
                inside = False
            continue
        m = _BEGIN.search(line)
        if m:
            out.append(line[:m.start()] + REDACTED)
            inside = not _END.search(line[m.end():])
            continue
        out.append(line)
    return "\n".join(out)


class PemRedactor:
    """Stateful line filter for streamed output (the state survives between calls)."""

    def __init__(self) -> None:
        self.inside = False

    def line(self, line: str) -> str | None:
        """The line with PEM removed, or None when the whole line belongs to a block."""
        if self.inside:
            if _END.search(line):
                self.inside = False
            return None
        m = _BEGIN.search(line)
        if m:
            self.inside = not _END.search(line[m.end():])
            return line[:m.start()] + REDACTED
        return line


class RedactingFilter(logging.Filter):
    """Logging filter: the formatted message never carries PEM text."""

    def __init__(self) -> None:
        super().__init__()
        self._r = PemRedactor()

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        if "-----" in msg or self._r.inside:
            record.msg = "\n".join(x for x in (self._r.line(ln) for ln in msg.splitlines()) if x is not None)
            record.args = ()
        return True


def install_log_redaction() -> None:
    f = RedactingFilter()
    root = logging.getLogger()
    root.addFilter(f)
    for h in root.handlers:
        h.addFilter(f)


def restrict_to_owner(path: pathlib.Path) -> None:
    """Owner-only access: chmod 600 on POSIX, an ACL with inheritance removed and only the current user on Windows."""
    if os.name == "nt":
        user = os.environ.get("USERNAME") or ""
        domain = os.environ.get("USERDOMAIN")
        who = rf"{domain}\{user}" if domain and user else user
        subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", f"{who}:(R,W)"],
                       check=True, capture_output=True)
    else:
        os.chmod(path, 0o600)


def write_private_file(directory: pathlib.Path, name: str, content: str) -> pathlib.Path:
    """Create `directory/name` that is never readable by others, not even briefly (created 0600 on POSIX)."""
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / re.sub(r"[^A-Za-z0-9._-]", "_", name)
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)
    restrict_to_owner(path)
    return path


def read_credentials(stream: IO[str] | None = None, *, key_dir: pathlib.Path | None = None) -> dict[str, str]:
    """Read the stdin JSON; PEM values become owner-only key files (their paths replace the values)."""
    raw = (stream or sys.stdin).read()
    data: Any = json.loads(raw) if raw.strip() else {}
    if not isinstance(data, dict):
        raise ValueError("credentials on stdin must be a JSON object")
    kdir = key_dir or pathlib.Path(tempfile.mkdtemp(prefix="srcintel-keys-"))
    out: dict[str, str] = {}
    for k, v in data.items():
        s = str(v)
        out[str(k)] = str(write_private_file(kdir, f"{k}.pem", s if s.endswith("\n") else s + "\n")) \
            if _BEGIN.search(s) else s
    return out
