"""core.common.observability - alias of ``core.domo.observability`` until the rename (ADR 032 section 1)."""
import sys

from core.domo import observability as _module

sys.modules[__name__] = _module
