"""core.common.checkpoint - alias of ``core.domo.checkpoint`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import checkpoint as _module

sys.modules[__name__] = _module
