"""core.common.sinks - alias of ``core.domo.sinks`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import sinks as _module

sys.modules[__name__] = _module
