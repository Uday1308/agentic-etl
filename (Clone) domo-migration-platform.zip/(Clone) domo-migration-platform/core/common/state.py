"""core.common.state - alias of ``core.domo.state`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import state as _module

sys.modules[__name__] = _module
