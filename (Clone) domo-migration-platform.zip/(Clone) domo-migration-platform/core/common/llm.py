"""core.common.llm - alias of ``core.domo.llm`` until the rename moves the file (ADR 032 section 1)."""
import sys

from core.domo import llm as _module

sys.modules[__name__] = _module
