"""core.contracts.telemetry — every row the platform writes about its own behaviour.

Observability here is not logging. It is the evidence trail that answers, for any run
and for the estate as a whole:

    what did it cost          -> LlmCallRow (tokens, per call, per agent, per role)
    what did it do            -> StepRow (every agent phase, with timing)
    what did it read          -> IngestionRow (which DOMO datasets, at which batch,
                                 for creation vs for validation)
    was it any good           -> JudgeRow (deterministic rules) and
                                 ValidationRow (parity against DOMO)
    who decided what          -> DecisionRow (every human override, for the client
                                 deviation report)

These are Delta table schemas expressed as models. Field names are the column names.
Adding a field is additive; renaming one is a migration, so names are chosen to age.

Every row carries ``run_id`` so the whole picture joins on one key, and ``ts`` in ISO
8601 UTC so ordering survives serialization.
"""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class _Row(BaseModel):
    """Common shape. Frozen: telemetry is written once and never edited."""
    model_config = ConfigDict(frozen=True)

    run_id: str
    ts: str                                  # ISO 8601 UTC
    environment: str = "dev"


# --------------------------------------------------------------------------- #
# cost + model usage
# --------------------------------------------------------------------------- #

class LlmCallRow(_Row):
    """One model call. The unit of cost.

    ``prompt_hash`` lets identical prompts be spotted across runs (a cheap cache-hit
    signal and a way to detect prompt drift). ``cost_usd`` is computed at write time
    from a rate card rather than derived later, so historical rows stay accurate when
    prices change.
    """
    call_id: str
    agent: str
    node: str = ""                           # graph node within the agent
    iteration: int = 1
    role: str                                # generator | evaluator
    model: str
    pool: str = "default"
    tokens_in: int = 0
    tokens_out: int = 0
    tokens_cached: int = 0
    cost_usd: float = 0.0
    latency_ms: int = 0
    status: str = "ok"                       # ok | retry | error | timeout
    error: str = ""
    prompt_hash: str = ""
    attempt: int = 1

    @property
    def tokens_total(self) -> int:
        return self.tokens_in + self.tokens_out


# --------------------------------------------------------------------------- #
# what the agents did
# --------------------------------------------------------------------------- #

class StepStatus(str, Enum):
    STARTED = "started"
    OK = "ok"
    FAILED = "failed"
    SKIPPED = "skipped"
    INTERRUPTED = "interrupted"              # parked for human review


class StepRow(_Row):
    """One agent phase. This is what the UI streams as "Context engineering…".

    Phases are declared by the agent, not invented by the UI, so the frontend never
    has to guess what an agent is doing — it renders ``phase`` directly.
    """
    step_id: str
    agent: str
    phase: str                               # 'Context engineering', 'Evaluating', ...
    phase_index: int = 0
    phase_count: int = 0
    iteration: int = 1
    status: StepStatus = StepStatus.STARTED
    duration_ms: int = 0
    detail: str = ""

    @property
    def progress(self) -> float:
        return (self.phase_index + 1) / self.phase_count if self.phase_count else 0.0


# --------------------------------------------------------------------------- #
# what we pulled from DOMO
# --------------------------------------------------------------------------- #

class IngestPurpose(str, Enum):
    """Why a DOMO dataset was pulled. Drives retention and the client report:
    creation inputs become real tables, validation references are evidence only."""
    CREATION = "creation"                    # an input the migrated flow reads
    VALIDATION = "validation"                # DOMO's own output, the parity reference
    METADATA = "metadata"                    # schema/history via the DOMO API


class IngestionRow(_Row):
    """One DOMO dataset pulled into Databricks, and the batch state it was pulled at.

    ``batch_id``/``batch_last_run`` are what make a parity result meaningful later —
    a comparison without them cannot be reproduced or defended.
    """
    dataset_id: str
    dataset_name: str = ""
    purpose: IngestPurpose
    target_table: str = ""                   # where it landed
    rows_ingested: int = 0
    domo_row_count: int | None = None        # DOMO's own count, independent reference
    batch_id: int | None = None
    batch_last_run: str | None = None
    bytes_ingested: int = 0
    duration_ms: int = 0
    status: str = "ok"
    error: str = ""
    used_domo_api: bool = False              # was the API flag on for this pull

    @property
    def count_matches(self) -> bool | None:
        if self.domo_row_count is None:
            return None
        return self.rows_ingested == self.domo_row_count


# --------------------------------------------------------------------------- #
# quality: judges and parity
# --------------------------------------------------------------------------- #

class JudgeRow(_Row):
    """One judge result. Tracked separately from evaluator output on purpose.

    Trending ``verdict`` per ``rule_id`` across releases is the regression signal:
    a rule that starts failing after a prompt change is a fact, not an opinion.
    """
    agent: str
    iteration: int = 1
    rule_id: str
    title: str = ""
    kind: str = ""
    verdict: str                             # pass | warn | fail
    findings: int = 0
    checked: int = 0
    nodes: tuple[str, ...] = ()
    note: str = ""


class ValidationRow(_Row):
    """One parity comparison against DOMO, at target grain.

    Mirrors core.contracts.validation.TargetParity, flattened for the table.
    """
    dataflow_id: str
    target: str
    table: str = ""
    checks_run: int = 0
    checks_passed: int = 0
    blocking_failures: int = 0
    advisory_failures: int = 0
    exact: bool = False
    passed: bool = False
    #: The two numbers every parity conversation actually starts from. Optional
    #: because a check can fail before either side is countable, but a verdict that
    #: omits them cannot be read by a human - the diagnosis text quotes them, so
    #: leaving them off the row meant the UI had to parse prose to get them back.
    source_rows: int | None = None
    migrated_rows: int | None = None
    expected_batch_id: int | None = None
    expected_batch_last_run: str | None = None
    failure_category: str = ""               # from validation.FailureCategory
    owner_agent: str = ""
    diagnosis: str = ""

    @property
    def check_pass_rate(self) -> float:
        return self.checks_passed / self.checks_run if self.checks_run else 0.0

    @property
    def row_delta(self) -> int | None:
        """Migrated minus DOMO, or None when either side was not counted."""
        if self.source_rows is None or self.migrated_rows is None:
            return None
        return self.migrated_rows - self.source_rows


# --------------------------------------------------------------------------- #
# what humans decided
# --------------------------------------------------------------------------- #

class DecisionKind(str, Enum):
    APPROVED = "approved"                    # accepted the agent output as-is
    REGENERATED = "regenerated"              # sent feedback, agent re-ran
    ISSUE_ACCEPTED = "issue_accepted"        # this specific issue will be fixed
    ISSUE_REJECTED = "issue_rejected"        # this specific issue is not a problem
    OVERRIDE = "override"                    # human edited the artifact directly
    CONSTRAINT_ADDED = "constraint_added"    # hard constraint pinned for future passes


class DecisionRow(_Row):
    """Every human intervention. This is the client deviation report.

    Reconstructing these eight months later is impossible, so they are recorded at the
    moment of the decision with the rationale attached.
    """
    dataflow_id: str = ""
    agent: str
    iteration: int = 1
    kind: DecisionKind
    actor: str                               # who decided
    issue_id: str = ""
    node: str = ""
    rationale: str = ""                      # the human's own words
    constraint: str = ""                     # for CONSTRAINT_ADDED


# --------------------------------------------------------------------------- #
# rollups
# --------------------------------------------------------------------------- #

class RunSummary(BaseModel):
    """Everything about one run, in the shape the UI and the report both want.

    Computed from the rows above rather than maintained alongside them — one source
    of truth, no drift between the dashboard and the deliverable.
    """
    model_config = ConfigDict(frozen=True)

    run_id: str
    dataflow_id: str
    dataflow_name: str = ""
    status: str = "running"
    started_ts: str = ""
    ended_ts: str = ""

    # cost
    llm_calls: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0

    # work
    steps_run: int = 0
    agents_completed: int = 0
    iterations_total: int = 0                # sum across agents; >7 means rework

    # ingestion
    datasets_creation: int = 0
    datasets_validation: int = 0
    rows_ingested: int = 0

    # quality
    judges_run: int = 0
    judges_failed: int = 0
    judge_pass_rate: float = 0.0
    targets_total: int = 0
    targets_exact: int = 0
    validation_pass_rate: float = 0.0

    # human
    decisions: int = 0
    issues_accepted: int = 0
    issues_rejected: int = 0

    # pack runs (Snowflake): built from run.json, not telemetry
    source: str = ""                         # "pack" when built from run.json
    units_total: int = 0
    units_by_status: dict[str, int] = Field(default_factory=dict)
    reason: str = ""

    @property
    def tokens_total(self) -> int:
        return self.tokens_in + self.tokens_out

    @property
    def cost_per_target(self) -> float:
        return self.cost_usd / self.targets_total if self.targets_total else 0.0

    @property
    def reworked(self) -> bool:
        """More iterations than agents means at least one agent went round again."""
        return self.iterations_total > self.agents_completed


def summarize(
    run_id: str,
    dataflow_id: str,
    *,
    llm: list[LlmCallRow] = (),
    steps: list[StepRow] = (),
    ingest: list[IngestionRow] = (),
    judged: list[JudgeRow] = (),
    validated: list[ValidationRow] = (),
    decisions: list[DecisionRow] = (),
    **extra: Any,
) -> RunSummary:
    """Fold raw telemetry into a RunSummary. Pure — no I/O, trivially testable."""
    judged = list(judged)
    validated = list(validated)
    decisions = list(decisions)
    steps = list(steps)
    llm = list(llm)
    ingest = list(ingest)

    ok_judges = sum(1 for j in judged if j.verdict == "pass")
    return RunSummary(
        run_id=run_id,
        dataflow_id=dataflow_id,
        llm_calls=len(llm),
        tokens_in=sum(c.tokens_in for c in llm),
        tokens_out=sum(c.tokens_out for c in llm),
        cost_usd=round(sum(c.cost_usd for c in llm), 4),
        steps_run=len(steps),
        agents_completed=len({s.agent for s in steps if s.status is StepStatus.OK}),
        iterations_total=len({(s.agent, s.iteration) for s in steps}),
        datasets_creation=sum(1 for i in ingest if i.purpose is IngestPurpose.CREATION),
        datasets_validation=sum(1 for i in ingest if i.purpose is IngestPurpose.VALIDATION),
        rows_ingested=sum(i.rows_ingested for i in ingest),
        judges_run=len(judged),
        judges_failed=sum(1 for j in judged if j.verdict == "fail"),
        judge_pass_rate=round(ok_judges / len(judged), 4) if judged else 0.0,
        targets_total=len(validated),
        targets_exact=sum(1 for v in validated if v.exact),
        validation_pass_rate=round(sum(1 for v in validated if v.passed) / len(validated), 4)
            if validated else 0.0,
        decisions=len(decisions),
        issues_accepted=sum(1 for d in decisions if d.kind is DecisionKind.ISSUE_ACCEPTED),
        issues_rejected=sum(1 for d in decisions if d.kind is DecisionKind.ISSUE_REJECTED),
        **extra,
    )
