"""core.contracts.discovery — the discovery table schema, defined once.

Every producer and consumer of discovery data goes through this module:

    Discovery agent  writes rows shaped by ``COLUMNS``
    SparkDiscoveryReader  reads them back
    scripts/local_dryrun.py  reads a CSV/JSON export of them
    core.domo.tiles  reads the ``properties`` payload

Before this existed the column aliasing was duplicated in three places, which is
exactly the kind of thing that drifts silently: a reader learns a new alias, the
others do not, and a dataflow half-parses. One definition, one normalizer.

Two layers are distinguished on purpose:

* the **row schema** (this file) — the table's columns, stable across ETL tools;
* the **properties payload** — tool-specific and free-form, normalized per tile type
  by ``core.domo.tiles``. Discovery does not interpret it.
"""
from __future__ import annotations

import json
from enum import Enum
from typing import Any, Iterable

from pydantic import BaseModel, ConfigDict, Field


class RecordType(str, Enum):
    """A discovery table holds nodes and edges in one table, discriminated here."""
    NODE = "NODE"
    LINEAGE = "LINEAGE"


class NodeCategory(str, Enum):
    SOURCE = "SOURCE"
    TRANSFORMATION = "TRANSFORMATION"
    TARGET = "TARGET"
    UNKNOWN = "UNKNOWN"


#: Canonical column -> accepted aliases, lower-cased at match time.
#: The canonical name is what the Discovery agent writes; the aliases are what older
#: exports, other ETL tools, and hand-made extracts have been seen to use.
COLUMNS: dict[str, tuple[str, ...]] = {
    # identity / scope
    "discovery_run_id": ("discovery_run_id", "run_id"),
    "config_id":        ("config_id",),
    "application_name": ("application_name", "application", "app"),
    "etl_tool":         ("etl_tool", "tool"),
    "dataflow_id":      ("dataflow_id", "flow_id", "dataflowid"),
    "dataflow_name":    ("dataflow_name", "flow_name"),
    "etl_master_id":    ("etl_master_id", "master_id"),
    "record_type":      ("record_type", "recordtype", "row_type"),
    # node columns
    "node_id":          ("node_id", "id", "nodeid", "node"),
    "node_name":        ("node_name", "name", "label", "display_name"),
    "node_category":    ("node_category", "category"),
    "node_type":        ("node_type", "tile_type"),
    "operation_type":   ("operation_type", "op_type", "type", "operation"),
    "properties":       ("properties", "config_json", "config", "params", "logic"),
    "input_node_ids":   ("input_node_ids", "inputs", "upstream", "parents"),
    "is_disabled":      ("is_disabled", "disabled"),
    "raw_node_json":    ("raw_node_json", "raw_json", "raw"),
    # lineage columns
    "from_node_id":     ("from_node_id", "source_node_id", "from"),
    "from_node_name":   ("from_node_name",),
    "from_node_type":   ("from_node_type",),
    "from_node_disabled": ("from_node_disabled",),
    "to_node_id":       ("to_node_id", "target_node_id", "to"),
    "to_node_name":     ("to_node_name",),
    "to_node_type":     ("to_node_type",),
    "to_node_disabled": ("to_node_disabled",),
    "relationship_type": ("relationship_type", "edge_type"),
    "sequence_order":   ("sequence_order", "seq", "order"),
    # provenance
    "discovered_at":    ("discovered_at", "created_at", "ts"),
    "is_normalized_flag": ("is_normalized_flag", "is_normalized"),
    "normalization_issues": ("normalization_issues", "issues"),
}

#: Without these a row cannot be turned into a node.
REQUIRED_NODE_COLUMNS = ("node_id", "operation_type")

#: Canonical operation types, and the spellings each has been seen under. Used to
#: classify a node without interpreting its properties.
SOURCE_OPS = frozenset({"SOURCE", "DATASET", "DATA", "INPUT", "DATASOURCE"})
TARGET_OPS = frozenset({"SINK", "TARGET", "OUTPUT", "WRITE", "PUBLISH"})


class DiscoveryRow(BaseModel):
    """One row, after normalization. Extra columns are preserved, not dropped —
    a future column should never be lost just because this file is older."""
    model_config = ConfigDict(frozen=True, extra="allow")

    record_type: str = RecordType.NODE.value
    dataflow_id: str = ""
    node_id: str = ""
    node_name: str = ""
    node_category: str = ""
    operation_type: str = ""
    properties: dict[str, Any] = Field(default_factory=dict)
    input_node_ids: list[str] = Field(default_factory=list)
    from_node_id: str = ""
    to_node_id: str = ""
    discovery_run_id: str = ""
    discovered_at: str = ""
    is_disabled: bool = False

    @property
    def is_node(self) -> bool:
        return "NODE" in (self.record_type or "").upper()

    @property
    def category(self) -> NodeCategory:
        """Category as stated, else derived from the operation type."""
        stated = (self.node_category or "").upper()
        if stated in NodeCategory.__members__:
            cat = NodeCategory[stated]
            if cat is not NodeCategory.UNKNOWN:
                return cat
        op = (self.operation_type or "").upper()
        if op in SOURCE_OPS:
            return NodeCategory.SOURCE
        if op in TARGET_OPS:
            return NodeCategory.TARGET
        return NodeCategory.TRANSFORMATION


class DiscoverySchemaError(ValueError):
    """Raised when an export cannot be read as discovery rows."""


# --------------------------------------------------------------------------- #
# value coercion
# --------------------------------------------------------------------------- #

import re  # noqa: E402  (kept local to the coercion helpers)

#: Spark renders array columns several ways depending on how the export was produced.
_ARRAYISH = re.compile(r"^\s*(?:WrappedArray|ArraySeq|List|array)\s*\((.*)\)\s*$",
                       re.IGNORECASE | re.DOTALL)
_NULLISH = {"", "null", "NULL", "None", "nan", "N/A"}


def as_object(value: Any, empty: Any) -> Any:
    """Coerce a cell into a dict/list. CSV exports give string forms of everything."""
    if value is None:
        return empty
    if not isinstance(value, str):
        return value
    text = value.strip()
    if text in _NULLISH or text in ("[]", "{}"):
        return empty
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = _ARRAYISH.match(text)
    if m:
        inner = m.group(1).strip()
        if not inner:
            return [] if isinstance(empty, list) else empty
        return [p.strip().strip("'\"") for p in inner.split(",") if p.strip()]
    if text[0] in "[{":
        try:
            import ast
            return ast.literal_eval(text)
        except (ValueError, SyntaxError):
            return empty
    if isinstance(empty, list):
        return [p.strip().strip("'\"") for p in text.split(",") if p.strip()] or [text]
    return empty


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in ("true", "1", "yes", "y")


def as_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text in _NULLISH else text


# --------------------------------------------------------------------------- #
# normalization — the one entry point
# --------------------------------------------------------------------------- #

def resolve_columns(available: Iterable[str], overrides: dict[str, str] | None = None
                    ) -> dict[str, str | None]:
    """Map canonical names to the actual columns present. Raises if a required one
    is missing, naming what WAS present so the fix is obvious."""
    available = list(available)
    lower = {c.lower().strip(): c for c in available}
    overrides = overrides or {}
    out: dict[str, str | None] = {}
    for canonical, aliases in COLUMNS.items():
        if canonical in overrides:
            col = overrides[canonical]
            if col not in available:
                raise DiscoverySchemaError(
                    f"column {col!r} given for {canonical!r} is not in the export: {available}")
            out[canonical] = col
            continue
        out[canonical] = next((lower[a] for a in aliases if a in lower), None)
    missing = [c for c in REQUIRED_NODE_COLUMNS if out.get(c) is None]
    if missing:
        raise DiscoverySchemaError(
            f"discovery export is missing required column(s) {missing}. "
            f"Columns present: {available}. "
            f"Pass overrides, e.g. columns={{'{missing[0]}': '<your column>'}}.")
    return out


def normalize_rows(rows: Iterable[dict], *, dataflow_id: str = "",
                   overrides: dict[str, str] | None = None,
                   run_id: str = "") -> list[DiscoveryRow]:
    """Turn raw export rows into ``DiscoveryRow``s.

    Scopes to one dataflow and one discovery run, because an export accumulates both
    and reading them together repeats node ids — which surfaces downstream as a bogus
    graph cycle rather than as the ingestion problem it actually is.
    """
    rows = [r for r in rows if r]
    if not rows:
        raise DiscoverySchemaError("export contained no rows")
    colmap = resolve_columns(rows[0].keys(), overrides)

    def get(row: dict, canonical: str):
        col = colmap.get(canonical)
        return row.get(col) if col else None

    if dataflow_id and colmap.get("dataflow_id"):
        scoped = [r for r in rows if as_text(get(r, "dataflow_id")) == str(dataflow_id)]
        if scoped:
            rows = scoped

    if colmap.get("discovery_run_id"):
        runs: dict[str, list[dict]] = {}
        for r in rows:
            runs.setdefault(as_text(get(r, "discovery_run_id")), []).append(r)
        if len(runs) > 1:
            if run_id:
                if run_id not in runs:
                    raise DiscoverySchemaError(
                        f"discovery run {run_id!r} not in the export. Available: "
                        f"{', '.join(sorted(runs))}")
                rows = runs[run_id]
            elif colmap.get("discovered_at"):
                newest = max(runs, key=lambda k: max(
                    as_text(get(r, "discovered_at")) for r in runs[k]))
                rows = runs[newest]
            else:
                rows = runs[list(runs)[-1]]

    out: list[DiscoveryRow] = []
    for r in rows:
        out.append(DiscoveryRow(
            record_type=as_text(get(r, "record_type")) or RecordType.NODE.value,
            dataflow_id=as_text(get(r, "dataflow_id")) or str(dataflow_id),
            node_id=as_text(get(r, "node_id")),
            node_name=as_text(get(r, "node_name")),
            node_category=as_text(get(r, "node_category")),
            operation_type=as_text(get(r, "operation_type")) or as_text(get(r, "node_type")),
            properties=as_object(get(r, "properties"), {}) or {},
            input_node_ids=[str(x) for x in (as_object(get(r, "input_node_ids"), []) or [])],
            from_node_id=as_text(get(r, "from_node_id")),
            to_node_id=as_text(get(r, "to_node_id")),
            discovery_run_id=as_text(get(r, "discovery_run_id")),
            discovered_at=as_text(get(r, "discovered_at")),
            is_disabled=as_bool(get(r, "is_disabled")),
        ))
    return out


def to_dataflow(rows: Iterable[DiscoveryRow], dataflow_id: str = "") -> dict:
    """Fold normalized rows into the standardized dataflow shape the planner reads.

    Disabled nodes are dropped — DOMO keeps them in the export but does not run them,
    and migrating a disabled tile would change behaviour.
    """
    rows = list(rows)
    nodes: list[dict] = []
    edges: list[dict] = []
    seen: set[str] = set()

    for r in rows:
        if not r.is_node or not r.node_id or r.is_disabled:
            continue
        if r.node_id in seen:
            continue                      # same node repeated across runs
        seen.add(r.node_id)
        nodes.append({
            "id": r.node_id,
            "name": r.node_name or r.node_id,
            "type": r.operation_type,
            "category": r.category.value,
            "properties": r.properties,
        })
        for src in r.input_node_ids:
            if src:
                edges.append({"from": str(src), "to": r.node_id})

    # LINEAGE rows fill the gap when inputs are not stated inline
    known = {(e["from"], e["to"]) for e in edges}
    for r in rows:
        if r.is_node:
            continue
        a, b = r.from_node_id, r.to_node_id
        if a and b and (a, b) not in known and a in seen and b in seen:
            edges.append({"from": a, "to": b})
            known.add((a, b))

    # an edge to a dropped (disabled) node would dangle
    edges = [e for e in edges if e["from"] in seen and e["to"] in seen]
    return {"dataflow_id": dataflow_id or (rows[0].dataflow_id if rows else ""),
            "nodes": nodes, "edges": edges}
