"""core.contracts.domo_raw — the DOMO API's own export, folded into our shape.

This is the tool-adapter seam the Standardization agent owns, written down
deterministically. DOMO's ``/dataflows/<id>`` payload and the standardized
document are different in three ways, and all three are load-bearing:

    topology    raw puts it in ``dependsOn`` on each action; there is NO
                ``connections`` list. Miss this and every downstream stage sees a
                dataflow with 71 tiles and no edges.
    tile names  raw uses DOMO's internal names (``LoadFromVault``,
                ``ExpressionEvaluator``, ``Metadata``). The tile registry keys on
                ``source``, ``formula``, ``alter_columns``.
    payloads    raw ``GroupBy.groups[].name`` is standardized
                ``groupByColumns``; raw ``MergeJoin.keys1``/``keys2`` become
                paired ``joinKeys``; and so on, per tile type.

Getting any of them wrong does not raise — it produces a run that looks complete
and is empty, every tile escalated, no targets. That is precisely the failure this
platform exists to prevent, so ``to_standardized`` refuses a payload it does not
recognise rather than passing through what it can.

The mapping was derived by diffing DOMO's raw export of dataflow 8099 against the
standardized document for the same flow, action by action. Where a raw field has
no standardized counterpart it is dropped deliberately, not forgotten: ``gui``
(canvas coordinates), ``settings``, ``tables`` and the load tuning flags describe
how DOMO draws and schedules a tile, not what it computes.
"""
from __future__ import annotations

from typing import Any

#: DOMO's internal action type -> the standardized vocabulary the tile registry
#: keys on. A type absent from here is reported, never guessed: an unmapped tile
#: silently becoming a passthrough is how wrong numbers reach an output table.
TYPE_MAP = {
    "LoadFromVault": "source",
    "PublishToVault": "sink",
    "Filter": "filter",
    "SelectValues": "select",
    "MergeJoin": "join",
    "ExpressionEvaluator": "formula",
    "Metadata": "alter_columns",
    "GroupBy": "aggregate",
    "UnionAll": "union",
    "NormalizeAll": "NormalizeAll",
    "Unique": "dedupe",
    "WindowAction": "rank",
    "TextFormatting": "text",
    "StringCalculator": "stringcalculator",
}

#: Raw keys that describe how DOMO draws or runs a tile rather than what it
#: computes. Dropped on purpose.
_PRESENTATION = {"gui", "settings", "tables", "previewRowLimit", "propagateAi",
                 "filterPolicy", "sourceType", "executeFlowWhenUpdated",
                 "pseudoDataSource", "truncateTextColumns", "truncateRows",
                 "onlyLoadNewVersions", "recentVersionCutoffMs", "schemaSource"}


class RawExportError(RuntimeError):
    """The payload is not a DOMO dataflow export, or uses a tile we cannot map."""


def is_raw_export(doc: Any) -> bool:
    """True for DOMO's own payload rather than a standardized document.

    Checked from both directions — what only raw has, and what only standardized
    has — because guessing wrong either way yields a silently empty run.
    """
    flow = _unwrap(doc)
    if not isinstance(flow, dict):
        return False
    raw_only = {"dapDataFlowId", "engineProperties", "executionCount"}
    return bool(raw_only & set(flow)) and "connections" not in flow


def _unwrap(doc: Any) -> dict:
    if isinstance(doc, dict) and len(doc) == 1:
        only = next(iter(doc.values()))
        if isinstance(only, dict) and ("actions" in only or "dapDataFlowId" in only):
            return only
    return doc if isinstance(doc, dict) else {}


def to_standardized(doc: Any, dataflow_id: str = "") -> dict:
    """Fold a raw DOMO export into the id-keyed standardized document.

    Returns ``{"<id>": {...}}`` — the shape ``core.contracts.standardized`` reads,
    so everything downstream is unchanged.
    """
    flow = _unwrap(doc)
    actions = list(flow.get("actions") or [])
    if not actions:
        raise RawExportError(
            "raw export has no actions; this is not a DOMO dataflow payload")

    df_id = str(dataflow_id or flow.get("id") or flow.get("dapDataFlowId") or "")
    unknown = sorted({a.get("type") for a in actions
                      if a.get("type") not in TYPE_MAP})
    if unknown:
        raise RawExportError(
            f"dataflow {df_id}: no mapping for DOMO tile type(s) {unknown}. Add "
            f"them to TYPE_MAP with their payload mapping - passing an unmapped "
            f"tile through would escalate it silently and produce empty SQL.")

    names = _dataset_names(flow)
    out_actions = []
    connections = []
    for a in actions:
        nid = str(a.get("id") or "")
        out_actions.append({
            "id": nid,
            "name": a.get("name") or nid,
            "type": TYPE_MAP[a["type"]],
            "logic": _logic(a, names),
        })
        # Topology. DOMO writes it per action; the standardized form is a list.
        for upstream in a.get("dependsOn") or []:
            connections.append({"from": str(upstream), "to": nid})

    return {df_id: {
        "id": df_id,
        "name": flow.get("name", ""),
        "database_type": flow.get("databaseType", "MAGIC"),
        "deleted": bool(flow.get("deleted", False)),
        "responsible_user_id": flow.get("responsibleUserId"),
        "inputs": list(flow.get("inputs") or []),
        "outputs": list(flow.get("outputs") or []),
        "actions": out_actions,
        "connections": connections,
        "disabled_skipped": [],
    }}


def _dataset_names(flow: dict) -> dict[str, str]:
    """dataSourceId -> dataset name, from the document's own input/output lists."""
    out = {}
    for group in ("inputs", "outputs"):
        for entry in flow.get(group) or []:
            if isinstance(entry, dict) and entry.get("dataSourceId"):
                out[str(entry["dataSourceId"])] = entry.get("dataSourceName", "")
    return out


def _logic(a: dict, names: dict[str, str]) -> dict:
    """The standardized ``logic`` payload for one raw action."""
    kind = a["type"]

    if kind == "LoadFromVault":
        ds = str(a.get("dataSourceId") or "")
        return {"datasetName": names.get(ds) or a.get("name", ""),
                "dataSourceId": ds}

    if kind == "PublishToVault":
        source = a.get("dataSource") or {}
        return {"datasetName": source.get("name") or a.get("name", ""),
                "dataSourceId": source.get("guid", ""),
                "versionChainType": a.get("versionChainType", "REPLACE"),
                "upsertColumns": a.get("upsertColumns"),
                "partitionIdColumns": a.get("partitionIdColumns")}

    if kind == "SelectValues":
        picked = []
        for f in a.get("fields") or []:
            if f.get("remove"):
                continue                    # DOMO marks dropped columns in place
            name = f.get("name", "")
            rename = f.get("rename") or ""
            picked.append({"column": name, "rename": rename or None,
                           "column_normalised": name,
                           "output_name": rename or name,
                           "change_type": "select_rename" if rename else "select"})
        return {"selectedColumns": picked}

    if kind == "MergeJoin":
        left, right = a.get("keys1") or [], a.get("keys2") or []
        # Paired by position: DOMO stores the two sides as parallel lists, and the
        # pairing IS the join condition. Zipping the shorter of the two would drop
        # a key and silently widen the join, so a mismatch is refused.
        if len(left) != len(right):
            raise RawExportError(
                f"join {a.get('id')} has {len(left)} left keys and {len(right)} "
                f"right keys; the pairing is ambiguous")
        return {"joinType": a.get("joinType", "INNER"),
                "relationshipType": a.get("relationshipType", ""),
                "leftInput": str(a.get("step1") or ""),
                "rightInput": str(a.get("step2") or ""),
                "joinKeys": [{"leftColumn": l, "rightColumn": r,
                              "leftColumn_normalised": l,
                              "rightColumn_normalised": r}
                             for l, r in zip(left, right)],
                "columnChanges": list(a.get("schemaModification2") or [])}

    if kind == "ExpressionEvaluator":
        # DOMO names a formula's output `fieldName`; the standardized document and
        # every tile renderer call it `outputColumn`. Passing this through untouched
        # made every formula in a raw-sourced run emit `AS new_column` - it rendered,
        # it looked green, and the SQL was wrong. Map it here, at the boundary that
        # exists precisely to reconcile the two vocabularies.
        return {"expressions": [
            {**e,
             "outputColumn": (e.get("fieldName") or e.get("outputColumn")
                              or e.get("name") or ""),
             "expression": e.get("expression", "")}
            for e in a.get("expressions") or []]}

    if kind == "Filter":
        return _filter_logic(a)

    if kind == "GroupBy":
        groups = [g.get("name", "") for g in a.get("groups") or []]
        aggs = []
        for f in a.get("fields") or []:
            col = f.get("source") or f.get("name", "")
            alias = f.get("name", "")
            aggs.append({"outputColumn": alias, "function": f.get("type", ""),
                         "inputColumn": col,
                         "inputColumn_normalised": col,
                         "outputColumn_normalised": alias})
        return {"groupByColumns": groups, "aggregations": aggs,
                "groupByColumns_normalised": list(groups)}

    if kind == "UnionAll":
        return {"unionType": a.get("unionType", "")}

    # NormalizeAll, ExpressionEvaluator, Metadata, Unique, WindowAction,
    # TextFormatting and StringCalculator already carry field names the tile
    # renderers read (`fields`, `expressions`, `orderRules`, `additions`,
    # `calculations`); everything but the presentation keys passes through.
    return {k: v for k, v in a.items()
            if k not in _PRESENTATION
            and k not in ("id", "name", "type", "dependsOn", "input", "inputs")}


def _filter_logic(a: dict) -> dict:
    """DOMO's flat ``filterList`` as the standardized group structure.

    Each entry carries its own ``andFilterList`` of sub-conditions; DOMO ORs the
    top-level entries and ANDs within one. Flattening that away would change which
    rows survive, so the two levels are preserved.
    """
    groups = []
    for entry in a.get("filterList") or []:
        conditions = [_condition(entry)]
        conditions += [_condition(sub) for sub in entry.get("andFilterList") or []]
        groups.append({"groupCombinator": "AND",
                       "conditions": [c for c in conditions if c]})
    top = "AND" if len(groups) <= 1 else "OR"
    return {"topLevelCombinator": top, "filterGroups": groups}


def _condition(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    column = entry.get("leftField") or ""
    value = entry.get("rightValue") or {}
    return {"column": column,
            "operator": entry.get("operator", ""),
            "value": value.get("value") if isinstance(value, dict) else value,
            "column_normalised": column,
            "rightField": entry.get("rightField"),
            "expression": entry.get("expression")}


__all__ = ["RawExportError", "TYPE_MAP", "is_raw_export", "to_standardized"]
