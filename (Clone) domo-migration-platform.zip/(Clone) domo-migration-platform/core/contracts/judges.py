"""core.contracts.judges — deterministic tests applied to every agent output.

A JUDGE is not an EVALUATOR. The distinction is deliberate and both exist:

    Evaluator   an LLM reviewing an agent's output. Opinion-based, non-deterministic,
                produces Issues for a human to accept or reject, can be wrong, and its
                verdict is advisory input to the HITL gate.

    Judge       a hardcoded rule. Deterministic, cheap, always runs, never asks a
                model anything. A judge failing is a fact about the artifact, not an
                opinion about it.

They are monitored separately because they answer different questions. Evaluator
issue counts tell you how noisy your reviewer is. Judge pass rates tell you whether
the *system* is getting better or worse over time — a judge that starts failing after
a prompt change is a regression signal you can act on, in a way that "the evaluator
raised 4 issues instead of 3" never is.

Judges are the layer that catches the failure classes we know are real:
order-dependent aggregations, batch-metadata dependencies, unresolved slots,
hardcoded literals carried across from DOMO, missing null guards.
"""
from __future__ import annotations

import abc
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class Verdict(str, Enum):
    PASS = "pass"
    WARN = "warn"        # worth a human's attention, does not block
    FAIL = "fail"        # the artifact is wrong; block promotion


class JudgeKind(str, Enum):
    """What a judge inspects. Used for grouping in dashboards, not for dispatch."""
    STRUCTURE = "structure"           # shape of the artifact (sections, ids, coverage)
    SEMANTICS = "semantics"           # meaning-preserving rules (null guards, casts)
    DETERMINISM = "determinism"       # will this produce the same answer twice
    LINEAGE = "lineage"               # references resolve, no dangling nodes
    POLICY = "policy"                 # house rules (naming, no hardcoded literals)


class Finding(BaseModel):
    """One thing a judge noticed. Node-addressed so it lands on a specific cell."""
    model_config = ConfigDict(frozen=True)

    node: str = ""                    # node id / step id, empty for artifact-level
    message: str
    detail: str = ""
    excerpt: str = ""                 # the offending fragment, for the reviewer


class JudgeResult(BaseModel):
    """The outcome of running one judge against one artifact."""
    model_config = ConfigDict(frozen=True)

    rule_id: str                      # stable id, e.g. "DET001" — tracked over time
    title: str
    kind: JudgeKind
    verdict: Verdict
    findings: tuple[Finding, ...] = ()
    checked: int = 0                  # how many units the judge examined
    note: str = ""

    @property
    def failed(self) -> bool:
        return self.verdict is Verdict.FAIL


@runtime_checkable
class Judgeable(Protocol):
    """Anything a judge can inspect. Agents adapt their output to this."""
    artifact: str
    node_ids: list[str]
    meta: dict[str, Any]


class Judge(abc.ABC):
    """Base class for a deterministic rule.

    Subclasses declare a stable ``rule_id`` so pass rates are trackable across
    releases, and implement ``run``. A judge must never call a model, touch the
    network, or depend on wall-clock time — same input, same verdict, forever.
    """
    rule_id: str = ""
    title: str = ""
    kind: JudgeKind = JudgeKind.STRUCTURE
    #: agents this judge applies to; empty means all
    applies_to: tuple[str, ...] = ()

    def relevant(self, agent: str) -> bool:
        return not self.applies_to or agent in self.applies_to

    @abc.abstractmethod
    def run(self, subject: Judgeable) -> JudgeResult: ...

    # -- helpers for subclasses ------------------------------------------- #
    def _result(self, verdict: Verdict, findings: tuple[Finding, ...] = (),
                checked: int = 0, note: str = "") -> JudgeResult:
        return JudgeResult(rule_id=self.rule_id, title=self.title, kind=self.kind,
                           verdict=verdict, findings=findings, checked=checked, note=note)

    def _verdict_from(self, findings: tuple[Finding, ...], *, on_finding: Verdict) -> Verdict:
        return on_finding if findings else Verdict.PASS


class JudgePanel(BaseModel):
    """Every judge result for one agent output, plus the rollup.

    ``blocking`` is what the graph acts on. ``pass_rate`` is what the observability
    dashboard trends — a falling pass rate means the system is degrading even if
    every individual run still ships.
    """
    model_config = ConfigDict(frozen=True)

    agent: str
    iteration: int = 1
    results: tuple[JudgeResult, ...] = ()

    @property
    def failures(self) -> tuple[JudgeResult, ...]:
        return tuple(r for r in self.results if r.verdict is Verdict.FAIL)

    @property
    def warnings(self) -> tuple[JudgeResult, ...]:
        return tuple(r for r in self.results if r.verdict is Verdict.WARN)

    @property
    def blocking(self) -> bool:
        return bool(self.failures)

    @property
    def pass_rate(self) -> float:
        return sum(1 for r in self.results if r.verdict is Verdict.PASS) / len(self.results) \
            if self.results else 0.0

    def summary(self) -> dict:
        return {
            "agent": self.agent,
            "iteration": self.iteration,
            "judges_run": len(self.results),
            "failed": len(self.failures),
            "warned": len(self.warnings),
            "pass_rate": round(self.pass_rate, 4),
            "failed_rules": [r.rule_id for r in self.failures],
        }


class JudgeRegistry:
    """Holds the judges and runs the ones relevant to an agent.

    Registration is explicit rather than auto-discovered so that adding a judge is a
    visible, reviewable act — these are the project's quality invariants.
    """

    def __init__(self, judges: list[Judge] | None = None) -> None:
        self._judges: list[Judge] = []
        for j in judges or []:
            self.register(j)

    def register(self, judge: Judge) -> "JudgeRegistry":
        if not judge.rule_id:
            raise ValueError(f"{type(judge).__name__} must declare a rule_id")
        if any(j.rule_id == judge.rule_id for j in self._judges):
            raise ValueError(f"duplicate judge rule_id: {judge.rule_id}")
        self._judges.append(judge)
        return self

    def for_agent(self, agent: str) -> list[Judge]:
        return [j for j in self._judges if j.relevant(agent)]

    def run(self, agent: str, subject: Judgeable, *, iteration: int = 1) -> JudgePanel:
        results = []
        for j in self.for_agent(agent):
            try:
                results.append(j.run(subject))
            except Exception as exc:  # a broken judge must not break the pipeline
                results.append(JudgeResult(
                    rule_id=j.rule_id, title=j.title, kind=j.kind, verdict=Verdict.WARN,
                    note=f"judge raised {type(exc).__name__}: {exc}",
                ))
        return JudgePanel(agent=agent, iteration=iteration, results=tuple(results))

    def __len__(self) -> int:
        return len(self._judges)
