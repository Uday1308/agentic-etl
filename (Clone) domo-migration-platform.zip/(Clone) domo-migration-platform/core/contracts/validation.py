"""core.contracts.validation — how "accuracy" is defined, measured and rolled up.

This is the number that ends up in the client deliverable, so it is defined once,
here, and computed identically for every dataflow in the estate. Nothing downstream
is allowed to invent its own arithmetic.

Three levels, each a pure function of the level below:

    Check          one comparison of one metric on one column (or the whole table)
    TargetParity   every check for one output table
    DataflowParity every target in one DOMO dataflow
    EstateParity   every dataflow in the migration

Design decisions worth knowing:

* Row count alone never constitutes a pass. Equal counts with wrong values is the
  failure mode that matters in a reconciliation pipeline, so a target is only
  ``exact`` when its value checks pass too.
* Checks are BLOCKING or ADVISORY. Blocking failures make the target fail.
  Advisory ones are recorded and reported but do not. Float sum drift inside
  tolerance is advisory; a distinct-count mismatch is never advisory.
* Accuracy is reported as a pair: ``targets_exact`` (the honest headline — how many
  outputs match perfectly) and ``check_pass_rate`` (the granular view). One number
  alone is misleading, and the client will ask both questions.
* Every comparison records the batch state it was taken at, because a parity result
  is meaningless without knowing which DOMO batch produced the expected side.
"""
from __future__ import annotations

import math
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Metric(str, Enum):
    """What was compared. Extend deliberately — each value needs a comparison rule."""
    ROW_COUNT = "row_count"
    SCHEMA = "schema"                 # column names + types present on both sides
    NULL_COUNT = "null_count"
    DISTINCT_COUNT = "distinct_count"
    SUM = "sum"
    MIN = "min"
    MAX = "max"
    CHECKSUM = "checksum"             # order-independent multiset hash of all rows


class Severity(str, Enum):
    BLOCKING = "blocking"             # failure fails the target
    ADVISORY = "advisory"             # failure is recorded, target can still pass


class CheckStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIPPED = "skipped"               # could not run (column absent, type unsupported)


#: Default severity per metric. Anything that can differ for benign floating-point
#: reasons is advisory; anything structural is blocking.
DEFAULT_SEVERITY: dict[Metric, Severity] = {
    Metric.ROW_COUNT: Severity.BLOCKING,
    Metric.SCHEMA: Severity.BLOCKING,
    Metric.NULL_COUNT: Severity.BLOCKING,
    Metric.DISTINCT_COUNT: Severity.BLOCKING,
    Metric.CHECKSUM: Severity.BLOCKING,
    Metric.SUM: Severity.ADVISORY,     # float accumulation order differs legitimately
    Metric.MIN: Severity.ADVISORY,
    Metric.MAX: Severity.ADVISORY,
}


class Check(BaseModel):
    """One comparison. Immutable once produced — this is evidence, not working state."""
    model_config = ConfigDict(frozen=True)

    metric: Metric
    column: str | None = None         # None for table-level metrics (row_count, checksum)
    expected: Any = None              # from DOMO
    actual: Any = None                # from the migrated table
    status: CheckStatus
    severity: Severity
    tolerance: float = 0.0            # relative tolerance applied, if any
    delta: float | None = None        # signed numeric difference where meaningful
    note: str = ""                    # why it was skipped, or what the mismatch means

    @property
    def failed(self) -> bool:
        return self.status is CheckStatus.FAIL

    @property
    def blocks(self) -> bool:
        return self.failed and self.severity is Severity.BLOCKING


def compare(
    metric: Metric,
    expected: Any,
    actual: Any,
    *,
    column: str | None = None,
    tolerance: float = 0.0,
    severity: Severity | None = None,
) -> Check:
    """Build a Check by applying the comparison rule for ``metric``.

    Numeric metrics honour a RELATIVE tolerance (0.0 means exact). Non-numeric
    metrics compare for equality. A None on either side yields SKIPPED rather than a
    false failure — an absent measurement is not a mismatch.
    """
    sev = severity or DEFAULT_SEVERITY.get(metric, Severity.BLOCKING)

    if expected is None or actual is None:
        return Check(metric=metric, column=column, expected=expected, actual=actual,
                     status=CheckStatus.SKIPPED, severity=sev, tolerance=tolerance,
                     note="measurement missing on one side")

    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)) \
            and not isinstance(expected, bool) and not isinstance(actual, bool):
        e, a = float(expected), float(actual)
        if math.isnan(e) or math.isnan(a):
            return Check(metric=metric, column=column, expected=expected, actual=actual,
                         status=CheckStatus.SKIPPED, severity=sev, tolerance=tolerance,
                         note="NaN measurement")
        delta = a - e
        scale = max(abs(e), abs(a), 1e-12)
        ok = abs(delta) <= tolerance * scale if tolerance > 0 else e == a
        return Check(metric=metric, column=column, expected=expected, actual=actual,
                     status=CheckStatus.PASS if ok else CheckStatus.FAIL,
                     severity=sev, tolerance=tolerance, delta=delta)

    ok = expected == actual
    return Check(metric=metric, column=column, expected=expected, actual=actual,
                 status=CheckStatus.PASS if ok else CheckStatus.FAIL,
                 severity=sev, tolerance=tolerance)


class BatchRef(BaseModel):
    """Which DOMO batch state the expected side was captured at.

    A parity result without this is not evidence. Inputs and expected outputs must be
    captured at the SAME batch state or the comparison is meaningless.
    """
    model_config = ConfigDict(frozen=True)

    dataset_id: str
    batch_id: int | None = None
    batch_last_run: str | None = None   # ISO timestamp as DOMO reported it
    row_count: int | None = None        # DOMO's own count, an independent reference


class TargetParity(BaseModel):
    """Every check for one migrated output table."""
    model_config = ConfigDict(frozen=True)

    target: str                        # DOMO dataset name of the output
    table: str                         # fully-qualified migrated table
    checks: tuple[Check, ...] = ()
    inputs: tuple[BatchRef, ...] = ()   # batch state of every input consumed
    expected_ref: BatchRef | None = None
    error: str | None = None            # comparison could not run at all

    @property
    def ran(self) -> tuple[Check, ...]:
        return tuple(c for c in self.checks if c.status is not CheckStatus.SKIPPED)

    @property
    def blocking_failures(self) -> tuple[Check, ...]:
        return tuple(c for c in self.checks if c.blocks)

    @property
    def advisory_failures(self) -> tuple[Check, ...]:
        return tuple(c for c in self.checks if c.failed and not c.blocks)

    @property
    def exact(self) -> bool:
        """No failures at all, and at least one value-level check actually ran.

        The second clause is what stops a target passing on row count alone.
        """
        if self.error or not self.ran:
            return False
        value_metrics = {Metric.SUM, Metric.CHECKSUM, Metric.NULL_COUNT,
                         Metric.DISTINCT_COUNT, Metric.MIN, Metric.MAX}
        if not any(c.metric in value_metrics for c in self.ran):
            return False
        return not any(c.failed for c in self.checks)

    @property
    def passed(self) -> bool:
        """No BLOCKING failures. Advisory drift is tolerated."""
        if self.error:
            return False
        return not self.blocking_failures and bool(self.ran)

    @property
    def check_pass_rate(self) -> float:
        ran = self.ran
        return sum(1 for c in ran if not c.failed) / len(ran) if ran else 0.0


class DataflowParity(BaseModel):
    """Rollup across every output table of one DOMO dataflow."""
    model_config = ConfigDict(frozen=True)

    dataflow_id: str
    dataflow_name: str = ""
    run_id: str = ""
    targets: tuple[TargetParity, ...] = ()

    @property
    def targets_exact(self) -> int:
        return sum(1 for t in self.targets if t.exact)

    @property
    def targets_passed(self) -> int:
        return sum(1 for t in self.targets if t.passed)

    @property
    def passed(self) -> bool:
        """A dataflow passes only if EVERY target passes. No partial credit here —
        a half-migrated dataflow is not migrated."""
        return bool(self.targets) and all(t.passed for t in self.targets)

    @property
    def exact(self) -> bool:
        return bool(self.targets) and all(t.exact for t in self.targets)

    @property
    def check_pass_rate(self) -> float:
        ran = [c for t in self.targets for c in t.ran]
        return sum(1 for c in ran if not c.failed) / len(ran) if ran else 0.0

    def summary(self) -> dict:
        return {
            "dataflow_id": self.dataflow_id,
            "targets": len(self.targets),
            "targets_exact": self.targets_exact,
            "targets_passed": self.targets_passed,
            "passed": self.passed,
            "check_pass_rate": round(self.check_pass_rate, 4),
        }


class EstateParity(BaseModel):
    """The client-facing number, across the whole migration."""
    model_config = ConfigDict(frozen=True)

    dataflows: tuple[DataflowParity, ...] = ()

    @property
    def total(self) -> int:
        return len(self.dataflows)

    @property
    def passed(self) -> int:
        return sum(1 for d in self.dataflows if d.passed)

    @property
    def exact(self) -> int:
        return sum(1 for d in self.dataflows if d.exact)

    @property
    def dataflow_pass_rate(self) -> float:
        return self.passed / self.total if self.total else 0.0

    @property
    def check_pass_rate(self) -> float:
        ran = [c for d in self.dataflows for t in d.targets for c in t.ran]
        return sum(1 for c in ran if not c.failed) / len(ran) if ran else 0.0

    def headline(self) -> dict:
        """Both numbers, always together. Reporting one alone misleads."""
        return {
            "dataflows_total": self.total,
            "dataflows_passed": self.passed,
            "dataflows_exact": self.exact,
            "dataflow_pass_rate": round(self.dataflow_pass_rate, 4),
            "check_pass_rate": round(self.check_pass_rate, 4),
        }


class FailureCategory(str, Enum):
    """Where a parity failure came from. Each routes to a different owner, which is
    the whole point of categorising rather than emitting prose."""
    INGESTION = "ingestion"           # source data differs -> connection/ingestion
    EXPRESSION = "expression"         # a translated expression is wrong -> md_plan
    COMPOSITION = "composition"       # join fanout, union order, grouping -> md_plan
    ASSEMBLY = "assembly"             # wiring of correct pieces -> cd_codegen
    INCREMENTAL = "incremental"       # scoping/watermark logic -> md_plan
    SOURCE_DRIFT = "source_drift"     # DOMO output moved between capture and compare
    NONDETERMINISM = "nondeterminism" # order-dependent aggregation, unstable result
    UNKNOWN = "unknown"               # needs human triage


class Diagnosis(BaseModel):
    """Validation's structured explanation of a failure. The category is what the
    graph routes on; the prose is for the human reading the review."""
    model_config = ConfigDict(frozen=True)

    category: FailureCategory
    owner_agent: str                  # which agent should regenerate
    nodes: tuple[str, ...] = ()       # node ids implicated
    explanation: str = ""
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    suggested_fix: str = ""


class ValidationReport(BaseModel):
    """What the Validation agent emits: the parity evidence plus, on failure, a
    routable diagnosis."""
    model_config = ConfigDict(frozen=True)

    parity: DataflowParity
    diagnoses: tuple[Diagnosis, ...] = ()

    @property
    def passed(self) -> bool:
        return self.parity.passed
