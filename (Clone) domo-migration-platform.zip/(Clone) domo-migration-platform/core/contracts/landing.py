"""core.contracts.landing — what a landed DOMO table has already been cleaned of.

The contract between whatever writes ``<catalog>.<source_schema>.*`` and everything
that reads it: the tile renderers, the expression emitter, the validation profiler.

Why this exists
---------------
DOMO's export writes a **leading apostrophe** on some values — the spreadsheet
convention for "treat this as text" — so a money column arrives as ``'-92866.56``
rather than ``-92866.56``. DOMO itself does not carry that through: its own output
table holds the clean value. A migration that lands the raw export and reads it as-is
therefore differs from DOMO on every affected row, and the difference is invisible
until something casts it.

It has surfaced six separate ways so far, each patched where it was noticed:

    filter comparisons        tiles._CLEAN
    alter-column casts        tiles._CLEAN
    arithmetic operands       expr.numeric_operand
    IFNULL numeric defaults   expr.numeric_operand
    numeric aggregates        expr.numeric_operand
    validation profiling      adapters.column_stats

Every one of those repairs a place a value is *read*. None of them repairs the value a
projection *carries*, because ``SELECT *`` cannot name a column to fix it — so the
artifact still reached the output table on any column no tile happened to touch.

Where to remove it
------------------
**Once, in the source CTE, naming every column.** ``cd_codegen`` does this when it is
given the source schemas::

    from agents.cd_codegen.sql_generator import generate_sql, source_columns_from_spark

    cols = source_columns_from_spark(spark, build)     # or a hand-written {table: {col: type}}
    generate_sql(dataflow, dataflow_id="8099", source_columns=cols)

That is the general fix: the strip is applied to every text column of every source, so
reads and carries are both covered and there is one place to look. It needs a column
list, which is why it is opt-in — DOMO's export does not carry source schemas, so they
have to be read from the tables themselves. Sources with no entry in the catalog are
marked in the generated SQL rather than passed off as clean.

**Or a cleaned VIEW over the raw table, with ``source_schema`` pointed at it.** Reading
``domo_input_clean.x`` instead of ``domo_input.x`` is a config change and not a code
change, and it needs nothing of the generator::

    create_clean_views(spark, "dev_test", "domo_input", "domo_input_clean")
    # then generate with source_schema="domo_input_clean"

Both beat cleaning on the way in, because a landed table should stay a faithful copy of
what DOMO exported: bronze is the export as received, and mutating it means there is no
longer anywhere to see what actually arrived. The cleanup belongs in the transformation.
``normalize_landed`` remains for a pipeline that would rather clean on write; the rule
it applies is identical either way.

After any of them, the six workarounds are harmless no-ops rather than the only defence.
They stay because they are also the only defence when no schema is available — an
offline dry run has none.

Scope, deliberately narrow
--------------------------
Only the leading apostrophe is stripped, because it is the only artifact proven to be
a *representation* difference rather than a value. Notably NOT included:

* ``tiles._CLEAN`` also strips a trailing ``E-<digits>``. In a string comparison that
  makes two renderings of the same number match; applied to a value it turns
  ``1.5E-05`` into ``1.5``, a hundred-thousand-fold error. It stays where it is, for
  comparisons only, and should not spread here.
* Trimming is opt-in. Trailing whitespace is common in these exports, but DOMO's own
  output may preserve it, and trimming at landing would then differ from DOMO in the
  other direction. Turn it on once you have checked.
"""
from __future__ import annotations

from typing import Any

#: A single leading apostrophe, DOMO's "force text" export marker.
LEADING_APOSTROPHE = "^'"

#: Human-readable description of every artifact this module removes. Keep in step with
#: ``strip_artifacts_sql`` — the validation report cites it when a parity diff is
#: explained by landing normalization.
REMOVED_ARTIFACTS = ("a single leading apostrophe (DOMO's force-as-text export marker)",)


def strip_artifacts_sql(col_sql: str) -> str:
    """SQL that removes DOMO's export artifacts from one text expression.

    ``col_sql`` is inserted verbatim, so pass an already-quoted identifier
    (``core.domo.naming.quoted``) or a full expression.
    """
    return "regexp_replace(" + col_sql + ", \"" + LEADING_APOSTROPHE + "\", '')"


def normalize_projection(columns: dict[str, str]) -> list[str]:
    """One projection item per column, artifacts stripped from the text ones.

    ``columns`` maps column name to Spark type string (as ``DataFrame.dtypes`` gives).
    Only ``string`` columns are touched — a number or a date cannot carry the artifact,
    and pushing them through ``regexp_replace`` would silently retype them to STRING,
    which is a worse bug than the one being fixed.

    Returned as items rather than as a whole SELECT so a caller can place them in its
    own statement: the source CTE in ``cd_codegen`` needs this projection with a WHERE
    clause attached. Every column is listed, including the untouched ones — naming only
    the text columns would drop the rest.
    """
    parts = []
    for name, dtype in columns.items():
        ident = "`" + str(name).replace("`", "``") + "`"
        if str(dtype).lower() == "string":
            parts.append(strip_artifacts_sql(ident) + " AS " + ident)
        else:
            parts.append(ident)
    return parts


def normalize_select_sql(table: str, columns: dict[str, str]) -> str:
    """A SELECT that lands ``table`` with the artifacts removed from its text columns.

    For landings written in SQL. Landings written with the DataFrame API should use
    ``normalize_landed``.
    """
    if not columns:
        raise ValueError(
            "landing: no columns given for " + table + "; the artifact strip has to name "
            "every column, so the table's schema is required")
    return ("SELECT\n" + ",\n".join("  " + p for p in normalize_projection(columns))
            + "\nFROM " + table)


def normalize_landed(df: Any, *, trim: bool = False) -> Any:
    """Remove DOMO's export artifacts from every string column of a DataFrame.

    Call this on the DataFrame you are about to write into the source schema::

        normalize_landed(spark.read.csv(export)).write.saveAsTable(target)

    Idempotent: running it over already-clean data changes nothing, so re-landing is
    safe. ``trim`` also strips surrounding whitespace — see the module docstring for
    why that is off by default.
    """
    from pyspark.sql import functions as F
    from pyspark.sql.types import StringType

    cols = []
    for field in df.schema.fields:
        c = F.col("`" + field.name + "`")
        if isinstance(field.dataType, StringType):
            c = F.regexp_replace(c, LEADING_APOSTROPHE, "")
            if trim:
                c = F.trim(c)
        cols.append(c.alias(field.name))
    return df.select(*cols)


def clean_view_ddl(source_table: str, view_table: str, columns: dict[str, str]) -> str:
    """DDL for a view that presents ``source_table`` with its text artifacts removed.

    A view rather than a table: no copy, no storage, no second thing to keep in sync,
    and the cleanup stays visible as SQL anyone can read.
    """
    return ("CREATE OR REPLACE VIEW " + view_table + " AS\n"
            + normalize_select_sql(source_table, columns))


def create_clean_views(spark: Any, catalog: str, source_schema: str,
                       clean_schema: str, *, tables: list[str] | None = None,
                       dry_run: bool = False) -> list[str]:
    """Create one artifact-free view per table in ``source_schema``.

    Returns the DDL it ran (or would run, with ``dry_run``). Safe to re-run: the views
    are CREATE OR REPLACE, and a table whose columns have changed simply gets a new
    definition — which is also why this must be re-run after a source schema change,
    since a view with an explicit column list does not pick up new columns by itself.
    """
    names = tables
    if names is None:
        names = [r[0] for r in
                 spark.sql("SHOW TABLES IN " + catalog + "." + source_schema)
                 .select("tableName").collect()]
    out: list[str] = []
    for name in names:
        src = catalog + "." + source_schema + "." + name
        cols = dict(spark.table(src).dtypes)
        if not any(str(t).lower() == "string" for t in cols.values()):
            continue                       # nothing that could carry the artifact
        ddl = clean_view_ddl(src, catalog + "." + clean_schema + "." + name, cols)
        out.append(ddl)
        if not dry_run:
            spark.sql(ddl)
    return out


def artifact_audit_sql(table: str, columns: dict[str, str]) -> str:
    """A query counting, per text column, how many values still carry an artifact.

    Run it against a landed table to see whether normalization is needed or worked.
    Every count zero means the table is clean.
    """
    text = [n for n, t in columns.items() if str(t).lower() == "string"]
    if not text:
        raise ValueError("landing: " + table + " has no string columns to audit")
    parts = []
    for name in text:
        ident = "`" + name.replace("`", "``") + "`"
        lit = "'" + name.replace("'", "''") + "'"
        parts.append(
            "  SUM(CASE WHEN " + ident + " RLIKE \"" + LEADING_APOSTROPHE
            + "\" THEN 1 ELSE 0 END) AS " + ident)
        del lit
    return ("SELECT\n" + ",\n".join(parts) + "\nFROM " + table)


__all__ = [
    "LEADING_APOSTROPHE",
    "clean_view_ddl",
    "create_clean_views",
    "REMOVED_ARTIFACTS",
    "artifact_audit_sql",
    "normalize_landed",
    "normalize_projection",
    "normalize_select_sql",
    "strip_artifacts_sql",
]
