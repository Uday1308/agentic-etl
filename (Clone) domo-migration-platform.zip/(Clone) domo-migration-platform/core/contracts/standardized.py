"""core.contracts.standardized — the standardized dataflow JSON, defined once.

The Standardization agent (2) writes one JSON per dataflow to a volume; Discovery (3)
and MD Plan (4) both read it. This module is the single definition of that document's
shape and the single place it is folded into the ``{"nodes", "edges"}`` form the
planner and the tile registry consume.

The document as written
-----------------------
Keyed by dataflow id, because a file may hold more than one::

    {"8099": {"id": 8099,
              "name": "...",
              "database_type": "MySQL",
              "deleted": false,
              "responsible_user_id": 1650988277,
              "inputs":  [{"dataSourceId", "dataSourceName"}],
              "outputs": [{"dataSourceId", "dataSourceName"}],
              "actions": [{"id", "name", "type", "logic"}],
              "connections": [{"from", "to"}],
              "disabled_skipped": []}}

``actions`` are the tiles, in no particular order; ``connections`` are the edges;
``logic`` is the tool-specific payload that ``core.domo.tiles`` interprets per type.
The planner needs ``{"dataflow_id", "nodes", "edges"}`` with ``logic`` carried on
``properties``, so ``to_planner_dataflow`` does exactly that fold — the mirror of
``core.contracts.discovery.to_dataflow``, which folds discovery *rows* into the same
shape. Two producers, one consumer shape, one definition of each mapping.

Why a fold rather than teaching the renderer this shape: the renderer already has two
upstreams (a standardized document and a discovery table). Normalizing at the boundary
keeps it with one input contract instead of two.
"""
from __future__ import annotations

from typing import Any

#: ``action.type`` values that are dataset reads, not transformations.
SOURCE_TYPES = frozenset({"source", "dataset", "data", "input", "datasource"})

#: ``action.type`` values that write a dataset out.
TARGET_TYPES = frozenset({"sink", "target", "output", "write", "publish"})

#: Top-level keys a dataflow object must carry to be foldable.
REQUIRED_KEYS = ("actions", "connections")


class StandardizedSchemaError(ValueError):
    """The standardized document is not in the documented shape."""


def unwrap(doc: Any, dataflow_id: str = "") -> tuple[str, dict]:
    """Return ``(dataflow_id, dataflow_object)`` from a standardized document.

    Accepts the id-keyed wrapper (the form the standardizer writes), a bare dataflow
    object, or either already folded. ``dataflow_id`` selects one when the wrapper
    holds several; without it a single-entry wrapper is unambiguous and anything else
    is an error rather than a guess.
    """
    if not isinstance(doc, dict):
        raise StandardizedSchemaError(
            f"standardized document is a {type(doc).__name__}, expected an object. "
            f"A discovery-table export is a list of rows — fold it with "
            f"core.contracts.discovery.to_dataflow() instead.")
    if not doc:
        raise StandardizedSchemaError("standardized document is empty")

    # already a dataflow object (wrapped or folded) — no id-keyed envelope
    if any(k in doc for k in REQUIRED_KEYS) or "nodes" in doc:
        return str(dataflow_id or doc.get("dataflow_id") or doc.get("id") or ""), doc

    wanted = str(dataflow_id) if dataflow_id else ""
    if wanted and wanted in doc:
        inner = doc[wanted]
    elif wanted:
        raise StandardizedSchemaError(
            f"standardized document has no entry for dataflow {wanted!r}; "
            f"it holds {sorted(doc)}")
    elif len(doc) == 1:
        wanted, inner = next(iter(doc.items()))
    else:
        raise StandardizedSchemaError(
            f"standardized document holds {len(doc)} dataflows ({sorted(doc)[:6]}); "
            f"pass dataflow_id to select one")

    if not isinstance(inner, dict):
        raise StandardizedSchemaError(
            f"dataflow {wanted!r} is a {type(inner).__name__}, expected an object")
    return str(wanted or inner.get("id") or ""), inner


def category_of(action_type: str) -> str:
    """SOURCE / TARGET / TRANSFORMATION for one ``action.type``."""
    t = (action_type or "").strip().lower()
    if t in SOURCE_TYPES:
        return "SOURCE"
    if t in TARGET_TYPES:
        return "TARGET"
    return "TRANSFORMATION"


def to_planner_dataflow(doc: Any, dataflow_id: str = "") -> dict:
    """Fold a standardized document into ``{"dataflow_id", "nodes", "edges"}``.

    ``action.logic`` becomes ``node.properties`` verbatim — the tile registry owns
    that payload and this module does not interpret it. Two enrichments are made
    because the information exists at the document level and is lost otherwise:

    * a sink's ``dataSourceId``, matched from ``outputs`` by dataset name — the sink's
      own ``logic`` carries only the name;
    * ``write_mode`` from ``versionChainType``, which is the key the renderer reads.

    Disabled tiles are dropped (DOMO keeps them in the export but does not run them),
    and edges touching a dropped tile are dropped with them, exactly as
    ``discovery.to_dataflow`` does.
    """
    df_id, flow = unwrap(doc, dataflow_id)

    # already folded — pass through so callers can accept either form
    if "nodes" in flow and "actions" not in flow:
        return {"dataflow_id": str(flow.get("dataflow_id") or df_id),
                "nodes": list(flow.get("nodes") or []),
                "edges": list(flow.get("edges") or flow.get("connections") or [])}

    missing = [k for k in REQUIRED_KEYS if k not in flow]
    if missing:
        raise StandardizedSchemaError(
            f"dataflow {df_id!r} is missing {missing}; it has {sorted(flow)}. Expected "
            f"the standardized shape (actions + connections) or the folded shape "
            f"(nodes + edges).")

    actions = list(flow.get("actions") or [])
    if not actions:
        raise StandardizedSchemaError(
            f"dataflow {df_id!r} has an empty 'actions' list, so a plan built from it "
            f"would have no steps. The standardizer produced a structurally valid but "
            f"empty document.")

    skipped = _skipped_ids(flow.get("disabled_skipped"))
    out_by_name = {str(o.get("dataSourceName") or ""): o
                   for o in (flow.get("outputs") or []) if isinstance(o, dict)}
    for o in (flow.get("outputs") or []):  # also keyed by id / qualified name (Snowflake names collide by name)
        if isinstance(o, dict):
            for key in ("dataset_id", "fq_name", "table"):
                if o.get(key):
                    out_by_name.setdefault(str(o[key]), o)

    nodes: list[dict] = []
    seen: set[str] = set()
    for a in actions:
        if not isinstance(a, dict):
            continue
        nid = str(a.get("id") or "")
        if not nid or nid in skipped or a.get("disabled"):
            continue
        if nid in seen:
            raise StandardizedSchemaError(
                f"dataflow {df_id!r} repeats action id {nid!r}; ids must be unique")
        seen.add(nid)
        a_type = str(a.get("type") or "")
        cat = category_of(a_type)
        props = dict(a.get("logic") or {})
        if cat == "TARGET":
            _enrich_target(props, out_by_name)
        nodes.append({
            "id": nid,
            "name": a.get("name") or nid,
            "type": a_type,
            "category": cat,
            "properties": props,
        })

    edges = []
    for c in (flow.get("connections") or []):
        if not isinstance(c, dict):
            continue
        src, dst = str(c.get("from") or ""), str(c.get("to") or "")
        if src in seen and dst in seen:
            edges.append({"from": src, "to": dst})

    return {"dataflow_id": str(df_id), "nodes": nodes, "edges": edges}


def validate_standardized(doc: Any, raw: dict | None = None,
                          dataflow_id: str = "") -> list[str]:
    """Return the problems with a standardized document; empty means it is sound.

    Returned rather than raised: the Standardization agent's gate collects these
    alongside its LLM evaluator's verdict and decides what blocks.

    When ``raw`` is supplied the check is also a losslessness count — every action and
    connection in the source document must survive into the standardized one. Renaming
    is allowed, dropping is not.
    """
    problems: list[str] = []
    try:
        df_id, flow = unwrap(doc, dataflow_id)
    except StandardizedSchemaError as e:
        return [str(e)]

    for key in REQUIRED_KEYS:
        if key not in flow:
            problems.append(f"missing required key: {key}")
    if problems:
        return problems
    if not isinstance(flow.get("actions"), list):
        problems.append("actions must be a list")
    if not isinstance(flow.get("connections"), list):
        problems.append("connections must be a list")
    if problems:
        return problems

    actions = flow["actions"]
    if not actions:
        problems.append("actions is empty — the document would produce a plan with no steps")
    ids = [str(a.get("id") or "") for a in actions if isinstance(a, dict)]
    if any(not i for i in ids):
        problems.append("one or more actions have an empty id")
    if len(set(ids)) != len(ids):
        problems.append("duplicate action ids in standardized output")
    known = set(ids)
    dangling = [c for c in flow["connections"] if isinstance(c, dict)
                and (str(c.get("from") or "") not in known
                     or str(c.get("to") or "") not in known)]
    if dangling:
        problems.append(f"{len(dangling)} connection(s) reference unknown action ids")

    if raw is not None:
        try:
            _, raw_flow = unwrap(raw, dataflow_id or df_id)
        except StandardizedSchemaError:
            raw_flow = raw if isinstance(raw, dict) else {}
        want_a = len(raw_flow.get("actions") or raw_flow.get("nodes") or [])
        want_c = len(raw_flow.get("connections") or raw_flow.get("edges") or [])
        skipped = len(_skipped_ids(flow.get("disabled_skipped")))
        if want_a and len(actions) + skipped != want_a:
            problems.append(
                f"action count changed: {want_a} -> {len(actions)} (+{skipped} skipped)")
        if want_c and len(flow["connections"]) != want_c:
            problems.append(
                f"connection count changed: {want_c} -> {len(flow['connections'])}")
    return problems


# --------------------------------------------------------------------------- #
# internals
# --------------------------------------------------------------------------- #
def _skipped_ids(disabled_skipped: Any) -> set[str]:
    """``disabled_skipped`` has been seen as a list of ids and as a list of objects."""
    out: set[str] = set()
    for item in (disabled_skipped or []):
        if isinstance(item, dict):
            nid = item.get("id") or item.get("node_id")
            if nid:
                out.add(str(nid))
        elif item:
            out.add(str(item))
    return out


def _enrich_target(props: dict, out_by_name: dict[str, dict]) -> None:
    """Carry the document-level output detail onto the sink that writes it."""
    name = str(props.get("datasetName") or props.get("dataset_name") or "")
    match = out_by_name.get(name)
    if match is None:
        # source-neutral lookup (ADR 032 section 2): the TARGET node's dataset id / fully qualified name
        for key in ("dataset_id", "datasetId", "fq_name", "table"):
            value = str(props.get(key) or "")
            hit = out_by_name.get(value) if value else None
            if hit is not None:
                match = hit
                break
    if match and not props.get("dataSourceId"):
        props["dataSourceId"] = match.get("dataSourceId", "")
    chain = props.get("versionChainType")
    if chain and "write_mode" not in props:
        props["write_mode"] = str(chain)


__all__ = [
    "REQUIRED_KEYS",
    "SOURCE_TYPES",
    "TARGET_TYPES",
    "StandardizedSchemaError",
    "category_of",
    "to_planner_dataflow",
    "unwrap",
    "validate_standardized",
]
