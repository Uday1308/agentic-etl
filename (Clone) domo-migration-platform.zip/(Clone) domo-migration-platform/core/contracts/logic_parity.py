"""core.contracts.logic_parity — does the generated SQL do what the DOMO graph says?

Data parity answers "are the numbers the same", and needs both systems to have run.
Logic parity answers a different question that needs neither: **is every tile
present, wired the same way, and reading columns that actually exist?** It is
computed from the DOMO graph and the generated SQL alone, so it is available the
moment codegen finishes and it is genuinely computed rather than asserted.

Two halves, and they catch different failures:

``structure``   Every transformation tile has a CTE; every DOMO edge appears as a
                reference between the corresponding CTEs; no CTE exists that no
                tile asked for; the chain ends at the declared target. This is the
                half that catches a dropped, duplicated or misordered tile — the
                failures that change results without changing row counts, and that
                a row-count check would wave straight through.

``lineage``     Every column a tile reads exists in what its input produces. This
                is the half that catches a rename or a drop: DOMO's Select tile
                renames ``C4`` to ``Settlement Date``, and any later tile still
                reading ``C4`` is reading a column that is no longer there.

What it deliberately does NOT claim
-----------------------------------
Nothing about values. Two dataflows can be structurally identical and produce
different numbers — a filter comparing against the wrong literal is invisible
here. Logic parity passing means the shape is right, and that is worth stating
plainly rather than letting it be read as "verified against DOMO".

Where a column set cannot be traced — the walk bottoms out at a SOURCE, and only
the table knows its columns — the check reports ``unverifiable`` and is counted
separately. It is never counted as a pass: "we could not check" and "we checked
and it was fine" are different answers, and collapsing them is how a gap becomes
invisible.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _vocabulary(vocabulary: Any = None) -> Any:
    """The pack vocabulary to judge with; the DOMO pack's when none is given (ADR 032 §1:
    the DOMO pin lives behind the pack, not in this module)."""
    if vocabulary is not None:
        return vocabulary
    from core.packs import default_pack

    return default_pack().vocabulary

#: Verdicts a single check can return. ``unverifiable`` is not a pass.
PASS, FAIL, UNVERIFIABLE = "pass", "fail", "unverifiable"


@dataclass
class Finding:
    """One check, on one thing, with the evidence to act on it."""
    check: str
    verdict: str
    subject: str = ""                 # the tile, CTE or column at issue
    detail: str = ""

    @property
    def ok(self) -> bool:
        return self.verdict == PASS


@dataclass
class TargetParity:
    """Logic parity for one output target."""
    target: str
    table: str = ""
    findings: list[Finding] = field(default_factory=list)

    @property
    def checks_run(self) -> int:
        return len(self.findings)

    @property
    def checks_passed(self) -> int:
        return sum(1 for f in self.findings if f.verdict == PASS)

    @property
    def failures(self) -> list[Finding]:
        return [f for f in self.findings if f.verdict == FAIL]

    @property
    def unverifiable(self) -> list[Finding]:
        return [f for f in self.findings if f.verdict == UNVERIFIABLE]

    @property
    def passed(self) -> bool:
        """No failures. Unverifiable checks do not fail a target, but they are
        reported so nobody reads a green result as a complete one."""
        return not self.failures

    @property
    def exact(self) -> bool:
        """Everything checked AND nothing left unchecked."""
        return self.passed and not self.unverifiable

    def diagnosis(self) -> str:
        if self.failures:
            lead = self.failures[0]
            more = f" (+{len(self.failures) - 1} more)" if len(self.failures) > 1 else ""
            return f"{lead.check}: {lead.detail}{more}"
        if self.unverifiable:
            return (f"{len(self.unverifiable)} check(s) could not be verified: "
                    f"{self.unverifiable[0].detail}")
        return ""


def columns_read(node: dict, *, vocabulary: Any = None) -> set[str]:
    """Every column name a tile reads from its input (the pack vocabulary's answer)."""
    return _vocabulary(vocabulary).columns_read(node)


def reads_in_order(node: dict, *, vocabulary: Any = None) -> list[tuple[set[str], str]]:
    """What a tile reads, and what it produces, in evaluation order (see the DOMO pack:
    a formula's later expression may read a column an earlier one created)."""
    return _vocabulary(vocabulary).reads_in_order(node)


def check_target(artifact: Any, *, nodes: list[dict], edges: list[dict],
                 df_var_of: dict[str, str], traced: dict[str, list[str] | None],
                 sections: dict[str, str], vocabulary: Any = None) -> TargetParity:
    """Structure and lineage for one generated artifact."""
    voc = _vocabulary(vocabulary)
    op_of = voc.op_of
    out = TargetParity(target=artifact.target, table=getattr(artifact, "table", ""))
    by_id = {str(n.get("id")): n for n in nodes}
    inputs_of: dict[str, list[str]] = {}
    for e in edges:
        inputs_of.setdefault(str(e.get("to")), []).append(str(e.get("from")))

    # which CTEs this artifact actually contains, and what each references
    present = set(sections)
    refs = {name: {other for other in present
                   if other != name and other in body}
            for name, body in sections.items()}

    # -- (a) structure ------------------------------------------------------ #
    # The tiles this target depends on, walked on the DOMO graph rather than on
    # the SQL, so a tile the generator dropped is still expected here.
    target_node = next((nid for nid, n in by_id.items()
                        if (n.get("properties") or {}).get("datasetName") == artifact.target
                        and op_of(n) in ("SINK", "WRITE", "OUTPUT")), "")
    wanted: set[str] = set()
    stack = [target_node] if target_node else []
    while stack:
        nid = stack.pop()
        if nid in wanted or nid not in by_id:
            continue
        wanted.add(nid)
        stack.extend(inputs_of.get(nid, []))

    missing = []
    for nid in sorted(wanted):
        node = by_id[nid]
        if op_of(node) in ("SINK", "WRITE", "OUTPUT"):
            continue                      # a sink is the final SELECT, not a CTE
        var = df_var_of.get(nid)
        if var and var not in present:
            missing.append(f"{node.get('name', nid)} ({var})")
    out.findings.append(Finding(
        "every tile has a CTE", FAIL if missing else PASS,
        subject=artifact.target,
        detail=(f"{len(missing)} tile(s) in this target's chain emitted no CTE: "
                f"{', '.join(missing[:4])}") if missing
        else f"{len(wanted) - 1} tile(s) each emitted exactly one CTE"))

    # Every DOMO edge inside the chain shows up as one CTE referencing another.
    broken = []
    for nid in sorted(wanted):
        child = df_var_of.get(nid)
        if not child or child not in present:
            continue
        for parent_id in inputs_of.get(nid, []):
            parent = df_var_of.get(parent_id)
            if parent and parent in present and parent not in refs.get(child, set()):
                broken.append(f"{parent} -> {child}")
    out.findings.append(Finding(
        "every DOMO edge is wired", FAIL if broken else PASS,
        subject=artifact.target,
        detail=(f"{len(broken)} edge(s) present in DOMO but not in the SQL: "
                f"{', '.join(broken[:4])}") if broken
        else "each CTE reads exactly the upstream tiles DOMO declares"))

    # A CTE nothing asked for is dead code at best and a stray branch at worst.
    known_vars = {df_var_of.get(nid) for nid in wanted}
    orphans = sorted(present - {v for v in known_vars if v})
    out.findings.append(Finding(
        "no unexplained CTEs", FAIL if orphans else PASS, subject=artifact.target,
        detail=(f"{len(orphans)} CTE(s) match no DOMO tile: {', '.join(orphans[:4])}")
        if orphans else f"all {len(present)} CTEs trace to a tile"))

    final = getattr(artifact, "final_cte", "")
    expected_final = df_var_of.get(next(iter(inputs_of.get(target_node, [])), ""), "")
    out.findings.append(Finding(
        "chain ends at the target", PASS if final and final == expected_final else FAIL,
        subject=artifact.target,
        detail=(f"final CTE {final!r} is the tile DOMO publishes from")
        if final == expected_final
        else f"final CTE is {final!r}; DOMO publishes from {expected_final!r}"))

    # -- (b) lineage -------------------------------------------------------- #
    unknown_inputs, bad_refs, checked = [], [], 0
    for nid in sorted(wanted):
        node = by_id[nid]
        if op_of(node) in ("SINK", "WRITE", "OUTPUT", "SOURCE", "DATASET"):
            continue
        steps = voc.reads_in_order(node)
        if not any(reads for reads, _ in steps):
            continue
        available: set[str] = set()
        unknown = False
        for parent_id in inputs_of.get(nid, []):
            cols = traced.get(parent_id)
            if cols is None:
                unknown = True
            else:
                available |= set(cols)
        if unknown:
            unknown_inputs.append(node.get("name", nid))
            continue
        checked += 1
        for reads, produces in steps:
            for col in sorted(reads - available):
                bad_refs.append(f"{node.get('name', nid)} reads `{col}`")
            # what this step produced is readable by the next, as DOMO evaluates
            if produces:
                available.add(produces)

    if bad_refs:
        verdict, detail = FAIL, (
            f"{len(bad_refs)} column reference(s) resolve to nothing upstream: "
            f"{'; '.join(bad_refs[:4])}")
    elif unknown_inputs and not checked:
        verdict, detail = UNVERIFIABLE, (
            f"no tile's inputs could be traced ({len(unknown_inputs)} unknown), so "
            f"no column reference was checked")
    else:
        verdict = PASS
        detail = f"every column read by {checked} tile(s) exists upstream"
        if unknown_inputs:
            detail += (f"; {len(unknown_inputs)} tile(s) skipped - their input "
                       f"columns bottom out at a source")
    out.findings.append(Finding("columns resolve upstream", verdict,
                                subject=artifact.target, detail=detail))
    return out


def logic_parity(artifacts, *, nodes: list[dict], edges: list[dict],
                 df_var_of: dict[str, str], sections_of, vocabulary: Any = None) -> list[TargetParity]:
    """Logic parity for every generated target.

    ``sections_of(artifact) -> {cte_name: body}`` is injected so this module never
    has to know how an artifact is split; the assembler owns that grammar and is
    the one place it should live.
    """
    voc = _vocabulary(vocabulary)
    traced: dict[str, list[str] | None] = {}
    by_id = {str(n.get("id")): n for n in nodes}
    inputs_of: dict[str, list[str]] = {}
    for e in edges:
        inputs_of.setdefault(str(e.get("to")), []).append(str(e.get("from")))

    def trace(nid: str, seen: frozenset = frozenset()) -> list[str] | None:
        if nid in traced:
            return traced[nid]
        if nid in seen or nid not in by_id:
            return None
        ups = [trace(u, seen | {nid}) for u in inputs_of.get(nid, [])]
        result = voc.output_columns(by_id[nid], ups)
        traced[nid] = result
        return result

    for nid in by_id:
        trace(nid)

    return [check_target(a, nodes=nodes, edges=edges, df_var_of=df_var_of,
                         traced=traced, sections=sections_of(a), vocabulary=voc)
            for a in artifacts if getattr(a, "sql", "")]


__all__ = ["Finding", "TargetParity", "PASS", "FAIL", "UNVERIFIABLE",
           "columns_read", "reads_in_order", "check_target", "logic_parity"]
