"""Credentials on stdin, owner-only key files, line-aware PEM redaction (P3-06)."""
from __future__ import annotations

import io
import json
import logging
import os
import stat

import pytest

from core.common.secrets_io import (
    PemRedactor,
    RedactingFilter,
    read_credentials,
    redact_pem_lines,
    write_private_file,
)
from scripts.run_batch import load_bundle

PEM = "-----BEGIN PRIVATE KEY-----\nAAAA\nBBBB\n-----END PRIVATE KEY-----"


def test_redact_whole_and_truncated():
    out = redact_pem_lines(f"a\n{PEM}\nb")
    assert "AAAA" not in out and out.startswith("a") and out.endswith("b")
    assert "BBBB" not in redact_pem_lines("a\n-----BEGIN PRIVATE KEY-----\nAAAA\nBBBB")


def test_stream_redactor_keeps_state_between_lines():
    r = PemRedactor()
    kept = [r.line(x) for x in PEM.splitlines()]
    assert kept[0] == "[redacted key]" and kept[1:] == [None, None, None]


def test_logging_filter_redacts():
    rec = logging.LogRecord("x", logging.INFO, "f", 1, f"key:\n{PEM}", (), None)
    RedactingFilter().filter(rec)
    assert "AAAA" not in rec.getMessage()


def test_credentials_pem_becomes_owner_only_file(tmp_path):
    creds = read_credentials(io.StringIO(json.dumps({"user": "svc", "private_key": PEM})), key_dir=tmp_path)
    assert creds["user"] == "svc"
    path = creds["private_key"]
    assert os.path.exists(path) and "BEGIN PRIVATE KEY" in open(path, encoding="utf-8").read()
    if os.name != "nt":
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o600


def test_write_private_file_sanitizes_name(tmp_path):
    p = write_private_file(tmp_path, "../evil name", "x")
    assert p.parent == tmp_path


def test_v1_snowflake_bundle_refused_v2_accepted(tmp_path):
    def bundle(version, platform):
        (tmp_path / "manifest.json").write_text(json.dumps(
            {"kind": "etl_logic_migration", "manifest_version": version, "etls": [],
             "source": {"id": "s1", "platform": platform}}), encoding="utf-8")
        return tmp_path
    with pytest.raises(SystemExit):
        load_bundle(bundle("1", "snowflake"))
    assert load_bundle(bundle("2", "snowflake"))["manifest_version"] == "2"
    assert load_bundle(bundle("1", "domo"))["manifest_version"] == "1"
