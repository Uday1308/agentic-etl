"""P3-03 (ADR 032 section 3), migrator side: the harness ACTOR approves only all-mapped plan/sql gates;
the awaiting_review / blocked / unsupported statuses; the "awaiting review" alias; --resume reusing
approved gates by payload hash; approval of a changed artifact refused."""
from __future__ import annotations

import json
import pathlib

import pytest
from test_run_batch import flow, make_bundle

from api.models import FeedbackSubmission
from api.ports import ArtifactChanged
from api.store_local import LocalStore
from core.review import BATCH_STATUSES, may_auto_approve, normalize_status
from scripts.e2e_mock_run import ACTOR
from scripts.run_batch import run_batch


def test_the_actor_may_approve_only_all_mapped_plan_and_sql_gates():
    assert may_auto_approve("plan", ["mapped", "mapped"]) == (True, "")
    assert may_auto_approve("sql", ["mapped"]) == (True, "")
    for origin in ("ai", "transpiled", "manual", "unresolved"):
        ok, why = may_auto_approve("sql", ["mapped", origin])
        assert not ok and origin in why
    assert not may_auto_approve("translation", ["mapped"])[0]
    assert not may_auto_approve("plan", ["mapped"], review_caveats=["SNW-REVIEW"])[0]


def test_awaiting_review_has_one_value_and_the_old_spelling_is_an_alias():
    assert normalize_status("awaiting review") == "awaiting_review" == normalize_status("awaiting_review")
    assert {"awaiting_review", "blocked", "unsupported", "lifted", "retired", "undecided"} <= set(BATCH_STATUSES)


def _risky_bundle(root: pathlib.Path) -> pathlib.Path:
    """ETL 11 has a tile no renderer knows (not mapped); ETL 12 depends on it."""
    b = make_bundle(root)
    f = flow("11", "orders", "orders_clean")
    f["11"]["actions"][1] = {"id": "a2", "name": "Risk", "type": "RiskScore", "logic": {}}
    (b / "etls" / "11.json").write_text(json.dumps(f), encoding="utf-8")
    return b


def _decisions(run_dir: pathlib.Path) -> list[dict]:
    rows: list[dict] = []
    for p in run_dir.rglob("decision*.json"):
        rows += json.loads(p.read_text(encoding="utf-8"))
    return rows


async def test_a_non_mapped_unit_leaves_the_gate_open_and_blocks_dependants(tmp_path):
    rep = await run_batch(_risky_bundle(tmp_path), volume=tmp_path / "vol", work=tmp_path / "work")
    assert [(r["etl_id"], r["status"]) for r in rep["etls"]] == [("11", "awaiting_review"), ("12", "blocked")]
    assert rep["counts"]["awaiting_review"] == 1 and rep["counts"]["blocked"] == 1 and rep["counts"]["migrated"] == 0
    held = rep["etls"][0]["review_gates"]
    assert [g["agent"] for g in held] == ["md_plan"] and held[0]["payload_hash"]
    run_dir = pathlib.Path(rep["etls"][0]["run_dir"])
    assert not any(d.get("actor") == ACTOR for d in _decisions(run_dir))          # no bot approval
    gate = json.loads((run_dir / "gates" / f"{held[0]['gate_id']}.json").read_text(encoding="utf-8"))
    assert gate["status"] == "interrupted" and "unresolved" in gate["review_required"]


async def test_an_unknown_source_platform_is_unsupported(tmp_path):
    b = make_bundle(tmp_path)
    m = json.loads((b / "manifest.json").read_text(encoding="utf-8"))
    m["manifest_version"] = "2"                    # a non-DOMO bundle is v2 (ADR 032); the platform has no pack
    m["source"] = {"id": "src_infa", "key": "infa", "platform": "informatica"}
    (b / "manifest.json").write_text(json.dumps(m), encoding="utf-8")
    rep = await run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work")
    assert {r["status"] for r in rep["etls"]} == {"unsupported"} and rep["counts"]["unsupported"] == 2


def _approve(work: pathlib.Path, gate: dict, *, payload_hash: str | None = None, approve: bool = True) -> None:
    (work / "feedback").mkdir(parents=True, exist_ok=True)
    (work / "feedback" / f"{gate['gate_id']}.approval.json").write_text(json.dumps({
        "gate_id": gate["gate_id"], "approve": approve, "reviewer": "lead@example.invalid",
        "payload_hash": gate["payload_hash"] if payload_hash is None else payload_hash,
        "decision_id": f"{gate['gate_id']}@t1"}), encoding="utf-8")


async def test_resume_reuses_an_approved_gate_with_an_unchanged_payload_hash(tmp_path):
    b, vol, work = _risky_bundle(tmp_path), tmp_path / "vol", tmp_path / "work"
    first = await run_batch(b, volume=vol, work=work)
    # nothing approved yet: resume carries the ETL over and its dependant stays blocked
    again = await run_batch(b, volume=vol, work=work, resume=first["batch_run_id"])
    assert [r["status"] for r in again["etls"]] == ["awaiting_review", "blocked"]

    _approve(work, first["etls"][0]["review_gates"][0])
    resumed = await run_batch(b, volume=vol, work=work, resume=first["batch_run_id"])
    row = resumed["etls"][0]
    assert row["reused_approvals"] == ["md_plan"] and resumed["resumed_from"] == first["batch_run_id"]
    # the plan gate was re-approved under the human's name; the SQL still holds an unresolved unit
    assert [g["agent"] for g in row["review_gates"]] == ["cd_codegen"] and row["status"] == "awaiting_review"
    reused = [d for d in _decisions(pathlib.Path(row["run_dir"])) if "reused_from" in d.get("rationale", "")]
    assert reused and reused[0]["actor"] == "lead@example.invalid"
    assert resumed["etls"][1]["status"] == "blocked"


async def test_a_changed_payload_hash_reopens_the_gate(tmp_path):
    b, vol, work = _risky_bundle(tmp_path), tmp_path / "vol", tmp_path / "work"
    first = await run_batch(b, volume=vol, work=work)
    _approve(work, first["etls"][0]["review_gates"][0], payload_hash="0" * 64)
    resumed = await run_batch(b, volume=vol, work=work, resume=first["batch_run_id"])
    assert [g["agent"] for g in resumed["etls"][0]["review_gates"]] == ["md_plan"]


async def test_a_rejected_review_does_not_resume(tmp_path):
    b, vol, work = _risky_bundle(tmp_path), tmp_path / "vol", tmp_path / "work"
    first = await run_batch(b, volume=vol, work=work)
    _approve(work, first["etls"][0]["review_gates"][0], approve=False)
    resumed = await run_batch(b, volume=vol, work=work, resume=first["batch_run_id"])
    assert resumed["etls"][0]["status"] == "awaiting_review" and "reused_approvals" not in resumed["etls"][0]


async def test_an_all_mapped_batch_still_migrates_and_its_sql_gate_holds_refs_not_text(tmp_path):
    rep = await run_batch(make_bundle(tmp_path), volume=tmp_path / "vol", work=tmp_path / "work")
    assert [r["status"] for r in rep["etls"]] == ["migrated", "migrated"]
    run_dir = pathlib.Path(rep["etls"][0]["run_dir"])
    gate = json.loads((run_dir / "gates" / "gate-cd_codegen-11-i1.json").read_text(encoding="utf-8"))
    t = gate["artifact"]["targets"][0]
    assert t["artifact_ref"].endswith(t["sha256"]) and "preview" in t and gate["payload_hash"]
    assert gate["artifact"]["coverage"]["mapped"] == 1
    assert any(d.get("actor") == ACTOR for d in _decisions(run_dir))   # all mapped: the harness approves
    # coverage dict on the ETL row, in the run record and summed in the batch report (section 3)
    assert rep["etls"][0]["coverage"]["mapped"] == 1 and rep["etls"][0]["coverage"]["ai"] == 0
    assert rep["coverage"]["mapped"] == 2 and rep["coverage"]["share"]["mapped"] == 100.0
    record = next(r for r in json.loads((tmp_path / "vol" / "runs.json").read_text(encoding="utf-8"))
                  if r["run_id"] == rep["etls"][0]["run_id"])
    assert record["coverage"] == rep["etls"][0]["coverage"]


async def test_approving_a_changed_artifact_is_refused(tmp_path):
    vol, work = tmp_path / "vol", tmp_path / "work"
    rep = await run_batch(make_bundle(tmp_path), volume=vol, work=work, stop_at="cd_codegen")
    store = LocalStore(tmp_path, work=work, volume=vol)
    gate = next(g for g in store.gates() if g.agent == "cd_codegen" and g.dataflow_id == "11")
    target = gate.artifact.targets[0]
    sub = FeedbackSubmission(actor="lead@example.invalid", approve=True)
    receipt = store.submit_feedback(gate.gate_id, sub)
    assert receipt.decision_rows
    approval = json.loads((work / "feedback" / f"{gate.gate_id}.approval.json").read_text(encoding="utf-8"))
    assert approval["artifacts"] == [{"artifact_ref": target["artifact_ref"], "sha256": target["sha256"]}]
    assert "SELECT" not in json.dumps(approval)                                   # refs and hashes, never text
    key, sha = target["artifact_ref"].split("/")
    (vol / key / "artifacts" / f"{sha}.sql").write_text("SELECT 'tampered'", encoding="utf-8")
    with pytest.raises(ArtifactChanged, match="changed"):
        store.submit_feedback(gate.gate_id, sub)
    assert rep["counts"]["stopped"] == 2
