"""S3 / S10 live variants (not run offline: excluded by the default marker filter). Needs DATABRICKS_HOST, a warehouse
(DATABRICKS_WAREHOUSE_ID) and credentials.
Run: ``.venv/Scripts/python -m pytest tests/integration/test_snowflake_verify_live.py -m databricks``."""

import pytest

from packs.snowflake import verify as vf
from packs.snowflake.warehouse import from_env

pytestmark = pytest.mark.databricks


def _wh():
    wh, why = from_env()
    if wh is None:
        pytest.skip(why)
    return wh


def test_explain_and_describe_query_on_a_real_warehouse():
    wh = _wh()
    ev, _ = vf.verify_sql(vf.VerifyConfig(wh, check_schema=False), "cte_chain", "SELECT 1 AS a")
    assert ev["status"] == "passed"
    bad, _ = vf.verify_sql(vf.VerifyConfig(wh, check_schema=False), "cte_chain", "SELECT no_such_fn(1)")
    assert bad["status"] == "failed" and bad["explain"]["error_class"]


def test_union_type_conflict_repair_on_a_real_warehouse():
    wh = _wh()
    sql = "SELECT CAST(1 AS BIGINT) AS id UNION ALL SELECT CAST(2 AS DECIMAL(38,0))"
    ev, fixed = vf.verify_sql(vf.VerifyConfig(wh, check_schema=False), "cte_chain", sql)
    assert ev["status"] == "passed"
