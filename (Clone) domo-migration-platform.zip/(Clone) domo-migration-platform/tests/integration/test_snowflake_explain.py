"""P3-20 (ADR 032 section 8, D-34): execution proof. "Translated" means a ``databricks``-marked test ran ``EXPLAIN`` on
EVERY generated artefact of the Snowflake fixture batch against a workspace that holds the UC target fixture
(``sfdemo_sales_db_core`` / ``sfdemo_sales_db_analytics``: ORDERS, CUSTOMERS, ORDER_ITEMS, PRODUCTS, RETURNS,
ORDER_FACTS, see ``tests/fixtures/snowflake/README.md``). It CANNOT run offline or in CI: excluded by the default
``-m 'not databricks'``. A green offline Snowflake run proves translation, not execution; this is the bar.

Run (needs a workspace, a SQL warehouse and the target fixture loaded):

    DATABRICKS_HOST=... DATABRICKS_TOKEN=... DATABRICKS_WAREHOUSE_ID=... \\
        .venv/Scripts/python -m pytest tests/integration/test_snowflake_explain.py -m databricks

Artefact kinds and what gets explained: ``cte_chain`` / ``statement`` / ``file_load`` / ``governance`` the text
itself; ``pipeline`` the inner query after ``AS`` (a pipeline is created by the pipelines service, not a warehouse);
``script`` every top-level statement of the procedure body; ``job`` every task's SQL body (the Jobs API schema is
checked offline by ``packs.snowflake.validators.v_job``); ``python`` is compiled (``ast.parse``) and its
``spark.sql`` literals explained."""
from __future__ import annotations

import ast
import asyncio
import os
import pathlib
import re
import sys

import pytest

pytestmark = pytest.mark.databricks

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "packs"))

from snowflake_bundle import make_bundle  # noqa: E402

from packs.snowflake.scripting import split_scripting  # noqa: E402
from scripts.run_batch import run_batch  # noqa: E402


def explain_targets(kind: str, text: str) -> list[str]:
    if kind == "pipeline":
        m = re.search(r"\bAS\b\s*(.+)$", text, re.I | re.S)
        return [m.group(1).strip()] if m else []
    if kind == "script":
        m = re.search(r"\bBEGIN\b(.*)\bEND\b\s*;?\s*$", text, re.I | re.S)
        return [n.text for n in split_scripting("BEGIN " + (m.group(1) if m else "") + " END")
                if n.kind in ("statement", "call")]
    if kind == "python":
        ast.parse(text)
        return [n.value for n in ast.walk(ast.parse(text)) if isinstance(n, ast.Constant)
                and isinstance(n.value, str) and re.match(r"\s*(select|merge|insert)\b", n.value, re.I)]
    return [text]


def workspace():
    from databricks.sdk import WorkspaceClient

    wh = os.environ.get("DATABRICKS_WAREHOUSE_ID")
    if not (os.environ.get("DATABRICKS_HOST") and wh):
        pytest.skip("DATABRICKS_HOST / DATABRICKS_WAREHOUSE_ID not set")
    return WorkspaceClient(), wh


def explain(w, wh: str, sql: str) -> None:
    res = w.statement_execution.execute_statement(statement=f"EXPLAIN {sql}", warehouse_id=wh, wait_timeout="30s")
    assert res.status and res.status.state.value == "SUCCEEDED", f"EXPLAIN failed for: {sql[:120]} -> {res.status}"


def test_explain_passes_on_every_generated_artefact(tmp_path):
    w, wh = workspace()
    bundle = make_bundle(tmp_path)
    report = asyncio.run(run_batch(bundle, volume=tmp_path / "vol", work=tmp_path / "work"))
    from agents.cd_codegen.translate.artifacts import read_artifact

    checked = 0
    for row in report["etls"]:
        for gate in (pathlib.Path(row["run_dir"]) / "gates").glob("gate-cd_codegen-*.json") if row.get("run_dir") else []:
            import json

            for art in json.loads(gate.read_text(encoding="utf-8"))["artifact"]["artifacts"]:
                for sql in explain_targets(art["kind"], read_artifact(tmp_path / "vol", art["artifact_ref"])):
                    explain(w, wh, sql)
                    checked += 1
    assert checked >= 5, "the fixture batch should have produced explainable artefacts"
