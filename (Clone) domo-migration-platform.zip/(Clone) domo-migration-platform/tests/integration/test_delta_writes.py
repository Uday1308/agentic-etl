"""Integration tests — real local Spark + Delta round-trips (guide §8, §10).

These exercise the ACTUAL Delta append/read-back that the fast contract tests
deliberately stub behind the sink seam:

  * ``DeltaObservabilityWriter`` default (Spark) path — one row written and read back
  * ``SparkDeltaAuditor`` (checkpoint) append — one audit row written and read back

They need a JVM + ``pyspark`` + ``delta-spark`` and network access to fetch the Delta
JARs, so they are marked ``integration`` and run in a dedicated CI job — NOT the fast
gate. If a Spark/Delta session can't be created (missing deps, offline, wrong Java),
the whole module SKIPS rather than fails, so it never blocks local work.

Note: rows here are fully populated on purpose. Persisting NULL columns (e.g. redacted
text with ``capture_text=False``) requires the real writer to supply an explicit Delta
schema — Spark can't infer a type for an all-NULL column. The redaction *decision* is
already covered fast in tests/contracts/test_observability.py; persisting NULLs on disk
is a schema concern for the real writer.
"""
import tempfile

import pytest

pytest.importorskip("pyspark")
pytest.importorskip("delta")

from delta import configure_spark_with_delta_pip  # noqa: E402
from pyspark.sql import SparkSession  # noqa: E402

from core.domo.checkpoint import SparkDeltaAuditor  # noqa: E402
from core.domo.observability import DeltaObservabilityWriter, LlmCallRow, NodeRow  # noqa: E402

pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def spark():
    warehouse = tempfile.mkdtemp()
    builder = (
        SparkSession.builder.master("local[1]").appName("core-integration")
        .config("spark.sql.warehouse.dir", warehouse)
        .config("spark.ui.enabled", "false")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )
    try:
        session = configure_spark_with_delta_pip(builder).getOrCreate()
    except Exception as exc:                # offline / no Delta jars / wrong Java
        pytest.skip(f"Spark+Delta session unavailable here: {exc!r}")
    session.sparkContext.setLogLevel("ERROR")
    yield session
    session.stop()


def _full_row(**over) -> LlmCallRow:
    base = dict(obs_run_id="r1", thread_id="t1", dataflow_id="8842", agent="md_plan",
                node="generate", role="generator", model="gen-endpoint", pool="cd_translation",
                prompt_hash="h1", prompt_text="the prompt", response_text="the response",
                tokens_in=10, tokens_out=4, latency_ms=120, retries=0,
                cost=0.0012, confidence=0.91, iteration=1, status="ok")
    base.update(over)
    return LlmCallRow(**base)


def test_observability_writer_delta_round_trip(spark):
    w = DeltaObservabilityWriter(capture_text=True, llm_table="obs_llm_calls",
                                 node_table="obs_nodes", spark=spark)
    w.record_llm_call(_full_row())
    w.record_node(NodeRow(obs_run_id="r1", thread_id="t1", agent="md_plan", node="generate",
                          iteration=1, status="success", duration_ms=42))

    assert spark.table("obs_llm_calls").count() == 1
    assert spark.table("obs_nodes").count() == 1
    row = spark.table("obs_llm_calls").collect()[0]
    assert row["prompt_text"] == "the prompt"      # captured when the flag is on
    assert row["prompt_hash"] == "h1"              # hash always present
    assert row["confidence"] == 0.91


def test_checkpoint_delta_auditor_round_trip(spark):
    auditor = SparkDeltaAuditor(table="checkpoint_audit", spark=spark)
    auditor.append("thread-xyz", {"dataflow_id": "8842", "current_agent": "md_plan",
                                  "status": "running"})
    rows = spark.table("checkpoint_audit").collect()
    assert len(rows) == 1
    assert rows[0]["thread_id"] == "thread-xyz"
    assert rows[0]["dataflow_id"] == "8842"
