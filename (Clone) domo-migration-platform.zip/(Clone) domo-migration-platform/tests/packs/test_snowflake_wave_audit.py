"""Regressions found by the all-waves audit (tests/tools/run_all_waves.py): post-pass rewrites, job assembly on resume."""
from __future__ import annotations

from packs.snowflake import assembly as asm
from packs.snowflake.postpass import Postpass, PostpassContext

TMAP = {("SALES_DB", "RAW", "ORDERS_RAW"): "main.t.orders_raw", ("SALES_DB", "CORE", "ORDERS"): "main.t.orders"}


def _pp(engine="task"):
    return Postpass(PostpassContext(table_map=TMAP, default_db="SALES_DB", default_schema="CORE", engine=engine))


def test_table_changes_literal_is_mapped_and_unmapped_one_is_flagged():
    ok = _pp().apply("SELECT * FROM TABLE_CHANGES('SALES_DB.RAW.ORDERS_RAW', 1)")
    assert "main.t.orders_raw" in ok.sql and not ok.unmapped
    bad = _pp().apply("SELECT * FROM TABLE_CHANGES('SALES_DB.RAW.GHOST', 1)")
    assert bad.unmapped == ["SALES_DB.RAW.GHOST"]


def test_qualified_routine_call_uses_the_definition_name_and_is_idempotent():
    once = _pp().apply("SELECT SALES_DB.CORE.UDF_NET(a, b) FROM SALES_DB.CORE.ORDERS").sql
    assert "main.sales_db_core.udf_net(a, b)" in once and "main.t.orders" in once
    assert _pp().apply(once).sql == once


def test_procedure_bind_variable_becomes_a_bare_name():
    out = _pp("sql_procedure").apply("SELECT a FROM SALES_DB.CORE.ORDERS LIMIT :P_LIMIT").sql
    assert out.endswith("LIMIT P_LIMIT") or out.lower().endswith("limit p_limit")
    assert ":P_LIMIT" in _pp("task").apply("SELECT a FROM SALES_DB.CORE.ORDERS LIMIT :P_LIMIT").sql


def test_stream_trigger_names_the_base_table():
    root = asm.EtlOutcome("r", "k", "task", "SALES_DB.CORE.MERGE", params={
        "condition_text": "SYSTEM$STREAM_HAS_DATA('SALES_DB.RAW.ORDERS_RAW_STREAM')",
        "stream_tables": {"ORDERS_RAW_STREAM": "main.t.orders_raw"}})
    jobs, reasons, _ = asm.build_jobs([root])
    assert jobs[0]["trigger"]["table_update"]["table_names"] == ["main.t.orders_raw"]
    assert not any("set the table names" in r for r in reasons)


def test_assembly_outcome_round_trips_without_sql_text():
    o = asm.EtlOutcome("1", "k", "task", "SALES_DB.CORE.ROOT", params={"schedule": "5 MINUTE"})
    back = asm.outcome_from_dict(asm.outcome_to_dict(o))
    jobs, _, _ = asm.build_jobs([back])
    assert jobs[0]["schedule"]["quartz_cron_expression"] == "0 0/5 * * * ?"


def test_routine_overloads_sharing_a_name_are_a_batch_review_reason():
    a = asm.EtlOutcome("1", "k1", "sql_procedure", "SALES_DB.CORE.LOAD_PRODUCTS(VARCHAR)")
    b = asm.EtlOutcome("2", "k2", "sql_procedure", "SALES_DB.CORE.LOAD_PRODUCTS(VARCHAR,NUMBER)")
    out = asm.assemble_batch(None, [a, b], {})
    assert any("2 overloads share one Databricks routine name" in r for r in out.review_reasons)
