"""Every picked asset gets a row (docs/plans/migrator-experience.md 3.2): a pipe-only batch builds a file_load unit
(it used to end "Succeeded, 0 migrated"), a mixed pick yields one row per asset with its route, a batch of only lifted /
retired / absorbed assets is `nothing_to_build`, and the delete endpoints remove a batch and a run. Offline."""
from __future__ import annotations

import asyncio
import json
import pathlib

import pytest
from fastapi.testclient import TestClient
from snowflake_bundle import etl, oid, table

from api.app import app, get_store
from api.store_local import LocalStore
from scripts.run_batch import run_batch

REPO = pathlib.Path(__file__).resolve().parents[2]
PIPE = oid("RAW", "ORDERS_PIPE", "pipe")
STREAM = oid("RAW", "ORDERS_STREAM")
POLICY = "snowflake:policy:SALES_DB.GOV.EMAIL_MASK@acme-prod.SALES_DB.CORE.CUSTOMERS#EMAIL"


def bundle(root: pathlib.Path, *, etls=(), file_loads=(), other=(), governance=(), excluded=()) -> pathlib.Path:
    b = root / "bundle"
    (b / "etls").mkdir(parents=True)
    rows = []
    for order, name, schema, engine, definition, kw in etls:
        row, doc = etl(order, name, schema, engine, definition, **kw)
        (b / "etls" / f"{name}.json").write_text(json.dumps(doc), encoding="utf-8")
        rows.append(row)
    loads = []
    for name in file_loads:
        eid = f"acme-prod.SALES_DB.RAW.pipe/{name}"
        (b / "etls" / f"{eid}.json").parent.mkdir(parents=True, exist_ok=True)     # native ids hold a "/"
        (b / "etls" / f"{eid}.json").write_text(json.dumps({"definition": "COPY INTO RAW.EVENTS FROM @RAW.STG"}),
                                                encoding="utf-8")
        loads.append({"etl_key": f"sfdemo__{name}", "etl_id": eid, "asset_id": PIPE, "name": name, "engine": "snowpipe",
                      "unit_kind": "file_load", "outputs": [table("RAW", "EVENTS")], "definition": f"etls/{eid}.json",
                      "url": "s3://example-landing/in/", "file_format": {"options": {"TYPE": "CSV", "SKIP_HEADER": 1}},
                      "auto_ingest": True, "in_scope": True})
    manifest = {
        "manifest_version": "2", "kind": "etl_logic_migration", "snapshot_id": "sf-1", "strategy": "dependency_waves",
        "selection": {"key": "assets-x", "wave": None, "batch_ids": [], "etl_ids": [], "asset_ids": []},
        "source": {"id": "sfdemo", "key": "sfdemo", "platform": "snowflake", "dialect": "snowflake"},
        "target": {"target_catalog": "main"}, "etls": rows, "file_loads": loads, "read_statements": [],
        "table_map": {}, "target_map": {}, "governance": list(governance), "other_assets": list(other),
        "excluded_etls": list(excluded), "notes": []}
    (b / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return b


def run(tmp_path, **kw):
    b = bundle(tmp_path, **kw)
    return asyncio.run(run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work"))


def by_asset(rep):
    return {r["asset_id"]: r for r in rep["rows"]}


def test_pipe_only_batch_produces_a_file_load_unit(tmp_path):
    rep = run(tmp_path, file_loads=["ORDERS_PIPE"])
    assert rep["summary"]["units_total"] == 1 and rep["summary"]["status"] == "needs_review"
    row = by_asset(rep)[PIPE]
    assert row["route"] == "file_load" and row["status"] == "awaiting_review"
    assert row["artifacts"] and row["artifacts"][0]["kind"] == "file_load" and row["unit_id"]
    assert row["gate_id"] and row["target"] == "main.sfdemo_sales_db_raw.events"
    vol = tmp_path / "vol"
    record = json.loads(next(vol.glob("*/run-*/run.json")).read_text(encoding="utf-8"))
    ref = record["source_definition_ref"]
    assert set(ref) == {"artifact_ref", "sha256"} and "COPY INTO" not in json.dumps(record)
    from agents.cd_codegen.translate.artifacts import read_artifact
    assert "COPY INTO" in read_artifact(vol, ref["artifact_ref"])                       # the text, by hash, on the volume
    assert rep["counts"]["awaiting_review"] == 1 and rep["counts"]["migrated"] == 0


def test_mixed_pick_has_one_row_per_asset_with_its_route(tmp_path):
    view = ("V_ORDER_NET", "CORE", "sql_view", "SELECT ORDER_ID FROM CORE.ORDERS", {"inputs": [table("CORE", "ORDERS")]})
    other = [
        {"asset_id": oid("CORE", "CUSTOMERS"), "name": "CUSTOMERS", "kind": "table", "route": "lift",
         "reason": "data is copied by ingestX", "ingestx": {"state": "draft"}, "target": "main.x.customers",
         "inputs": [], "outputs": []},
        {"asset_id": STREAM, "name": "ORDERS_STREAM", "kind": "stream", "route": "absorbed", "reason": "absorbed",
         "inputs": [], "outputs": []},
    ]
    gov = [{"id": POLICY, "name": "SALES_DB.GOV.EMAIL_MASK", "kind": "masking", "dataset_id": oid("CORE", "CUSTOMERS"),
            "column": "EMAIL", "table": "main.x.customers", "body_available": True}]
    rep = run(tmp_path, etls=[(1, *view[:4], {"inputs": view[4]["inputs"]})], file_loads=["ORDERS_PIPE"], other=other,
              governance=gov)
    rows = by_asset(rep)
    assert rows[oid("CORE", "V_ORDER_NET")]["route"] == "rebuild"
    assert rows[PIPE]["route"] == "file_load"
    assert rows[oid("CORE", "CUSTOMERS")]["status"] == "lifted" and rows[oid("CORE", "CUSTOMERS")]["ingestx"]
    assert rows[STREAM]["route"] == "absorbed" and rows[STREAM]["status"] == "absorbed"
    assert rows[POLICY]["route"] == "governance" and rows[POLICY]["status"] == "proposed"       # ADR 034
    assert len(rep["rows"]) == 5 and {r["route"] for r in rep["rows"]} == {
        "rebuild", "file_load", "lift", "absorbed", "governance"}
    # units: the view, the pipe and ONE governance unit; counts and summary agree
    assert rep["summary"]["units_total"] == 3
    assert rep["summary"]["by_route"] == {"absorbed": 1, "file_load": 1, "governance": 1, "lift": 1, "rebuild": 1}
    assert rep["summary"]["status"] == "needs_review"                       # the pipe waits for review
    assert {n["id"] for n in rep["lineage"]["nodes"]} >= {oid("CORE", "V_ORDER_NET"), PIPE, oid("CORE", "ORDERS")}
    assert {"from": oid("CORE", "ORDERS"), "to": oid("CORE", "V_ORDER_NET")} in rep["lineage"]["edges"]
    assert rep["etls"][-1]["etl_id"] == "__governance__"
    assert rep["etls"][-1]["status"] == "proposed" and "access framework" in rep["etls"][-1]["reason"]
    assert rep["counts"]["proposed"] == 1 and rep["counts"]["unsupported"] == 0      # proposed is not an issue


def test_a_rebuilt_dataset_mirrors_its_producer_unit(tmp_path):
    mirror = [{"asset_id": oid("ANALYTICS", "V_ORDER_NET_T"), "name": "V_ORDER_NET", "kind": "table", "route": "rebuild",
               "reason": "output of V_ORDER_NET", "produced_by": oid("CORE", "V_ORDER_NET"), "inputs": [], "outputs": []}]
    rep = run(tmp_path, etls=[(1, "V_ORDER_NET", "CORE", "sql_view", "SELECT 1 AS A", {})], other=mirror)
    rows = by_asset(rep)
    assert rows[oid("ANALYTICS", "V_ORDER_NET_T")]["status"] == rows[oid("CORE", "V_ORDER_NET")]["status"]
    assert rows[oid("ANALYTICS", "V_ORDER_NET_T")]["unit_id"] is None          # not a unit of its own
    assert rows[oid("ANALYTICS", "V_ORDER_NET_T")]["produced_by"] == oid("CORE", "V_ORDER_NET")
    assert sum(rep["summary"]["by_status"].values()) == rep["summary"]["units_total"] == sum(rep["counts"].values())


def test_everything_lifted_or_retired_is_nothing_to_build(tmp_path):
    other = [{"asset_id": oid("CORE", "ORDERS"), "name": "ORDERS", "kind": "table", "route": "lift", "reason": "lift",
              "ingestx": {"state": "not_configured"}, "inputs": [], "outputs": []},
             {"asset_id": oid("CORE", "OLD"), "name": "OLD", "kind": "table", "route": "retire", "reason": "dead",
              "inputs": [], "outputs": []}]
    rep = run(tmp_path, other=other, excluded=[{"etl_id": "x", "asset_id": oid("CORE", "V_OLD"), "name": "V_OLD",
                                                "disposition": "retire"}])
    assert rep["summary"] == {"status": "nothing_to_build", "units_total": 0,
                              "by_route": {"lift": 1, "retire": 2}, "by_status": {"lifted": 1, "retired": 2}}
    assert rep["etls"] == [] and rep["counts"]["failed"] == 0
    assert rep["lineage"]["nodes"]


def test_delete_endpoints_remove_a_batch_and_a_run(tmp_path):
    rep = run(tmp_path, etls=[(1, "V_ORDER_NET", "CORE", "sql_view", "SELECT 1 AS A", {})], file_loads=["ORDERS_PIPE"])
    vol, work = tmp_path / "vol", tmp_path / "work"
    store = LocalStore(REPO, work=work, volume=vol, samples=tmp_path / "none")
    app.dependency_overrides[get_store] = lambda: store
    try:
        c = TestClient(app)
        dirs = [pathlib.Path(r["run_dir"]) for r in rep["etls"] if r.get("run_dir")]
        assert len(dirs) == 2 and all(d.is_dir() for d in dirs)
        gone = c.delete(f"/api/runs/{dirs[0].name}")
        assert gone.status_code == 200 and gone.json()["counts"]["run_dirs"] == 1 and not dirs[0].exists()
        assert c.delete(f"/api/runs/{dirs[0].name}").status_code == 404
        done = c.delete(f"/api/batches/{rep['batch_run_id']}")
        assert done.status_code == 200 and done.json()["counts"]["reports"] == 1
        assert not pathlib.Path(rep["report_path"]).exists() and not dirs[1].exists()
        assert c.delete(f"/api/batches/{rep['batch_run_id']}").status_code == 404
        assert c.delete("/api/runs/..%2Fx").status_code in (404, 405)
        assert c.delete("/api/runs/x", headers={"X-Srcintel-User-Roles": "viewer"}).status_code == 403
    finally:
        app.dependency_overrides.clear()


@pytest.mark.parametrize("counts,total,status", [
    ({}, 0, "nothing_to_build"), ({"awaiting_review": 1}, 2, "needs_review"),
    ({"migrated": 2}, 2, "completed"), ({"migrated": 1, "blocked": 1}, 2, "completed_with_issues")])
def test_rollup(counts, total, status):
    from scripts.run_batch import rollup
    assert rollup(counts, total) == status


def test_a_batch_with_only_proposed_governance_is_completed_not_an_issue(tmp_path):
    gov = [{"id": POLICY, "name": "SALES_DB.GOV.EMAIL_MASK", "kind": "masking", "dataset_id": oid("CORE", "CUSTOMERS"),
            "column": "EMAIL", "table": "main.x.customers", "body_available": True}]
    rep = run(tmp_path, governance=gov)
    assert rep["summary"]["units_total"] == 1 and rep["summary"]["by_status"] == {"proposed": 1}
    assert rep["summary"]["status"] == "completed"
