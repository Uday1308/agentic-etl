"""migrator-experience 9.1: translation actually happens. The AI tier's translator comes from configuration
(serving | scripted | off), tier 0 handles ``CALL`` task bodies and plain-DML procedures, and a review whose units hold no
code is not approvable as it stands (edits become a ``manual`` artifact on resume; out of scope ends ``unsupported``).

The bundle mirrors the 7 SALES_DB.CORE objects of tests/fixtures/snowflake in the raw SQL API partition shape.
Offline: scripted / fake translators only (hard rule 10)."""
from __future__ import annotations

import asyncio
import json
import pathlib

import pytest
from fastapi.testclient import TestClient

from agents.cd_codegen.translate.artifacts import read_artifact
from api.app import app, get_store
from api.store_local import LocalStore
from core.domo.llm import RawCompletion
from packs.snowflake import contract as ct
from packs.snowflake.llm import (
    FIXTURE_ANSWERS,
    LlmChoice,
    ServingTranslator,
    choose_llm,
    mask_for_prompt,
    restore_literals,
    serving_translator,
)
from scripts.run_batch import run_batch

ACCT = "acme-prod"
CORE = f"{ACCT}.SALES_DB.CORE"


def part(cols: list[str], rows: list[list]) -> dict:
    return {"rowType": [{"name": c} for c in cols], "data": rows}


PROC_COLS = ["PROCEDURE_ID", "PROCEDURE_CATALOG", "PROCEDURE_SCHEMA", "PROCEDURE_NAME", "ARGUMENT_SIGNATURE",
             "DATA_TYPE", "PROCEDURE_LANGUAGE", "PROCEDURE_DEFINITION"]
TASK_COLS = ["ROOT_TASK_ID", "NAME", "ID", "DATABASE_NAME", "SCHEMA_NAME", "SCHEDULE", "PREDECESSORS", "STATE",
             "DEFINITION", "CONDITION_TEXT", "TASK_RELATIONS"]
FUNC_COLS = ["FUNCTION_ID", "FUNCTION_CATALOG", "FUNCTION_SCHEMA", "FUNCTION_NAME", "ARGUMENT_SIGNATURE", "DATA_TYPE",
             "FUNCTION_LANGUAGE", "FUNCTION_DEFINITION"]

LOAD = ("BEGIN\n  INSERT INTO SALES_DB.CORE.PRODUCTS (PRODUCT_ID, COST)\n    SELECT PRODUCT_ID, COST FROM "
        "SALES_DB.RAW.PRODUCTS_RAW{limit};\n  RETURN 'loaded';\nEND;")
MERGE = ("MERGE INTO SALES_DB.CORE.ORDERS t\nUSING (SELECT ORDER_ID, AMOUNT FROM SALES_DB.RAW.ORDERS_RAW_STREAM WHERE "
         "METADATA$ACTION = 'INSERT') s\nON t.ORDER_ID = s.ORDER_ID\nWHEN MATCHED THEN UPDATE SET t.AMOUNT = s.AMOUNT")
NOTIFY = ("BEGIN\n  CALL SYSTEM$SEND_EMAIL('NOTIFY_INT', 'someone@example.invalid', 'Daily load finished', 'done');\n"
          "  RETURN 'sent';\nEND;")
PROCS = part(PROC_COLS, [
    ["1", "SALES_DB", "CORE", "LOAD_PRODUCTS", "(P_MODE VARCHAR)", "VARCHAR", "SQL", LOAD.format(limit="")],
    ["2", "SALES_DB", "CORE", "LOAD_PRODUCTS", "(P_MODE VARCHAR, P_LIMIT NUMBER)", "VARCHAR", "SQL",
     LOAD.format(limit=" WHERE COST > 0").replace("INSERT INTO", "INSERT /* two args */ INTO")],
    ["3", "SALES_DB", "CORE", "NOTIFY_DONE", "()", "VARCHAR", "SQL", NOTIFY]])
TASKS = part(TASK_COLS, [
    ["r", "ROOT_DAILY", "1", "SALES_DB", "CORE", "USING CRON 0 5 * * * UTC", "[]", "started",
     "CALL SALES_DB.CORE.LOAD_PRODUCTS('full')", None, '{"Predecessors": [], "FinalizerTask": "SALES_DB.CORE.NOTIFY_FINALIZER"}'],
    ["r", "MERGE_ORDERS", "2", "SALES_DB", "CORE", None, '["SALES_DB.CORE.ROOT_DAILY"]', "started", MERGE, None,
     '{"Predecessors": ["SALES_DB.CORE.ROOT_DAILY"]}'],
    ["r", "NOTIFY_FINALIZER", "3", "SALES_DB", "CORE", None, "[]", "started", "CALL SALES_DB.CORE.NOTIFY_DONE()", None,
     '{"Predecessors": [], "FinalizedRootTask": "SALES_DB.CORE.ROOT_DAILY"}']])
FUNCS = part(FUNC_COLS, [["9", "SALES_DB", "CORE", "UDF_NET_AMOUNT", "(AMOUNT NUMBER, DISCOUNT NUMBER)", "NUMBER(38,2)",
                          "SQL", "AMOUNT - COALESCE(DISCOUNT, 0)"]])


def make_core_bundle(root: pathlib.Path) -> pathlib.Path:
    b = root / "bundle"
    (b / "etls").mkdir(parents=True)

    def tbl(schema: str, name: str) -> dict:
        return {"dataset_id": f"snowflake:dataset:{ACCT}.SALES_DB.{schema}.{name}", "name": f"SALES_DB.{schema}.{name}",
                "table": f"main.sfdemo_{schema.lower()}.{name.lower()}"}

    spec = [  # order, name, id suffix, engine, partition, inputs, outputs
        (1, "UDF_NET_AMOUNT", "func/UDF_NET_AMOUNT(NUMBER,NUMBER)", "udf_sql", FUNCS, [], []),
        (2, "LOAD_PRODUCTS2", "proc/LOAD_PRODUCTS(VARCHAR,NUMBER)", "sql_procedure", PROCS,
         [tbl("RAW", "PRODUCTS_RAW")], [tbl("CORE", "PRODUCTS")]),
        (3, "ROOT_DAILY", "task/ROOT_DAILY", "task", TASKS, [], []),
        (4, "LOAD_PRODUCTS1", "proc/LOAD_PRODUCTS(VARCHAR)", "sql_procedure", PROCS,
         [tbl("RAW", "PRODUCTS_RAW")], [tbl("CORE", "PRODUCTS")]),
        (5, "MERGE_ORDERS", "task/MERGE_ORDERS", "task", TASKS, [tbl("RAW", "ORDERS_RAW")], [tbl("CORE", "ORDERS")]),
        (6, "NOTIFY_FINALIZER", "task/NOTIFY_FINALIZER", "task", TASKS, [], []),
        (7, "NOTIFY_DONE", "proc/NOTIFY_DONE()", "sql_procedure", PROCS, [], [])]
    etls = []
    for order, name, suffix, engine, partition, ins, outs in spec:
        etl_id = f"{CORE}.{suffix}"
        (b / "etls" / f"{name}.json").write_text(json.dumps(partition), encoding="utf-8")
        etls.append({"order": order, "etl_id": etl_id, "asset_id": f"snowflake:transform:{etl_id}",
                     "name": f"SALES_DB.CORE.{suffix.split('/')[1]}", "engine": engine, "etl_key": f"sfdemo__{name}",
                     "definition": f"etls/{name}.json", "inputs": ins, "outputs": outs, "batch_id": "w1",
                     "depends_on_etls": ([] if name in ("UDF_NET_AMOUNT", "LOAD_PRODUCTS2", "ROOT_DAILY") else
                                         [f"{CORE}.task/ROOT_DAILY"])})
    manifest = {
        "manifest_version": "2", "kind": "etl_logic_migration", "snapshot_id": "sf-core", "strategy": "dependency_waves",
        "strategy_label": "Dependency waves", "selection": {"key": "w1-core-1", "wave": 1, "batch_ids": ["w1"]},
        "source": {"id": "sfdemo", "key": "sfdemo", "platform": "snowflake", "dialect": "snowflake"},
        "target": {"target_catalog": "main"}, "etls": etls, "file_loads": [], "read_statements": [], "table_map": {},
        "target_map": {}, "governance": [], "notes": []}
    (b / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return b


@pytest.fixture(autouse=True)
def clean_llm_env(monkeypatch):
    for k in ("MIGRATOR_LLM", "MIGRATOR_LLM_ENDPOINT", "SRCINTEL__LLM__PROVIDER", "SRCINTEL__LLM__ENDPOINT",
              "SRCINTEL_ENV"):
        monkeypatch.delenv(k, raising=False)


def go(tmp_path, mode: str, **kw) -> tuple[dict, pathlib.Path]:
    import os

    os.environ["MIGRATOR_LLM"] = mode
    try:
        b = make_core_bundle(tmp_path)
        return asyncio.run(run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work", **kw)), b
    finally:
        os.environ.pop("MIGRATOR_LLM", None)


def by_name(rep: dict) -> dict:
    """Rows by object name; overloads keep their signature (``LOAD_PRODUCTS(VARCHAR)``)."""
    return {(n.split("(")[0] if n.count("(") and "LOAD_PRODUCTS" not in n else n): r
            for r in rep["etls"] for n in [r["name"].split(".")[-1]]}


def run_json(row: dict) -> dict:
    return json.loads((pathlib.Path(row["run_dir"]) / "run.json").read_text(encoding="utf-8"))


# ------------------------------------------------------------------------------------------------ config
def test_choose_llm_matrix(tmp_path):
    cfg = tmp_path / "config"
    cfg.mkdir()
    (cfg / "local.yaml").write_text("llm:\n  provider: fake\n  endpoint: from-yaml\n", encoding="utf-8")
    (cfg / "databricks.yaml").write_text("llm:\n  provider: databricks_serving\n  endpoint: db-endpoint\n",
                                         encoding="utf-8")
    base = {"SRCINTEL_CONFIG_DIR": str(cfg)}
    assert choose_llm(base).mode == "scripted"                                                   # local + fake
    assert choose_llm({**base, "SRCINTEL_ENV": "databricks"}) == LlmChoice("serving", "db-endpoint",
                                                                          "llm.provider=databricks_serving")
    assert choose_llm({**base, "SRCINTEL__LLM__PROVIDER": "databricks_serving"}).endpoint == "from-yaml"
    assert choose_llm({**base, "SRCINTEL__LLM__PROVIDER": "databricks_serving",
                       "SRCINTEL__LLM__ENDPOINT": "env-endpoint"}).endpoint == "env-endpoint"
    assert choose_llm({**base, "MIGRATOR_LLM": "off"}).mode == "off"
    assert choose_llm({**base, "MIGRATOR_LLM": "serving", "MIGRATOR_LLM_ENDPOINT": "e"}) == LlmChoice(
        "serving", "e", "MIGRATOR_LLM")
    assert choose_llm({**base, "SRCINTEL__LLM__PROVIDER": "anthropic"}).mode == "off"            # unsupported: said why
    assert "not supported" in choose_llm({**base, "SRCINTEL__LLM__PROVIDER": "anthropic"}).reason
    assert choose_llm({**base, "MIGRATOR_LLM": "bogus"}).mode == "off"
    # fake on a Databricks deployment never silently runs canned answers
    (cfg / "databricks.yaml").write_text("llm:\n  provider: fake\n", encoding="utf-8")
    assert choose_llm({**base, "SRCINTEL_ENV": "databricks"}).mode == "off"


def test_prompt_literals_are_masked_and_restored():
    masked, lits = mask_for_prompt("SELECT 'a@example.invalid', 'it''s' FROM t WHERE x = 'y'")
    assert "example.invalid" not in masked and masked.count("<<L") == 3 and len(lits) == 3
    assert restore_literals("SELECT '<<L1>>', '<<L2>>', '<<L9>>'", lits) == \
        "SELECT 'a@example.invalid', 'it''s', '<<L9>>'"


def test_serving_translator_goes_through_llmclient_and_restores_literals():
    seen: list[str] = []

    def caller(spec, prompt, schema, timeout):
        seen.append(prompt)
        assert spec.endpoint == "my-endpoint"
        if "NEVER" in prompt:
            return RawCompletion(text="```sql\n-- CANNOT TRANSLATE: no equivalent\n```")
        return RawCompletion(text="```sql\nINSERT INTO t SELECT '<<L1>>'\n```")

    tr = serving_translator(LlmChoice("serving", "my-endpoint"), {}, caller=caller)
    assert isinstance(tr, ServingTranslator)
    build = type("B", (), {"unresolved": [
        {"step": "u1", "source_text": "INSERT INTO t SELECT 'secret@example.invalid'", "engine": "sql_procedure"},
        {"step": "u2", "source_text": "SELECT NEVER()", "engine": "task"}]})()
    got = asyncio.run(tr.resolve_tail(build))
    assert got["u1"].usable and got["u1"].sql == "INSERT INTO t SELECT 'secret@example.invalid'"
    assert not got["u2"].usable and "no equivalent" in got["u2"].why_not
    assert all("secret@example.invalid" not in p for p in seen)                   # the prompt never carried the literal


# ------------------------------------------------------------------------------------------------ tier 0
def test_call_and_execute_task_are_deterministic():
    from packs.snowflake import translate as tr

    ctx = tr.make_context(etl_key="k", engine="task", table_map={}, default_db="SALES_DB", default_schema="CORE")
    call = tr.tier0_call("CALL core.load_products('full', 3)", ctx)
    assert call == {"db": "SALES_DB", "schema": "CORE", "name": "LOAD_PRODUCTS", "args": ["'full'", "3"],
                    "target": "main.sales_db_core.load_products"}
    assert tr.tier0_call("CALL SYSTEM$SEND_EMAIL('a')", ctx) is None                # system procedures have no tier 0
    assert tr.tier0_call("SELECT 1", ctx) is None
    assert tr.tier0_execute_task("EXECUTE TASK SALES_DB.CORE.OTHER;", ctx)["name"] == "OTHER"


def test_pick_row_reads_task_columns_and_overloads():
    t = ct.pick_row(TASKS, f"snowflake:transform:{CORE}.task/MERGE_ORDERS")
    assert t["NAME"] == "MERGE_ORDERS"
    one = ct.pick_row(PROCS, f"{CORE}.proc/LOAD_PRODUCTS(VARCHAR)")
    two = ct.pick_row(PROCS, f"{CORE}.proc/LOAD_PRODUCTS(VARCHAR,NUMBER)")
    assert one["ARGUMENT_SIGNATURE"] == "(P_MODE VARCHAR)" and two["ARGUMENT_SIGNATURE"].endswith("P_LIMIT NUMBER)")


# ------------------------------------------------------------------------------------------------ the batch
def test_scripted_batch_translates_the_seven_core_units(tmp_path):
    rep, _ = go(tmp_path, "scripted")
    rows = by_name(rep)
    assert rep["translation"]["llm"] == "scripted" and rep["translation"]["llm_detail"]["mode"] == "scripted"
    assert rep["counts"]["failed"] == 0 and rep["counts"]["blocked"] == 0 and len(rows) == 7
    for name, row in rows.items():
        rj = run_json(row)
        assert rj["llm"] == "scripted"
        assert all(u["status"] == "resolved" and not u["no_code"] for u in rj["units"]), name
    # task bodies that are a CALL: tier 0, no AI, a job task that runs the procedure's notebook with the args
    for name in ("ROOT_DAILY", "NOTIFY_FINALIZER"):
        assert rows[name]["status"] == "migrated" and {u["origin"] for u in run_json(rows[name])["units"]} == {"mapped"}
    for name in ("LOAD_PRODUCTS(VARCHAR)", "LOAD_PRODUCTS(VARCHAR,NUMBER)", "UDF_NET_AMOUNT"):
        assert {u["origin"] for u in run_json(rows[name])["units"]} == {"mapped"}
    # the stream consumer is a tier 0 rule (change data feed), held for review; the AI unit stays inferred
    merge = run_json(rows["MERGE_ORDERS"])["units"][0]
    assert rows["MERGE_ORDERS"]["status"] == "awaiting_review" and merge["origin"] == "mapped"
    assert "SNW-STREAM-CDF" in merge["review_caveats"]
    assert rows["NOTIFY_DONE"]["status"] == "awaiting_review"
    assert {(u["origin"], u["state"]) for u in run_json(rows["NOTIFY_DONE"])["units"]} == {("ai", "inferred")}
    job = json.loads(next(pathlib.Path(rep["assembly"]["path"]).glob("jobs/*.json")).read_text(encoding="utf-8"))
    tasks = {t["task_key"]: t for t in job["tasks"]}
    assert tasks["root_daily"]["notebook_task"]["notebook_path"].endswith("/main/sales_db_core/load_products")
    assert tasks["root_daily"]["notebook_task"]["base_parameters"] == {"arg1": "full"}
    assert tasks["notify_finalizer"]["run_if"] == "ALL_DONE" and "sql_task" in tasks["merge_orders"]
    assert "MERGE INTO" in FIXTURE_ANSWERS["merge into sales_db.core.orders"][0]


def test_off_mode_leaves_units_without_code_and_says_so(tmp_path):
    rep, _ = go(tmp_path, "off")
    assert rep["translation"]["llm"] == "off"
    merge = by_name(rep)["NOTIFY_DONE"]
    assert merge["status"] == "awaiting_review" and run_json(merge)["llm"] == "off"
    unit = run_json(merge)["units"][0]
    assert unit["status"] == "awaiting_review" and unit["no_code"] is True
    gate = json.loads(next((pathlib.Path(merge["run_dir"]) / "gates").glob("gate-translation-*.json")).read_text("utf-8"))
    assert gate["no_code_unit_ids"] == [unit["unit_id"]] and gate["artifact"]["units"][0]["no_code"] is True


# ------------------------------------------------------------------------------------------------ honest reviews
@pytest.fixture
def review(tmp_path):
    """An ``off`` batch with its API store: NOTIFY_DONE holds a translation gate with one no_code unit."""
    rep, bundle = go(tmp_path, "off")
    store = LocalStore(tmp_path, work=tmp_path / "work" / ".platform_local", volume=tmp_path / "vol")
    app.dependency_overrides[get_store] = lambda: store
    merge = by_name(rep)["NOTIFY_DONE"]
    gate = next(h for h in run_json(merge)["held"] if h["agent"] == "translation")
    unit_id = run_json(merge)["units"][0]["unit_id"]
    yield TestClient(app), rep, bundle, merge, gate["gate_id"], unit_id, tmp_path
    app.dependency_overrides.clear()


def feedback(client, gate_id, **kw):
    return client.post(f"/api/gates/{gate_id}/feedback", json={"actor": "lead@example.invalid", **kw})


def resume(tmp_path, bundle, rep):
    import os

    os.environ["MIGRATOR_LLM"] = "off"
    try:
        return asyncio.run(run_batch(bundle, volume=tmp_path / "vol", work=tmp_path / "work",
                                     resume=rep["batch_run_id"]))
    finally:
        os.environ.pop("MIGRATOR_LLM", None)


def test_gate_api_exposes_no_code_and_refuses_approval_without_code(review):
    client, _, _, _, gate_id, unit_id, _ = review
    g = client.get(f"/api/gates/{gate_id}").json()
    assert g["no_code_unit_ids"] == [unit_id] and g["artifact"]["units"][0]["no_code"] is True
    r = feedback(client, gate_id, approve=True)
    assert r.status_code == 422 and unit_id in r.json()["detail"] and "no translated code" in r.json()["detail"]
    assert feedback(client, gate_id, approve=True, edits={unit_id: "   "}).status_code == 422
    assert feedback(client, gate_id, approve=True, edits={"not-a-unit": "SELECT 1"}).status_code == 422
    assert feedback(client, gate_id, approve=False, freeform="needs code").status_code == 200   # sending back is fine


def test_edits_become_a_manual_validated_artifact_on_resume(review):
    client, rep, bundle, merge, gate_id, unit_id, tmp_path = review
    code = ("MERGE INTO main.sfdemo_core.orders t USING main.sfdemo_core.orders s ON t.order_id = s.order_id "
            "WHEN MATCHED THEN UPDATE SET t.amount = s.amount")
    assert feedback(client, gate_id, approve=True, edits={unit_id: code}).status_code == 200
    approval = json.loads((tmp_path / "work" / ".platform_local" / "feedback" / f"{gate_id}.approval.json").read_text())
    assert set(approval["edits"]) == {unit_id} and code not in json.dumps(approval)          # by hash, never inline
    assert read_artifact(tmp_path / "vol", approval["edits"][unit_id]["artifact_ref"]) == code
    row = by_name(resume(tmp_path, bundle, rep))["NOTIFY_DONE"]
    unit = run_json(row)["units"][0]
    assert unit["origin"] == "manual" and unit["status"] == "resolved" and unit["edited"] and not unit["no_code"]
    assert row["status"] == "awaiting_review"                      # a manual artifact is itself reviewed (sql gate)
    held = [h["agent"] for h in run_json(row)["held"]]
    assert held == ["cd_codegen"]                                  # the translation gate was reused, not re-opened
    gate = json.loads(next((pathlib.Path(row["run_dir"]) / "gates").glob("gate-cd_codegen-*.json")).read_text("utf-8"))
    art = gate["artifact"]["artifacts"][0]
    assert art["origin"] == "manual" and code in read_artifact(tmp_path / "vol", art["artifact_ref"])


def test_an_edit_that_does_not_validate_stays_unresolved(review):
    client, rep, bundle, merge, gate_id, unit_id, tmp_path = review
    assert feedback(client, gate_id, approve=True, edits={unit_id: "MERGE INTO ((("}).status_code == 200
    row = by_name(resume(tmp_path, bundle, rep))["NOTIFY_DONE"]
    unit = run_json(row)["units"][0]
    assert unit["status"] == "awaiting_review" and unit["no_code"] and "does not validate" in " ".join(unit["reasons"])
    assert row["status"] == "awaiting_review"


def test_out_of_scope_ends_the_unit_unsupported_with_the_reason(review):
    client, rep, bundle, merge, gate_id, unit_id, tmp_path = review
    r = feedback(client, gate_id, approve=True, out_of_scope_unit_ids=[unit_id],
                 out_of_scope_reasons={unit_id: "stream consumer is retired"})
    assert r.status_code == 200
    row = by_name(resume(tmp_path, bundle, rep))["NOTIFY_DONE"]
    assert row["status"] == "unsupported" and "stream consumer is retired" in row["reason"]
    assert run_json(row)["units"][0]["status"] == "unsupported"


# ------------------------------------------------------------------------------------------------ stream rule
def test_stream_consumer_is_tier_zero_change_data_feed(tmp_path):
    """MERGE ... USING (... FROM <stream> WHERE METADATA$ACTION = 'INSERT') needs no AI: table_changes + _change_type."""
    rep, _ = go(tmp_path, "off")                 # AI off: the rule alone must produce the code
    row = by_name(rep)["MERGE_ORDERS"]
    unit = run_json(row)["units"][0]
    assert unit["origin"] == "mapped" and unit["status"] == "resolved" and not unit["no_code"]
    assert unit["review_caveats"] == ["SNW-STREAM-CDF"]
    gate = json.loads(next((pathlib.Path(row["run_dir"]) / "gates").glob("gate-cd_codegen-*.json")).read_text("utf-8"))
    art = gate["artifact"]["artifacts"][0]
    text = read_artifact(tmp_path / "vol", art["artifact_ref"])
    assert "TABLE_CHANGES('main.sfdemo_raw.orders_raw', :start_version)" in text
    assert "_change_type IN ('insert', 'update_postimage')" in text and "METADATA$" not in text
    assert any("enable delta.enableChangeDataFeed on main.sfdemo_raw.orders_raw" in r for r in art["review_reasons"])
    job = json.loads(next(pathlib.Path(rep["assembly"]["path"]).glob("jobs/*.json")).read_text(encoding="utf-8"))
    merge_task = next(t for t in job["tasks"] if t["task_key"] == "merge_orders")
    assert merge_task["sql_task"]["parameters"] == {"start_version": "0"}


def test_stream_metadata_mapping_table():
    from packs.snowflake import translate as tr

    ctx = tr.make_context(etl_key="k", engine="task", default_db="SALES_DB", default_schema="CORE",
                          table_map={("SALES_DB", "RAW", "ORDERS_RAW"): "main.r.orders_raw"})

    def sql(where: str) -> str:
        q = f"SELECT * FROM SALES_DB.RAW.ORDERS_RAW_STREAM WHERE {where}"
        res, item = tr.tier0_unit(tr.PreUnit("u", {"sql": q, "language": "sql"}, "task"), ctx)
        assert item is None, item
        return res.sql.split("WHERE ")[1]

    assert sql("METADATA$ACTION = 'INSERT' AND NOT METADATA$ISUPDATE") == "_change_type = 'insert'"
    assert sql("METADATA$ACTION = 'INSERT' AND METADATA$ISUPDATE") == "_change_type = 'update_postimage'"
    assert sql("METADATA$ACTION = 'DELETE' AND METADATA$ISUPDATE = FALSE") == "_change_type = 'delete'"
    assert sql("METADATA$ACTION = 'DELETE'") == "_change_type IN ('delete', 'update_preimage')"
    for bad in ("SELECT METADATA$ROW_ID FROM SALES_DB.RAW.ORDERS_RAW_STREAM",
                "SELECT METADATA$ACTION FROM SALES_DB.RAW.ORDERS_RAW_STREAM"):
        _, item = tr.tier0_unit(tr.PreUnit("u", {"sql": bad, "language": "sql"}, "task"), ctx)
        assert item is not None and "no deterministic rule" in item["reasons"][0]


def test_a_partial_stream_rewrite_is_offered_as_suggested_code():
    from packs.snowflake import translate as tr

    ctx = tr.make_context(etl_key="k", engine="task", default_db="SALES_DB", default_schema="CORE",
                          table_map={("SALES_DB", "RAW", "ORDERS_RAW"): "main.r.orders_raw"})
    q = ("SELECT * FROM SALES_DB.RAW.ORDERS_RAW_STREAM s JOIN OTHER.X.UNKNOWN u ON 1 = 1 "
         "WHERE METADATA$ACTION = 'INSERT'")
    res, item = tr.tier0_unit(tr.PreUnit("u", {"sql": q, "language": "sql"}, "task"), ctx)
    assert item is not None and "unmapped reference" in item["reasons"][0]
    assert "table_changes('main.r.orders_raw', :start_version)" in res.suggested_code.lower().replace(
        "table_changes", "table_changes")
