# Ported (anonymized) from SNF2DBX-main/tests/test_equivalence*.py (LatentView internal), adapted to the pack's
# query-shaped units and the ConversionContext's column catalogue.
"""S5 (ADR 037 section 2): the equivalence checker. Structural cases run everywhere; the sample-data execution needs
``duckdb`` (absent from the migrator venv: those tests skip, and the not_checkable path is tested instead)."""
from __future__ import annotations

import asyncio
import importlib.util

import pytest

from packs.snowflake import equivalence as eqv
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.postpass import PostpassContext

HAS_DUCKDB = importlib.util.find_spec("duckdb") is not None
NAMES = PostpassContext(table_map={("DB", "S", "ORDERS"): "main.s.orders"}, default_db="DB", default_schema="S")
COLS = {"main.s.orders": {"id": "NUMBER(38,0)", "amount": "NUMBER(10,2)", "status": "VARCHAR", "d": "DATE"}}
CONV = ConversionContext.build(catalogue=COLS)


def check(src, out, ids=(), conv=CONV, **kw):
    return eqv.check(src, out, names=NAMES, conversion=conv, caveat_ids=set(ids), **kw)


# ------------------------------------------------------------------------------------------------ structural
def test_identical_canonical_trees_are_equivalent():
    v = check("SELECT id, IFF(amount > 100, 'big', 'small') AS size FROM orders",
              "SELECT id, IF(amount > 100, 'big', 'small') AS size FROM main.s.orders")
    assert (v.status, v.structure) == (eqv.EQUIVALENT, "same")


def test_spelling_differences_the_canonical_form_removes():
    assert check("SELECT status, COUNT(*) AS c FROM orders GROUP BY 1",
                 "SELECT status, COUNT(*) AS c FROM main.s.orders GROUP BY status").status == eqv.EQUIVALENT
    assert check("SELECT (id) AS i FROM orders WHERE (amount > 1)",
                 "SELECT id AS i FROM main.s.orders WHERE amount > 1").status == eqv.EQUIVALENT


def test_a_difference_a_unit_declared_is_explained():
    v = check("SELECT id, DATEADD(day, 1, d) AS n FROM orders", "SELECT id, d + INTERVAL '1' DAY AS n FROM main.s.orders",
              ids={"SNW-DATEADD"})
    assert v.status in (eqv.EXPLAINED, eqv.EQUIVALENT)


def test_a_difference_nothing_explains_is_not_checkable_without_a_sample():
    """Structure differs, no rule explains it and the sample cannot run: said so, not guessed (no review noise)."""
    v = check("SELECT a FROM orders", "SELECT b FROM main.s.orders", conv=ConversionContext.build())
    assert v.status == eqv.NOT_CHECKABLE and v.structure == "differs"
    assert any("catalogue" in x or "described" in x for x in v.detail + [v.sample])


@pytest.mark.parametrize("src", [
    "SELECT payload:a::string AS a FROM orders",                 # semi-structured path
    "SELECT f.value FROM orders, LATERAL FLATTEN(input => x) f",
    "SELECT $1 FROM orders",
    "SELECT * FROM orders AT(TIMESTAMP => '2024-01-01'::timestamp)",
    "SELECT RANDOM() FROM orders",
    "SELECT HASH(id) FROM orders",
])
def test_constructs_duckdb_does_not_share_are_not_checkable(src):
    v = check(src, "SELECT 1 FROM main.s.orders")
    assert v.status == eqv.NOT_CHECKABLE and "DuckDB does not share" in v.detail[0]


def test_an_escalated_unit_and_unparsable_text_are_not_checkable():
    assert check("SELECT 1 FROM orders", "SELECT 1 FROM main.s.orders", escalated=True).status == eqv.NOT_CHECKABLE
    assert check("SELECT 1 FROM orders", "CALL p()").status == eqv.NOT_CHECKABLE
    assert check("SELECT 1 FROM unmapped_table", "SELECT 1 FROM main.s.orders").status == eqv.NOT_CHECKABLE


def test_the_verdict_record_carries_no_source_text_and_no_literals():
    v = check("SELECT id FROM orders WHERE status = 'SECRET_LITERAL'",
              "SELECT id FROM main.s.orders WHERE status = 'OTHER_LITERAL'", conv=ConversionContext.build())
    blob = repr(v.record())
    assert "SECRET_LITERAL" not in blob and "OTHER_LITERAL" not in blob


def test_describe_diff_names_shapes_not_values():
    import sqlglot
    a = sqlglot.parse_one("SELECT a FROM t WHERE x > 1", read="duckdb")
    b = sqlglot.parse_one("SELECT a FROM t WHERE x >= 7", read="duckdb")
    assert all("7" not in d for d in eqv.describe_diff(a, b))


# ------------------------------------------------------------------------------------------------ sample data
needs_duckdb = pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb is not installed in this environment")


@needs_duckdb
def test_same_results_on_sample_data_prove_equivalence_despite_a_different_shape():
    v = check("SELECT id, ZEROIFNULL(amount) AS a FROM orders", "SELECT id, COALESCE(amount, 0) AS a FROM main.s.orders")
    assert v.status == eqv.EQUIVALENT and v.sample == "match"


@needs_duckdb
def test_a_wrong_conversion_differs_on_sample_data_and_no_rule_explains_it():
    v = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1")
    assert v.status == eqv.UNEXPLAINED and v.sample == "differ"


@needs_duckdb
def test_a_standard_rewrite_never_explains_a_difference_in_the_rows():
    """NULLS FIRST is a standard rewrite for the structure; if the ROWS still differ, it is not an explanation."""
    v = check("SELECT id FROM orders QUALIFY ROW_NUMBER() OVER (PARTITION BY status ORDER BY id) = 1",
              "SELECT id FROM main.s.orders QUALIFY ROW_NUMBER() OVER (PARTITION BY status ORDER BY id NULLS FIRST) = 1")
    assert v.status == eqv.UNEXPLAINED


@needs_duckdb
def test_a_declared_rewrite_that_changes_the_rows_is_explained():
    v = check("SELECT id, ROUND(amount) AS r FROM orders", "SELECT id, CAST(ROUND(amount) AS DOUBLE) AS r FROM main.s.orders",
              ids={"SNW-ROUND-FLOAT", "SNW-IMPLICIT-CAST"})
    assert v.status in (eqv.EQUIVALENT, eqv.EXPLAINED)


@needs_duckdb
def test_the_sample_is_seeded_so_the_verdict_is_reproducible():
    a = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1")
    b = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1")
    assert a.record() == b.record()


@needs_duckdb
def test_a_table_without_described_columns_skips_the_sample():
    v = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1",
              conv=ConversionContext.build())
    assert v.status == eqv.NOT_CHECKABLE and v.sample.startswith("skipped")


@needs_duckdb
def test_a_type_duckdb_does_not_emulate_skips_the_sample():
    conv = ConversionContext.build(catalogue={"main.s.orders": {"id": "NUMBER", "p": "VARIANT"}})
    v = check("SELECT id FROM orders WHERE id > 1", "SELECT id FROM main.s.orders WHERE id >= 1", conv=conv)
    assert v.status == eqv.NOT_CHECKABLE and "not emulated" in v.sample


# ------------------------------------------------------------------------------------------------ without duckdb
@pytest.mark.skipif(HAS_DUCKDB, reason="the not-installed path needs an environment without duckdb")
def test_missing_duckdb_is_recorded_as_not_checkable_never_a_pass():
    v = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1")
    assert v.status == eqv.NOT_CHECKABLE and "duckdb is not installed" in v.sample


def test_missing_duckdb_is_simulated(monkeypatch):
    import builtins
    real = builtins.__import__

    def deny(name, *a, **k):
        if name == "duckdb":
            raise ImportError("no duckdb")
        return real(name, *a, **k)
    monkeypatch.setattr(builtins, "__import__", deny)
    v = check("SELECT id FROM orders WHERE amount > 1", "SELECT id FROM main.s.orders WHERE amount >= 1")
    assert v.status == eqv.NOT_CHECKABLE and "duckdb is not installed" in v.sample


# ------------------------------------------------------------------------------------------------ wired in
def test_the_verdict_is_evidence_on_a_view_unit_and_a_difference_adds_the_review_caveat():
    from agents.cd_codegen.translate.chain import TranslationSettings
    from packs.snowflake import translate as tr

    def run(sql):
        doc = {"etl_id": "e1", "asset_id": "bench:view:acme.DB.S.V", "engine": "sql_view", "name": "V",
               "definition": f"CREATE VIEW DB.S.V AS {sql}", "params": {}}
        ctx = tr.make_context(etl_key="e1", engine="sql_view", table_map=NAMES.table_map, default_db="DB",
                              default_schema="S", settings=TranslationSettings(tiers=("human",)), conversion=CONV)
        return asyncio.run(tr.translate_etl(doc, ctx))[0]

    res = run("SELECT id, IFF(amount > 100, 'big', 'small') AS size FROM orders")
    assert res.evidence["equivalence"]["status"] == eqv.EQUIVALENT
    assert "SNW-EQUIV-DIFF" not in res.caveats
    proc = {"etl_id": "p", "asset_id": "bench:proc:acme.DB.S.proc/P()", "engine": "sql_procedure", "name": "P",
            "definition": "CREATE PROCEDURE DB.S.P() RETURNS STRING LANGUAGE SQL AS $$ BEGIN RETURN 'x'; END $$",
            "params": {}}
    ctx = tr.make_context(etl_key="p", engine="sql_procedure", table_map=NAMES.table_map, default_db="DB",
                          default_schema="S", settings=TranslationSettings(tiers=("human",)), conversion=CONV)
    out = asyncio.run(tr.translate_etl(proc, ctx))[0]
    assert "equivalence" not in out.evidence                    # a procedure is not a query-shaped unit
