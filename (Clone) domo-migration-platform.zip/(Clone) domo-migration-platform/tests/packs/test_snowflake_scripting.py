"""P3-07 (ADR 032 section 2): the pack's block-aware Scripting splitter over the shared corpus
(`tests/fixtures/snowflake/scripting/*.sql`, byte-equal to the workspace copy, see test_snowflake_lists.py). One
golden per corpus file (the migrator keeps control-flow blocks WHOLE with their ordered children; the adapter's own
goldens extract every statement), plus the edge cases the ADR lists."""
from __future__ import annotations

import pathlib

import pytest

from packs.snowflake.scripting import extract_body, is_scripting, shape, split_scripting

CORPUS = pathlib.Path(__file__).resolve().parents[1] / "fixtures" / "snowflake" / "scripting"

#: name -> ((kind, first three words) per node, number of children per node)
GOLDEN = {
    "exception_block": ([("declare", "DECLARE BAD_INPUT EXCEPTION"), ("statement", "INSERT INTO FACT_SALES_CLEAN"),
                         ("block", "BEGIN UPDATE FACT_SALES_CLEAN"), ("exception", "EXCEPTION WHEN BAD_INPUT")],
                        [1, 0, 1, 4]),
    "execute_immediate_literal": ([("script", "EXECUTE IMMEDIATE 'INSERT"), ("script", "EXECUTE IMMEDIATE $$"),
                                   ("script", "RETURN 'OK'")], [0, 0, 0]),
    "execute_immediate_variable": ([("declare", "DECLARE STMT VARCHAR"), ("script", "LET TARGET VARCHAR"),
                                    ("script", "STMT := 'INSERT"), ("script", "EXECUTE IMMEDIATE :STMT"),
                                    ("script", "RETURN 'OK'")], [1, 0, 0, 0, 0]),
    "for_cursor": ([("declare", "DECLARE C1 CURSOR"), ("block", "FOR REC IN"), ("script", "RETURN TOTAL")],
                   [2, 2, 0]),
    "nested_if": ([("declare", "DECLARE RUN_MODE VARCHAR"), ("block", "IF (:RUN_MODE ="), ("script", "RETURN 'DONE'")],
                  [2, 4, 0]),
    "resultset": ([("declare", "DECLARE RES RESULTSET"), ("statement", "SELECT COUNT(*) INTO"),
                   ("block", "FOR R IN"), ("script", "RETURN CNT")], [2, 0, 1, 0]),
}


def test_corpus_has_exactly_the_golden_cases():
    assert sorted(p.stem for p in CORPUS.glob("*.sql")) == sorted(GOLDEN)


@pytest.mark.parametrize("name", sorted(GOLDEN))
def test_corpus_case(name):
    body = (CORPUS / f"{name}.sql").read_text(encoding="utf-8")
    nodes = split_scripting(body)
    want_shape, want_children = GOLDEN[name]
    assert shape(nodes) == want_shape
    assert [len(n.children) for n in nodes] == want_children
    assert [n.statement_index for n in nodes] == list(range(len(nodes)))
    assert all(n.unparsed for n in nodes if n.kind in ("block", "declare", "exception", "script"))


def test_a_control_block_keeps_every_child_in_order():
    body = (CORPUS / "nested_if.sql").read_text(encoding="utf-8")
    block = next(n for n in split_scripting(body) if n.kind == "block")
    kinds = [c.split()[0].upper() for c in block.children]
    assert kinds == ["TRUNCATE", "IF", "DELETE", "INSERT"]       # the inner IF stays whole, order preserved


def test_case_expression_inside_a_case_block_and_a_transaction_inside_a_block():
    body = """BEGIN
  BEGIN TRANSACTION;
  CASE (x) WHEN 1 THEN
    INSERT INTO t SELECT CASE WHEN a THEN 1 ELSE 2 END FROM s;
  ELSE
    DELETE FROM t;
  END CASE;
  COMMIT;
END"""
    nodes = split_scripting(body)
    assert [(n.kind, n.text.split()[0].upper()) for n in nodes] == [
        ("statement", "BEGIN"), ("block", "CASE"), ("statement", "COMMIT")]
    assert nodes[1].children == ["INSERT INTO t SELECT CASE WHEN a THEN 1 ELSE 2 END FROM s", "DELETE FROM t"]


def test_dollar_quotes_inside_string_literals_and_quoted_bodies():
    nodes = split_scripting("BEGIN\n  INSERT INTO log VALUES ('$$ not an end; really');\n  RETURN 'a;b';\nEND")
    assert [n.kind for n in nodes] == ["statement", "script"] and "'$$ not an end; really'" in nodes[0].text
    ddl = "CREATE PROCEDURE p() RETURNS STRING LANGUAGE SQL AS 'BEGIN RETURN ''x''; END'"
    assert extract_body(ddl) == "BEGIN RETURN 'x'; END"
    assert extract_body("CREATE PROCEDURE p() AS $$BEGIN SELECT '$$'; END$$") == "BEGIN SELECT '$$'; END"


def test_nested_if_in_for_and_exception_handler_stay_inside_their_block():
    body = """BEGIN
  FOR r IN c DO
    IF (r.x > 1) THEN
      UPDATE t SET a = 1;
    END IF;
  END FOR;
  EXCEPTION WHEN OTHER THEN
    INSERT INTO err VALUES (1);
END"""
    nodes = split_scripting(body)
    assert [n.kind for n in nodes] == ["block", "exception"]
    assert nodes[0].opener == "FOR" and nodes[0].children == [
        "IF (r.x > 1) THEN\n      UPDATE t SET a = 1;\n    END IF"]
    assert nodes[1].children == ["INSERT INTO err VALUES (1)"]


def test_is_scripting():
    assert is_scripting("DECLARE x NUMBER; BEGIN RETURN 1; END")
    assert is_scripting("$$BEGIN SELECT 1; END$$")
    assert not is_scripting("BEGIN TRANSACTION")
    assert not is_scripting("SELECT 1")
