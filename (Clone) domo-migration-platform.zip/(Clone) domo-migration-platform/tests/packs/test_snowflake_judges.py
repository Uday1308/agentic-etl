# Ported (anonymized) from SNF2DBX-main/tests (judge rules and refactor cases; LatentView internal), adapted to the
# pack's per-unit judge pass.
"""S6 (ADR 037 section 2): the deterministic judges, the REF002 / REF003 refactors and their wiring after tier 0."""
from __future__ import annotations

import asyncio

import pytest
import yaml

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import caveats as cav
from packs.snowflake import judges, post_tier0
from packs.snowflake import translate as tr
from packs.snowflake.conversion import ConversionContext


def ids(findings):
    return sorted({f.id for f in findings})


# ------------------------------------------------------------------------------------------------ the judges
def test_every_judge_id_has_a_family_a_severity_and_a_note():
    for cid, (fam, sev, note) in judges.CAVEAT_TABLE.items():
        assert fam in judges.FAMILIES and sev in cav.SEVERITIES and note, cid


def test_judge_ids_are_in_caveats_yaml_with_the_same_severity():
    """The catalogue and the table are one list (the yaml block is generated from CAVEAT_TABLE)."""
    table = cav.load_catalogue().by_id()
    missing = [c for c in judges.CAVEAT_TABLE if c not in table]
    assert not missing, f"append these ids to caveats.yaml (judges.yaml_block()): {missing}"
    for cid, (fam, sev, _) in judges.CAVEAT_TABLE.items():
        assert (table[cid].family, table[cid].severity) == (fam, sev), cid
    assert set(judges.FAMILIES) <= set(cav.load_catalogue().families)


def test_yaml_block_is_valid_yaml_and_lists_every_id():
    block = yaml.safe_load(judges.yaml_block())
    assert {e["id"] for e in block["migrator_only"]} == set(judges.CAVEAT_TABLE)


@pytest.mark.parametrize("code,expected", [
    ("SELECT PG_SLEEP(1)", {"SNW-DET-FOREIGN-FN"}),
    ("SELECT ISNULL(a, 0) FROM t", {"SNW-DET-FOREIGN-FN"}),
    ("SELECT 1 /* GETDATE( */", set()),                                           # a comment is not code
    ("SELECT 'GETDATE(' AS x", set()),                                            # nor a literal
    ("USE ROLE ACCOUNTADMIN", {"SNW-POL-ROLE"}),
    ("DROP TABLE x", {"SNW-POL-DDL"}),
    ("GRANT SELECT ON t TO r", {"SNW-POL-GRANT"}),
    ("SELECT 1 -- password = 'abcdefgh'", {"SNW-POL-CREDENTIAL"}),
    ("SELECT 'dapi" + "a" * 32 + "'", {"SNW-POL-CREDENTIAL"}),
    ("SELECT 1 AS __PENDING_3__", {"SNW-STR-PENDING"}),
    ("", {"SNW-STR-EMPTY"}),
    ("SELECT a FROM t", set()),
])
def test_output_judges(code, expected):
    assert ids(judges.judge_text("", code, source_is_sql=False)) == sorted(expected)


def test_credential_judge_reads_literals_but_other_judges_do_not():
    f = judges.judge_text("", "SELECT 'DROP TABLE x' AS note", source_is_sql=False)
    assert ids(f) == []                                              # DROP inside a string is not DDL
    assert ids(judges.judge_text("", "SET token = 'abcd1234efgh'", source_is_sql=False)) == ["SNW-POL-CREDENTIAL"]


def test_warehouse_name_is_a_policy_finding():
    f = judges.judge_text("", "USE WAREHOUSE COMPUTE_WH; SELECT 1", source_is_sql=False, warehouses={"COMPUTE_WH"})
    assert "SNW-POL-WAREHOUSE" in ids(f)


def test_semantic_judges_read_the_source():
    f = judges.judge_text("SELECT CURRENT_ROLE(), CURRENT_TIMESTAMP() FROM t", "SELECT NULL, current_timestamp() FROM t")
    assert {"SNW-SEM-CURRENT-ROLE", "SNW-SEM-SESSION-TZ"} <= set(ids(f))
    assert judges.severity_of("SNW-SEM-SESSION-TZ") == "info"          # recorded, never forces a review


def test_column_set_judge_and_the_rename_exemption():
    src, out = "SELECT a, b FROM t", "SELECT a FROM main.s.t"
    assert "SNW-SEM-COLUMNS" in ids(judges.judge_text(src, out, kind="cte_chain", name_map={"t": "t"}))
    assert "SNW-SEM-COLUMNS" not in ids(judges.judge_text(src, out, kind="cte_chain", name_map={"t": "t"},
                                                          declared={"SNW-QUOTED-IDENT"}))
    star = judges.judge_text("SELECT * FROM t", "SELECT * FROM main.s.t", kind="cte_chain", name_map={"t": "t"})
    assert "SNW-SEM-COLUMNS" not in ids(star)                          # a star's columns are the table's


def test_lineage_judges():
    f = judges.judge_text("SELECT a FROM orders", "SELECT a FROM main.s.invoices", kind="cte_chain",
                          name_map={"orders": "orders"})
    assert "SNW-LIN-TABLE-DROPPED" in ids(f)
    ok = judges.judge_text("SELECT a FROM orders", "SELECT a FROM main.s.orders", kind="cte_chain",
                           name_map={"orders": "orders"})
    assert "SNW-LIN-TABLE-DROPPED" not in ids(ok)
    changes = judges.judge_text("SELECT a FROM o_stream", "SELECT a FROM TABLE_CHANGES('main.s.o', :v)", kind="cte_chain",
                                name_map={"o_stream": "o"})
    assert "SNW-LIN-TABLE-DROPPED" not in ids(changes)                 # a change feed read is a read of the base table
    calls = judges.judge_text("CALL etl.load_a(); CALL etl.load_b()", "CALL main.etl.load_a()", kind="script")
    assert "SNW-LIN-CALL-DROPPED" in ids(calls)
    assert "SNW-LIN-CALL-DROPPED" not in ids(judges.judge_text("CALL p()", "CALL main.s.p__ret(x)", kind="script"))


def test_performance_and_concurrency_judges():
    loop = "FOR r AS SELECT id FROM src DO INSERT INTO t SELECT r.id; END FOR"
    assert ids(judges.judge_text("", loop, source_is_sql=False)) == ["SNW-PERF-ROW-LOOP"]
    assert ids(judges.judge_text("", "FOR r AS SELECT id FROM src DO SET x = r.id; END FOR", source_is_sql=False)) == []
    maxkey = "SET v = (SELECT MAX(order_id) + 1 FROM t);"
    assert ids(judges.judge_text("", maxkey, source_is_sql=False)) == ["SNW-CONC-MAX-KEY"]
    pre = ("SET n = (SELECT COUNT(*) FROM (SELECT a FROM s WHERE b > 1) AS c);\n"
           "INSERT INTO t SELECT a FROM s WHERE b > 1;")
    assert ids(judges.judge_text("", pre, source_is_sql=False)) == ["SNW-PERF-PRECOUNT"]
    other = ("SET n = (SELECT COUNT(*) FROM (SELECT a FROM s WHERE b > 1) AS c);\nINSERT INTO t SELECT a FROM u;")
    assert ids(judges.judge_text("", other, source_is_sql=False)) == []        # the counted query is not repeated


# ------------------------------------------------------------------------------------------------ REF002 / REF003
def test_ref002_reads_the_row_count_from_the_commit_metrics():
    body = ("SET rowcount_ = (SELECT COUNT(*) FROM (SELECT a FROM src WHERE b > 1) AS counted_);\n"
            "INSERT INTO main.s.t SELECT a FROM src WHERE b > 1;\nSELECT rowcount_;")
    r = judges.refactor_rowcount(body)
    assert [f.id for f in r.applied] == ["SNW-REF-ROWCOUNT"]
    assert "COUNT(*)" not in r.sql and "DESCRIBE HISTORY main.s.t LIMIT 1" in r.sql
    assert "operationMetrics['numOutputRows']" in r.sql
    assert r.sql.index("INSERT INTO") < r.sql.index("DESCRIBE HISTORY")           # read AFTER the statement
    assert judges.judge_text("", r.sql, source_is_sql=False) == []                # PERF002 no longer fires


@pytest.mark.parametrize("dml,metric", [
    ("UPDATE main.s.t SET a = 1 WHERE b > 1", "numUpdatedRows"),
    ("DELETE FROM main.s.t WHERE b > 1", "numDeletedRows"),
])
def test_ref002_metrics_per_statement_kind(dml, metric):
    body = f"SET n = (SELECT COUNT(*) FROM (SELECT * FROM main.s.t WHERE b > 1) AS c);\n{dml};"
    r = judges.refactor_rowcount(body)
    assert not r.applied or metric in r.sql                                       # applied only if the query is repeated


def test_ref002_leaves_a_count_that_is_not_repeated():
    body = "SET n = (SELECT COUNT(*) FROM (SELECT a FROM src) AS c);\nINSERT INTO t SELECT a FROM other;"
    r = judges.refactor_rowcount(body)
    assert r.sql == body and not r.applied


def test_ref003_run_id_read_back_needs_the_run_id_column():
    body = ("INSERT INTO main.s.t (a, b) VALUES (1, 'x');\n"
            "SET v = (SELECT MAX(id) FROM main.s.t WHERE a IS NOT DISTINCT FROM 1);")
    with_col = judges.refactor_runid(body, lambda t: ["id", "a", "b", "run_id"])
    assert [f.id for f in with_col.applied] == ["SNW-REF-RUNID"]
    assert "MAX(" not in with_col.sql and "run_id_ = uuid()" in with_col.sql
    assert "run_id) VALUES (1, 'x', run_id_)" in with_col.sql and "WHERE run_id = run_id_" in with_col.sql
    assert with_col.sql.startswith("DECLARE run_id_ STRING;")
    without = judges.refactor_runid(body, lambda t: ["id", "a", "b"])
    assert without.sql == body and not without.applied                            # never adds a column to a table
    assert ids(judges.judge_text("", without.sql, source_is_sql=False)) == ["SNW-CONC-MAX-KEY"]   # flagged instead


# ------------------------------------------------------------------------------------------------ wired after tier 0
def run(definition: str, engine="sql_view", columns=None, table_map=None, **kw):
    doc = {"etl_id": "e1", "asset_id": "bench:view:acme.DB.S.V", "engine": engine, "name": "V",
           "definition": definition, "params": kw.pop("params", {})}
    ctx = tr.make_context(etl_key="e1", engine=engine,
                          table_map=table_map or {("DB", "S", "ORDERS"): "main.s.orders"}, default_db="DB",
                          default_schema="S", settings=TranslationSettings(tiers=("human",)),
                          conversion=ConversionContext.build(catalogue=columns), **kw)
    return asyncio.run(tr.translate_etl(doc, ctx))[0]


def test_a_clean_view_gets_no_judge_caveat():
    res = run("CREATE VIEW DB.S.V AS SELECT id, amount FROM orders WHERE amount > 0")
    assert res.status == "resolved" and res.origin == "mapped"
    assert not set(res.caveats) & set(judges.CAVEAT_TABLE)
    assert res.evidence["judges"] == [] and res.evidence["post_tier0"] is True


def test_a_judge_finding_is_a_review_caveat_and_is_recorded_without_source_text():
    res = run("CREATE VIEW DB.S.V AS SELECT id, compute_wh AS w FROM orders", params={"warehouse": "COMPUTE_WH"})
    assert res.status == "resolved" and "SNW-POL-WAREHOUSE" in res.review_caveats
    assert res.needs_review
    blob = repr(res.evidence)
    assert "COMPUTE_WH" in blob and "SELECT" not in blob and "FROM" not in blob         # names, never SQL text


def test_an_escalate_finding_turns_the_unit_into_a_review_with_the_draft_kept():
    res = run("CREATE VIEW DB.S.V AS SELECT id FROM orders WHERE note = 'token = ''abcd1234efgh'''")
    assert res.status in ("awaiting_review", "resolved")
    if res.status == "awaiting_review":
        assert res.origin == "unresolved" and not res.sql and res.suggested_code
        assert any("SNW-POL-CREDENTIAL" in r for r in res.reasons)


def test_edited_and_ai_units_are_never_judged():
    class Res:
        status, origin, sql, edited, evidence = "resolved", "ai", "SELECT 1", False, {}
    assert not post_tier0._eligible(Res())
    Res.origin, Res.edited = "mapped", True
    assert not post_tier0._eligible(Res())


PROC = """CREATE OR REPLACE PROCEDURE DB.S.P() RETURNS STRING LANGUAGE SQL AS
$$
DECLARE n NUMBER DEFAULT 0;
BEGIN
  MERGE INTO DB.S.TGT t USING (SELECT id, v FROM DB.S.SRC) s ON t.id = s.id
    WHEN MATCHED THEN UPDATE SET t.v = s.v
    WHEN NOT MATCHED THEN INSERT (id, v) VALUES (s.id, s.v);
  n := n + SQLROWCOUNT;
  RETURN 'rows ' || n;
END;
$$"""
PROC_TABLES = {("DB", "S", "TGT"): "main.s.tgt", ("DB", "S", "SRC"): "main.s.src"}


def test_the_rowcount_refactor_is_opt_in_and_the_default_keeps_the_converters_pre_count():
    off = run(PROC, engine="sql_procedure", table_map=PROC_TABLES)
    assert "COUNT(*)" in off.sql and "DESCRIBE HISTORY" not in off.sql
    assert "SNW-PERF-PRECOUNT" in off.review_caveats                       # the judge still flags the double work
    on = run(PROC, engine="sql_procedure", table_map=PROC_TABLES, refactor_history=True)
    assert "DESCRIBE HISTORY main.s.tgt LIMIT 1" in on.sql and "COUNT(*)" not in on.sql
    assert "SNW-REF-ROWCOUNT" in on.review_caveats and "SNW-PERF-PRECOUNT" not in on.caveats
    assert on.sql.index("MERGE INTO") < on.sql.index("DESCRIBE HISTORY")
