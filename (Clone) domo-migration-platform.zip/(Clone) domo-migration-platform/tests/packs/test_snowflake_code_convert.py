# Ported (anonymized) from SNF2DBX-main/tests/workbench/test_code_converters.py (LatentView internal), adapted to the
# pack: the converters read a unit document, every inner SQL statement goes through the pack's tier 0, names come from the
# batch's table map, and a refusal is a precise reason with the line.
"""S2 (ADR 037, catalogue 5.11-5.13, 6.12): JavaScript and Snowpark Python procedures / UDFs as tier 0, Java / Scala
packaging flags, and the L4 pre-pass (a ``v := (CALL p())`` converts when ``p`` is in the batch).

The JavaScript tests need ``esprima`` (``requirements.txt``: ``esprima==4.0.1``); without it they are skipped and one test
asserts the precise "esprima not installed" reason. The JavaScript translator is ALSO exercised on hand-built syntax trees
(no esprima needed), so a broken port shows up either way."""
from __future__ import annotations

import ast
import asyncio
import json
import re
from types import SimpleNamespace

import pytest

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import code_units as cu
from packs.snowflake import js_convert as js
from packs.snowflake import translate as tr
from packs.snowflake.code_common import CodeNames, CodeRefused, CodeServices, parse_code_object
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.handlers import HandlerContext, build_artifacts

try:
    import esprima  # noqa: F401
    HAVE_ESPRIMA = True
except ImportError:                                           # pragma: no cover - depends on the environment
    HAVE_ESPRIMA = False
needs_esprima = pytest.mark.skipif(not HAVE_ESPRIMA, reason="esprima is not installed (esprima==4.0.1)")

TABLES = {("DEMO", "CORE", t): f"main.core.{t.lower()}" for t in
          ("ORDERS", "DAILY", "SUMMARY", "ERRORS", "ORDERS_ARCHIVE")}


def convert(defn: str, engine: str, *, sig: str = "", tables: dict | None = None, procedures: dict | None = None):
    kind = "func" if engine.startswith("udf_") else "proc"
    doc = {"etl_id": "e1", "asset_id": f"bench:{kind}:acme.DEMO.CORE.{kind}/P({sig})", "engine": engine, "name": "P",
           "definition": defn, "params": {}}
    ctx = tr.make_context(etl_key="e1", engine=engine, table_map=tables if tables is not None else dict(TABLES),
                          default_db="DEMO", default_schema="CORE", settings=TranslationSettings(tiers=("human",)),
                          conversion=ConversionContext.build())
    ctx.procedure_returns.update(procedures or {})
    units = asyncio.run(tr.translate_etl(doc, ctx))
    arts = build_artifacts(doc, units, HandlerContext())
    return SimpleNamespace(units=units, arts=arts, ctx=ctx, text="\n".join(a.text for a in arts),
                           ok=all(u.status == "resolved" for u in units), reasons=[r for u in units for r in u.reasons],
                           review=sorted({c for u in units for c in u.review_caveats}))


# ---------------------------------------------------------------------------------------------- Snowpark Python
SNOWPARK = """CREATE OR REPLACE PROCEDURE DEMO.CORE.LOAD(RUN_DATE DATE)
RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION = '3.11' PACKAGES = ('snowflake-snowpark-python', 'holidays')
HANDLER = 'run' AS $$
import snowflake.snowpark as snowpark
from snowflake.snowpark.functions import col, iff

def run(session: snowpark.Session, run_date):
    df = session.table("ORDERS").filter(col("ORDER_DATE") == run_date)
    df = df.with_column("BIG", iff(col("AMOUNT") > 100, 1, 0)).group_by("REGION").count()
    df.write.save_as_table("DEMO.CORE.DAILY", mode="overwrite")
    n = session.sql("SELECT COUNT(*) AS N FROM DEMO.CORE.DAILY WHERE IFF(N > 0, TRUE, FALSE)").collect()[0]["N"]
    return f"rows {n}"
$$"""


def test_snowpark_procedure_becomes_a_pyspark_notebook_by_rule():
    r = convert(SNOWPARK, "snowpark_python", sig="DATE")
    assert r.ok and r.units[0].origin == "mapped" and r.units[0].kind == "python"
    text = r.text
    ast.parse(text)
    assert "session.table('main.core.orders')" in text
    assert ".withColumn('BIG', when(col('AMOUNT') > 100, 1).otherwise(0)).groupBy('REGION')" in text
    assert "write.mode('overwrite').saveAsTable('main.core.daily')" in text
    assert "FROM main.core.daily WHERE IF(COUNT(*) > 0, TRUE, FALSE)" in text   # inner SQL: tier 0 + the alias rule (1.11)
    assert "from pyspark.sql.functions import col, when" in text and "snowpark" not in text
    assert '_result = run(spark, _arg("RUN_DATE", datetime.date.fromisoformat))' in text
    assert '# MAGIC %pip install "holidays"' in text                           # a package outside the runtime
    assert {"SNW-CODE-PYTHON", "SNW-ALIAS-INLINED", "always_review:snowpark_python"} <= set(r.review)
    assert "SNW-QUOTED-IDENT" not in r.review          # the SQL text patterns are not run over Python / JavaScript code
    assert r.arts[0].kind == "python"
    assert any(n.startswith("Snowflake returns unquoted column names") for n in r.arts[0].review_reasons)


def test_the_unit_record_and_evidence_never_carry_source_text():
    r = convert(SNOWPARK, "snowpark_python", sig="DATE")
    blob = json.dumps(r.units[0].record(), default=str)
    for fragment in ("ORDER_DATE", "AMOUNT", "REGION", "holidays", "save_as_table", "SELECT COUNT"):
        assert fragment not in blob
    assert r.units[0].evidence["code_converter"]["inner_statements"] == 1


@pytest.mark.parametrize("body, message", [
    ('def run(session):\n    session.table("ORDERS").merge(x, y, [])', "line 2: Table.merge() (Snowpark DML)"),
    ('from snowflake.snowpark.functions import datediff\ndef run(session):\n    return 1', "line 1: snowflake.snowpark.functions.datediff"),
    ('import _snowflake\ndef run(session):\n    return 1', "line 1: _snowflake"),
    ('def run(session):\n    return session.get_current_role()', "line 2: session.get_current_role()"),
    ('def run(session):\n    session.table("DEMO.CORE.GONE").show()', "DEMO.CORE.GONE is not in the batch's table map"),
    ('def run(session):\n    session.sql("SELECT RATIO_TO_REPORT(A) OVER () FROM DEMO.CORE.ORDERS")', "line 2: session.sql"),
    ('def run(session)\n    return 1', "Python syntax error at line 1"),
])
def test_snowpark_without_an_exact_rule_is_refused_with_the_line(body, message):
    defn = f"CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION='3.11' HANDLER='run' AS $${body}$$"
    r = convert(defn, "snowpark_python")
    assert not r.ok and r.arts == []
    assert any(message in x for x in r.reasons), r.reasons
    assert "SNW-CODE-REFUSED" in r.units[0].caveats
    assert not any("ORDERS" in x or "RATIO_TO_REPORT" in x for x in r.reasons if "session.sql" in x and "SQL could" not in x)


def test_dynamic_sql_in_python_is_passed_with_a_review_note_and_residue_is_refused():
    ok = convert("CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION='3.11' HANDLER='run' AS $$"
                 'def run(session):\n    return session.sql(f"SELECT {1}").collect()$$', "snowpark_python")
    assert ok.ok and any("builds SQL at run time" in n for n in ok.arts[0].review_reasons)


def test_dict_methods_are_not_mistaken_for_snowpark():
    r = convert("CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION='3.11' HANDLER='run' AS $$"
                "def run(session):\n    d = {}\n    d.update({'a': 1})\n    return d.get('a')$$", "snowpark_python")
    assert r.ok and "d.update({'a': 1})" in r.text


def test_session_call_reads_a_converted_sql_procedure_through_its_twin():
    body = ('def run(session):\n    v = session.call("DEMO.CORE.GET_COUNT", 3)\n    session.call("DEMO.CORE.OTHER")\n'
            '    return v')
    defn = f"CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION='3.11' HANDLER='run' AS $${body}$$"
    r = convert(defn, "snowpark_python", procedures={"DEMO.CORE.GET_COUNT": "NUMBER"})
    assert r.ok
    assert "session.sql('CALL main.demo_core.get_count(?)', args=[3]).collect()[0][0]" in r.text
    assert "session.sql('CALL main.demo_core.other()')" in r.text
    assert any("callee is outside this conversion" in n for n in r.arts[0].review_reasons)


# ---------------------------------------------------------------------------------------------- Python UDFs
def _udf_body(text: str) -> str:
    return text.split("AS $$\n", 1)[1].rsplit("\n$$", 1)[0]


def _run_udf(text: str, *args):
    head = text.split("(", 1)[1].split("\nRETURNS", 1)[0].rsplit(")", 1)[0]
    params = [p.split()[0] for p in re.split(r",\s*(?![^()]*\))", head) if p.strip()]
    ns: dict = {}
    exec("def udf(" + ", ".join(params) + "):\n" + "\n".join("    " + ln for ln in _udf_body(text).splitlines()), ns)
    return ns["udf"](*args)


def test_python_udf_becomes_a_uc_function_with_strict_and_packages():
    r = convert("""CREATE FUNCTION DEMO.CORE.ADD_ONE(X NUMBER(10,0)) RETURNS NUMBER(10,0) LANGUAGE PYTHON RUNTIME_VERSION='3.11'
PACKAGES=('numpy','snowflake-snowpark-python') HANDLER='add' STRICT AS $$
def add(x):
    return x + 1
$$""", "udf_python", sig="NUMBER")
    assert r.ok and r.arts[0].kind == "statement"
    assert r.text.startswith("CREATE OR REPLACE FUNCTION main.demo_core.p(X DECIMAL(10, 0))\nRETURNS DECIMAL(10, 0)\nLANGUAGE PYTHON")
    assert """dependencies = '["numpy"]'""" in r.text
    assert _run_udf(r.text, 4) == 5 and _run_udf(r.text, None) is None
    assert "SNW-CODE-PYTHON" in r.review


def test_vectorized_class_and_staged_python_functions_are_refused():
    vec = convert("CREATE FUNCTION DEMO.CORE.F(X INT) RETURNS INT LANGUAGE PYTHON RUNTIME_VERSION='3.11' HANDLER='f' AS $$"
                  "import _snowflake\n@_snowflake.vectorized(input=pandas.DataFrame)\ndef f(x):\n    return x$$", "udf_python")
    assert not vec.ok and any("_snowflake" in x for x in vec.reasons)
    cls = convert("CREATE FUNCTION DEMO.CORE.F(X INT) RETURNS TABLE(A INT) LANGUAGE PYTHON RUNTIME_VERSION='3.11' "
                  "HANDLER='F' AS $$\nclass F:\n    def process(self, x):\n        yield (x,)\n$$", "udf_python")
    assert not cls.ok and any("Python table functions" in x for x in cls.reasons)
    staged = convert("CREATE FUNCTION DEMO.CORE.F(X INT) RETURNS INT LANGUAGE PYTHON RUNTIME_VERSION='3.11' "
                     "IMPORTS=('@stage/mod.py') HANDLER='mod.f' AS $$\ndef f(x):\n    return x\n$$", "udf_python")
    assert not staged.ok and any("IMPORTS from stages" in x for x in staged.reasons)


# ---------------------------------------------------------------------------------------------- Java / Scala
def test_java_and_scala_are_packaged_for_a_human_with_a_precise_flag():
    r = convert("CREATE OR REPLACE PROCEDURE DEMO.CORE.P(N INT) RETURNS INT LANGUAGE JAVA RUNTIME_VERSION='11' "
                "PACKAGES=('com.snowflake:snowpark:1.9.0') IMPORTS=('@stage/jobs.jar') HANDLER='Jobs.run' AS ''",
                "snowpark_java")
    assert not r.ok and r.arts == []
    assert "SNW-CODE-PACKAGING" in r.units[0].caveats
    joined = " ".join(r.reasons)
    assert "Java procedure (handler Jobs.run)" in joined and "@stage/jobs.jar" in joined and "spark_jar_task" in joined
    scala = convert("CREATE FUNCTION DEMO.CORE.F(X INT) RETURNS INT LANGUAGE SCALA RUNTIME_VERSION='2.12' "
                    "HANDLER='F.f' AS $$ object F { def f(x: Int) = x } $$", "udf_scala")
    assert "SNW-CODE-PACKAGING" in scala.units[0].caveats and "Scala function" in " ".join(scala.reasons)
    assert "inline" in " ".join(scala.reasons)


# ---------------------------------------------------------------------------------------------- the definition
def test_the_definition_parser_reads_both_quoting_forms_and_a_bare_body():
    quoted = parse_code_object({"engine": "javascript_procedure", "asset_id": "a:proc:acme.DEMO.CORE.proc/P(FLOAT)",
                                "definition": "CREATE PROCEDURE DEMO.CORE.P(\"DAYS\" FLOAT, S VARCHAR DEFAULT 'x') "
                                              "RETURNS VARCHAR LANGUAGE JAVASCRIPT EXECUTE AS CALLER AS '\n"
                                              "var a = \"it''s\";\nreturn a;\n'"})
    assert quoted.language == "javascript" and quoted.returns == "VARCHAR" and quoted.execute_as == "CALLER"
    assert [a["name"] for a in quoted.args] == ["DAYS", "S"] and quoted.args[1]["default"] == "'x'"
    assert 'var a = "it\'s";' in quoted.body
    bare = parse_code_object({"engine": "snowpark_python", "asset_id": "a:proc:acme.DEMO.CORE.proc/P(NUMBER)",
                              "definition": "def run(session, n):\n    return n", "language": "python",
                              "params": {"argument_signature": "(N NUMBER)", "handler": "run",
                                         "packages": "['numpy', 'pandas']"}})
    assert bare.handler == "run" and bare.packages == ["numpy", "pandas"] and [a["name"] for a in bare.args] == ["N"]


# ---------------------------------------------------------------------------------------------- JavaScript
JS = r"""CREATE OR REPLACE PROCEDURE DEMO.CORE.REFRESH(RUN_DATE VARCHAR)
RETURNS VARCHAR LANGUAGE JAVASCRIPT EXECUTE AS CALLER AS $$
var count = 0;
snowflake.execute({sqlText: "BEGIN"});
try {
  var del = snowflake.createStatement({sqlText: "DELETE FROM DEMO.CORE.SUMMARY WHERE RUN_DATE = :1", binds: [RUN_DATE]});
  del.execute();
  var rs = snowflake.execute({sqlText: "SELECT REGION FROM ORDERS WHERE D = ?", binds: [RUN_DATE]});
  while (rs.next()) { count++; }
  for (var i = 0; i < 3; i++) { if (i == 1) continue; count += 10; }
  snowflake.execute({sqlText: "COMMIT"});
} catch (err) {
  throw "Failed: " + err.message;
}
return "Inserted " + count + " rows " + (-7 % 3) + " " + Math.round(2.5);
$$"""


class FakeSpark:
    def __init__(self, rows):
        self.rows, self.calls = rows, []

    def sql(self, text, args=None):
        self.calls.append((text, args))
        sel, dele = text.lower().startswith("select region"), text.upper().startswith("DELETE")
        rows = self.rows if sel else [(2,)] if dele else [("ok",)]
        columns = ["REGION"] if sel else ["num_affected_rows"] if dele else ["status"]
        return type("Frame", (), {"collect": lambda self: rows, "columns": columns})()


def run_notebook(code, widgets):
    spark, exits = FakeSpark([("east",), ("west",)]), []
    dbutils = type("D", (), {})()
    dbutils.widgets = type("W", (), {"text": staticmethod(lambda *a: None), "get": staticmethod(lambda name: widgets[name])})()
    dbutils.notebook = type("N", (), {"exit": staticmethod(exits.append)})()
    exec(code.replace("# MAGIC", "#"), {"spark": spark, "dbutils": dbutils})
    return exits[0], spark.calls


def test_without_esprima_the_javascript_refusal_names_the_missing_dependency(monkeypatch):
    import builtins
    real = builtins.__import__

    def no_esprima(name, *a, **kw):
        if name == "esprima":
            raise ImportError("no esprima")
        return real(name, *a, **kw)
    monkeypatch.setattr(builtins, "__import__", no_esprima)
    r = convert(JS, "javascript_procedure", sig="VARCHAR")
    assert not r.ok and r.arts == []
    assert any(x.startswith("esprima not installed") for x in r.reasons), r.reasons
    assert "SNW-CODE-REFUSED" in r.units[0].caveats


@needs_esprima
def test_javascript_procedure_runs_with_js_semantics():
    r = convert(JS, "javascript_procedure", sig="VARCHAR", tables={**TABLES, ("DEMO", "CORE", "SUMMARY"): "main.core.summary"})
    assert r.ok, r.reasons
    result, calls = run_notebook(r.text, {"RUN_DATE": "2026-01-01"})
    assert result == "Inserted 22 rows -1 3"             # 2 rows + 2 loop passes x 10; JS % and Math.round
    assert ("USE main.core", None) in calls
    assert ("DELETE FROM main.core.summary WHERE RUN_DATE = ?", ["2026-01-01"]) in calls
    assert ("SELECT region FROM main.core.orders WHERE D = ?", ["2026-01-01"]) in calls
    assert any("Transaction control" in n for n in r.arts[0].review_reasons)
    assert {"SNW-CODE-JS", "always_review:javascript_procedure"} <= set(r.review)


@needs_esprima
def test_javascript_udf_runs_with_js_semantics():
    r = convert(r"""CREATE FUNCTION DEMO.CORE.FMT(P VARCHAR) RETURNS VARCHAR LANGUAGE JAVASCRIPT AS $$
if (P === null) return null;
var d = P.replace(/[^0-9]/g, '');
return d.length == 10 ? '(' + d.substring(0,3) + ') ' + d.substring(3,6) + '-' + d.substring(6) : "x" + 1 + 2;
$$""", "udf_js", sig="VARCHAR")
    assert r.ok, r.reasons
    assert _run_udf(r.text, "555-123-4567") == "(555) 123-4567"
    assert _run_udf(r.text, None) is None and _run_udf(r.text, "12") == "x12"


def _udf(body, args="S VARCHAR"):
    return f"CREATE FUNCTION DEMO.CORE.F({args}) RETURNS VARCHAR LANGUAGE JAVASCRIPT AS $${body}$$"


@needs_esprima
def test_regex_replace_with_callback_converts_without_ai():
    r = convert(_udf(r"""
  if (S === null || S === undefined) return null;
  return S.toLowerCase().replace(/\b\w/g, function(c) { return c.toUpperCase(); });"""), "udf_js", sig="VARCHAR")
    assert r.ok and "flags=re.A" in r.text                      # JavaScript \w and \b are ASCII-only
    assert _run_udf(r.text, "JOHN o'neil-SMITH") == "John O'Neil-Smith"
    assert _run_udf(r.text, "\u00e9lan") == "\u00e9Lan" and _run_udf(r.text, None) is None


@needs_esprima
@pytest.mark.parametrize("body, value, expected", [
    (r"return S.replace(/(\d+)-(\d+)/, function(all, a, b) { return b + '-' + a; });", "x 12-34 56-78", "x 34-12 56-78"),
    (r"return S.replace(/[aeiou]/g, (v) => v.toUpperCase());", "banana", "bAnAnA"),
    (r"return S.replace(/X/gi, function() { return '*'; });", "axbX", "a*b*"),
])
def test_regex_replace_callback_forms(body, value, expected):
    r = convert(_udf(body), "udf_js", sig="VARCHAR")
    assert r.ok and _run_udf(r.text, value) == expected


@needs_esprima
@pytest.mark.parametrize("body, message", [
    ("return new Date().toISOString();", "line 1: new Date()"),
    ('var x = snowflake.execute({sqlText: "SELECT 1", resultSetFormat: "x"}); return 1;', "options"),
    ("var a = [1];\nreturn a.someUnknown();", "line 2: .someUnknown() has no rule"),
    ("for (var i = 0; i < 3; i++) { if (i) continue; if (i > 1) break; } return 1;", "continue and break"),
    ("switch (A) { case 1: x = 1; case 2: x = 2; break; } return x;", "fall-through"),
    ('return eval("1");', "eval() is not declared"),
    ("return A +;", "JavaScript syntax error at line 1"),
])
def test_javascript_without_a_rule_is_refused_with_the_line(body, message):
    r = convert(f"CREATE PROCEDURE DEMO.CORE.P(A FLOAT) RETURNS VARCHAR LANGUAGE JAVASCRIPT AS $${body}$$",
                "javascript_procedure", sig="FLOAT")
    assert not r.ok and any(message in x for x in r.reasons), r.reasons


@needs_esprima
def test_javascript_udf_cannot_run_sql_and_table_returns_are_refused():
    r = convert("CREATE FUNCTION DEMO.CORE.F(A FLOAT) RETURNS FLOAT LANGUAGE JAVASCRIPT AS $$"
                "return snowflake.execute({sqlText: 'SELECT 1'});$$", "udf_js", sig="FLOAT")
    assert not r.ok and any("UDF" in x for x in r.reasons)
    t = convert("CREATE PROCEDURE DEMO.CORE.P() RETURNS TABLE(A INT) LANGUAGE JAVASCRIPT AS $$return 1;$$",
                "javascript_procedure")
    assert not t.ok and any("returning TABLE" in x for x in t.reasons)


ARCHIVE = """CREATE OR REPLACE PROCEDURE DEMO.CORE.ARCHIVE("DAYS" FLOAT) RETURNS VARCHAR LANGUAGE JAVASCRIPT EXECUTE AS CALLER AS '
var tgt = "DEMO.CORE.ORDERS_ARCHIVE";
try {
  snowflake.execute({sqlText: `CREATE TABLE IF NOT EXISTS ${tgt} LIKE DEMO.CORE.ORDERS`});
  var ins = snowflake.execute({sqlText: `INSERT INTO ${tgt} SELECT * FROM DEMO.CORE.ORDERS WHERE D < DATEADD(day, -:1, CURRENT_DATE())`, binds: [DAYS]});
  return "ok";
} catch (err) {
  snowflake.execute({sqlText: "INSERT INTO DEMO.CORE.ERRORS VALUES (:1, CURRENT_USER())", binds: [err.message]});
  return "failed";
}
'"""


@needs_esprima
def test_javascript_dynamic_sql_maps_table_strings_binds_and_unmapped_tables_are_refused():
    r = convert(ARCHIVE, "javascript_procedure", sig="FLOAT")
    assert r.ok, r.reasons
    assert any("treated as a table name" in n for n in r.arts[0].review_reasons)
    assert 'tgt = "main.core.orders_archive"' in r.text
    assert "DATEADD(day, -?, CURRENT_DATE())" in r.text and "_rebind([DAYS], [1])" in r.text
    gone = convert(ARCHIVE, "javascript_procedure", sig="FLOAT",
                   tables={k: v for k, v in TABLES.items() if k[2] != "ORDERS_ARCHIVE"})
    assert not gone.ok and any("not in the batch's table map" in x for x in gone.reasons)


# ---------------------------------------------------------------------------------------------- hand-built trees
def _n(type_, **kw):
    return SimpleNamespace(type=type_, loc=SimpleNamespace(start=SimpleNamespace(line=2)), **kw)


def _id(name):
    return _n("Identifier", name=name)


def _lit(value):
    return _n("Literal", value=value, regex=None)


def _services() -> CodeServices:
    names = CodeNames(dict(TABLES), "DEMO", "CORE")
    svc = CodeServices(lambda t: "SELECT 1 AS n FROM main.core.orders", lambda t: [], names)
    return svc


def _fn(*statements):
    return SimpleNamespace(body=SimpleNamespace(body=list(statements)))


def test_javascript_translator_on_hand_built_trees(monkeypatch):
    """The port is exercised without esprima: ``var rs = snowflake.execute({sqlText: ...}); rs.next(); return
    rs.getColumnValue(1) + 1;`` through the real translator rules and the notebook assembly."""
    execute = _n("MemberExpression", object=_id("snowflake"), property=_id("execute"), computed=False)
    spec = _n("ObjectExpression", properties=[_n("Property", key=_id("sqlText"), value=_lit("SELECT COUNT(*) FROM ORDERS"),
                                                  computed=False, kind="init")])
    decl = _n("VariableDeclaration", declarations=[_n("VariableDeclarator", id=_id("rs"),
                                                      init=_n("CallExpression", callee=execute, arguments=[spec]))])
    nxt = _n("ExpressionStatement", expression=_n("CallExpression", callee=_n(
        "MemberExpression", object=_id("rs"), property=_id("next"), computed=False), arguments=[]))
    get = _n("CallExpression", callee=_n("MemberExpression", object=_id("rs"), property=_id("getColumnValue"),
                                         computed=False), arguments=[_lit(1)])
    ret = _n("ReturnStatement", argument=_n("BinaryExpression", operator="+", left=get, right=_lit(1.0)))
    monkeypatch.setattr(js, "_parse", lambda body: _fn(decl, nxt, ret))
    obj = parse_code_object({"engine": "javascript_procedure", "asset_id": "a:proc:acme.DEMO.CORE.proc/P(NUMBER)",
                             "definition": "CREATE PROCEDURE DEMO.CORE.P(N NUMBER) RETURNS NUMBER LANGUAGE JAVASCRIPT AS "
                                           "$$x$$", "language": "javascript"})
    code, notes = js.convert_javascript_procedure(obj, _services(), "# NODE")
    ast.parse(code)
    assert "_sf_execute(\"SELECT 1 AS n FROM main.core.orders\")" in code       # tier 0 text, not the Snowflake text
    assert "COUNT" not in code and "rs.next()" in code and "return _add(rs.getColumnValue(1), 1.0)" in code
    assert code.rstrip().endswith('dbutils.notebook.exit("" if _result is None else _s(_result))')
    assert any(n.startswith("SEM004|Notebook runs with the job principal") for n in notes)


def test_javascript_translator_refuses_what_it_has_no_rule_for_with_the_line(monkeypatch):
    bad = _n("ExpressionStatement", expression=_n("CallExpression", callee=_id("eval"), arguments=[_lit("1")]))
    monkeypatch.setattr(js, "_parse", lambda body: _fn(bad))
    obj = parse_code_object({"engine": "udf_js", "asset_id": "a:func:acme.DEMO.CORE.func/F()",
                             "definition": "CREATE FUNCTION DEMO.CORE.F() RETURNS VARCHAR LANGUAGE JAVASCRIPT AS $$x$$",
                             "language": "javascript"})
    with pytest.raises(CodeRefused, match=r"line 1: eval\(\) is not declared"):
        js.convert_javascript_udf(obj, "main.d.f", "", "STRING", _services())


# ---------------------------------------------------------------------------------------------- L4
def test_the_pre_pass_collects_scalar_return_types_so_a_call_into_a_variable_converts():
    callee = """CREATE OR REPLACE PROCEDURE DEMO.CORE.GET_COUNT() RETURNS NUMBER LANGUAGE SQL AS
$$
DECLARE n NUMBER DEFAULT 0;
BEGIN
  SELECT COUNT(*) INTO :n FROM DEMO.CORE.ORDERS;
  RETURN n;
END;
$$"""
    plain = """CREATE OR REPLACE PROCEDURE DEMO.CORE.NO_VALUE() RETURNS VARCHAR LANGUAGE SQL AS
$$
BEGIN
  INSERT INTO DEMO.CORE.DAILY SELECT 1, 2;
END;
$$"""
    doc = {"engine": "sql_procedure", "asset_id": "a:proc:acme.DEMO.CORE.proc/GET_COUNT()", "definition": callee}
    assert cu.procedure_return_type(doc) == ("DEMO.CORE.GET_COUNT", "NUMBER")
    assert cu.procedure_return_type({**doc, "definition": plain}) is None
    assert cu.procedure_return_type({"engine": "udf_sql", "definition": "x"}) is None


def test_prepare_batch_runs_the_pre_pass_so_a_caller_converts_whatever_the_batch_order(tmp_path):
    """L4: ``prepare_batch`` reads every procedure's RETURNS first; the caller (listed BEFORE its callee) converts."""
    import json

    from packs.snowflake.batch import prepare_batch
    from packs.snowflake.run import make_unit_context, short_key
    from tests.packs.snowflake_bundle import etl, table

    callee = ("CREATE OR REPLACE PROCEDURE SALES_DB.CORE.GET_COUNT() RETURNS NUMBER LANGUAGE SQL AS\n$$\nDECLARE n NUMBER "
              "DEFAULT 0;\nBEGIN\n  SELECT COUNT(*) INTO :n FROM CORE.ORDERS;\n  RETURN n;\nEND;\n$$")
    caller = ("CREATE OR REPLACE PROCEDURE SALES_DB.CORE.TOTALS() RETURNS NUMBER LANGUAGE SQL AS\n$$\nDECLARE v NUMBER;\n"
              "BEGIN\n  v := (CALL SALES_DB.CORE.GET_COUNT());\n  RETURN v;\nEND;\n$$")
    orders = table("CORE", "ORDERS")
    rows = [etl(1, "TOTALS", "CORE", "sql_procedure", caller, objtype="proc", sig="", inputs=[orders]),
            etl(2, "GET_COUNT", "CORE", "sql_procedure", callee, objtype="proc", sig="", inputs=[orders])]
    bundle = tmp_path / "bundle"
    (bundle / "etls").mkdir(parents=True)
    for row, doc in rows:
        (bundle / "etls" / f"{row['name']}.json").write_text(json.dumps(doc), encoding="utf-8")
    manifest = {"etls": [r for r, _ in rows], "table_map": {orders["dataset_id"]: orders["table"]}, "target_map": {},
                "source": {"id": "sfdemo"}, "target": {"target_catalog": "main"}}
    batch = prepare_batch(manifest, bundle, tmp_path / "work", source_id="sfdemo",
                          settings=TranslationSettings(tiers=("human",)))
    assert batch.procedure_returns == {"SALES_DB.CORE.GET_COUNT": "NUMBER", "SALES_DB.CORE.TOTALS": "NUMBER"}
    row, doc = rows[0]
    from packs.snowflake import contract as ct
    unit_doc = ct.unit_doc(row, doc)
    ctx = make_unit_context(unit_doc, short_key("sfdemo__TOTALS"), batch)
    assert ctx.procedure_returns == batch.procedure_returns
    units = asyncio.run(tr.translate_etl(unit_doc, ctx))
    assert units[0].status == "resolved" and "get_count__ret" in units[0].sql, units[0].reasons
