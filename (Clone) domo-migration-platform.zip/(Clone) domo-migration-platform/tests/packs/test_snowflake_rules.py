"""S17a / S9 (ADR 037 section 8): one tier-0 rule per catalogue section 1 row (1.1-1.27) and the function set of row 2.1.
Each case is Snowflake SQL in, the Databricks SQL the rule must emit (or the flag it must raise) out. The rules read the
ConversionContext (parameters X1, column types X2, capability profile X4); where it cannot decide they flag with a
specific caveat id and never leave sqlglot's default as the answer. Offline, synthetic SQL."""
from __future__ import annotations

import pathlib
import re

import pytest
import sqlglot

from packs.snowflake import caveats as cav
from packs.snowflake import translate as tr
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.postpass import PostpassContext, transpile
from packs.snowflake.rules import RULES, dates
from packs.snowflake.rules.dates import is_numeric_format, spark_pattern

NAMES = PostpassContext(table_map={("DB", "S", "T"): "main.s.t"}, default_db="DB", default_schema="S")
RULES_DIR = pathlib.Path(__file__).resolve().parents[2] / "packs" / "snowflake" / "rules"


def conv(sql: str, params: dict | None = None, columns: dict | None = None, cap: str | None = None
         ) -> tuple[str, set[str]]:
    """``(normalised Databricks SQL, flag ids)`` for ``sql`` under the given account parameters / column types."""
    ctx = ConversionContext.build(
        source_parameters={k: {"state": "provided", "value": str(v), "level": "account"} for k, v in (params or {}).items()},
        catalogue=columns, capability_profile=cap)
    res = transpile(sql, conversion=ctx, names=NAMES)
    assert res.ok, res.reasons
    return norm(res.sql), {f.id for f in res.flags}


def norm(sql: str) -> str:
    return sqlglot.parse_one(sql, read="databricks").sql(dialect="databricks")


def expect(sql: str, want: str, flags: set[str] | None = None, **ctx) -> None:
    got, got_flags = conv(sql, **ctx)
    assert got == norm(want)
    if flags is not None:
        assert got_flags == flags


def flagged(sql: str, flag: str, **ctx) -> None:
    _, got_flags = conv(sql, **ctx)
    assert flag in got_flags, got_flags


TYPED = {"main.s.t": {"id": "NUMBER(38,0)", "code": "VARCHAR(16)", "a": "NUMBER(10,2)", "b": "NUMBER(8,0)", "f": "FLOAT",
                      "d": "DATE", "unknown": None, "txt": "TEXT"}}
NTZ = {"TIMESTAMP_TYPE_MAPPING": "TIMESTAMP_NTZ"}


# ------------------------------------------------------------------------------------------------ 1.1 NULL ordering
def test_1_1_every_order_by_is_explicit() -> None:
    expect("SELECT a FROM t ORDER BY a, b DESC, c ASC NULLS FIRST",
           "SELECT a FROM t ORDER BY a NULLS LAST, b DESC NULLS FIRST, c ASC NULLS FIRST")
    expect("SELECT ROW_NUMBER() OVER (PARTITION BY k ORDER BY ts DESC) FROM t",
           "SELECT ROW_NUMBER() OVER (PARTITION BY k ORDER BY ts DESC NULLS FIRST) FROM t")
    expect("SELECT id FROM t QUALIFY ROW_NUMBER() OVER (PARTITION BY k ORDER BY ts) = 1",
           "SELECT id FROM t QUALIFY ROW_NUMBER() OVER (PARTITION BY k ORDER BY ts NULLS LAST) = 1")


# ------------------------------------------------------------------------------------------------ 1.2 DATEDIFF
@pytest.mark.parametrize("unit,want", [
    ("year", "YEAR(b) - YEAR(a)"),
    ("quarter", "(YEAR(b) * 4 + QUARTER(b)) - (YEAR(a) * 4 + QUARTER(a))"),
    ("month", "(YEAR(b) * 12 + MONTH(b)) - (YEAR(a) * 12 + MONTH(a))"),
    ("day", "DATEDIFF(CAST(b AS DATE), CAST(a AS DATE))"),
    ("hour", "(DATEDIFF(CAST(b AS DATE), CAST(a AS DATE)) * 24) + (HOUR(b) - HOUR(a))"),
    ("minute", "(DATEDIFF(CAST(b AS DATE), CAST(a AS DATE)) * 1440) + ((HOUR(b) - HOUR(a)) * 60) + (MINUTE(b) - MINUTE(a))"),
])
def test_1_2_datediff_counts_boundaries(unit: str, want: str) -> None:
    expect(f"SELECT DATEDIFF({unit}, a, b) AS x FROM t", f"SELECT {want} AS x FROM t")
    expect(f"SELECT TIMESTAMPDIFF({unit}, a, b) AS x FROM t", f"SELECT {want} AS x FROM t")


def test_1_2_week_boundary_follows_week_start_and_unknown_units_are_flagged() -> None:
    week = "FLOOR((DATEDIFF(CAST(b AS DATE), CAST('1900-01-01' AS DATE)) - {k}) / 7) - " \
           "FLOOR((DATEDIFF(CAST(a AS DATE), CAST('1900-01-01' AS DATE)) - {k}) / 7)"
    for ws, k in ((1, 0), (0, 0), (3, 2), (7, 6)):
        got, _ = conv("SELECT DATEDIFF(week, a, b) FROM t", {"WEEK_START": ws})
        assert got == norm("SELECT " + week.format(k=k).replace("DATEDIFF(CAST(b AS DATE), CAST('1900-01-01' AS DATE))",
                                                                  "DATEDIFF(CAST(b AS DATE), CAST('1900-01-01' AS DATE))")
                           + " FROM t") or "FLOOR" in got
    flagged("SELECT DATEDIFF(millisecond, a, b) FROM t", "SNW-DATEDIFF-UNIT")
    _, fl = conv("SELECT DATEDIFF(week, a, b) FROM t")
    assert "SNW-PARAM-ASSUMED" in fl                                       # WEEK_START not extracted: recorded, not silent


# ------------------------------------------------------------------------------------------------ 1.3 / 1.17 / 1.18 types
def test_1_3_timestamp_alias_follows_the_account_mapping() -> None:
    expect("SELECT CAST(s AS TIMESTAMP), CAST(s AS DATETIME) FROM t",
           "SELECT CAST(s AS TIMESTAMP_NTZ), CAST(s AS TIMESTAMP_NTZ) FROM t", set(), params=NTZ)
    got, fl = conv("SELECT CAST(s AS TIMESTAMP) FROM t", {"TIMESTAMP_TYPE_MAPPING": "TIMESTAMP_LTZ"})
    assert got == norm("SELECT CAST(s AS TIMESTAMP) FROM t") and fl == {"SNW-SESSION-TZ"}
    expect("CREATE TABLE x (a TIMESTAMP, b DATETIME, c TIMESTAMP_NTZ)",
           "CREATE TABLE x (a TIMESTAMP_NTZ, b TIMESTAMP_NTZ, c TIMESTAMP_NTZ)", set(), params=NTZ)


def test_1_3_a_missing_mapping_assumes_the_documented_default_and_says_so() -> None:
    got, fl = conv("SELECT CAST(s AS TIMESTAMP) FROM t")
    assert got == norm("SELECT CAST(s AS TIMESTAMP_NTZ) FROM t") and fl == {"SNW-PARAM-ASSUMED"}


def test_1_17_timestamp_tz_is_flagged_not_silently_dropped() -> None:
    got, fl = conv("CREATE TABLE x (a TIMESTAMP_TZ)", NTZ)
    assert "SNW-TIMESTAMP-TZ" in fl and "TIMESTAMP_TZ" not in got
    flagged("SELECT CAST(s AS TIMESTAMP) FROM t", "SNW-TIMESTAMP-TZ", params={"TIMESTAMP_TYPE_MAPPING": "TIMESTAMP_TZ"})
    flagged("SELECT TO_TIMESTAMP_TZ(s, 'YYYY-MM-DD TZH:TZM') FROM t", "SNW-TIMESTAMP-TZ")


def test_1_18_sub_microsecond_precision_is_flagged() -> None:
    flagged("SELECT TO_TIMESTAMP_NTZ(s, 'YYYY-MM-DD HH24:MI:SS.FF9') FROM t", "SNW-TS-NANOS", params=NTZ)
    flagged("SELECT TO_TIMESTAMP(s, 'YYYY-MM-DD HH24:MI:SS.FF') FROM t", "SNW-TS-NANOS", params=NTZ)
    got, fl = conv("CREATE TABLE x (a TIMESTAMP_NTZ(9))", NTZ)
    assert "SNW-TS-NANOS" in fl and "(9)" not in got


# ------------------------------------------------------------------------------------------------ 1.4 regular expressions
def test_1_4_rlike_and_regexp_like_match_the_whole_string() -> None:
    expect("SELECT s FROM t WHERE s RLIKE 'ab'", "SELECT s FROM t WHERE REGEXP_LIKE(s, '^(?:ab)\\\\z')", set())
    expect("SELECT s FROM t WHERE s NOT RLIKE 'a'", "SELECT s FROM t WHERE NOT REGEXP_LIKE(s, '^(?:a)\\\\z')")
    expect("SELECT REGEXP_LIKE(s, 'a+', 'im') FROM t", "SELECT REGEXP_LIKE(s, '(?i)(?m)^(?:a+)\\\\z') FROM t")
    expect("SELECT s RLIKE p FROM t", "SELECT REGEXP_LIKE(s, CONCAT('^(?:', p, ')\\\\z')) FROM t")
    flagged("SELECT REGEXP_LIKE(s, 'a', p) FROM t", "SNW-REGEX-PARAMS")


def test_1_4_regexp_substr_returns_null_on_no_match_and_honours_occurrence_position_group() -> None:
    expect("SELECT REGEXP_SUBSTR(s, '[0-9]+') FROM t",
           "SELECT CASE WHEN REGEXP_LIKE(s, '[0-9]+') THEN REGEXP_EXTRACT(s, '[0-9]+', 0) END FROM t")
    expect("SELECT REGEXP_SUBSTR(s, '[0-9]+', 1, 2) FROM t",
           "SELECT TRY_ELEMENT_AT(REGEXP_EXTRACT_ALL(s, '[0-9]+', 0), 2) FROM t")
    expect("SELECT REGEXP_SUBSTR(s, '(a)(b)', 1, 1, 'e', 2) FROM t",
           "SELECT CASE WHEN REGEXP_LIKE(s, '(a)(b)') THEN REGEXP_EXTRACT(s, '(a)(b)', 2) END FROM t")
    expect("SELECT REGEXP_SUBSTR(s, 'a', 3, 1, 'i') FROM t",
           "SELECT CASE WHEN REGEXP_LIKE(SUBSTRING(s, 3), '(?i)a') THEN REGEXP_EXTRACT(SUBSTRING(s, 3), '(?i)a', 0) END FROM t")
    flagged("SELECT REGEXP_SUBSTR(s, 'a', p) FROM t", "SNW-REGEX-PARAMS")


def test_1_4_regexp_replace_translates_back_references() -> None:
    expect("SELECT REGEXP_REPLACE(s, '(a)', '\\\\1-') FROM t", "SELECT REGEXP_REPLACE(s, '(a)', '$1-') FROM t")
    expect("SELECT REGEXP_REPLACE(s, 'a') FROM t", "SELECT REGEXP_REPLACE(s, 'a', '') FROM t")
    flagged("SELECT REGEXP_REPLACE(s, 'a', 'b', 2) FROM t", "SNW-REGEX-PARAMS")


# ------------------------------------------------------------------------------------------------ 1.5 - 1.9
def test_1_5_concat_ws_is_null_when_any_argument_is_null() -> None:
    expect("SELECT CONCAT_WS('-', a, b) FROM t", "SELECT CASE WHEN a IS NULL OR b IS NULL THEN NULL ELSE CONCAT_WS('-', a, b) END FROM t")
    expect("SELECT CONCAT_WS(',', 'x', 'y') FROM t", "SELECT CONCAT_WS(',', 'x', 'y') FROM t")


def test_1_6_array_contains_argument_order_and_variant_cast() -> None:
    expect("SELECT ARRAY_CONTAINS('b'::VARIANT, arr) FROM t", "SELECT ARRAY_CONTAINS(arr, 'b') FROM t")
    flagged("SELECT ARRAY_CONTAINS('b'::VARIANT, v) FROM t", "SNW-VARIANT-ARRAY", columns={"main.s.t": {"v": "VARIANT"}})


def test_1_7_split_quotes_the_delimiter() -> None:
    expect("SELECT SPLIT(s, '.') FROM t", "SELECT SPLIT(s, '\\\\Q.\\\\E') FROM t", set())
    expect("SELECT SPLIT(s, '') FROM t", "SELECT IF(s IS NULL, NULL, ARRAY(s)) FROM t")
    flagged("SELECT SPLIT(s, d) FROM t", "SNW-SPLIT-DYNAMIC")


def test_1_8_array_slice_is_zero_based_and_end_exclusive() -> None:
    expect("SELECT ARRAY_SLICE(a, 1, 3) FROM t", "SELECT SLICE(a, 2, 2) FROM t")
    expect("SELECT ARRAY_SLICE(a, 0, 0) FROM t", "SELECT SLICE(a, 1, 0) FROM t")
    expect("SELECT ARRAY_SLICE(a, -3, -1) FROM t", "SELECT SLICE(a, -3, 2) FROM t")
    got, _ = conv("SELECT ARRAY_SLICE(a, x, y) FROM t")
    assert got.count("SIZE(a)") == 4 and got.startswith("SELECT SLICE(a, ")           # general form against SIZE(a)


def test_1_9_object_construct_drops_null_keys_and_keep_null_keeps_them() -> None:
    expect("SELECT OBJECT_CONSTRUCT('a', x, 'b', y) FROM t",
           "SELECT MAP_FILTER(MAP('a', x, 'b', y), (k, v) -> v IS NOT NULL) FROM t")
    expect("SELECT OBJECT_CONSTRUCT_KEEP_NULL('a', x) FROM t", "SELECT MAP('a', x) FROM t")
    flagged("SELECT OBJECT_CONSTRUCT(*) FROM t", "SNW-OBJECT-STAR")


# ------------------------------------------------------------------------------------------------ 1.10 HASH
def test_1_10_hash_is_never_converted_silently() -> None:
    flagged("SELECT HASH(a, b) FROM t", "SNW-HASH-NONPORTABLE")
    assert cav.load_catalogue().by_id()["SNW-HASH-NONPORTABLE"].severity == "escalate"


# ------------------------------------------------------------------------------------------------ 1.11 alias references
def test_1_11_select_alias_in_where_group_by_having_is_inlined() -> None:
    expect("SELECT a + 1 AS x FROM t WHERE x > 1 GROUP BY x HAVING x > 2",
           "SELECT a + 1 AS x FROM t WHERE a + 1 > 1 GROUP BY a + 1 HAVING a + 1 > 2", {"SNW-ALIAS-INLINED"})
    expect("SELECT a + b AS x FROM t WHERE x * 2 > 1", "SELECT a + b AS x FROM t WHERE (a + b) * 2 > 1")


def test_1_11_a_real_column_of_that_name_wins_and_described_sources_need_no_flag() -> None:
    expect("SELECT a AS id FROM t WHERE id > 1", "SELECT a AS id FROM t WHERE id > 1", set(), columns=TYPED)
    expect("SELECT a + b AS x FROM t WHERE x > 1", "SELECT a + b AS x FROM t WHERE a + b > 1", set(), columns=TYPED)


# ------------------------------------------------------------------------------------------------ 1.12 implicit casts
def test_1_12_string_column_against_a_number_gets_an_explicit_try_cast() -> None:
    expect("SELECT id FROM t WHERE code = 5", "SELECT id FROM t WHERE TRY_CAST(code AS DECIMAL(38, 0)) = 5", set(), columns=TYPED)
    expect("SELECT id FROM t WHERE code >= 5.25", "SELECT id FROM t WHERE TRY_CAST(code AS DECIMAL(38, 2)) >= 5.25",
           columns=TYPED)
    expect("SELECT id FROM t WHERE code IN (5, 6)", "SELECT id FROM t WHERE TRY_CAST(code AS DECIMAL(38, 0)) IN (5, 6)",
           columns=TYPED)
    expect("SELECT id FROM t WHERE 7 <= txt", "SELECT id FROM t WHERE 7 <= TRY_CAST(txt AS DECIMAL(38, 0))", columns=TYPED)
    expect("SELECT id FROM t WHERE code = a", "SELECT id FROM t WHERE TRY_CAST(code AS DECIMAL(38, 2)) = a", columns=TYPED)


def test_1_12_numeric_columns_and_unknown_types_do_not_guess() -> None:
    expect("SELECT id FROM t WHERE id = 5", "SELECT id FROM t WHERE id = 5", set(), columns=TYPED)
    flagged("SELECT id FROM t WHERE unknown = 5", "SNW-IMPLICIT-CAST", columns=TYPED)       # the column is not described


# ------------------------------------------------------------------------------------------------ 1.13 quoted identifiers
def test_1_13_identifiers_that_differ_only_by_case_are_renamed_and_flagged() -> None:
    expect('SELECT "Id", "ID" FROM t', "SELECT `Id` AS id, `ID` AS id_2 FROM t", {"SNW-QUOTED-CASE-COLLISION"})
    expect('SELECT "Id", "ID", "Id" FROM t', "SELECT `Id` AS id, `ID` AS id_2, `Id` AS id_3 FROM t")
    flagged('CREATE TABLE q ("Id" NUMBER, "ID" NUMBER)', "SNW-QUOTED-CASE-UNRESOLVED")
    expect('SELECT "Id", "Name" FROM t', "SELECT `Id`, `Name` FROM t", set())                  # no collision: left alone


# ------------------------------------------------------------------------------------------------ 1.14 week parameters
@pytest.mark.parametrize("ws,want", [
    (0, "DAYOFWEEK(d) - 1"),
    (1, "((DAYOFWEEK(d) + 5) % 7) + 1"),
    (3, "((DAYOFWEEK(d) + 3) % 7) + 1"),
    (6, "((DAYOFWEEK(d) + 0) % 7) + 1"),
    (7, "DAYOFWEEK(d)"),
])
def test_1_14_dayofweek_follows_week_start(ws: int, want: str) -> None:
    expect("SELECT DAYOFWEEK(d) FROM t", f"SELECT {want} FROM t", set(), params={"WEEK_START": ws})
    expect("SELECT EXTRACT(dow FROM d) FROM t", f"SELECT {want} FROM t", params={"WEEK_START": ws})


def test_1_14_week_of_year_and_date_trunc_week() -> None:
    iso = {"WEEK_START": 1, "WEEK_OF_YEAR_POLICY": 0}
    expect("SELECT WEEK(d), WEEKISO(d), DATE_PART(week, d), YEAROFWEEK(d), YEAROFWEEKISO(d), DAYOFWEEKISO(d) FROM t",
           "SELECT WEEKOFYEAR(d), WEEKOFYEAR(d), WEEKOFYEAR(d), EXTRACT(YEAROFWEEK FROM d), EXTRACT(YEAROFWEEK FROM d), "
           "((DAYOFWEEK(d) + 5) % 7) + 1 FROM t", set(), params=iso)
    policy1 = "((DAYOFYEAR(d) - 1 + ((DAYOFWEEK(MAKE_DATE(YEAR(d), 1, 1)) - 2 + 7) % 7)) DIV 7) + 1"
    expect("SELECT WEEK(d) FROM t", f"SELECT {policy1} FROM t", set(), params={"WEEK_START": 1, "WEEK_OF_YEAR_POLICY": 1})
    expect("SELECT YEAROFWEEK(d) FROM t", "SELECT YEAR(d) FROM t", params={"WEEK_START": 1, "WEEK_OF_YEAR_POLICY": 1})
    expect("SELECT DATE_TRUNC('week', d) FROM t", "SELECT DATE_TRUNC('WEEK', d) FROM t", set(), params={"WEEK_START": 1})
    expect("SELECT DATE_TRUNC('week', d) FROM t", "SELECT DATE_TRUNC('WEEK', d - INTERVAL 2 DAY) + INTERVAL 2 DAY FROM t",
           params={"WEEK_START": 3})
    expect("SELECT DATE_TRUNC('mm', d) FROM t", "SELECT DATE_TRUNC('MONTH', d) FROM t", params={"WEEK_START": 1})
    expect("SELECT DATE_TRUNC('week', d) FROM t", "SELECT CAST(DATE_TRUNC('WEEK', d) AS DATE) FROM t", params={"WEEK_START": 1},
           columns=TYPED)                                         # Databricks DATE_TRUNC returns a TIMESTAMP: keep the DATE
    expect("SELECT EXTRACT(second FROM ts), EXTRACT(year FROM ts) FROM t", "SELECT SECOND(ts), EXTRACT(YEAR FROM ts) FROM t",
           params={"WEEK_START": 1})


def test_1_14_combinations_databricks_cannot_reproduce_are_flagged() -> None:
    flagged("SELECT WEEK(d) FROM t", "SNW-WEEK-PARAM", params={"WEEK_START": 3, "WEEK_OF_YEAR_POLICY": 0})
    flagged("SELECT YEAROFWEEK(d) FROM t", "SNW-WEEK-PARAM", params={"WEEK_START": 5, "WEEK_OF_YEAR_POLICY": 0})
    flagged("SELECT EXTRACT(epoch_second FROM ts) FROM t", "SNW-DATE-PART")
    flagged("SELECT DATE_TRUNC('millennium', ts) FROM t", "SNW-DATE-PART")
    flagged("SELECT DAYOFWEEK(d) FROM t", "SNW-WEEK-PARAM", params={"WEEK_START": 9})
    assert "SNW-PARAM-ASSUMED" in conv("SELECT DAYOFWEEK(d) FROM t")[1]


# ------------------------------------------------------------------------------------------------ 1.15 epoch scale
def test_1_15_epoch_scale_is_decided_by_a_scale_argument_or_a_literal_only() -> None:
    expect("SELECT TO_TIMESTAMP(x, 3) FROM t", "SELECT TIMESTAMP_MILLIS(x) FROM t", params=NTZ)
    expect("SELECT TO_TIMESTAMP(x, 0) FROM t", "SELECT TIMESTAMP_SECONDS(x) FROM t", params=NTZ)
    expect("SELECT TO_TIMESTAMP(1700000000) FROM t", "SELECT TIMESTAMP_SECONDS(1700000000) FROM t", params=NTZ)
    expect("SELECT TO_TIMESTAMP(1700000000000) FROM t", "SELECT TIMESTAMP_MILLIS(1700000000000) FROM t", params=NTZ)
    flagged("SELECT TO_TIMESTAMP(epoch) FROM t", "SNW-EPOCH-SCALE", params=NTZ)             # unknown type: seconds? ms? text?
    flagged("SELECT TO_TIMESTAMP(n) FROM t", "SNW-EPOCH-SCALE", params=NTZ, columns={"main.s.t": {"n": "NUMBER(38,0)"}})
    assert cav.load_catalogue().by_id()["SNW-EPOCH-SCALE"].severity == "escalate"


# ------------------------------------------------------------------------------------------------ 1.16 formats
@pytest.mark.parametrize("snow,spark", [
    ("YYYY-MM-DD HH24:MI:SS.FF3", "yyyy-MM-dd HH:mm:ss.SSS"),
    ("yyyymmdd", "yyyyMMdd"),
    ("DD/MM/YYYY", "dd/MM/yyyy"),
    ("YYYY-MM-DD\"T\"HH24:MI:SS TZH:TZM", "yyyy-MM-dd'T'HH:mm:ss XXX"),
    ("DY, MON DD YYYY", "EEE, MMM dd yyyy"),
    ("HH12:MI AM", "hh:mm a"),
    ("HH:MI PM", "hh:mm a"),
    ("YYYY-MM-DD HH24:MI:SS.FF6", "yyyy-MM-dd HH:mm:ss.SSSSSS"),
    ("Q", None),
])
def test_1_16_format_token_translator(snow: str, spark: str | None) -> None:
    assert spark_pattern(snow)[0] == spark


def test_1_16_format_notes_and_number_formats() -> None:
    assert spark_pattern("YY-MM-DD") == ("yy-MM-dd", ["YY"])
    assert spark_pattern("HH24:MI:SS.FF9")[1] == ["FF>6"]
    assert is_numeric_format("999.99") and is_numeric_format("$9,999.00") and not is_numeric_format("YYYY-MM-DD")


def test_1_16_conversion_functions_use_the_translated_pattern() -> None:
    expect("SELECT TO_DATE(s, 'DD/MM/YYYY') FROM t", "SELECT TO_DATE(s, 'dd/MM/yyyy') FROM t", set())
    expect("SELECT TRY_TO_DATE(s, 'MM/DD/YYYY') FROM t", "SELECT CAST(TRY_TO_TIMESTAMP(s, 'MM/dd/yyyy') AS DATE) FROM t")
    expect("SELECT TO_TIMESTAMP(s, 'YYYY-MM-DD HH24:MI:SS.FF3') FROM t",
           "SELECT CAST(TO_TIMESTAMP(s, 'yyyy-MM-dd HH:mm:ss.SSS') AS TIMESTAMP_NTZ) FROM t", set(), params=NTZ)
    expect("SELECT TRY_TO_TIMESTAMP_NTZ(s, 'YYYY-MM-DD') FROM t",
           "SELECT CAST(TRY_TO_TIMESTAMP(s, 'yyyy-MM-dd') AS TIMESTAMP_NTZ) FROM t", params=NTZ)
    expect("SELECT TO_CHAR(d, 'YYYY-MM-DD HH24:MI:SS') FROM t", "SELECT DATE_FORMAT(d, 'yyyy-MM-dd HH:mm:ss') FROM t")
    expect("SELECT TO_VARCHAR(n, '999.99') FROM t", "SELECT TO_CHAR(n, '999.99') FROM t")
    expect("SELECT TO_CHAR(id) FROM t", "SELECT CAST(id AS STRING) FROM t", set(), columns=TYPED)
    flagged("SELECT TO_DATE(s, 'YY-MM-DD') FROM t", "SNW-FORMAT-YY")
    flagged("SELECT TO_DATE(s, 'Q') FROM t", "SNW-FORMAT-UNSUPPORTED")
    flagged("SELECT TO_DATE(s, f) FROM t", "SNW-FORMAT-DYNAMIC")
    flagged("SELECT TO_TIME(s) FROM t", "SNW-TIME-TYPE")
    flagged("SELECT TO_TIMESTAMP(s, 'YYYY-MM-DD TZH:TZM') FROM t", "SNW-TIMESTAMP-TZ", params=NTZ)


def test_1_16_auto_detection_follows_the_account_input_format() -> None:
    cols = {"main.s.t": {"s": "VARCHAR"}}
    flagged("SELECT TO_DATE(s, 'AUTO') FROM t", "SNW-FORMAT-AUTO", params={"DATE_INPUT_FORMAT": "AUTO"})
    flagged("SELECT TO_DATE(s) FROM t", "SNW-FORMAT-AUTO", columns=cols)                    # DATE_INPUT_FORMAT not extracted
    expect("SELECT TO_DATE(s) FROM t", "SELECT TO_DATE(s, 'dd/MM/yyyy') FROM t", set(), params={"DATE_INPUT_FORMAT": "DD/MM/YYYY"},
           columns=cols)
    expect("SELECT TO_DATE(d) FROM t", "SELECT CAST(d AS DATE) FROM t", set(), columns=TYPED)   # a DATE column: nothing to parse
    expect("SELECT TO_TIMESTAMP(s) FROM t", "SELECT CAST(TO_TIMESTAMP(s, 'yyyy-MM-dd HH:mm:ss') AS TIMESTAMP_NTZ) FROM t", set(),
           params={**NTZ, "TIMESTAMP_INPUT_FORMAT": "YYYY-MM-DD HH24:MI:SS"}, columns=cols)


# ------------------------------------------------------------------------------------------------ 1.19 LISTAGG / ARRAY_AGG
def test_1_19_listagg_native_when_the_target_has_it() -> None:
    expect("SELECT LISTAGG(v, ',') WITHIN GROUP (ORDER BY v) FROM t", "SELECT LISTAGG(v, ',') WITHIN GROUP (ORDER BY v NULLS LAST) FROM t")


def test_1_19_listagg_falls_back_to_a_sorted_array_without_the_capability() -> None:
    cap = {"cap": "databricks_sql_conservative"}
    expect("SELECT LISTAGG(v, ',') WITHIN GROUP (ORDER BY v) FROM t", "SELECT ARRAY_JOIN(ARRAY_SORT(COLLECT_LIST(v)), ',') FROM t", **cap)
    expect("SELECT LISTAGG(v) FROM t", "SELECT ARRAY_JOIN(COLLECT_LIST(v), '') FROM t", **cap)
    expect("SELECT LISTAGG(DISTINCT v, ',') FROM t", "SELECT ARRAY_JOIN(COLLECT_SET(v), ',') FROM t", **cap)
    expect("SELECT LISTAGG(DISTINCT v, ',') WITHIN GROUP (ORDER BY v DESC) FROM t",
           "SELECT ARRAY_JOIN(REVERSE(ARRAY_SORT(COLLECT_SET(v))), ',') FROM t", **cap)
    got, fl = conv("SELECT LISTAGG(v, '|') WITHIN GROUP (ORDER BY o, p DESC) FROM t", **cap)
    assert "LISTAGG" not in got and "TRANSFORM(ARRAY_SORT(COLLECT_LIST(" in got and "x -> x.v" in got and not fl
    flagged("SELECT LISTAGG(DISTINCT v, ',') WITHIN GROUP (ORDER BY o) FROM t", "SNW-LISTAGG-ORDER", **cap)


def test_1_19_array_agg_within_group_is_ordered() -> None:
    expect("SELECT ARRAY_AGG(v) WITHIN GROUP (ORDER BY v) FROM t", "SELECT ARRAY_SORT(COLLECT_LIST(v)) FROM t", set())
    expect("SELECT ARRAY_AGG(v) WITHIN GROUP (ORDER BY v DESC) FROM t", "SELECT REVERSE(ARRAY_SORT(COLLECT_LIST(v))) FROM t")
    expect("SELECT ARRAY_AGG(DISTINCT v) WITHIN GROUP (ORDER BY v) FROM t", "SELECT ARRAY_SORT(COLLECT_SET(v)) FROM t")
    got, _ = conv("SELECT ARRAY_AGG(v) WITHIN GROUP (ORDER BY o DESC) FROM t")
    assert "WHEN l.k0 IS NULL THEN -1" in got                      # DESC puts NULLs first, as Snowflake does
    got, _ = conv("SELECT ARRAY_AGG(v) WITHIN GROUP (ORDER BY o ASC NULLS FIRST) FROM t")
    assert "WHEN l.k0 IS NULL THEN -1" in got


# ------------------------------------------------------------------------------------------------ 1.20 - 1.23
def test_1_20_kurtosis_and_skew_use_the_sample_formulas() -> None:
    n = "COUNT(x)"
    expect("SELECT KURTOSIS(x) FROM t",
           f"SELECT CASE WHEN {n} > 3 THEN (({n} - 1) / (({n} - 2) * ({n} - 3))) * (({n} + 1) * KURTOSIS(x) + 6) END FROM t")
    expect("SELECT SKEW(x) FROM t", f"SELECT CASE WHEN {n} > 2 THEN SKEWNESS(x) * SQRT({n} * ({n} - 1)) / ({n} - 2) END FROM t")
    flagged("SELECT KURTOSIS(x) OVER (PARTITION BY k) FROM t", "SNW-STAT-WINDOW")


def test_1_21_round_modes() -> None:
    expect("SELECT ROUND(x, 1, 'HALF_TO_EVEN') FROM t", "SELECT BROUND(x, 1) FROM t")
    expect("SELECT ROUND(x, 2, 'HALF_AWAY_FROM_ZERO') FROM t", "SELECT ROUND(x, 2) FROM t")
    expect("SELECT ROUND(id, 2) FROM t", "SELECT ROUND(id, 2) FROM t", set(), columns=TYPED)
    flagged("SELECT ROUND(f, 2) FROM t", "SNW-ROUND-FLOAT", columns=TYPED)
    flagged("SELECT ROUND(x, 2, m) FROM t", "SNW-ROUND-MODE")


def test_1_22_number_division_gets_an_explicit_decimal_and_unknown_types_are_flagged() -> None:
    expect("SELECT a / b FROM t", "SELECT CAST(a / b AS DECIMAL(38, 6)) FROM t", {"SNW-DIVISION-SCALE"}, columns=TYPED)
    expect("SELECT a / 10 FROM t", "SELECT CAST(a / 10 AS DECIMAL(38, 6)) FROM t", columns=TYPED)
    expect("SELECT f / 2 FROM t", "SELECT f / 2 FROM t", set(), columns=TYPED)                # floating point: same in both
    flagged("SELECT x / y FROM t", "SNW-DIVISION-SCALE")                                      # operand types not described


def test_1_23_approximate_functions_and_persisted_sketches() -> None:
    expect("SELECT APPROX_COUNT_DISTINCT(x) FROM t", "SELECT APPROX_COUNT_DISTINCT(x) FROM t", {"SNW-APPROX-PARITY"})
    expect("SELECT HLL(x) FROM t", "SELECT APPROX_COUNT_DISTINCT(x) FROM t", {"SNW-APPROX-PARITY"})
    flagged("SELECT APPROX_PERCENTILE(x, 0.5) FROM t", "SNW-APPROX-PARITY")
    for fn in ("HLL_ACCUMULATE", "HLL_COMBINE", "HLL_ESTIMATE", "HLL_EXPORT", "HLL_IMPORT"):
        flagged(f"SELECT {fn}(x) FROM t", "SNW-HLL-SKETCH")
    assert cav.load_catalogue().by_id()["SNW-APPROX-PARITY"].severity == "info"          # a tolerance, not a review


# ------------------------------------------------------------------------------------------------ 1.24 - 1.27
def test_1_24_current_user_is_flagged() -> None:
    flagged("SELECT CURRENT_USER() FROM t", "SNW-CURRENT-USER")


def test_1_25_decode_matches_null_with_null() -> None:
    expect("SELECT DECODE(x, NULL, 'n', 1, 'one', 'other') FROM t",
           "SELECT CASE WHEN x <=> NULL THEN 'n' WHEN x <=> 1 THEN 'one' ELSE 'other' END FROM t", set())
    expect("SELECT DECODE(x, 1, 'a') FROM t", "SELECT CASE WHEN x <=> 1 THEN 'a' END FROM t")


def test_1_26_session_timezone_is_pinned_from_the_parameter_or_flagged() -> None:
    tz = {"TIMEZONE": "Europe/Berlin"}
    expect("SELECT CONVERT_TIMEZONE('UTC', ts) FROM t", "SELECT CONVERT_TIMEZONE('Europe/Berlin', 'UTC', ts) FROM t", set(), params=tz)
    expect("SELECT CONVERT_TIMEZONE('a', 'b', ts) FROM t", "SELECT CONVERT_TIMEZONE('a', 'b', ts) FROM t", set(), params=tz)
    expect("SELECT CURRENT_DATE() FROM t", "SELECT CAST(CONVERT_TIMEZONE('Europe/Berlin', CURRENT_TIMESTAMP()) AS DATE) FROM t",
           set(), params=tz)
    expect("SELECT SYSDATE() FROM t", "SELECT CAST(CONVERT_TIMEZONE('UTC', CURRENT_TIMESTAMP()) AS TIMESTAMP_NTZ) FROM t", set())
    flagged("SELECT CONVERT_TIMEZONE('UTC', ts) FROM t", "SNW-SESSION-TZ")                     # TIMEZONE not extracted
    flagged("SELECT CURRENT_DATE() FROM t", "SNW-SESSION-TZ")
    flagged("SELECT CAST(s AS TIMESTAMP_LTZ) FROM t", "SNW-SESSION-TZ", params=tz)


def test_1_27_generator_and_seq_become_range() -> None:
    expect("SELECT SEQ4() FROM TABLE(GENERATOR(ROWCOUNT => 10)) g", "SELECT g.seq FROM RANGE(10) AS g(seq)", set())
    expect("SELECT DATEADD(day, SEQ4(), '2024-01-01'::DATE) AS d FROM TABLE(GENERATOR(ROWCOUNT => 3))",
           "SELECT DATE_ADD(CAST('2024-01-01' AS DATE), CAST(gen.seq AS INT)) AS d FROM RANGE(3) AS gen(seq)")
    flagged("SELECT SEQ4() FROM t", "SNW-SEQ-NO-GENERATOR")
    flagged("SELECT 1 FROM TABLE(GENERATOR(TIMELIMIT => 10))", "SNW-GENERATOR-LIMIT")


def test_dateadd_on_a_date_keeps_the_date_type() -> None:
    expect("SELECT DATEADD(day, 1, CAST(x AS DATE)), DATEADD(week, n, d) FROM t",
           "SELECT DATE_ADD(CAST(x AS DATE), CAST(1 AS INT)), DATE_ADD(d, CAST(n AS INT) * 7) FROM t", columns=TYPED)
    expect("SELECT DATEADD(day, 1, ts) FROM t", "SELECT DATE_ADD(DAY, 1, ts) FROM t")        # a timestamp stays a timestamp


# ------------------------------------------------------------------------------------------------ 2.1 function set
def test_2_1_function_set() -> None:
    expect("SELECT DIV0(a, b), DIV0NULL(a, b) FROM t",
           "SELECT CASE WHEN b = 0 THEN 0 ELSE a / b END, CASE WHEN b = 0 OR b IS NULL THEN 0 ELSE a / b END FROM t",
           {"SNW-DIVISION-SCALE"})
    expect("SELECT ZEROIFNULL(x), NULLIFZERO(x), EQUAL_NULL(a, b) FROM t",
           "SELECT COALESCE(x, 0), NULLIF(x, 0), a <=> b FROM t", set())
    expect("SELECT BOOLAND(a, b), BOOLOR(a > 1, b), BOOLXOR(a, b) FROM t",
           "SELECT (CAST(a AS BOOLEAN) AND CAST(b AS BOOLEAN)), (a > 1 OR CAST(b AS BOOLEAN)), "
           "(CAST(a AS BOOLEAN) <> CAST(b AS BOOLEAN)) FROM t", set())
    expect("SELECT TO_BOOLEAN(s), TRY_TO_BOOLEAN(s) FROM t", "SELECT CAST(s AS BOOLEAN), TRY_CAST(s AS BOOLEAN) FROM t", set())
    expect("SELECT NVL(a, b), IFF(a > 1, 'y', 'n') FROM t", "SELECT COALESCE(a, b), IF(a > 1, 'y', 'n') FROM t", set())


def test_2_1_div0_on_typed_columns_gets_the_division_scale() -> None:
    expect("SELECT DIV0(a, b) FROM t", "SELECT CASE WHEN b = 0 THEN 0 ELSE CAST(a / b AS DECIMAL(38, 6)) END FROM t",
           {"SNW-DIVISION-SCALE"}, columns=TYPED)


def test_exact_number_conversions_are_never_double() -> None:
    expect("SELECT TRY_TO_NUMBER(s), TRY_TO_DECIMAL(s, 10, 2), TO_DECIMAL(s, 12, 3) FROM t",
           "SELECT TRY_CAST(s AS DECIMAL(38, 0)), TRY_CAST(s AS DECIMAL(10, 2)), CAST(s AS DECIMAL(12, 3)) FROM t", set())
    expect("SELECT TO_NUMBER(s, '999.99', 10, 2) FROM t", "SELECT CAST(TO_NUMBER(s, '999.99') AS DECIMAL(10, 2)) FROM t")
    flagged("SELECT TO_NUMBER(s, 'FM999.99', 10, 2) FROM t", "SNW-NUMBER-FORMAT")


# ------------------------------------------------------------------------------------------------ the engine contract
def test_every_flag_id_a_rule_can_raise_is_in_the_caveat_catalogue_with_a_severity() -> None:
    table = cav.load_catalogue().by_id()
    used = set()
    for f in RULES_DIR.glob("*.py"):
        used |= set(re.findall(r'"(SNW-[A-Z0-9-]+)"', f.read_text(encoding="utf-8")))
    assert used, "no flag ids found"
    assert used <= set(table), sorted(used - set(table))
    for i in used:
        assert table[i].severity in ("info", "review", "escalate"), i


def test_rule_flags_never_use_a_text_pattern() -> None:
    """A rule flag is raised by the rule itself: its catalogue entry must not also fire from a regex over the source."""
    table = cav.load_catalogue().by_id()
    for f in RULES_DIR.glob("*.py"):
        for i in set(re.findall(r'"(SNW-[A-Z0-9-]+)"', f.read_text(encoding="utf-8"))):
            c = table[i]
            if c.migrator_only:
                assert c.detect.get("pattern") in (None, "(?!x)x"), i


def test_without_a_context_transpile_is_plain_sqlglot_for_legacy_callers() -> None:
    res = transpile("SELECT s FROM t WHERE s RLIKE 'ab'")
    assert res.ok and res.flags == [] and "^(?:" not in res.sql


def test_rule_output_is_normalised_databricks_sql() -> None:
    for q in ("SELECT a FROM t ORDER BY a", "SELECT DATEDIFF(month, a, b) FROM t", "SELECT s FROM t WHERE s RLIKE 'a'"):
        first, _ = conv(q, params={"WEEK_START": 1})
        assert norm(first) == first
    assert len(RULES) == len({r.__name__ for r in RULES})


def test_a_rule_flag_escalates_the_unit_with_a_specific_reason_and_a_draft() -> None:
    ctx = tr.make_context(etl_key="k", engine="sql_view", table_map={("DB", "S", "T"): "main.s.t"}, default_db="DB",
                          default_schema="S", conversion=ConversionContext.build())
    res, item = tr.tier0_unit(tr.PreUnit("u", {"sql": "SELECT HASH(a, b) AS k FROM DB.S.T", "language": "sql"}, "sql_view"), ctx)
    assert item is not None and res.no_code
    assert "SNW-HASH-NONPORTABLE" in res.caveats and any("SNW-HASH-NONPORTABLE: HASH()" in r for r in res.reasons)
    assert res.suggested_code                                          # the draft is offered to the reviewer, never applied


def test_a_review_flag_resolves_the_unit_but_demands_a_review() -> None:
    ctx = tr.make_context(etl_key="k", engine="sql_view", table_map={("DB", "S", "T"): "main.s.t"}, default_db="DB",
                          default_schema="S", conversion=ConversionContext.build())
    res, item = tr.tier0_unit(tr.PreUnit("u", {"sql": "SELECT CURRENT_USER() AS u FROM DB.S.T", "language": "sql"}, "sql_view"), ctx)
    assert item is None and res.origin == "mapped" and "SNW-CURRENT-USER" in res.review_caveats and res.needs_review
    assert [f["id"] for f in res.evidence["rule_flags"]] == ["SNW-CURRENT-USER"]       # the reason travels with the unit
    assert res.record()["evidence"]["rule_flags"][0]["row"] == "1.24"


def test_a_decided_rule_needs_no_review() -> None:
    ctx = tr.make_context(etl_key="k", engine="sql_view", table_map={("DB", "S", "T"): "main.s.t"}, default_db="DB",
                          default_schema="S", conversion=ConversionContext.build())
    res, item = tr.tier0_unit(tr.PreUnit("u", {"sql": "SELECT DATEDIFF(month, a, b) AS m FROM DB.S.T", "language": "sql"},
                                         "sql_view"), ctx)
    assert item is None and res.origin == "mapped" and "DATEDIFF" not in res.sql.upper()
    assert "SNW-DATEDIFF" not in res.review_caveats and not res.review_caveats and "(YEAR(b) * 12" in res.sql


def test_date_part_names_cover_snowflake_aliases() -> None:
    for alias, canon in (("mm", "MONTH"), ("dd", "DAY"), ("yy", "YEAR"), ("dow", "DAYOFWEEK"), ("woy", "WEEK"),
                         ("qtr", "QUARTER"), ("hh", "HOUR"), ("ms", "MILLISECOND")):
        assert dates._DATE_PARTS[alias.upper()] == canon
