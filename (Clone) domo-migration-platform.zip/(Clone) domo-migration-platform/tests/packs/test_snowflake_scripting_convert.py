# Ported (anonymized) from SNF2DBX-main/tests/workbench/test_scripting_converter.py and test_sequences_rowcount.py
# (LatentView internal), adapted to the pack: the converter reads the splitter's nodes, every inner statement goes
# through tier 0 (so names, binds and rules are the pack's), and the handler wraps the body in CREATE PROCEDURE.
"""S1 (ADR 037, catalogue 5.1-5.6, 5.8, 5.10, 5.14): Snowflake Scripting -> Databricks SQL scripting as tier 0."""
from __future__ import annotations

import asyncio
import os
import pathlib
from types import SimpleNamespace

import pytest

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import translate as tr
from packs.snowflake.conversion import CapabilityProfile, ConversionContext, select_profile
from packs.snowflake.dml_shapes import NotCountable, count_query
from packs.snowflake.handlers import HandlerContext, build_artifacts
from packs.snowflake.scripting import split_scripting
from packs.snowflake.scripting_convert import CAVEATS, table_refs
from packs.snowflake.validators import validate


def _norm(text: str) -> str:
    return " ".join(text.split())


def convert(body: str, *, ret: str = "VARCHAR", args: str = "", sig: str = "", cap: str | None = None,
            procedures: dict | None = None, conversion: ConversionContext | None = None, engine: str = "sql_procedure",
            definition: str | None = None):
    """Run a body through the real tier 0 + handler. ``text`` = every artifact's text, whitespace-normalized."""
    defn = definition or (f"CREATE OR REPLACE PROCEDURE DEMO.CORE.P({args}) RETURNS {ret} LANGUAGE SQL AS\n$$\n{body}\n$$")
    table_map = {}
    for parts in table_refs(defn):
        full = (["DEMO", "CORE", *parts])[-3:] if len(parts) < 3 else parts
        table_map[tuple(x.upper() for x in full)] = f"main.{full[1].lower()}.{full[2].lower()}"
    doc = {"etl_id": "e1", "asset_id": f"bench:proc:acme.DEMO.CORE.proc/P({sig})", "engine": engine, "name": "P",
           "definition": defn, "params": {}}
    ctx = tr.make_context(etl_key="e1", engine=engine, table_map=table_map, default_db="DEMO", default_schema="CORE",
                          settings=TranslationSettings(tiers=("human",)),
                          conversion=conversion or ConversionContext.build(capability_profile=cap))
    ctx.procedure_returns.update(procedures or {})
    units = asyncio.run(tr.translate_etl(doc, ctx))
    arts = build_artifacts(doc, units, HandlerContext())
    text = _norm("\n".join(a.text for a in arts))
    notes = [n["note"] for u in units for n in u.params.get("scripting_notes", [])]
    review = sorted({c for u in units for c in u.review_caveats})
    reasons = [r for u in units for r in u.reasons]
    return SimpleNamespace(units=units, arts=arts, text=text, notes=notes, review=review, reasons=reasons,
                           ok=all(u.status == "resolved" for u in units), ctx=ctx)


def flagged(body: str, message: str, **kw) -> None:
    r = convert(body, **kw)
    assert not r.ok and r.arts == [], r.text
    assert any(message in x for x in r.reasons), r.reasons


# ---------------------------------------------------------------- the splitter's nodes are the contract
def test_the_converter_consumes_the_splitters_nodes():
    from packs.snowflake.scripting_convert import Services, Translated
    from packs.snowflake.scripting_convert import convert as conv

    body = "DECLARE n NUMBER DEFAULT 1;\nBEGIN\n  n := n + 1;\n  RETURN n;\nEXCEPTION WHEN OTHER THEN RETURN 0;\nEND"
    nodes = split_scripting(body)
    assert [n.kind for n in nodes] == ["declare", "script", "script", "exception"]
    out = conv(nodes, Services(lambda t: Translated(t.lower()), lambda n: None), params=["P"], returns="NUMBER")
    assert "SET n = n + 1;" in out.text and "DECLARE EXIT HANDLER FOR SQLEXCEPTION" in out.text
    assert out.returns == "scalar" and out.return_type == "DECIMAL(38,0)"


# ---------------------------------------------------------------- 5.1 variables, control flow
def test_variables_assignment_select_into_and_return():
    r = convert("""
        DECLARE n NUMBER DEFAULT 0; total NUMBER(10,2);
        BEGIN
          SELECT COUNT(*), SUM(AMT) INTO :n, :total FROM DEMO.CORE.ORDERS WHERE ID > :P;
          n := n + 1;
          RETURN 'n=' || n;
        END;""", args="P NUMBER", sig="NUMBER")
    assert r.ok
    assert "CREATE OR REPLACE PROCEDURE main.demo_core.p__ret(P DECIMAL(38, 0), OUT return_value STRING)" in r.text
    assert "DECLARE n DECIMAL(38,0) DEFAULT 0; DECLARE total DECIMAL(10,2);" in r.text
    assert "SET (n, total) = ( SELECT COUNT(*), SUM(amt) FROM main.core.orders WHERE id > p );" in r.text
    assert "SET n = n + 1;" in r.text and "SET return_value = 'n=' || n; LEAVE main;" in r.text
    assert r.text.endswith("AS BEGIN DECLARE return_value STRING; CALL main.demo_core.p__ret(P, return_value); "
                           "SELECT return_value AS return_value; END")
    assert any("no-row" in n for n in r.notes)
    assert {"SNW-SCRIPTING", "SNW-SCRIPT-RETURN", "SNW-SCRIPT-SEMANTICS"} <= set(r.review)    # never auto-approved
    assert set(r.review) - set(CAVEATS) <= {"SNW-SESSION-VAR", "SNW-NUMBER-PRECISION", "SNW-INT-DIVISION"}
    for a in r.arts:
        assert validate(a.kind, a.text) == []


def test_if_case_while_repeat_loop_and_labels():
    r = convert("""
        DECLARE n NUMBER DEFAULT 5;
        BEGIN
          IF (n > 3) THEN n := 1; ELSEIF (n = 2) THEN n := 2; ELSE n := 3; END IF;
          CASE (n) WHEN 1 THEN n := 10; ELSE n := 20; END CASE;
          WHILE (n > 0) DO n := n - 1; IF (n = 5) THEN BREAK; END IF; END WHILE;
          REPEAT n := n + 1; UNTIL (n >= 3) END REPEAT;
          LOOP n := n + 1; IF (n > 9) THEN BREAK; END IF; CONTINUE; END LOOP;
          RETURN n;
        END;""")
    assert r.ok
    assert "IF (n > 3) THEN SET n = 1; ELSEIF (n = 2) THEN SET n = 2; ELSE SET n = 3; END IF;" in r.text
    assert "CASE (n) WHEN 1 THEN SET n = 10; ELSE SET n = 20; END CASE;" in r.text
    assert "loop_1: WHILE (n > 0) DO SET n = n - 1; IF (n = 5) THEN LEAVE loop_1; END IF; END WHILE loop_1;" in r.text
    assert "loop_2: REPEAT SET n = n + 1; UNTIL (n >= 3) END REPEAT loop_2;" in r.text
    assert "loop_3: LOOP SET n = n + 1; IF (n > 9) THEN LEAVE loop_3; END IF; ITERATE loop_3; END LOOP loop_3;" in r.text


def test_a_user_label_names_the_loop_and_break_can_target_an_outer_one():
    r = convert("""
        DECLARE n NUMBER DEFAULT 0;
        BEGIN
          outer_loop: WHILE (n < 5) DO
            n := n + 1;
            FOR i IN 1 TO 3 DO IF (i = 2) THEN BREAK outer_loop; END IF; END FOR;
          END WHILE outer_loop;
          RETURN n;
        END;""")
    assert r.ok and "outer_loop: WHILE (n < 5) DO" in r.text and "LEAVE outer_loop;" in r.text


def test_for_range_continue_still_increments_and_reverse():
    r = convert("""
        DECLARE s NUMBER DEFAULT 0;
        BEGIN
          FOR i IN 1 TO 3 DO IF (i = 2) THEN CONTINUE; END IF; s := s + i; END FOR;
          FOR j IN REVERSE 1 TO 3 DO s := s + j; END FOR;
          RETURN s;
        END;""")
    assert r.ok
    assert "DECLARE i BIGINT DEFAULT 1; DECLARE i_end_ BIGINT DEFAULT 3; loop_1: WHILE i <= i_end_ DO body_2: BEGIN" in r.text
    assert "LEAVE body_2;" in r.text and "END body_2; SET i = i + 1; END WHILE loop_1;" in r.text
    assert "DECLARE j BIGINT DEFAULT 3; DECLARE j_end_ BIGINT DEFAULT 1;" in r.text and "WHILE j >= j_end_" in r.text
    assert "SET j = j - 1;" in r.text


def test_let_opens_a_scoped_block():
    r = convert("BEGIN LET x NUMBER := 1; LET y := x + 1; RETURN y; END;")
    assert r.ok and "BEGIN DECLARE x DECIMAL(38,0) DEFAULT 1; BEGIN DECLARE y DEFAULT x + 1;" in r.text


# ---------------------------------------------------------------- 5.3 cursors and RESULTSETs, 5.6 RETURN TABLE
def test_cursor_and_resultset_loops_and_return_table():
    r = convert("""
        DECLARE c1 CURSOR FOR SELECT ID FROM DEMO.CORE.ORDERS;
                rs RESULTSET DEFAULT (SELECT ID, AMT FROM DEMO.CORE.ORDERS WHERE AMT > 0);
        BEGIN
          FOR r IN c1 DO UPDATE DEMO.CORE.ORDERS SET SEEN = TRUE WHERE ID = r.ID; END FOR;
          RETURN TABLE(rs);
        END;""", ret="TABLE (ID NUMBER, AMT NUMBER)")
    assert r.ok and len(r.arts) == 1                     # a table-returning procedure has no OUT twin
    assert ("loop_1: FOR r AS SELECT id FROM main.core.orders DO UPDATE main.core.orders SET seen = TRUE WHERE id = r.id; "
            "END FOR loop_1;") in r.text
    assert r.text.endswith("SELECT id, amt FROM main.core.orders WHERE amt > 0; END main; END")
    assert "return_value" not in r.text and "SNW-SCRIPT-RETURN" in r.review
    assert validate("script", r.arts[0].text) == []


def test_empty_resultset_takes_its_query_from_the_later_assignment():
    r = convert("""
        DECLARE res RESULTSET;
        BEGIN
          UPDATE DEMO.CORE.ORDERS SET SEEN = TRUE;
          res := (SELECT ID FROM DEMO.CORE.ORDERS WHERE SEEN);
          RETURN TABLE(res);
        END;""", ret="TABLE (ID NUMBER)")
    assert r.ok and r.text.endswith("SELECT id FROM main.core.orders WHERE seen; END main; END")


def test_return_table_after_lets_and_a_nested_block_is_final():
    r = convert("""
        BEGIN
          LET a NUMBER := 1;
          LET b NUMBER := a + 1;
          BEGIN UPDATE DEMO.CORE.ORDERS SET SEEN = TRUE; END;
          LET res RESULTSET := (SELECT ID FROM DEMO.CORE.ORDERS WHERE ID > :b);
          RETURN TABLE(res);
        END;""", ret="TABLE (ID NUMBER)")
    assert r.ok and "SELECT id FROM main.core.orders WHERE id > b;" in r.text


@pytest.mark.parametrize("body, message", [
    ("DECLARE res RESULTSET; BEGIN RETURN TABLE(res); END;", "used before a query is assigned"),
    ("DECLARE res RESULTSET; BEGIN IF (1=1) THEN res := (SELECT 1 AS X); END IF; RETURN TABLE(res); END;",
     "inside IF/CASE/loop"),
    ("DECLARE res RESULTSET DEFAULT (SELECT 1 AS X); BEGIN BEGIN RETURN TABLE(res); END; "
     "UPDATE DEMO.CORE.ORDERS SET SEEN = TRUE; END;", "final statement"),
    ("DECLARE res RESULTSET DEFAULT (CALL DEMO.CORE.P2()); BEGIN FOR r IN res DO RETURN 'x'; END FOR; RETURN 'y'; END;",
     "reads the result of a CALL"),
    ("DECLARE res RESULTSET; BEGIN res := (EXECUTE IMMEDIATE 'DELETE FROM DEMO.CORE.ORDERS'); RETURN 'ok'; END;",
     "never read"),
])
def test_resultset_shapes_that_would_need_a_guess_are_flagged(body, message):
    flagged(body, message, ret="TABLE (X NUMBER)" if "TABLE(" in body else "VARCHAR")


def test_a_resultset_call_runs_in_place_even_when_never_read():
    r = convert("""
        DECLARE res RESULTSET DEFAULT (CALL DEMO.AUDIT.LOG_START('start')); return_msg RESULTSET;
        BEGIN
          UPDATE DEMO.CORE.ORDERS SET SEEN = TRUE;
          IF (1 = 1) THEN return_msg := (CALL DEMO.AUDIT.LOG_END('ok')); END IF;
          RETURN 'ok';
        EXCEPTION WHEN OTHER THEN
          return_msg := (CALL DEMO.AUDIT.LOG_END('fail'));
          RETURN SQLERRM;
        END;""")
    assert r.ok
    start = r.text.index("CALL main.demo_audit.log_start('start');")
    assert r.text.index("DECLARE EXIT HANDLER") < start < r.text.index("UPDATE main.core.orders SET seen = TRUE;")
    assert "IF (1 = 1) THEN CALL main.demo_audit.log_end('ok'); END IF;" in r.text
    assert "CALL main.demo_audit.log_end('fail'); SET return_value = err_message;" in r.text


# ---------------------------------------------------------------- 5.2 exceptions
def test_exceptions_raise_resignal_and_diagnostics():
    r = convert("""
        DECLARE bad EXCEPTION (-20001, 'bad input');
        BEGIN
          IF (1 = 1) THEN RAISE bad; END IF;
          RETURN 'ok';
        EXCEPTION
          WHEN bad THEN RETURN 'handled';
          WHEN OTHER THEN INSERT INTO DEMO.CORE.LOG VALUES (SQLERRM, SQLSTATE); RAISE;
        END;""")
    assert r.ok
    assert "DECLARE bad CONDITION FOR SQLSTATE '45001';" in r.text
    assert "DECLARE EXIT HANDLER FOR bad BEGIN SET return_value = 'handled'; END;" in r.text
    assert "DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN DECLARE err_message STRING; DECLARE err_state STRING;" in r.text
    assert "GET DIAGNOSTICS CONDITION 1 err_message = MESSAGE_TEXT, err_state = RETURNED_SQLSTATE;" in r.text
    assert "INSERT INTO main.core.log VALUES (err_message, err_state); RESIGNAL;" in r.text
    assert "SIGNAL bad SET MESSAGE_TEXT = 'bad input';" in r.text
    assert "SNW-SCRIPT-HANDLER" in r.review


def test_statement_error_and_sqlcode_are_reviewed_not_invented():
    r = convert("BEGIN INSERT INTO DEMO.CORE.T SELECT 1; EXCEPTION WHEN STATEMENT_ERROR THEN "
                "INSERT INTO DEMO.CORE.LOG VALUES (SQLCODE); END;", ret="VARCHAR")
    assert r.ok and "FOR SQLEXCEPTION" in r.text
    assert any("SQLCODE has no Databricks equivalent" in n for n in r.notes)
    assert any("covers all errors" in n for n in r.notes)


# ---------------------------------------------------------------- 5.7 EXECUTE IMMEDIATE, calls, 5.8 transactions
def test_literal_execute_immediate_call_transactions_and_wait():
    r = convert("""
        BEGIN
          EXECUTE IMMEDIATE 'TRUNCATE TABLE DEMO.CORE.STAGE';
          CALL DEMO.CORE.LOG_EVENT(:x, 1);
          BEGIN TRANSACTION; DELETE FROM DEMO.CORE.T; COMMIT;
          CALL SYSTEM$WAIT(5);
          RETURN 'done';
        END;""")
    assert r.ok
    assert "EXECUTE IMMEDIATE 'TRUNCATE TABLE main.core.stage';" in r.text
    assert "CALL main.demo_core.log_event(x, 1);" in r.text
    assert "DELETE FROM main.core.t;" in r.text and "TRANSACTION" not in r.text and "COMMIT" not in r.text
    assert "SYSTEM$WAIT" not in r.text
    assert any("SYSTEM$WAIT removed" in n for n in r.notes)
    assert "SNW-TXN" in r.review                                      # atomicity is gone: a reviewer decides


def test_a_transaction_only_procedure_is_converted_and_flagged_with_snw_txn():
    r = convert("BEGIN\n  BEGIN TRANSACTION;\n  DELETE FROM DEMO.CORE.T WHERE X = 1;\n"
                "  INSERT INTO DEMO.CORE.T SELECT * FROM DEMO.CORE.S;\n  COMMIT;\n  RETURN 'ok';\nEND;")
    assert r.ok and "SNW-TXN" in r.review and "COMMIT" not in r.text
    assert any("no longer atomic" in n for n in r.notes)


def test_rollback_is_flagged_because_removing_it_changes_the_data():
    flagged("BEGIN BEGIN TRANSACTION; DELETE FROM DEMO.CORE.T; ROLLBACK; RETURN 'x'; END;", "ROLLBACK undoes")


def test_execute_immediate_of_run_time_text_is_flagged_for_the_shim():
    flagged("BEGIN EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || :tbl; RETURN 'ok'; END;", "built at run time",
            args="tbl STRING", sig="VARCHAR")


def test_dollar_quoted_literal_execute_immediate_is_translated():
    r = convert("BEGIN EXECUTE IMMEDIATE $$DELETE FROM DEMO.CORE.T WHERE X = 1$$; RETURN 'ok'; END;")
    assert r.ok and "EXECUTE IMMEDIATE 'DELETE FROM main.core.t WHERE x = 1';" in r.text


def test_strings_and_comments_are_not_rewritten():
    r = convert("BEGIN -- RETURN :x\n INSERT INTO DEMO.CORE.T VALUES (':x IF END;'); RETURN 'ok'; END;")
    assert r.ok and "VALUES (':x IF END;')" in r.text


# ---------------------------------------------------------------- 5.5 SQLROWCOUNT
def test_sqlrowcount_after_merge_counts_the_source_rows_first():
    r = convert("""
        DECLARE n NUMBER DEFAULT 0;
        BEGIN
          MERGE INTO DEMO.CORE.T AS t USING (SELECT ID, AMT FROM DEMO.CORE.S) AS s ON t.ID = s.ID
            WHEN MATCHED THEN UPDATE SET t.AMT = s.AMT
            WHEN NOT MATCHED THEN INSERT (ID, AMT) VALUES (s.ID, s.AMT);
          n := n + SQLROWCOUNT;
          IF (SQLNOTFOUND) THEN RETURN 'none'; END IF;
          RETURN 'rows ' || n;
        END;""")
    assert r.ok
    assert r.text.index("SET rowcount_ = ( SELECT COUNT(*) FROM (SELECT id, amt FROM main.core.s) AS s );") \
        < r.text.index("MERGE INTO main.core.t")
    assert "DECLARE rowcount_ BIGINT DEFAULT 0;" in r.text
    assert "SET n = n + rowcount_;" in r.text and "IF ((rowcount_ = 0)) THEN" in r.text
    assert "SQLROWCOUNT" not in r.text and "SNW-SCRIPT-ROWCOUNT" in r.review


@pytest.mark.parametrize("statement, expected", [
    ("INSERT INTO T (A) VALUES (1), (2)", "SELECT 2"),
    ("INSERT INTO T SELECT A FROM S WHERE A > 1", "SELECT COUNT(*) FROM (SELECT A FROM S WHERE A > 1) AS counted_"),
    ("UPDATE T SET A = 1 WHERE B = 2", "SELECT COUNT(*) FROM T WHERE B = 2"),
    ("DELETE FROM T WHERE B = 2", "SELECT COUNT(*) FROM T WHERE B = 2"),
    ("MERGE INTO T t USING S s ON t.ID = s.ID WHEN MATCHED THEN UPDATE SET t.A = s.A",
     "SELECT COUNT(*) FROM S AS s WHERE EXISTS (SELECT 1 FROM T t WHERE t.ID = s.ID)"),
    ("MERGE INTO T t USING S s ON t.ID = s.ID WHEN NOT MATCHED THEN INSERT (ID) VALUES (s.ID)",
     "SELECT COUNT(*) FROM S AS s WHERE NOT EXISTS (SELECT 1 FROM T t WHERE t.ID = s.ID)"),
])
def test_count_queries(statement, expected):
    assert count_query(statement) == expected


@pytest.mark.parametrize("statement, message", [
    ("UPDATE T SET A = S.A FROM S WHERE T.ID = S.ID", "joins other tables"),
    ("DELETE FROM T USING S WHERE T.ID = S.ID", "joins other tables"),
    ("MERGE INTO T t USING S s ON t.ID = s.ID WHEN MATCHED AND s.X = 1 THEN DELETE", "conditional"),
])
def test_uncountable_statements_are_refused(statement, message):
    with pytest.raises(NotCountable, match=message):
        count_query(statement)


def test_sqlrowcount_without_a_countable_statement_is_flagged():
    flagged("DECLARE n NUMBER; BEGIN UPDATE DEMO.CORE.T SET A = 1 FROM DEMO.CORE.S WHERE T.ID = S.ID; n := SQLROWCOUNT; "
            "RETURN n; END;", "joins other tables")
    flagged("DECLARE n NUMBER; BEGIN n := SQLROWCOUNT; RETURN n; END;", "SQLROWCOUNT")      # no DML before it
    flagged("DECLARE n NUMBER; BEGIN IF (1 = 1) THEN DELETE FROM DEMO.CORE.T; END IF; n := SQLROWCOUNT; RETURN n; END;",
            "SQLROWCOUNT")                                              # the count belongs to a DML that may not run


# ---------------------------------------------------------------- 5.6 return values and callers
def test_call_return_value_uses_the_out_parameter_twin():
    r = convert("""
        DECLARE v_status VARCHAR; v_first VARCHAR DEFAULT (CALL DEMO.CORE.INGEST('a', 1));
        BEGIN
          v_status := (CALL DEMO.CORE.INGEST(:v_first, 2));
          LET v_last := (CALL DEMO.CORE.INGEST('d', 4));
          RETURN v_status || v_last;
        END;""", procedures={"DEMO.CORE.INGEST": "VARCHAR"})
    assert r.ok
    assert "DECLARE v_status STRING; DECLARE v_first STRING; CALL main.demo_core.ingest__ret('a', 1, v_first);" in r.text
    assert "CALL main.demo_core.ingest__ret(v_first, 2, v_status);" in r.text
    assert "BEGIN DECLARE v_last STRING; CALL main.demo_core.ingest__ret('d', 4, v_last);" in r.text


def test_call_return_value_of_a_procedure_outside_the_conversion_is_flagged():
    flagged("DECLARE v VARCHAR; BEGIN v := (CALL OTHER.S.P(1)); RETURN v; END;", "same conversion")


def test_return_scalar_gets_a_twin_that_holds_the_body_and_a_wrapper_that_returns_a_row():
    r = convert("BEGIN IF (1 = 1) THEN RETURN 'a'; END IF; RETURN 'b'; END;", args="P NUMBER", sig="NUMBER")
    assert r.ok and [a.name for a in r.arts] == ["main.demo_core.p__ret", "main.demo_core.p"]
    twin, wrapper = r.arts
    assert twin.text.startswith("CREATE OR REPLACE PROCEDURE main.demo_core.p__ret(P DECIMAL(38, 0), OUT return_value STRING)")
    assert "SQL SECURITY INVOKER" in twin.text and "main: BEGIN" in twin.text
    assert "CALL main.demo_core.p__ret(P, return_value);" in wrapper.text and "SELECT return_value AS return_value;" in wrapper.text
    assert all(validate("script", a.text) == [] for a in r.arts)


def test_a_procedure_with_no_value_return_is_one_plain_procedure():
    r = convert("DECLARE n NUMBER DEFAULT 1; BEGIN IF (n = 1) THEN INSERT INTO DEMO.CORE.T SELECT 1; END IF; END;")
    assert r.ok and [a.name for a in r.arts] == ["main.demo_core.p"] and "__ret" not in r.text and "return_value" not in r.text


def test_an_unknown_return_type_is_assumed_string_and_said_so():
    r = convert("BEGIN IF (1 = 1) THEN RETURN 1; END IF; RETURN 2; END;", definition=(
        "BEGIN IF (1 = 1) THEN RETURN 1; END IF; RETURN 2; END;"))
    assert r.ok and "OUT return_value STRING" in r.text and any("RETURNS type is not known" in n for n in r.notes)


def test_execute_as_owner_is_a_review_reason_and_invoker_rights_are_generated():
    r = convert("BEGIN IF (1 = 1) THEN RETURN 'a'; END IF; RETURN 'b'; END;", definition=(
        "CREATE OR REPLACE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE SQL EXECUTE AS OWNER AS\n$$\n"
        "BEGIN IF (1 = 1) THEN RETURN 'a'; END IF; RETURN 'b'; END;\n$$"))
    assert r.ok and "SQL SECURITY INVOKER" in r.text
    assert all("SNW-EXEC-AS" in a.caveats and any("EXECUTE AS OWNER" in x for x in a.review_reasons) for a in r.arts)


# ---------------------------------------------------------------- unsupported constructs are flagged precisely
@pytest.mark.parametrize("body, message", [
    ("BEGIN OPEN c1; RETURN 1; END;", "Explicit cursor OPEN"),
    ("BEGIN BEGIN RETURN 1; EXCEPTION WHEN OTHER THEN RETURN 2; END; END;", "nested block"),
    ("BEGIN RAISE missing_exc; END;", "undeclared exception"),
    ("BEGIN IF (1 = 1) THEN SHOW TABLES; END IF; RETURN 1; END;", "administrative statement"),
    ("BEGIN INSERT INTO DEMO.CORE.T SELECT SEQ1.NEXTVAL; RETURN 1; END;", ".NEXTVAL"),
    ("DECLARE g GEOGRAPHY; BEGIN RETURN 1; END;", "no deterministic Databricks mapping"),
])
def test_unsupported_constructs_report_the_reason(body, message):
    flagged(body, message)


def test_a_conversion_error_names_the_procedure_body_line():
    r = convert("BEGIN\n  RETURN 1;\n  IF (x THEN\nEND;")
    assert not r.ok and any("procedure body line" in x or "tier 0" in x for x in r.reasons)


# ---------------------------------------------------------------- REF001: per-row DML in a cursor loop -> set-based
def test_a_cursor_loop_with_one_keyed_update_becomes_one_set_based_statement():
    r = convert("""
        BEGIN
          FOR r IN (SELECT DISTINCT ID FROM DEMO.CORE.S) DO
            UPDATE DEMO.CORE.T SET FLAG = 1 WHERE ID = r.ID;
          END FOR;
          RETURN 'ok';
        END;""")
    assert r.ok and "FOR r AS" not in r.text
    assert ("UPDATE main.core.t SET flag = 1 WHERE id IN (SELECT id FROM (SELECT DISTINCT id FROM main.core.s) "
            "AS loop_keys_);") in r.text
    assert "SNW-SCRIPT-REFACTOR" in r.review and any("Safe because" in n for n in r.notes)


def test_a_loop_whose_keys_may_repeat_is_kept_as_a_loop():
    r = convert("BEGIN FOR r IN (SELECT ID FROM DEMO.CORE.S) DO UPDATE DEMO.CORE.T SET FLAG = 1 WHERE ID = r.ID; "
                "END FOR; RETURN 'ok'; END;")
    assert r.ok and "FOR r AS SELECT id FROM main.core.s DO UPDATE main.core.t SET flag = 1 WHERE id = r.id;" in r.text
    assert "SNW-SCRIPT-REFACTOR" not in r.review


def test_the_refactor_can_be_switched_off():
    defn = ("CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE SQL AS $$ BEGIN FOR r IN "
            "(SELECT DISTINCT ID FROM DEMO.CORE.S) DO UPDATE DEMO.CORE.T SET FLAG = 1 WHERE ID = r.ID; END FOR; "
            "RETURN 'ok'; END; $$")
    r = convert("", definition=defn)
    assert "loop_keys_" in r.text
    ctx = r.ctx
    ctx.refactor_loops = False
    doc = {"etl_id": "e1", "asset_id": "bench:proc:acme.DEMO.CORE.proc/P()", "engine": "sql_procedure", "name": "P",
           "definition": defn, "params": {}}
    units = asyncio.run(tr.translate_etl(doc, ctx))
    assert "FOR r AS" in _norm(units[0].sql)


# ---------------------------------------------------------------- capability profiles (X4)
def test_without_sql_scripting_the_body_is_flagged_not_guessed():
    flagged("DECLARE n NUMBER DEFAULT 0; BEGIN IF (n = 0) THEN n := 1; END IF; RETURN n; END;",
            "has no SQL scripting", cap="databricks_sql_conservative")


def test_without_create_procedure_the_body_is_a_notebook_cell_compound_statement():
    cur = select_profile("databricks_sql_current")
    profile = CapabilityProfile("scripting_only", {**dict(cur.flags), "sql_procedures": False})
    r = convert("DECLARE n NUMBER DEFAULT 0; BEGIN IF (n = 0) THEN n := 1; END IF; RETURN n; END;",
                args="P_LIM NUMBER", sig="NUMBER", conversion=ConversionContext(capabilities=profile))
    assert r.ok and [a.kind for a in r.arts] == ["task_body"] and "CREATE" not in r.text
    assert r.text.startswith("BEGIN DECLARE P_LIM DECIMAL(38, 0) DEFAULT :P_LIM; DECLARE return_value STRING; main: BEGIN")
    assert r.text.endswith("END main; SELECT return_value AS return_value; END;")
    assert r.arts[0].spec == {"form": "notebook_cell", "parameters": ["P_LIM"]}
    assert any("sql_procedures is false" in x for x in r.arts[0].review_reasons)


# ---------------------------------------------------------------- anonymous blocks (task bodies)
def test_an_anonymous_block_in_a_task_converts_to_one_compound_statement():
    body = ("BEGIN\n  DELETE FROM DEMO.CORE.T WHERE X < 1;\n  IF (1 = 1) THEN INSERT INTO DEMO.CORE.T SELECT 1; END IF;\nEND")
    r = convert("", engine="task", definition=f"CREATE TASK T1 WAREHOUSE = W SCHEDULE = '5 MINUTE' AS\n{body}")
    assert r.ok and [a.kind for a in r.arts] == ["task_body"]
    assert r.text.startswith("main: BEGIN DELETE FROM main.core.t WHERE x < 1; IF (1 = 1) THEN INSERT INTO main.core.t SELECT 1;")
    assert r.text.endswith("END IF; END main;")


def test_a_return_inside_a_task_block_is_flagged():
    r = convert("", engine="task", definition="CREATE TASK T1 WAREHOUSE = W AS\nBEGIN IF (1 = 1) THEN RETURN 'x'; END IF; END")
    assert not r.ok and any("RETURN inside a task/script block" in x for x in r.reasons)


# ---------------------------------------------------------------- the inner statements are the pack's tier 0
def test_inner_statements_take_the_pack_rules_the_names_and_the_residue_guard():
    r = convert("BEGIN INSERT INTO DEMO.CORE.T SELECT IFF(A > 1, 1, 0), CURRENT_TIMESTAMP() FROM DEMO.CORE.S; "
                "RETURN 'ok'; END;")
    assert r.ok and "INSERT INTO main.core.t SELECT IF(a > 1, 1, 0)" in r.text and "main.core.s" in r.text
    flagged("BEGIN INSERT INTO DEMO.CORE.T SELECT RATIO_TO_REPORT(A) OVER () FROM DEMO.CORE.S; RETURN 'ok'; END;",
            "SNW-RESIDUE")


def test_phase_a_leaves_nothing_for_the_later_tiers_when_the_body_converts():
    body = "BEGIN IF (1 = 1) THEN INSERT INTO DEMO.CORE.T SELECT 1; END IF; RETURN 'ok'; END;"
    r = convert(body)
    doc = {"etl_id": "e1", "asset_id": "bench:proc:acme.DEMO.CORE.proc/P()", "engine": "sql_procedure", "name": "P",
           "definition": f"CREATE PROCEDURE DEMO.CORE.P() RETURNS VARCHAR LANGUAGE SQL AS $$ {body} $$", "params": {}}
    assert r.ok and tr.phase_a_units(doc, r.ctx) == []
    bad = {**doc, "definition": doc["definition"].replace("RETURN 'ok'", "OPEN c1")}
    assert tr.phase_a_units(bad, r.ctx)                          # unconverted: the units still go down the chain


def test_a_scripting_procedure_is_never_auto_approved():
    r = convert("BEGIN IF (1 = 1) THEN INSERT INTO DEMO.CORE.T SELECT 1; END IF; END;")
    unit = r.units[0]
    assert unit.origin == "mapped" and unit.needs_review and "SNW-SCRIPTING" in unit.review_caveats
    assert unit.column_check == "unverifiable"
    assert "children" not in unit.params and "source_text" not in unit.record()        # rule 11: no source in records


# ---------------------------------------------------------------- golden outputs over the shared Scripting corpus
CORPUS = pathlib.Path(__file__).resolve().parents[1] / "fixtures" / "snowflake" / "scripting"
GOLDEN = pathlib.Path(__file__).resolve().parents[1] / "fixtures" / "snowflake" / "scripting_convert"


def _golden_text(name: str) -> tuple[str, str]:
    """``(file suffix, text)``: the artifacts converted from the corpus file, or the first flag reason."""
    r = convert((CORPUS / f"{name}.sql").read_text(encoding="utf-8"))
    if r.ok:
        return ".databricks.sql", "\n\n".join(a.text for a in r.arts) + "\n"
    return ".flag.txt", r.reasons[0].split("\n")[0] + "\n"


@pytest.mark.parametrize("name", sorted(p.stem for p in CORPUS.glob("*.sql")))
def test_golden_output_per_corpus_file(name):
    """Regenerate with ``UPDATE_GOLDEN=1`` after an intended change, and read the diff: the golden IS the review."""
    suffix, text = _golden_text(name)
    path = GOLDEN / f"{name}{suffix}"
    if os.environ.get("UPDATE_GOLDEN"):
        GOLDEN.mkdir(exist_ok=True)
        for old in GOLDEN.glob(f"{name}.*"):
            old.unlink()
        path.write_text(text, encoding="utf-8")
    assert path.exists(), f"no golden for {name}: run with UPDATE_GOLDEN=1"
    assert path.read_text(encoding="utf-8") == text
    assert len(list(GOLDEN.glob(f"{name}.*"))) == 1                        # never both a conversion and a flag


def test_the_corpus_goldens_are_exactly_the_corpus_files():
    assert sorted({p.name.split(".")[0] for p in GOLDEN.iterdir()}) == sorted(p.stem for p in CORPUS.glob("*.sql"))
    # what converts, converts; what must not be guessed is flagged with its reason
    assert {p.name.split(".")[0] for p in GOLDEN.glob("*.flag.txt")} == {
        "exception_block", "execute_immediate_literal", "execute_immediate_variable"}


# ---------------------------------------------------------------- splitter and header helpers this path relies on
def test_a_malformed_body_does_not_crash_the_splitter_and_is_flagged():
    nodes = split_scripting("BEGIN\n  RETURN 1;\n  IF (x THEN\nEND;")
    assert nodes                                                                  # no IndexError past the last token
    r = convert("BEGIN\n  RETURN 1;\n  IF (x THEN\nEND;")
    assert not r.ok


def test_a_dollar_literal_inside_a_body_is_not_mistaken_for_the_wrapper():
    from packs.snowflake.scripting import is_scripting

    assert is_scripting("BEGIN EXECUTE IMMEDIATE $$ DELETE FROM t $$; END")
    assert is_scripting("$$BEGIN SELECT 1; END$$")


def test_procedure_header_and_parameter_names():
    from packs.snowflake import contract as ct
    from packs.snowflake.scripting import procedure_header

    ddl = ("CREATE OR REPLACE PROCEDURE DEMO.CORE.P(LIM NUMBER(10,2), T VARCHAR) RETURNS TABLE (A NUMBER, B VARCHAR) "
           "LANGUAGE SQL EXECUTE AS RESTRICTED CALLER AS $$ BEGIN RETURN TABLE(x); END $$")
    head = procedure_header(ddl)
    assert head == {"returns": "TABLE (A NUMBER, B VARCHAR)", "params": [("LIM", "NUMBER(10,2)"), ("T", "VARCHAR")],
                    "execute_as": "RESTRICTED CALLER"}
    assert procedure_header("BEGIN RETURN 1; END") == {}                         # a bare body says nothing
    # the asset id carries types only: the body's own names come from the stored CREATE
    doc = {"asset_id": "acme.DEMO.CORE.proc/P(NUMBER,VARCHAR)", "definition": ddl, "params": {}}
    assert ct.signature_pairs(doc) == [("LIM", "NUMBER"), ("T", "VARCHAR")]
    named = {**doc, "params": {"argument_signature": "(X NUMBER, Y VARCHAR)"}}
    assert ct.signature_pairs(named) == [("X", "NUMBER"), ("Y", "VARCHAR")]


def test_table_refs_reads_the_names_a_body_mentions():
    body = ("BEGIN INSERT INTO a.t SELECT * FROM s JOIN db.x.y ON 1=1; EXECUTE IMMEDIATE 'TRUNCATE TABLE z'; "
            "-- FROM ignored\nEND")
    assert table_refs(body) == [["a", "t"], ["s"], ["db", "x", "y"], ["z"]]
