"""X5 (ADR 37 section 8): the silent-semantics data tests. For every catalogue section 1 corpus case that carries a data
set, the CONVERTED SQL (the real tier 0, ``benchmark.run_case``) is executed against the case's rows and compared with the
rows Snowflake returns (``data.expect``, hand-computed and ``unverified`` until the account run).

    DuckDB      local and offline: the Databricks text is transpiled ``databricks -> duckdb`` (the rules write explicit
                NULLS FIRST / LAST so the transpile is neutral). A case DuckDB cannot run faithfully is ``live_only`` in
                the corpus, with the reason, and is skipped here.
    Databricks  ``-m databricks``: the same converted text on a SQL warehouse over temp views built from the case data
                (DATABRICKS_SERVER_HOSTNAME / DATABRICKS_HTTP_PATH / DATABRICKS_TOKEN). Not run in CI.

A case whose class is ``flag`` and that the engine escalates (HASH, epoch scale, sketches) has no converted text to run:
that is the intended outcome and it is skipped with the reason.
"""
from __future__ import annotations

import pytest
import snowflake_datatest as dt

from packs.snowflake import benchmark as bm

CASES = [c for c in bm.load_corpus() if c.silent and c.data and c.data.get("expect") is not None]
ALL = [pytest.param(c, id=c.id) for c in CASES]
LOCAL = [pytest.param(c, id=c.id) for c in CASES if not c.live_only]


def _converted(case: bm.Case) -> str:
    out = bm.run_case(case)
    if out.observed != "mapped":
        assert case.cls in bm.FLAGGED_CLASSES, f"{case.id}: a {case.cls} case did not convert: {out.reasons}"
        pytest.skip(f"{case.id}: the engine flags this construct instead of converting it ({'; '.join(out.reasons)[:120]})")
    return out.sql


def test_the_data_set_covers_every_section_1_row_and_live_only_is_explained() -> None:
    rows = {c.row for c in CASES}
    flagged_only = {c.row for c in bm.load_corpus() if c.silent} - rows           # rows whose expect is null (not reproducible)
    assert {f"1.{i}" for i in range(1, 28)} == rows | flagged_only
    assert len(CASES) >= 40
    for c in CASES:
        assert c.live_only is None or len(c.live_only) > 20, c.id                 # a reason, not a bare marker


@pytest.mark.parametrize("case", LOCAL)
def test_converted_sql_returns_the_rows_snowflake_returns_on_duckdb(case: bm.Case) -> None:
    pytest.importorskip("duckdb")
    sql = _converted(case)
    rows = dt.run_duckdb(sql, case.data["tables"], case.prelude)
    assert dt.rows_match(rows, case.data["expect"], dt.top_level_order(sql)), (case.id, sql, rows, case.data["expect"])


@pytest.mark.databricks
@pytest.mark.parametrize("case", ALL)
def test_converted_sql_returns_the_rows_snowflake_returns_on_a_databricks_warehouse(case: bm.Case) -> None:
    if not dt.databricks_configured():
        pytest.skip("no SQL warehouse configured (DATABRICKS_SERVER_HOSTNAME / DATABRICKS_HTTP_PATH / DATABRICKS_TOKEN)")
    sql = _converted(case)
    rows = dt.run_databricks(sql, case.data["tables"], case.prelude)
    assert dt.rows_match(rows, case.data["expect"], dt.top_level_order(sql)), (case.id, sql, rows, case.data["expect"])


# ------------------------------------------------------------------------------------------------ the kit itself
def test_the_kit_compares_rows_with_one_canonical_form() -> None:
    import datetime as d
    import decimal
    assert dt.rows_match([[d.date(2024, 1, 1), 1.00001, decimal.Decimal("2.5"), [1, 2], {"a": 1}, True, None]],
                         [["2024-01-01", 1.0, 2.5, "[1,2]", '{"a":1}', True, None]], ordered=True)
    assert dt.rows_match([[d.datetime(2024, 1, 2, 3, 4, 5, 678000)]], [["2024-01-02 03:04:05.678"]], ordered=True)
    assert dt.rows_match([[1], [2]], [[2], [1]], ordered=False) and not dt.rows_match([[1], [2]], [[2], [1]], ordered=True)
    assert not dt.rows_match([[1]], [[2]], ordered=True)


def test_the_kit_builds_warehouse_temp_views_without_a_warehouse() -> None:
    stmts = dt.temp_view_statements({"T": {"columns": ["A", "D"], "rows": [["x", "2024-01-01"]], "types": {"D": "DATE"}}})
    assert stmts == ["CREATE OR REPLACE TEMP VIEW t AS SELECT a, CAST(d AS DATE) AS d FROM "
                     "(SELECT * FROM VALUES ('x', '2024-01-01') AS v(a, d))"]
    arr = dt.temp_view_statements({"A": {"columns": ["ARR"], "rows": [['["a"]']], "types": {"ARR": "VARCHAR[]"}}})
    assert "from_json(arr, 'ARRAY<VARCHAR>')" in arr[0]
