"""P3-07 (ADR 032 sections 2 and 4, D-3): the migrator half of the equality tests. The migrator cannot import
`srcintel`, so it reads the adapter README (the contract) and compares: caveat ids, engine enum and the shared
Scripting corpus (this copy against the workspace copy, byte for byte). The splitter itself runs the corpus in
`test_snowflake_scripting.py`. Missing workspace files FAIL when `CI` is set and skip on a lone checkout."""
from __future__ import annotations

import os
import pathlib
import re

import pytest
import yaml

from packs.snowflake.caveats import load_catalogue
from packs.snowflake.contract import ENGINES

APP = pathlib.Path(__file__).resolve().parents[2]
REPO = APP.parents[1]
README = REPO / "packages" / "srcintel-core" / "src" / "srcintel" / "adapters" / "snowflake" / "README.md"
OURS = APP / "tests" / "fixtures" / "snowflake" / "scripting"
THEIRS = REPO / "tests" / "fixtures" / "snowflake" / "scripting"


def _need(path: pathlib.Path) -> None:
    if not path.exists():
        if os.environ.get("CI"):
            pytest.fail(f"{path} is missing")
        pytest.skip(f"{path} is missing (a checkout without the workspace)")


def readme_section(title: str) -> list[str]:
    _need(README)
    body = README.read_text(encoding="utf-8").split(f"## {title}", 1)[1].split("\n## ", 1)[0]
    return re.findall(r"^- `([^`]+)`", body, re.M)


def test_caveat_id_set_equals_the_adapter_readme_list():
    assert set(load_catalogue().ids) == set(readme_section("Caveat ids"))
    only = {c.id for c in load_catalogue().entries if c.migrator_only}
    assert only and not only & set(load_catalogue().ids)


def test_every_caveat_has_a_family_a_severity_and_a_detect_rule():
    cat = load_catalogue()
    for c in cat.entries:
        assert c.family in cat.families and c.severity in ("info", "review", "escalate", "block") and c.detect, c.id


def test_engine_list_equals_the_adapter_readme_list():
    assert list(ENGINES) == readme_section("Engines")
    assert set(ENGINES) == set(yaml.safe_load((APP / "packs" / "snowflake" / "engines.yaml").read_text())["engines"])


def test_scripting_corpus_is_byte_equal_to_the_workspace_copy():
    _need(THEIRS)
    ours = {p.name: p.read_bytes() for p in OURS.glob("*.sql")}
    theirs = {p.name: p.read_bytes() for p in THEIRS.glob("*.sql")}
    assert sorted(ours) == sorted(theirs) and ours == theirs
