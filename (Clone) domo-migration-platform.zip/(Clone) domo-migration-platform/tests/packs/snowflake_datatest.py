"""snowflake_datatest - run a benchmark case's CONVERTED SQL on a database and compare the rows (X5, ADR 037
section 8: the silent-semantics test kit).

Two executors share one case format (``tests/fixtures/snowflake/conversion/corpus_1_semantics.yaml``):

    DuckDB (local, offline)   the Databricks text is transpiled ``databricks -> duckdb`` with sqlglot; the converted
                              rules write explicit NULLS FIRST / LAST so the transpile is neutral. A few Spark functions
                              DuckDB spells differently are renamed by ``DUCKDB_SHIMS`` (each is the same function: a
                              rename, never a rewrite of the semantics). A case that DuckDB cannot run faithfully is
                              marked ``live_only`` in the corpus with the reason.
    Databricks SQL warehouse  the same converted text on temp views built from the case's data (``-m databricks``).

Data format (``data.tables``): ``{NAME: {columns: [...], rows: [[...]], types: {COL: TYPE}}}``; a cell given as a JSON
array / object string in a column typed ``ARRAY`` / ``MAP`` / ``...[]`` is loaded as that structure. ``expect`` is the list
of rows Snowflake returns (hand-computed, ``unverified`` until the account run).
"""
from __future__ import annotations

import datetime as dt
import decimal
import json
import os
import re
from typing import Any

import sqlglot
from sqlglot import exp

#: Spark function -> the DuckDB function with the same semantics (a rename); applied to the parsed Databricks tree.
DUCKDB_SHIMS = {"BROUND": "ROUND_EVEN", "TRY_ELEMENT_AT": "LIST_EXTRACT"}


def strip_qualifiers(tree: exp.Expression) -> None:
    for t in tree.find_all(exp.Table):
        t.set("catalog", None)
        t.set("db", None)


def to_duckdb(databricks_sql: str) -> str:
    tree = sqlglot.parse_one(databricks_sql, read="databricks")
    strip_qualifiers(tree)
    for node in list(tree.find_all(exp.Kurtosis)):        # Spark kurtosis = the population excess kurtosis
        node.replace(exp.Anonymous(this="KURTOSIS_POP", expressions=[node.this.copy()]))
    for node in list(tree.find_all(exp.DayOfWeek)):       # Spark Sunday=1..Saturday=7; DuckDB dayofweek is Sunday=0..6
        node.replace(exp.Paren(this=exp.Add(this=exp.Anonymous(this="DAYOFWEEK", expressions=[node.this.copy()]),
                                            expression=exp.Literal.number(1))))
    for node in list(tree.find_all(exp.StrToTime)):       # Spark fractional-second letters -> strptime %g / %f
        f = node.args.get("format")
        if isinstance(f, exp.Literal) and f.is_string:
            node.set("format", exp.Literal.string(re.sub(r"\.S{6}(?!S)", ".%f", re.sub(r"\.S{3}(?!S)", ".%g", f.this))))
    for node in list(tree.find_all(exp.Anonymous)):
        new = DUCKDB_SHIMS.get(str(node.this).upper())
        if new:
            node.set("this", new)
    return tree.sql(dialect="duckdb")


def _duck_type(values: list[Any], declared: str | None) -> str:
    if declared:
        return declared
    kinds = {type(v) for v in values if v is not None}
    if kinds <= {bool}:
        return "BOOLEAN"
    if kinds <= {int, bool}:
        return "BIGINT"
    if kinds <= {int, float}:
        return "DOUBLE"
    return "VARCHAR"


def _is_nested(declared: str | None) -> bool:
    return bool(declared and re.match(r"^(ARRAY|MAP|STRUCT)|\[\]$", declared, re.I))


def load_duckdb(con: Any, tables: dict[str, dict]) -> None:
    for name, spec in (tables or {}).items():
        cols = [str(c).lower() for c in spec["columns"]]
        types = {str(k).lower(): v for k, v in (spec.get("types") or {}).items()}
        rows = spec.get("rows") or []
        decl = [_duck_type([r[i] for r in rows], types.get(c)) for i, c in enumerate(cols)]
        con.execute(f"CREATE TABLE {name.lower()} (" + ", ".join(f'"{c}" {t}' for c, t in zip(cols, decl)) + ")")
        for r in rows:
            cells = [json.loads(v) if _is_nested(types.get(c)) and isinstance(v, str) else v for v, c in zip(r, cols)]
            con.execute(f"INSERT INTO {name.lower()} VALUES (" + ", ".join("?" for _ in cols) + ")", cells)


def run_duckdb(databricks_sql: str, tables: dict[str, dict], prelude: str | None = None) -> list[list[Any]]:
    import duckdb
    con = duckdb.connect(":memory:")
    try:
        load_duckdb(con, tables)
        if prelude and prelude.upper().startswith("SET TIME ZONE"):
            con.execute("SET TimeZone=" + prelude.split("TIME ZONE", 1)[1].strip().replace('"', "'"))
        return [list(r) for r in con.execute(to_duckdb(databricks_sql)).fetchall()]
    finally:
        con.close()


# ------------------------------------------------------------------------------------------------ comparison
def _ts(text: str) -> str:
    text = re.sub(r"(\.\d*?)0+$", r"\1", text)
    return text[:-1] if text.endswith(".") else text


def canonical(v: Any) -> Any:
    """One comparable form for a returned or expected cell."""
    if v is None or isinstance(v, (bool, int)):
        return v
    if isinstance(v, (float, decimal.Decimal)):
        return round(float(v), 4)
    if isinstance(v, dt.datetime):          # a midnight timestamp equals the date: DATE vs TIMESTAMP is the rules' job
        return v.date().isoformat() if v.time() == dt.time(0) else _ts(v.isoformat(sep=" "))
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, (list, tuple, dict)):
        return json.dumps(v, separators=(",", ":"), default=str)
    if isinstance(v, str):
        if re.match(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}", v):
            return re.sub(r" 00:00:00$", "", _ts(v.replace("T", " ")))
        if v[:1] in "[{":
            try:
                return json.dumps(json.loads(v), separators=(",", ":"))
            except ValueError:
                return v
        return v
    return str(v)


def top_level_order(databricks_sql: str) -> bool:
    """Does the statement itself order its rows (a window or aggregate ORDER BY does not)?"""
    tree = sqlglot.parse_one(databricks_sql, read="databricks")
    return tree.args.get("order") is not None


def rows_match(actual: list[list[Any]], expected: list[list[Any]], ordered: bool) -> bool:
    a = [[canonical(c) for c in r] for r in actual]
    e = [[canonical(c) for c in r] for r in expected]
    if not ordered:
        a, e = sorted(a, key=repr), sorted(e, key=repr)
    return a == e


# ------------------------------------------------------------------------------------------------ Databricks warehouse
def _sql_value(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(v)
    return "'" + str(v).replace("'", "''") + "'"


def temp_view_statements(tables: dict[str, dict]) -> list[str]:
    """``CREATE OR REPLACE TEMP VIEW`` per table from the case's rows; typed columns are cast so the converted SQL sees
    the types the corpus declares (``types``), JSON array / map cells go through ``from_json``."""
    out = []
    for name, spec in (tables or {}).items():
        cols = [str(c).lower() for c in spec["columns"]]
        types = {str(k).lower(): v for k, v in (spec.get("types") or {}).items()}
        rows = spec.get("rows") or []
        values = ", ".join("(" + ", ".join(_sql_value(v) for v in r) + ")" for r in rows) or \
            "(" + ", ".join("NULL" for _ in cols) + ")"
        raw = f"SELECT * FROM VALUES {values} AS v({', '.join(cols)})"
        proj = []
        for c in cols:
            t = types.get(c)
            if t and t.upper().endswith("[]"):
                proj.append(f"from_json({c}, 'ARRAY<{t[:-2]}>') AS {c}")
            elif t and re.match(r"^(ARRAY|MAP|STRUCT)", t, re.I):
                proj.append(f"from_json({c}, '{t}') AS {c}")
            elif t:
                proj.append(f"CAST({c} AS {t}) AS {c}")
            else:
                proj.append(c)
        where = "" if rows else " WHERE 1 = 0"
        out.append(f"CREATE OR REPLACE TEMP VIEW {name.lower()} AS SELECT {', '.join(proj)} FROM ({raw}){where}")
    return out


def run_databricks(databricks_sql: str, tables: dict[str, dict], prelude: str | None = None) -> list[list[Any]]:
    """The same converted SQL on a SQL warehouse (``-m databricks``). Needs DATABRICKS_SERVER_HOSTNAME,
    DATABRICKS_HTTP_PATH and DATABRICKS_TOKEN in the environment (never read from a file)."""
    from databricks import sql as dbsql
    tree = sqlglot.parse_one(databricks_sql, read="databricks")
    strip_qualifiers(tree)
    with dbsql.connect(server_hostname=os.environ["DATABRICKS_SERVER_HOSTNAME"], http_path=os.environ["DATABRICKS_HTTP_PATH"],
                       access_token=os.environ["DATABRICKS_TOKEN"]) as conn, conn.cursor() as cur:
        for stmt in temp_view_statements(tables):
            cur.execute(stmt)
        if prelude:
            cur.execute(prelude)
        cur.execute(tree.sql(dialect="databricks"))
        return [list(r) for r in cur.fetchall()]


def databricks_configured() -> bool:
    return all(os.environ.get(k) for k in ("DATABRICKS_SERVER_HOSTNAME", "DATABRICKS_HTTP_PATH", "DATABRICKS_TOKEN"))


__all__ = ["DUCKDB_SHIMS", "canonical", "databricks_configured", "load_duckdb", "rows_match", "run_databricks",
           "run_duckdb", "temp_view_statements", "to_duckdb", "top_level_order"]
