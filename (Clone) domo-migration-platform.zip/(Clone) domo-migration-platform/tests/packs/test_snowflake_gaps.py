"""S17b conversion gaps (catalogue 2.4, 2.10, 2.13-2.17, 2.24, 2.30, 6.12, 6.18; X6-X8; L10, L12, L13). Offline, synthetic."""
from __future__ import annotations

import ast
import json

import pytest

from packs.snowflake import caveats as cav
from packs.snowflake import dynamic_sql, federation, overloads
from packs.snowflake import objects as ob
from packs.snowflake import translate as tr
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.handlers import ROUTE_FEDERATED, route_of
from packs.snowflake.postpass import Postpass, PostpassContext
from packs.snowflake.rules import cortex, gaps
from packs.snowflake.validators import sniff_kind, validate

TABLES = {("DB", "S", "T"): "main.s.t", ("DB", "S", "Q"): "main.s.q"}


def _tier0(sql: str, **kw):
    ctx = tr.make_context(etl_key="k", engine="sql_view", table_map=TABLES, default_db="DB", default_schema="S", **kw)
    return tr.tier0_unit(tr.PreUnit("u", {"sql": sql, "language": "sql"}, "sql_view"), ctx)


def test_every_new_flag_id_is_in_the_catalogue() -> None:
    table = cav.load_catalogue().by_id()
    for fid in ("SNW-STRTOK", "SNW-STRTOK-UNSUPPORTED", "SNW-FLATTEN", "SNW-FLATTEN-UNSUPPORTED", "SNW-ASOF",
                "SNW-ASOF-UNSUPPORTED", "SNW-MATCH-RECOGNIZE-REWRITE", "SNW-MATCH-RECOGNIZE-UNSUPPORTED",
                "SNW-CONNECT-BY-REWRITE", "SNW-CONNECT-BY-UNSUPPORTED", "SNW-PIVOT-DYNAMIC", "SNW-PIVOT-FROZEN",
                "SNW-RESULT-SCAN-UNSUPPORTED", "SNW-SYSTEM-TABLE", "SNW-SYSTEM-TABLE-UNMAPPED", "SNW-CORTEX",
                "SNW-CORTEX-MODEL", "SNW-DYNAMIC-SQL-SHIM", "SNW-FEDERATED", "SNW-UDF-OVERLOAD", "SNW-DMF-RULE",
                "SNW-PROFILE-ASSUMED"):
        assert fid in table, fid
    assert table["SNW-FLATTEN-UNSUPPORTED"].severity == "escalate" and table["SNW-FLATTEN"].severity == "review"


def test_strtok_family_and_split_to_table() -> None:
    res, item = _tier0("SELECT STRTOK(a, ',;', 2) AS x, STRTOK_TO_ARRAY(a) AS y FROM DB.S.T")
    assert item is None and "try_element_at(filter(split(a, '[,;]'), x -> x <> ''), 2)" in res.sql.lower()
    assert "SNW-STRTOK" in res.review_caveats
    res, item = _tier0("SELECT s.index, s.value FROM DB.S.T t, TABLE(SPLIT_TO_TABLE(t.a, ',')) s")
    assert item is None and "POSEXPLODE" in res.sql.upper() and "s.pos + 1" in res.sql
    res, item = _tier0("SELECT STRTOK(a, '-', 1) FROM DB.S.T")                  # a hyphen needs an escape: escalated
    assert item is not None and any("SNW-STRTOK-UNSUPPORTED" in r for r in res.reasons)


def test_flatten_outputs_and_recursive_flag() -> None:
    res, item = _tier0("SELECT t.a, f.index, f.value FROM DB.S.T t, LATERAL FLATTEN(input => t.arr, outer => true) f")
    assert item is None and "LATERAL VIEW OUTER POSEXPLODE(t.arr) f AS index, value" in res.sql
    res, item = _tier0("SELECT f.value FROM DB.S.T t, LATERAL FLATTEN(input => t.arr, recursive => true) f")
    assert item is not None and any("SNW-FLATTEN-UNSUPPORTED" in r and "WITH RECURSIVE" in r for r in res.reasons)


def test_asof_connect_by_match_recognize_and_pivot() -> None:
    res, item = _tier0("SELECT t.a, q.b FROM DB.S.T t ASOF JOIN DB.S.Q q MATCH_CONDITION (t.ts >= q.ts) ON t.k = q.k")
    assert item is None and "QUALIFY ROW_NUMBER() OVER (PARTITION BY t.__asof_id ORDER BY q.ts DESC) = 1" in res.sql
    assert "SNW-ASOF" in res.review_caveats
    res, item = _tier0("SELECT a, LEVEL FROM DB.S.T START WITH p IS NULL CONNECT BY PRIOR a = p")
    assert item is None and res.sql.startswith("WITH RECURSIVE __cb AS") and "p.__level + 1" in res.sql
    cons = ConversionContext.build(capability_profile="databricks_sql_conservative")
    res, item = _tier0("SELECT a FROM DB.S.T START WITH p IS NULL CONNECT BY PRIOR a = p", conversion=cons)
    assert item is not None and any("SNW-CONNECT-BY-UNSUPPORTED" in r for r in res.reasons)
    res, item = _tier0("SELECT * FROM DB.S.T MATCH_RECOGNIZE (PARTITION BY u ORDER BY ts MEASURES COUNT(*) AS n "
                       "PATTERN (a+) DEFINE a AS x > 1) m")
    assert item is None and "GROUP BY u, __mr_g" in res.sql
    q = "SELECT * FROM DB.S.T PIVOT (SUM(amount) FOR month IN (ANY ORDER BY month))"
    res, item = _tier0(q)
    assert item is not None and any("SNW-PIVOT-DYNAMIC" in r for r in res.reasons)
    res, item = _tier0(q, conversion=ConversionContext.build(pivot_values={"month": ["jan", "feb"]}))
    assert item is None and "IN ('jan', 'feb')" in res.sql and "SNW-PIVOT-FROZEN" in res.review_caveats


def test_system_tables_and_result_scan() -> None:
    res, item = _tier0("SELECT table_name FROM INFORMATION_SCHEMA.TABLES")
    assert item is None and "main.information_schema.tables" in res.sql
    res, item = _tier0("SELECT query_id FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY")
    assert item is not None and any("SNW-SYSTEM-TABLE-UNMAPPED" in r for r in res.reasons)
    res, item = _tier0("SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))")
    assert item is not None and any("SNW-RESULT-SCAN-UNSUPPORTED" in r for r in res.reasons)


def test_cortex_maps_to_ai_functions_and_reads_the_endpoint_map() -> None:
    res, item = _tier0("SELECT SNOWFLAKE.CORTEX.COMPLETE('llama3-8b', p) AS a, SNOWFLAKE.CORTEX.SUMMARIZE(p) AS s FROM DB.S.T")
    assert item is None and "AI_QUERY('databricks-meta-llama-3-1-8b-instruct', p)" in res.sql and "AI_SUMMARIZE(p)" in res.sql
    assert "SNW-CORTEX" in res.review_caveats
    res, item = _tier0("SELECT SNOWFLAKE.CORTEX.COMPLETE('new-model', p) FROM DB.S.T")
    assert item is None and "SNW-CORTEX-MODEL" in res.review_caveats
    assert cortex.endpoint_map()["default_endpoint"]


def test_profile_decisions_need_a_profile() -> None:
    cols = {"main.s.t": {"big": "NUMBER(38,0)", "ts_raw": "NUMBER(38,0)"}}
    prof = {"main.s.t": {"big": {"min": "1", "max": "99"}, "ts_raw": {"min": "1700000000", "max": "1710000000"}}}
    q = "SELECT CAST(big AS NUMBER(38,0)) AS b, TO_TIMESTAMP(ts_raw) AS ts FROM DB.S.T"
    with_p, _ = _tier0(q, conversion=ConversionContext.build(catalogue=cols, profiles=prof))
    assert "CAST(big AS BIGINT)" in with_p.sql and "TIMESTAMP_SECONDS(ts_raw)" in with_p.sql
    assert "SNW-PROFILE-ASSUMED" in with_p.review_caveats
    without, item = _tier0(q, conversion=ConversionContext.build(catalogue=cols))
    assert "BIGINT" not in without.sql                      # no profile: no decision


def test_default_nextval_becomes_identity_only_for_a_known_sequence() -> None:
    seqs = {"sequences": [{"id": "DB.S.ORD", "database": "DB", "schema": "S", "name": "ORD", "next_value": 500,
                           "interval": 5, "ordered": False}]}
    ddl = "CREATE TABLE DB.S.T (id NUMBER DEFAULT ord.NEXTVAL, v VARCHAR)"
    res, item = _tier0(ddl, conversion=ConversionContext.build(source_objects=seqs))
    assert item is None and "GENERATED BY DEFAULT AS IDENTITY (START WITH 500 INCREMENT BY 5)" in res.sql
    res, item = _tier0(ddl)
    assert item is not None and any("SNW-SEQ-SHARED" in r for r in res.reasons)


def test_statements_validator_revalidates_each_statement() -> None:
    text = "CREATE OR REPLACE TEMP VIEW v AS SELECT 1 AS a; INSERT INTO t SELECT a FROM v"
    assert sniff_kind(text) == "statements" and validate("statements", text) == []
    bad = "INSERT INTO t SELECT 1; INSERT INTO u SELECT FROM"
    assert sniff_kind(bad) == "statements" or validate(sniff_kind(bad), bad)
    assert validate("statements", "INSERT INTO t SELECT 1; GRANT ALL ON t TO x") != []


def test_federated_route_and_view() -> None:
    row = {"engine": "sql_view", "etl_id": "e", "disposition": "federate"}
    assert route_of(row)[0] == ROUTE_FEDERATED
    doc = {"engine": "sql_view", "asset_id": "snowflake:view:acme.DB.S.V"}
    built = federation.federated_view(doc, "main.s.v", "snf_fed")
    assert built["status"] == "awaiting_review" and "SELECT * FROM snf_fed.s.v" in built["text"]
    assert "placeholder" in " ".join(federation.federated_view(doc, "main.s.v", "")["reasons"])
    proc = federation.federated_view({"engine": "sql_procedure", "asset_id": "snowflake:view:acme.DB.S.P"}, "x", "c")
    assert proc["status"] == "unsupported"


def test_overloaded_udfs_are_renamed_by_signature_and_calls_follow_arity() -> None:
    manifest = {"etls": [{"engine": "udf_sql", "asset_id": "snowflake:function:acme.DB.S.func/F(NUMBER)"},
                         {"engine": "udf_sql", "asset_id": "snowflake:function:acme.DB.S.func/F(VARCHAR, NUMBER)"},
                         {"engine": "udf_sql", "asset_id": "snowflake:function:acme.DB.S.func/G(NUMBER)"}]}
    plan = overloads.plan(manifest)
    assert sorted(plan.by_asset.values()) == ["f__number", "f__varchar_number"] and ("DB", "S", "F") in plan.by_call
    pp = Postpass(PostpassContext(table_map=TABLES, default_db="DB", default_schema="S",
                                  overload_calls=plan.by_call))
    out = pp.apply("SELECT S.F(a) AS x, S.F(a, b) AS y FROM main.s.t")
    assert "f_number(a)" in out.sql and "f_varchar_number(a, b)" in out.sql and out.renamed and not out.ambiguous
    amb = overloads.plan({"etls": [{"engine": "udf_sql", "asset_id": "x:y:a.DB.S.func/F(NUMBER)"},
                                   {"engine": "udf_sql", "asset_id": "x:y:a.DB.S.func/F(FLOAT)"}]})
    pp2 = Postpass(PostpassContext(table_map=TABLES, default_db="DB", default_schema="S", overload_calls=amb.by_call))
    assert pp2.apply("SELECT S.F(a) FROM main.s.t").problems          # same arity: never a guess


def test_dmf_becomes_a_quality_rule_proposal() -> None:
    res = ob.convert_object("dmf", "ALTER TABLE t ADD DATA METRIC FUNCTION SNOWFLAKE.CORE.NULL_COUNT ON (id) "
                                   "EXPECTATION no_nulls (VALUE = 0)")
    draft = json.loads(res.text)["proposals"][0]
    assert res.status == "converted" and draft["type"] == "not_null" and draft["origin"] == "template"
    assert draft["threshold"] == {"max_failing_rows": 0} and "SNW-DMF-RULE" in res.caveats
    assert ob.convert_object("dmf", "ALTER TABLE t ADD DATA METRIC FUNCTION db.s.custom ON (x)").status == "flagged"


def test_dynamic_sql_shim_is_opt_in_and_valid_python() -> None:
    ast.parse(dynamic_sql.shim_notebook_source())
    ddl = dynamic_sql.shim_function_ddl("main.m.snowflake_to_databricks")
    assert "LANGUAGE PYTHON" in ddl and "sqlglot==" in ddl
    body = ddl.split("$$")[1]
    ast.parse("def f(text):\n" + body.split("\n", 1)[1] if body.lstrip().startswith("import") else body)
    proc = ("CREATE OR REPLACE PROCEDURE p(tbl STRING) RETURNS STRING LANGUAGE SQL AS $$\nBEGIN\n  EXECUTE IMMEDIATE "
            "'TRUNCATE TABLE ' || :tbl;\n  RETURN 'ok';\nEND;\n$$")
    doc = {"etl_id": "e", "engine": "sql_procedure", "asset_id": "a:b:acme.DB.S.p", "name": "P", "definition": proc}
    import asyncio
    off = asyncio.run(tr.translate_etl(doc, tr.make_context(etl_key="k", engine="sql_procedure", table_map=TABLES,
                                                            default_db="DB", default_schema="S")))
    assert off[0].status != "resolved"
    on = asyncio.run(tr.translate_etl(doc, tr.make_context(etl_key="k", engine="sql_procedure", table_map=TABLES,
                                                           default_db="DB", default_schema="S",
                                                           dynamic_shim="main.m.snowflake_to_databricks")))
    assert on[0].status == "resolved" and "main.m.snowflake_to_databricks(" in on[0].sql
    assert "SNW-DYNAMIC-SQL-SHIM" in on[0].review_caveats


def test_notebook_procedure_calls_name_their_widgets() -> None:
    ctx = tr.make_context(etl_key="k", engine="task", table_map=TABLES, default_db="DB", default_schema="S",
                          notebook_procs={"DB.S.JSP": ["P_MODE", "P_LIMIT"]})
    call = tr.tier0_call("CALL DB.S.JSP('full', 10)", ctx)
    assert call["notebook_params"] == ["P_MODE", "P_LIMIT"]
    from packs.snowflake.handlers import _job_task_of
    res = tr.UnitResult("u", "task", params={"call": call})
    assert _job_task_of([res])["notebook_task"]["base_parameters"] == {"P_MODE": "full", "P_LIMIT": "10"}


def test_sql_generator_forwards_the_conversion_context() -> None:
    from agents.cd_codegen import sql_generator as sg
    seen = {}

    class P:
        def registry(self, dialect, **kw):
            seen.update(kw)
            return object()
    marker = ConversionContext()
    sg._registry_of(P(), "sql", marker)
    assert seen == {"conversion": marker}
    seen.clear()
    sg._registry_of(P(), "sql")
    assert seen == {}


@pytest.mark.parametrize("fn", [gaps.rule_flatten, gaps.rule_asof, gaps.rule_connect_by])
def test_rules_leave_a_plain_select_untouched(fn) -> None:
    import sqlglot

    from packs.snowflake.rules.base import RuleContext, SnowflakeSource
    tree = sqlglot.parse_one("SELECT a FROM t WHERE b = 1", read=SnowflakeSource)
    before = tree.sql()
    rc = RuleContext(ConversionContext())
    fn(tree, rc)
    assert tree.sql() == before and not rc.flags
