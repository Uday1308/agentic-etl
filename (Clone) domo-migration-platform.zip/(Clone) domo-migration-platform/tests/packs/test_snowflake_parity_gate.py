"""Q10 / L7 / S12 (ADR 035, 037): the Snowflake source query, the batch parity gate and the sign-off pack.
Offline: ``httpx.MockTransport``, ``FakeWarehouse`` and a generated test key only (hard rule 10)."""
from __future__ import annotations

import asyncio
import json
import pathlib

import httpx
from snowflake_bundle import make_bundle

from packs.snowflake import parity_batch as pb
from packs.snowflake import signoff
from packs.snowflake import source_query as sq
from packs.snowflake.warehouse import FakeWarehouse
from scripts.run_batch import run_batch

ORDERS = "main.sfdemo_sales_db_core.orders"
SRC_ROW = {"M0": "5", "C0_NULLS": "0", "C0_DISTINCT": "5", "C0_SUM": "15", "C0_MIN": "1", "C0_MAX": "5"}
TGT_ROW = {k.lower(): v for k, v in SRC_ROW.items()}


def _pem() -> str:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption()).decode("ascii")


def test_source_query_reads_rows_over_the_sql_api_and_never_leaks(tmp_path):
    seen = []

    def handler(req: httpx.Request) -> httpx.Response:
        seen.append((req.method, req.url.path, req.headers.get("authorization", "")[:6]))
        return httpx.Response(200, json={"resultSetMetaData": {"rowType": [{"name": "M0"}], "partitionInfo": [{}]},
                                         "data": [["5"]], "statementHandle": "h"})

    pem = tmp_path / "k.pem"
    pem.write_text(_pem(), encoding="ascii")
    src, why = sq.from_env({"SOURCE_CREDENTIAL_ACCOUNT": "acme-prod", "SOURCE_CREDENTIAL_USER": "svc",
                            "SOURCE_CREDENTIAL_PRIVATE_KEY": str(pem)}, transport=httpx.MockTransport(handler))
    assert src is not None and why == "" and not pem.exists()          # the key file is read once and deleted
    assert src.query("SELECT 1") == [{"M0": "5"}] and seen[0][:2] == ("POST", "/api/v2/statements")
    assert seen[0][2] == "Bearer" and src.host == "acme-prod.snowflakecomputing.com"


def test_source_query_errors_carry_no_secret():
    def handler(req):
        return httpx.Response(422, json={"code": "000904", "message": "SQL compilation error: secret_value"})

    auth = sq.KeyPairAuth("acme-prod", "svc", _pem())
    src = sq.SnowflakeSourceQuery("acme-prod", auth, transport=httpx.MockTransport(handler))
    try:
        src.query("SELECT secret_value")
    except sq.SourceQueryError as exc:
        assert "secret_value" not in str(exc) and exc.kind == "statement" and exc.error_class == "000904"
    else:
        raise AssertionError("expected an error")


def test_no_credentials_is_none_with_a_reason():
    src, why = sq.from_env({})
    assert src is None and "no Snowflake source credentials" in why


def _bundle(tmp_path, *, boundary=True, columns=True):
    b = make_bundle(tmp_path)
    m = json.loads((b / "manifest.json").read_text(encoding="utf-8"))
    if columns:
        m["source_columns"] = {ORDERS: {"ID": "NUMBER(38,0)"}}
    if boundary:
        m["load_boundaries"] = {ORDERS: "2026-11-06T00:00:00Z"}
    (b / "manifest.json").write_text(json.dumps(m), encoding="utf-8")
    return b


def _run(tmp_path, source, target, **kw):
    b = _bundle(tmp_path, **kw)
    return asyncio.run(run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work",
                                 parity_ports=(source, target, "")))


def _ports(target_row):
    return FakeWarehouse().on('from "sales_db"', [SRC_ROW]), FakeWarehouse().on("from `main`", [target_row])


def test_a_mismatch_adds_the_caveat_and_holds_the_batch(tmp_path):
    rep = _run(tmp_path, *_ports({**TGT_ROW, "c0_sum": "16"}))
    assert rep["parity"]["status"] == "mismatched"
    unit = next(r for r in rep["etls"] if r["etl_id"] == pb.PARITY_ETL_ID)
    assert unit["status"] == "awaiting_review" and unit["gate_id"] and rep["summary"]["status"] == "needs_review"
    reader = next(r for r in rep["etls"] if r["name"] == "V_ORDER_NET")
    assert "SNW-PARITY-MISMATCH" in reader["caveats"] and reader["parity"][ORDERS]["status"] == "mismatched"
    assert "16" not in json.dumps(unit)                                 # aggregates stay in the report, not the unit
    gate = pathlib.Path(unit["run_dir"]) / "gates" / f"{unit['gate_id']}.json"
    assert json.loads(gate.read_text(encoding="utf-8"))["agent"] == "validation"
    assert list(pathlib.Path(rep["report_path"]).parent.glob("*/parity/parity_report.json"))


def test_a_match_holds_nothing(tmp_path):
    rep = _run(tmp_path, *_ports(TGT_ROW))
    assert rep["parity"]["status"] == "inconclusive"            # the other landed tables are unverifiable
    t = {x["target"]: x for x in rep["parity"]["tables"]}
    assert t[ORDERS]["status"] == "passed" and t[ORDERS]["boundary"] == "2026-11-06T00:00:00Z"
    assert not any(r["etl_id"] == pb.PARITY_ETL_ID for r in rep["etls"])


def test_unknown_boundary_is_unverifiable_with_the_reason(tmp_path):
    src, tgt = _ports(TGT_ROW)
    rep = _run(tmp_path, src, tgt, boundary=False)
    assert rep["parity"]["status"] == "unverifiable" and "load boundary is unknown" in rep["parity"]["reason"]
    assert src.calls == [] and tgt.calls == []                  # never compared at "now"


def test_no_source_connection_is_unverifiable(tmp_path):
    rep = _run(tmp_path, None, FakeWarehouse())
    assert rep["parity"]["status"] == "unverifiable"


def test_signoff_claims_only_what_ran(tmp_path):
    rep = _run(tmp_path, *_ports({**TGT_ROW, "c0_sum": "16"}))
    so = rep["signoff"]
    d = pathlib.Path(so["dir"])
    assert (d / "cutover_runbook.md").exists() and so["ready"] is False
    checks = {c["check"]: c["status"] for c in so["checks"]}
    assert checks["Deployed to Databricks"] == "not run" and checks["Data parity (counts, checksums, column profiles)"] == "mismatched"
    assert checks["Converted code checked on Databricks (EXPLAIN / schema)"] == "not run"
    text = (d / "cutover_runbook.md").read_text(encoding="utf-8")
    assert "Not ready for cut-over" in text and "Deployed to Databricks: **not run**" in text
    assert "SELECT" not in text
    assert ("signoff.xlsx" in so["files"]) or ("signoff.md" in so["files"])


def test_signoff_csv_fallback_when_openpyxl_is_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(signoff, "_xlsx", lambda *a, **k: False)
    out = signoff.write({"counts": {}, "rows": [], "etls": [], "batch_run_id": "b"}, tmp_path / "s")
    assert out["format"] == "csv+markdown" and (tmp_path / "s" / "signoff.md").exists()
