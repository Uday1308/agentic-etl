"""A synthetic Snowflake handoff bundle (manifest v2) for the offline batch tests and the translation eval.

Mirrors the shape of ``tests/fixtures/snowflake`` (account ``acme-prod``, ``SALES_DB.CORE``): a view over a table, a
dynamic table, a 4-deep task graph with a finalizer, a Scripting procedure, a SQL UDF and the view that calls it, a
secure (hidden) view, a pipe (routed to ``file_load``) and a ``query`` writer (routed to ``statement``). Synthetic
only: no real names, e-mails or keys. The per-ETL ``etls/<id>.json`` holds the merged unit document
(``packs.snowflake.contract.unit_doc`` also reads a raw SQL API partition; see test_snowflake_contract.py).
"""
from __future__ import annotations

import json
import pathlib

ACCT = "acme-prod"


def oid(schema: str, name: str, objtype: str = "", sig: str | None = None) -> str:
    return f"{ACCT}.SALES_DB.{schema}.{objtype + '/' if objtype else ''}{name}" + (f"({sig})" if sig is not None else "")


def table(schema: str, name: str) -> dict:
    return {"dataset_id": oid(schema, name), "name": name, "table": f"main.sfdemo_sales_db_{schema.lower()}.{name.lower()}",
            "availability": "earlier_wave"}


def etl(order: int, name: str, schema: str, engine: str, definition: object, *, inputs=(), outputs=(), objtype: str = "",
        sig: str | None = None, params: dict | None = None, **extra) -> tuple[dict, dict]:
    eid = f"{ACCT}.SALES_DB.{schema}.{name}"
    doc = {"definition": definition, "params": params or {}}
    row = {"order": order, "etl_id": eid, "asset_id": oid(schema, name, objtype, sig), "name": name, "engine": engine,
           "etl_key": f"sfdemo__{name}", "definition": f"etls/{name}.json", "inputs": list(inputs), "outputs": list(outputs),
           "batch_id": "w1", "depends_on_etls": [], **extra}
    return row, doc


def make_bundle(root: pathlib.Path) -> pathlib.Path:
    b = root / "bundle"
    (b / "etls").mkdir(parents=True)
    orders, customers = table("CORE", "ORDERS"), table("CORE", "CUSTOMERS")
    rows: list[tuple[dict, dict]] = [
        etl(1, "UDF_NET_AMOUNT", "CORE", "udf_sql", "amount - discount", objtype="func", sig="NUMBER,NUMBER",
            params={"data_type": "NUMBER(38,2)"}),
        etl(2, "V_ORDER_NET", "CORE", "sql_view",
            "SELECT o.ORDER_ID, CORE.UDF_NET_AMOUNT(o.AMOUNT, o.DISCOUNT) AS NET, IFF(o.AMOUNT > 100, 'big', 'small') AS BAND "
            "FROM CORE.ORDERS o", inputs=[orders],
            outputs=[table("ANALYTICS", "V_ORDER_NET")]),
        etl(3, "DT_ORDER_DAILY", "CORE", "dynamic_table",
            "SELECT DATE_TRUNC('day', ORDER_TS) AS DAY, SUM(AMOUNT) AS TOTAL FROM CORE.ORDERS GROUP BY 1",
            inputs=[orders], outputs=[table("CORE", "DT_ORDER_DAILY")], params={"target_lag": "1 hour"}),
        etl(4, "V_SECURE_MARGIN", "ANALYTICS", "sql_view", {"state": "unavailable", "reason": "secure view body hidden"},
            params={"secure": True}),
        etl(5, "SCRIPT_REFRESH", "CORE", "sql_procedure",
            "BEGIN\n  TRUNCATE TABLE CORE.STAGE_ORDERS;\n  IF (1 = 1) THEN\n    INSERT INTO CORE.STAGE_ORDERS SELECT * FROM CORE.ORDERS;\n"
            "  END IF;\nEND", objtype="proc", sig="",
            inputs=[orders]),
    ]
    graph = [("ROOT_DAILY", [], "USING CRON 0 6 * * * UTC", False),
             ("MERGE_ORDERS", ["ROOT_DAILY"], None, False),
             ("BUILD_ORDER_FACTS", ["MERGE_ORDERS"], None, False),
             ("REFRESH_FIN_SUMMARY", ["BUILD_ORDER_FACTS"], None, False),
             ("NOTIFY_FINALIZER", [], None, True)]
    for i, (name, preds, sched, fin) in enumerate(graph):
        rel = {"Predecessors": [f"SALES_DB.CORE.{p}" for p in preds]}
        if fin:
            rel["FinalizedRootTaskName"] = "SALES_DB.CORE.ROOT_DAILY"
        rows.append(etl(6 + i, name, "CORE", "task", f"INSERT INTO CORE.RUN_LOG SELECT '{name}', CURRENT_TIMESTAMP()",
                        params={"schedule": sched, "task_relations": json.dumps(rel)}))
    rows.append(etl(11, "LEGACY_EVENTS_PIPE", "RAW", "snowpipe", "COPY INTO RAW.EVENTS FROM @RAW.STG", unit_kind="file_load"))
    rows.append(etl(12, "QW_dbt_orders", "CORE", "query", "MERGE INTO CORE.ORDERS t USING CORE.ORDERS_NEW s ON t.ID = s.ID "
                    "WHEN MATCHED THEN UPDATE SET t.AMOUNT = s.AMOUNT", unit_kind="statement"))
    for row, doc in rows:
        (b / "etls" / f"{row['name']}.json").write_text(json.dumps(doc), encoding="utf-8")
    manifest = {
        "manifest_version": "2", "kind": "etl_logic_migration", "snapshot_id": "sf-1", "strategy": "dependency_waves",
        "strategy_label": "Dependency waves", "selection": {"key": "wave-1", "wave": 1, "batch_ids": ["w1"]},
        "source": {"id": "sfdemo", "key": "sfdemo", "platform": "snowflake", "dialect": "snowflake"},
        "target": {"target_catalog": "main"}, "etls": [r for r, _ in rows], "file_loads": [], "read_statements": [],
        "table_map": {t["dataset_id"]: t["table"] for t in (
            orders, customers, table("CORE", "RUN_LOG"), table("CORE", "STAGE_ORDERS"), table("CORE", "ORDERS_NEW"))},
        "target_map": {}, "governance": [], "notes": [],
    }
    (b / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return b
