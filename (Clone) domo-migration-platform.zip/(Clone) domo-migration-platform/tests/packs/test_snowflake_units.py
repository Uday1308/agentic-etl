"""P3-18 / P3-19: file_load and statement builders (synthetic data only; literals stay redacted)."""
from __future__ import annotations

import asyncio

from packs.snowflake import units
from packs.snowflake.handlers import HandlerContext


def _doc(**kw):
    return {"etl_id": "11", "asset_id": "acct.RAW.PUBLIC.EVENTS_PIPE", "name": "EVENTS_PIPE", "engine": "snowpipe",
            "outputs": [{"table": "main.raw.events"}], "params": {}, **kw}


def test_cloud_path_maps_azure_and_gcs():
    assert units.cloud_path("azure://acct.blob.core.windows.net/box/in/")[0] == "abfss://box@acct.dfs.core.windows.net/in/"
    assert units.cloud_path("gcs://b/p")[0] == "gs://b/p"
    assert units.cloud_path("@stage/x")[1]


def test_pipe_becomes_auto_loader_with_caveat_for_unmapped_option():
    row = {"etl_id": "11", "url": "s3://bucket/events/", "auto_ingest": True,
           "file_format": {"options": {"TYPE": "CSV", "FIELD_DELIMITER": "|", "SKIP_HEADER": 1, "VALIDATE_UTF8": True}}}
    [art] = units.build_file_load(row, _doc(), HandlerContext())
    assert art.kind == "file_load" and art.origin == "manual"
    assert art.text.startswith("CREATE OR REFRESH STREAMING TABLE main.raw.events AS")
    assert "read_files(" in art.text and "delimiter => '|'" in art.text and "header => 'true'" in art.text
    assert any("VALIDATE_UTF8" in r for r in art.review_reasons)


def test_one_shot_load_becomes_copy_into():
    row = {"etl_id": "12", "url": "s3://bucket/x/", "file_format": "PARQUET"}
    [art] = units.build_file_load(row, _doc(engine="copy_into"), HandlerContext())
    assert art.text == "COPY INTO main.raw.events\nFROM 's3://bucket/x/'\nFILEFORMAT = PARQUET"
    assert not art.review_reasons


def test_missing_path_is_a_review_reason_not_a_guess():
    [art] = units.build_file_load({"etl_id": "13"}, _doc(), HandlerContext())
    assert any("cloud path unavailable" in r for r in art.review_reasons)


def test_statement_without_context_keeps_redacted_text_and_lists_repoints():
    row = {"etl_id": "20", "name": "BI_READ", "statements": ["SELECT a FROM SALES.CORE.ORDERS WHERE x = '[redacted-literal]'"]}
    arts = asyncio.run(units.build_statement(row, {"etl_id": "20", "name": "BI_READ"}, HandlerContext()))
    assert [a.kind for a in arts] == ["statement", "repoint_task"]
    assert arts[0].text.startswith("-- NOT TRANSLATED") and arts[0].origin == "manual"
    assert "SALES.CORE.ORDERS" in arts[1].text
    assert "[redacted-literal]" not in arts[1].text


def test_source_objects_ignore_ctes():
    objs = units.source_objects("WITH c AS (SELECT 1 FROM A.B.T) SELECT * FROM c", {})
    assert [o for o, _ in objs] == ["A.B.T"]


# ------------------------------------------------------------------------------ wave audit regressions (file loads)
def test_auto_formats_are_dropped_and_real_patterns_translated():
    fmt, opts, why = units.map_format({"TYPE": "CSV", "DATE_FORMAT": "AUTO", "TIMESTAMP_FORMAT": "AUTO"})
    assert (fmt, opts, why) == ("csv", {}, [])
    _fmt, opts, why = units.map_format({"TYPE": "CSV", "DATE_FORMAT": "YYYY-MM-DD", "TIMESTAMP_FORMAT": "YYYY-MM-DD HH24:MI:SS"})
    assert opts == {"dateFormat": "yyyy-MM-dd", "timestampFormat": "yyyy-MM-dd HH:mm:ss"} and not why
    _fmt, opts, why = units.map_format({"TYPE": "CSV", "DATE_FORMAT": "DD/MON/YYYY WEIRD"})
    assert "dateFormat" not in opts and any("DATE_FORMAT" in r for r in why)


def test_format_option_mappings_never_silently_dropped():
    _f, opts, why = units.map_format({"TYPE": "CSV", "SKIP_HEADER": 3, "NULL_IF": ["NA", "N/A", ""], "ESCAPE": "NONE",
                                     "FIELD_OPTIONALLY_ENCLOSED_BY": '"', "ENCODING": "ISO88591", "TRIM_SPACE": "true",
                                     "RECORD_DELIMITER": "|", "COMPRESSION": "GZIP", "NOPE": 1})
    assert opts["header"] == "true" and opts["skipRows"] == "2" and opts["nullValue"] == "NA"
    assert opts["quote"] == '"' and "escape" not in opts and opts["encoding"] == "ISO-8859-1"
    assert opts["ignoreLeadingWhiteSpace"] == "true" and opts["lineSep"] == "|"
    joined = " | ".join(why)
    assert "NULL_IF" in joined and "SKIP_HEADER" in joined and "NOPE" in joined


def test_pattern_regex_becomes_a_glob_or_a_review_reason():
    assert units.regex_to_glob(".*orders_.*[.]csv") == "*orders_*.csv"
    assert units.regex_to_glob("a(b|c)") is None


PIPE_ORDERS = ("COPY INTO SALES_DB.RAW.ORDERS_RAW\nFROM @SALES_DB.RAW.ORDERS_STAGE\n"
               "FILE_FORMAT = (FORMAT_NAME = 'SALES_DB.RAW.CSV_ORDERS_FMT')\nPATTERN = '.*orders_.*[.]csv'\n"
               "ON_ERROR = 'CONTINUE'\nMATCH_BY_COLUMN_NAME = CASE_INSENSITIVE")
PIPE_EVENTS = ("COPY INTO SALES_DB.RAW.EVENTS (EVENT_ID, EVENT_TS, PAYLOAD)\nFROM 's3://b/events/'\n"
               "FILE_FORMAT = (TYPE = JSON)\nON_ERROR = 'SKIP_FILE'")


def _pipe_doc(text, outputs, **kw):
    return {"etl_id": "p1", "asset_id": "snowflake:transform:acct.SALES_DB.RAW.pipe/P", "name": "SALES_DB.RAW.P",
            "engine": "snowpipe", "definition": text, "params": {}, "outputs": outputs, **kw}


def _out(name, table):
    return {"dataset_id": f"snowflake:dataset:acct.{name}", "name": name, "table": table}


def test_pipe_target_is_its_copy_into_table_not_the_first_output():
    outs = [_out("SALES_DB.CORE.ORDERS", "main.c.orders"), _out("SALES_DB.RAW.ORDERS_RAW", "main.r.orders_raw")]
    row = {"etl_id": "p1", "url": "s3://b/orders/", "auto_ingest": True,
           "file_format": {"name": "SALES_DB.RAW.CSV_ORDERS_FMT", "options": {"TYPE": "CSV", "DATE_FORMAT": "AUTO",
                                                                             "TIMESTAMP_FORMAT": "AUTO",
                                                                             "SKIP_HEADER": "1"}}}
    [art] = units.build_file_load(row, _pipe_doc(PIPE_ORDERS, outs), HandlerContext())
    assert art.text.startswith("CREATE OR REFRESH STREAMING TABLE main.r.orders_raw AS")
    assert "AUTO" not in art.text and "pathGlobFilter => '*orders_*.csv'" in art.text
    assert "mode => 'PERMISSIVE'" in art.text and any("ON_ERROR" in r for r in art.review_reasons)


def test_inline_format_is_read_from_the_copy_text():
    outs = [_out("SALES_DB.RAW.EVENTS", "main.r.events")]
    [art] = units.build_file_load({"etl_id": "p2"}, _pipe_doc(PIPE_EVENTS, outs, engine="copy_into"), HandlerContext())
    assert "FILEFORMAT = JSON" in art.text and art.text.startswith("COPY INTO main.r.events")
    assert "SNW-FILE-FORMAT" not in art.caveats


def test_unresolved_named_format_is_visibly_incomplete():
    text = "COPY INTO SALES_DB.RAW.EVENTS FROM 's3://b/e/' FILE_FORMAT = (FORMAT_NAME = 'SALES_DB.RAW.GHOST_FMT')"
    [art] = units.build_file_load({"etl_id": "p3"}, _pipe_doc(text, [_out("SALES_DB.RAW.EVENTS", "main.r.events")]),
                                  HandlerContext())
    assert "SNW-FILE-FORMAT" in art.caveats and any(r.startswith("file format not resolved") for r in art.review_reasons)


def test_copy_target_without_a_hand_off_table_is_a_reason():
    text = "COPY INTO SALES_DB.RAW.NOWHERE FROM 's3://b/e/' FILE_FORMAT = (TYPE = CSV)"
    [art] = units.build_file_load({"etl_id": "p4"}, _pipe_doc(text, [_out("SALES_DB.RAW.OTHER", "main.r.other")]),
                                  HandlerContext())
    assert any("NOWHERE" in r and "no target table" in r for r in art.review_reasons)
