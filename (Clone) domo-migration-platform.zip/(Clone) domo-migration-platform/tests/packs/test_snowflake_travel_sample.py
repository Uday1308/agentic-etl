"""L6 (ADR 037, catalogue 2.19 SAMPLE, 2.20 time travel, 2.21 CHANGES) and L5 (the batch ConversionContext reaches the
pack's expression / registry entry points).

The three clauses used to be dropped SILENTLY: the post-pass rebuilt every mapped table reference from its name and
alias only, so ``t SAMPLE (10)`` / ``t AT(OFFSET => -3600)`` / ``t CHANGES(...)`` became a plain ``t``. Each now converts
by rule and is flagged, or is escalated with a reason; none is dropped."""
from __future__ import annotations

import asyncio

import pytest

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import translate as tr
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.pack import PACK, SnowflakeExpressions
from packs.snowflake.postpass import Postpass, PostpassContext, transpile

TABLES = {("DEMO", "CORE", "T"): "main.core.t", ("DEMO", "CORE", "U"): "main.core.u"}


def run(select: str, **conv):
    doc = {"etl_id": "e1", "asset_id": "a:view:acme.DEMO.CORE.V", "engine": "sql_view", "name": "V",
           "definition": f"CREATE VIEW DEMO.CORE.V AS\n{select}", "params": {}}
    ctx = tr.make_context(etl_key="e1", engine="sql_view", table_map=dict(TABLES), default_db="DEMO",
                          default_schema="CORE", settings=TranslationSettings(tiers=("human",)),
                          conversion=ConversionContext.build(**conv))
    unit = asyncio.run(tr.translate_etl(doc, ctx))[0]
    return unit


def flags_of(unit) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in unit.evidence.get("rule_flags", []):
        out.setdefault(f["id"], []).append(f["reason"])
    return out


# ------------------------------------------------------------------------------------------------ the silent drop
def test_the_post_pass_keeps_every_clause_of_a_mapped_table_reference():
    pp = Postpass(PostpassContext(table_map=dict(TABLES), default_db="DEMO", default_schema="CORE"))
    for text in ("SELECT * FROM t TABLESAMPLE (10 PERCENT)",
                 "SELECT * FROM t AS a TABLESAMPLE (10 PERCENT) REPEATABLE (3)",
                 "SELECT * FROM t TIMESTAMP AS OF '2024-01-01'",
                 "SELECT * FROM t VERSION AS OF 3 AS a"):
        out = pp.apply(text).sql
        assert "main.core.t" in out
        assert ("TABLESAMPLE" in out) == ("TABLESAMPLE" in text) and ("AS OF" in out) == ("AS OF" in text), (text, out)
        assert (" AS a" in out) == (" AS a" in text), (text, out)


# ------------------------------------------------------------------------------------------------ 2.19 SAMPLE
def test_sample_becomes_tablesample_and_is_always_flagged():
    u = run("SELECT id FROM t SAMPLE (10)")
    assert u.status == "resolved" and u.sql == "SELECT id FROM main.core.t TABLESAMPLE (10 PERCENT)"
    assert "SNW-SAMPLE" in u.caveats and "SNW-SAMPLE" in u.review_caveats
    assert "differ on every engine" in flags_of(u)["SNW-SAMPLE"][0]


def test_sample_rows_seed_and_system_are_named_in_the_flag():
    u = run("SELECT id FROM t AS x SAMPLE SYSTEM (5) REPEATABLE (7)")
    assert u.sql == "SELECT id FROM main.core.t TABLESAMPLE (5 PERCENT) REPEATABLE (7) AS x"
    reason = flags_of(u)["SNW-SAMPLE"][0]
    assert "REPEATABLE(seed) repeats within Databricks only" in reason and "SYSTEM (block) sampling became row-level" in reason
    rows = run("SELECT id FROM t SAMPLE (100 ROWS)")
    assert rows.sql == "SELECT id FROM main.core.t TABLESAMPLE (100 ROWS)"
    assert "leading-rows limit" in flags_of(rows)["SNW-SAMPLE"][0]


# ------------------------------------------------------------------------------------------------ 2.20 time travel
def test_at_offset_becomes_timestamp_as_of_current_timestamp_minus_interval():
    u = run("SELECT * FROM t AT(OFFSET => -3600) AS a")
    assert u.status == "resolved"
    assert u.sql == "SELECT * FROM main.core.t TIMESTAMP AS OF (CURRENT_TIMESTAMP() - INTERVAL '3600' SECOND) AS a"
    assert "SNW-TIME-TRAVEL" in u.review_caveats
    assert "delta.logRetentionDuration" in flags_of(u)["SNW-TIME-TRAVEL"][0]


def test_at_timestamp_keeps_the_point_in_time_and_assumed_parameters_are_flagged():
    u = run("SELECT * FROM t AT(TIMESTAMP => '2024-01-01 00:00:00'::timestamp)")
    assert u.sql == "SELECT * FROM main.core.t TIMESTAMP AS OF CAST('2024-01-01 00:00:00' AS TIMESTAMP_NTZ)"
    assert "SNW-PARAM-ASSUMED" in u.caveats                      # TIMESTAMP_TYPE_MAPPING was not extracted
    pinned = run("SELECT * FROM t AT(TIMESTAMP => '2024-01-01 00:00:00'::timestamp)",
                 source_parameters={"TIMESTAMP_TYPE_MAPPING": {"state": "provided", "value": "TIMESTAMP_NTZ"}})
    assert "SNW-PARAM-ASSUMED" not in pinned.caveats


def test_before_reads_one_millisecond_earlier_and_says_so():
    u = run("SELECT * FROM t BEFORE(OFFSET => -60)")
    assert "TIMESTAMP AS OF (CURRENT_TIMESTAMP() - INTERVAL '60' SECOND - INTERVAL '1' MILLISECOND)" in u.sql
    assert any("BEFORE excludes the point itself" in r for r in flags_of(u)["SNW-TIME-TRAVEL"])


def test_a_computed_offset_uses_timestampadd():
    u = run("SELECT * FROM t AT(OFFSET => -n_secs)")
    assert u.status == "resolved" and "TIMESTAMP AS OF (DATE_ADD(SECOND, -n_secs, CURRENT_TIMESTAMP()))" in u.sql


@pytest.mark.parametrize("clause", ["AT(STATEMENT => '01a2b3c4-0000-1111-2222-333344445555')",
                                    "BEFORE(STATEMENT => '01a2b3c4-0000-1111-2222-333344445555')"])
def test_statement_time_travel_is_escalated_with_the_reason_and_the_clause_stays_in_the_draft(clause):
    u = run(f"SELECT * FROM t {clause}")
    assert u.status == "awaiting_review" and u.origin == "unresolved"
    assert "SNW-TIME-TRAVEL-STATEMENT" in u.caveats
    assert any(r.startswith("SNW-TIME-TRAVEL-STATEMENT:") and "DESCRIBE HISTORY" in r for r in u.reasons), u.reasons
    assert "STATEMENT =>" in u.suggested_code               # nothing was dropped: the reviewer sees what is left


# ------------------------------------------------------------------------------------------------ 2.21 CHANGES
def test_changes_becomes_table_changes_with_the_change_data_feed_flag():
    u = run("SELECT * FROM t CHANGES(INFORMATION => DEFAULT) AT(OFFSET => -60) c")
    assert u.status == "resolved"
    assert u.sql == "SELECT * FROM TABLE_CHANGES('main.core.t', CURRENT_TIMESTAMP() - INTERVAL '60' SECOND) AS c"
    why = flags_of(u)["SNW-CHANGES"][0]
    assert "delta.enableChangeDataFeed on main.core.t" in why and "net change" in why
    assert "SNW-CHANGES" in u.review_caveats


def test_changes_append_only_filters_inserts_and_keeps_the_end_point():
    u = run("SELECT * FROM t CHANGES(INFORMATION => APPEND_ONLY) AT(TIMESTAMP => '2024-01-01'::timestamp) "
            "END(TIMESTAMP => '2024-01-02'::timestamp) c")
    assert u.status == "resolved"
    assert ("TABLE_CHANGES('main.core.t', CAST('2024-01-01' AS TIMESTAMP_NTZ), CAST('2024-01-02' AS TIMESTAMP_NTZ)) "
            "WHERE _change_type = 'insert') AS c") in u.sql
    assert "APPEND_ONLY became _change_type = 'insert'" in flags_of(u)["SNW-CHANGES"][0]


def test_changes_from_a_statement_is_escalated():
    u = run("SELECT * FROM t CHANGES(INFORMATION => DEFAULT) AT(STATEMENT => 'q1')")
    assert u.status == "awaiting_review"
    assert any("SNW-TIME-TRAVEL-STATEMENT" in r for r in u.reasons)


def test_a_join_of_a_sampled_and_a_travelled_table_converts_both_clauses():
    u = run("SELECT t.id FROM t SAMPLE (5) JOIN u AT(OFFSET => -10) ON t.id = u.id")
    assert "TABLESAMPLE (5 PERCENT)" in u.sql and "TIMESTAMP AS OF" in u.sql and set(flags_of(u)) >= {"SNW-SAMPLE", "SNW-TIME-TRAVEL"}


# ------------------------------------------------------------------------------------------------ L5
def test_the_pack_entry_points_apply_the_rules_with_the_given_conversion_context():
    # DIV0 is a rule (sqlglot's own mapping loses the zero branch's type); without the context the rules do not run
    legacy = transpile("SELECT DIV0(a, b)").sql
    with_rules = SnowflakeExpressions.translate("DIV0(a, b)")
    assert with_rules is not None and "CASE WHEN" in with_rules.upper() and with_rules != legacy
    reg = PACK.registry("sql")
    rendered = reg.render({"type": "sql", "properties": {"sql": "SELECT id FROM t SAMPLE (10)"}}, [], "df")
    assert "TABLESAMPLE (10 PERCENT)" in rendered.code and rendered.confidence == "MEDIUM"      # the SNW-SAMPLE flag
    assert "SNW-SAMPLE" in rendered.notes
    pinned = ConversionContext.build(source_parameters={"WEEK_START": {"state": "provided", "value": "1"}})
    assert PACK.registry("sql", conversion=pinned).conversion is pinned
    assert SnowflakeExpressions.translate("DATE_TRUNC('week', d)", conversion=pinned) is not None
    esc = reg.render({"type": "sql", "properties": {"sql": "SELECT * FROM t AT(STATEMENT => 'q1')"}}, [], "df")
    assert esc.unresolved and any("SNW-TIME-TRAVEL-STATEMENT" in u for u in esc.unresolved)
