"""P3-09 / P3-10 / P3-12 (ADR 032 sections 3, 5, 6): a Snowflake batch from the synthetic bundle through the promoted
runner: views, a dynamic table (pipeline), a 4-deep task graph with a finalizer (ONE job), a Scripting procedure, a
UDF and its caller, a hidden view, routed pipes and query writers; the review rule (AI or transpiled output is never
auto-approved); the two-phase batch (one Transpiler call, a fingerprint cache, tier 1 ``unavailable`` without
Lakebridge); the Lakebridge boundary. Offline: FakeTranspiler and a scripted LLM only (hard rule 10)."""
from __future__ import annotations

import ast
import asyncio
import json
import pathlib

import pytest
from snowflake_bundle import make_bundle

from agents.cd_codegen.translate.artifacts import read_artifact
from agents.cd_codegen.translate.chain import TranslationConfigError, TranslationSettings
from agents.cd_codegen.translate.ports import FakeTranspiler, SqlUnit, assert_allowed
from agents.cd_codegen.translate.twophase import cache_dir, run_phase_a
from core.lakebridge import LakebridgeCliTranspiler, clean_env
from core.packs import Collaborators, get_pack
from core.review import may_auto_approve
from core.runner import HarnessGates, run_pipeline
from packs.snowflake.fakes import ScriptedTranslator
from packs.snowflake.handlers import BUILDERS, route_of
from packs.snowflake.run import BatchContext
from scripts.run_batch import run_batch

APP = pathlib.Path(__file__).resolve().parents[2]
PACK = get_pack("snowflake")


def batch(tmp_path, **kw):
    b = make_bundle(tmp_path)
    return b, asyncio.run(run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work", **kw))


def rows(report):
    return {r["name"]: r for r in report["etls"]}


# ------------------------------------------------------------------------------------------------- the batch
def test_batch_statuses_and_the_review_rule(tmp_path):
    _, rep = batch(tmp_path)
    r = rows(rep)
    # all-mapped views and the UDF migrate; everything past tier 0 or with a review caveat waits for a human
    assert r["UDF_NET_AMOUNT"]["status"] == "migrated" and r["V_ORDER_NET"]["status"] == "migrated"
    assert r["DT_ORDER_DAILY"]["status"] == "awaiting_review"                    # SNW-DT-LAG is a review caveat
    assert r["V_SECURE_MARGIN"]["status"] == "awaiting_review"                    # hidden body: a manual item
    assert r["SCRIPT_REFRESH"]["status"] == "awaiting_review"                     # the IF body converts (S1), SNW-SCRIPTING review
    assert r["ROOT_DAILY"]["status"] == "awaiting_review"                         # SNW-NAME-RESOLUTION on a task
    assert rep["counts"]["failed"] == 0 and rep["source_platform"] == "snowflake"
    # the scripting procedure is ONE unit now (the whole body converts, S1), not one per node
    assert rep["coverage"]["total"] >= 10 and rep["coverage"]["mapped"] >= 2


def test_hidden_view_is_never_translated_and_counts_as_unresolved(tmp_path):
    _, rep = batch(tmp_path)
    row = rows(rep)["V_SECURE_MARGIN"]
    assert row["coverage"]["unresolved"] == 1 and row["coverage"]["mapped"] == 0
    run_dir = pathlib.Path(row["run_dir"])
    unit = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))["units"][0]
    assert unit["status"] == "manual" and "unavailable" in unit["reasons"][0]


def test_pipe_and_query_writer_are_routed_not_unsupported(tmp_path):
    _, rep = batch(tmp_path)
    r = rows(rep)
    assert r["LEGACY_EVENTS_PIPE"]["status"] == "awaiting_review"       # file_load stub (P3-18 builds it)
    assert r["QW_dbt_orders"]["status"] == "awaiting_review"            # statement stub (P3-19 builds it)
    assert route_of({"engine": "snowpipe"})[0] == "file_load"
    assert route_of({"engine": "query", "unit_kind": "statement"})[0] == "statement"
    assert route_of({"engine": "sql_view"})[0] == "translate"


def test_unknown_engine_and_dbt_writer_are_unsupported_with_the_reason(tmp_path):
    assert route_of({"engine": "streamlit"})[0] == "unsupported" and "streamlit" in route_of({"engine": "streamlit"})[1]
    route, why = route_of({"engine": "query", "tool_key": "dbt-prod"})
    assert route == "unsupported" and "Phase 4" in why


def test_one_job_per_root_task_graph_with_finalizer_and_schedule(tmp_path):
    _, rep = batch(tmp_path)
    asm = rep["assembly"]
    assert asm["jobs"] == ["ROOT_DAILY"] and asm["status"] == "open" and not asm["auto_approvable"]
    job = json.loads(next(pathlib.Path(asm["path"]).glob("jobs/*.json")).read_text(encoding="utf-8"))
    tasks = {t["task_key"]: t for t in job["tasks"]}
    assert set(tasks) == {"root_daily", "merge_orders", "build_order_facts", "refresh_fin_summary", "notify_finalizer"}
    assert tasks["merge_orders"]["depends_on"] == [{"task_key": "root_daily"}]
    assert tasks["refresh_fin_summary"]["depends_on"] == [{"task_key": "build_order_facts"}]
    fin = tasks["notify_finalizer"]
    assert fin["run_if"] == "ALL_DONE" and {d["task_key"] for d in fin["depends_on"]} == set(tasks) - {"notify_finalizer"}
    assert job["schedule"]["quartz_cron_expression"] == "0 0 6 * * ?" or job["schedule"]["quartz_cron_expression"].startswith("0 0 6")


def test_udf_is_registered_before_its_caller(tmp_path):
    _, rep = batch(tmp_path)
    order = json.loads((pathlib.Path(rep["assembly"]["path"]) / "udf_order.json").read_text(encoding="utf-8"))
    assert order.index("acme-prod.SALES_DB.CORE.UDF_NET_AMOUNT") < len(order)
    assert order[0].endswith("UDF_NET_AMOUNT")


def test_generated_artifacts_are_stored_by_hash_and_records_hold_no_sql(tmp_path):
    _, rep = batch(tmp_path)
    row = rows(rep)["V_ORDER_NET"]
    gate = json.loads(next((pathlib.Path(row["run_dir"]) / "gates").glob("gate-cd_codegen-*.json")).read_text("utf-8"))
    art = gate["artifact"]["artifacts"][0]
    assert art["sha256"] and art["artifact_ref"].endswith(art["sha256"]) and "preview" in art
    text = read_artifact(tmp_path / "vol", art["artifact_ref"])
    assert text.startswith("CREATE OR REPLACE VIEW main.sfdemo_sales_db_analytics.v_order_net AS")
    assert "if(o.amount > 100" in text.lower() or "if(o.amount>100" in text.lower().replace(" ", "")
    assert "SELECT" not in json.dumps(json.loads((pathlib.Path(row["run_dir"]) / "run.json").read_text("utf-8")))


# ------------------------------------------------------------------------------------------------- review rule
def one_etl(sql: str, engine: str = "sql_view", name: str = "V_X") -> dict:
    return {"etl_id": f"e-{name}", "asset_id": f"acme-prod.SALES_DB.CORE.{name}", "engine": engine, "name": name,
            "etl_key": f"sfdemo__{name}", "inputs": [], "outputs": [{"dataset_id": "o", "name": name,
                                                                     "table": f"main.s.{name.lower()}"}],
            "payload": {"definition": sql}}


def run_one(tmp_path, etl, *, llm=None, settings=None, tier1=None):
    from packs.snowflake.postpass import table_key  # noqa: F401

    b = BatchContext(table_map={("SALES_DB", "CORE", "ORDERS"): "main.s.orders"},
                     settings=settings or TranslationSettings())
    if tier1 is not None:
        b.tier1 = tier1
    collab = Collaborators(extra={"llm_translator": llm})
    return asyncio.run(run_pipeline(etl, pack=PACK, collaborators=collab, gates=HarnessGates(), work=tmp_path,
                                    volume=tmp_path / "vol", source_id="sfdemo", batch=b))


FLATTEN = "SELECT f.value FROM CORE.ORDERS o, LATERAL FLATTEN(input => o.arr, recursive => true) f"


def test_ai_output_is_inferred_and_never_auto_approved(tmp_path):
    llm = ScriptedTranslator({"flatten": "SELECT explode(o.arr) AS value FROM main.s.orders o"})
    rec = run_one(tmp_path, one_etl(FLATTEN), llm=llm)
    assert rec.status == "awaiting_review" and {h["agent"] for h in rec.held} == {"translation", "cd_codegen"}
    unit = rec.units[0]
    assert unit["origin"] == "ai" and unit["state"] == "inferred" and unit["confidence"] is not None
    assert "input =>" not in json.dumps(unit["evidence"])                       # evidence: reasons, never source text
    assert rec.coverage["ai"] == 1 and rec.tiers["tier1"]["state"] == "unavailable"
    assert may_auto_approve("sql", ["ai"])[0] is False


def test_transpiled_output_is_never_auto_approved_and_names_an_allowed_tool(tmp_path):
    from agents.cd_codegen.translate.twophase import TierOneReport

    fake = FakeTranspiler({"flatten": "SELECT explode(o.arr) AS value FROM main.s.orders o"})
    sql = FLATTEN
    from agents.cd_codegen.translate.attempt import unit_fingerprint

    fp = unit_fingerprint(sql, source_dialect="snowflake", engine="sql_view", pack_version="1")
    cache = {fp: {"sql": "SELECT explode(o.arr) AS value FROM main.s.orders o", "tool": fake.name,
                  "tool_version": "fake-1", "warnings": [], "error": ""}}
    t1 = TierOneReport("ok", cache=cache, tool=fake.name)
    s = TranslationSettings(lakebridge_enabled=True)
    rec = run_one(tmp_path, one_etl(sql), settings=s, tier1=t1)
    unit = rec.units[0]
    assert unit["origin"] == "transpiled" and unit["state"] == "derived" and rec.status == "awaiting_review"
    tier1 = next(a for a in unit["attempts"] if a["tier"] == 1)
    assert tier1["tool"] in ("bladebridge", "morpheus") and tier1["tool_version"] == "fake-1"


def test_no_answer_from_any_tier_ends_awaiting_review_with_a_human_item(tmp_path):
    rec = run_one(tmp_path, one_etl(FLATTEN), llm=ScriptedTranslator({}))
    unit = rec.units[0]
    assert unit["status"] == "awaiting_review" and unit["origin"] == "unresolved"
    assert [a["tier"] for a in unit["attempts"]] == [0, 1, 2, 3]
    assert rec.status == "awaiting_review" and rec.coverage["unresolved"] == 1


def test_a_block_caveat_skips_tiers_one_and_two(tmp_path):
    llm = ScriptedTranslator({"stage": "SELECT 1"})
    rec = run_one(tmp_path, one_etl("SELECT $1 AS c FROM @CORE.STG"), llm=llm)
    unit = rec.units[0]
    assert unit["status"] == "awaiting_review" and not llm.calls
    assert [a["status"] for a in unit["attempts"] if a["tier"] in (1, 2)] == ["skipped", "skipped"]


def test_mapped_unit_with_only_info_caveats_is_auto_approved(tmp_path):
    rec = run_one(tmp_path, one_etl("SELECT IFF(AMOUNT > 1, 1, 0) AS b FROM SALES_DB.CORE.ORDERS"))
    assert rec.status == "migrated" and rec.held == [] and rec.coverage["mapped"] == 1


def test_run_batch_status_matches_runner_for_a_domo_free_install():
    assert "snowflake" in __import__("core.packs", fromlist=["known_platforms"]).known_platforms()


# ------------------------------------------------------------------------------------------------- two-phase + Lakebridge
def units(n=3):
    return [SqlUnit("etlk", f"u{i}", f"select {i}", f"fp{i}") for i in range(n)]


def test_phase_a_makes_one_transpiler_call_and_a_resume_hits_the_cache(tmp_path):
    fake = FakeTranspiler({f"fp{i}": f"SELECT {i}" for i in range(3)})
    rep = run_phase_a(fake, units(), source_dialect="snowflake", work=tmp_path)
    assert rep.status == "ok" and len(fake.calls) == 1 and len(fake.calls[0]) == 3 and rep.submitted == 3
    assert len(list(cache_dir(tmp_path).glob("*.json"))) == 3 and rep.cache["fp1"]["sql"] == "SELECT 1"
    again = run_phase_a(fake, units(), source_dialect="snowflake", work=tmp_path)      # --resume repeats phase A
    assert len(fake.calls) == 1 and again.cached == 3 and again.submitted == 0


def test_lakebridge_absent_reports_tier_one_unavailable_not_failed(tmp_path):
    off = FakeTranspiler(unavailable_reason="Lakebridge CLI not found")
    rep = run_phase_a(off, units(), source_dialect="snowflake", work=tmp_path)
    assert rep.status == "unavailable" and "not found" in rep.reason and rep.cache is None and not off.calls
    assert run_phase_a(None, units(), source_dialect="snowflake", work=tmp_path).status == "unavailable"
    assert run_phase_a(FakeTranspiler(), units(), source_dialect="snowflake", work=tmp_path,
                       enabled=False).status == "unavailable"


def test_a_crashing_transpiler_gives_every_unit_the_reason(tmp_path):
    class Boom(FakeTranspiler):
        def transpile(self, units, source_dialect):
            raise TimeoutError("lakebridge.timeout_s")

    rep = run_phase_a(Boom(), units(2), source_dialect="snowflake", work=tmp_path)
    assert rep.status == "ok" and all("TimeoutError" in e["error"] for e in rep.cache.values())


def test_only_rule_based_transpilers_are_allowed():
    assert_allowed("bladebridge") and assert_allowed("Morpheus")
    with pytest.raises(TranslationConfigError):
        assert_allowed("switch")                                   # LLM-backed: would be tier 2, origin=ai
    with pytest.raises(TranslationConfigError):
        LakebridgeCliTranspiler(transpiler="switch")


def test_cli_transpiler_uses_an_explicit_env_no_shell_and_cleans_its_folders(tmp_path, monkeypatch):
    monkeypatch.setenv("SRCINTEL_SECRET", "x")
    monkeypatch.setenv("DATABRICKS_HOST", "https://example.invalid")
    seen = {}

    def fake_run(cmd, **kw):
        seen.update(cmd=cmd, kw=kw)
        out = pathlib.Path(cmd[cmd.index("--output-folder") + 1])
        src = pathlib.Path(cmd[cmd.index("--input-source") + 1])
        seen["src"], seen["out"] = src, out
        (out / "etlk").mkdir(parents=True)
        (out / "etlk" / "u0.sql").write_text("SELECT 0", encoding="utf-8")

        class P:
            returncode, stdout, stderr = 0, "", ""
        return P()

    t = LakebridgeCliTranspiler(runner=fake_run, version="x")
    res = t.transpile([SqlUnit("etlk", "u0", "select 0", "fp0")], "snowflake")
    assert res[0].sql == "SELECT 0" and res[0].tool == "bladebridge"
    assert seen["kw"]["shell"] is False and "SRCINTEL_SECRET" not in seen["kw"]["env"]
    assert seen["kw"]["env"].get("DATABRICKS_HOST") and not seen["src"].exists() and not seen["out"].exists()
    assert "SRCINTEL_SECRET" not in clean_env({"SRCINTEL_SECRET": "x", "PATH": "p"})


def test_only_core_lakebridge_imports_databricks_among_the_new_code():
    roots = [APP / "packs" / "snowflake", APP / "agents" / "cd_codegen" / "translate"]
    files = [f for r in roots for f in r.rglob("*.py")] + [APP / "core" / n for n in ("runner.py", "packs.py", "review.py")]
    offenders = []
    for f in files:
        for node in ast.walk(ast.parse(f.read_text(encoding="utf-8"))):
            mods = [a.name for a in node.names] if isinstance(node, ast.Import) else \
                [node.module or ""] if isinstance(node, ast.ImportFrom) else []
            offenders += [f"{f.name}: {m}" for m in mods if m.split(".")[0] in ("databricks", "pyspark")]
    assert offenders == []
    assert "databricks.sdk" in (APP / "core" / "lakebridge.py").read_text(encoding="utf-8")


def test_stub_builders_can_be_installed_by_later_tracks():
    assert set(BUILDERS) == {"file_load", "statement"}      # installed by packs.snowflake.units (P3-18 / P3-19)


def _approve_gate(work, gate):
    (work / "feedback").mkdir(parents=True, exist_ok=True)
    (work / "feedback" / f"{gate['gate_id']}.approval.json").write_text(json.dumps({
        "gate_id": gate["gate_id"], "approve": True, "reviewer": "lead@example.invalid",
        "payload_hash": gate["payload_hash"], "decision_id": f"{gate['gate_id']}@t1"}), encoding="utf-8")


def test_resume_reuses_snowflake_approvals_and_the_unit_moves_on(tmp_path):
    """Approving every held gate of a Snowflake unit and resuming must change that unit's status (no silent re-hold)."""
    b, first = batch(tmp_path)
    work = tmp_path / "work"
    held = [r for r in first["etls"] if r["status"] == "awaiting_review"]
    assert held
    for r in held:
        for g in r["review_gates"]:
            _approve_gate(work, g)
    again = asyncio.run(run_batch(b, volume=tmp_path / "vol", work=work, resume=first["batch_run_id"], keep_going=True))
    by_name = rows(again)
    for r in held:
        new = by_name[r["name"]]
        assert new.get("reused_approvals"), (r["name"], new["status"], new.get("review_gates"))
        # a gate that reappears is a different gate (a later stage), never the one already approved
        assert not ({g["gate_id"] for g in new["review_gates"]} & {g["gate_id"] for g in r["review_gates"]}), r["name"]


def test_gate_ids_are_unique_per_run_and_a_second_run_never_inherits_the_first_approval(tmp_path):
    """Two batches of the same object must not share a gate id (one feedback file): approving run 2 leaves run 1."""
    b, first = batch(tmp_path)
    work = tmp_path / "work"
    second = asyncio.run(run_batch(b, volume=tmp_path / "vol", work=work))
    g1 = {g["gate_id"] for r in first["etls"] for g in r.get("review_gates") or []}
    g2 = {g["gate_id"] for r in second["etls"] for g in r.get("review_gates") or []}
    assert g1 and g2 and not (g1 & g2)
    assert all(len(str(work / "feedback" / f"{g}.approval.json")) < 240 for g in g1 | g2)
    row2 = next(r for r in second["etls"] if r.get("review_gates"))
    for g in row2["review_gates"]:
        _approve_gate(work, g)
    row1 = next(r for r in first["etls"] if r["name"] == row2["name"])
    assert not any((work / "feedback" / f"{g['gate_id']}.approval.json").exists() for g in row1["review_gates"])


def test_administration_only_procedure_is_unsupported_with_the_reason():
    from packs.snowflake.handlers import ADMIN_REASON, admin_only_body

    body = ("BEGIN\n  ALTER USER IDENTIFIER(:P_USER) SET PASSWORD = 'x;y';\n"
            "  CREATE OR REPLACE STAGE G.S URL = 's3://b/' CREDENTIALS = (AWS_KEY_ID = 'k' AWS_SECRET_KEY = 's')\n"
            "    ENCRYPTION = (TYPE = 'AWS_CSE');\n  GRANT USAGE ON STAGE G.S TO ROLE R;\n  RETURN 'rotated';\nEND;")
    row = {"engine": "sql_procedure", "etl_id": "p1", "name": "ROTATE", "payload": body}
    assert route_of(row) == ("unsupported", ADMIN_REASON)
    assert "not migrated as logic" in ADMIN_REASON
    assert admin_only_body("BEGIN\n  CREATE STORAGE INTEGRATION s TYPE = EXTERNAL_STAGE;\n  CREATE ROLE r;\nEND;")
    # data logic, or a stage without credentials, stays a rebuild
    assert route_of({**row, "payload": "BEGIN\n  INSERT INTO T SELECT 1;\n  GRANT SELECT ON T TO ROLE R;\nEND;"})[0] == "translate"
    assert not admin_only_body("BEGIN\n  CREATE STAGE G.S URL = 's3://b/';\nEND;")
    assert route_of({"engine": "sql_procedure"})[0] == "translate"            # no body known: the old behaviour
