"""S3 / S4 / S10 (ADR 037): post-conversion validation, data parity and type repair. Offline: ``FakeWarehouse`` only
(rules 4/5/10); the ``@pytest.mark.databricks`` live variants are in tests/integration (not run here)."""
from __future__ import annotations

import asyncio
from decimal import Decimal

import pytest
from snowflake_bundle import make_bundle

from packs.snowflake import parity as pr
from packs.snowflake import type_repair as tr
from packs.snowflake import verify as vf
from packs.snowflake.caveats import load_catalogue
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.translate import UnitResult
from packs.snowflake.warehouse import FakeWarehouse, WarehouseError, error_class_of, from_env
from scripts.run_batch import run_batch


def unit(sql, kind="cte_chain", uid="u1"):
    return UnitResult(uid, "query", sql=sql, kind=kind, origin="mapped", state="provided", status="resolved")


def describe(*cols):
    return [{"col_name": n, "data_type": t, "comment": ""} for n, t in cols]


# ------------------------------------------------------------------------------------------------ the port
def test_error_class_parsing():
    assert error_class_of("[TABLE_OR_VIEW_NOT_FOUND] The table or view `a` cannot be found") == "TABLE_OR_VIEW_NOT_FOUND"
    assert error_class_of("[INCOMPATIBLE_COLUMN_TYPE.X] boom") == "INCOMPATIBLE_COLUMN_TYPE.X"
    assert error_class_of("ParseException near foo") == "PARSE_SYNTAX_ERROR"
    assert error_class_of("???") == "UNKNOWN"


def test_no_warehouse_in_env_is_none_with_a_reason(monkeypatch):
    for k in ("DATABRICKS_WAREHOUSE_ID", "DATABRICKS_HTTP_PATH"):
        monkeypatch.delenv(k, raising=False)
    wh, why = from_env()
    assert wh is None and "no SQL warehouse" in why


def test_the_new_modules_import_no_databricks():
    import pathlib
    root = pathlib.Path(vf.__file__).parent
    for name in ("warehouse", "verify", "parity", "type_repair"):
        text = (root / f"{name}.py").read_text(encoding="utf-8")
        assert "import databricks" not in text and "from databricks" not in text.replace("from databricks.", "X.") or \
            "api.store_delta" in text


# ------------------------------------------------------------------------------------------------ S3 explain
def test_off_by_default_records_nothing():
    r = unit("SELECT 1")
    assert "verify" not in r.evidence


def test_no_warehouse_is_unverifiable_never_passed():
    cfg = vf.VerifyConfig(warehouse=None, reason="no SQL warehouse configured")
    r = unit("SELECT a FROM t")
    out = vf.verify_results([r], cfg)
    assert r.evidence["verify"]["status"] == "unverifiable" and "no SQL warehouse" in r.evidence["verify"]["reason"]
    assert out == {"unverifiable": 1} and not r.review_caveats
    assert cfg.summary()["warehouse"] is False


def test_explain_passes_and_is_recorded():
    wh = FakeWarehouse()
    cfg = vf.VerifyConfig(wh)
    r = unit("SELECT a FROM main.s.t")
    vf.verify_results([r], cfg)
    assert r.evidence["verify"]["status"] == "passed" and r.evidence["verify"]["explain"]["statements"] == 1
    assert wh.calls[0].startswith("EXPLAIN SELECT")


def test_explain_failure_needs_review_with_the_error_class_and_no_source_text():
    wh = FakeWarehouse().on("explain", error=WarehouseError("UNRESOLVED_ROUTINE", "[UNRESOLVED_ROUTINE] secret_fn(x)"))
    r = unit("SELECT secret_fn(a) FROM main.s.t")
    vf.verify_results([r], vf.VerifyConfig(wh))
    ev = r.evidence["verify"]
    assert ev["status"] == "failed" and ev["explain"]["error_class"] == "UNRESOLVED_ROUTINE"
    assert "secret_fn" not in repr(r.evidence)
    assert "SNW-VERIFY-EXPLAIN" in r.review_caveats and r.needs_review
    assert "secret_fn" not in repr(r.record())


def test_missing_object_is_unverifiable_unless_strict():
    wh = FakeWarehouse().on("explain", error="TABLE_OR_VIEW_NOT_FOUND")
    r = unit("SELECT a FROM main.s.t")
    vf.verify_results([r], vf.VerifyConfig(wh))
    assert r.evidence["verify"]["status"] == "unverifiable" and not r.review_caveats
    r2 = unit("SELECT a FROM main.s.t")
    vf.verify_results([r2], vf.VerifyConfig(wh, missing_is_failure=True))
    assert r2.evidence["verify"]["status"] == "failed"


def test_plan_text_failure_is_detected():
    wh = FakeWarehouse().on("explain", rows=[{"plan": "Error occurred during query planning:\n[PARSE_SYNTAX_ERROR] x"}])
    r = unit("SELECT a FROM main.s.t")
    vf.verify_results([r], vf.VerifyConfig(wh))
    assert r.evidence["verify"]["explain"]["error_class"] == "PARSE_SYNTAX_ERROR"


def test_explain_targets_by_shape():
    assert vf.explain_targets("statement", "CREATE OR REPLACE VIEW main.s.v AS SELECT a FROM main.s.t") \
        == ["SELECT a FROM main.s.t"]
    assert vf.explain_targets("statement", "CREATE TABLE main.s.x AS (SELECT 1 AS a)") == ["SELECT 1 AS a"]
    assert vf.explain_targets("statement", "MERGE INTO a USING b ON a.i=b.i WHEN MATCHED THEN DELETE")[0].startswith("MERGE")
    assert vf.explain_targets("statement", "CREATE FUNCTION f() RETURNS INT RETURN 1") == []
    assert vf.explain_targets("pipeline", "CREATE OR REFRESH MATERIALIZED VIEW m AS SELECT 1") == ["SELECT 1"]
    na = vf.verify_sql(vf.VerifyConfig(FakeWarehouse()), "statement", "CREATE FUNCTION f() RETURNS INT RETURN 1")[0]
    assert na["explain"]["status"] == "not_applicable" and na["status"] == "unverifiable"


# ------------------------------------------------------------------------------------------------ S3 schema (X2)
CTX = ConversionContext.build(catalogue={"main.s.v": {"id": "NUMBER(38,0)", "name": "VARCHAR", "amt": "FLOAT",
                                                      "ts": "TIMESTAMP_NTZ(9)"}})
VIEW = "CREATE OR REPLACE VIEW main.s.v AS SELECT id, name, amt, ts FROM main.s.t"
GOOD = describe(("id", "decimal(38,0)"), ("name", "string"), ("amt", "double"), ("ts", "timestamp_ntz"))


def test_schema_matches_expected_source_types():
    wh = FakeWarehouse().on("describe query", rows=GOOD)
    r = unit(VIEW, "statement")
    vf.verify_results([r], vf.VerifyConfig(wh), CTX)
    assert r.evidence["verify"]["schema"] == {"status": "passed", "problems": [], "checked": 4, "unknown": 0}
    assert r.evidence["verify"]["status"] == "passed"


def test_schema_mismatch_is_flagged_for_review():
    bad = describe(("id", "bigint"), ("name", "string"), ("amt", "string"), ("ts", "timestamp"))
    wh = FakeWarehouse().on("describe query", rows=bad)
    r = unit(VIEW, "statement")
    vf.verify_results([r], vf.VerifyConfig(wh), CTX)
    s = r.evidence["verify"]["schema"]
    # bigint is exact scale 0 = NUMBER(38,0): fine; FLOAT -> string and NTZ -> LTZ are real differences
    assert s["status"] == "failed" and len(s["problems"]) == 2
    assert "SNW-VERIFY-SCHEMA" in r.review_caveats and r.evidence["verify"]["status"] == "failed"


def test_schema_missing_column_and_unknown_expected_types():
    out = vf.compare_schema({"a": "NUMBER(10,2)", "b": None}, [("a", "decimal(10,0)"), ("b", "string")])
    assert out["status"] == "failed" and out["problems"] == ["a: expected exact scale 2, got exact scale 0"]
    out = vf.compare_schema({"a": None}, [("a", "string")])
    assert out["status"] == "unverifiable" and out["checked"] == 0
    out = vf.compare_schema({"a": "VARCHAR", "z": "VARCHAR"}, [("a", "string")])
    assert out["status"] == "failed" and "missing columns: z" in out["problems"][0]


def test_schema_unverifiable_without_expected_types_does_not_fail_the_unit():
    wh = FakeWarehouse().on("describe query", rows=GOOD)
    r = unit("CREATE VIEW main.s.other AS SELECT 1 AS a", "statement")
    vf.verify_results([r], vf.VerifyConfig(wh), CTX)
    assert r.evidence["verify"]["schema"]["status"] == "unverifiable" and not r.review_caveats


# ------------------------------------------------------------------------------------------------ S10 type repair
UNION = "CREATE VIEW main.s.u AS SELECT id FROM main.s.a UNION ALL SELECT n FROM main.s.b"


def _union_wh(fixed=True):
    def explain_answer(stmt):
        if "cast(" in stmt.lower() and fixed:
            return []
        raise WarehouseError("CANNOT_MERGE_INCOMPATIBLE_DATA_TYPE", "[CANNOT_MERGE_INCOMPATIBLE_DATA_TYPE] x")

    wh = FakeWarehouse()
    wh.on("describe query select id from", rows=describe(("id", "bigint")))
    wh.on("describe query select n from", rows=describe(("n", "decimal(38,0)")))
    wh.on("explain", rows=explain_answer)
    return wh


def test_union_type_conflict_is_repaired_and_flagged():
    wh = _union_wh()
    r = unit(UNION, "statement")
    vf.verify_results([r], vf.VerifyConfig(wh, check_schema=False))
    assert "CAST" in r.sql.upper() and "DECIMAL(38, 0)" in r.sql.upper().replace("DECIMAL(38,0)", "DECIMAL(38, 0)")
    assert r.evidence["verify"]["repair"]["status"] == "applied"
    assert r.evidence["verify"]["repair"]["changes"] == ["id: bigint / decimal(38,0) -> DECIMAL(38,0)"]
    assert r.evidence["verify"]["status"] == "passed" and "SNW-TYPE-REPAIR" in r.review_caveats and r.needs_review


def test_repair_that_does_not_pass_explain_is_not_applied():
    wh = _union_wh(fixed=False)
    r = unit(UNION, "statement")
    original = r.sql
    vf.verify_results([r], vf.VerifyConfig(wh, check_schema=False))
    assert r.sql == original and r.evidence["verify"]["repair"]["status"] == "not_possible"
    assert r.evidence["verify"]["status"] == "failed" and "SNW-VERIFY-EXPLAIN" in r.review_caveats


def test_repair_off_and_non_type_errors_never_repair():
    r = unit(UNION, "statement")
    vf.verify_results([r], vf.VerifyConfig(_union_wh(), repair_types=False, check_schema=False))
    assert "repair" not in r.evidence["verify"]


def test_recursive_cte_date_anchor_keeps_date():
    wh = FakeWarehouse()
    wh.on("describe query", rows=lambda s: describe(("d", "date")) if "add" not in s.lower()
          else describe(("d", "timestamp")))
    sql = ("WITH RECURSIVE r(d) AS (SELECT CAST('2024-01-01' AS DATE) AS d UNION ALL "
           "SELECT DATE_ADD(d, 1) FROM r WHERE d < CAST('2024-01-05' AS DATE)) SELECT d FROM r")
    out = tr.repair_statement(wh, sql)
    assert out and out["changes"] == ["d: date / timestamp -> DATE"] and out["sql"].upper().startswith("WITH RECURSIVE")


def test_widen_rules():
    assert tr.widen("bigint", "decimal(38,0)") == "DECIMAL(38,0)"
    assert tr.widen("int", "bigint") == "bigint"
    assert tr.widen("decimal(10,2)", "double") == "DOUBLE"
    assert tr.widen("date", "timestamp") == "TIMESTAMP"
    assert tr.widen("string", "int") == "STRING" and tr.widen("boolean", "int") is None


# ------------------------------------------------------------------------------------------------ after deploy
def test_check_deployed():
    wh = FakeWarehouse().on("describe table `main`.`s`.`gone`", error="TABLE_OR_VIEW_NOT_FOUND")
    out = vf.check_deployed(wh, [{"name": "main.s.t", "kind": "table"}, {"name": "main.s.gone", "kind": "view"},
                                 {"name": "main.s.j", "kind": "job"}])
    st = {o["name"]: o["status"] for o in out["objects"]}
    assert st == {"main.s.t": "passed", "main.s.gone": "failed", "main.s.j": "not_applicable"} and out["status"] == "failed"
    none = vf.check_deployed(None, [{"name": "main.s.t", "kind": "table"}])
    assert none["status"] == "unverifiable" and none["objects"][0]["status"] == "unverifiable"


# ------------------------------------------------------------------------------------------------ S4 parity
COLS = [{"name": "ID", "type": "NUMBER(38,0)"}, {"name": "NAME", "type": "VARCHAR"}, {"name": "AMT", "type": "FLOAT"},
        {"name": "D", "type": "DATE"}, {"name": "TS", "type": "TIMESTAMP_TZ"}, {"name": "OK", "type": "BOOLEAN"},
        {"name": "V", "type": "VARIANT"}, {"name": "X", "type": None}]


def test_metric_selection_by_type():
    ms = pr.metrics_for(COLS)
    by = {(m.column, m.metric): m for m in ms}
    assert ("ID", "sum") in by and by[("ID", "sum")].blocking and ("ID", "min") in by
    assert by[("AMT", "sum")].blocking is False and by[("AMT", "sum")].approx
    assert ("NAME", "checksum") in by and ("NAME", "total_length") in by
    assert ("D", "max") in by and ("TS", "min") in by and ("OK", "true_count") in by
    assert [m.metric for m in ms if m.column == "V"] == ["null_count"]
    assert sorted(m.metric for m in ms if m.column == "X") == ["distinct_count", "null_count"]
    assert "CONVERT_TIMEZONE('UTC'" in by[("TS", "min")].source_expr and "to_utc_timestamp" in by[("TS", "min")].target_expr
    assert [m.metric for m in pr.metrics_for(COLS, pr.ParityConfig(text_checksums=False)) if m.column == "NAME"] \
        == ["null_count", "distinct_count"]
    assert pr.metrics_for(COLS, pr.ParityConfig(float_blocking=True))[0].blocking


def test_sql_generators_and_boundary():
    ms = pr.metrics_for(COLS[:1])
    src = pr.source_sql("DB.SC.T", ms, "2026-11-06T00:00:00Z")
    assert src.startswith("SELECT COUNT(*) AS m0") and '"DB"."SC"."T"' in src
    assert src.endswith("AT (TIMESTAMP => TO_TIMESTAMP_TZ('2026-11-06T00:00:00Z'))")
    assert "AT (" not in pr.source_sql("DB.SC.T", ms)
    assert pr.target_sql("cat.sch.t", ms).endswith("FROM `cat`.`sch`.`t`")
    with pytest.raises(ValueError):
        pr.source_sql("DB.SC.T", ms, "x'); DROP TABLE t; --")
    with pytest.raises(ValueError):
        pr.source_sql("DB.SC.T; DROP", ms)
    with pytest.raises(ValueError):
        pr.target_sql("only.two", ms)


def test_decimal_safe_compare_and_tolerance():
    assert pr.same(Decimal("12345678901234567890.123"), "12345678901234567890.123", blocking=True)
    assert not pr.same("12345678901234567890.1230001", Decimal("12345678901234567890.123"), blocking=True)
    assert pr.same(1.0, "1.0", blocking=True) and pr.same(None, None, blocking=True) and not pr.same(None, 0, blocking=True)
    assert pr.same(1000000.0, 1000000.0000001, blocking=False, approx=True, tolerance=Decimal("1e-9"))
    assert not pr.same(1.0, 1.1, blocking=False, approx=True)
    assert pr.same(True, "true", blocking=True) and pr.same("abc", "abc", blocking=True) and not pr.same("a", "b", blocking=True)


def _rows(ms, src_over=None, tgt_over=None):
    base = {m.alias: 1 for m in ms}
    return {**base, **(src_over or {})}, {**base, **(tgt_over or {})}


def test_compare_status_blocking_vs_advisory():
    cols = [{"name": "ID", "type": "NUMBER(38,0)"}, {"name": "AMT", "type": "FLOAT"}]
    ms = pr.metrics_for(cols)
    s, t = _rows(ms)
    assert pr.table_status(pr.compare(ms, s, t)) == "passed"
    s, t = _rows(ms, {"c1_sum": "100.0"}, {"c1_sum": "100.001"})                # beyond the 1e-9 relative tolerance
    assert pr.table_status(pr.compare(ms, s, t)) == "passed with advisory differences"
    s, t = _rows(ms, tgt_over={"c0_sum": 2})
    assert pr.table_status(pr.compare(ms, s, t)) == "mismatched"
    s, t = _rows(ms, {"c1_sum": "100.0"}, {"c1_sum": "100.001"})
    wide = pr.ParityConfig(column_tolerance={"amt": Decimal("1e-3")})
    assert pr.table_status(pr.compare(ms, s, t, wide)) == "passed"


class Src:
    def __init__(self, row):
        self.row, self.sql = row, []

    def query(self, sql):
        self.sql.append(sql)
        return [self.row]


def _agree(table):
    ms = pr.metrics_for(table["columns"])
    return {m.alias: 7 for m in ms}


TABLES = [{"source": "DB.SC.T1", "target": "main.sc.t1", "columns": COLS[:2]},
          {"source": "DB.SC.T2", "target": "main.sc.t2", "columns": COLS[:1]},
          {"source": "DB.SC.T3", "target": "main.sc.t3", "columns": COLS[:1]}]


def test_run_parity_report_per_table_and_batch_level(tmp_path):
    t1, t2 = _agree(TABLES[0]), _agree(TABLES[1])
    src = Src(t1)
    src.query = lambda sql, _s=src: [t1] if '"T1"' in sql else [t2] if '"T2"' in sql else (_ for _ in ()).throw(RuntimeError("boom"))
    wh = FakeWarehouse().on("`t1`", rows=[t1]).on("`t2`", rows=[{**t2, "c0_sum": 8}])
    log = []
    rep = pr.run_parity(src, wh, TABLES, {"DB.SC.T1": "2026-11-06T00:00:00Z"}, record=lambda *a: log.append(a))
    st = {t["source"]: t["status"] for t in rep["tables"]}
    assert st == {"DB.SC.T1": "passed", "DB.SC.T2": "mismatched", "DB.SC.T3": "error"} and rep["status"] == "mismatched"
    assert rep["tables"][0]["boundary"] == "2026-11-06T00:00:00Z" and rep["tables"][2]["error_class"] == "RuntimeError"
    ev = pr.evidence_by_target(rep)
    assert ev["main.sc.t2"]["mismatches"] == ["ID sum"] and ev["main.sc.t1"]["status"] == "passed"
    assert [x[1] for x in log].count("failed") == 2
    path = pr.write_report(rep, tmp_path)
    assert path.name == "parity_report.json" and path.parent.name == "parity"


def test_parity_without_a_port_is_unverifiable():
    rep = pr.run_parity(None, FakeWarehouse(), TABLES)
    assert rep["status"] == "unverifiable" and {t["status"] for t in rep["tables"]} == {"unverifiable"}


def test_parity_evidence_feeds_units_and_gates():
    rep = {"tables": [{"source": "DB.S.T", "target": "main.s.t", "status": "mismatched",
                       "metrics": [{"column": "ID", "metric": "sum", "match": False, "blocking": True}]}]}
    r = unit("SELECT 1")
    other = unit("SELECT 2", uid="u2")
    pr.attach_to_results([r, other], rep, lambda x: ["MAIN.S.T"] if x is r else [])
    assert r.evidence["parity"]["main.s.t"]["status"] == "mismatched" and "SNW-PARITY-MISMATCH" in r.review_caveats
    assert "parity" not in other.evidence


def test_tables_from_context_uses_the_catalogue_and_never_guesses():
    conv = ConversionContext.build(catalogue={"main.s.t": {"id": "NUMBER(38,0)", "x": None}})
    spec = pr.tables_from_context(conv, {("DB", "S", "T"): "main.s.t", ("DB", "S", "U"): "main.s.u"})
    assert spec == [{"source": "DB.S.T", "target": "main.s.t",
                     "columns": [{"name": "ID", "type": "NUMBER(38,0)"}, {"name": "X", "type": None}]}]


# ------------------------------------------------------------------------------------------------ catalogue + batch
def test_new_caveat_ids_are_registered_migrator_only():
    cat = load_catalogue()
    for cid, sev in (("SNW-VERIFY-EXPLAIN", "escalate"), ("SNW-VERIFY-SCHEMA", "review"), ("SNW-TYPE-REPAIR", "review"),
                     ("SNW-PARITY-MISMATCH", "escalate")):
        e = next(c for c in cat.entries if c.id == cid)
        assert e.severity == sev and e.migrator_only


def _batch(tmp_path, **kw):
    b = make_bundle(tmp_path)
    return asyncio.run(run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work", **kw))


def test_batch_without_verify_has_no_verify_section(tmp_path):
    rep = _batch(tmp_path)
    assert "verify" not in rep and "parity" not in rep


def test_batch_with_verify_and_no_warehouse_is_unverifiable(tmp_path):
    cfg = vf.VerifyConfig(warehouse=None, reason="no SQL warehouse configured")
    rep = _batch(tmp_path, verify=cfg)
    assert rep["verify"]["enabled"] and rep["verify"]["warehouse"] is False and rep["verify"]["units"] > 0
    assert set(rep["verify"]["by_status"]) == {"unverifiable"}


def test_batch_with_a_warehouse_failure_holds_the_unit_for_review(tmp_path):
    base = _batch(tmp_path / "a")
    wh = FakeWarehouse().on("explain", error="UNRESOLVED_ROUTINE")
    rep = _batch(tmp_path / "b", verify=vf.VerifyConfig(wh))
    assert rep["verify"]["failed"] and rep["verify"]["by_status"].get("failed")
    names = {r["name"]: r["status"] for r in rep["etls"]}
    was = {r["name"]: r["status"] for r in base["etls"]}
    # a unit that was migrated automatically now waits for a human
    assert any(was[n] == "migrated" and names[n] == "awaiting_review" for n in names)


def test_batch_parity_hook_writes_the_batch_report(tmp_path):
    seen = {}

    def hook(batch_ctx):
        seen["tables"] = len(batch_ctx.table_map)
        return pr.run_parity(None, None, [{"source": "DB.S.T", "target": "main.s.t", "columns": []}])

    rep = _batch(tmp_path, parity=hook)
    assert rep["parity"]["status"] == "unverifiable" and seen["tables"] > 0
    import pathlib
    assert list(pathlib.Path(rep["report_path"]).parent.glob("*/parity/parity_report.json"))
