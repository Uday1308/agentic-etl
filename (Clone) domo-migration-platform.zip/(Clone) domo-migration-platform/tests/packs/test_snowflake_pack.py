"""P3-07 / P3-08 (ADR 032 sections 2-4): the SQL node in the standardized contract, the caveat catalogue and the
generated SNW judges, tier 0 (sqlglot.transpile + rules) with the deterministic post-pass, the per-kind validators
and the column check, and the vocabulary's lineage (``unverifiable``, never passed vacuously)."""
from __future__ import annotations

import json
import pathlib

import pytest

from core.contracts.judges import Verdict
from core.contracts.standardized import to_planner_dataflow, validate_standardized
from core.packs import SourcePack, get_pack, missing_parts
from packs.snowflake import caveats as cav
from packs.snowflake import contract as ct
from packs.snowflake.columns import build_catalogue, information_schema_sql
from packs.snowflake.postpass import Postpass, PostpassContext, transpile
from packs.snowflake.validators import column_check, sniff_kind, validate
from packs.snowflake.vocabulary import VOCABULARY, column_lineage

REPO = pathlib.Path(__file__).resolve().parents[4]
RAW = REPO / "tests" / "fixtures" / "snowflake" / "raw"
ACCT = "acme-prod"


def partition(kind: str, needle: str) -> dict:
    if not RAW.exists():
        pytest.skip("workspace fixtures not present")
    for f in sorted((RAW / kind).glob("*.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        if needle in json.dumps(d):
            return d
    raise AssertionError(f"no {kind} partition holds {needle}")


def row(engine: str, schema: str, name: str, **kw) -> dict:
    eid = f"{ACCT}.SALES_DB.{schema}.{name}"
    return {"etl_id": eid, "asset_id": eid, "engine": engine, "name": name, **kw}


# ------------------------------------------------------------------------------------------------- the pack
def test_pack_satisfies_the_protocol_and_is_ready():
    pack = get_pack("snowflake")
    assert isinstance(pack, SourcePack) and not missing_parts(pack)
    assert pack.caveats.literals_sensitive and pack.profile.ready
    assert pack.caveats.judge_ids == tuple(sorted(cav.load_catalogue().families))
    from api.profile import profile_for

    assert profile_for("snowflake").source.ready is True


# ------------------------------------------------------------------------------------------------- the SQL node
def test_sql_node_shape_and_planner_fold():
    doc = {"etl_id": "e1", "asset_id": f"{ACCT}.SALES_DB.CORE.proc/LOAD_PRODUCTS(VARCHAR,NUMBER)",
           "engine": "sql_procedure", "name": "LOAD_PRODUCTS",
           "definition": "INSERT INTO t SELECT * FROM s",
           "inputs": [{"dataset_id": "in-1", "name": "S", "table": "main.x.s"}],
           "outputs": [{"dataset_id": "out-1", "name": "T", "table": "main.x.t"}]}
    std = ct.to_standardized(doc, "e1")
    assert validate_standardized(std, None, "e1") == []
    node = next(a for a in std["e1"]["actions"] if a["type"] == "sql")
    assert node["logic"]["engine"] == "sql_procedure" and node["logic"]["signature"] == ["VARCHAR", "NUMBER"]
    assert node["logic"]["source_dialect"] == "snowflake" and node["logic"]["statement_index"] == 0
    # the sink is found by its TARGET category / dataset id, not by DOMO's dataset name
    flow = to_planner_dataflow(std, "e1")
    sink = next(n for n in flow["nodes"] if n["category"] == "TARGET")
    assert sink["properties"]["table"] == "main.x.t"
    assert {n["category"] for n in flow["nodes"]} == {"SOURCE", "TRANSFORMATION", "TARGET"}


def test_hidden_definition_is_one_unavailable_node_never_translated():
    d = partition("view", "V_SECURE_MARGIN")
    doc = ct.unit_doc(row("sql_view", "ANALYTICS", "V_SECURE_MARGIN"), d)
    assert ct.is_unavailable(doc["definition"]) and doc["params"]["secure"] is True
    nodes = ct.node_units(doc)
    assert len(nodes) == 1 and nodes[0]["state"] == "unavailable" and nodes[0]["sql"] is None
    assert nodes[0]["original_ddl_ref"]["state"] == "unavailable"          # hard rule 6: never "" / None


def test_raw_partition_rows_are_picked_by_name_and_the_ddl_is_unwrapped():
    d = partition("view", "V_AS_OF")
    doc = ct.unit_doc(row("sql_view", "ANALYTICS", "V_AS_OF"), d)
    assert ct.node_units(doc)[0]["sql"].upper().startswith("SELECT CURRENT_DATE()")


def test_scripting_procedure_is_split_by_the_block_aware_splitter():
    doc = {"etl_id": "p", "asset_id": f"{ACCT}.SALES_DB.CORE.proc/P()", "engine": "sql_procedure", "name": "P",
           "definition": "BEGIN\n TRUNCATE TABLE a;\n IF (1=1) THEN INSERT INTO a SELECT 1; END IF;\nEND"}
    nodes = ct.node_units(doc)
    assert [n.get("node_kind") for n in nodes] == ["statement", "block"]
    assert nodes[1]["params"]["unparsed"] is True and len(nodes[1]["params"]["children"]) == 1


def test_unknown_engine_is_refused_by_the_contract():
    with pytest.raises(ValueError):
        ct.to_standardized({"engine": "nope", "definition": "x"}, "x")


# ------------------------------------------------------------------------------------------------- caveats
@pytest.mark.parametrize("sql,expected", [
    ("SELECT IFF(a, 1, 0) FROM t", "SNW-IFF"),
    ("SELECT v:a.b::string FROM t", "SNW-VARIANT-PATH"),
    ("SELECT * FROM t, LATERAL FLATTEN(input => t.arr) f", "SNW-LATERAL-FLATTEN"),
    ("SELECT DATEADD(day, 1, d) FROM t", "SNW-DATEADD"),
    ("SELECT a FROM t QUALIFY ROW_NUMBER() OVER (ORDER BY a) = 1", "SNW-QUALIFY"),
    ("SELECT a / b FROM t", "SNW-INT-DIVISION"),
    ("SELECT CONVERT_TIMEZONE('UTC', ts) FROM t", "SNW-TIMESTAMP-TZ"),
    ("SELECT s.NEXTVAL FROM t", "SNW-SEQUENCE"),
    ("SELECT $1 FROM t", "SNW-STAGE-COLUMN"),
    ("SELECT a FROM t START WITH x = 1 CONNECT BY PRIOR a = b", "SNW-CONNECT-BY"),
])
def test_each_caveat_is_detected(sql, expected):
    assert expected in cav.detect(sql)


def test_literals_and_comments_never_trigger_or_leak_into_detection():
    assert cav.detect("SELECT 'a:b', 'IFF(x)' FROM t -- QUALIFY\n") == []
    assert "IFF" not in cav.blank_literals("SELECT 'IFF(secret)' AS x")


def test_severity_classes_and_block_goes_straight_to_the_human():
    cls = cav.classify(["SNW-IFF", "SNW-LATERAL-FLATTEN", "SNW-STAGE-COLUMN", "SNW-VARIANT-PATH"])
    assert cls["info"] == ["SNW-IFF"] and cls["escalate"] == ["SNW-LATERAL-FLATTEN"]
    assert cls["block"] == ["SNW-STAGE-COLUMN"] and cls["review"] == ["SNW-VARIANT-PATH"]


def test_one_judge_per_family_generated_from_the_yaml():
    from core.contracts.judges import JudgeKind  # noqa: F401

    judges = cav.generate_judges()
    assert [j.rule_id for j in judges] == sorted(cav.load_catalogue().families)

    class Subject:
        artifact, node_ids = "", []
        meta = {"caveats_hit": {"u1": ["SNW-STAGE-COLUMN", "SNW-IFF"], "u2": ["SNW-VARIANT-PATH"]}}

    by_id = {j.rule_id: j.run(Subject()) for j in judges}
    assert by_id["SNW005"].verdict is Verdict.FAIL          # block caveat
    assert by_id["SNW002"].verdict is Verdict.WARN          # review caveat
    assert by_id["SNW006"].verdict is Verdict.PASS          # info only


# ------------------------------------------------------------------------------------------------- tier 0 + post-pass
def pp(**kw) -> Postpass:
    return Postpass(PostpassContext(table_map={
        ("SALES_DB", "CORE", "ORDERS"): "main.sfdemo_sales_db_core.orders",
        ("HR_DB", "CORE", "ORDERS"): "main.sfdemo_hr_db_core.orders"}, default_db="SALES_DB",
        default_schema="CORE", engine="sql_view", **kw))


def test_tier0_transpiles_then_the_postpass_maps_qualifies_and_folds():
    tr = transpile("SELECT IFF(AMOUNT > 1, 1, 0) AS BIG, o.ID FROM CORE.ORDERS o")
    assert tr.ok and "IF(" in tr.sql
    res = pp().apply(tr.sql)
    assert res.sql == "SELECT IF(amount > 1, 1, 0) AS big, o.id FROM main.sfdemo_sales_db_core.orders AS o"
    assert res.assumed == ["CORE.ORDERS -> SALES_DB.CORE.ORDERS"] and not res.problems


def test_same_table_name_in_two_databases_gets_distinct_targets():
    a = pp().apply("SELECT x FROM SALES_DB.CORE.ORDERS").sql
    b = pp().apply("SELECT x FROM HR_DB.CORE.ORDERS").sql
    assert a != b and "sales_db" in a and "hr_db" in b


def test_postpass_is_idempotent_and_an_unmapped_reference_is_a_problem():
    once = pp().apply("SELECT x FROM CORE.ORDERS").sql
    assert pp().apply(once).sql == once and pp().problems(once) == []
    bad = pp().apply("SELECT x FROM CORE.NOT_LANDED")
    assert bad.unmapped == ["SALES_DB.CORE.NOT_LANDED"] and bad.problems
    cte = pp().apply("WITH a AS (SELECT 1 AS x) SELECT x FROM a")
    assert not cte.problems                                    # a CTE is local, never mapped


def test_postpass_maps_landed_source_columns():
    p = pp(source_columns={"ORDER_ID": "order_id_landed"})
    assert "order_id_landed" in p.apply("SELECT ORDER_ID FROM CORE.ORDERS").sql


def test_tier0_refuses_what_sqlglot_cannot_translate():
    assert not transpile("SELECT FROM FROM").ok


# ------------------------------------------------------------------------------------------------- validators
def test_validator_per_kind():
    assert validate("cte_chain", "WITH a AS (SELECT 1 AS x) SELECT x FROM a") == []
    assert validate("cte_chain", "DELETE FROM t") and validate("cte_chain", "SELECT 1; SELECT 2")
    assert validate("statement", "MERGE INTO t USING s ON t.a = s.a WHEN MATCHED THEN UPDATE SET b = 1") == []
    assert validate("statement", "SELECT 1")
    proc = "CREATE OR REPLACE PROCEDURE m.s.p() LANGUAGE SQL SQL SECURITY INVOKER AS BEGIN DELETE FROM t; END"
    assert validate("script", proc) == []
    assert validate("script", proc.replace("DELETE FROM t", "EXECUTE IMMEDIATE :v"))
    assert validate("script", "SELECT 1")
    assert validate("pipeline", "CREATE OR REFRESH MATERIALIZED VIEW m.s.v AS SELECT 1 AS a") == []
    assert validate("pipeline", "CREATE TABLE x (a INT)")
    job = {"name": "j", "tasks": [{"task_key": "a", "sql_task": {}}, {"task_key": "b", "run_if": "ALL_DONE",
                                                                      "depends_on": [{"task_key": "a"}], "sql_task": {}}]}
    assert validate("job", json.dumps(job)) == []
    job["tasks"][1]["depends_on"] = [{"task_key": "zz"}]
    assert validate("job", json.dumps(job))
    assert validate("python", "import pyspark\nx = 1") == []
    assert validate("python", "import subprocess") and validate("python", "eval('1')") and validate("python", "def (")
    assert validate("file_load", "COPY INTO t FROM 's3://b/p' FILEFORMAT = CSV") == []
    assert validate("file_load", "SELECT 1")
    assert validate("governance", "GRANT SELECT ON TABLE t TO `g`") == [] and validate("governance", "DROP TABLE t")


def test_sniff_kind():
    assert [sniff_kind(s) for s in ("SELECT 1", "MERGE INTO a", "CALL p()", "a + b",
                                    "CREATE PROCEDURE p() LANGUAGE SQL AS BEGIN SELECT 1; END")] == [
        "cte_chain", "statement", "call", "expression", "script"]


# ------------------------------------------------------------------------------------------------- column check
def test_column_check_is_never_a_vacuous_pass():
    cat = {"main.s.t": {"a": "int", "b": "string"}}
    assert column_check("SELECT a, b FROM main.s.t", cat).status == "ok"
    miss = column_check("SELECT a, z FROM main.s.t", cat)
    assert miss.status == "failed" and miss.missing
    assert column_check("SELECT a FROM main.s.t", None).status == "unverifiable"          # no catalogue
    assert column_check("SELECT a FROM main.s.other", cat).status == "unverifiable"       # table not catalogued


def test_the_catalogue_is_one_query_per_500_tables_and_falls_back_to_source_columns():
    names = [f"c.s.t{i}" for i in range(1200)]
    stmts = information_schema_sql(names)
    assert len(stmts) == 3 and all("information_schema.columns" in s for s in stmts)
    seen: list[str] = []

    def query(sql: str) -> list[dict]:
        seen.append(sql)
        return [{"table_catalog": "c", "table_schema": "s", "table_name": "t1", "column_name": "A", "data_type": "int"}]

    cat = build_catalogue(names, query, source_columns={"c.s.t2": {"B": "string"}})
    assert len(seen) == 3 and cat["c.s.t1"] == {"a": "int"} and cat["c.s.t2"] == {"b": "string"}
    assert build_catalogue(["c.s.t2"], None, source_columns={"c.s.t2": {"B": "x"}}) == {"c.s.t2": {"b": "x"}}


# ------------------------------------------------------------------------------------------------- lineage
def test_lineage_comes_from_sqlglot_and_is_unverifiable_without_it():
    sql = "SELECT o.id, SUM(o.amt) AS tot FROM a.b.orders o GROUP BY 1"
    assert column_lineage(sql) == {"id": {"ID"}, "tot": {"AMT"}}
    node = {"type": "sql", "properties": {"sql": sql}}
    assert VOCABULARY.lineage_status(node) == "verifiable" and VOCABULARY.columns_read(node) == {"ID", "AMT"}
    star = {"type": "sql", "properties": {"sql": "SELECT * FROM t"}}
    assert VOCABULARY.lineage_status(star) == "unverifiable" and VOCABULARY.columns_read(star) == set()
    assert VOCABULARY.lineage_status({"type": "sql", "properties": {}}) == "unverifiable"
