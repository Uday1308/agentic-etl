# Ported (anonymized) from SNF2DBX-main/tests (sequence, external table and alert cases; LatentView internal),
# adapted to the pack: objects are converted from their DDL, statement patterns run through the real tier 0.
"""S8 (ADR 037 section 2, catalogue 4.3, 6.4, 6.5, 6.7, 6.10, 6.11): sequences, external tables, alerts, stream types,
multi-table INSERT and the stream + MERGE -> AUTO CDC pattern."""
from __future__ import annotations

import asyncio
import json

import pytest

from agents.cd_codegen.translate.chain import TranslationSettings
from packs.snowflake import objects as ob
from packs.snowflake import translate as tr
from packs.snowflake.assembly import assemble_batch
from packs.snowflake.conversion import ConversionContext
from packs.snowflake.validators import validate

TABLES = {("DB", "S", n.upper()): f"main.s.{n}" for n in ("src", "big", "mid", "small", "a", "b", "t", "tgt", "orders")}


def unit(sql, engine="query", columns=None, stream_tables=None, stream_types=None, table_map=None):
    doc = {"etl_id": "e1", "asset_id": "bench:q:acme.DB.S.Q", "engine": engine, "name": "Q", "definition": sql, "params": {}}
    ctx = tr.make_context(etl_key="e1", engine=engine, table_map=table_map or TABLES, default_db="DB", default_schema="S",
                          settings=TranslationSettings(tiers=("human",)), conversion=ConversionContext.build(catalogue=columns),
                          stream_tables=stream_tables or {}, stream_types=stream_types or {})
    return asyncio.run(tr.translate_etl(doc, ctx))[0]


def statements(sql):
    return [s.strip() for s in sql.split(";\n")]


# ------------------------------------------------------------------------------------------------ 4.3 multi-table INSERT
def test_insert_all_is_one_insert_per_target_from_one_temp_view():
    r = unit("INSERT ALL WHEN amount > 100 THEN INTO big (id) VALUES (id) WHEN amount <= 100 THEN INTO small (id) VALUES (id)"
             " SELECT id, amount FROM src")
    assert r.status == "resolved" and r.origin == "mapped"
    s = statements(r.sql)
    assert s[0].startswith("CREATE OR REPLACE TEMPORARY VIEW mti_") and "FROM main.s.src" in s[0]
    view = s[0].split()[5]
    assert s[1] == f"INSERT INTO main.s.big (id) SELECT id FROM {view} WHERE amount > 100"
    assert s[2] == f"INSERT INTO main.s.small (id) SELECT id FROM {view} WHERE amount <= 100"
    assert "SNW-MULTI-INSERT" in r.review_caveats and r.params["multi_insert"]["mode"] == "ALL"
    assert all(validate("statement", x) == [] for x in s)            # every statement validates on its own
    assert "not atomic" in json.dumps(r.evidence["pattern"]["notes"]) or "ONE statement" in r.evidence["pattern"]["notes"][0]


def test_insert_all_without_conditions_loads_every_row_into_every_target():
    r = unit("INSERT ALL INTO a (id) VALUES (id) INTO b (id, amount) VALUES (id, amount) SELECT id, amount FROM src")
    s = statements(r.sql)
    assert "WHERE" not in s[1] and "WHERE" not in s[2]
    assert s[2].startswith("INSERT INTO main.s.b (id, amount) SELECT id, amount FROM mti_")


def test_insert_first_predicates_are_mutually_exclusive_and_null_safe():
    r = unit("INSERT FIRST WHEN amount > 100 THEN INTO big (id) VALUES (id) WHEN amount > 10 THEN INTO mid (id) VALUES (id)"
             " ELSE INTO small (id) VALUES (id) SELECT id, amount FROM src")
    s = statements(r.sql)
    assert s[1].endswith("WHERE amount > 100")
    assert s[2].endswith("WHERE (amount > 10) AND NOT COALESCE(amount > 100, FALSE)")
    assert s[3].endswith("WHERE NOT COALESCE(amount > 100, FALSE) AND NOT COALESCE(amount > 10, FALSE)")
    assert r.params["multi_insert"]["mode"] == "FIRST"


def test_insert_first_matches_snowflake_on_sample_rows():
    """The predicates are the semantics: each row lands in exactly the first target whose condition is TRUE; NULL falls
    through (NOT COALESCE(NULL, FALSE) is TRUE). Evaluated in Python over the same predicates."""
    rows = [150, 50, 5, None]

    def snowflake_first(a):
        for name, cond in (("big", a is not None and a > 100), ("mid", a is not None and a > 10)):
            if cond:
                return name
        return "small"

    def converted(a):
        c1 = a is not None and a > 100
        c2 = a is not None and a > 10
        out = []
        if c1:
            out.append("big")
        if c2 and not c1:
            out.append("mid")
        if not c1 and not c2:
            out.append("small")
        return out
    for a in rows:
        assert converted(a) == [snowflake_first(a)], a


@pytest.mark.parametrize("sql,why", [
    ("INSERT OVERWRITE ALL INTO a INTO b SELECT id, amount FROM src", "OVERWRITE"),
    ("INSERT ALL INTO a (x) VALUES (id + 1) INTO b (x) VALUES (id) SELECT id + 1, id FROM src", "no name"),
])
def test_unprovable_multi_inserts_escalate(sql, why):
    r = unit(sql)
    assert r.status == "awaiting_review" and not r.sql and any(why.lower() in x.lower() for x in r.reasons)


# ------------------------------------------------------------------------------------------------ 6.11 sequences
def test_nextval_in_insert_select_drops_the_identity_column():
    r = unit("INSERT INTO t SELECT s.NEXTVAL, v FROM src", columns={"main.s.t": {"id": "NUMBER", "v": "VARCHAR"}})
    assert r.sql == "INSERT INTO main.s.t (v) SELECT v FROM main.s.src"
    assert {"SNW-SEQ-IDENTITY"} <= set(r.review_caveats) and r.params["sequence_identity"]["column"] == "id"
    assert "NEXTVAL" not in r.sql


def test_nextval_with_an_explicit_column_list_and_values():
    r = unit("INSERT INTO t (id, v) VALUES (s.NEXTVAL, 'x')")
    assert r.sql == "INSERT INTO main.s.t (v) VALUES ('x')"


@pytest.mark.parametrize("sql", [
    "INSERT INTO t SELECT s.NEXTVAL, v FROM src",                       # target columns unknown
    "INSERT INTO t (id, v) SELECT id, v FROM src WHERE id > s.NEXTVAL",   # NEXTVAL outside a projected column
    "INSERT INTO t (id, v) SELECT s.NEXTVAL, s.NEXTVAL FROM src",       # twice
    "INSERT INTO t (id, v) SELECT s.NEXTVAL + 1, v FROM src",           # inside an expression
])
def test_nextval_elsewhere_escalates_with_the_options(sql):
    r = unit(sql)
    assert r.status == "awaiting_review" and "SNW-SEQ-SHARED" in r.caveats
    assert "uuid()" in r.reasons[0] and "counter table" in r.reasons[0]


def test_single_use_sequence_becomes_an_identity_clause():
    spec = ob.parse_sequence("CREATE OR REPLACE SEQUENCE db.s.order_seq START = 1000 INCREMENT = 5 ORDER")
    assert spec == {"name": "db.s.order_seq", "start": 1000, "increment": 5, "ordered": True}
    res = ob.convert_sequence(spec, [{"table": "db.s.orders", "column": "id"}])
    assert res.status == "converted"
    assert res.text == "GENERATED BY DEFAULT AS IDENTITY (START WITH 1000 INCREMENT BY 5)"
    assert any("ORDER" in x for x in res.reasons) and "SNW-SEQ-IDENTITY" in res.caveats
    assert any("current value" in x for x in res.reasons)              # the start must be the current value + step


def test_shared_and_standalone_sequences_are_flagged_with_the_options():
    spec = ob.parse_sequence("CREATE SEQUENCE x")
    assert (spec["start"], spec["increment"], spec["ordered"]) == (1, 1, False)
    for usages in ([], [{"table": "a", "column": "id"}, {"table": "b", "column": "id"}]):
        res = ob.convert_sequence(spec, usages)
        assert res.status == "flagged" and res.caveats == ["SNW-SEQ-SHARED"] and not res.text
        assert "uuid()" in res.reasons[0]


def test_a_column_default_nextval_becomes_the_identity_clause():
    seqs = {"DB.S.ORDER_SEQ": {"start": 7, "increment": 2}}
    assert ob.default_to_identity("db.s.order_seq.NEXTVAL", seqs) == \
        "GENERATED BY DEFAULT AS IDENTITY (START WITH 7 INCREMENT BY 2)"
    assert ob.default_to_identity("CURRENT_TIMESTAMP()", seqs) is None
    assert ob.default_to_identity("unknown.NEXTVAL", seqs) is None


# ------------------------------------------------------------------------------------------------ 6.10 external tables
EXT = ("CREATE EXTERNAL TABLE db.s.ext_orders (id NUMBER AS (VALUE:id::NUMBER), v VARCHAR AS (VALUE:v::VARCHAR)) "
       "LOCATION = @raw_stage/orders/ FILE_FORMAT = (TYPE = PARQUET)")


def test_plain_external_table_is_a_uc_external_table():
    res = ob.convert_object("external_table", EXT, stage_urls={"RAW_STAGE": "s3://bucket.example.invalid/raw/"})
    assert res.status == "converted" and res.params["route"] == "uc_external_table"
    assert res.text == ("CREATE TABLE IF NOT EXISTS main.db_s.ext_orders (id DECIMAL(38, 0), v STRING) USING parquet "
                        "LOCATION 's3://bucket.example.invalid/raw/orders'")
    assert "SNW-EXT-LOCATION" not in res.caveats


def test_an_unknown_stage_keeps_a_placeholder_never_an_invented_url():
    res = ob.convert_object("external_table", EXT)
    assert "{{stage:RAW_STAGE}}/orders" in res.text and "SNW-EXT-LOCATION" in res.caveats
    assert any("external location" in x for x in res.reasons)


def test_filename_partition_expressions_move_into_the_load_query():
    ddl = ("CREATE EXTERNAL TABLE ext_events (id NUMBER AS (VALUE:id::NUMBER), load_day DATE AS "
           "(TO_DATE(SPLIT_PART(METADATA$FILENAME, '/', 2), 'YYYYMMDD'))) PARTITION BY (load_day) "
           "LOCATION = @raw_stage/events/ FILE_FORMAT = (TYPE = PARQUET)")
    res = ob.convert_object("external_table", ddl, stage_urls={"RAW_STAGE": "s3://b.example.invalid/raw"})
    assert res.params["route"] == "file_load" and res.status == "converted"
    assert res.text.startswith("CREATE OR REFRESH STREAMING TABLE ") and "PARTITIONED BY (load_day)" in res.text
    assert "_metadata.file_path" in res.text and "METADATA$" not in res.text
    assert "FROM STREAM read_files('s3://b.example.invalid/raw/events', format => 'parquet')" in res.text
    assert validate("file_load", res.text) == []                         # the pack's own file_load validator accepts it
    assert any("generated column" in x for x in res.reasons)


def test_regex_pattern_and_unknown_expressions_are_never_translated_silently():
    res = ob.convert_object("external_table", EXT.replace("FILE_FORMAT", "PATTERN = '.*[.]parquet' FILE_FORMAT"),
                            stage_urls={"RAW_STAGE": "s3://b.example.invalid/raw"})
    assert any("regular expression" in x for x in res.reasons)
    bad = ob.convert_object("external_table", EXT.replace("VALUE:v::VARCHAR", "UPPER(VALUE:v::VARCHAR)"),
                            stage_urls={"RAW_STAGE": "s3://b.example.invalid/raw"})
    assert bad.status == "flagged" and any("convert by hand" in x for x in bad.reasons)
    avro = ob.convert_object("external_table", EXT.replace("PARQUET", "XML"))
    assert avro.status == "flagged"


def test_csv_columns_are_read_by_position():
    ddl = ("CREATE EXTERNAL TABLE ext_c (a NUMBER AS (VALUE:c1::NUMBER), d DATE AS (TO_DATE(SPLIT_PART(METADATA$FILENAME, "
           "'/', 1)))) PARTITION BY (d) LOCATION = @s/p/ FILE_FORMAT = (TYPE = CSV)")
    res = ob.convert_object("external_table", ddl, stage_urls={"S": "s3://b.example.invalid/x"})
    assert "`_c0`" in res.text and "header => 'false'" in res.text


# ------------------------------------------------------------------------------------------------ 6.7 alerts
ALERT = ("CREATE ALERT low_stock WAREHOUSE = wh SCHEDULE = '30 MINUTE' IF (EXISTS (SELECT 1 FROM orders WHERE amount < 5)) "
         "THEN CALL SYSTEM$SEND_EMAIL('ops_int', 'ops@example.invalid', 'low stock', 'check stock')")


def test_alert_condition_becomes_a_row_count_query_and_the_job_is_paused():
    ctx = tr.make_context(etl_key="a", engine="query", table_map=TABLES, default_db="DB", default_schema="S")
    spec = ob.parse_alert(ALERT)
    assert spec["schedule"] == "30 MINUTE" and spec["warehouse"] == "wh" and "SEND_EMAIL" in spec["action"]
    res = ob.convert_alert(spec, convert_query=ob.tier0_query_converter(ctx))
    assert res.text == "SELECT count(*) AS row_count FROM (SELECT 1 FROM main.s.orders WHERE amount < 5) AS alert_condition"
    entry = res.params["alert"]
    job, why = ob.alert_job(entry)
    assert job["schedule"]["pause_status"] == "PAUSED" and job["schedule"]["quartz_cron_expression"] == "0 0/30 * * * ?"
    assert job["tasks"][0]["sql_task"]["alert"]["alert_id"] == "${var.alert_low_stock}"
    assert job["alert_definition"]["trigger"] == "row_count > 0" and entry["action_kind"] == "email"
    assert validate("job", json.dumps(job)) == [] and any("PAUSED" in x for x in why)


def test_a_non_email_action_is_not_converted_and_says_so():
    res = ob.convert_object("alert", "CREATE ALERT a SCHEDULE = '5 MINUTE' IF (EXISTS (SELECT 1 FROM orders)) "
                                     "THEN INSERT INTO log VALUES (1)", convert_query=lambda q: (q, []))
    assert res.params["alert"]["action_kind"] == "other"
    assert any("not an e-mail" in x for x in res.reasons)
    _, why = ob.alert_job(res.params["alert"])
    assert any("not converted" in x for x in why)


def test_an_untranslated_condition_flags_the_alert():
    res = ob.convert_object("alert", ALERT)
    assert res.status == "flagged" and res.params["alert"]["condition_source"]
    job, why = ob.alert_job(res.params["alert"])
    assert any("not translated" in x for x in why) and job["alert_definition"]["query"] is None


def test_assembly_builds_one_paused_job_per_alert_and_never_auto_approves():
    ctx = tr.make_context(etl_key="a", engine="query", table_map=TABLES, default_db="DB", default_schema="S")
    entry = ob.convert_alert(ob.parse_alert(ALERT), convert_query=ob.tier0_query_converter(ctx)).params["alert"]
    asm = assemble_batch(None, [], {"alerts": [entry]})
    assert [j["name"] for j in asm.jobs] == ["alert_low_stock"] and asm.jobs[0]["schedule"]["pause_status"] == "PAUSED"
    assert not asm.auto_approvable and asm.gate()["auto_approvable"] is False
    assert any("alert_low_stock" in r for r in asm.review_reasons)


# ------------------------------------------------------------------------------------------------ 6.4 / 6.5 streams
def test_stream_types_map_to_a_change_feed_filter_and_offset_bookkeeping():
    std = ob.convert_object("stream", "CREATE OR REPLACE STREAM s ON TABLE db.s.orders")
    assert std.text == "ALTER TABLE main.db_s.orders SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
    assert std.params["read"]["filter"] is None and std.params["read"]["starting_version"] == "current_version"
    assert any("offset bookkeeping" in x for x in std.reasons)
    only = ob.convert_object("stream", "CREATE STREAM s ON TABLE orders APPEND_ONLY = TRUE SHOW_INITIAL_ROWS = TRUE")
    assert only.params["read"]["filter"] == "_change_type = 'insert'" and only.params["read"]["starting_version"] == 0
    assert any("version 0" in x for x in only.reasons)
    view = ob.convert_object("stream", "CREATE STREAM s ON VIEW v")
    assert view.status == "flagged" and "SNW-STREAM-TYPE" in view.caveats


def test_a_read_of_an_append_only_stream_sees_inserts_only():
    r = unit("SELECT id FROM orders_stream WHERE id > 0", stream_tables={"ORDERS_STREAM": "main.s.orders"},
             stream_types={"ORDERS_STREAM": {"append_only": True}})
    assert "_change_type = 'insert'" in r.sql and "TABLE_CHANGES('main.s.orders', :start_version)" in r.sql
    assert "AS orders_stream" in r.sql and "change_data_feed" in r.params
    std = unit("SELECT id FROM orders_stream", stream_tables={"ORDERS_STREAM": "main.s.orders"})
    assert "_change_type" not in std.sql and "TABLE_CHANGES(" in std.sql


def test_show_initial_rows_is_a_reviewer_note_on_the_read():
    r = unit("SELECT id FROM orders_stream", stream_tables={"ORDERS_STREAM": "main.s.orders"},
             stream_types={"ORDERS_STREAM": {"show_initial_rows": True}})
    assert "version 0" in r.params["change_data_feed"]["note"]


MERGE = ("MERGE INTO tgt t USING (SELECT id, v, METADATA$ACTION AS act FROM orders_stream) s ON t.id = s.id "
         "WHEN MATCHED AND s.act = 'DELETE' THEN DELETE WHEN MATCHED THEN UPDATE SET v = s.v "
         "WHEN NOT MATCHED THEN INSERT (id, v) VALUES (s.id, s.v)")


def test_stream_task_merge_becomes_one_auto_cdc_flow():
    r = unit(MERGE, engine="task", stream_tables={"ORDERS_STREAM": "main.s.orders"})
    assert r.status == "resolved" and r.kind == "pipeline" and "SNW-AUTO-CDC" in r.review_caveats
    assert r.sql == ("CREATE OR REFRESH STREAMING TABLE main.s.tgt;\n"
                     "AUTO CDC INTO main.s.tgt FROM STREAM(main.s.orders) KEYS (id) APPLY AS DELETE WHEN "
                     "_change_type = 'delete' SEQUENCE BY _commit_version COLUMNS id, v STORED AS SCD TYPE 1")
    assert validate("pipeline", r.sql) == [] and "UNVERIFIED" in r.evidence["pattern"]["notes"][0]


@pytest.mark.parametrize("sql", [
    MERGE.replace("SELECT id, v, METADATA$ACTION", "SELECT id, v * 2 AS v, METADATA$ACTION"),    # computed column
    MERGE.replace("ON t.id = s.id", "ON t.id = s.id AND t.v > 1"),                                 # non-key ON
    MERGE.replace("s.act = 'DELETE'", "s.act = 'INSERT'"),                                         # not a delete clause
    MERGE.replace("FROM orders_stream", "FROM orders_stream WHERE id > 0"),                        # a filter
])
def test_a_merge_outside_the_proven_shape_keeps_the_generic_path(sql):
    r = unit(sql, engine="task", stream_tables={"ORDERS_STREAM": "main.s.orders"})
    assert "AUTO CDC" not in (r.sql or "") and "SNW-AUTO-CDC" not in r.caveats


def test_a_merge_on_an_unknown_stream_is_not_an_auto_cdc_pattern():
    r = unit(MERGE.replace("orders_stream", "evt_changes"), engine="task")
    assert r.status == "awaiting_review" and "SNW-AUTO-CDC" not in r.caveats


# ------------------------------------------------------------------------------------------------ the corpus
def test_corpus_6b_cases_behave_as_classified():
    from packs.snowflake import benchmark as bm
    cases = [c for c in bm.load_corpus() if c.source == "corpus_6b_objects.yaml"]
    assert len(cases) >= 20 and bm.validate_corpus(cases) == []
    for o in bm.run_all(cases):
        assert o.observed != "error", (o.case.id, o.reasons)
        if o.case.cls in bm.FLAGGED_CLASSES:
            assert o.flagged, o.case.id
        else:
            assert o.deterministic, (o.case.id, o.observed, o.reasons)
        if o.case.sql:
            assert o.sql_match, (o.case.id, o.sql)
        assert not o.residue, o.case.id
