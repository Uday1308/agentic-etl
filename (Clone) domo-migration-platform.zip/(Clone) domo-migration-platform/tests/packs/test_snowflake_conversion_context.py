"""ConversionContext (conversion engine v2 X1, X2, X4; ADR 037 sections 3-5): account parameters from the handoff
manifest, the target capability profile, column types for the referenced tables, and that ``prepare_batch`` threads
all three into every unit's context. Offline, synthetic."""
from __future__ import annotations

import pathlib

import pytest

from packs.snowflake import translate as tr
from packs.snowflake.batch import prepare_batch
from packs.snowflake.conversion import (
    PARAMETER_NAMES,
    SNOWFLAKE_DEFAULTS,
    ConversionContext,
    SessionParameters,
    load_profiles,
    select_profile,
    type_family,
)
from packs.snowflake.run import make_unit_context

PARAMS = {
    "TIMEZONE": {"value": "Europe/Berlin", "default": "America/Los_Angeles", "level": "account", "state": "provided"},
    "WEEK_START": {"value": "1", "default": "0", "level": "account", "state": "provided"},
    "WEEK_OF_YEAR_POLICY": {"state": "unavailable", "reason": "the account parameter read did not return it"},
}


# ------------------------------------------------------------------------------------------------ X1 parameters
def test_parameters_are_provided_or_unavailable_never_defaulted_silently() -> None:
    p = SessionParameters.from_manifest(PARAMS)
    assert p.get("TIMEZONE").known and p.get("timezone").value == "Europe/Berlin"
    wk = p.get("WEEK_OF_YEAR_POLICY")
    assert not wk.known and wk.state == "unavailable" and wk.value is None and "did not return" in wk.reason
    assert p.get("DATE_INPUT_FORMAT").state == "unavailable"            # absent from the input altogether
    assert set(p.values) == set(PARAMETER_NAMES)
    assert p.known == ["TIMEZONE", "WEEK_START"]


def test_value_or_default_always_says_when_it_assumed() -> None:
    p = SessionParameters.from_manifest(PARAMS)
    assert p.get("WEEK_START").value_or_default() == ("1", False)
    assert p.get("WEEK_OF_YEAR_POLICY").value_or_default() == (SNOWFLAKE_DEFAULTS["WEEK_OF_YEAR_POLICY"], True)


def test_a_source_without_parameters_is_all_unavailable() -> None:
    p = SessionParameters.from_manifest(None)
    assert p.known == [] and all(v.state == "unavailable" for v in p.values.values())


# ------------------------------------------------------------------------------------------------ X4 capabilities
def test_default_profile_is_a_modern_warehouse() -> None:
    prof = select_profile()
    assert prof.name == "databricks_sql_current"
    for flag in ("variant", "recursive_cte", "sql_procedures", "collations", "listagg", "geo_types", "abac",
                 "sql_scripting"):
        assert prof.has(flag), flag
    assert not prof.has("multi_statement_txn") and not prof.has("temp_tables")


def test_every_profile_states_every_flag() -> None:
    default, profiles = load_profiles()
    assert default in profiles and len(profiles) >= 2
    flags = {frozenset(p.flags) for p in profiles.values()}
    assert len(flags) == 1 and len(next(iter(flags))) == 10
    assert not any(select_profile("databricks_sql_conservative").flags.values())


def test_selection_order_argument_then_environment_then_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("MIGRATOR_CAPABILITY_PROFILE", raising=False)
    assert select_profile().name == "databricks_sql_current"
    monkeypatch.setenv("MIGRATOR_CAPABILITY_PROFILE", "databricks_sql_conservative")
    assert select_profile().name == "databricks_sql_conservative"
    assert select_profile("databricks_sql_current").name == "databricks_sql_current"
    with pytest.raises(ValueError, match="unknown capability profile"):
        select_profile("nope")


def test_unknown_flag_is_an_error_not_false() -> None:
    with pytest.raises(KeyError):
        select_profile().has("quantum")


def test_a_profile_file_can_override_and_inherits_the_default_flags(tmp_path: pathlib.Path) -> None:
    f = tmp_path / "caps.yaml"
    f.write_text("default_profile: base\nflags: {variant: v, listagg: l}\nprofiles:\n  base: {variant: true, listagg: true}\n"
                 "  old: {listagg: false}\n", encoding="utf-8")
    _, profiles = load_profiles(f)
    assert profiles["old"].flags == {"variant": True, "listagg": False}
    f.write_text("default_profile: base\nflags: {variant: v}\nprofiles:\n  base: {variant: true, bogus: true}\n",
                 encoding="utf-8")
    with pytest.raises(ValueError, match="unknown flags"):
        load_profiles(f)


# ------------------------------------------------------------------------------------------------ X2 types
def test_type_families() -> None:
    assert type_family("NUMBER(38,0)") == "numeric" and type_family("varchar(16777216)") == "string"
    assert type_family("TIMESTAMP_NTZ(9)") == "timestamp_ntz" and type_family("TIMESTAMP_TZ") == "timestamp_tz"
    assert type_family("TIMESTAMP") == "timestamp" and type_family("DATE") == "date"
    assert type_family("VARIANT") == "variant" and type_family("ARRAY") == "variant"
    assert type_family("BOOLEAN") == "boolean" and type_family("GEOGRAPHY") == "geo"
    assert type_family(None) is None and type_family("") is None and type_family("WIDGET") == "other"


def test_column_types_are_case_folded_and_unknown_stays_none() -> None:
    ctx = ConversionContext.build(catalogue={"Main.S.Orders": {"ORDER_ID": "NUMBER(38,0)", "Note": None}})
    assert ctx.table_columns("main.s.orders") == {"order_id": "NUMBER(38,0)", "note": None}
    assert ctx.column_type("MAIN.S.ORDERS", "Order_Id") == "NUMBER(38,0)"
    assert ctx.column_family("main.s.orders", "order_id") == "numeric"
    assert ctx.column_type("main.s.orders", "note") is None              # present, type unknown
    assert ctx.table_columns("main.s.other") is None and ctx.column_type("main.s.other", "x") is None


def test_digest_changes_with_anything_a_rule_may_read() -> None:
    a = ConversionContext.build(source_parameters=PARAMS)
    assert a.digest == ConversionContext.build(source_parameters=PARAMS).digest
    assert a.digest != ConversionContext.build().digest
    assert a.digest != ConversionContext.build(source_parameters=PARAMS, capability_profile="databricks_sql_conservative").digest
    assert a.digest != ConversionContext.build(source_parameters=PARAMS, catalogue={"m.s.t": {"a": "DATE"}}).digest
    s = a.summary()
    assert s["capability_profile"] == "databricks_sql_current" and s["parameters_known"] == ["TIMEZONE", "WEEK_START"]
    assert "Berlin" not in str(s)                                         # the summary carries no values or names


# ------------------------------------------------------------------------------------------------ threading
MANIFEST = {
    "kind": "etl_logic_migration", "manifest_version": 2, "etls": [], "file_loads": [], "read_statements": [],
    "target_map": {"acme.DB.S.ORDERS": "main.s.orders"},
    "source_parameters": PARAMS,
    "source_columns": {"main.s.orders": {"order_id": "NUMBER(38,0)", "placed_at": "TIMESTAMP_NTZ(9)", "note": None}},
    "target": {"capability_profile": "databricks_sql_conservative"},
}


def test_prepare_batch_builds_the_context_from_the_manifest(tmp_path: pathlib.Path) -> None:
    batch = prepare_batch(MANIFEST, tmp_path, tmp_path / "work")
    conv = batch.conversion
    assert conv.param("TIMEZONE").value == "Europe/Berlin" and not conv.param("DATE_INPUT_FORMAT").known
    assert conv.capabilities.name == "databricks_sql_conservative" and not conv.has("listagg")
    assert conv.column_family("main.s.orders", "placed_at") == "timestamp_ntz"
    # the same columns are the validators' column catalogue (X2 reuses it, one source of truth)
    assert batch.catalogue == {"main.s.orders": {"order_id": "NUMBER(38,0)", "placed_at": "TIMESTAMP_NTZ(9)",
                                                 "note": None}}


def test_an_explicit_profile_argument_beats_the_manifest(tmp_path: pathlib.Path) -> None:
    batch = prepare_batch(MANIFEST, tmp_path, tmp_path / "work", capability_profile="databricks_sql_current")
    assert batch.conversion.capabilities.name == "databricks_sql_current"


def test_a_manifest_without_the_new_keys_still_works(tmp_path: pathlib.Path) -> None:
    old = {k: v for k, v in MANIFEST.items() if k not in ("source_parameters", "source_columns", "target")}
    batch = prepare_batch(old, tmp_path, tmp_path / "work")
    assert batch.catalogue is None and batch.conversion.parameters.known == []
    assert batch.conversion.capabilities.name == "databricks_sql_current"


def test_every_unit_context_carries_the_batch_conversion(tmp_path: pathlib.Path) -> None:
    batch = prepare_batch(MANIFEST, tmp_path, tmp_path / "work")
    doc = {"engine": "sql_view", "asset_id": "acct:view:acme.DB.S.V", "name": "V", "definition": "SELECT 1"}
    ctx = make_unit_context(doc, "k", batch)
    assert ctx.conversion is batch.conversion and ctx.catalogue == batch.catalogue
    res, _ = tr.tier0_unit(tr.PreUnit("u", {"sql": "SELECT 1 AS x", "language": "sql"}, "sql_view"), ctx)
    assert res.params["conversion"] == batch.conversion.summary()        # auditable on the unit, no names or values
