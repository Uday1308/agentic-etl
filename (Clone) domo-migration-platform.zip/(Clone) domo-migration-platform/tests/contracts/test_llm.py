"""Contract tests for core.domo.llm.LLMClient (Core Development Guide §9).

Asserts the documented contract, not model quality:
  * goes through registry + concurrency + assembler + observability
  * parses structured output (tolerating ```json fences)
  * hard-constraint violations are RETURNED on LlmResult (ratified decision)
  * exactly one observability row per call
  * retries are counted; exhaustion raises and still records a row
  * NO HARDCODED INPUTS — proven by divergent fixtures (guide §14 golden rule)

All LLM I/O is mocked; these are fast and gate CI.
"""
from __future__ import annotations

import pytest
from conftest import cfg, make_caller

from core.domo.llm import LLMClient
from core.domo.models import EndpointSpec, ModelRegistry, Role
from core.domo.prompts import HardConstraintChecker, PromptAssembler, PromptLayers
from core.domo.schemas import EvalResult


def _registry() -> ModelRegistry:
    return ModelRegistry({"dev": {
        "generator": EndpointSpec(endpoint="gen-endpoint"),
        "evaluator": EndpointSpec(endpoint="eval-endpoint"),
    }})


def _client(obs, concurrency, caller) -> LLMClient:
    return LLMClient(
        registry=_registry(),
        assembler=PromptAssembler(),
        checker=HardConstraintChecker(),
        concurrency=concurrency,
        observability=obs,
        caller=caller,
    )


async def test_happy_path_parses_records_and_returns(obs, concurrency):
    caller = make_caller(text='{"verdict":"pass","confidence":0.9,"issues":[],"summary":"good"}')
    client = _client(obs, concurrency, caller)

    res = await client.complete(
        Role.EVALUATOR, PromptLayers(base="do it"),
        pool="evaluation", response_schema=EvalResult, config=cfg(iteration=2),
    )

    assert isinstance(res.parsed, EvalResult) and res.parsed.passed
    assert res.confidence == 0.9              # confidence surfaced from parsed
    assert res.tokens_in == 7 and res.tokens_out == 3 and res.retries == 0
    assert len(obs.llm_calls) == 1            # exactly one row
    row = obs.llm_calls[0]
    assert row.role == "evaluator" and row.model == "eval-endpoint" and row.iteration == 2
    assert row.prompt_hash and row.status == "ok"


async def test_goes_through_all_collaborators(obs, concurrency):
    caller = make_caller(text="plain text")
    client = _client(obs, concurrency, caller)

    await client.complete(Role.GENERATOR, PromptLayers(base="hello"),
                          pool="cd_translation", config=cfg())

    # concurrency: the named pool was acquired
    assert concurrency.acquired == ["cd_translation"]
    # registry: the recorded model is the resolved endpoint (not a literal)
    assert obs.llm_calls[0].model == "gen-endpoint"
    # assembler: the prompt actually sent includes assembled content
    assert "hello" in caller.prompts[0]
    # observability: recorded exactly once
    assert len(obs.llm_calls) == 1


async def test_hard_constraint_violation_returned_not_raised(obs, concurrency):
    # response contains the forbidden token -> checker flags it, complete RETURNS it
    caller = make_caller(text="this contains SECRET data")
    client = _client(obs, concurrency, caller)

    res = await client.complete(
        Role.GENERATOR, PromptLayers(base="x", hard_constraints=["SECRET"]),
        pool="cd_translation", config=cfg(),
    )
    assert res.hard_constraint_violations == ["SECRET"]   # returned, no exception


async def test_structured_parse_strips_json_fences(obs, concurrency):
    caller = make_caller(text='```json\n{"verdict":"revise","confidence":0.3,"summary":"meh"}\n```')
    client = _client(obs, concurrency, caller)
    res = await client.complete(Role.EVALUATOR, PromptLayers(base="x"),
                                pool="evaluation", response_schema=EvalResult, config=cfg())
    assert res.parsed.verdict.value == "revise" and res.parsed.confidence == 0.3


async def test_retry_then_success_counts_retries(obs, concurrency):
    caller = make_caller(text="ok", fail_times=2)   # fail twice, succeed on the 3rd
    client = _client(obs, concurrency, caller)
    res = await client.complete(Role.GENERATOR, PromptLayers(base="x"),
                                pool="cd_translation", config=cfg())
    assert res.retries == 2
    assert len(obs.llm_calls) == 1 and obs.llm_calls[0].status == "ok"


async def test_retry_exhausted_raises_and_records_error(obs, concurrency):
    caller = make_caller(always_fail=True)
    client = _client(obs, concurrency, caller)
    with pytest.raises(RuntimeError):
        await client.complete(Role.GENERATOR, PromptLayers(base="x"),
                              pool="cd_translation", config=cfg())
    # a single error row is still recorded for observability
    assert len(obs.llm_calls) == 1 and obs.llm_calls[0].status == "error"


async def test_no_hardcoded_inputs_divergent_fixtures(obs, concurrency):
    """Two different calls must produce correspondingly different observability rows.
    If any value were hardcoded, the two rows would collide on that field."""
    client = _client(obs, concurrency, make_caller(text="ok"))

    await client.complete(Role.GENERATOR, PromptLayers(base="prompt-A"),
                          pool="cd_translation", config=cfg(iteration=1, node="generate"))
    await client.complete(Role.EVALUATOR, PromptLayers(base="prompt-B"),
                          pool="evaluation", config=cfg(iteration=5, node="evaluate"))

    a, b = obs.llm_calls
    assert a.role != b.role                    # role flowed from the arg
    assert a.model != b.model                  # endpoint resolved per role
    assert a.pool != b.pool                    # pool flowed from the arg
    assert a.iteration != b.iteration          # iteration flowed from config
    assert a.node != b.node                    # node flowed from config
    assert a.prompt_hash != b.prompt_hash      # prompt actually assembled from layers


class _Block:
    """Stands in for an SDK content-block object exposing `.text`."""
    def __init__(self, text):
        self.text = text


def test_content_to_text_normalizes_endpoint_shapes():
    """Endpoints return content as str, list-of-dicts, list-of-strings, objects, or
    None. All must flatten to text so _parse/raw_text never see a non-string."""
    from core.domo.llm import _content_to_text
    assert _content_to_text("hello") == "hello"
    assert _content_to_text(None) == ""
    assert _content_to_text([{"type": "text", "text": "ab"}, {"type": "text", "text": "cd"}]) == "abcd"
    assert _content_to_text(["x", "y"]) == "xy"
    assert _content_to_text([_Block("p"), _Block("q")]) == "pq"


async def test_complete_handles_list_content_from_endpoint(obs, concurrency):
    """Regression: a list-shaped message.content must not blow up _parse."""
    def list_caller(spec, prompt, response_schema, timeout_s):
        # emulate the caller after normalization would have run; here we exercise
        # the full path by returning a normal string (normalization is unit-tested above)
        return __import__("core.domo.llm", fromlist=["RawCompletion"]).RawCompletion(
            text='{"verdict":"pass","confidence":0.8,"issues":[],"summary":"ok"}')
    client = _client(obs, concurrency, list_caller)
    res = await client.complete(Role.EVALUATOR, PromptLayers(base="x"),
                                pool="evaluation", response_schema=EvalResult, config=cfg())
    assert res.parsed.passed and res.hard_constraint_violations == []


def test_extract_json_pulls_object_from_prose():
    from core.domo.llm import _extract_json
    assert _extract_json('blah blah {"a": 1, "b": "x}y"} trailing') == '{"a": 1, "b": "x}y"}'
    assert _extract_json("prefix [1, 2, 3] suffix") == "[1, 2, 3]"


async def test_parse_tolerates_fenced_and_prose_wrapped_json(obs, concurrency):
    text = ('Sure, here is the evaluation:\n```json\n'
            '{"verdict": "pass", "confidence": 0.7, "issues": [], "summary": "ok"}\n```\nHope it helps!')
    client = _client(obs, concurrency, make_caller(text=text))
    res = await client.complete(Role.EVALUATOR, PromptLayers(base="x"),
                                pool="evaluation", response_schema=EvalResult, config=cfg())
    assert res.parsed.passed and res.parsed.confidence == 0.7


async def test_parse_empty_response_raises_readable_error(obs, concurrency):
    client = _client(obs, concurrency, make_caller(text="   "))
    with pytest.raises(ValueError, match="empty response"):
        await client.complete(Role.EVALUATOR, PromptLayers(base="x"),
                              pool="evaluation", response_schema=EvalResult, config=cfg())


async def test_parse_unparseable_response_names_the_schema(obs, concurrency):
    client = _client(obs, concurrency, make_caller(text="I cannot help with that."))
    with pytest.raises(ValueError, match="EvalResult"):
        await client.complete(Role.EVALUATOR, PromptLayers(base="x"),
                              pool="evaluation", response_schema=EvalResult, config=cfg())
