"""Contract tests for core.domo.prompts (Core Development Guide §4).

The assembler is pure and deterministic, includes every provided layer, and states
precedence explicitly (P1 > P2 > P3 > P4). The hard-constraint checker is a
deterministic rule check: it flags a violation present in the response and passes
clean text. No LLM calls.
"""
from __future__ import annotations

from core.domo.prompts import HardConstraintChecker, PromptAssembler, PromptLayers
from core.domo.schemas import HumanFeedback, Issue, Severity


def _layers() -> PromptLayers:
    return PromptLayers(
        base="BASE_MARKER",
        user_prompt="USER_MARKER",
        human_feedback=[HumanFeedback(freeform="HUMAN_MARKER", ts="2024-01-01T00:00:00")],
        agent_feedback=[Issue(id="1", severity=Severity.WARN, ref="n", message="AGENT_MARKER")],
        hard_constraints=["NEVER_DO_THIS"],
    )


def test_assemble_includes_every_layer():
    out = PromptAssembler().assemble(_layers())
    for marker in ("BASE_MARKER", "USER_MARKER", "HUMAN_MARKER", "AGENT_MARKER", "NEVER_DO_THIS"):
        assert marker in out


def test_assemble_states_precedence_explicitly():
    out = PromptAssembler().assemble(_layers())
    # the contract is that precedence is declared in the prompt, not merely implied
    assert "P1" in out and "P4" in out
    assert "precedence" in out.lower()


def test_assemble_is_deterministic():
    layers = _layers()
    assert PromptAssembler().assemble(layers) == PromptAssembler().assemble(layers)


def test_hard_constraint_checker_flags_and_passes():
    chk = HardConstraintChecker()
    assert chk.check("the model leaked a SECRET token", ["SECRET"]) == ["SECRET"]
    assert chk.check("perfectly clean output", ["SECRET"]) == []
    assert chk.check("anything", []) == []


def test_no_hardcoded_inputs_divergent_fixtures():
    a = PromptAssembler().assemble(PromptLayers(base="ALPHA"))
    b = PromptAssembler().assemble(PromptLayers(base="BETA"))
    assert "ALPHA" in a and "BETA" in b and a != b   # output reflects the input layers
