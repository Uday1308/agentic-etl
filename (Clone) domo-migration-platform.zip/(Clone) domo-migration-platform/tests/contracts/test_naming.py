"""Identifier naming policy — one rule, applied by every emitter.

If the generated SQL and the ingested tables disagree about a column name, every
query fails. So the policy is set once and both emitters read it.
"""
from __future__ import annotations

import pytest

from core.domo.expr import translate
from core.domo.naming import (
    IdentifierPolicy,
    column,
    policy_from_args,
    quoted,
    set_policy,
    unquote,
)
from core.domo.tiles import q


@pytest.fixture(autouse=True)
def _reset():
    previous = set_policy(IdentifierPolicy())      # delta_safe by default
    yield
    set_policy(previous)


SAFE = IdentifierPolicy(mode="delta_safe")


# -- unquoting -------------------------------------------------------------- #

def test_pre_quoted_names_are_unwrapped_once():
    assert unquote("`Transaction No.`") == "Transaction No."
    assert unquote("  `Issuance Dept.`  ") == "Issuance Dept."
    assert unquote("Journal Batch Name") == "Journal Batch Name"


def test_doubled_backtick_escape_survives():
    assert unquote("`weird``name`") == "weird``name"


# -- preserve mode ---------------------------------------------------------- #

def test_delta_safe_is_the_default():
    """Sanitized is what actually runs: ingestion had to rename these columns to land
    them in Delta, so the generated SQL must reference the renamed form."""
    assert IdentifierPolicy().mode == "delta_safe"
    assert column("Journal Batch Name") == "Journal_Batch_Name"


def test_preserve_keeps_domo_names_verbatim():
    set_policy(IdentifierPolicy(mode="preserve"))
    assert column("Journal Batch Name") == "Journal Batch Name"
    assert quoted("Journal Batch Name") == "`Journal Batch Name`"


# -- delta_safe mode -------------------------------------------------------- #

def test_delta_invalid_characters_become_underscores():
    set_policy(SAFE)
    assert column("Journal Batch Name") == "Journal_Batch_Name"
    assert column("Debit Entered Amount") == "Debit_Entered_Amount"
    assert column("Amount (USD)") == "Amount_USD"


def test_repeats_collapse():
    set_policy(SAFE)
    assert column("Sub  Account   Code") == "Sub_Account_Code"


def test_domo_batch_columns_keep_their_own_underscores():
    """`_BATCH_ID_` is genuinely named that. Stripping the edges would point the SQL
    at a column that does not exist."""
    set_policy(SAFE)
    assert column("_BATCH_ID_") == "_BATCH_ID_"
    assert column("_BATCH_LAST_RUN_") == "_BATCH_LAST_RUN_"


def test_edge_separators_introduced_by_sanitizing_are_removed():
    set_policy(SAFE)
    assert column("Amount ") == "Amount"
    assert column("(Total)") == "Total"


def test_dots_are_kept_unless_you_say_otherwise():
    """Delta allows dots in a column name; some ingestions strip them anyway."""
    set_policy(SAFE)
    assert column("Transaction No.") == "Transaction_No."
    set_policy(IdentifierPolicy(mode="delta_safe", extra_chars="."))
    assert column("Transaction No.") == "Transaction_No"


def test_overrides_win_over_every_rule():
    set_policy(IdentifierPolicy(mode="delta_safe",
                                overrides={"Odd Legacy Name": "legacy_col_7"}))
    assert column("Odd Legacy Name") == "legacy_col_7"


def test_a_name_that_sanitizes_to_nothing_falls_back():
    set_policy(SAFE)
    assert column("()") == "()"


# -- both emitters agree ---------------------------------------------------- #

def test_tiles_and_expressions_use_the_same_policy():
    """The failure this prevents: a tile emits `Invoice_Amount` while an expression
    emits `Invoice Amount`, and the query fails on one of them."""
    set_policy(SAFE)
    assert q("Invoice Amount") == "`Invoice_Amount`"
    # `in`, not `==`: the contract is that BOTH sides sanitize the identifier the same
    # way, not how arithmetic happens to be wrapped (see the numeric-coercion tests).
    assert "`Invoice_Amount`" in translate("`Invoice Amount` + 1", dialect="sql").code


def test_switching_policy_switches_both():
    set_policy(IdentifierPolicy(mode="preserve"))
    assert q("Invoice Amount") == "`Invoice Amount`"
    assert "`Invoice Amount`" in translate("`Invoice Amount` + 1", dialect="sql").code
    set_policy(SAFE)
    assert q("Invoice Amount") == "`Invoice_Amount`"
    assert "`Invoice_Amount`" in translate("`Invoice Amount` + 1", dialect="sql").code


def test_pyspark_still_rewrites_dots_regardless_of_policy():
    """A dotted name is a struct path in PySpark — a language rule, not a preference."""
    set_policy(SAFE)
    assert "a__b" in translate("`a.b` + 1", dialect="pyspark").code


def test_unknown_mode_is_rejected():
    with pytest.raises(ValueError, match="unknown column mode"):
        policy_from_args("sanitise_everything")
