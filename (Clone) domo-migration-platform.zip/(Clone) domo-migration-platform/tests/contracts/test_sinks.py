"""Telemetry sinks: they must collect everything and never break a run."""
from __future__ import annotations

from core.contracts.judges import JudgeKind, JudgePanel, JudgeResult, Verdict
from core.contracts.telemetry import (
    DecisionKind,
    DecisionRow,
    IngestionRow,
    IngestPurpose,
    LlmCallRow,
    StepRow,
    StepStatus,
)
from core.contracts.validation import (
    BatchRef,
    Check,
    CheckStatus,
    DataflowParity,
    Diagnosis,
    FailureCategory,
    Metric,
    Severity,
    TargetParity,
)
from core.domo.sinks import DeltaSink, InMemorySink, RecordingObservability

TS = "2026-07-24T09:00:00Z"


def test_in_memory_sink_answers_the_observability_questions():
    s = InMemorySink()
    s.llm_call(LlmCallRow(run_id="r", ts=TS, call_id="c1", agent="md_plan", role="generator",
                          model="m", tokens_in=1000, tokens_out=400, cost_usd=0.12))
    s.llm_call(LlmCallRow(run_id="r", ts=TS, call_id="c2", agent="cd_codegen", role="evaluator",
                          model="m", tokens_in=500, tokens_out=100, cost_usd=0.03))
    s.ingestion(IngestionRow(run_id="r", ts=TS, dataset_id="d1", dataset_name="Feed",
                             purpose=IngestPurpose.CREATION, rows_ingested=1000))
    s.ingestion(IngestionRow(run_id="r", ts=TS, dataset_id="d2", dataset_name="Expected",
                             purpose=IngestPurpose.VALIDATION, rows_ingested=500))

    assert s.cost_by_agent() == {"md_plan": 0.12, "cd_codegen": 0.03}   # sorted desc
    assert s.tokens_by_agent()["md_plan"] == {"in": 1000, "out": 400, "calls": 1}
    assert ("Feed", "creation", 1000) in s.datasets_read()
    summary = s.summary("r", "8099")
    assert summary.tokens_total == 2000 and summary.datasets_validation == 1


def test_judge_panel_folds_into_rows():
    s = InMemorySink()
    panel = JudgePanel(agent="cd_codegen", iteration=2, results=(
        JudgeResult(rule_id="DET001", title="ordered aggs", kind=JudgeKind.DETERMINISM,
                    verdict=Verdict.FAIL, checked=1),
        JudgeResult(rule_id="STR001", title="sections", kind=JudgeKind.STRUCTURE,
                    verdict=Verdict.PASS, checked=9),
    ))
    s.judge_panel(panel, run_id="r")
    assert len(s.judges) == 2
    assert {j.rule_id for j in s.judge_failures()} == {"DET001"}
    assert s.judges[0].iteration == 2


def test_parity_folds_into_rows_with_batch_state_and_category():
    s = InMemorySink()
    t = TargetParity(
        target="Summary", table="cat.sch.summary",
        checks=(Check(metric=Metric.ROW_COUNT, status=CheckStatus.FAIL,
                      severity=Severity.BLOCKING, expected=18204, actual=17792),),
        expected_ref=BatchRef(dataset_id="d1", batch_id=7, batch_last_run=TS))
    parity = DataflowParity(dataflow_id="8099", targets=(t,))
    diag = Diagnosis(category=FailureCategory.EXPRESSION, owner_agent="md_plan",
                     nodes=("Summary",), explanation="filter drops rows")
    s.parity(parity, run_id="r", diagnoses=(diag,))

    row = s.validations[0]
    assert row.passed is False and row.blocking_failures == 1
    assert row.expected_batch_id == 7                 # evidence is defensible later
    assert row.failure_category == "expression" and row.owner_agent == "md_plan"


def test_recording_observability_prices_calls_at_write_time():
    """Rates are applied when the row is written so historical rows stay accurate
    when prices change."""
    s = InMemorySink()
    obs = RecordingObservability(s, run_id="r", rate_card={"gpt-oss": (0.001, 0.002)})

    class Row:
        agent, role, model, pool = "cd_codegen", "generator", "gpt-oss", "cd_translation"
        tokens_in, tokens_out, latency_ms, iteration, status = 1000, 500, 1200, 1, "ok"
        call_id, node, prompt_hash = "c1", "generate", "abc"

    obs.record_llm_call(Row())
    assert s.llm_calls[0].cost_usd == 0.002          # 1.0*0.001 + 0.5*0.002
    assert s.llm_calls[0].agent == "cd_codegen"


def test_recording_observability_tolerates_sparse_rows():
    """Different agents emit different fields; a missing one must not explode."""
    s = InMemorySink()
    obs = RecordingObservability(s, run_id="r")

    class Bare:
        pass

    obs.record_llm_call(Bare())
    obs.record_node(Bare())
    assert len(s.llm_calls) == 1 and len(s.steps) == 1
    assert s.llm_calls[0].cost_usd == 0.0


def test_delta_sink_never_raises_into_the_caller():
    """A dropped telemetry row is bad; a crashed migration because of one is worse."""
    class Broken:
        def createDataFrame(self, rows):
            raise RuntimeError("cluster gone")

    sink = DeltaSink(Broken(), "cat", "sch")
    sink.llm_call(LlmCallRow(run_id="r", ts=TS, call_id="c", agent="a", role="generator",
                             model="m"))
    sink.step(StepRow(run_id="r", ts=TS, step_id="s", agent="a", phase="p",
                      status=StepStatus.OK))
    assert len(sink.errors) == 2 and "cluster gone" in sink.errors[0]


def test_decisions_are_captured_for_the_deviation_report():
    s = InMemorySink()
    s.decision(DecisionRow(run_id="r", ts=TS, agent="md_plan", kind=DecisionKind.ISSUE_ACCEPTED,
                           actor="adarsh.a", issue_id="i1", rationale="null guard needed"))
    s.decision(DecisionRow(run_id="r", ts=TS, agent="md_plan",
                           kind=DecisionKind.CONSTRAINT_ADDED, actor="adarsh.a",
                           constraint="Never rename source columns"))
    summary = s.summary("r", "8099")
    assert summary.decisions == 2 and summary.issues_accepted == 1
    assert s.decisions[0].rationale == "null guard needed"
