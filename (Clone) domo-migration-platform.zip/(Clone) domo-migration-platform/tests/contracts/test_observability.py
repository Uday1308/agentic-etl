"""Contract tests for core.domo.observability (Core Development Guide §8).

Rows carry the required fields; the writer is an interface (ABC) so tests and other
components can inject a fake; the concrete Delta writer accepts the text-capture flag.
The deep text-vs-hash *persistence* behaviour belongs to the real Delta writer and is
asserted there (the placeholder is a no-op) — see the skipped test below.
"""
from __future__ import annotations

import pytest
from conftest import FakeObservability
from pydantic import ValidationError

from core.domo.observability import (
    DeltaObservabilityWriter,
    LlmCallRow,
    NodeRow,
    ObservabilityWriter,
)


def _llm_row(**over) -> LlmCallRow:
    base = dict(obs_run_id="o", thread_id="t", dataflow_id="df", agent="md_plan",
                node="generate", role="generator", model="m", pool="cd_translation",
                prompt_hash="abc123")
    base.update(over)
    return LlmCallRow(**base)


def test_rows_require_their_key_fields():
    _llm_row()                                   # all required present -> ok
    with pytest.raises(ValidationError):
        LlmCallRow(obs_run_id="o")               # missing most required fields
    NodeRow(obs_run_id="o", thread_id="t", agent="a", node="n")
    with pytest.raises(ValidationError):
        NodeRow(obs_run_id="o")                  # missing thread_id/agent/node


def test_writer_is_an_abstract_interface():
    with pytest.raises(TypeError):
        ObservabilityWriter()                    # cannot instantiate the ABC


def test_fake_writer_captures_calls():
    fake = FakeObservability()
    fake.record_llm_call(_llm_row())
    fake.record_node(NodeRow(obs_run_id="o", thread_id="t", agent="a", node="n"))
    assert len(fake.llm_calls) == 1 and len(fake.node_rows) == 1
    assert fake.llm_calls[0].role == "generator"


def test_concrete_writer_accepts_capture_flag():
    # both configurations must construct and accept rows without error (recording sink)
    for flag in (True, False):
        captured: list = []
        w = DeltaObservabilityWriter(capture_text=flag, sink=lambda t, r: captured.append((t, r)))
        w.record_llm_call(_llm_row())
        w.record_node(NodeRow(obs_run_id="o", thread_id="t", agent="a", node="n"))
        assert len(captured) == 2


def test_capture_flag_toggles_text_but_always_keeps_hash():
    """The redaction contract, tested through the sink seam — no Spark required.
    capture_text on -> full text persisted; off -> text blanked, hash retained."""
    row = _llm_row(prompt_text="secret prompt", response_text="secret response", prompt_hash="h123")

    kept: list = []
    DeltaObservabilityWriter(capture_text=True, sink=lambda t, r: kept.append(r)).record_llm_call(row)
    assert kept[0]["prompt_text"] == "secret prompt"
    assert kept[0]["response_text"] == "secret response"
    assert kept[0]["prompt_hash"] == "h123"

    hidden: list = []
    DeltaObservabilityWriter(capture_text=False, sink=lambda t, r: hidden.append(r)).record_llm_call(row)
    assert hidden[0]["prompt_text"] is None          # text redacted in prod mode
    assert hidden[0]["response_text"] is None
    assert hidden[0]["prompt_hash"] == "h123"        # hash always kept for correlation


def test_rows_routed_to_their_tables():
    routed: list = []
    w = DeltaObservabilityWriter(llm_table="obs_llm_calls", node_table="obs_nodes",
                                 sink=lambda t, r: routed.append(t))
    w.record_llm_call(_llm_row())
    w.record_node(NodeRow(obs_run_id="o", thread_id="t", agent="a", node="n"))
    assert routed == ["obs_llm_calls", "obs_nodes"]


def test_no_hardcoded_inputs_divergent_fixtures():
    a = _llm_row(role="generator", model="gen-endpoint", iteration=1)
    b = _llm_row(role="evaluator", model="eval-endpoint", iteration=4)
    assert (a.role, a.model, a.iteration) != (b.role, b.model, b.iteration)
