"""Contract tests for core.domo.state (Core Development Guide §5).

The reducers are the load-bearing logic: merge_by_index merges concurrent partials
without loss (never last-write-wins across indices), merge_feedback accumulates in
order per agent, and a RunState round-trips through the checkpoint serializer.
"""
from __future__ import annotations

from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

from core.domo.state import RunStatus, merge_by_index, merge_feedback


def test_merge_by_index_merges_without_loss():
    # partials arriving out of order must all survive, keyed by their index
    merged = merge_by_index({0: "a", 2: "c"}, {1: "b"})
    assert merged == {0: "a", 1: "b", 2: "c"}


def test_merge_by_index_updates_same_index_but_keeps_others():
    merged = merge_by_index({0: "a", 1: "b"}, {1: "B", 2: "c"})
    assert merged == {0: "a", 1: "B", 2: "c"}   # index 1 updated, 0 untouched, 2 added


def test_merge_by_index_handles_empty_sides():
    assert merge_by_index(None, {0: "x"}) == {0: "x"}
    assert merge_by_index({0: "x"}, None) == {0: "x"}


def test_merge_feedback_accumulates_in_order_per_agent():
    step1 = merge_feedback({}, {"md_plan": ["f1"]})
    step2 = merge_feedback(step1, {"md_plan": ["f2"]})
    assert step2["md_plan"] == ["f1", "f2"]          # order preserved, accumulated


def test_merge_feedback_keeps_agents_separate():
    merged = merge_feedback({"md_plan": ["a"]}, {"cd_codegen": ["b"]})
    assert merged == {"md_plan": ["a"], "cd_codegen": ["b"]}


def test_run_status_values():
    assert {s.value for s in RunStatus} == {"running", "awaiting_human", "failed", "done"}


def test_run_state_round_trips_through_checkpoint_serializer():
    serde = JsonPlusSerializer()
    state = {
        "thread_id": "t1", "dataflow_id": "8842", "environment": "dev",
        "status": RunStatus.RUNNING, "current_agent": "md_plan",
        "md_plan": {"iteration": 2}, "feedback": {"md_plan": []},
        "obs_run_id": "obs-1",
    }
    restored = serde.loads_typed(serde.dumps_typed(state))
    assert restored == state


def test_no_hardcoded_inputs_divergent_fixtures():
    # the reducers reflect their inputs, not baked-in constants
    assert merge_by_index({}, {5: "five"}) != merge_by_index({}, {6: "six"})
    assert merge_feedback({}, {"a": ["x"]}) != merge_feedback({}, {"b": ["y"]})
