"""The discovery row schema — one definition, shared by every reader and writer.

Before this contract existed the column aliasing was duplicated across the Spark
reader, the offline runner and the tile renderers. These tests exist to stop that
drifting apart again.
"""
from __future__ import annotations

import json

import pytest

from core.contracts.discovery import (
    DiscoveryRow,
    DiscoverySchemaError,
    NodeCategory,
    as_object,
    normalize_rows,
    resolve_columns,
    to_dataflow,
)

REAL = [
    {"discovery_run_id": "r2", "discovered_at": "2026-07-02", "record_type": "NODE",
     "dataflow_id": "8099", "node_id": "n1", "node_name": "Feed", "node_category": "SOURCE",
     "operation_type": "source", "properties": json.dumps({"datasetName": "NA | F&A | Feed"}),
     "input_node_ids": "[]", "is_disabled": "false"},
    {"discovery_run_id": "r2", "discovered_at": "2026-07-02", "record_type": "NODE",
     "dataflow_id": "8099", "node_id": "n2", "node_name": "Join Data 2",
     "node_category": "TRANSFORMATION", "operation_type": "join",
     "properties": json.dumps({"joinType": "LEFT OUTER"}),
     "input_node_ids": "WrappedArray(n1)", "is_disabled": "false"},
    {"discovery_run_id": "r2", "discovered_at": "2026-07-02", "record_type": "NODE",
     "dataflow_id": "8099", "node_id": "n3", "node_name": "Sink",
     "node_category": "TARGET", "operation_type": "sink", "properties": "{}",
     "input_node_ids": '["n2"]', "is_disabled": "false"},
    # older run — must not win
    {"discovery_run_id": "r1", "discovered_at": "2026-06-01", "record_type": "NODE",
     "dataflow_id": "8099", "node_id": "n1", "node_name": "STALE", "node_category": "SOURCE",
     "operation_type": "source", "properties": "{}", "input_node_ids": "[]",
     "is_disabled": "false"},
    # other dataflow — must be filtered out
    {"discovery_run_id": "r2", "discovered_at": "2026-07-02", "record_type": "NODE",
     "dataflow_id": "9999", "node_id": "z1", "node_name": "OTHER", "node_category": "SOURCE",
     "operation_type": "source", "properties": "{}", "input_node_ids": "[]",
     "is_disabled": "false"},
    {"discovery_run_id": "r2", "discovered_at": "2026-07-02", "record_type": "LINEAGE",
     "dataflow_id": "8099", "node_id": "", "node_name": "", "node_category": "",
     "operation_type": "", "properties": "", "input_node_ids": "",
     "from_node_id": "n1", "to_node_id": "n2", "is_disabled": "false"},
]


# -- column resolution ------------------------------------------------------ #

def test_resolves_canonical_and_aliased_columns():
    colmap = resolve_columns(["id", "type", "node_name", "config_json", "upstream"])
    assert colmap["node_id"] == "id" and colmap["operation_type"] == "type"
    assert colmap["properties"] == "config_json" and colmap["input_node_ids"] == "upstream"


def test_missing_required_column_names_what_was_present():
    with pytest.raises(DiscoverySchemaError, match="operation_type"):
        resolve_columns(["node_id", "node_name"])


def test_explicit_override_wins():
    colmap = resolve_columns(["nid", "tile"], {"node_id": "nid", "operation_type": "tile"})
    assert colmap["node_id"] == "nid" and colmap["operation_type"] == "tile"


def test_override_naming_an_absent_column_fails_loud():
    with pytest.raises(DiscoverySchemaError, match="not in the export"):
        resolve_columns(["node_id", "operation_type"], {"node_id": "nope"})


# -- value coercion --------------------------------------------------------- #

@pytest.mark.parametrize("raw,expected", [
    ('["a","b"]', ["a", "b"]),
    ("WrappedArray(a, b)", ["a", "b"]),
    ("List(a, b)", ["a", "b"]),
    ("a,b", ["a", "b"]),
    ("a", ["a"]),
    ("[]", []),
    ("null", []),
    (None, []),
])
def test_array_cells_from_csv_exports(raw, expected):
    assert as_object(raw, []) == expected


def test_json_properties_survive_pipes_and_quotes():
    payload = {"datasetName": "NA | F&A | CMS Rec | PROD", "note": "it's fine"}
    assert as_object(json.dumps(payload), {}) == payload


def test_unparseable_properties_degrade_to_empty_not_garbage():
    assert as_object("{not json", {}) == {}


# -- normalization ---------------------------------------------------------- #

def test_scopes_to_dataflow_and_newest_run():
    rows = normalize_rows(REAL, dataflow_id="8099")
    assert {r.node_id for r in rows if r.is_node} == {"n1", "n2", "n3"}
    assert all(r.discovery_run_id == "r2" for r in rows)
    assert not any(r.node_name == "STALE" for r in rows)
    assert not any(r.node_id == "z1" for r in rows)


def test_a_specific_run_can_be_pinned():
    rows = normalize_rows(REAL, dataflow_id="8099", run_id="r1")
    assert [r.node_name for r in rows] == ["STALE"]


def test_unknown_pinned_run_lists_the_available_ones():
    with pytest.raises(DiscoverySchemaError, match="r1"):
        normalize_rows(REAL, dataflow_id="8099", run_id="nope")


def test_category_falls_back_to_the_operation_type():
    """DOMO writes UNKNOWN in node_category often enough that the op type has to
    settle it — 'sink' is a target, 'source' is a source."""
    assert DiscoveryRow(node_category="UNKNOWN", operation_type="sink").category \
        is NodeCategory.TARGET
    assert DiscoveryRow(node_category="", operation_type="source").category \
        is NodeCategory.SOURCE
    assert DiscoveryRow(node_category="", operation_type="join").category \
        is NodeCategory.TRANSFORMATION


def test_stated_category_wins_over_the_operation_type():
    assert DiscoveryRow(node_category="TARGET", operation_type="join").category \
        is NodeCategory.TARGET


def test_unknown_columns_are_preserved_not_dropped():
    """A column added later must not be lost because this file is older."""
    row = DiscoveryRow(node_id="n1", operation_type="join", some_future_column="keep me")
    assert row.some_future_column == "keep me"


# -- folding into a dataflow ------------------------------------------------ #

def test_builds_nodes_and_edges_from_inline_inputs():
    doc = to_dataflow(normalize_rows(REAL, dataflow_id="8099"), "8099")
    assert [n["id"] for n in doc["nodes"]] == ["n1", "n2", "n3"]
    assert {"from": "n1", "to": "n2"} in doc["edges"]
    assert {"from": "n2", "to": "n3"} in doc["edges"]


def test_lineage_rows_do_not_duplicate_inline_edges():
    doc = to_dataflow(normalize_rows(REAL, dataflow_id="8099"), "8099")
    assert doc["edges"].count({"from": "n1", "to": "n2"}) == 1


def test_disabled_nodes_are_dropped_with_their_edges():
    """DOMO keeps disabled tiles in the export but does not run them; migrating one
    would change behaviour."""
    rows = [dict(r) for r in REAL if r["dataflow_id"] == "8099" and r["record_type"] == "NODE"
            and r["discovery_run_id"] == "r2"]
    rows[1]["is_disabled"] = "true"                    # disable the join
    doc = to_dataflow(normalize_rows(rows, dataflow_id="8099"), "8099")
    assert [n["id"] for n in doc["nodes"]] == ["n1", "n3"]
    assert all(e["from"] != "n2" and e["to"] != "n2" for e in doc["edges"])


def test_properties_reach_the_node_as_a_dict():
    doc = to_dataflow(normalize_rows(REAL, dataflow_id="8099"), "8099")
    src = next(n for n in doc["nodes"] if n["id"] == "n1")
    assert src["properties"]["datasetName"] == "NA | F&A | Feed"


def test_empty_export_fails_loud():
    with pytest.raises(DiscoverySchemaError, match="no rows"):
        normalize_rows([])


def test_the_offline_runner_and_the_spark_reader_agree():
    """Both paths must produce the same dataflow from the same rows — that is the
    whole point of the shared contract."""
    from agents.discovery.ports import SparkDiscoveryReader

    class FakeRow:
        def __init__(self, d):
            self._d = d

        def asDict(self, recursive=False):
            return self._d

    class FakeDF:
        def __init__(self, rows):
            self._rows = rows

        def where(self, _):
            return self

        def collect(self):
            return [FakeRow(r) for r in self._rows]

    class FakeSpark:
        def table(self, _):
            return FakeDF(REAL)

    via_spark = SparkDiscoveryReader("t", spark=FakeSpark()).read("8099")
    via_offline = to_dataflow(normalize_rows(REAL, dataflow_id="8099"), "8099")
    assert via_spark == via_offline
