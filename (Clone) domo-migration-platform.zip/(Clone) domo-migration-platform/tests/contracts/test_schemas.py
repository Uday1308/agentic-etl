"""Contract tests for core.domo.schemas (Core Development Guide §3).

Value objects: validation rejects bad/missing fields; immutables are frozen;
models round-trip losslessly through JSON (checkpoint serialisation).
"""
from __future__ import annotations

import pytest
from conftest import ts_iso  # noqa: F401  (kept for symmetry with other suites)
from pydantic import ValidationError

from core.domo.schemas import EvalResult, GenResult, HumanFeedback, Issue, Severity, Verdict


def test_eval_result_confidence_must_be_in_range():
    EvalResult(verdict=Verdict.PASS, confidence=0.0, summary="ok")
    EvalResult(verdict=Verdict.PASS, confidence=1.0, summary="ok")
    with pytest.raises(ValidationError):
        EvalResult(verdict=Verdict.PASS, confidence=1.5, summary="too high")
    with pytest.raises(ValidationError):
        EvalResult(verdict=Verdict.PASS, confidence=-0.1, summary="too low")


def test_missing_required_fields_rejected():
    with pytest.raises(ValidationError):
        EvalResult(confidence=0.5)                 # no verdict
    with pytest.raises(ValidationError):
        Issue(severity=Severity.WARN, ref="n", message="m")   # no id


def test_eval_result_passed_property():
    assert EvalResult(verdict=Verdict.PASS, confidence=0.9, summary="").passed is True
    assert EvalResult(verdict=Verdict.REVISE, confidence=0.9, summary="").passed is False
    assert EvalResult(verdict=Verdict.FAIL, confidence=0.9, summary="").passed is False


def test_value_objects_are_frozen():
    issue = Issue(id="1", severity=Severity.ERROR, ref="node:7", message="bad")
    with pytest.raises((ValidationError, TypeError)):
        issue.message = "changed"
    fb = HumanFeedback(freeform="looks good", ts="2024-01-01T00:00:00")
    with pytest.raises((ValidationError, TypeError)):
        fb.freeform = "changed"


def test_json_round_trip_is_lossless():
    ev = EvalResult(
        verdict=Verdict.REVISE, confidence=0.42, summary="needs work",
        issues=[Issue(id="i1", severity=Severity.WARN, ref="line:12",
                      message="rename", suggested_fix="use snake_case")],
    )
    assert EvalResult.model_validate_json(ev.model_dump_json()) == ev

    gen = GenResult(artifact="print('hi')", node_keys=["n1", "n2"], meta={"lang": "python"})
    assert GenResult.model_validate_json(gen.model_dump_json()) == gen


def test_no_hardcoded_inputs_divergent_fixtures():
    a = EvalResult(verdict=Verdict.PASS, confidence=0.10, summary="A")
    b = EvalResult(verdict=Verdict.FAIL, confidence=0.90, summary="B")
    assert (a.verdict, a.confidence, a.summary) != (b.verdict, b.confidence, b.summary)
    assert a.model_dump_json() != b.model_dump_json()
