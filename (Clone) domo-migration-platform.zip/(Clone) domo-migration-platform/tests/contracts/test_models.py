"""Contract tests for core.domo.models (Core Development Guide §6).

The registry resolves a role to an endpoint per environment, raises on an unknown
role/env, and a config change changes the resolved endpoint (no hardcoding).
"""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from core.domo.models import EndpointSpec, ModelRegistry, Role


def _registry() -> ModelRegistry:
    return ModelRegistry({
        "dev": {"generator": EndpointSpec(endpoint="dev-gen"),
                "evaluator": EndpointSpec(endpoint="dev-eval")},
        "prod": {"generator": EndpointSpec(endpoint="prod-gen"),
                 "evaluator": EndpointSpec(endpoint="prod-eval")},
    })


def test_resolves_role_per_environment():
    reg = _registry()
    assert reg.resolve(Role.GENERATOR, "dev").endpoint == "dev-gen"
    assert reg.resolve(Role.EVALUATOR, "dev").endpoint == "dev-eval"
    assert reg.resolve(Role.GENERATOR, "prod").endpoint == "prod-gen"


def test_unknown_role_or_env_raises():
    reg = _registry()
    with pytest.raises(KeyError):
        reg.resolve(Role.CLASSIFIER, "dev")     # role not bound
    with pytest.raises(KeyError):
        reg.resolve(Role.GENERATOR, "staging")  # env not bound


def test_endpoint_spec_is_frozen():
    spec = EndpointSpec(endpoint="x")
    with pytest.raises((ValidationError, TypeError)):
        spec.endpoint = "y"


def test_no_hardcoded_inputs_divergent_fixtures():
    """A config change must change the resolved endpoint — proof nothing is baked in."""
    reg_a = ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="endpoint-A")}})
    reg_b = ModelRegistry({"dev": {"generator": EndpointSpec(endpoint="endpoint-B")}})
    assert reg_a.resolve(Role.GENERATOR, "dev").endpoint == "endpoint-A"
    assert reg_b.resolve(Role.GENERATOR, "dev").endpoint == "endpoint-B"
