"""The DOMO expression transpiler — the deterministic core of the platform.

Fixtures are real expressions lifted from the cms_8099 plan, so a regression here is
a regression against production data.
"""
from __future__ import annotations

import pytest

from core.domo.expr import (
    Binary,
    Case,
    Col,
    DomoParseError,
    InList,
    PySparkEmitter,
    detect_functions,
    parse,
    tokenize,
    translate,
)

# -- tokenizer -------------------------------------------------------------- #

def test_tokenizes_backticked_columns_and_strings():
    toks = tokenize("`Period End Date` = 'CMS Worksheet'")
    assert toks[0].value == "Period End Date" and toks[2].value == "CMS Worksheet"


def test_doubled_quote_escape():
    assert tokenize("'it''s'")[0].value == "it's"


def test_block_comments_are_ignored():
    """DOMO users leave /* ... */ inside formulas — cms_8099 s55 does exactly this."""
    toks = tokenize("`a` /* WHEN x THEN y */ + 1")
    assert [t.value for t in toks if t.value] == ["a", "+", "1"]


def test_unterminated_column_is_a_clear_error():
    with pytest.raises(DomoParseError, match="unterminated column"):
        tokenize("`Never closed")


# -- parser ----------------------------------------------------------------- #

def test_operator_precedence_is_correct():
    """Regex translation gets this wrong; a real parser cannot."""
    ast = parse("1 + 2 * 3")
    assert isinstance(ast, Binary) and ast.op == "+"
    assert isinstance(ast.right, Binary) and ast.right.op == "*"


def test_and_binds_tighter_than_or():
    ast = parse("a = 1 OR b = 2 AND c = 3")
    assert ast.op == "OR" and ast.right.op == "AND"


def test_nested_case_parses():
    ast = parse("CASE WHEN a = 1 THEN CASE WHEN b = 2 THEN 'x' ELSE 'y' END ELSE 'z' END")
    assert isinstance(ast, Case) and isinstance(ast.whens[0][1], Case)


def test_simple_case_form_expands_to_comparisons():
    ast = parse("CASE `Currency` WHEN 'GBP' THEN 1 ELSE 0 END")
    cond = ast.whens[0][0]
    assert isinstance(cond, Binary) and cond.op == "=" and isinstance(cond.left, Col)


def test_case_without_when_is_rejected():
    with pytest.raises(DomoParseError, match="CASE with no WHEN"):
        parse("CASE ELSE 1 END")


def test_trailing_input_is_rejected_rather_than_silently_dropped():
    with pytest.raises(DomoParseError, match="trailing input"):
        parse("`a` + 1 garbage garbage")


def test_in_like_isnull_and_between():
    assert isinstance(parse("`m` IN (1,2,3)"), InList)
    assert parse("`d` NOT IN ('X')").negated is True
    assert parse("`d` LIKE '%FX%'").pattern.value == "%FX%"
    assert parse("`d` IS NOT NULL").negated is True
    assert parse("`n` BETWEEN 1 AND 5").op == "AND"


# -- emitter ---------------------------------------------------------------- #

#: The naming policy applies to BOTH dialects — PySpark reads the same sanitized
#: tables, so it must reference the same column names as the SQL path.
REAL = {
    "LAST_DAY(`Date`)": "F.last_day(F.col('Date'))",
    "MONTH(`Period End Date`)": "F.month(F.col('Period_End_Date'))",
    "`Invoice Amount` / `Exchange Rate`":
        "(F.col('Invoice_Amount') / F.col('Exchange_Rate'))",
}


@pytest.mark.parametrize("domo,expected", list(REAL.items()))
def test_real_expressions_emit_expected_pyspark(domo, expected):
    assert translate(domo).code == expected


def test_every_cms_8099_expression_resolves_deterministically():
    """The whole point: no model needed for DOMO's own vocabulary."""
    exprs = [
        "LAST_DAY(`Date`)",
        "MONTH(`Period End Date`)",
        "YEAR(`Period End Date`)",
        "'CMS Worksheet'",
        "IFNULL(`Debit Accounted Amount`,0)-IFNULL(`Credit Accounted Amount`,0)",
        "`CMS Matrix Amount`*-1",
        "IFNULL(`Amount`/`Oracle Exchange Rate`,0)",
        "CASE WHEN `Month Number` IN (1,2,3) THEN CONCAT(MONTHNAME(`Period End Date`),'-',"
        "LEFT(YEAR(`Period End Date`)-1,4)) ELSE CONCAT(MONTHNAME(`Period End Date`),'-',"
        "YEAR(`Period End Date`)) END",
        "CASE WHEN `_BATCH_ID_` = 2 THEN '2025-05-31' WHEN DAY(`_BATCH_LAST_RUN_`) >= 15 "
        "THEN LAST_DAY(`_BATCH_LAST_RUN_`) ELSE LAST_DAY(DATE_SUB(`_BATCH_LAST_RUN_`, "
        "INTERVAL 1 MONTH)) END",
        "CASE WHEN `Description` LIKE('%FX%') AND `Source` NOT IN ('GLOPIP') THEN "
        "'FX Current Month' ELSE `Source` END",
        "CASE WHEN `Currency` = 'GBP' THEN `Invoice Amount` * `Exchange Rate` "
        "ELSE `Invoice Amount` / `Exchange Rate` END",
    ]
    unresolved = [e for e in exprs if not translate(e).resolved]
    assert unresolved == [], f"{len(unresolved)} expressions needed a model"


def test_date_sub_with_interval_becomes_add_months():
    out = translate("DATE_SUB(`d`, INTERVAL 1 MONTH)")
    assert out.code == "F.add_months(F.col('d'), -1)"


def test_date_sub_with_plain_days():
    assert translate("DATE_SUB(`d`, 7)").code == "F.date_sub(F.col('d'), 7)"


def test_left_casts_before_substring():
    """LEFT(YEAR(x)-1, 4) must cast to string first or Spark returns null."""
    code = translate("LEFT(YEAR(`d`)-1,4)").code
    assert ".cast('string')" in code and "F.substring(" in code


def test_negative_multiplier_is_handled():
    assert translate("`Amount`*-1").code == "(F.col('Amount') * F.lit(-1))"


def test_not_in_is_negated_correctly():
    assert translate("`Source` NOT IN ('GLOPIP')").code.startswith("(~(")


def test_dotted_column_names_are_rewritten():
    """A dot is a struct path to Spark, so DOMO's dotted names become __."""
    assert "a__b" in translate("`a.b` + 1").code


# -- semantic caveats ------------------------------------------------------- #

def test_concat_null_semantics_are_flagged():
    """DOMO CONCAT ignores nulls; Spark returns null if any argument is null."""
    out = translate("CONCAT(`a`,'-',`b`)")
    assert out.resolved and any("CONCAT" in n for n in out.notes)
    assert out.confidence == "MEDIUM"


def test_division_semantics_are_flagged():
    assert any("integer division" in n for n in translate("`a` / `b`").notes)


def test_case_without_else_is_flagged():
    out = translate("CASE WHEN `a` = 1 THEN 'x' END")
    assert out.resolved and any("without ELSE" in n for n in out.notes)


def test_clean_expression_is_high_confidence():
    assert translate("LAST_DAY(`Date`)").confidence == "HIGH"


# -- escalation ------------------------------------------------------------- #

def test_unknown_function_escalates_precisely():
    """Only the genuinely unknown fragment goes to a model — and it is named."""
    out = translate("WEIRD_DOMO_FUNC(`a`, 2)")
    assert not out.resolved and out.unsupported == ["WEIRD_DOMO_FUNC"]
    assert out.confidence == "LOW" and out.code == ""


def test_parse_failure_never_half_translates():
    out = translate("CASE WHEN `a` THEN")
    assert not out.resolved and out.code == ""


def test_empty_expression_is_null_not_an_error():
    assert translate("   ").code == "F.lit(None)"


# -- metadata for the plan -------------------------------------------------- #

def test_columns_and_functions_are_reported():
    out = translate("CONCAT(MONTHNAME(`Period End Date`),'-',YEAR(`Period End Date`))")
    assert out.columns_used == {"Period End Date"}
    assert {"CONCAT", "MONTHNAME", "YEAR"} <= out.functions_used


def test_detect_functions_survives_unparseable_input():
    assert "LAST_DAY" in detect_functions("LAST_DAY(`a` +++")


def test_emitter_is_reusable_and_stateless_across_calls():
    em = PySparkEmitter()
    a = translate("MONTH(`x`)", emitter=em)
    b = translate("YEAR(`y`)", emitter=em)
    assert a.functions_used == {"MONTH"} and b.functions_used == {"YEAR"}


# -- SQL dialect ------------------------------------------------------------ #

#: Expected output uses the DEFAULT delta_safe policy: spaces become underscores,
#: because that is what ingestion had to do to land these columns in Delta.
SQL_REAL = {
    "LAST_DAY(`Date`)": "last_day(`Date`)",
    "MONTH(`Period End Date`)": "CAST(month(`Period_End_Date`) AS BIGINT)",
    # IFNULL with a NUMERIC default is not in this exact-match table: it is coerced,
    # and its expectation is built from numeric_operand() in
    # test_ifnull_with_a_numeric_default_coerces_its_column so the two cannot drift.
    "IFNULL(`a`,'')": "coalesce(`a`, '')",
    "`d` IS NOT NULL": "(`d` IS NOT NULL)",
    "`s` NOT IN ('X','Y')": "(`s` NOT IN ('X', 'Y'))",
    "`d` LIKE '%FX%'": "(`d` LIKE '%FX%')",
    "DATE_SUB(`d`, INTERVAL 1 MONTH)": "add_months(`d`, -1)",
}


@pytest.mark.parametrize("domo,expected", list(SQL_REAL.items()))
def test_sql_emits_expected(domo, expected):
    assert translate(domo, dialect="sql").code == expected


def test_sql_keeps_case_when_native():
    """SQL is a closer target than the DataFrame API: CASE WHEN passes through instead
    of becoming a method chain, so there is less to get wrong."""
    code = translate("CASE WHEN `a` = 1 THEN 'x' ELSE 'y' END", dialect="sql").code
    assert code == "(CASE WHEN (`a` = 1) THEN 'x' ELSE 'y' END)"


def test_sql_escapes_embedded_quotes():
    assert translate("'it''s'", dialect="sql").code == "'it''s'"


def test_sql_casts_before_left():
    """DOMO applies LEFT to numbers; SQL left() needs a string."""
    assert "cast(" in translate("LEFT(YEAR(`d`)-1,4)", dialect="sql").code


def test_sql_dotted_columns_keep_their_real_name():
    """A backticked `a.b` is one column name in SQL, not a struct path, so the dot is
    preserved. Renaming it would break parity against DOMO's own output — the table
    is configured with column mapping instead (see the assembler header).

    PySpark is different: there F.col('a.b') IS a struct path, so that emitter still
    rewrites the dot."""
    sql = translate("`a.b` + 1", dialect="sql").code
    assert "`a.b`" in sql and "a__b" not in sql        # the dot is legal and preserved
    assert "a__b" in translate("`a.b` + 1", dialect="pyspark").code


def test_every_cms_8099_expression_resolves_in_sql_too():
    exprs = [
        "LAST_DAY(`Date`)", "MONTH(`Period End Date`)", "YEAR(`Period End Date`)",
        "'CMS Worksheet'", "`CMS Matrix Amount`*-1",
        "IFNULL(`Debit Accounted Amount`,0)-IFNULL(`Credit Accounted Amount`,0)",
        "IFNULL(`Amount`/`Oracle Exchange Rate`,0)",
        "CASE WHEN `Month Number` IN (1,2,3) THEN CONCAT(MONTHNAME(`Period End Date`),'-',"
        "LEFT(YEAR(`Period End Date`)-1,4)) ELSE CONCAT(MONTHNAME(`Period End Date`),'-',"
        "YEAR(`Period End Date`)) END",
        "CASE WHEN `_BATCH_ID_` = 2 THEN '2025-05-31' WHEN DAY(`_BATCH_LAST_RUN_`) >= 15 "
        "THEN LAST_DAY(`_BATCH_LAST_RUN_`) ELSE LAST_DAY(DATE_SUB(`_BATCH_LAST_RUN_`, "
        "INTERVAL 1 MONTH)) END",
        "CASE WHEN `Description` LIKE('%FX%') AND `Source` NOT IN ('GLOPIP') THEN "
        "'FX Current Month' ELSE `Source` END",
        "CASE WHEN `Currency` = 'GBP' THEN `Invoice Amount` * `Exchange Rate` "
        "ELSE `Invoice Amount` / `Exchange Rate` END",
    ]
    unresolved = [e for e in exprs if not translate(e, dialect="sql").resolved]
    assert unresolved == []


def test_both_dialects_share_the_same_semantic_caveats():
    """One AST, one set of DOMO-vs-engine divergences. Notes must not drift."""
    py = translate("CONCAT(`a`,`b`)", dialect="pyspark")
    sql = translate("CONCAT(`a`,`b`)", dialect="sql")
    assert py.notes == sql.notes and py.confidence == sql.confidence == "MEDIUM"


def test_unknown_function_escalates_in_sql_too():
    out = translate("WEIRD_FN(`a`)", dialect="sql")
    assert not out.resolved and out.unsupported == ["WEIRD_FN"] and out.code == ""


def test_empty_expression_is_sql_null():
    assert translate("  ", dialect="sql").code == "NULL"


def test_unknown_dialect_is_rejected():
    with pytest.raises(ValueError, match="unknown dialect"):
        translate("`a`", dialect="tsql")

# --------------------------------------------------------------------------- #
# DOMO coerces text to number implicitly; Spark under ANSI refuses
# (DATATYPE_MISMATCH.BINARY_OP_WRONG_TYPE)
# --------------------------------------------------------------------------- #
def _sql(expr: str) -> str:
    from core.domo.expr import translate
    return translate(expr, dialect="sql").code


def test_a_column_divided_by_a_column_is_coerced_to_a_number():
    """A dynamic unpivot emits its value column as text whenever the columns it
    stacked were text, and nothing casts it unless DOMO happened to put an Alter
    Columns on that branch. ANSI then rejects the division outright."""
    from core.domo.expr import numeric_operand
    got = _sql("`Invoice Amount` / `Oracle Exchange Rate`")
    assert got == (f"({numeric_operand(chr(96) + 'Invoice_Amount' + chr(96))} / "
                   f"{numeric_operand(chr(96) + 'Oracle_Exchange_Rate' + chr(96))})")


def test_try_cast_not_cast_so_an_uncoercible_value_is_null_as_in_domo():
    """ANSI CAST raises on bad input; DOMO yields null. Null is the faithful answer,
    and a query that raises mid-run is the least useful outcome of the two."""
    assert "TRY_CAST" in _sql("`a` * `b`")
    assert "CAST(`a` AS DOUBLE)" not in _sql("`a` * `b`").replace("TRY_CAST", "")


def test_every_arithmetic_operator_coerces():
    for op in ("+", "-", "*", "/", "%"):
        assert _sql(f"`a` {op} `b`").count("TRY_CAST") == 2, op


def test_comparisons_are_not_coerced():
    """DOMO compares text as text; coercing here would change which rows match."""
    for op in ("=", "<>", ">", "<", ">=", "<="):
        assert "TRY_CAST" not in _sql(f"`a` {op} 'x'"), op


def test_only_bare_columns_are_wrapped():
    """A literal is already typed and a function result was coerced by whatever
    produced it — wrapping those adds noise without adding safety."""
    got = _sql("`a` * 2")
    assert got.count("TRY_CAST") == 1
    assert "TRY_CAST(2" not in got


def test_a_nested_expression_is_not_double_wrapped():
    got = _sql("(`a` / `b`) * `c`")
    assert got.count("TRY_CAST") == 3          # a, b, c — not the parenthesised result


def test_ifnull_with_a_numeric_default_coerces_its_column():
    """`IFNULL(x, 0)` asserts x is numeric; ANSI rejects coalesce(STRING, INT)."""
    from core.domo.expr import numeric_operand
    assert _sql("IFNULL(`amt`, 0)") ==         f"coalesce({numeric_operand(chr(96) + 'amt' + chr(96))}, 0)"


def test_the_coercion_strips_domos_leading_apostrophe_before_casting():
    """DOMO exports "'-92866.56". TRY_CAST of that is NULL — silently — so a plain
    cast would turn every such value into a null instead of a number."""
    got = _sql("`amt` * 2")
    assert "regexp_replace" in got
    assert got.index("regexp_replace") < got.index("AS DOUBLE")


def test_ifnull_with_a_text_default_assumes_nothing():
    assert _sql("IFNULL(`name`, '')") == "coalesce(`name`, '')"
    assert _sql("IFNULL(`name`, 'n/a')") == "coalesce(`name`, 'n/a')"


def test_coalesce_between_two_columns_is_left_alone():
    assert _sql("COALESCE(`a`,`b`)") == "coalesce(`a`, `b`)"


def test_the_coercion_is_called_out_as_a_caveat():
    from core.domo.expr import translate
    out = translate("`a` / `b`", dialect="sql")
    assert any("coerced to a number" in n for n in out.notes)
