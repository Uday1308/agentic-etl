"""Standardized-document contracts (core.contracts.standardized).

The shape here is the one the Standardization agent (2) writes and both Discovery (3)
and MD Plan (4) read, so a drift in either direction is a silent empty plan. The last
test in this file is the real one: it pins the fold against a checked-in DOMO export.
"""
from __future__ import annotations

import json
import pathlib

import pytest

from core.contracts.standardized import (
    StandardizedSchemaError,
    category_of,
    to_planner_dataflow,
    unwrap,
    validate_standardized,
)

REPO = pathlib.Path(__file__).resolve().parents[2]
EXPORT = REPO / "8099_standardized.json"


def flow(**over) -> dict:
    body = {
        "id": 8099,
        "name": "cms",
        "inputs": [{"dataSourceId": "in-1", "dataSourceName": "feed"}],
        "outputs": [{"dataSourceId": "out-1", "dataSourceName": "result"}],
        "actions": [
            {"id": "a1", "name": "src", "type": "source",
             "logic": {"datasetName": "feed", "dataSourceId": "in-1"}},
            {"id": "a2", "name": "Add Formula", "type": "formula",
             "logic": {"expressions": [{"outputColumn": "c", "expression": "UPPER(`a`)"}]}},
            {"id": "a3", "name": "result", "type": "sink",
             "logic": {"datasetName": "result", "versionChainType": "REPLACE"}},
        ],
        "connections": [{"from": "a1", "to": "a2"}, {"from": "a2", "to": "a3"}],
        "disabled_skipped": [],
    }
    body.update(over)
    return {"8099": body}


# --------------------------------------------------------------------------- #
# unwrap
# --------------------------------------------------------------------------- #
def test_unwrap_takes_the_single_entry_of_an_id_keyed_document():
    df_id, inner = unwrap(flow())
    assert df_id == "8099" and inner["name"] == "cms"


def test_unwrap_selects_by_dataflow_id_when_several_are_present():
    doc = {**flow(), "9000": {"actions": [], "connections": []}}
    assert unwrap(doc, "9000")[1] == {"actions": [], "connections": []}


def test_unwrap_refuses_to_guess_between_several_dataflows():
    doc = {**flow(), "9000": {"actions": [], "connections": []}}
    with pytest.raises(StandardizedSchemaError, match="pass dataflow_id"):
        unwrap(doc)


def test_unwrap_accepts_a_bare_dataflow_object():
    assert unwrap(flow()["8099"])[1]["name"] == "cms"


def test_unwrap_names_the_discovery_fold_when_handed_rows():
    """A discovery export is a list. It has its own fold; point at it."""
    with pytest.raises(StandardizedSchemaError, match="discovery"):
        unwrap([{"node_id": "a1"}])


def test_unwrap_reports_a_missing_dataflow_rather_than_returning_empty():
    with pytest.raises(StandardizedSchemaError, match="no entry for dataflow"):
        unwrap(flow(), "1234")


# --------------------------------------------------------------------------- #
# fold
# --------------------------------------------------------------------------- #
def test_actions_become_nodes_with_logic_carried_on_properties():
    out = to_planner_dataflow(flow())
    assert out["dataflow_id"] == "8099"
    assert [n["id"] for n in out["nodes"]] == ["a1", "a2", "a3"]
    formula = out["nodes"][1]
    assert formula["properties"]["expressions"][0]["expression"] == "UPPER(`a`)"
    assert formula["name"] == "Add Formula" and formula["type"] == "formula"


def test_categories_are_derived_from_the_tile_type():
    cats = [n["category"] for n in to_planner_dataflow(flow())["nodes"]]
    assert cats == ["SOURCE", "TRANSFORMATION", "TARGET"]
    assert category_of("SINK") == "TARGET" and category_of("Dataset") == "SOURCE"
    assert category_of("NormalizeAll") == "TRANSFORMATION"


def test_connections_become_edges():
    assert to_planner_dataflow(flow())["edges"] == [
        {"from": "a1", "to": "a2"}, {"from": "a2", "to": "a3"}]


def test_a_sink_gains_the_dataset_id_and_write_mode_it_needs():
    """The sink's own logic carries only a name; the id lives on the document's
    ``outputs``, and the renderer reads ``write_mode``, not ``versionChainType``."""
    sink = to_planner_dataflow(flow())["nodes"][2]
    assert sink["properties"]["dataSourceId"] == "out-1"
    assert sink["properties"]["write_mode"] == "REPLACE"


def test_disabled_tiles_and_the_edges_touching_them_are_dropped():
    doc = flow(disabled_skipped=["a2"])
    out = to_planner_dataflow(doc)
    assert [n["id"] for n in out["nodes"]] == ["a1", "a3"]
    assert out["edges"] == []          # both edges touched a2


def test_disabled_skipped_accepts_objects_as_well_as_ids():
    out = to_planner_dataflow(flow(disabled_skipped=[{"id": "a2"}]))
    assert [n["id"] for n in out["nodes"]] == ["a1", "a3"]


def test_an_already_folded_document_passes_through():
    """Discovery's to_dataflow() output and the planner fixtures are already folded;
    accepting both keeps one call site rather than two."""
    folded = {"dataflow_id": "8099", "nodes": [{"id": "n1"}], "edges": []}
    assert to_planner_dataflow(folded) == folded


def test_an_empty_action_list_is_an_error_not_an_empty_plan():
    with pytest.raises(StandardizedSchemaError, match="empty 'actions'"):
        to_planner_dataflow(flow(actions=[]))


def test_a_document_without_actions_names_the_keys_it_did_find():
    with pytest.raises(StandardizedSchemaError, match="missing"):
        to_planner_dataflow({"8099": {"id": 8099, "name": "cms", "inputs": []}})


def test_duplicate_action_ids_are_rejected():
    dupes = flow(actions=[{"id": "a1", "type": "filter", "logic": {}},
                          {"id": "a1", "type": "filter", "logic": {}}])
    with pytest.raises(StandardizedSchemaError, match="repeats action id"):
        to_planner_dataflow(dupes)


# --------------------------------------------------------------------------- #
# validate
# --------------------------------------------------------------------------- #
def test_a_faithful_document_has_no_problems():
    assert validate_standardized(flow(), raw=flow()) == []


def test_dropping_a_tile_is_counted_as_loss():
    lossy = flow(actions=flow()["8099"]["actions"][:2])
    assert any("action count changed" in p for p in validate_standardized(lossy, raw=flow()))


def test_a_tile_dropped_as_disabled_is_not_counted_as_loss():
    kept = flow(actions=flow()["8099"]["actions"][:2], disabled_skipped=["a3"])
    assert not [p for p in validate_standardized(kept, raw=flow())
                if "action count changed" in p]


def test_dangling_connections_are_reported():
    bad = flow(connections=[{"from": "a1", "to": "ghost"}])
    assert any("unknown action ids" in p for p in validate_standardized(bad))


def test_validate_returns_problems_rather_than_raising():
    """The agent's gate collects these alongside its evaluator's verdict."""
    assert validate_standardized([1, 2, 3]) != []


# --------------------------------------------------------------------------- #
# the real export
# --------------------------------------------------------------------------- #
@pytest.mark.skipif(not EXPORT.exists(), reason="checked-in DOMO export not present")
def test_the_real_export_folds_into_the_decomposition_discovery_produces():
    """Pinned against dataflow 8099. The discovery-table path independently yields
    10 sources / 55 transformations / 6 targets from the same dataflow, so these
    numbers are the agreement between the two upstreams — not just today's output.
    """
    doc = json.loads(EXPORT.read_text(encoding="utf-8"))
    assert validate_standardized(doc) == []

    out = to_planner_dataflow(doc, "8099")
    assert out["dataflow_id"] == "8099"
    assert len(out["nodes"]) == 71
    assert len(out["edges"]) == 81

    by_cat: dict[str, int] = {}
    for n in out["nodes"]:
        by_cat[n["category"]] = by_cat.get(n["category"], 0) + 1
    assert by_cat == {"SOURCE": 10, "TRANSFORMATION": 55, "TARGET": 6}

    # every tile keeps its payload — that is what the tile registry transpiles from
    assert all(isinstance(n["properties"], dict) for n in out["nodes"])
    formulas = [n for n in out["nodes"] if n["type"] == "formula"]
    assert len(formulas) == 14
    assert all(f["properties"].get("expressions") for f in formulas)
