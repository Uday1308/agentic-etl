"""Contract tests for core.domo.checkpoint (Core Development Guide §10).

Covers the Delta-audited checkpointer and the reader:
  * reads/writes delegate to the wrapped Postgres saver
  * one Delta audit row is appended per checkpoint put (the node boundary)
  * an audit failure never breaks the run (swallowed)
  * a re-run overwrites cleanly (idempotency) — no duplicate-key errors
  * RunStateReader projects the latest snapshot and status
  * NO HARDCODED INPUTS — each audit row carries its own thread_id

Postgres is stood in by LangGraph's in-process MemorySaver; Delta by a fake auditor.
"""
from __future__ import annotations

from conftest import cfg
from langgraph.checkpoint.memory import MemorySaver

from core.domo.checkpoint import DeltaAuditedCheckpointer, DeltaAuditor, RunStateReader
from core.domo.nodes import Evaluator, FeedbackApplier, Generator, build_gen_eval_hitl
from core.domo.schemas import EvalResult, GenResult, Verdict
from core.domo.state import RunStatus


# -- doubles ---------------------------------------------------------------- #
class FakeAuditor(DeltaAuditor):
    def __init__(self):
        self.rows: list[tuple[str, dict]] = []
    def append(self, thread_id: str, snapshot: dict) -> None:
        self.rows.append((thread_id, dict(snapshot)))


class FailingAuditor(DeltaAuditor):
    def append(self, thread_id: str, snapshot: dict) -> None:
        raise RuntimeError("delta is down")


class SpySaver(MemorySaver):
    """Wraps MemorySaver to record that reads were delegated to it."""
    def __init__(self):
        super().__init__()
        self.get_tuple_calls = 0
    def get_tuple(self, config):
        self.get_tuple_calls += 1
        return super().get_tuple(config)


class _Gen(Generator):
    async def generate(self, state, config):
        return GenResult(artifact="artifact-1")


class _Pass(Evaluator):
    async def evaluate(self, result, state):
        return EvalResult(verdict=Verdict.PASS, confidence=0.9, summary="ok")


class _Applier(FeedbackApplier):
    def apply(self, result, feedback):
        return result


def _one_node_graph(checkpointer):
    # evaluator=None, hitl=False, max_iters=1 -> a single generate node, one put
    return build_gen_eval_hitl(name="standardization", generator=_Gen(), evaluator=None,
                               feedback_applier=_Applier(), hitl=False, max_iters=1)\
        .compile(checkpointer=checkpointer)


# -- tests ------------------------------------------------------------------ #
async def test_audit_row_appended_and_snapshot_captured(obs):
    aud = FakeAuditor()
    ckpt = DeltaAuditedCheckpointer(MemorySaver(), aud)
    app = _one_node_graph(ckpt)
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="c1", observability=obs))

    assert len(aud.rows) >= 1                       # at least one audit row per run
    tids = {tid for tid, _ in aud.rows}
    assert tids == {"c1"}                            # keyed by this run's thread_id
    last_snapshot = aud.rows[-1][1]
    assert last_snapshot.get("standardization", {}).get("gen", {}).get("artifact") == "artifact-1"


async def test_reads_delegate_to_wrapped_saver(obs):
    spy = SpySaver()
    ckpt = DeltaAuditedCheckpointer(spy, FakeAuditor())
    app = _one_node_graph(ckpt)
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="c2", observability=obs))

    reader = RunStateReader(ckpt)
    before = spy.get_tuple_calls
    reader.snapshot("c2")
    assert spy.get_tuple_calls > before             # the read was delegated to the pg saver


async def test_audit_failure_is_swallowed(obs):
    ckpt = DeltaAuditedCheckpointer(MemorySaver(), FailingAuditor())
    app = _one_node_graph(ckpt)
    # a broken Delta must not break the run
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="c3", observability=obs))
    reader = RunStateReader(ckpt)
    assert reader.snapshot("c3").get("standardization", {}).get("gen") is not None


async def test_reader_projects_status(obs):
    ckpt = DeltaAuditedCheckpointer(MemorySaver(), FakeAuditor())
    app = _one_node_graph(ckpt)
    await app.ainvoke({"standardization": {}, "feedback": {}, "status": RunStatus.RUNNING},
                      cfg(thread_id="c4", observability=obs))
    reader = RunStateReader(ckpt)
    assert reader.status("c4") == RunStatus.RUNNING
    assert reader.status("does-not-exist") is None


async def test_rerun_is_idempotent(obs):
    ckpt = DeltaAuditedCheckpointer(MemorySaver(), FakeAuditor())
    app = _one_node_graph(ckpt)
    rc = cfg(thread_id="c5", observability=obs)
    await app.ainvoke({"standardization": {}, "feedback": {}}, rc)
    # re-running the same thread must not raise and must leave a coherent snapshot
    await app.ainvoke({"standardization": {}, "feedback": {}}, rc)
    reader = RunStateReader(ckpt)
    assert reader.snapshot("c5").get("standardization", {}).get("gen") is not None


async def test_no_hardcoded_inputs_divergent_fixtures(obs):
    aud = FakeAuditor()
    ckpt = DeltaAuditedCheckpointer(MemorySaver(), aud)
    app = _one_node_graph(ckpt)
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="alpha", observability=obs))
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="beta", observability=obs))
    seen = {tid for tid, _ in aud.rows}
    assert {"alpha", "beta"} <= seen        # each row carried its own thread_id, not a literal
