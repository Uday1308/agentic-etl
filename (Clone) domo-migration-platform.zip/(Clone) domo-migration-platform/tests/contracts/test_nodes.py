"""Contract tests for core.domo.nodes (Core Development Guide §12).

Covers the Node harness and the build_gen_eval_hitl loop:
  * harness returns a dict delta and emits exactly one NodeRow
  * sync and async run both work
  * in-place mutation is rejected
  * a failing run emits a 'failed' row and re-raises
  * a GraphInterrupt (HITL pause) propagates and is NOT recorded as a completion
  * the loop generates -> evaluates -> pauses resumably -> applies feedback -> regenerates
  * max_iters is enforced; iteration increments; feedback accumulates
  * NO HARDCODED INPUTS — the agent name and injected strategies flow through

LLM/Spark are not involved; strategies are trivial fakes.
"""
from __future__ import annotations

import pytest
from conftest import cfg, ts_iso
from langgraph.checkpoint.memory import MemorySaver
from langgraph.errors import GraphInterrupt
from langgraph.types import Command

from core.domo.nodes import Evaluator, FeedbackApplier, Generator, Node, build_gen_eval_hitl
from core.domo.schemas import EvalResult, GenResult, HumanFeedback, Verdict


# --------------------------------------------------------------------------- #
# Node harness
# --------------------------------------------------------------------------- #
async def test_harness_returns_delta_and_emits_one_row(obs):
    class N(Node):
        agent, name = "discovery", "discover"
        def run(self, state, config):
            return {"discovery": {"done": True}}

    out = await N()({"discovery": {}}, cfg(observability=obs))
    assert out == {"discovery": {"done": True}}
    assert len(obs.node_rows) == 1
    assert obs.node_rows[0].node == "discover" and obs.node_rows[0].status == "success"


async def test_async_run_is_awaited(obs):
    class N(Node):
        agent, name = "x", "async_node"
        async def run(self, state, config):
            return {"x": {"ok": 1}}

    out = await N()({"x": {}}, cfg(observability=obs))
    assert out == {"x": {"ok": 1}} and obs.node_rows[0].node == "async_node"


async def test_inplace_mutation_rejected(obs):
    class N(Node):
        agent, name = "x", "mutator"
        def run(self, state, config):
            state["sneaky"] = 1          # mutate the input in place -> contract violation
            return {}

    with pytest.raises(RuntimeError, match="mutated state in place"):
        await N()({"a": 1}, cfg(observability=obs))


async def test_non_dict_return_rejected(obs):
    class N(Node):
        agent, name = "x", "bad_return"
        def run(self, state, config):
            return ["not", "a", "dict"]

    with pytest.raises(TypeError):
        await N()({}, cfg(observability=obs))


async def test_failed_run_emits_failed_row_and_reraises(obs):
    class N(Node):
        agent, name = "x", "boom"
        def run(self, state, config):
            raise ValueError("kaboom")

    with pytest.raises(ValueError):
        await N()({}, cfg(observability=obs))
    assert len(obs.node_rows) == 1 and obs.node_rows[0].status == "failed"


async def test_graphinterrupt_propagates_without_completion_row(obs):
    class N(Node):
        agent, name = "x", "pauses"
        def run(self, state, config):
            raise GraphInterrupt("parking for human")   # HITL pause

    with pytest.raises(GraphInterrupt):
        await N()({}, cfg(observability=obs))
    assert obs.node_rows == []       # a pause is neither success nor failure


# --------------------------------------------------------------------------- #
# gen -> eval -> HITL loop
# --------------------------------------------------------------------------- #
class _Gen(Generator):
    def __init__(self, tag="v"):
        self.tag = tag
        self.calls = 0
    async def generate(self, state, config):
        self.calls += 1
        return GenResult(artifact=f"{self.tag}{self.calls}")


class _PassOnNth(Evaluator):
    """REVISE until the Nth iteration, then PASS — to exercise the regenerate loop."""
    def __init__(self, pass_on=2):
        self.pass_on = pass_on
        self.calls = 0
    async def evaluate(self, result, state):
        self.calls += 1
        v = Verdict.PASS if self.calls >= self.pass_on else Verdict.REVISE
        return EvalResult(verdict=v, confidence=0.8, summary="x")


class _AlwaysRevise(Evaluator):
    async def evaluate(self, result, state):
        return EvalResult(verdict=Verdict.REVISE, confidence=0.2, summary="never happy")


class _Applier(FeedbackApplier):
    def apply(self, result, feedback):
        assert all(isinstance(f, HumanFeedback) for f in feedback)   # typed history
        return GenResult(artifact=result.artifact + "+fb")


def _accept_resume():
    return Command(resume={"accepted_issue_ids": [], "rejected_issue_ids": [],
                           "freeform": "", "hard_constraints": [], "ts": ts_iso()})


def _revise_resume():
    return Command(resume={"accepted_issue_ids": [], "rejected_issue_ids": ["i1"],
                           "freeform": "please change X", "hard_constraints": [], "ts": ts_iso()})


async def test_eval_loop_regenerates_until_pass(obs):
    gen, ev = _Gen(), _PassOnNth(pass_on=2)
    app = build_gen_eval_hitl(name="standardization", generator=gen, evaluator=ev,
                              feedback_applier=_Applier(), hitl=False, max_iters=5)\
        .compile(checkpointer=MemorySaver())
    await app.ainvoke({"standardization": {}, "feedback": {}},
                      cfg(thread_id="s1", observability=obs))
    st = app.get_state(cfg(thread_id="s1", observability=obs))
    assert not st.next                      # completed (no pause without hitl)
    assert gen.calls == 2 and ev.calls == 2 # regenerated exactly once
    assert st.values["standardization"]["iteration"] == 2


async def test_max_iters_enforced(obs):
    gen = _Gen()
    app = build_gen_eval_hitl(name="standardization", generator=gen, evaluator=_AlwaysRevise(),
                              feedback_applier=_Applier(), hitl=False, max_iters=3)\
        .compile(checkpointer=MemorySaver())
    await app.ainvoke({"standardization": {}, "feedback": {}}, cfg(thread_id="s2", observability=obs))
    st = app.get_state(cfg(thread_id="s2", observability=obs))
    assert not st.next and st.values["standardization"]["iteration"] == 3   # stopped at the cap


async def test_hitl_pause_json_payload_and_resume_completes(obs):
    app = build_gen_eval_hitl(name="md_plan", generator=_Gen(), evaluator=_PassOnNth(pass_on=1),
                              feedback_applier=_Applier(), hitl=True, max_iters=3)\
        .compile(checkpointer=MemorySaver())
    rc = cfg(thread_id="h1", observability=obs)

    await app.ainvoke({"md_plan": {}, "feedback": {}}, rc)
    st = app.get_state(rc)
    assert st.next, "run should be parked awaiting human"
    payload = st.tasks[0].interrupts[0].value
    assert isinstance(payload["artifact"], dict)        # JSON-native, not a pydantic object
    assert payload["eval"]["verdict"] == "pass"

    await app.ainvoke(_accept_resume(), rc)             # accept -> should end
    st2 = app.get_state(rc)
    assert not st2.next
    assert len(st2.values["feedback"]["md_plan"]) == 1  # feedback accumulated


async def test_hitl_feedback_accumulates_over_iterations(obs):
    app = build_gen_eval_hitl(name="md_plan", generator=_Gen(), evaluator=_PassOnNth(pass_on=1),
                              feedback_applier=_Applier(), hitl=True, max_iters=5)\
        .compile(checkpointer=MemorySaver())
    rc = cfg(thread_id="h2", observability=obs)
    await app.ainvoke({"md_plan": {}, "feedback": {}}, rc)
    await app.ainvoke(_revise_resume(), rc)     # ask for changes -> regenerate -> pause again
    await app.ainvoke(_accept_resume(), rc)     # accept -> end
    st = app.get_state(rc)
    assert not st.next
    assert len(st.values["feedback"]["md_plan"]) == 2      # two rounds of feedback kept


async def test_no_hardcoded_inputs_divergent_fixtures(obs):
    """The agent name and the injected generator must flow through: two loops built
    with different names write under different state keys with different artifacts."""
    app_a = build_gen_eval_hitl(name="md_plan", generator=_Gen("A"), evaluator=_PassOnNth(1),
                                feedback_applier=_Applier(), hitl=False, max_iters=1)\
        .compile(checkpointer=MemorySaver())
    app_b = build_gen_eval_hitl(name="cd_codegen", generator=_Gen("B"), evaluator=_PassOnNth(1),
                                feedback_applier=_Applier(), hitl=False, max_iters=1)\
        .compile(checkpointer=MemorySaver())

    await app_a.ainvoke({"md_plan": {}, "feedback": {}}, cfg(thread_id="d1", observability=obs))
    await app_b.ainvoke({"cd_codegen": {}, "feedback": {}}, cfg(thread_id="d2", observability=obs))

    sa = app_a.get_state(cfg(thread_id="d1", observability=obs)).values
    sb = app_b.get_state(cfg(thread_id="d2", observability=obs)).values
    assert "md_plan" in sa and "cd_codegen" in sb        # stored under the given name, not a literal
    assert sa["md_plan"]["gen"]["artifact"] != sb["cd_codegen"]["gen"]["artifact"]
