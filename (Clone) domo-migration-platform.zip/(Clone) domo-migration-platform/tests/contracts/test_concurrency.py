"""Contract tests for core.domo.concurrency (Core Development Guide §7).

Concurrency never exceeds a pool cap or the global ceiling under load, and the
context manager always releases — even when the body raises.
"""
from __future__ import annotations

import asyncio

from core.domo.concurrency import ConcurrencyManager


async def _run_load(cm: ConcurrencyManager, pool: str, n: int, hold: float = 0.02) -> int:
    """Launch n tasks against one pool; return the peak observed concurrency."""
    live = 0
    peak = 0

    async def task():
        nonlocal live, peak
        async with cm.acquire(pool):
            live += 1
            peak = max(peak, live)
            await asyncio.sleep(hold)
            live -= 1

    await asyncio.gather(*(task() for _ in range(n)))
    return peak


async def test_pool_cap_is_never_exceeded():
    cm = ConcurrencyManager({"cd_translation": 3}, global_ceiling=100)
    peak = await _run_load(cm, "cd_translation", n=20)
    assert peak <= 3


async def test_global_ceiling_is_never_exceeded():
    # generous per-pool caps, but the global ceiling must dominate
    cm = ConcurrencyManager({"a": 10, "b": 10}, global_ceiling=4)
    live = 0
    peak = 0

    async def task(pool):
        nonlocal live, peak
        async with cm.acquire(pool):
            live += 1
            peak = max(peak, live)
            await asyncio.sleep(0.02)
            live -= 1

    await asyncio.gather(*(task("a" if i % 2 else "b") for i in range(24)))
    assert peak <= 4


async def test_context_manager_releases_on_exception():
    cm = ConcurrencyManager({"p": 1}, global_ceiling=10)

    class Boom(Exception):
        ...

    try:
        async with cm.acquire("p"):
            raise Boom()
    except Boom:
        pass

    # if the slot wasn't released, this second acquire would deadlock
    await asyncio.wait_for(_acquire_once(cm, "p"), timeout=1.0)


async def _acquire_once(cm: ConcurrencyManager, pool: str) -> None:
    async with cm.acquire(pool):
        return None


async def test_no_hardcoded_inputs_divergent_fixtures():
    # the cap comes from config: a cap of 1 serialises, a cap of 5 does not
    cm1 = ConcurrencyManager({"p": 1}, global_ceiling=100)
    cm5 = ConcurrencyManager({"p": 5}, global_ceiling=100)
    assert await _run_load(cm1, "p", n=10) == 1
    assert await _run_load(cm5, "p", n=10) > 1
