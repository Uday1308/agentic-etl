"""Contracts for accuracy, judges and telemetry — the three things the client report
and the observability dashboard both read from."""
from __future__ import annotations

import pytest

from core.contracts.judges import JudgeRegistry, Verdict
from core.contracts.telemetry import (
    DecisionKind,
    DecisionRow,
    IngestionRow,
    IngestPurpose,
    JudgeRow,
    LlmCallRow,
    StepRow,
    StepStatus,
    ValidationRow,
    summarize,
)
from core.contracts.validation import (
    BatchRef,
    Check,
    CheckStatus,
    DataflowParity,
    EstateParity,
    FailureCategory,
    Metric,
    Severity,
    TargetParity,
    compare,
)
from judges.rules import DEFAULT_JUDGES

TS = "2026-07-24T09:00:00Z"


class Subject:
    def __init__(self, artifact, node_ids=None, meta=None):
        self.artifact = artifact
        self.node_ids = node_ids or []
        self.meta = meta or {}


def _chk(metric, ok=True, col=None, sev=None):
    return Check(metric=metric, column=col,
                 status=CheckStatus.PASS if ok else CheckStatus.FAIL,
                 severity=sev or Severity.BLOCKING, expected=1, actual=1 if ok else 2)


# --------------------------------------------------------------------------- #
# accuracy arithmetic
# --------------------------------------------------------------------------- #

def test_row_count_alone_is_never_exact():
    """The failure that matters is right count, wrong values. A target that only
    compared row counts has not been validated."""
    t = TargetParity(target="T", table="c.s.t", checks=(_chk(Metric.ROW_COUNT),))
    assert t.passed          # nothing blocking failed
    assert not t.exact       # but no value-level check ran


def test_exact_requires_value_checks_to_pass():
    ok = TargetParity(target="T", table="c.s.t", checks=(
        _chk(Metric.ROW_COUNT), _chk(Metric.CHECKSUM), _chk(Metric.SUM, col="amt")))
    assert ok.exact and ok.passed

    bad = TargetParity(target="T", table="c.s.t", checks=(
        _chk(Metric.ROW_COUNT), _chk(Metric.CHECKSUM, ok=False)))
    assert not bad.exact and not bad.passed


def test_advisory_failure_does_not_block():
    """Float sum drift inside tolerance is advisory: recorded, not fatal."""
    t = TargetParity(target="T", table="c.s.t", checks=(
        _chk(Metric.CHECKSUM),
        _chk(Metric.SUM, ok=False, col="amt", sev=Severity.ADVISORY)))
    assert t.passed              # no blocking failure
    assert not t.exact           # but not a clean match either
    assert len(t.advisory_failures) == 1


def test_relative_tolerance_on_numeric_compare():
    c = compare(Metric.SUM, 1_000_000.0, 1_000_000.4, column="amt", tolerance=1e-6)
    assert c.status is CheckStatus.PASS
    tight = compare(Metric.SUM, 1_000_000.0, 1_000_000.4, column="amt", tolerance=1e-12)
    assert tight.status is CheckStatus.FAIL and tight.delta == pytest.approx(0.4)


def test_missing_measurement_is_skipped_not_failed():
    c = compare(Metric.DISTINCT_COUNT, None, 12, column="co")
    assert c.status is CheckStatus.SKIPPED and not c.failed


def test_dataflow_needs_every_target_to_pass():
    good = TargetParity(target="A", table="t", checks=(_chk(Metric.CHECKSUM),))
    bad = TargetParity(target="B", table="t", checks=(_chk(Metric.CHECKSUM, ok=False),))
    assert not DataflowParity(dataflow_id="8099", targets=(good, bad)).passed
    assert DataflowParity(dataflow_id="8099", targets=(good,)).passed


def test_estate_reports_both_numbers():
    """One number alone misleads, so headline() always carries both."""
    exact = DataflowParity(dataflow_id="1", targets=(
        TargetParity(target="A", table="t", checks=(_chk(Metric.CHECKSUM),)),))
    partial = DataflowParity(dataflow_id="2", targets=(
        TargetParity(target="B", table="t", checks=(
            _chk(Metric.CHECKSUM), _chk(Metric.SUM, ok=False, sev=Severity.ADVISORY))),))
    h = EstateParity(dataflows=(exact, partial)).headline()
    assert h["dataflows_passed"] == 2      # both pass (advisory only)
    assert h["dataflows_exact"] == 1       # but only one is clean
    assert 0 < h["check_pass_rate"] < 1


def test_error_target_never_passes():
    t = TargetParity(target="T", table="t", error="comparison could not run")
    assert not t.passed and not t.exact


def test_batch_ref_is_carried_on_parity():
    """A parity result without batch state cannot be defended later."""
    t = TargetParity(target="T", table="t", checks=(_chk(Metric.CHECKSUM),),
                     expected_ref=BatchRef(dataset_id="d1", batch_id=7,
                                           batch_last_run=TS, row_count=18204))
    assert t.expected_ref.batch_id == 7 and t.expected_ref.row_count == 18204


# --------------------------------------------------------------------------- #
# judges
# --------------------------------------------------------------------------- #

@pytest.fixture
def registry():
    return JudgeRegistry(list(DEFAULT_JUDGES))


def _fires(registry, rule_id, artifact, **kw):
    panel = registry.run("cd_codegen", Subject(artifact, **kw))
    hit = next(r for r in panel.results if r.rule_id == rule_id)
    return hit


def test_det001_catches_unordered_first(registry):
    """cms_8099 s11: F.first() with no ordering is non-deterministic in Spark."""
    art = ("# [node: s11] op=AGG origin=md\n"
           "df_s11 = src.groupBy('k').agg(F.first(F.col('rate')).alias('rate'))\n"
           "# [/node: s11]\n")
    r = _fires(registry, "DET001", art)
    assert r.verdict is Verdict.FAIL and r.findings[0].node == "s11"


def test_det001_passes_when_ordered(registry):
    art = ("# [node: s11] op=AGG origin=md\n"
           "w = Window.partitionBy('k').orderBy('seq')\n"
           "df_s11 = src.withColumn('rate', F.first('rate').over(w))\n"
           "# [/node: s11]\n")
    assert _fires(registry, "DET001", art).verdict is Verdict.PASS


def test_sem001_catches_bare_decimal_cast(registry):
    """DecimalType() defaults to (10,0) and truncates the decimals DOMO kept."""
    art = ("# [node: s13] op=ALTER origin=md\n"
           "df_s13 = src.withColumn('amt', F.col('amt').cast(DecimalType()))\n"
           "# [/node: s13]\n")
    assert _fires(registry, "SEM001", art).verdict is Verdict.FAIL


def test_sem001_passes_with_precision(registry):
    art = ("# [node: s13] op=ALTER origin=md\n"
           "df_s13 = src.withColumn('amt', F.col('amt').cast(DecimalType(18, 2)))\n"
           "# [/node: s13]\n")
    assert _fires(registry, "SEM001", art).verdict is Verdict.PASS


def test_sem003_catches_hardcoded_batch_patch(registry):
    """cms_8099 s09 pins _BATCH_ID_ = 2 to a literal date. Batch ids renumber on
    re-ingestion, so this silently attaches to the wrong batch."""
    art = ("# [node: s09] op=FORMULA origin=md\n"
           "df_s09 = src.withColumn('Period End Date',\n"
           "    F.when((F.col('_BATCH_ID_') == F.lit(2)), F.lit('2025-05-31')))\n"
           "# [/node: s09]\n")
    r = _fires(registry, "SEM003", art)
    assert r.verdict is Verdict.FAIL and r.findings[0].node == "s09"


def test_sem003_catches_sql_form(registry):
    art = ("# [node: s09] op=FORMULA origin=md\n"
           "CASE WHEN _BATCH_ID_ = 2 THEN '2025-05-31' ELSE LAST_DAY(dt) END\n"
           "# [/node: s09]\n")
    assert _fires(registry, "SEM003", art).verdict is Verdict.FAIL


def test_sem002_warns_on_batch_metadata_unless_declared(registry):
    art = ("# [node: s20] op=FILTER origin=md\n"
           "df_s20 = src.filter(F.col('_BATCH_LAST_RUN_') != '2026-03-30T14:18:07')\n"
           "# [/node: s20]\n")
    assert _fires(registry, "SEM002", art).verdict is Verdict.WARN
    declared = _fires(registry, "SEM002", art,
                      meta={"batch_metadata_contract": ["_BATCH_LAST_RUN_"]})
    assert declared.verdict is Verdict.PASS


def test_str003_catches_unresolved_slot(registry):
    art = "# [node: s01] op=FORMULA origin=ai\ndf = src.withColumn('x', __PENDING_3__)\n# [/node: s01]\n"
    assert _fires(registry, "STR003", art).verdict is Verdict.FAIL


def test_str001_catches_unclosed_section(registry):
    art = "# [node: s01] op=X origin=md\ndf_a = 1\n"          # never closed
    assert _fires(registry, "STR001", art).verdict is Verdict.FAIL


def test_str001_catches_duplicate_node_ids(registry):
    art = ("# [node: s01] op=X origin=md\na = 1\n# [/node: s01]\n"
           "# [node: s01] op=X origin=md\nb = 2\n# [/node: s01]\n")
    r = _fires(registry, "STR001", art)
    assert r.verdict is Verdict.FAIL and "duplicate" in r.findings[0].message


def test_str002_catches_dropped_node(registry):
    art = "# [node: s01] op=X origin=md\na = 1\n# [/node: s01]\n"
    r = _fires(registry, "STR002", art, node_ids=["s01", "s02"])
    assert r.verdict is Verdict.FAIL and r.findings[0].node == "s02"


def test_pol001_catches_credential_literal(registry):
    art = "# [node: s01] op=SOURCE origin=md\nconn = 'password=hunter2xyz'\n# [/node: s01]\n"
    assert _fires(registry, "POL001", art).verdict is Verdict.FAIL


def test_clean_artifact_passes_every_judge(registry):
    art = (
        "# [node: src_df] op=SOURCE origin=md\n"
        "src_df = spark.read.table('cat.bronze.src')\n"
        "# [/node: src_df]\n\n"
        "# [node: df_agg_s01] op=AGGREGATE origin=md\n"
        "df_agg_s01 = src_df.groupBy('co').agg(F.sum('amt').alias('amt'))\n"
        "# [/node: df_agg_s01]\n"
    )
    panel = registry.run("cd_codegen", Subject(art, node_ids=["src_df", "df_agg_s01"]))
    assert panel.pass_rate == 1.0 and not panel.blocking


def test_judge_registry_rejects_duplicate_rule_ids():
    from judges.rules import NodeAddressable
    reg = JudgeRegistry([NodeAddressable()])
    with pytest.raises(ValueError, match="duplicate"):
        reg.register(NodeAddressable())


def test_broken_judge_warns_instead_of_breaking_the_run(registry):
    from core.contracts.judges import Judge, JudgeKind

    class Exploding(Judge):
        rule_id, title, kind = "ZZZ999", "explodes", JudgeKind.STRUCTURE

        def run(self, subject):
            raise RuntimeError("boom")

    registry.register(Exploding())
    panel = registry.run("cd_codegen", Subject("# [node: a] x\ncode\n# [/node: a]\n"))
    bad = next(r for r in panel.results if r.rule_id == "ZZZ999")
    assert bad.verdict is Verdict.WARN and "boom" in bad.note
    assert not panel.blocking          # a broken judge must not block the pipeline


def test_panel_summary_shape(registry):
    art = "# [node: s11] op=AGG origin=md\ndf = s.groupBy('k').agg(F.first('r'))\n# [/node: s11]\n"
    s = registry.run("cd_codegen", Subject(art), iteration=2).summary()
    assert s["iteration"] == 2 and "DET001" in s["failed_rules"] and 0 <= s["pass_rate"] <= 1


# --------------------------------------------------------------------------- #
# telemetry
# --------------------------------------------------------------------------- #

def test_summarize_folds_every_stream():
    llm = [LlmCallRow(run_id="r", ts=TS, call_id="c1", agent="md_plan", role="generator",
                      model="m", tokens_in=1000, tokens_out=400, cost_usd=0.12),
           LlmCallRow(run_id="r", ts=TS, call_id="c2", agent="cd_codegen", role="evaluator",
                      model="m", tokens_in=800, tokens_out=100, cost_usd=0.05)]
    steps = [StepRow(run_id="r", ts=TS, step_id="s1", agent="md_plan", phase="Understanding tiles",
                     status=StepStatus.OK),
             StepRow(run_id="r", ts=TS, step_id="s2", agent="md_plan", phase="Evaluating",
                     status=StepStatus.OK, iteration=2),
             StepRow(run_id="r", ts=TS, step_id="s3", agent="cd_codegen", phase="Assembling",
                     status=StepStatus.OK)]
    ingest = [IngestionRow(run_id="r", ts=TS, dataset_id="d1", purpose=IngestPurpose.CREATION,
                           rows_ingested=1000, domo_row_count=1000),
              IngestionRow(run_id="r", ts=TS, dataset_id="d2", purpose=IngestPurpose.VALIDATION,
                           rows_ingested=500, domo_row_count=500)]
    judged = [JudgeRow(run_id="r", ts=TS, agent="cd_codegen", rule_id="DET001", verdict="pass"),
              JudgeRow(run_id="r", ts=TS, agent="cd_codegen", rule_id="SEM001", verdict="fail")]
    validated = [ValidationRow(run_id="r", ts=TS, dataflow_id="8099", target="A",
                               checks_run=6, checks_passed=6, exact=True, passed=True),
                 ValidationRow(run_id="r", ts=TS, dataflow_id="8099", target="B",
                               checks_run=6, checks_passed=5, blocking_failures=1)]
    decisions = [DecisionRow(run_id="r", ts=TS, agent="cd_codegen",
                             kind=DecisionKind.ISSUE_ACCEPTED, actor="adarsh.a"),
                 DecisionRow(run_id="r", ts=TS, agent="cd_codegen",
                             kind=DecisionKind.ISSUE_REJECTED, actor="adarsh.a")]

    s = summarize("r", "8099", llm=llm, steps=steps, ingest=ingest,
                  judged=judged, validated=validated, decisions=decisions)

    assert s.llm_calls == 2 and s.tokens_total == 2300 and s.cost_usd == pytest.approx(0.17)
    assert s.datasets_creation == 1 and s.datasets_validation == 1
    assert s.judge_pass_rate == 0.5 and s.judges_failed == 1
    assert s.targets_total == 2 and s.targets_exact == 1 and s.validation_pass_rate == 0.5
    assert s.issues_accepted == 1 and s.issues_rejected == 1
    assert s.cost_per_target == pytest.approx(0.085)


def test_rework_is_visible_in_the_summary():
    """More (agent, iteration) pairs than agents means something went round again."""
    steps = [StepRow(run_id="r", ts=TS, step_id=f"s{i}", agent="md_plan", phase="p",
                     status=StepStatus.OK, iteration=i) for i in (1, 2, 3)]
    s = summarize("r", "8099", steps=steps)
    assert s.agents_completed == 1 and s.iterations_total == 3 and s.reworked


def test_ingestion_row_flags_count_mismatch():
    ok = IngestionRow(run_id="r", ts=TS, dataset_id="d", purpose=IngestPurpose.CREATION,
                      rows_ingested=100, domo_row_count=100)
    bad = IngestionRow(run_id="r", ts=TS, dataset_id="d", purpose=IngestPurpose.CREATION,
                       rows_ingested=98, domo_row_count=100)
    unknown = IngestionRow(run_id="r", ts=TS, dataset_id="d", purpose=IngestPurpose.CREATION,
                           rows_ingested=98)
    assert ok.count_matches is True and bad.count_matches is False
    assert unknown.count_matches is None


def test_step_progress_is_derivable_for_the_ui():
    s = StepRow(run_id="r", ts=TS, step_id="s", agent="md_plan",
                phase="Context engineering", phase_index=1, phase_count=5)
    assert s.progress == pytest.approx(0.4)


def test_telemetry_rows_are_immutable():
    row = LlmCallRow(run_id="r", ts=TS, call_id="c", agent="a", role="generator", model="m")
    with pytest.raises(Exception):
        row.tokens_in = 5


def test_failure_category_routes_to_an_owner():
    from core.contracts.validation import Diagnosis
    d = Diagnosis(category=FailureCategory.EXPRESSION, owner_agent="md_plan",
                  nodes=("s54",), explanation="null guard dropped", confidence=0.8)
    assert d.category is FailureCategory.EXPRESSION and d.owner_agent == "md_plan"
