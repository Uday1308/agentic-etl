"""The master pipeline: order, gates and the phase vocabulary the UI renders."""
from __future__ import annotations

import pytest

from agents.master import AGENT_DEFAULTS, AGENT_ORDER, AGENT_PHASES, MasterPipeline, Stage


def _all_stages():
    return [Stage(agent=a, runner=object(), **{k: v for k, v in AGENT_DEFAULTS[a].items()})
            for a in AGENT_ORDER]


def test_seven_agents_in_blueprint_order():
    p = MasterPipeline(_all_stages())
    assert [s.agent for s in p.stages] == list(AGENT_ORDER)
    assert len(p.stages) == 7


def test_stages_sort_into_order_regardless_of_input_order():
    shuffled = list(reversed(_all_stages()))
    assert [s.agent for s in MasterPipeline(shuffled).stages] == list(AGENT_ORDER)


def test_unknown_agent_is_rejected():
    with pytest.raises(ValueError, match="unknown agents"):
        MasterPipeline([Stage(agent="not_an_agent", runner=object())])


def test_hitl_gates_match_the_blueprint():
    gates = MasterPipeline(_all_stages()).hitl_gates
    assert gates == ["discovery", "md_plan", "cd_codegen", "validation", "classifier"]


def test_agents_without_ai_are_declared_as_such():
    """Connection and Discovery are deterministic by contract — no model at all."""
    assert AGENT_DEFAULTS["connection"]["ai_gen"] is False
    assert AGENT_DEFAULTS["discovery"]["ai_gen"] is False


def test_next_after_walks_the_pipeline():
    p = MasterPipeline(_all_stages())
    assert p.next_after("md_plan").agent == "cd_codegen"
    assert p.next_after("classifier") is None
    assert p.next_after("nope") is None


def test_a_subset_pipeline_is_valid():
    """A caller can run discovery -> codegen without rebuilding the graph."""
    subset = [s for s in _all_stages() if s.agent in ("discovery", "md_plan", "cd_codegen")]
    p = MasterPipeline(subset)
    assert [s.agent for s in p.stages] == ["discovery", "md_plan", "cd_codegen"]
    assert p.next_after("cd_codegen") is None


def test_every_agent_declares_its_phase_vocabulary():
    """The UI renders these verbatim; it never guesses what an agent is doing."""
    for agent in AGENT_ORDER:
        assert AGENT_PHASES.get(agent), f"{agent} has no declared phases"
        assert all(isinstance(p, str) and p for p in AGENT_PHASES[agent])


def test_stage_exposes_its_phases():
    p = MasterPipeline(_all_stages())
    assert "Context engineering" in p.stage("md_plan").phases
    assert "Waiting for the pipeline" in p.stage("validation").phases


def test_describe_is_serializable_for_the_frontend():
    rows = MasterPipeline(_all_stages()).describe()
    assert len(rows) == 7
    assert set(rows[0]) == {"agent", "ai_gen", "ai_review", "hitl", "phases"}
