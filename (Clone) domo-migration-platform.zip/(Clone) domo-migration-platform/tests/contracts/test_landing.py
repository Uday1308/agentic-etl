"""Landing-normalization contracts (core.contracts.landing).

DOMO's export writes a leading apostrophe on some values; DOMO's own output does not
carry it through. Landing the raw export and reading it as-is therefore produces a
migrated table that differs from DOMO on every affected row — invisibly, until
something casts it. These tests pin the one definition of that cleanup.
"""
from __future__ import annotations

import pytest

from core.contracts.landing import (
    LEADING_APOSTROPHE,
    artifact_audit_sql,
    normalize_select_sql,
    strip_artifacts_sql,
)

COLS = {"Supplier": "string", "Invoice_Amount": "string",
        "Batch_Id": "bigint", "Due_Date": "date"}


# --------------------------------------------------------------------------- #
# the SQL form
# --------------------------------------------------------------------------- #
def test_a_text_column_is_stripped():
    assert strip_artifacts_sql("`x`") == "regexp_replace(`x`, \"^'\", '')"


def test_only_a_LEADING_apostrophe_is_anchored():
    """An apostrophe inside a value is data — a supplier called O'Brien keeps it."""
    assert LEADING_APOSTROPHE.startswith("^")


def test_the_select_strips_text_columns_and_leaves_the_others_alone():
    sql = normalize_select_sql("cat.sch.tbl", COLS)
    assert "regexp_replace(`Supplier`" in sql
    assert "regexp_replace(`Invoice_Amount`" in sql
    assert "regexp_replace(`Batch_Id`" not in sql      # a bigint cannot carry it
    assert "regexp_replace(`Due_Date`" not in sql
    assert sql.rstrip().endswith("FROM cat.sch.tbl")


def test_every_column_survives_the_projection():
    """Naming columns to strip them is exactly how a column gets accidentally dropped."""
    sql = normalize_select_sql("t", COLS)
    for name in COLS:
        assert f"`{name}`" in sql
    assert sql.count(" AS `") == 2                     # only the two text columns aliased


def test_a_backtick_in_a_column_name_is_escaped():
    sql = normalize_select_sql("t", {"we`ird": "string"})
    assert "`we``ird`" in sql


def test_no_columns_fails_loud_rather_than_emitting_select_star():
    """`SELECT *` cannot strip anything. Silently emitting it would land the artifact
    while looking like it had been handled."""
    with pytest.raises(ValueError, match="schema is required"):
        normalize_select_sql("t", {})


# --------------------------------------------------------------------------- #
# the audit
# --------------------------------------------------------------------------- #
def test_the_audit_counts_only_text_columns():
    sql = artifact_audit_sql("t", COLS)
    assert "`Supplier`" in sql and "`Invoice_Amount`" in sql
    assert "`Batch_Id`" not in sql
    assert sql.count("SUM(CASE WHEN") == 2


def test_a_table_with_no_text_columns_cannot_be_audited():
    with pytest.raises(ValueError, match="no string columns"):
        artifact_audit_sql("t", {"n": "bigint"})


# --------------------------------------------------------------------------- #
# one definition, shared with the expression emitter
# --------------------------------------------------------------------------- #
def test_the_emitter_uses_this_modules_definition():
    """Six sites work around this artifact. They must not each carry their own rule —
    that is the drift that produced the op_type bug earlier in this codebase."""
    from core.domo.expr import numeric_operand
    assert LEADING_APOSTROPHE in numeric_operand("`x`")


# --------------------------------------------------------------------------- #
# against a real Spark session
# --------------------------------------------------------------------------- #
pytest.importorskip("pyspark.sql", reason="pyspark not installed")


@pytest.fixture(scope="module")
def spark():
    """A local session, or skip. These run for real on a cluster; a dev box wired for
    Spark Connect (no local master) skips them rather than reporting a false failure."""
    try:
        from pyspark.sql import SparkSession
        s = (SparkSession.builder.master("local[1]").appName("landing-test")
             .config("spark.ui.enabled", "false")
             .config("spark.sql.shuffle.partitions", "1").getOrCreate())
    except Exception as exc:                                  # noqa: BLE001
        pytest.skip(f"no local Spark session available: {type(exc).__name__}")
    yield s
    try:
        s.stop()
    except Exception:                                         # noqa: BLE001
        pass


def test_normalize_landed_strips_the_artifact_from_real_data(spark):
    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame(
        [("DENSO", "'-92866.559999999998", 1),
         ("O'Brien Ltd", "1681.32", 2),
         (None, None, 3)],
        "Supplier string, Invoice_Amount string, Batch_Id int")
    got = {r["Supplier"]: r["Invoice_Amount"] for r in normalize_landed(df).collect()}
    assert got["DENSO"] == "-92866.559999999998"       # artifact removed
    assert got["O'Brien Ltd"] == "1681.32"             # untouched
    assert None in got                                  # nulls survive


def test_an_apostrophe_inside_a_value_is_data_not_an_artifact(spark):
    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame([("O'Brien",)], "Supplier string")
    assert normalize_landed(df).collect()[0]["Supplier"] == "O'Brien"


def test_normalization_is_idempotent(spark):
    """Re-landing must be safe: a second pass over clean data changes nothing."""
    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame([("'12.5",)], "Amount string")
    once = normalize_landed(df)
    assert normalize_landed(once).collect() == once.collect() == [("12.5",)]


def test_non_text_columns_keep_their_type(spark):
    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame([("'1.5", 7)], "a string, b int")
    out = normalize_landed(df)
    assert dict(out.dtypes) == {"a": "string", "b": "int"}


def test_the_stripped_value_now_casts_where_the_raw_one_would_not(spark):
    """The whole point: after landing, a plain CAST works and parity compares numbers
    rather than one number and one string."""
    from pyspark.sql import functions as F

    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame([("'-92866.56",)], "Amount string")
    raw = df.select(F.try_cast(F.col("Amount"), "double").alias("v")).collect()[0]["v"]
    clean = normalize_landed(df).select(
        F.try_cast(F.col("Amount"), "double").alias("v")).collect()[0]["v"]
    assert raw is None                                  # silently null before
    assert clean == pytest.approx(-92866.56)            # a real number after


def test_trim_is_opt_in(spark):
    from core.contracts.landing import normalize_landed
    df = spark.createDataFrame([("  x  ",)], "a string")
    assert normalize_landed(df).collect()[0]["a"] == "  x  "
    assert normalize_landed(df, trim=True).collect()[0]["a"] == "x"


# --------------------------------------------------------------------------- #
# the cleaned view — cleaning in a SELECT, without the transpiler knowing a schema
# --------------------------------------------------------------------------- #
def test_the_view_cleans_text_columns_and_passes_the_rest_through():
    from core.contracts.landing import clean_view_ddl
    ddl = clean_view_ddl("cat.raw.t", "cat.clean.t", COLS)
    assert ddl.startswith("CREATE OR REPLACE VIEW cat.clean.t AS")
    assert "regexp_replace(`Invoice_Amount`" in ddl
    assert "regexp_replace(`Batch_Id`" not in ddl
    assert ddl.rstrip().endswith("FROM cat.raw.t")


def test_the_view_keeps_every_column_and_its_name():
    """A view is what everything downstream reads. Dropping or renaming a column here
    breaks the whole dataflow, silently, at the first step that references it."""
    from core.contracts.landing import clean_view_ddl
    ddl = clean_view_ddl("cat.raw.t", "cat.clean.t", COLS)
    for name in COLS:
        assert f"`{name}`" in ddl


def test_the_view_is_create_or_replace_so_it_can_be_rebuilt():
    """A view with an explicit column list does not pick up a new source column by
    itself, so re-running after a schema change has to be safe."""
    from core.contracts.landing import clean_view_ddl
    assert "CREATE OR REPLACE VIEW" in clean_view_ddl("a.b.c", "a.d.c", COLS)


def test_the_view_body_is_the_same_projection_used_for_a_sql_landing():
    """One rule, two delivery mechanisms — not two rules that can drift."""
    from core.contracts.landing import clean_view_ddl, normalize_select_sql
    assert normalize_select_sql("cat.raw.t", COLS) in clean_view_ddl(
        "cat.raw.t", "cat.clean.t", COLS)


def test_creating_views_skips_tables_with_no_text_columns(monkeypatch):
    """A table that cannot carry the artifact needs no view; making one anyway would
    add a layer of indirection for nothing."""
    from core.contracts.landing import create_clean_views

    class FakeDF:
        def __init__(self, dtypes): self.dtypes = dtypes
        def select(self, *_): return self
        def collect(self): return [("has_text",), ("all_numeric",)]

    class FakeSpark:
        def __init__(self): self.ran = []
        def sql(self, q):
            self.ran.append(q)
            return FakeDF([])
        def table(self, name):
            return FakeDF([("a", "string")] if name.endswith("has_text")
                          else [("n", "bigint")])

    spark = FakeSpark()
    ddl = create_clean_views(spark, "cat", "raw", "clean",
                             tables=["has_text", "all_numeric"])
    assert len(ddl) == 1 and "cat.clean.has_text" in ddl[0]


def test_dry_run_returns_the_ddl_without_executing_it():
    from core.contracts.landing import create_clean_views

    class FakeDF:
        dtypes = [("a", "string")]
        def select(self, *_): return self
        def collect(self): return []

    class FakeSpark:
        def __init__(self): self.executed = []
        def sql(self, q): self.executed.append(q); return FakeDF()
        def table(self, name): return FakeDF()

    spark = FakeSpark()
    ddl = create_clean_views(spark, "cat", "raw", "clean", tables=["t"], dry_run=True)
    assert len(ddl) == 1
    assert spark.executed == []          # nothing ran
