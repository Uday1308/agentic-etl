"""SQL tile renderers — the shared deterministic layer both agents use.

Renderers emit CTE bodies: a bare SELECT, no CREATE OR REPLACE prefix and no
semicolon, because materialization is a deliberate human decision.
"""
from __future__ import annotations

import pytest

from core.domo.tiles import SqlTileRegistry, sql_type, tile_registry

REG = tile_registry("sql")

#: Every expectation below uses the DEFAULT delta_safe naming policy.


def _r(node, inputs=("src",), out="out"):
    return REG.render(node, list(inputs), out)


def test_registry_dialect_selection():
    assert isinstance(tile_registry("sql"), SqlTileRegistry)
    assert tile_registry("pyspark").find("filter") is not None
    with pytest.raises(ValueError, match="unknown dialect"):
        tile_registry("tsql")


def test_bodies_are_plain_selects_without_materialization():
    """Stored preference and design decision: no CREATE OR REPLACE, no semicolon."""
    for node in ({"type": "filter", "properties": {"conditions": [
                     {"column": "a", "operator": "EQUALS", "value": "x"}]}},
                 {"type": "select", "properties": {"columns": ["a"]}},
                 {"type": "groupBy", "properties": {"groupBy": ["k"], "aggregations": [
                     {"function": "SUM", "column": "amt", "alias": "t"}]}}):
        code = _r(node).code
        assert code.lstrip().upper().startswith("SELECT")
        assert "CREATE" not in code.upper() and not code.rstrip().endswith(";")


def test_formula_tile_annotates_each_mapping_with_its_domo_source():
    r = _r({"type": "formula", "properties": {"expressions": [
        {"name": "Period End Date", "expression": "LAST_DAY(`Date`)"}]}})
    assert r.resolved
    assert "-- DOMO : LAST_DAY(`Date`)" in r.code
    assert "last_day(`Date`) AS `Period_End_Date`" in r.code
    assert r.expressions[0]["source"] == "python"


def test_formula_escalates_only_the_bad_expression():
    r = _r({"type": "formula", "properties": {"expressions": [
        {"name": "good", "expression": "MONTH(`d`)"},
        {"name": "bad", "expression": "WEIRD_FN(`d`)"}]}})
    assert not r.resolved and r.unresolved == ["WEIRD_FN"]
    assert r.expressions[0]["source"] == "python" and r.expressions[1]["source"] == "llm"


def test_join_drops_duplicated_right_keys():
    """DOMO tolerates duplicate column names across inputs; SQL does not."""
    r = _r({"type": "join", "properties": {
        "joinKeys": [{"left": "Supplier", "right": "Company Name"}], "joinType": "left"}},
        inputs=("plant", "mapping"))
    assert r.resolved
    assert "rt.* EXCEPT (`Company_Name`)" in r.code
    assert "LEFT JOIN mapping AS rt" in r.code
    assert r.join_keys == [{"left": "Supplier", "right": "Company Name"}]


def test_join_without_keys_escalates_but_cross_is_allowed_with_a_warning():
    assert not _r({"type": "join", "properties": {}}, inputs=("a", "b")).resolved
    cross = _r({"type": "join", "properties": {"joinType": "cross"}}, inputs=("a", "b"))
    assert cross.resolved and any("cross join" in n for n in cross.notes)


def test_domo_decimal_maps_to_double():
    """Verified against dev_test.domo_output: DOMO renders a DECIMAL-cast column as
    DOUBLE. Emitting DECIMAL(18,2) instead is a type mismatch and shifts max/sum
    comparisons in the parity report."""
    r = _r({"type": "alterColumns", "properties": {"fields": [
        {"name": "Invoice Amount", "type": "DECIMAL"}]}})
    assert "AS DOUBLE) AS `Invoice_Amount`" in r.code
    assert "DECIMAL(" not in r.code


def test_numeric_type_mapping_matches_domo_output():
    assert sql_type("DECIMAL")[0] == "DOUBLE"
    assert sql_type("DOUBLE")[0] == "DOUBLE"
    assert sql_type("LONG")[0] == "BIGINT"


def test_first_aggregation_is_flagged_low():
    r = _r({"type": "groupBy", "properties": {"groupBy": ["k"], "aggregations": [
        {"function": "FIRST", "column": "rate", "alias": "rate"}]}})
    assert r.confidence == "LOW" and any("order-dependent" in n for n in r.notes)


def test_group_by_select_list_is_comma_separated():
    r = _r({"type": "groupBy", "properties": {
        "groupBy": ["Company", "Period End Date"],
        "aggregations": [{"function": "SUM", "column": "amt", "alias": "t"}]}})
    assert "  `Company`\n  , `Period_End_Date`" in r.code
    assert "GROUP BY `Company`, `Period_End_Date`" in r.code


def test_filter_strips_the_domo_quote_artifact():
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Paying Company", "operator": "NOT_EQUALS", "value": "DIAM"}]}})
    assert "regexp_replace" in r.code and "<> 'DIAM'" in r.code


def test_filter_in_and_not_in():
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Company", "operator": "IN", "value": ["ASMI", "DIAM"]}]}})
    assert "`Company` IN ('ASMI', 'DIAM')" in r.code


def test_union_warns_that_sql_matches_by_position():
    """DOMO's append matches by name; UNION ALL matches by position."""
    r = _r({"type": "append", "properties": {}}, inputs=("a", "b", "c"))
    assert r.code.count("UNION ALL") == 2
    assert any("column order" in n for n in r.notes)


def test_dynamic_unpivot_escalates_when_value_columns_are_unknown():
    """DOMO resolves them at run time; SQL cannot, so guessing is not an option."""
    r = _r({"type": "normalizeall", "properties": {"id_columns": ["a"]}})
    assert not r.resolved and "resolved at run time" in r.unresolved[0]


def test_unpivot_renders_when_value_columns_are_stated():
    r = _r({"type": "unpivot", "properties": {
        "id_columns": ["Base Currency"], "value_columns": ["USD", "CAD"],
        "name_column": "Exchange Currency", "value_column": "Oracle Exchange Rate"}})
    assert r.resolved and "stack(2, 'USD', `USD`, 'CAD', `CAD`)" in r.code


def test_sort_warns_that_cte_ordering_is_not_guaranteed():
    r = _r({"type": "sort", "properties": {"orderBy": [
        {"column": "d", "direction": "desc"}]}})
    assert "ORDER BY `d` DESC" in r.code
    assert any("outermost SELECT" in n for n in r.notes)


def test_unknown_tile_escalates_rather_than_guessing():
    r = _r({"type": "RiskScore", "properties": {}})
    assert not r.resolved and "RiskScore" in r.unresolved[0] and r.confidence == "LOW"


def test_a_broken_renderer_escalates_instead_of_crashing():
    class Boom:
        op_types = ("BOOM",)

        def render(self, node, inputs, out_var):
            raise RuntimeError("kaboom")

    r = SqlTileRegistry([Boom()]).render({"type": "BOOM"}, [], "out")
    assert not r.resolved and "kaboom" in r.unresolved[0]


# -- identifier quoting (DELTA_INVALID_CHARACTERS_IN_COLUMN_NAMES) ---------- #

def test_identifiers_are_quoted_exactly_once():
    """DOMO sometimes stores a column name that already carries backticks. Wrapping
    it again yields an identifier containing literal backticks, which Delta rejects.
    Names are also sanitized, per the default policy."""
    from core.domo.tiles import q
    assert q("`Transaction No.`") == "`Transaction_No.`"
    assert q("Journal Batch Name") == "`Journal_Batch_Name`"
    assert q("  `Issuance Dept.`  ") == "`Issuance_Dept.`"
    assert q("Sub Account Code") == "`Sub_Account_Code`"


def test_doubled_backtick_escape_is_preserved():
    """A doubled backtick is the SQL escape for one literal backtick — not quoting."""
    from core.domo.tiles import q
    assert q("weird``name") == "`weird``name`"


def test_expression_columns_are_quoted_once_too():
    from core.domo.expr import translate
    assert translate("`Invoice No.` = 1", dialect="sql").code == "(`Invoice_No.` = 1)"


def test_generated_sql_never_emits_doubled_quoting():
    """End to end: a tile whose properties carry pre-quoted names must still produce
    identifiers Delta will accept."""
    r = _r({"type": "select", "properties": {"selectedColumns": [
        {"column": "`Transaction No.`", "rename": "`Txn No.`"},
        {"column": "Journal Batch Name"}]}})
    assert "``" not in r.code
    assert "`Transaction_No.` AS `Txn_No.`" in r.code


# -- DOMO vs SQL null semantics --------------------------------------------- #

def test_not_equals_is_null_safe():
    """The bug that empties a table: in SQL, NULL <> 'x' is NULL, so every row with a
    null value is dropped. DOMO's not-equals filter keeps those rows."""
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "_BATCH_LAST_RUN_", "operator": "NE", "value": "2026-03-30T14:18:07"}]}})
    assert "`_BATCH_LAST_RUN_` IS NULL OR" in r.code
    assert any("null-safe" in n for n in r.notes)


def test_not_in_and_not_contains_are_null_safe_too():
    for op, value in (("NOT_IN", ["GLOPIP"]), ("NCT", "FX")):
        r = _r({"type": "filter", "properties": {"conditions": [
            {"column": "Source", "operator": op, "value": value}]}})
        assert "`Source` IS NULL OR" in r.code, op


def test_positive_operators_are_left_alone():
    """Only negative comparisons need the guard — adding it everywhere would change
    the meaning of an equals filter."""
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Company", "operator": "EQ", "value": "DIAM"}]}})
    assert "IS NULL OR" not in r.code


# -- formula tiles that use their own output -------------------------------- #

def test_formula_nests_when_an_expression_uses_a_column_the_tile_just_made():
    """DOMO evaluates a formula tile's expressions in order, so a later one may use an
    earlier one's output. A flat SELECT either fails to resolve the alias or — worse —
    binds it to a same-named column already on the input."""
    r = _r({"type": "formula", "properties": {"expressions": [
        {"outputColumn": "Month Number", "expression": "MONTH(`Date`)"},
        {"outputColumn": "Fiscal Period2",
         "expression": "CASE WHEN `Month Number` IN (1,2,3) THEN 'Q1' ELSE 'x' END"}]}})
    assert r.resolved
    assert r.code.count("SELECT") == 2 and "FROM (" in r.code
    # the dependent expression must sit OUTSIDE the layer that defines what it reads
    outer, inner = r.code.split("FROM (", 1)
    assert "Fiscal_Period2" in outer and "AS `Month_Number`" not in outer
    assert "CAST(month(`Date`) AS BIGINT) AS `Month_Number`" in inner
    assert any("just created" in n for n in r.notes)


def test_independent_expressions_stay_in_one_select():
    r = _r({"type": "formula", "properties": {"expressions": [
        {"outputColumn": "a", "expression": "MONTH(`Date`)"},
        {"outputColumn": "b", "expression": "YEAR(`Date`)"}]}})
    assert r.code.count("SELECT") == 1 and "FROM (" not in r.code


def test_formula_never_excepts_the_columns_it_creates():
    """`* EXCEPT (col)` fails outright in Databricks when col does not already exist,
    and a formula tile creates NEW columns. EXCEPT is only safe where the excluded
    column is read from the input, as in alter-columns and joins."""
    r = _r({"type": "formula", "properties": {"expressions": [
        {"outputColumn": "Net Amount", "expression": "`a` - `b`"}]}})
    assert "EXCEPT" not in r.code
    assert "SELECT\n  *\n" in r.code


def test_alter_columns_may_except_because_those_columns_exist():
    r = _r({"type": "alterColumns", "properties": {"fields": [
        {"name": "Company Code", "rename": "Company"}]}})
    assert "* EXCEPT (`Company_Code`)" in r.code


# -- timestamp filters compare natively ------------------------------------- #

def test_timestamp_filters_compare_as_timestamps_not_text():
    """CAST(ts AS STRING) renders '2026-03-30 14:18:07' while DOMO's literal says
    '2026-03-30T14:18:07', so a text comparison never matches and the filter quietly
    does nothing. Verified against the real table: native comparison passes 100%."""
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "_BATCH_LAST_RUN_", "operator": "NE",
         "value": "2026-03-30T14:18:07"}]}})
    assert "`_BATCH_LAST_RUN_` <> TIMESTAMP '2026-03-30 14:18:07'" in r.code
    assert "CAST(`_BATCH_LAST_RUN_` AS STRING)" not in r.code
    assert "`_BATCH_LAST_RUN_` IS NULL OR" in r.code       # still null-safe


def test_iso_separator_and_zone_are_normalised_in_the_literal():
    from core.domo.tiles import ts_literal
    assert ts_literal("2026-03-30T14:18:07") == "TIMESTAMP '2026-03-30 14:18:07'"
    assert ts_literal("2026-04-01T00:00:00Z") == "TIMESTAMP '2026-04-01 00:00:00'"
    assert ts_literal("2026-04-02T06:30:00+05:30") == "TIMESTAMP '2026-04-02 06:30:00'"
    assert ts_literal("2026-03-30 14:18:07") == "TIMESTAMP '2026-03-30 14:18:07'"


def test_string_filters_still_get_the_quote_cleaning():
    """Only timestamp-shaped values switch to native comparison; text columns still
    need the leading-apostrophe strip DOMO exports introduce."""
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Paying Company", "operator": "NE", "value": "DIAM"}]}})
    assert "regexp_replace" in r.code and "TIMESTAMP" not in r.code


def test_timestamp_detection_does_not_fire_on_ordinary_values():
    from core.domo.tiles import looks_like_timestamp
    assert looks_like_timestamp("2026-03-30T14:18:07")
    assert looks_like_timestamp("2026-03-30 14:18")
    assert not looks_like_timestamp("2026-03-30")          # bare date stays text
    assert not looks_like_timestamp("DIAM")
    assert not looks_like_timestamp(12345)
    assert not looks_like_timestamp(None)


def test_in_lists_of_timestamps_are_native_too():
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "run_at", "operator": "NOT_IN",
         "value": ["2026-03-30T14:18:07", "2026-03-27T10:48:56"]}]}})
    assert "TIMESTAMP '2026-03-30 14:18:07'" in r.code
    assert "TIMESTAMP '2026-03-27 10:48:56'" in r.code
    assert "`run_at` IS NULL OR" in r.code

# --------------------------------------------------------------------------- #
# a formula that overwrites the column it reads
# --------------------------------------------------------------------------- #
def _formula(exprs, inputs=("df_in",), out="df_out"):
    from core.domo.tiles import tile_registry
    return tile_registry("sql").render(
        {"type": "formula", "properties": {"expressions": exprs}}, list(inputs), out)


def test_a_formula_that_reads_the_column_it_writes_replaces_it_in_place():
    """DOMO replaces in place. A bare `*` here emits TWO columns with one name —
    Spark accepts it at this step, then every later reference is ambiguous."""
    r = _formula([{"outputColumn": "CMS Matrix Amount",
                   "expression": "`CMS Matrix Amount`*-1"}])
    assert r.resolved
    assert "* EXCEPT (`CMS_Matrix_Amount`)" in r.code
    assert r.code.count("AS `CMS_Matrix_Amount`") == 1


def test_a_formula_that_adds_a_new_column_still_uses_a_bare_star():
    """EXCEPT on a column that does not exist yet fails outright, so it must not be
    emitted for the ordinary add-a-column case."""
    r = _formula([{"outputColumn": "Margin Pct", "expression": "`revenue` - `cost`"}])
    assert r.resolved
    assert "EXCEPT" not in r.code and "\n  *\n" in r.code


def test_only_the_overwritten_columns_are_excepted():
    r = _formula([{"outputColumn": "Amount", "expression": "`Amount` * -1"},
                  {"outputColumn": "Flag", "expression": "'x'"}])
    assert "* EXCEPT (`Amount`)" in r.code
    assert "`Flag`" not in r.code.split("EXCEPT (")[1].split(")")[0]


def test_the_replacement_is_called_out_as_a_caveat_for_the_reviewer():
    r = _formula([{"outputColumn": "Amount", "expression": "`Amount` * -1"}])
    assert any("in place" in n for n in r.notes)


def test_several_overwrites_in_one_tile_are_excepted_together():
    r = _formula([{"outputColumn": "A", "expression": "`A` * 2"},
                  {"outputColumn": "B", "expression": "`B` + 1"}])
    excepted = r.code.split("EXCEPT (")[1].split(")")[0]
    assert "`A`" in excepted and "`B`" in excepted


# --------------------------------------------------------------------------- #
# tracing a column set DOMO resolves at run time
# --------------------------------------------------------------------------- #
def test_a_select_tile_states_its_output_columns_in_domo_spelling():
    from core.domo.tiles import declared_output_columns
    node = {"type": "select", "properties": {"selectedColumns": [
        {"column": "C2", "rename": "Base Currency"},
        {"column": "RMB/CNY"},
    ]}}
    assert declared_output_columns(node) == ["Base Currency", "RMB/CNY"]


def test_a_tile_that_does_not_state_its_columns_returns_none():
    """None means 'escalate', which is right. A guess here becomes silent bad data."""
    from core.domo.tiles import declared_output_columns
    assert declared_output_columns({"type": "formula", "properties": {}}) is None
    assert declared_output_columns({"type": "join", "properties": {}}) is None


def test_the_tracer_walks_back_through_row_only_tiles():
    from agents.md_plan.render import resolve_dynamic_columns
    nodes = [
        {"id": "a", "type": "select", "properties": {"selectedColumns": [
            {"column": "id"}, {"column": "USD"}, {"column": "RMB/CNY"}]}},
        {"id": "b", "type": "filter", "properties": {}},
        {"id": "c", "type": "NormalizeAll", "properties": {
            "idFields": ["id"], "keyField": "Cur", "valueField": "Rate"}},
    ]
    edges = [{"from": "a", "to": "b"}, {"from": "b", "to": "c"}]
    out = {n["id"]: n for n in resolve_dynamic_columns(nodes, edges)}
    assert out["c"]["properties"]["value_columns"] == ["USD", "RMB/CNY"]


def test_id_fields_are_matched_after_sanitization():
    """idFields carry DOMO's spelling (`Base Currency`); a traced column may already be
    the ingested one. Comparing raw would unpivot the id column."""
    from agents.md_plan.render import resolve_dynamic_columns
    nodes = [
        {"id": "a", "type": "select", "properties": {"selectedColumns": [
            {"column": "Base_Currency"}, {"column": "USD"}]}},
        {"id": "b", "type": "NormalizeAll", "properties": {
            "idFields": ["Base Currency"], "keyField": "k", "valueField": "v"}},
    ]
    out = {n["id"]: n for n in resolve_dynamic_columns(nodes, [{"from": "a", "to": "b"}])}
    assert out["b"]["properties"]["value_columns"] == ["USD"]


def test_an_untraceable_upstream_leaves_the_tile_escalating():
    from agents.md_plan.render import resolve_dynamic_columns
    nodes = [
        {"id": "a", "type": "join", "properties": {}},
        {"id": "b", "type": "NormalizeAll", "properties": {
            "idFields": ["id"], "keyField": "k", "valueField": "v"}},
    ]
    out = {n["id"]: n for n in resolve_dynamic_columns(nodes, [{"from": "a", "to": "b"}])}
    assert "value_columns" not in out["b"]["properties"]


def test_an_explicit_value_column_list_is_never_overwritten():
    from agents.md_plan.render import resolve_dynamic_columns
    nodes = [
        {"id": "a", "type": "select", "properties": {"selectedColumns": [{"column": "X"}]}},
        {"id": "b", "type": "NormalizeAll", "properties": {
            "idFields": [], "value_columns": ["ONLY_THIS"], "keyField": "k",
            "valueField": "v"}},
    ]
    out = {n["id"]: n for n in resolve_dynamic_columns(nodes, [{"from": "a", "to": "b"}])}
    assert out["b"]["properties"]["value_columns"] == ["ONLY_THIS"]


# --------------------------------------------------------------------------- #
# the column tracer generalises — nothing about it is specific to one dataflow
# --------------------------------------------------------------------------- #
def _trace(nodes, edges, target="u"):
    from agents.md_plan.render import resolve_dynamic_columns
    out = {n["id"]: n for n in resolve_dynamic_columns(nodes, edges)}
    return out[target]["properties"].get("value_columns")


def _sel(nid, cols):
    return {"id": nid, "type": "select",
            "properties": {"selectedColumns": [{"column": c} for c in cols]}}


UNPIVOT = {"id": "u", "type": "NormalizeAll",
           "properties": {"idFields": ["id"], "keyField": "k", "valueField": "v"}}


def test_the_tracer_carries_no_knowledge_of_any_particular_dataflow():
    """Columns come from the graph, never from the code. A quarterly sales flow that
    shares nothing with the currency flow must trace just as well."""
    assert _trace([_sel("a", ["id", "Q1 Sales", "Q2 Sales"]), UNPIVOT],
                  [{"from": "a", "to": "u"}]) == ["Q1 Sales", "Q2 Sales"]


def test_a_groupby_upstream_states_its_own_output():
    nodes = [{"id": "g", "type": "aggregate", "properties": {
        "groupByColumns": ["id"],
        "aggregations": [{"inputColumn": "a", "outputColumn": "A Total", "function": "SUM"},
                         {"inputColumn": "b", "outputColumn": "B Total", "function": "SUM"}]}},
        UNPIVOT]
    assert _trace(nodes, [{"from": "g", "to": "u"}]) == ["A Total", "B Total"]


def test_a_formula_upstream_adds_its_new_columns_to_its_input():
    nodes = [_sel("a", ["id", "base"]),
             {"id": "f", "type": "formula", "properties": {"expressions": [
                 {"outputColumn": "derived", "expression": "`base` * 2"}]}}, UNPIVOT]
    assert _trace(nodes, [{"from": "a", "to": "f"}, {"from": "f", "to": "u"}]) \
        == ["base", "derived"]


def test_a_formula_that_overwrites_does_not_duplicate_the_column():
    nodes = [_sel("a", ["id", "amt"]),
             {"id": "f", "type": "formula", "properties": {"expressions": [
                 {"outputColumn": "amt", "expression": "`amt` * -1"}]}}, UNPIVOT]
    assert _trace(nodes, [{"from": "a", "to": "f"}, {"from": "f", "to": "u"}]) == ["amt"]


def test_an_alter_columns_upstream_applies_its_renames():
    nodes = [_sel("a", ["id", "amt usd", "amt eur"]),
             {"id": "al", "type": "alter_columns", "properties": {"fields": [
                 {"name": "amt usd", "rename": "USD Amount", "type": "DOUBLE"}]}}, UNPIVOT]
    got = _trace(nodes, [{"from": "a", "to": "al"}, {"from": "al", "to": "u"}])
    assert got == ["amt eur", "USD Amount"]


def test_alter_columns_is_traced_despite_domos_several_spellings():
    """`alter_columns`, `ALTER COLUMNS` and `AlterColumns` are one tile. The tracer
    normalizes exactly as the registry does, or it silently skips the tile."""
    for spelling in ("alter_columns", "ALTER COLUMNS", "AlterColumns"):
        nodes = [_sel("a", ["id", "x"]),
                 {"id": "al", "type": spelling, "properties": {"fields": [
                     {"name": "x", "rename": "X2"}]}}, UNPIVOT]
        assert _trace(nodes, [{"from": "a", "to": "al"}, {"from": "al", "to": "u"}]) \
            == ["X2"], spelling


def test_a_join_upstream_combines_both_sides_minus_the_dropped_key():
    nodes = [_sel("a", ["id", "north"]), _sel("b", ["id", "south"]),
             {"id": "j", "type": "join", "properties": {
                 "joinType": "LEFT OUTER",
                 "joinKeys": [{"leftColumn": "id", "rightColumn": "id"}]}}, UNPIVOT]
    got = _trace(nodes, [{"from": "a", "to": "j"}, {"from": "b", "to": "j"},
                         {"from": "j", "to": "u"}])
    assert got == ["north", "south"]


def test_a_union_upstream_takes_its_columns_from_the_first_input():
    nodes = [_sel("a", ["id", "x", "y"]), _sel("b", ["id", "x", "y"]),
             {"id": "un", "type": "union", "properties": {}}, UNPIVOT]
    assert _trace(nodes, [{"from": "a", "to": "un"}, {"from": "b", "to": "un"},
                          {"from": "un", "to": "u"}]) == ["x", "y"]


def test_a_bare_source_upstream_escalates_because_only_the_table_knows():
    """No tile states a source's columns. Guessing would be wrong data with no
    symptom, so this must escalate to the schema probe or the AI tail."""
    nodes = [{"id": "s", "type": "source", "properties": {"datasetName": "feed"}}, UNPIVOT]
    assert _trace(nodes, [{"from": "s", "to": "u"}]) is None


def test_a_cycle_terminates_instead_of_hanging():
    nodes = [{"id": "p", "type": "filter", "properties": {}},
             {"id": "qq", "type": "filter", "properties": {}}, UNPIVOT]
    assert _trace(nodes, [{"from": "p", "to": "qq"}, {"from": "qq", "to": "p"},
                          {"from": "qq", "to": "u"}]) is None


# --------------------------------------------------------------------------- #
# append: DOMO matches by NAME, UNION ALL matches by POSITION
# --------------------------------------------------------------------------- #
def _union(inputs, per_input=None):
    from core.domo.tiles import tile_registry
    props = {} if per_input is None else {"input_columns": per_input}
    return tile_registry("sql").render({"type": "union", "properties": props},
                                       list(inputs), "df_out")


def test_branches_with_different_columns_are_aligned_by_name_and_null_filled():
    """NUM_COLUMNS_MISMATCH otherwise. DOMO's append fills a missing column with null."""
    r = _union(["a", "b"], [["id", "x"], ["id", "y", "z"]])
    assert r.resolved
    branches = r.code.split("UNION ALL")
    assert len(branches) == 2
    for b in branches:                      # same three columns, same order, both sides
        assert b.index("`id`") < b.index("`x`") < b.index("`y`") < b.index("`z`")
    assert "NULL AS `y`" in branches[0] and "NULL AS `z`" in branches[0]
    assert "NULL AS `x`" in branches[1]


def test_a_bare_null_is_used_so_spark_can_take_the_type_from_the_other_branch():
    """CASTing the padding would force a type on a column another branch supplies."""
    r = _union(["a", "b"], [["id"], ["id", "amount"]])
    assert "NULL AS `amount`" in r.code
    assert "CAST(NULL" not in r.code


def test_identical_branches_need_no_padding_and_raise_no_caveat():
    r = _union(["a", "b"], [["id", "x"], ["id", "x"]])
    assert "NULL AS" not in r.code
    assert not any("null-filled" in n for n in r.notes)


def test_the_padding_is_called_out_for_the_reviewer():
    r = _union(["a", "b"], [["id"], ["id", "extra"]])
    assert any("null-filled" in n for n in r.notes)


def test_without_traced_columns_it_falls_back_and_says_it_is_not_aligned():
    """Silence here would imply an alignment that did not happen."""
    r = _union(["a", "b"])
    assert "SELECT * FROM a" in r.code
    assert any("NOT aligned" in n for n in r.notes)


def test_the_union_output_is_the_superset_of_every_branch():
    """Reporting only the first branch's columns would under-report downstream."""
    from core.domo.tiles import output_columns
    node = {"type": "union", "properties": {}}
    assert output_columns(node, [["id", "x"], ["id", "y"]]) == ["id", "x", "y"]
    assert output_columns(node, [["id", "x"], None]) is None


# --------------------------------------------------------------------------- #
# a formula that overwrites a column WITHOUT reading it
# (AMBIGUOUS_REFERENCE at the next step, not at this one)
# --------------------------------------------------------------------------- #
def _formula_with_input(exprs, input_cols):
    from core.domo.tiles import tile_registry
    node = {"type": "formula",
            "properties": {"expressions": exprs, "input_columns": [input_cols]}}
    return tile_registry("sql").render(node, ["df_in"], "df_out")


def test_a_constant_assigned_to_an_existing_column_replaces_it():
    """`'literal' AS `Report Name`` never reads the column, so self-reference cannot
    detect it. Only the traced input schema can. Emitting a bare `*` here gives the CTE
    two `Report_Name` columns — legal at this step, AMBIGUOUS_REFERENCE at the next."""
    r = _formula_with_input(
        [{"outputColumn": "Report Name", "expression": "'AP Plant Pmt FX Gain/Loss'"}],
        ["Company", "Report Name", "Amount"])
    assert "* EXCEPT (`Report_Name`)" in r.code
    assert r.code.count("AS `Report_Name`") == 1


def test_a_genuinely_new_column_is_still_added_not_excepted():
    r = _formula_with_input([{"outputColumn": "Margin", "expression": "'x'"}],
                            ["Company", "Amount"])
    assert "EXCEPT" not in r.code


def test_the_input_schema_is_matched_after_sanitization():
    """The tile says `Report Name`; the traced input may already be `Report_Name`."""
    r = _formula_with_input([{"outputColumn": "Report Name", "expression": "'x'"}],
                            ["Report_Name"])
    assert "* EXCEPT (`Report_Name`)" in r.code


def test_a_column_created_by_an_earlier_layer_counts_as_existing():
    """Expression 2 reads expression 1's output, so they land in separate nested
    SELECTs. The second layer must see the first layer's new column as available."""
    r = _formula_with_input(
        [{"outputColumn": "Base", "expression": "'x'"},
         {"outputColumn": "Base", "expression": "concat(`Base`, 'y')"}],
        ["Company"])
    assert r.code.count("* EXCEPT (`Base`)") == 1     # only the second layer excepts
    assert r.resolved


def test_without_a_traced_schema_it_falls_back_to_self_reference():
    """No input_columns: the only safe signal left is an expression reading the column
    it writes. A blanket EXCEPT would fail on a column that does not exist yet."""
    from core.domo.tiles import tile_registry
    node = {"type": "formula", "properties": {"expressions": [
        {"outputColumn": "Amount", "expression": "`Amount` * -1"}]}}
    r = tile_registry("sql").render(node, ["df_in"], "df_out")
    assert "* EXCEPT (`Amount`)" in r.code


def test_the_reason_for_the_replacement_is_recorded():
    r = _formula_with_input([{"outputColumn": "Report Name", "expression": "'x'"}],
                            ["Report Name"])
    assert any("already exists on the input" in n for n in r.notes)


# --------------------------------------------------------------------------- #
# numeric aggregates over a text column
# (CAST_INVALID_INPUT — DOMO coerces, ANSI Spark raises)
# --------------------------------------------------------------------------- #
def _agg(fn, col="Invoice Amount", alias="Out"):
    from core.domo.tiles import tile_registry
    node = {"type": "aggregate", "properties": {
        "groupByColumns": ["Company"],
        "aggregations": [{"inputColumn": col, "outputColumn": alias, "function": fn}]}}
    return tile_registry("sql").render(node, ["df_in"], "df_out")


def test_sum_coerces_its_input_to_a_number():
    """DOMO exports a leading apostrophe on some numbers, so SUM over the raw column
    raises CAST_INVALID_INPUT on the first such value."""
    code = _agg("SUM").code
    assert "SUM(TRY_CAST(" in code
    assert "AS DOUBLE)) AS `Out`" in code


def test_the_leading_apostrophe_is_stripped_before_the_cast_not_after():
    """TRY_CAST of "'-92866.56" is NULL — silently. The artifact has to go first."""
    code = _agg("SUM").code
    strip = code.index("regexp_replace")
    cast = code.index("AS DOUBLE")
    assert strip < cast


def test_avg_and_stddev_coerce_too():
    for fn in ("AVG", "STDDEV"):
        assert "TRY_CAST(" in _agg(fn).code, fn


def test_min_max_count_and_first_are_left_alone():
    """These are meaningful over text; coercing them would change the answer."""
    for fn in ("MIN", "MAX", "COUNT", "FIRST", "LAST"):
        assert "TRY_CAST(" not in _agg(fn).code, fn


def test_the_coercion_is_recorded_as_a_caveat():
    assert any("coerces its input to a number" in n for n in _agg("SUM").notes)


def test_the_numeric_helper_is_shared_with_the_expression_emitter():
    """One definition, so arithmetic and aggregates cannot drift on how they coerce."""
    from core.domo.expr import numeric_operand, translate
    helper = numeric_operand("`Invoice_Amount`")
    assert helper in _agg("SUM").code
    assert helper in translate("`Invoice Amount` * 2", dialect="sql").code
