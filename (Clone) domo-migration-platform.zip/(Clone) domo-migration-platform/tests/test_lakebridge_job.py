"""Lakebridge job transpiler against a fake Jobs API + fake volume (ADR 034 section 7). Offline."""
from __future__ import annotations

import importlib.util
import io
import json
import pathlib

import pytest

from agents.cd_codegen.translate.chain import TranslationConfigError
from agents.cd_codegen.translate.ports import SqlUnit
from agents.cd_codegen.translate.twophase import run_phase_a
from core.lakebridge import LakebridgeJobTranspiler, load_allowlist, tier1_from_env, tier1_label

ROOT = pathlib.Path(__file__).resolve().parents[3]
_spec = importlib.util.spec_from_file_location("lb_job", ROOT / "jobs" / "lakebridge_transpile.py")
lb_job = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(lb_job)

UNITS = [SqlUnit("e1", "u1", "select 1", "fp1"), SqlUnit("e1", "u2", "select bad", "fp2")]


class FakeFiles:
    def __init__(self, store):
        self.store = store

    def upload(self, path, data, overwrite=False):
        self.store[path] = data.read()

    def download(self, path):
        return type("R", (), {"contents": io.BytesIO(self.store[path])})()

    def delete_directory(self, path):
        for k in [k for k in self.store if k.startswith(path)]:
            del self.store[k]


class FakeJobs:
    """run_now executes the job's pure core against the fake volume, like the cluster would."""

    def __init__(self, store, allowlist_seen):
        self.store, self.params, self.seen = store, None, allowlist_seen

    def list(self, name=None):
        return iter([type("J", (), {"job_id": 7})()])

    def run_now(self, job_id, job_parameters=None):
        self.params = job_parameters
        req = json.loads(self.store[job_parameters["request_path"]])

        def fake_cli(tool, dialect, src, out):
            for f in src.rglob("*.sql"):
                if "bad" not in f.read_text():
                    (out / f.relative_to(src)).parent.mkdir(parents=True, exist_ok=True)
                    (out / f.relative_to(src)).write_text("SELECT 1 /* dbx */")
            return 0, ""
        doc = lb_job.run_request(req, lb_job.parse_allowlist(job_parameters["allowlist"]), version="9.9",
                                 transpile=fake_cli)
        self.store[job_parameters["result_path"]] = json.dumps(doc).encode()
        return type("W", (), {"result": lambda self, timeout=None: None})()


class FakeClient:
    def __init__(self):
        self.store = {}
        self.files = FakeFiles(self.store)
        self.jobs = FakeJobs(self.store, [])


def test_job_transpiler_roundtrip_and_cleanup():
    c = FakeClient()
    t = LakebridgeJobTranspiler(volume_path="/Volumes/c/s/v", batch_run_id="b1", transpiler="bladebridge",
                                allowlist=("bladebridge",), job_id="7", client=c)
    res = t.transpile(UNITS, "snowflake")
    assert [r.fingerprint for r in res] == ["fp1", "fp2"]
    assert res[0].sql.startswith("SELECT 1") and res[0].tool_version == "9.9" and not res[0].error
    assert res[1].sql == "" and "no output" in res[1].error
    assert c.jobs.params["allowlist"] == "bladebridge" and "secret" not in json.dumps(c.jobs.params).lower()
    assert c.store == {}  # request/result folder deleted


def test_empty_allowlist_is_unavailable(tmp_path):
    env = {"MIGRATOR_LAKEBRIDGE": "job"}
    tp, settings, mode = tier1_from_env(volume=tmp_path, batch_run_id="b", environ=env,
                                        allowlist_path=tmp_path / "none.json")
    rep = run_phase_a(tp, UNITS, source_dialect="snowflake", work=tmp_path, enabled=True)
    assert rep.status == "unavailable" and rep.reason == "allow-list empty"
    assert tier1_label(mode, rep.as_dict()) == "unavailable: allow-list empty"
    assert load_allowlist(environ={}) == ()  # the shipped config is empty


def test_off_and_allow_listed_labels(tmp_path):
    assert tier1_from_env(volume=tmp_path, batch_run_id="b", environ={})[2] == "off"
    assert tier1_label("off", {"status": "unavailable", "reason": "x"}) == "off"
    c = FakeClient()
    env = {"MIGRATOR_LAKEBRIDGE": "job", "MIGRATOR_LAKEBRIDGE_ALLOWLIST": "bladebridge",
           "MIGRATOR_LAKEBRIDGE_JOB_ID": "7"}
    tp, settings, mode = tier1_from_env(volume="/Volumes/c/s/v", batch_run_id="b2", environ=env, client=c)
    rep = run_phase_a(tp, UNITS, source_dialect="snowflake", work=tmp_path, enabled=True)
    assert rep.status == "ok" and rep.cache["fp1"]["sql"].startswith("SELECT 1")
    assert rep.cache["fp2"]["error"]
    assert tier1_label(mode, rep.as_dict()) == "on (job)"


def test_llm_based_modes_rejected(tmp_path):
    tp, _s, _m = tier1_from_env(volume=tmp_path, batch_run_id="b",
                                environ={"MIGRATOR_LAKEBRIDGE": "job", "MIGRATOR_LAKEBRIDGE_ALLOWLIST": "switch"})
    assert "allow-list rejected" in (tp.available() or "")
    with pytest.raises(TranslationConfigError):
        LakebridgeJobTranspiler(volume_path="/v", batch_run_id="b", transpiler="switch")
    out = lb_job.run_request({"transpiler": "switch", "source_dialect": "snowflake",
                              "units": [{"id": "fp1", "path": "e/u.sql", "sql": "select 1"}]}, ["switch"])
    assert "LLM" in out["results"][0]["error"]
    assert "allow-list empty" in lb_job.run_request({"transpiler": "bladebridge", "units": [
        {"id": "x", "path": "a.sql", "sql": "s"}]}, [])["results"][0]["error"]
