"""The migrator's sqlglot pin equals the workspace's ``uv.lock`` (ADR 032 section 8, P3-01).

Versions parse and qualify differently, so Discovery's lineage and the migrator's
translation would disagree silently if the two drifted. The workspace lock is found by
walking up from this app; a standalone checkout (no ``uv.lock`` above it) skips the
lock comparison but still checks that the pin is exact and installed.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

APP = Path(__file__).resolve().parents[1]


def _pinned() -> str:
    text = (APP / "requirements.txt").read_text(encoding="utf-8")
    m = re.search(r"^sqlglot==([0-9][^\s#]*)\s*(?:#.*)?$", text, re.MULTILINE)
    assert m, "requirements.txt must pin sqlglot with == (ADR 032 section 8)"
    return m.group(1)


def _locked() -> str | None:
    for parent in APP.parents:
        lock = parent / "uv.lock"
        if lock.is_file():
            m = re.search(r'^name = "sqlglot"\nversion = "([^"]+)"', lock.read_text(encoding="utf-8"),
                          re.MULTILINE)
            return m.group(1) if m else None
    return None


def test_sqlglot_pin_matches_the_workspace_lock():
    locked = _locked()
    if locked is None:
        pytest.skip("no workspace uv.lock with sqlglot above this app (standalone checkout)")
    assert _pinned() == locked


def test_installed_sqlglot_is_the_pinned_version():
    sqlglot = pytest.importorskip("sqlglot")
    assert sqlglot.__version__ == _pinned()
