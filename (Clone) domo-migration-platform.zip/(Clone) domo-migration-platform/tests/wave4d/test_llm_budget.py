"""S14: per-run LLM budget, attempts per unit, validator-feedback retry loop, usage ledger and view."""
from __future__ import annotations

import asyncio
import json
import pathlib

from fastapi.testclient import TestClient

from api.app import app, get_store
from api.store_local import LocalStore
from core import llm_budget as lb
from core.domo.llm import RawCompletion
from packs.snowflake.llm import LlmChoice, serving_translator, validator_feedback

REPO = pathlib.Path(__file__).resolve().parents[2]


def item(step="u1", text="SELECT secret_col FROM sales.orders"):
    return {"step": step, "source_text": text, "engine": "sql_procedure"}


def run(tr, *items):
    return asyncio.run(tr.resolve_tail(type("B", (), {"unresolved": list(items)})()))


def make(answers, *, budget=None, ledger=None, attempts=3, pricing=None):
    prompts: list[str] = []
    it = iter(answers)

    def caller(spec, prompt, schema, timeout):
        prompts.append(prompt)
        text = next(it)
        return RawCompletion(text=text, tokens_in=100, tokens_out=50)

    b = budget or lb.RunBudget(lb.BudgetConfig(attempts_per_unit=attempts), pricing)
    return serving_translator(LlmChoice("serving", "ep"), {}, caller=caller, budget=b, ledger=ledger, run_id="r1"), prompts, b


def test_validator_feedback_retry_then_success_and_ledger_has_no_text(tmp_path):
    ledger = lb.UsageLedger(tmp_path / "u.jsonl")
    tr, prompts, b = make(["```sql\nSELECT FROM WHERE ((\n```", "```sql\nSELECT 1 AS x\n```"], ledger=ledger)
    got = run(tr, item())
    assert got["u1"].usable and got["u1"].sql == "SELECT 1 AS x"
    assert len(prompts) == 2 and "rejected by the validators" in prompts[1] and "PARSE" in prompts[1]
    assert "SELEKT" not in prompts[1]                                    # the feedback carries classes, not the answer
    rows = ledger.rows()
    assert [r["attempt"] for r in rows] == [1, 2] and rows[0]["error_class"] == "PARSE" and rows[1]["error_class"] == ""
    blob = json.dumps(rows)
    assert "secret_col" not in blob and "SELEKT" not in blob and "sales.orders" not in blob
    assert b.calls == 2 and b.tokens == 300
    s = lb.summarize(rows)
    assert s["calls"] == 2 and s["tokens_in"] == 200 and s["cost"] is None and s["error_classes"] == {"PARSE": 1}


def test_attempts_per_unit_cap():
    tr, prompts, _ = make(["```sql\nSELECT FROM WHERE ((\n```"] * 5, attempts=2)
    got = run(tr, item())
    assert not got["u1"].usable and len(prompts) == 2 and "2 attempt" in got["u1"].why_not and "PARSE" in got["u1"].why_not


def test_budget_stops_calls_and_unit_waits_for_a_person(tmp_path):
    ledger = lb.UsageLedger(tmp_path / "u.jsonl")
    b = lb.RunBudget(lb.BudgetConfig(max_tokens=200, attempts_per_unit=3))
    tr, prompts, _ = make(["```sql\nSELECT FROM WHERE ((\n```", "```sql\nSELECT FROM WHERE ((\n```", "```sql\nSELECT 1\n```"], budget=b, ledger=ledger)
    got = run(tr, item("a"))
    assert not got["a"].usable and "budget exhausted" in got["a"].why_not and "token limit" in got["a"].why_not
    assert len(prompts) == 2                                              # 150 + 150 tokens: the third call never happens
    assert ledger.rows()[-1]["status"] == "budget"
    assert lb.summarize(ledger.rows())["refused_by_budget"] == 1


def test_call_limit_is_shared_across_units():
    b = lb.RunBudget(lb.BudgetConfig(max_calls=1, attempts_per_unit=1))
    tr, prompts, _ = make(["```sql\nSELECT 1\n```", "```sql\nSELECT 2\n```"], budget=b)
    got = run(tr, item("a"), item("b"))
    assert [got["a"].usable, got["b"].usable].count(True) == 1 and len(prompts) == 1


def test_cost_is_unknown_without_a_rate_and_enforced_with_one():
    unpriced = lb.Pricing({"default": {"input_per_m": None, "output_per_m": None}})
    b = lb.RunBudget(lb.BudgetConfig(max_cost=0.0001), unpriced)
    assert b.add("ep", 1000, 1000) is None and b.cost is None and b.exhausted() == "" and b.cost_unenforceable("ep")
    priced = lb.Pricing({"ep": {"input_per_m": 1.0, "output_per_m": 2.0}})
    b2 = lb.RunBudget(lb.BudgetConfig(max_cost=0.002), priced)
    assert b2.add("ep", 1000, 1000) == 0.003 and "cost limit" in b2.exhausted()


def test_config_files_load_and_zero_means_unlimited(tmp_path):
    cfg = lb.load_budget()
    assert cfg.attempts_per_unit == 3 and cfg.max_tokens > 0
    p = tmp_path / "b.yaml"
    p.write_text("budget: {max_tokens_per_run: 0, max_calls_per_run: null}\nattempts_per_unit: 0\n")
    c = lb.load_budget(p)
    assert c.max_tokens == 0 and c.max_calls == 0 and c.attempts_per_unit == 3 or c.attempts_per_unit == 1
    assert lb.load_pricing().cost("whatever", 10, 10) is None
    assert "not calibrated" in json.dumps(lb.load_pricing().endpoints)


def test_feedback_text_has_classes_and_caveats_only():
    t = validator_feedback(["RESIDUE"], ["SNW-IFF"], 1)
    assert "RESIDUE" in t and "SNW-IFF" in t


def test_usage_view(tmp_path):
    vol = tmp_path / "vol"
    led = lb.ledger_for(vol, "batch-1")
    led.record(run_id="batch-1", unit="u", endpoint="ep", attempt=1, status="completed", tokens_in=10, tokens_out=5,
               cost=None, error_class="")
    led.record(run_id="batch-1", unit="u", endpoint="ep", attempt=2, status="failed", tokens_in=0, tokens_out=0,
               cost=None, error_class="TimeoutError")
    store = LocalStore(REPO, work=tmp_path / "work", volume=vol, samples=tmp_path / "none")
    app.dependency_overrides[get_store] = lambda: store
    try:
        c = TestClient(app)
        d = c.get("/api/usage").json()
        assert d["summary"]["calls"] == 2 and d["summary"]["cost"] is None and d["runs"][0]["run_id"] == "batch-1"
        assert d["summary"]["error_classes"] == {"TimeoutError": 1} and d["budget"]["attempts_per_unit"] == 3
        assert c.get("/api/usage", params={"run_id": "batch-1"}).json()["summary"]["failed"] == 1
        assert c.get("/api/usage", params={"run_id": "other"}).json()["runs"] == []
    finally:
        app.dependency_overrides.clear()
