"""S11: review groups by caveat family, policy-bound group accept, decision carry-over and suggestions (ADR 037)."""
from __future__ import annotations

import json
import pathlib

import pytest
from fastapi.testclient import TestClient

from api.app import app, get_store
from api.store_local import LocalStore
from core import decision_ledger as dl
from core import review_policy as rp
from core.runner import HarnessGates

REPO = pathlib.Path(__file__).resolve().parents[2]


def unit(uid, caveats, origin="transpiled", fp=None, no_code=False):
    return {"unit_id": uid, "engine": "sql", "origin": origin, "status": "resolved", "review_caveats": caveats,
            "fingerprint": fp or f"fp-{uid}", "no_code": no_code, "edited": False}


def gate(gid, units, run="r1"):
    return {"gate_id": gid, "run_id": run, "dataflow_id": gid, "agent": "translation", "status": "interrupted",
            "judges": [], "artifact": {"kind": "translation", "units": units}}


def test_policy_decides_group_eligibility():
    pol = rp.load_policy()
    ok, _ = rp.eligibility(rp.gate_items(gate("a", [unit("u", ["SNW-IFF"])])), pol)
    assert ok
    for caveats, why in ((["SNW-NUMBER-PRECISION"], "individual"), (["SNW-LATERAL-FLATTEN"], "escalate"),
                         (["SNW-STAGE-COLUMN"], "block"), (["NOT-A-CAVEAT"], "escalate"), ([], "no caveat")):
        ok, reason = rp.eligibility(rp.gate_items(gate("a", [unit("u", caveats)])), pol)
        assert not ok and why in reason
    ok, reason = rp.eligibility(rp.gate_items(gate("a", [unit("u", ["SNW-IFF"], origin="ai")])), pol)
    assert not ok and "ai" in reason
    nc = gate("a", [unit("u", ["SNW-IFF"], no_code=True)])
    assert not rp.eligibility(rp.gate_items(nc), pol)[0]
    # one individual unit keeps the whole gate individual
    mixed = gate("a", [unit("u", ["SNW-IFF"]), unit("v", ["SNW-NUMBER-PRECISION"])])
    assert not rp.eligibility(rp.gate_items(mixed), pol)[0]


def test_groups_by_family_with_risk():
    groups = rp.build_groups([gate("g1", [unit("u1", ["SNW-IFF"])]), gate("g2", [unit("u2", ["SNW-QUALIFY"])]),
                              gate("g3", [unit("u3", ["SNW-NUMBER-PRECISION"])])])
    fams = {g["family"]: g for g in groups}
    assert [a["gate_id"] for a in fams["SNW006"]["acceptable"]] == ["g1", "g2"]
    assert fams["SNW004"]["acceptable"] == [] and fams["SNW004"]["individual"][0]["gate_id"] == "g3"
    assert groups[0]["family"] == "SNW004"          # riskiest first


def test_off_policy_turns_group_accept_off(tmp_path):
    p = tmp_path / "p.yaml"
    p.write_text("group_accept: {enabled: false}\n", encoding="utf-8")
    assert not rp.eligibility(rp.gate_items(gate("a", [unit("u", ["SNW-IFF"])])), rp.load_policy(p))[0]
    assert not rp.load_policy(tmp_path / "missing.yaml").group_enabled


@pytest.fixture
def client(tmp_path):
    vol = tmp_path / "vol"
    for gid, units in (("g1", [unit("u1", ["SNW-IFF"], fp="F1")]), ("g2", [unit("u2", ["SNW-IFF"], fp="F2")]),
                       ("g3", [unit("u3", ["SNW-NUMBER-PRECISION"])])):
        d = vol / gid / f"run-{gid}"
        (d / "gates").mkdir(parents=True)
        (d / "run.json").write_text(json.dumps({"etl_id": gid, "etl_key": gid, "run_id": f"run-{gid}",
                                                "status": "awaiting_review", "held": [{"gate_id": gid}]}))
        (d / "gates" / f"{gid}.json").write_text(json.dumps(gate(gid, units, f"run-{gid}")))
    store = LocalStore(REPO, work=tmp_path / "work", volume=vol, samples=tmp_path / "none")
    app.dependency_overrides[get_store] = lambda: store
    yield TestClient(app), store
    app.dependency_overrides.clear()


def test_group_accept_records_per_gate_and_refuses_individual(client):
    c, store = client
    groups = c.get("/api/review/groups").json()["groups"]
    g6 = next(g for g in groups if g["family"] == "SNW006")
    assert {a["gate_id"] for a in g6["acceptable"]} == {"g1", "g2"}
    r = c.post("/api/review/groups/accept", json={"family": "SNW006", "gate_ids": ["g1", "g2", "g3"],
                                                  "actor": "rev@x.invalid", "note": "reviewed the pattern"}).json()
    assert r["accepted"] == ["g1", "g2"] and r["refused"][0]["gate_id"] == "g3"
    fb = pathlib.Path(store.work) / "feedback"
    assert (fb / "g1.approval.json").exists() and (fb / "g2.approval.json").exists()      # one record per gate
    assert not (fb / "g3.approval.json").exists()
    left = [g["gate_id"] for g in c.get("/api/gates", params={"open_only": True}).json()]
    assert left == ["g3"]
    # an individual gate cannot be pushed through the group route even when named in its own family
    bad = c.post("/api/review/groups/accept", json={"family": "SNW004", "gate_ids": ["g3"], "actor": "r@x.invalid"}).json()
    assert bad["accepted"] == [] and "individual" in bad["refused"][0]["reason"]
    assert c.post("/api/review/groups/accept", json={"family": "NOPE", "gate_ids": ["g3"], "actor": "r"}).status_code == 404
    # the ledger has a row per unit, approve, with the reviewer
    rows = dl.for_store(store).rows()
    assert {(r["unit_id"], r["decision"], r["reviewer"]) for r in rows} == {("u1", "approve", "rev@x.invalid"),
                                                                           ("u2", "approve", "rev@x.invalid")}


def test_suggestions_come_from_similar_past_decisions(client):
    c, store = client
    c.post("/api/review/groups/accept", json={"family": "SNW006", "gate_ids": ["g1"], "actor": "rev@x.invalid",
                                              "note": "fine"})
    s = c.get("/api/review/suggestions", params={"gate_id": "g2"}).json()["units"]["u2"]
    assert s[0]["basis"] == "same_caveats" and s[0]["decision"] == "approve" and s[0]["count"] == 1
    assert s[0]["last_reviewer"] == "rev@x.invalid" and "fine" in s[0]["rationale"]
    assert c.get("/api/review/suggestions", params={"gate_id": "nope"}).status_code == 404


def test_carry_over_needs_same_statement_and_caveats(tmp_path):
    led = dl.DecisionLedger(tmp_path / "l.jsonl")
    g = gate("g", [unit("a", ["SNW-IFF"], fp="FA"), unit("b", ["SNW-QUALIFY"], fp="FB")])
    dl.record_feedback(led, g, approve=True, reviewer="rev", decision_id="d1")
    payload = {"artifact": {"units": [unit("a2", ["SNW-IFF"], fp="FA"), unit("b2", ["SNW-QUALIFY"], fp="FB")]}}
    gates = HarnessGates(ledger=led)
    d = gates.decide("translation", payload, origins=["transpiled"], review_caveats=["SNW-IFF"], gate_id="g")
    assert d.status == "approved" and d.reused_from == "ledger:d1" and d.reviewer == "rev"
    # a changed statement, a changed caveat set, an AI unit, a no-code unit: all stay open
    for u in (unit("a", ["SNW-IFF"], fp="CHANGED"), unit("a", ["SNW-IFF", "SNW-HASH"], fp="FA"),
              unit("a", ["SNW-IFF"], origin="ai", fp="FA"), unit("a", ["SNW-IFF"], fp="FA", no_code=True)):
        p = {"artifact": {"units": [u]}}
        assert gates.decide("translation", p, origins=[u["origin"]], review_caveats=["x"], gate_id="g").status == "open"
    assert HarnessGates().decide("translation", payload, origins=["transpiled"], gate_id="g").status == "open"
    # a rejected earlier decision never carries over
    led2 = dl.DecisionLedger(tmp_path / "l2.jsonl")
    dl.record_feedback(led2, g, approve=False, reviewer="rev", decision_id="d2")
    assert HarnessGates(ledger=led2).decide("translation", payload, origins=["transpiled"], gate_id="g").status == "open"
