"""S13: deploy plan order and digest, idempotent statements, approval bound to the digest, results, rollback, verify."""
from __future__ import annotations

import json
import pathlib

import pytest
from fastapi.testclient import TestClient

from agents.cd_codegen.translate.artifacts import write_artifact
from api import deploy_routes
from api.app import app, get_store
from api.store_local import LocalStore
from core import deploy as dp
from packs.snowflake.warehouse import FakeWarehouse

REPO = pathlib.Path(__file__).resolve().parents[2]
TEXTS = {
    "t": "CREATE OR REPLACE TABLE main.s.orders (id INT)",
    "v": "-- a view\nCREATE VIEW main.s.v_orders AS SELECT * FROM main.s.orders",
    "f": "CREATE FUNCTION main.s.fx(a INT) RETURNS INT RETURN a + 1",
    "f2": "CREATE OR REPLACE FUNCTION main.s.fy(a INT) RETURNS INT RETURN main.s.fx(a)",
    "i": "INSERT INTO main.s.orders SELECT 1",
    "d": "DROP TABLE main.s.orders",
    "py": "print('x')",
}


def report(order=("v", "f2", "f", "t"), status="migrated"):
    rows = []
    for n, k in enumerate(order):
        kind = "python" if k == "py" else "statement"
        rows.append({"etl_id": k, "name": k, "order": n, "status": status, "artifacts": [{"ref": k, "kind": kind, "name": k}]})
    return {"batch_run_id": "b1", "etls": rows, "assembly": {"status": "approved"}}


def build(rep=None, **kw):
    return dp.build_plan(rep or report(), lambda ref: TEXTS[ref], **kw)


def test_order_is_dependency_order_and_statements_idempotent():
    plan = build(assembly_dir=None)
    assert [s["kind"] for s in plan["steps"]] == ["schema", "table", "function", "function", "view"]
    # callee before caller: fx has no order hint, so the registration order given by the manifest decides (f2 listed
    # before f here); with the assembly's udf_order the callee wins
    by = {s["object"]: s for s in plan["steps"]}
    assert by["main.s.orders"]["sql"].startswith("CREATE TABLE IF NOT EXISTS") and "OR REPLACE" not in by["main.s.orders"]["sql"]
    assert "never replaced" in by["main.s.orders"]["note"]
    assert by["main.s.v_orders"]["sql"].startswith("-- a view\nCREATE OR REPLACE VIEW main.s.v_orders")
    assert by["main.s.fx"]["sql"].startswith("CREATE OR REPLACE FUNCTION")
    assert plan["steps"][0]["sql"] == "CREATE SCHEMA IF NOT EXISTS main.s"
    assert [s["index"] for s in plan["steps"]] == [1, 2, 3, 4, 5]


def test_udf_order_file_puts_callee_first(tmp_path):
    a = tmp_path / "assembly"
    a.mkdir()
    (a / "udf_order.json").write_text(json.dumps(["f", "f2"]))
    plan = build(assembly_dir=a)
    assert [s["object"] for s in plan["steps"] if s["kind"] == "function"] == ["main.s.fx", "main.s.fy"]


def test_non_ddl_destructive_and_unmigrated_are_excluded_not_deployed():
    plan = build({"batch_run_id": "b", "etls": [
        {"etl_id": "i", "name": "i", "order": 0, "status": "migrated", "artifacts": [{"ref": "i", "kind": "statement"}]},
        {"etl_id": "d", "name": "d", "order": 1, "status": "migrated", "artifacts": [{"ref": "d", "kind": "statement"}]},
        {"etl_id": "t", "name": "t", "order": 2, "status": "awaiting_review", "artifacts": [{"ref": "t", "kind": "statement"}]}]})
    assert plan["steps"] == [] and "nothing to deploy" in plan["problems"][0]
    reasons = " ".join(e["reason"] for e in plan["excluded"])
    assert "runs in a job" in reasons and "never drops" in reasons and "awaiting_review" in reasons
    for t in TEXTS.values():
        assert not any("DROP" in (s.get("sql") or "").upper() for s in build().get("steps", []))
        _ = t


def test_digest_changes_with_any_step_and_is_checked():
    p1, p2 = build(), build(report(order=("v", "f", "t")))
    assert p1["digest"] != p2["digest"]
    dp.approved(p1, p1["digest"])
    with pytest.raises(ValueError):
        dp.approved(p1, p2["digest"])
    tampered = {**p1, "steps": p1["steps"][:-1]}
    with pytest.raises(ValueError):
        dp.approved(tampered, p1["digest"])
    blocked = build({"batch_run_id": "b", "etls": []})
    with pytest.raises(ValueError):
        dp.approved(blocked, blocked["digest"])


def test_jobs_are_paused_and_need_an_approved_assembly(tmp_path):
    a = tmp_path / "assembly" / "jobs"
    a.mkdir(parents=True)
    (a / "j.json").write_text(json.dumps({"name": "load", "schedule": {"quartz_cron_expression": "0 0 1 * * ?", "pause_status": "UNPAUSED"},
                                          "tasks": [{"task_key": "t", "sql_task": {"warehouse_id": "${var.warehouse_id}"}}],
                                          "review_reasons": ["x"], "external_predecessors": ["y"]}))
    plan = build(assembly_dir=tmp_path / "assembly", warehouse_id="wh1")
    job = plan["steps"][-1]
    assert job["kind"] == "job" and job["spec"]["schedule"]["pause_status"] == "PAUSED"
    assert "review_reasons" not in job["spec"] and "wh1" in json.dumps(job["spec"])
    open_ = report()
    open_["assembly"] = {"status": "open"}
    plan2 = build(open_, assembly_dir=tmp_path / "assembly")
    assert not [s for s in plan2["steps"] if s["kind"] == "job"] and "assembly is not approved" in str(plan2["excluded"])


def test_execute_runs_in_order_stops_on_failure_and_keeps_error_class_only():
    plan = build()
    fake = dp.FakeDeployer(fail_on={"fy": "ROUTINE_NOT_FOUND"})
    res = dp.execute_plan(plan, plan["digest"], fake, lambda r: TEXTS[r])
    assert res["status"] == "failed"
    st = {r["object"]: r for r in res["steps"]}
    assert st["main.s.fy"]["status"] == "failed" and st["main.s.fy"]["error_class"] == "ROUTINE_NOT_FOUND"
    assert st["main.s.v_orders"]["status"] == "skipped"            # nothing runs after a failure
    assert "scripted" not in json.dumps(res) and "CREATE" not in json.dumps(res["steps"])


def test_success_verifies_and_rollback_drops_only_what_was_created():
    plan = build()
    fake = dp.FakeDeployer(existing={"main.s.orders"}, warehouse=FakeWarehouse())
    res = dp.execute_plan(plan, plan["digest"], fake, lambda r: TEXTS[r])
    assert res["status"] == "passed" and res["verified"]["status"] == "passed"
    assert {o["name"] for o in res["verified"]["objects"]} == {"main.s.orders", "main.s.v_orders", "main.s.fx", "main.s.fy"}
    rb = res["rollback"]
    assert "DROP VIEW IF EXISTS main.s.v_orders;" in rb.splitlines()
    assert "-- DROP TABLE IF EXISTS main.s.orders;" in rb                # existed before: never a live line
    assert all(line.startswith("--") or line.startswith("DROP ") for line in rb.splitlines())
    assert plan["rollback"].count("\nDROP") == 0                         # the plan-time script is all comments
    # second run changes nothing it should not: tables are IF NOT EXISTS, nothing dropped
    assert not any("DROP" in c[1].upper() for c in fake.calls if c[0] == "sql")


def test_verify_without_warehouse_is_unverifiable_never_passed():
    plan = build()
    res = dp.execute_plan(plan, plan["digest"], dp.FakeDeployer(), lambda r: TEXTS[r])
    assert res["status"] == "passed" and res["verified"]["status"] == "unverifiable"


def test_changed_digest_never_runs():
    plan = build()
    fake = dp.FakeDeployer()
    with pytest.raises(ValueError):
        dp.execute_plan(plan, "0" * 64, fake, lambda r: TEXTS[r])
    assert fake.calls == []


# ---------------------------------------------------------------------------------------------------- the API
@pytest.fixture
def api(tmp_path):
    vol = tmp_path / "vol"
    rows = []
    for n, (k, text) in enumerate(TEXTS.items()):
        if k in ("py", "d", "i", "f2"):
            continue
        stored = write_artifact(vol, "k1", text, kind="statement")
        rows.append({"etl_id": k, "name": k, "order": n, "status": "migrated",
                     "artifacts": [{"ref": stored.artifact_ref, "kind": "statement", "name": k}]})
    (vol / "batches" / "k1").mkdir(parents=True)
    (vol / "batches" / "k1" / "batch-b1.json").write_text(json.dumps({"batch_run_id": "batch-b1", "etls": rows}))
    store = LocalStore(REPO, work=tmp_path / "work", volume=vol, samples=tmp_path / "none")
    fake = dp.FakeDeployer(warehouse=FakeWarehouse())
    app.dependency_overrides[get_store] = lambda: store
    app.dependency_overrides[deploy_routes.get_deployer] = lambda: fake
    yield TestClient(app), fake, vol
    app.dependency_overrides.clear()


def test_api_plan_approve_run_rollback(api):
    c, fake, vol = api
    state = c.get("/api/batches/batch-b1/deploy").json()
    digest = state["plan"]["digest"]
    assert state["approval"] is None and state["runs"] == []
    # not approved: refused, nothing executed
    r = c.post("/api/batches/batch-b1/deploy/run", json={"digest": digest, "actor": "a@x.invalid"})
    assert r.status_code == 409 and fake.calls == []
    # approval for a stale digest is refused
    assert c.post("/api/batches/batch-b1/deploy/approve", json={"digest": "0" * 64, "actor": "a@x.invalid"}).status_code == 409
    ok = c.post("/api/batches/batch-b1/deploy/approve", json={"digest": digest, "actor": "a@x.invalid"})
    assert ok.status_code == 200 and ok.json()["approver"] == "a@x.invalid"
    run = c.post("/api/batches/batch-b1/deploy/run", json={"digest": digest, "actor": "a@x.invalid"}).json()
    assert run["status"] == "passed" and run["approved_by"] == "a@x.invalid"
    assert [s["status"] for s in run["steps"]] == ["succeeded"] * len(run["steps"])
    assert c.get("/api/batches/batch-b1/deploy").json()["runs"][0]["plan_digest"] == digest
    rb = c.get("/api/batches/batch-b1/deploy/rollback")
    assert rb.status_code == 200 and "attachment" in rb.headers["content-disposition"] and "DROP" in rb.text
    # the plan changes (a new artifact appears): the old approval no longer covers it
    rp = vol / "batches" / "k1" / "batch-b1.json"
    doc = json.loads(rp.read_text())
    s = write_artifact(vol, "k1", "CREATE VIEW main.s.v2 AS SELECT 1", kind="statement")
    doc["etls"].append({"etl_id": "n", "name": "n", "order": 9, "status": "migrated",
                        "artifacts": [{"ref": s.artifact_ref, "kind": "statement", "name": "n"}]})
    rp.write_text(json.dumps(doc))
    assert c.post("/api/batches/batch-b1/deploy/run", json={"digest": digest}).status_code == 409
    assert c.get("/api/batches/nope/deploy").status_code == 404


def test_api_without_a_warehouse_deploys_nothing(api):
    c, _, _ = api
    app.dependency_overrides[deploy_routes.get_deployer] = lambda: None
    digest = c.get("/api/batches/batch-b1/deploy").json()["plan"]["digest"]
    c.post("/api/batches/batch-b1/deploy/approve", json={"digest": digest, "actor": "a@x.invalid"})
    assert c.post("/api/batches/batch-b1/deploy/run", json={"digest": digest}).status_code == 501
