"""Evaluation tests (Core Development Guide §8) — QUALITY, not contract.

These are SLOW, may call a real/recorded model, and DO NOT gate CI. They measure the
quality of AI output (translation correctness, classification quality, accuracy vs
target) rather than whether the code honours its interfaces. They run on demand
(`pytest -m eval`) or on a schedule — never on the PR gate.

Everything here is marked ``@pytest.mark.eval`` so the default contract run
(`pytest -m "not eval"`) skips it. This file is a placeholder establishing the
separation; real eval sets land here as models/prompts mature.
"""
import pytest

pytestmark = pytest.mark.eval


@pytest.mark.skip(reason="placeholder — real eval sets require a live/recorded model")
def test_translation_quality_placeholder():
    ...
