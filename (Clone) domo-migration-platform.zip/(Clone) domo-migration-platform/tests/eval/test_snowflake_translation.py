"""P3-11 (ADR 032 section 8): the offline translation eval over ``snowflake_translation.yaml``.

NOT marked ``eval``: it runs in the default pytest run (no model, no Lakebridge, no Databricks). Tier 1 is a
``FakeTranspiler`` driven through the real phase A, tier 2 a scripted translator, tier 3 the human. It reports
coverage per tier and caveat recall and fails on the YAML ``gates``. Add a case here with every new caveat or rule."""
from __future__ import annotations

import asyncio
import pathlib

import yaml

from agents.cd_codegen.translate.chain import TranslationSettings
from agents.cd_codegen.translate.ports import FakeTranspiler
from agents.cd_codegen.translate.twophase import run_phase_a
from packs.snowflake import translate as tr
from packs.snowflake.fakes import ScriptedTranslator

SUITE = yaml.safe_load((pathlib.Path(__file__).with_name("snowflake_translation.yaml")).read_text(encoding="utf-8"))
TABLE_MAP = {tuple(e["key"]): e["target"] for e in SUITE["table_map"]}


def run_case(case: dict, work: pathlib.Path) -> tuple[dict, list[tr.UnitResult]]:
    cid = case["id"]
    doc = {"etl_id": cid, "asset_id": f"acme-prod.SALES_DB.CORE.{cid}", "engine": case["engine"], "name": cid,
           "definition": case["sql"], "params": {}}
    settings = TranslationSettings(lakebridge_enabled=bool(case.get("transpiler")))
    ctx = tr.make_context(etl_key=cid, engine=case["engine"], table_map=TABLE_MAP, default_db="SALES_DB",
                          default_schema="CORE", settings=settings)
    if case.get("transpiler"):
        units = tr.phase_a_units(doc, ctx)
        fake = FakeTranspiler({units[0].path: case["transpiler"]})
        ctx.tier1_cache = run_phase_a(fake, units, source_dialect="snowflake", work=work / cid).cache
    if case.get("llm"):
        ctx.llm = ScriptedTranslator({case["sql"].lower(): case["llm"]})
    return case, asyncio.run(tr.translate_etl(doc, ctx))


def tier_of(r: tr.UnitResult) -> int:
    if r.status != "resolved":
        return 3
    return {"mapped": 0, "transpiled": 1, "ai": 2}[r.origin]


def evaluate(work: pathlib.Path) -> dict:
    expected = found = 0
    tiers = dict.fromkeys(range(4), 0)
    per_case = {}
    for case in SUITE["cases"]:
        _, results = run_case(case, work)
        unit = results[0]
        per_case[case["id"]] = unit
        tiers[tier_of(unit)] += 1
        want = set(case.get("caveats") or [])
        expected += len(want)
        found += len(want & set(unit.caveats))
    n = len(SUITE["cases"])
    return {"recall": found / expected if expected else 1.0, "tiers": tiers, "n": n,
            "resolved_share": (n - tiers[3]) / n, "units": per_case}


def test_every_case_lands_on_its_expected_tier(tmp_path):
    rep = evaluate(tmp_path)
    for case in SUITE["cases"]:
        unit = rep["units"][case["id"]]
        assert tier_of(unit) == case["tier"], (case["id"], unit.origin, unit.status, unit.reasons, unit.attempts)
        if case.get("origin"):
            assert unit.origin == case["origin"], case["id"]
        if case.get("review"):
            assert unit.review_caveats, f"{case['id']}: a review caveat must hold the sql gate"
        if case["tier"] in (1, 2):
            assert unit.needs_review, f"{case['id']}: transpiled / ai output is never auto-approved"
        if case["tier"] == 2:
            assert unit.state == "inferred" and unit.confidence is not None, case["id"]
        if case["tier"] == 1:
            assert unit.state == "derived" and any(a["tier"] == 1 and a["tool"] for a in unit.attempts), case["id"]


def test_gates_coverage_per_tier_and_caveat_recall(tmp_path):
    g, rep = SUITE["gates"], evaluate(tmp_path)
    print(f"snowflake translation eval: tiers={rep['tiers']} recall={rep['recall']:.2f} "
          f"resolved={rep['resolved_share']:.2f}")
    assert rep["recall"] >= g["caveat_recall"]
    assert rep["resolved_share"] >= g["min_resolved_share"]
    assert rep["tiers"][0] >= g["tier0_min_cases"]


def test_no_unit_record_carries_source_text(tmp_path):
    rep = evaluate(tmp_path)
    for case in SUITE["cases"]:
        blob = str(rep["units"][case["id"]].record())
        assert case["sql"] not in blob, case["id"]
