"""S15 (ADR 037 section 7): the Snowflake conversion benchmark. The real corpus must be well-formed, cover every row of
catalogue section 1, and meet the CURRENT-baseline gates (``tests/fixtures/snowflake/conversion/gates.yaml``);
the runner itself is tested on tiny synthetic corpora. Offline: tier 0 only (hard rule 10)."""
from __future__ import annotations

import json
import pathlib
import re

import pytest
import yaml

from packs.snowflake import benchmark as bm

REPO = pathlib.Path(__file__).resolve().parents[4]
CATALOGUE = REPO / "docs" / "plans" / "snowflake-conversion-catalogue.md"


@pytest.fixture(scope="module")
def corpus():
    return bm.load_corpus()


@pytest.fixture(scope="module")
def outcomes(corpus):
    return bm.run_all(corpus)


# ------------------------------------------------------------------------------------------------ the corpus
def test_corpus_is_well_formed(corpus):
    assert bm.validate_corpus(corpus) == []
    assert len(corpus) >= 90


def test_every_section_1_row_has_a_case_with_data(corpus):
    rows = {f"1.{i}" for i in range(1, 28)}
    have = {c.row for c in corpus if c.silent}
    assert rows <= have, f"missing section 1 rows: {sorted(rows - have)}"
    for c in corpus:
        if c.silent:
            assert c.data is not None and "tables" in c.data and "expect" in c.data, c.id


def test_a_representative_subset_of_sections_2_to_6(corpus):
    other = [c for c in corpus if not c.silent]
    assert len(other) >= 30
    assert {c.section for c in other} == {"2", "3", "4", "5", "6"}
    assert {c.cls for c in corpus} == set(bm.CLASSES)            # all five classifications are exercised


@pytest.mark.skipif(not CATALOGUE.exists(), reason="the repository docs are not next to the migrator")
def test_every_case_names_a_real_catalogue_row_and_section_1_is_complete(corpus):
    text = CATALOGUE.read_text(encoding="utf-8")
    rows = set(re.findall(r"^\| (\d\.\d+) \|", text, re.M))
    assert {c.row for c in corpus} <= rows, sorted({c.row for c in corpus} - rows)
    section1 = {r for r in rows if r.startswith("1.")}
    assert section1 <= {c.row for c in corpus}


def test_expected_texts_parse_as_databricks_sql(corpus):
    import sqlglot
    for c in corpus:
        if c.sql and c.engine in ("sql_procedure", "task"):
            # SQL scripting is not parsable by sqlglot (ADR 037 S1): a procedure / task body expectation is a labelled
            # compound statement, compared as normalized text; its inner statements are parsed one by one
            assert c.sql.lstrip().startswith("main: BEGIN"), c.id
        elif c.sql and c.engine != "object:sequence":              # an identity clause is a column fragment, not a statement  # noqa: E501
            sqlglot.parse_one(c.sql, read="databricks")          # a malformed expectation would score as a miss


# ------------------------------------------------------------------------------------------------ the gates
def test_current_baseline_gates_pass(outcomes):
    result = bm.evaluate(outcomes)
    assert bm.check_gates(result, bm.load_gates()) == []
    assert result["overall"]["residue_clean_rate"] == 1.0         # nothing resolved at tier 0 carries residue


def test_the_baseline_is_deterministic(outcomes):
    again = bm.evaluate(bm.run_all())
    assert again == bm.evaluate(outcomes)


def test_no_silent_row_converts_without_the_expected_sql_or_a_flag(outcomes):
    """S17a (ADR 037 section 8): every catalogue section 1 case is either converted to the expected Databricks text or
    flagged with a caveat; none returns different numbers without anybody being told."""
    unsafe = [o.case.id for o in outcomes if o.case.silent and not o.silent_safe]
    assert unsafe == []
    s1 = bm.evaluate(outcomes)["sections"]["1"]
    assert s1["silent_safe_rate"] == 1.0 and s1["sql_match_rate"] == 1.0 and s1["deterministic_rate"] == 1.0


def test_gates_file_is_a_ratchet_floor_not_above_the_current_values(outcomes):
    result = bm.evaluate(outcomes)
    gates = bm.load_gates()
    for name, floor in gates["overall"].items():
        assert result["overall"][name] is not None and floor <= result["overall"][name] + 1e-9
    assert set(gates["sections"]) <= set(result["sections"])


# ------------------------------------------------------------------------------------------------ the runner
def _write(tmp_path, cases, gates=None):
    (tmp_path / "corpus_1_x.yaml").write_text(yaml.safe_dump({"cases": cases}), encoding="utf-8")
    if gates is not None:
        (tmp_path / "gates.yaml").write_text(yaml.safe_dump(gates), encoding="utf-8")
    return tmp_path


CASES = [
    {"id": "1.1-ok", "row": "1.1", "title": "t", "class": "rule", "input": "SELECT a FROM t",
     "sql": "SELECT a FROM t", "data": {"tables": {"T": {"columns": ["A"], "rows": [[1]]}}, "expect": [[1]]}},
    {"id": "1.2-wrong", "row": "1.2", "title": "t", "class": "rule", "input": "SELECT a FROM t",
     "sql": "SELECT b FROM t", "data": {"tables": {}, "expect": None, "note": "n/a"}},
    {"id": "2.1-flag", "row": "2.1", "title": "t", "class": "flag",
     "input": "SELECT a FROM t MATCH_RECOGNIZE (PARTITION BY a MEASURES 1 AS m PATTERN (x) DEFINE x AS true)"},
    {"id": "6.1-unrouted", "row": "6.1", "title": "t", "class": "not_migrated", "engine": None,
     "input": "CREATE WAREHOUSE w"},
]


def test_metrics_math_on_a_tiny_corpus(tmp_path):
    cases = bm.load_corpus(_write(tmp_path, CASES))
    assert bm.validate_corpus(cases) == []
    outs = {o.case.id: o for o in bm.run_all(cases)}
    assert outs["1.1-ok"].observed == "mapped" and outs["1.1-ok"].sql_match is True
    assert outs["1.2-wrong"].observed == "mapped" and outs["1.2-wrong"].sql_match is False
    assert outs["1.2-wrong"].silent_safe is False                  # converted, not the expected text, nobody told
    assert outs["2.1-flag"].observed == "escalated" and outs["2.1-flag"].flagged
    assert outs["6.1-unrouted"].observed == "unrouted" and outs["6.1-unrouted"].flagged
    m = bm.evaluate(list(outs.values()))
    assert m["overall"]["deterministic_rate"] == 1.0              # both rule cases resolve at tier 0
    assert m["overall"]["silent_safe_rate"] == 0.5                # 1.1 correct, 1.2 silently wrong
    assert m["overall"]["flag_correct_rate"] == 1.0
    assert m["overall"]["sql_match_rate"] == 0.5
    assert m["overall"]["denominators"]["silent_safe_rate"] == 2
    assert sorted(m["sections"]) == ["1", "2", "6"]


def test_corpus_validation_names_each_problem(tmp_path):
    bad = [{"id": "1.1-x", "row": "1.1", "title": "t", "class": "magic", "input": "SELECT 1"},
           {"id": "1.1-x", "row": "9.9", "title": "t", "class": "rule", "input": " "},
           {"id": "1.3-y", "row": "1.3", "title": "t", "class": "rule", "input": "SELECT 1",
            "data": {"tables": {"T": {"columns": ["A", "B"], "rows": [[1]]}}, "expect": None}}]
    problems = "\n".join(bm.validate_corpus(bm.load_corpus(_write(tmp_path, bad))))
    for needle in ("duplicate case id 1.1-x", "class 'magic'", "row '9.9'", "empty input",
                   "expect is null without a note", "rows that do not match its columns"):
        assert needle in problems, needle


def test_gate_checking_fails_below_a_threshold_and_skips_empty_metrics(tmp_path):
    result = bm.evaluate(bm.run_all(bm.load_corpus(_write(tmp_path, CASES))))
    ok = {"overall": {"silent_safe_rate": 0.5}, "sections": {"1": {"silent_safe_rate": 0.5}}}
    assert bm.check_gates(result, ok) == []
    fails = bm.check_gates(result, {"min_cases": 99, "overall": {"silent_safe_rate": 0.9},
                                    "sections": {"2": {"sql_match_rate": 1.0}, "6": {"flag_correct_rate": 1.0}}})
    assert any("silent_safe_rate 0.5000 < 0.9000" in f for f in fails) and any("corpus shrank" in f for f in fails)
    assert not any("section 2" in f for f in fails)               # section 2 has no SQL expectation: skipped


def test_sql_normalization_ignores_case_qualifiers_and_spacing():
    assert bm.sql_equal("select A from main.bench_public.T", "SELECT a   FROM t")
    assert bm.sql_equal("SELECT IF(a > 1, 1, 2) AS x FROM t", "select if(a>1,1,2) as x from t")
    assert not bm.sql_equal("SELECT a FROM t", "SELECT b FROM t")
    assert bm.normalize_sql("not sql at all ((") == "not sql at all (("


def test_report_and_cli(tmp_path, capsys):
    root = _write(tmp_path, CASES, {"min_cases": 4, "overall": {"deterministic_rate": 1.0}})
    report, js = tmp_path / "r.md", tmp_path / "r.json"
    assert bm.main(["--corpus", str(root), "--report", str(report), "--json", str(js), "--gate"]) == 0
    text = report.read_text(encoding="utf-8")
    assert "| overall | 4 |" in text and "| section 1 | 2 |" in text and "all gates pass" in text
    assert "`1.2-wrong`" in text                                   # listed as a silent row nobody is told about
    assert json.loads(js.read_text(encoding="utf-8"))["overall"]["cases"] == 4
    (root / "gates.yaml").write_text(yaml.safe_dump({"overall": {"silent_safe_rate": 1.0}}), encoding="utf-8")
    assert bm.main(["--corpus", str(root), "--gate", "--report", str(report)]) == 1
    assert "FAIL overall: silent_safe_rate" in report.read_text(encoding="utf-8")


def test_cli_refuses_a_malformed_corpus(tmp_path, capsys):
    root = _write(tmp_path, [{"id": "x", "row": "1.1", "title": "t", "class": "rule", "input": "SELECT 1"}])
    assert bm.main(["--corpus", str(root)]) == 2
    assert "silent row needs data" in capsys.readouterr().err
