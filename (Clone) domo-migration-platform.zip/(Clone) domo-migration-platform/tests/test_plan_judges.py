"""The plan gets checked too.

Before these existed the md_plan gate showed a reviewer "0 checks" on the one
artifact whose approval is the entire point of that gate. The twelve SQL rules
were running, finding no ``[node:]`` markers in a markdown document, and
returning nothing — which is not the same as a clean bill of health, and looked
exactly like one.

Each rule below is written against a failure the plan can really have, and the
tests are the failing document rather than a mock: a rule that cannot be shown
failing on realistic input is not evidence of anything.
"""
from __future__ import annotations

import pathlib

import pytest

from core.contracts.judges import JudgeRegistry, Verdict
from judges.rules import DEFAULT_JUDGES

ROOT = pathlib.Path(__file__).resolve().parents[1]

PLAN = """# ETL Migration: Example — DataFlow 1234

## 1. Pipeline Overview

Reads 1 source, applies 2 steps, writes 1 table. 2 of 2 steps were translated
deterministically from DOMO's own tile vocabulary.

## 2. Source Tables

| df_var | Dataset Name | Dataset ID |
|---|---|---|
| `src_a_df` | `Source A` | `abc-123` |

## 3. Execution DAG

```
src_a_df  ->  df_add_formula_s01  (Add Formula)
df_add_formula_s01  ->  df_group_by_s02  (Group By)
df_group_by_s02  ->  cat.gold.out_table  (Output A)
```

## 4. DataFrame Variable Map

| Step | df_var | Node Name | Type |
|---|---|---|---|
| s01 | `df_add_formula_s01` | Add Formula | FORMULA |

## 5. Transformation Plan

### Step s01 | `Add Formula` | `FORMULA`
- **In:** `src_a_df` | **Out:** `df_add_formula_s01` | **Confidence:** `HIGH`
- **Translation:** deterministic

### Step s02 | `Group By` | `AGGREGATE`
- **In:** `df_add_formula_s01` | **Out:** `df_group_by_s02` | **Confidence:** `LOW`
- **Translation:** deterministic

**Semantic caveats — these are what approval is really about:**

- FIRST(x) is order-dependent; recover the tile's ordering.

## 6. Output Targets

| Target | Source Step | Mode | Destination Table |
|---|---|---|---|
| `Output A` | `df_group_by_s02` | `overwrite` | `cat.gold.out_table` |

## 9. Python vs. LLM Coverage Report

2 of 2 steps deterministic.
"""


class _Subject:
    def __init__(self, artifact: str, node_ids=(), meta=None):
        self.artifact = artifact
        self.node_ids = list(node_ids)
        self.meta = meta or {}


def _run(artifact: str, agent: str = "md_plan"):
    panel = JudgeRegistry(list(DEFAULT_JUDGES)).run(agent, _Subject(artifact), iteration=1)
    return {r.rule_id: r for r in panel.results}


# -- scoping ---------------------------------------------------------------- #

def test_the_sql_rules_do_not_run_on_a_plan():
    """A markdown document has no `[node:]` sections, so the SQL structure rules
    would parse nothing and pass. Twelve vacuous passes is a claim that twelve
    things were examined, which is worse than saying nothing."""
    ids = set(_run(PLAN))
    assert "STR001" not in ids and "LIN001" not in ids and "SEM001" not in ids


def test_the_artifact_agnostic_rules_still_run_on_a_plan():
    """Placeholders and credentials are text, not SQL. They apply anywhere."""
    ids = set(_run(PLAN))
    assert {"STR003", "POL001"} <= ids


def test_the_plan_rules_do_not_run_on_sql():
    ids = set(_run("-- [node: a] op=SELECT\na AS (SELECT 1)\n", agent="cd_codegen"))
    assert not any(i.startswith("MD") for i in ids)


def test_a_plan_gate_is_no_longer_zero_checks():
    assert len(_run(PLAN)) == 7


# -- MD001: the sections codegen reads -------------------------------------- #

def test_a_missing_section_fails_and_says_what_breaks():
    """Section 6 gone means every CTE is generated and nothing is written
    anywhere — and the extractor reports no error, it just returns less."""
    without = PLAN.replace("## 6. Output Targets", "## 66. Output Targets")
    r = _run(without)["MD001"]
    assert r.verdict is Verdict.FAIL
    assert "section 6" in r.findings[0].message
    assert "nothing is written" in r.findings[0].detail


def test_a_complete_plan_passes_MD001():
    assert _run(PLAN)["MD001"].verdict is Verdict.PASS


# -- MD002: the extractor's three fields ------------------------------------ #

def test_a_step_without_an_out_fails():
    """The worst way a plan can be wrong: the step still reads as planned work,
    and simply never appears in the SQL."""
    broken = PLAN.replace("| **Out:** `df_group_by_s02` ", "")
    r = _run(broken)["MD002"]
    assert r.verdict is Verdict.FAIL
    assert r.findings[0].node == "s02"
    assert "Out" in r.findings[0].message


def test_every_step_is_counted_not_just_the_broken_one():
    assert _run(PLAN)["MD002"].checked == 2


# -- MD003: the DAG and the step list must agree ---------------------------- #

def test_a_dag_node_with_no_step_section_fails():
    """The step is in the DAG and has no entry describing it."""
    orphan = PLAN.replace("### Step s02 | `Group By` | `AGGREGATE`",
                          "### Step sZZ | `Group By` | `AGGREGATE`").replace(
        "| **Out:** `df_group_by_s02` |", "| **Out:** `df_renamed_s02` |")
    r = _run(orphan)["MD003"]
    assert r.verdict is Verdict.FAIL
    assert "df_group_by_s02" in [f.node for f in r.findings]


def test_an_input_nothing_produces_fails():
    """The mirror failure, and the worse one: the plan reads as if the data comes
    from somewhere and never says where. Checking only the destination end of
    each edge missed this entirely."""
    orphan = PLAN.replace("df_group_by_s02  ->  cat.gold.out_table",
                          "df_ghost_s09  ->  cat.gold.out_table")
    r = _run(orphan)["MD003"]
    assert r.verdict is Verdict.FAIL
    assert r.findings[0].node == "df_ghost_s09"


def test_a_declared_output_table_is_a_legitimate_end_of_an_edge():
    """A write target is produced by no step and is not a source. Flagging it
    would make every correct plan fail — which is what a first version of this
    rule did on the real 8099 plan."""
    assert _run(PLAN)["MD003"].verdict is Verdict.PASS


def test_a_source_is_a_legitimate_start():
    assert "src_a_df" not in [f.node for f in _run(PLAN)["MD003"].findings]


# -- MD004: low confidence must be explained -------------------------------- #

def test_a_low_confidence_step_with_no_caveat_warns():
    silent = PLAN.replace(
        "**Semantic caveats — these are what approval is really about:**\n\n"
        "- FIRST(x) is order-dependent; recover the tile's ordering.\n", "")
    r = _run(silent)["MD004"]
    assert r.verdict is Verdict.WARN
    assert r.findings[0].node == "s02"


def test_a_low_confidence_step_that_states_its_caveat_passes():
    r = _run(PLAN)["MD004"]
    assert r.verdict is Verdict.PASS
    assert r.checked == 1, "the LOW step must actually have been examined"


def test_it_is_a_warning_not_a_failure():
    """An unexplained caveat is a gap in the document, not a broken artifact.
    Rendering it as a failure is how everything starts looking like a failure."""
    silent = PLAN.replace("- FIRST(x) is order-dependent; recover the tile's ordering.", "")
    assert _run(silent)["MD004"].verdict is not Verdict.FAIL


# -- MD005: the coverage split ---------------------------------------------- #

def test_a_plan_that_never_states_its_split_warns():
    quiet = PLAN.replace("deterministically", "carefully").replace(
        "2 of 2 steps deterministic.", "All steps done.")
    assert _run(quiet)["MD005"].verdict is Verdict.WARN


def test_the_real_plan_states_its_split():
    assert _run(PLAN)["MD005"].verdict is Verdict.PASS


# -- against the real artifact ---------------------------------------------- #

def test_every_rule_passes_on_the_plan_the_pipeline_actually_wrote():
    """The rules must hold on real output, not only on a fixture written to fit
    them. This is the test that caught `-> None` in the execution DAG."""
    plans = sorted((ROOT / "ex_volume").glob("*/run-*/md/plan_*.md"))
    if not plans:
        pytest.skip("no plan on ex_volume; run scripts/e2e_mock_run.py first")
    results = _run(plans[-1].read_text(encoding="utf-8"))
    bad = {rid: r.verdict.value for rid, r in results.items() if r.verdict is Verdict.FAIL}
    assert not bad, f"{plans[-1].name}: {bad}"
    assert results["MD002"].checked > 0, "no steps were examined; the parser is broken"
    assert results["MD003"].checked > 0, "no DAG edges were examined"
