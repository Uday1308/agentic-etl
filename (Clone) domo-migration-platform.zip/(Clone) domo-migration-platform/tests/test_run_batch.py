"""The batch runner: a wave-planner handoff bundle in, every ETL migrated in manifest order, one batch report out.

The bundle here is synthetic (two tiny standardized dataflows, the second reading the first's output) so the test
pins the CONTRACT - ordering, naming from the manifest, dependency skips, the prerequisites list - not any export.
"""
from __future__ import annotations

import json
import pathlib

import pytest

from scripts.run_batch import approvals_of, load_bundle, prerequisites, run_batch, selection_key


def flow(df_id: str, src: str, out: str) -> dict:
    return {df_id: {
        "id": int(df_id), "name": f"etl {df_id}",
        "inputs": [{"dataSourceId": f"{src}-id", "dataSourceName": src}],
        "outputs": [{"dataSourceId": f"{out}-id", "dataSourceName": out}],
        "actions": [
            {"id": "a1", "name": "src", "type": "source", "logic": {"datasetName": src, "dataSourceId": f"{src}-id"}},
            {"id": "a2", "name": "Add Formula", "type": "formula",
             "logic": {"expressions": [{"outputColumn": "c", "expression": "UPPER(`a`)"}]}},
            {"id": "a3", "name": out, "type": "sink", "logic": {"datasetName": out, "versionChainType": "REPLACE"}},
        ],
        "connections": [{"from": "a1", "to": "a2"}, {"from": "a2", "to": "a3"}],
        "disabled_skipped": [],
    }}


def make_bundle(root: pathlib.Path, *, second_definition: bool = True) -> pathlib.Path:
    b = root / "bundle"
    (b / "etls").mkdir(parents=True)
    (b / "etls" / "11.json").write_text(json.dumps(flow("11", "orders", "orders_clean")), encoding="utf-8")
    if second_definition:
        (b / "etls" / "12.json").write_text(json.dumps(flow("12", "orders_clean", "orders_kpi")), encoding="utf-8")
    manifest = {
        "manifest_version": "1", "kind": "etl_logic_migration", "snapshot_id": "domo-x", "strategy": "dependency_waves",
        "strategy_label": "Dependency waves", "selection": {"wave": 1, "batch_ids": ["w1-sales-1"]},
        "source": {"platform": "domo"},
        "target": {"platform": "databricks", "dialect": "sql", "source_catalog": "acme", "source_schema": "landing",
                   "target_catalog": "acme", "target_schema": "sales_silver"},
        "depends_on_batches": [], "temporary_snapshots": [],
        "etls": [
            {"order": 1, "etl_id": "11", "name": "etl 11", "batch_id": "w1-sales-1", "definition": "etls/11.json",
             "depends_on_etls": [], "inputs": [{"dataset_id": "d:orders", "name": "orders", "availability": "source"}]},
            {"order": 2, "etl_id": "12", "name": "etl 12", "batch_id": "w1-sales-1", "definition": "etls/12.json",
             "depends_on_etls": ["11"],
             "inputs": [{"dataset_id": "d:orders_clean", "name": "orders_clean", "availability": "this_batch"}]},
        ],
    }
    (b / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return b


async def test_batch_migrates_in_order_with_manifest_naming(tmp_path: pathlib.Path) -> None:
    rep = await run_batch(make_bundle(tmp_path), volume=tmp_path / "vol", work=tmp_path / "work")
    assert [(r["etl_id"], r["status"]) for r in rep["etls"]] == [("11", "migrated"), ("12", "migrated")]
    assert rep["counts"]["migrated"] == 2 and rep["logic_only"] is True
    assert [p["name"] for p in rep["prerequisites"]] == ["orders"]          # only true source data is listed
    sql = "\n".join(p.read_text(encoding="utf-8") for p in (tmp_path / "vol").rglob("etl_11__*.sql"))
    assert "acme.landing." in sql and "dev_test" not in sql                 # naming came from the manifest
    assert pathlib.Path(rep["report_path"]).exists()


async def test_a_missing_definition_fails_and_dependants_are_blocked(tmp_path: pathlib.Path) -> None:
    b = make_bundle(tmp_path, second_definition=False)
    m = json.loads((b / "manifest.json").read_text(encoding="utf-8"))
    m["etls"].reverse()                                                    # 12 (no definition) first
    m["etls"][0]["order"], m["etls"][1]["order"] = 1, 2
    m["etls"][1]["depends_on_etls"] = ["12"]
    (b / "manifest.json").write_text(json.dumps(m), encoding="utf-8")
    rep = await run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work", keep_going=True)
    assert [(r["etl_id"], r["status"]) for r in rep["etls"]] == [("12", "failed"), ("11", "blocked")]  # ADR 032 s3


def test_manifest_contract_is_checked(tmp_path: pathlib.Path) -> None:
    b = make_bundle(tmp_path)
    m = json.loads((b / "manifest.json").read_text(encoding="utf-8"))
    assert prerequisites(m)[0]["needed_by"] == ["11"]
    (b / "manifest.json").write_text(json.dumps({**m, "manifest_version": "9"}), encoding="utf-8")
    with pytest.raises(SystemExit, match="not supported"):
        load_bundle(b)


async def test_hand_picked_etls_run_as_a_batch_of_one(tmp_path: pathlib.Path) -> None:
    """New run -> Pick ETLs: the bundle names ETLs instead of batches; the same runner migrates them."""
    b = make_bundle(tmp_path)
    m = json.loads((b / "manifest.json").read_text(encoding="utf-8"))
    m["selection"] = {"wave": None, "batch_ids": [], "etl_ids": ["12"]}
    m["etls"] = [{**m["etls"][1], "order": 1, "batch_id": "w1-sales-1",
                  "inputs": [{"dataset_id": "d:orders_clean", "name": "orders_clean", "availability": "other_batch",
                              "batch_id": "w1-sales-1"}]}]
    (b / "manifest.json").write_text(json.dumps(m), encoding="utf-8")
    rep = await run_batch(b, volume=tmp_path / "vol", work=tmp_path / "work")
    assert [(r["etl_id"], r["status"]) for r in rep["etls"]] == [("12", "migrated")]
    assert rep["selection"]["etl_ids"] == ["12"] and rep["counts"]["migrated"] == 1
    assert [p["name"] for p in rep["prerequisites"]] == ["orders_clean"]  # its producer is not in this run
    assert pathlib.Path(rep["report_path"]).parent == tmp_path / "vol" / "batches" / "etls-12"


def test_selection_key_names_batches_waves_and_picked_etls() -> None:
    assert selection_key({"wave": 1, "batch_ids": ["a", "b"]}) == "a-b"
    assert selection_key({"wave": 2, "batch_ids": []}) == "wave-2"
    assert selection_key({"wave": None, "batch_ids": [], "etl_ids": ["8099", "8774"]}) == "etls-8099-8774"
    assert selection_key({"batch_ids": [], "etl_ids": ["1", "2", "3", "4"]}) == "etls-1-and-3-more"


def test_resume_reads_approvals_where_the_api_store_writes_them(tmp_path: pathlib.Path) -> None:
    """--work is the store ROOT; LocalStore writes decisions under <root>/.platform_local/feedback. Reading
    <root>/feedback instead made every resume miss the human approvals (Apply approvals looped)."""
    fb = tmp_path / ".platform_local" / "feedback"
    fb.mkdir(parents=True)
    (fb / "gate-translation-x-ab12.approval.json").write_text(json.dumps(
        {"approve": True, "payload_hash": "h1", "reviewer": "lead@example.invalid"}), encoding="utf-8")
    row = {"run_dir": str(tmp_path / "run"), "review_gates": [{"gate_id": "gate-translation-x-ab12",
                                                               "agent": "translation"}]}
    got = approvals_of(row, tmp_path)
    assert got == {"translation": {"payload_hash": "h1", "reviewer": "lead@example.invalid",
                                   "decision_id": "gate-translation-x-ab12"}}
