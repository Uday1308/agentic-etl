"""SQL tile renderers — the shared deterministic layer both agents use.

Renderers emit CTE bodies: a bare SELECT, no CREATE OR REPLACE prefix and no
semicolon, because materialization is a deliberate human decision.
"""
from __future__ import annotations

import pytest

from core.domo.tiles import SqlTileRegistry, sql_type, tile_registry

REG = tile_registry("sql")


def _r(node, inputs=("src",), out="out"):
    return REG.render(node, list(inputs), out)


def test_registry_dialect_selection():
    assert isinstance(tile_registry("sql"), SqlTileRegistry)
    assert tile_registry("pyspark").find("filter") is not None
    with pytest.raises(ValueError, match="unknown dialect"):
        tile_registry("tsql")


def test_bodies_are_plain_selects_without_materialization():
    """Stored preference and design decision: no CREATE OR REPLACE, no semicolon."""
    for node in ({"type": "filter", "properties": {"conditions": [
                     {"column": "a", "operator": "EQUALS", "value": "x"}]}},
                 {"type": "select", "properties": {"columns": ["a"]}},
                 {"type": "groupBy", "properties": {"groupBy": ["k"], "aggregations": [
                     {"function": "SUM", "column": "amt", "alias": "t"}]}}):
        code = _r(node).code
        assert code.lstrip().upper().startswith("SELECT")
        assert "CREATE" not in code.upper() and not code.rstrip().endswith(";")


def test_formula_tile_annotates_each_mapping_with_its_domo_source():
    r = _r({"type": "formula", "properties": {"expressions": [
        {"name": "Period End Date", "expression": "LAST_DAY(`Date`)"}]}})
    assert r.resolved
    assert "-- DOMO : LAST_DAY(`Date`)" in r.code
    # delta_safe is the default column policy (core/domo/naming.py): the alias is the
    # sanitized name the landed table carries
    assert "last_day(`Date`) AS `Period_End_Date`" in r.code
    assert r.expressions[0]["source"] == "python"


def test_formula_escalates_only_the_bad_expression():
    r = _r({"type": "formula", "properties": {"expressions": [
        {"name": "good", "expression": "MONTH(`d`)"},
        {"name": "bad", "expression": "WEIRD_FN(`d`)"}]}})
    assert not r.resolved and r.unresolved == ["WEIRD_FN"]
    assert r.expressions[0]["source"] == "python" and r.expressions[1]["source"] == "llm"


def test_join_drops_duplicated_right_keys():
    """DOMO tolerates duplicate column names across inputs; SQL does not."""
    r = _r({"type": "join", "properties": {
        "joinKeys": [{"left": "Supplier", "right": "Company Name"}], "joinType": "left"}},
        inputs=("plant", "mapping"))
    assert r.resolved
    assert "rt.* EXCEPT (`Company_Name`)" in r.code
    assert "LEFT JOIN mapping AS rt" in r.code
    assert r.join_keys == [{"left": "Supplier", "right": "Company Name"}]


def test_join_without_keys_escalates_but_cross_is_allowed_with_a_warning():
    assert not _r({"type": "join", "properties": {}}, inputs=("a", "b")).resolved
    cross = _r({"type": "join", "properties": {"joinType": "cross"}}, inputs=("a", "b"))
    assert cross.resolved and any("cross join" in n for n in cross.notes)


def test_decimal_cast_maps_to_double_like_domo_output():
    """DOMO's own output renders a DECIMAL-cast column as DOUBLE (core/domo/tiles.py
    ``sql_type``); DECIMAL(18, 2) was a type mismatch against the DOMO table."""
    r = _r({"type": "alterColumns", "properties": {"column_changes": [
        {"name": "Invoice Amount", "type": "DECIMAL"}]}})
    assert "AS DOUBLE) AS `Invoice_Amount`" in r.code


def test_bare_decimal_is_never_emitted():
    for t in ("DECIMAL", "NUMERIC", "MONEY", "CURRENCY"):
        emitted = sql_type(t)[0]
        assert emitted == "DOUBLE" and emitted != "DECIMAL"


def test_first_aggregation_is_flagged_low():
    r = _r({"type": "groupBy", "properties": {"groupBy": ["k"], "aggregations": [
        {"function": "FIRST", "column": "rate", "alias": "rate"}]}})
    assert r.confidence == "LOW" and any("order-dependent" in n for n in r.notes)


def test_group_by_select_list_is_comma_separated():
    r = _r({"type": "groupBy", "properties": {
        "groupBy": ["Company", "Period End Date"],
        "aggregations": [{"function": "SUM", "column": "amt", "alias": "t"}]}})
    assert "  `Company`\n  , `Period_End_Date`" in r.code
    assert "GROUP BY `Company`, `Period_End_Date`" in r.code


def test_filter_strips_the_domo_quote_artifact():
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Paying Company", "operator": "NOT_EQUALS", "value": "DIAM"}]}})
    assert "regexp_replace" in r.code and "<> 'DIAM'" in r.code


def test_filter_in_and_not_in():
    r = _r({"type": "filter", "properties": {"conditions": [
        {"column": "Company", "operator": "IN", "value": ["ASMI", "DIAM"]}]}})
    assert "`Company` IN ('ASMI', 'DIAM')" in r.code


def test_union_warns_that_sql_matches_by_position():
    """DOMO's append matches by name; UNION ALL matches by position."""
    r = _r({"type": "append", "properties": {}}, inputs=("a", "b", "c"))
    assert r.code.count("UNION ALL") == 2
    assert any("column order" in n for n in r.notes)


def test_dynamic_unpivot_escalates_when_value_columns_are_unknown():
    """DOMO resolves them at run time; SQL cannot, so guessing is not an option."""
    r = _r({"type": "normalizeall", "properties": {"id_columns": ["a"]}})
    assert not r.resolved and "resolved at run time" in r.unresolved[0]


def test_unpivot_renders_when_value_columns_are_stated():
    r = _r({"type": "unpivot", "properties": {
        "id_columns": ["Base Currency"], "value_columns": ["USD", "CAD"],
        "name_column": "Exchange Currency", "value_column": "Oracle Exchange Rate"}})
    assert r.resolved and "stack(2, 'USD', `USD`, 'CAD', `CAD`)" in r.code


def test_sort_warns_that_cte_ordering_is_not_guaranteed():
    r = _r({"type": "sort", "properties": {"orderBy": [
        {"column": "d", "direction": "desc"}]}})
    assert "ORDER BY `d` DESC" in r.code
    assert any("outermost SELECT" in n for n in r.notes)


def test_unknown_tile_escalates_rather_than_guessing():
    r = _r({"type": "RiskScore", "properties": {}})
    assert not r.resolved and "RiskScore" in r.unresolved[0] and r.confidence == "LOW"


def test_a_broken_renderer_escalates_instead_of_crashing():
    class Boom:
        op_types = ("BOOM",)

        def render(self, node, inputs, out_var):
            raise RuntimeError("kaboom")

    r = SqlTileRegistry([Boom()]).render({"type": "BOOM"}, [], "out")
    assert not r.resolved and "kaboom" in r.unresolved[0]
