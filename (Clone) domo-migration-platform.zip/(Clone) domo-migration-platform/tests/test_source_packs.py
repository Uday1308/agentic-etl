"""P3-02 (ADR 032 section 1): the SourcePack protocol, the DOMO pack wrapping today's code, the registry
threaded through generate_sql / build_steps, the DOMO pins moved out of logic_parity.py and render.py,
profile_for(platform) per request, and core/common for the generic modules."""
from __future__ import annotations

import ast
import pathlib

import pytest
from fastapi.testclient import TestClient

from agents.cd_codegen.sql_generator import build_steps, generate_sql
from core.domo.tiles import tile_registry
from core.packs import (
    SourcePack,
    UnknownSourcePlatform,
    get_pack,
    known_platforms,
    missing_parts,
    register_pack,
    unregister_pack,
)

APP = pathlib.Path(__file__).resolve().parents[1]

FLOW = {
    "dataflow_id": "77",
    "nodes": [
        {"id": "n1", "name": "Feed", "category": "SOURCE", "type": "DataSet",
         "properties": {"dataset_name": "feed", "dataSourceId": "abc"}},
        {"id": "n2", "name": "Add Formula 1", "type": "formula", "properties": {
            "expressions": [{"name": "Up", "expression": "UPPER(`a`)"}]}},
        {"id": "n3", "name": "Out", "category": "TARGET", "type": "Target",
         "properties": {"dataset_name": "out", "write_mode": "REPLACE"}},
    ],
    "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
}


def test_the_domo_pack_satisfies_the_protocol_and_wraps_todays_code():
    pack = get_pack("domo")
    assert isinstance(pack, SourcePack) and missing_parts(pack) == []
    assert pack.platform == "domo" and pack.source_dialect == "domo_beastmode"
    assert type(pack.registry("sql")) is type(tile_registry("sql"))
    assert pack.registry("pyspark").find("filter") is not None
    assert pack.contract.is_raw_export({"onboardFlowVersion": {}}) in (True, False)
    assert pack.expressions.translate("UPPER(`a`)", dialect="sql").code.lower().startswith("upper(")
    assert pack.vocabulary.op_of({"type": "formula"}) == "FORMULA"
    assert pack.caveats.literals_sensitive is False and pack.caveats.as_of_column == "_BATCH_LAST_RUN_"
    assert pack.profile.unit == "dataflow" and pack.profile.step == "tile"
    assert get_pack(None) is pack and get_pack(" DOMO ") is pack


def test_an_unknown_platform_is_refused_not_guessed():
    with pytest.raises(UnknownSourcePlatform, match="informatica"):
        get_pack("informatica")


class _SpyRegistry:
    def __init__(self):
        self.inner, self.calls = tile_registry("sql"), 0

    def render(self, node, inputs, out):
        self.calls += 1
        return self.inner.render(node, inputs, out)


class _SpyPack:
    """A DOMO pack whose registry is observed: proves the pack, not core.domo, is asked."""

    def __init__(self):
        base = get_pack("domo")
        for name in ("platform", "source_dialect", "version", "contract", "vocabulary", "expressions",
                     "caveats", "profile", "collaborators"):
            setattr(self, name, getattr(base, name))
        self.platform = "spy"
        self.spy = _SpyRegistry()
        self.asked: list[str] = []

    def registry(self, target_dialect="sql"):
        self.asked.append(target_dialect)
        return self.spy


def test_generate_sql_renders_through_the_packs_registry():
    pack = _SpyPack()
    register_pack("spy", lambda: pack)
    try:
        assert "spy" in known_platforms()
        gen = generate_sql(FLOW, dataflow_id="77", pack=get_pack("spy"), materialize=False)
    finally:
        unregister_pack("spy")
    assert pack.asked == ["sql"]                 # one registry for the plan and the CTEs
    assert pack.spy.calls >= 2                   # PlanRenderer and build_steps both used it
    assert gen.succeeded and gen.coverage == "1/1 deterministic, 0 by model, 0 unresolved"


def test_build_steps_takes_a_registry():
    gen = generate_sql(FLOW, dataflow_id="77", materialize=False)
    spy = _SpyRegistry()
    steps, _ = build_steps(gen.build, FLOW["nodes"], registry=spy)
    assert spy.calls == 1 and [s.origin for s in steps] == ["mapped"]


def _module_level_imports(path: pathlib.Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    out = set()
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module)
        elif isinstance(node, ast.Import):
            out |= {a.name for a in node.names}
    return out


@pytest.mark.parametrize("rel", ["core/contracts/logic_parity.py", "agents/md_plan/render.py",
                                 "agents/cd_codegen/sql_generator.py"])
def test_domo_pins_are_behind_the_pack(rel):
    pins = {m for m in _module_level_imports(APP / rel) if m.startswith(("core.domo.tiles", "core.domo.expr"))}
    assert pins == set(), f"{rel} still imports {pins} at module level"


def test_logic_parity_keeps_its_helpers_through_the_pack():
    from core.contracts.logic_parity import columns_read, reads_in_order

    node = {"type": "formula", "properties": {"expressions": [
        {"name": "m", "expression": "MONTH(`d`)"}, {"name": "n", "expression": "`m` + 1"}]}}
    assert columns_read(node) == {"d", "m"}
    assert reads_in_order(node) == [({"d"}, "m"), ({"m"}, "n")]


def test_the_stale_md_plan_tiles_copy_is_gone():
    assert not (APP / "agents" / "md_plan" / "tiles.py").exists()


def test_core_common_is_the_same_module_as_core_domo():
    import core.common.naming as common_naming
    import core.domo.naming as domo_naming

    assert common_naming is domo_naming


def test_profile_is_picked_per_request(monkeypatch):
    from api.app import app
    from api.profile import profile_for

    monkeypatch.delenv("MIGRATION_SOURCE", raising=False)
    assert profile_for().source.id == "domo" and profile_for().source.unit == "dataflow"
    snow = profile_for("snowflake").source
    assert (snow.unit, snow.step, snow.ready) == ("object", "statement", True)
    client = TestClient(app)
    assert client.get("/api/meta").json()["profile"]["source"]["id"] == "domo"
    got = client.get("/api/meta", headers={"X-Srcintel-Source-Platform": "snowflake"}).json()
    assert got["profile"]["source"]["id"] == "snowflake" and got["profile"]["source"]["unit"] == "object"
