"""P3-04 (ADR 032 section 3): the tier framework. ChainTranslator / TranslationAttempt / Resolution,
the coverage dict with derived read-only aliases (DOMO goldens unchanged), artifact refs with sha256
and masked previews, the access-checked artifact endpoint, and prompt masking for literal-sensitive packs."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from agents.cd_codegen.sql_generator import generate_sql, generate_sql_with_tail
from agents.cd_codegen.translate.artifacts import (
    ArtifactError,
    masked_preview,
    read_artifact,
    verify,
    write_artifact,
)
from agents.cd_codegen.translate.attempt import Resolution, TranslationAttempt, unit_fingerprint
from agents.cd_codegen.translate.chain import (
    ChainTranslator,
    HumanTier,
    LakebridgeTier,
    LlmTier,
    TranslationConfigError,
    TranslationSettings,
    coverage_of,
)
from core.literals import mask_literals

FLOW = {
    "dataflow_id": "88",
    "nodes": [
        {"id": "n1", "name": "Feed", "category": "SOURCE", "type": "DataSet",
         "properties": {"dataset_name": "feed", "dataSourceId": "abc"}},
        {"id": "n2", "name": "Add Formula 1", "type": "formula", "properties": {
            "expressions": [{"name": "Up", "expression": "UPPER(`a`)"}]}},
        {"id": "n3", "name": "Risk", "type": "RiskScore", "properties": {}},
        {"id": "n4", "name": "Out", "category": "TARGET", "type": "Target",
         "properties": {"dataset_name": "out", "write_mode": "REPLACE"}},
    ],
    "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}, {"from": "n3", "to": "n4"}],
}
RISK = "s02"


class _Answer:
    def __init__(self, step_id, sql="", confidence=None, why=""):
        self.step_id, self.sql, self.confidence, self.why_not = step_id, sql, confidence, why

    @property
    def usable(self):
        return bool(self.sql)


class ScriptedTranslator:
    """FakeLLM-style tier-2 translator: answers from a script, records what it was asked."""

    def __init__(self, answers: dict[str, tuple[str, float | None]]):
        self.answers, self.asked = answers, []

    async def resolve_tail(self, build, **_):
        out = {}
        for item in build.unresolved:
            self.asked.append(item)
            sql, conf = self.answers.get(item["step"], ("", None))
            out[item["step"]] = _Answer(item["step"], sql, conf, "" if sql else "model declined")
        return out


def _item(step="s1", **kw):
    return {"step": step, "reasons": ["unrecognised tile type 'X'"], **kw}


async def test_tier_order_first_success_wins_and_unavailable_is_not_a_failure():
    llm = ScriptedTranslator({"s1": ("SELECT 1 AS x FROM up", 0.9)})
    chain = ChainTranslator([LakebridgeTier(None), LlmTier(llm), HumanTier()])
    res = (await chain.resolve_tail(type("B", (), {"unresolved": [_item()]})()))["s1"]
    assert [(a.tier, a.status) for a in res.attempts] == [(0, "failed"), (1, "unavailable"), (2, "ok")]
    assert not res.attempts[1].counts_as_failure
    r = res.resolution
    assert (r.origin, r.state, r.confidence) == ("ai", "inferred", 0.9) and r.sha256 and res.usable
    assert not res.awaiting_review


async def test_a_later_tier_never_runs_after_success_and_transpiled_names_an_allow_listed_tool():
    llm = ScriptedTranslator({"s1": ("SELECT 2 AS x FROM up", 0.99)})
    cache = {"s1": {"sql": "SELECT 1 AS x FROM up", "tool": "BladeBridge", "tool_version": "0.9"}}
    chain = ChainTranslator([LakebridgeTier(cache), LlmTier(llm)])
    res = (await chain.resolve_tail(type("B", (), {"unresolved": [_item(source_text="select 1")]})()))["s1"]
    assert res.resolution.origin == "transpiled" and res.resolution.state == "derived"
    assert res.attempts[-1].tool == "bladebridge" and llm.asked == []


async def test_a_non_allow_listed_transpiler_fails_tier_1_and_the_reason_reaches_tier_2():
    llm = ScriptedTranslator({"s1": ("SELECT 2 AS x FROM up", 0.8)})
    cache = {"s1": {"sql": "SELECT 1", "tool": "switch"}}
    chain = ChainTranslator([LakebridgeTier(cache), LlmTier(llm)])
    res = (await chain.resolve_tail(type("B", (), {"unresolved": [_item(source_text="select 1")]})()))["s1"]
    assert res.attempts[1].status == "failed" and "not allow-listed" in res.attempts[1].reasons[0]
    assert any("not allow-listed" in r for r in llm.asked[0]["reasons"])
    assert res.resolution.origin == "ai"


async def test_low_confidence_and_validation_failures_escalate_to_human_review():
    llm = ScriptedTranslator({"s1": ("SELECT 1 AS x FROM up", 0.4), "s2": ("DROP TABLE t", 0.95)})
    chain = ChainTranslator([LlmTier(llm), HumanTier()], min_confidence=0.7,
                            validate=lambda sql: ["not a SELECT"] if not sql.upper().startswith("SELECT") else [])
    out = await chain.resolve_tail(type("B", (), {"unresolved": [_item("s1"), _item("s2")]})())
    for sid in ("s1", "s2"):
        assert out[sid].resolution is None and out[sid].awaiting_review and not out[sid].usable
        assert out[sid].attempts[-1].tier == 3
    assert "below min_confidence" in out["s1"].why_not and "not a SELECT" in out["s2"].why_not


async def test_a_block_caveat_goes_straight_to_tier_3():
    llm = ScriptedTranslator({"s1": ("SELECT 1", 0.99)})
    chain = ChainTranslator([LakebridgeTier({}), LlmTier(llm), HumanTier()], block_caveats={"SNW-X"})
    res = (await chain.resolve_tail(type("B", (), {"unresolved": [_item(caveats=["SNW-X"])]})()))["s1"]
    assert llm.asked == [] and res.awaiting_review
    assert [(a.tier, a.status) for a in res.attempts][1:] == [(1, "skipped"), (2, "skipped"), (3, "skipped")]


async def test_the_post_pass_runs_on_every_tier_output():
    """A tier-2 draft naming the source table is rewritten to the landed one before validation."""
    llm = ScriptedTranslator({"s1": ("SELECT * FROM SALES.PUBLIC.ORDERS", 0.9)})
    chain = ChainTranslator([LlmTier(llm)], postpass=lambda s: s.replace("SALES.PUBLIC.ORDERS", "main.sales.orders"),
                            validate=lambda s: ["unmapped source table"] if "SALES.PUBLIC" in s else [])
    res = (await chain.resolve_tail(type("B", (), {"unresolved": [_item()]})()))["s1"]
    assert res.sql == "SELECT * FROM main.sales.orders"


def test_settings_validate_tiers_and_refuse_removed_or_llm_backed_options():
    s = TranslationSettings.from_dict({"lakebridge": {"enabled": True, "transpilers": ["morpheus"]}})
    assert s.tiers == ("lakebridge", "llm", "human") and s.min_confidence == 0.7 and s.unverified_cap == 0.5
    with pytest.raises(TranslationConfigError, match="review_transpiled was removed"):
        TranslationSettings.from_dict({"review_transpiled": False})
    with pytest.raises(TranslationConfigError, match="allow-list"):
        TranslationSettings.from_dict({"lakebridge": {"transpilers": ["switch"]}})
    with pytest.raises(TranslationConfigError, match="order"):
        TranslationSettings(tiers=("llm", "lakebridge"))
    chain = ChainTranslator.from_settings(s, translator=None)
    assert [t.tier for t in chain.tiers] == [1, 2, 3]


def test_resolution_and_attempt_records_follow_hard_rule_9():
    with pytest.raises(ValueError, match="confidence"):
        Resolution(origin="ai", state="inferred", sql="SELECT 1")
    with pytest.raises(ValueError):
        TranslationAttempt(tier=1, status="maybe")
    r = Resolution(origin="transpiled", state="derived", sql="SELECT 'x'", trace=[TranslationAttempt(1, "ok")])
    assert r.needs_review and "sql" not in r.to_record() and r.to_record()["sha256"] == r.sha256
    ok = r.confirm("rev@example.invalid", sha256=r.sha256)
    assert (ok.origin, ok.state, ok.reviewed_by, ok.needs_review) == ("transpiled", "confirmed",
                                                                      "rev@example.invalid", False)
    with pytest.raises(ValueError, match="changed"):
        r.confirm("rev@example.invalid", sha256="0" * 64)
    assert unit_fingerprint("select  1", source_dialect="snowflake") == unit_fingerprint(
        "select 1", source_dialect="snowflake") != unit_fingerprint("select 1", source_dialect="domo_beastmode")


def test_coverage_dict_and_the_domo_goldens_are_unchanged():
    gen = generate_sql(FLOW, dataflow_id="88", materialize=False)
    assert gen.coverage == "1/2 deterministic, 0 by model, 1 unresolved"      # the pre-ADR-032 string
    assert gen.coverage_split["mapped"] == 1 and gen.coverage_split["unresolved"] == 1
    assert gen.coverage_split["share"]["mapped"] == 50.0 and gen.ai_steps == [] and gen.ai_resolved == {}
    legacy = generate_sql(FLOW, dataflow_id="88", materialize=False,
                          ai_resolved={RISK: "SELECT * FROM df_add_formula_1_s01"})
    assert legacy.ai_steps == [RISK] and legacy.coverage == "1/2 deterministic, 1 by model, 0 unresolved"
    assert legacy.resolved[RISK].origin == "ai" and legacy.ai_resolved == {RISK: "SELECT * FROM df_add_formula_1_s01"}
    assert coverage_of(["mapped", "hybrid", "ai", "weird"])["mapped"] == 2


async def test_generate_sql_with_the_chain_marks_transpiled_ctes():
    cache = {RISK: {"sql": "SELECT * FROM df_add_formula_1_s01", "tool": "morpheus"}}
    chain = ChainTranslator([LakebridgeTier(cache), LlmTier(None), HumanTier()])

    class _WithText:   # DOMO tiles carry no SQL text; give this unit some so tier 1 applies
        def __init__(self, inner):
            self.inner = inner

        async def resolve_tail(self, build, **kw):
            for item in build.unresolved:
                item["source_text"] = "risk"
            return await self.inner.resolve_tail(build, **kw)

    gen = await generate_sql_with_tail(FLOW, translator=_WithText(chain), config=None, dataflow_id="88",
                                       materialize=False)
    assert gen.resolved[RISK].origin == "transpiled" and gen.origins[RISK] == "transpiled"
    assert "origin=transpiled" in gen.succeeded[0].sql
    assert gen.coverage_split["transpiled"] == 1 and gen.ai_steps == []
    assert gen.coverage == "1/2 deterministic, 0 by model, 0 unresolved, 1 transpiled, 0 manual"


def test_artifacts_are_content_addressed_masked_and_verified(tmp_path):
    sql = "SELECT * FROM t WHERE email = 'person@example.invalid' AND n = 'it''s'"
    rec = write_artifact(tmp_path, "src1__etl_9", sql, source_id="src1")
    assert rec.artifact_ref == f"src1__etl_9/{rec.sha256}" and read_artifact(tmp_path, rec.artifact_ref) == sql
    assert "person@example.invalid" not in rec.preview and "'***'" in rec.preview
    verify(tmp_path, rec.artifact_ref, rec.sha256)
    (tmp_path / "src1__etl_9" / "artifacts" / f"{rec.sha256}.sql").write_text(sql + " OR 1=1", encoding="utf-8")
    with pytest.raises(ArtifactError, match="changed"):
        verify(tmp_path, rec.artifact_ref, rec.sha256)
    with pytest.raises(ArtifactError):
        read_artifact(tmp_path, "../etc/" + "0" * 64)
    assert masked_preview("x" * 10, limit=4).endswith("(truncated)")
    assert mask_literals("a $$secret 'x'$$ b") == "a '***' b"


def test_the_artifact_endpoint_checks_role_and_source(tmp_path, monkeypatch):
    from api.app import app, get_store
    from api.store_local import LocalStore

    store = LocalStore(tmp_path, work=tmp_path / "work", volume=tmp_path / "vol")
    rec = write_artifact(tmp_path / "vol", "src1__9", "SELECT 'secret' AS s", source_id="src1")
    app.dependency_overrides[get_store] = lambda: store
    try:
        c = TestClient(app)
        ok = c.get(f"/api/artifacts/{rec.artifact_ref}", headers={"X-Srcintel-Source-Id": "src1"})
        assert ok.status_code == 200 and ok.json()["text"] == "SELECT 'secret' AS s"
        assert ok.json()["sha256"] == rec.sha256
        other = c.get(f"/api/artifacts/{rec.artifact_ref}", headers={"X-Srcintel-Source-Id": "src2"})
        assert other.status_code == 404
        viewer = c.get(f"/api/artifacts/{rec.artifact_ref}",
                       headers={"X-Srcintel-Source-Id": "src1", "X-Srcintel-User-Roles": "viewer"})
        assert viewer.status_code == 403
        assert c.get("/api/artifacts/nope/" + "0" * 64).status_code == 404
        assert c.get("/api/artifacts/bad..ref").status_code == 400
        monkeypatch.setenv("DATABRICKS_APP_PORT", "8000")
        assert c.get(f"/api/artifacts/{rec.artifact_ref}").status_code == 401
        deployed = c.get(f"/api/artifacts/{rec.artifact_ref}",
                         headers={"X-Forwarded-Email": "rev@example.invalid", "X-Srcintel-Source-Id": "src1"})
        assert deployed.status_code == 403                  # no roles forwarded: no unmasked SQL
    finally:
        app.dependency_overrides.pop(get_store, None)


def test_literal_sensitive_packs_mask_prompts_in_every_environment():
    from core.domo.observability import DeltaObservabilityWriter, LlmCallRow

    row = LlmCallRow(obs_run_id="r", thread_id="t", dataflow_id="d", agent="cd_codegen", node="n", role="g",
                     model="m", pool="p", prompt_hash="h",
                     prompt_text="WHERE name = 'Jane Example'", response_text="SELECT 'Jane Example'")
    seen = []
    DeltaObservabilityWriter(capture_text=True, mask_literals=True,
                             sink=lambda t, r: seen.append(r)).record_llm_call(row)
    assert "Jane Example" not in str(seen[0]) and seen[0]["prompt_text"] == "WHERE name = '***'"
    DeltaObservabilityWriter(capture_text=True, sink=lambda t, r: seen.append(r)).record_llm_call(row)
    assert seen[1]["prompt_text"] == "WHERE name = 'Jane Example'"     # DOMO (not sensitive): unchanged
    from core.packs import PackCaveats
    from packs.domo.pack import PACK

    class _Sensitive:
        caveats = PackCaveats(literals_sensitive=True)

    DeltaObservabilityWriter.for_pack(_Sensitive(), sink=lambda t, r: seen.append(r)).record_llm_call(row)
    DeltaObservabilityWriter.for_pack(PACK, sink=lambda t, r: seen.append(r)).record_llm_call(row)
    assert seen[2]["prompt_text"] == "WHERE name = '***'" and seen[3]["prompt_text"] == row.prompt_text
