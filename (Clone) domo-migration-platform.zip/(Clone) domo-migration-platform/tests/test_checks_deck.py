"""The deck must describe the checks the platform actually runs.

``docs/migration_quality_checks.pptx`` is read in review meetings, by people who
will not read the source, at the moment they are deciding whether to trust a
run. Every way it can be wrong is a way to mislead exactly that reader:

* a rule with no slide — they look it up and it is not there;
* a slide for a rule that no longer exists — they look it up and believe it ran;
* a severity that disagrees with the code — they read "warning" and move on from
  something that failed the gate.

The build guards the first two. This guards the third, which is the one that
cannot be caught by looking at the deck.
"""
from __future__ import annotations

import pathlib

import pytest

pytest.importorskip("pptx", reason="python-pptx is not installed")

from pptx import Presentation  # noqa: E402

from judges.rules import DEFAULT_JUDGES  # noqa: E402
from scripts.make_checks_deck import PLAIN, build, finding_verdict  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]
RULE_PREFIXES = ("MD", "STR", "DET", "SEM", "LIN", "POL")


@pytest.fixture(scope="module")
def deck(tmp_path_factory):
    """Built fresh, not read from disk. A committed file that nobody rebuilt is
    exactly the stale artifact these tests exist to rule out."""
    out = build(tmp_path_factory.mktemp("deck") / "checks.pptx")
    return Presentation(out)


def _slides(deck):
    """``rule_id -> the strings on its slide``."""
    out = {}
    for slide in deck.slides:
        texts = [s.text_frame.text for s in slide.shapes
                 if s.has_text_frame and s.text_frame.text.strip()]
        if texts and len(texts[0]) <= 6 and texts[0].startswith(RULE_PREFIXES):
            out[texts[0]] = texts
    return out


def test_every_rule_the_platform_runs_has_a_slide(deck):
    assert set(_slides(deck)) == {j.rule_id for j in DEFAULT_JUDGES}


def test_the_severity_badge_matches_the_code(deck):
    """A rule whose finding fails the gate must not be presented as a warning.

    This is the failure mode with no visible symptom: the deck looks fine, reads
    fine, and quietly tells somebody not to worry about a blocking finding.
    """
    slides = _slides(deck)
    wrong = {}
    for judge in DEFAULT_JUDGES:
        texts = slides[judge.rule_id]
        badge = next((t for t in texts if "finding here" in t), "")
        shown = "WARN" if "WARNING" in badge else "FAIL" if "FAILS" in badge else "?"
        if shown != finding_verdict(judge):
            wrong[judge.rule_id] = (finding_verdict(judge), shown)
    assert not wrong, f"deck and code disagree on severity: {wrong}"


def test_the_title_of_each_slide_is_the_rule_title(deck):
    slides = _slides(deck)
    for judge in DEFAULT_JUDGES:
        assert judge.title in slides[judge.rule_id], judge.rule_id


def test_the_counts_on_the_verdict_slide_are_computed(deck):
    """They were typed once and were wrong — 5 warn / 12 fail against a code that
    said 6 and 11 — on the slide whose subject is not overstating a result."""
    warns = sum(1 for j in DEFAULT_JUDGES if finding_verdict(j) == "WARN")
    fails = len(DEFAULT_JUDGES) - warns
    body = " ".join(s.text_frame.text for slide in deck.slides
                    for s in slide.shapes if s.has_text_frame)
    assert f"{warns} of the {len(DEFAULT_JUDGES)} rules warn" in body
    assert f"{fails} of the {len(DEFAULT_JUDGES)} rules fail" in body


def test_unverifiable_is_explained(deck):
    """It is a real verdict a reviewer will see, and the one they ask about."""
    body = " ".join(s.text_frame.text for slide in deck.slides
                    for s in slide.shapes if s.has_text_frame)
    assert "UNVERIFIABLE" in body
    assert "Never counted as a pass" in body
    assert "When a check cannot run at all" in body


def test_a_rule_without_a_slide_fails_the_build(tmp_path):
    """The guard that stops someone adding a judge and forgetting the deck."""
    saved = PLAIN.pop("SEM003")
    try:
        with pytest.raises(SystemExit, match="SEM003"):
            build(tmp_path / "x.pptx")
    finally:
        PLAIN["SEM003"] = saved


def test_a_slide_for_a_rule_that_no_longer_exists_fails_the_build(tmp_path):
    PLAIN["ZZZ999"] = dict(means="", matters="", ok="", bad="")
    try:
        with pytest.raises(SystemExit, match="ZZZ999"):
            build(tmp_path / "x.pptx")
    finally:
        del PLAIN["ZZZ999"]


def test_the_committed_deck_is_not_stale():
    """Rebuild and compare the rule set. The .pptx is a zip with timestamps, so
    the bytes differ on every build — the content is what has to match."""
    committed = ROOT / "docs" / "migration_quality_checks.pptx"
    if not committed.exists():
        pytest.skip("deck has not been built; run scripts/make_checks_deck.py")
    on_disk = _slides(Presentation(committed))
    assert set(on_disk) == {j.rule_id for j in DEFAULT_JUDGES}, (
        "the committed deck does not match the current rules; re-run "
        "scripts/make_checks_deck.py")
