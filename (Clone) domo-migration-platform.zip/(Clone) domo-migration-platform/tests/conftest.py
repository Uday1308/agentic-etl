"""Shared fakes and fixtures for the core contract suite and the agent suites.

One source of truth: agent tests re-export from here (see
agents/cd_codegen/tests/conftest.py) so a fake never diverges between suites.

Everything here is hermetic — no Spark, no network, no serving endpoint. A contract
test that needs any of those belongs in tests/integration/ instead.
"""
from __future__ import annotations

import datetime as _dt
import pathlib
import sys
from typing import Any

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from core.domo.llm import RawCompletion  # noqa: E402
from core.domo.observability import LlmCallRow, NodeRow  # noqa: E402


def ts_iso() -> str:
    """A stable ISO-8601 UTC timestamp for fixtures."""
    return _dt.datetime(2026, 7, 24, 9, 0, 0, tzinfo=_dt.timezone.utc).isoformat()


class FakeObservability:
    """Collects rows in memory so assertions can inspect what was recorded.

    Deliberately not a mock: tests assert on the CONTENT of the rows (role, model,
    pool, iteration, prompt hash), which is the contract the real writer must honour.
    """

    def __init__(self) -> None:
        self.llm_calls: list[LlmCallRow] = []
        self.node_rows: list[NodeRow] = []

    def record_llm_call(self, row: LlmCallRow) -> None:
        self.llm_calls.append(row)

    def record_node(self, row: NodeRow) -> None:
        self.node_rows.append(row)


class TrackingConcurrency:
    """Real semaphore semantics, plus a record of which pools were acquired.

    Lets tests assert that a fan-out actually used its named pool rather than
    silently falling back to the default.
    """

    def __init__(self) -> None:
        self.acquired: list[str] = []
        self.in_flight: dict[str, int] = {}
        self.peak: dict[str, int] = {}

    def acquire(self, pool: str = "default"):
        tracker = self

        class _Slot:
            async def __aenter__(self):
                tracker.acquired.append(pool)
                tracker.in_flight[pool] = tracker.in_flight.get(pool, 0) + 1
                tracker.peak[pool] = max(tracker.peak.get(pool, 0), tracker.in_flight[pool])
                return None

            async def __aexit__(self, *exc):
                tracker.in_flight[pool] -= 1
                return False

        return _Slot()


def make_caller(*, text: str = "ok", fail_times: int = 0, always_fail: bool = False,
                tokens_in: int = 7, tokens_out: int = 3):
    """Build a fake endpoint caller.

    ``fail_times`` raises for the first N calls then succeeds — exercises the retry
    path. ``always_fail`` never succeeds. The caller records every prompt it saw on
    ``.prompts`` so tests can assert on layer ordering.
    """
    state = {"calls": 0}

    def caller(spec, prompt, response_schema, timeout_s):
        state["calls"] += 1
        caller.prompts.append(prompt)
        if always_fail or state["calls"] <= fail_times:
            raise RuntimeError(f"endpoint unavailable (attempt {state['calls']})")
        return RawCompletion(text=text, tokens_in=tokens_in, tokens_out=tokens_out)

    caller.prompts = []
    caller.calls = lambda: state["calls"]
    return caller


def cfg(**configurable: Any) -> dict:
    """A LangGraph RunnableConfig with sensible defaults for the contract suite."""
    base = {
        "thread_id": "t-test",
        "environment": "dev",
        "obs_run_id": "run-test",
        "iteration": 1,
    }
    base.update(configurable)
    return {"configurable": base}


@pytest.fixture
def obs() -> FakeObservability:
    return FakeObservability()


@pytest.fixture
def concurrency() -> TrackingConcurrency:
    return TrackingConcurrency()
