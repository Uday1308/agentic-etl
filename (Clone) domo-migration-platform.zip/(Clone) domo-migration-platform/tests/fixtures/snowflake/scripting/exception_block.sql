-- Synthetic case: an EXCEPTION block with named and OTHER handlers, and a nested block.
DECLARE
  bad_input EXCEPTION (-20001, 'bad input');
BEGIN
  INSERT INTO fact_sales_clean SELECT * FROM fact_sales WHERE amount IS NOT NULL;
  BEGIN
    UPDATE fact_sales_clean SET amount = 0 WHERE amount < 0;
  END;
EXCEPTION
  WHEN bad_input OR expression_error THEN
    INSERT INTO error_log (msg) VALUES ('bad input');
    RAISE;
  WHEN OTHER THEN
    INSERT INTO error_log (msg) VALUES (:sqlerrm);
    RETURN 'failed';
END;
