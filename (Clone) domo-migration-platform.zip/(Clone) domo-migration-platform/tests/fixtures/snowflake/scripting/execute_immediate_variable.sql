-- Synthetic case: EXECUTE IMMEDIATE over a variable (dynamic SQL, not parseable).
DECLARE
  stmt VARCHAR;
BEGIN
  LET target VARCHAR := 'archive_orders';
  stmt := 'INSERT INTO ' || target || ' SELECT * FROM orders';
  EXECUTE IMMEDIATE :stmt;
  RETURN 'ok';
END;
