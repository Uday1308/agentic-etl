-- Synthetic case: nested IF with ELSEIF / ELSE branches.
DECLARE
  run_mode VARCHAR DEFAULT 'full';
  row_limit NUMBER(10, 0) DEFAULT 100;
BEGIN
  IF (:run_mode = 'full') THEN
    TRUNCATE TABLE stage_orders;
    IF (:row_limit > 0) THEN
      INSERT INTO stage_orders SELECT * FROM raw_orders WHERE amount > :row_limit;
    END IF;
  ELSEIF (:run_mode = 'delta') THEN
    DELETE FROM stage_orders WHERE order_date < CURRENT_DATE() - 7;
  ELSE
    INSERT INTO run_log (msg) VALUES ('skipped');
  END IF;
  RETURN 'done';
END;
