-- Synthetic case: RESULTSET declared with a query, iterated, and SELECT ... INTO a variable.
DECLARE
  res RESULTSET DEFAULT (SELECT customer_id, segment FROM dim_customer WHERE segment = 'retail');
  cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO :cnt FROM dim_customer;
  FOR r IN res DO
    UPDATE dim_customer SET last_seen = CURRENT_TIMESTAMP() WHERE customer_id = r.customer_id;
  END FOR;
  RETURN cnt;
END;
