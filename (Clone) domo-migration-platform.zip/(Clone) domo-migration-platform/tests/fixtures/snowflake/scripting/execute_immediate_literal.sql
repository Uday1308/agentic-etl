-- Synthetic case: EXECUTE IMMEDIATE with a string literal and with a $$ literal holding a block.
BEGIN
  EXECUTE IMMEDIATE 'INSERT INTO daily_snapshot SELECT * FROM fact_sales WHERE sale_date = CURRENT_DATE()';
  EXECUTE IMMEDIATE $$
    BEGIN
      DELETE FROM daily_snapshot WHERE sale_date < DATEADD(day, -30, CURRENT_DATE());
    END;
  $$;
  RETURN 'ok';
END;
