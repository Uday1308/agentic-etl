-- Synthetic case: FOR over a declared cursor, with a range loop inside.
DECLARE
  c1 CURSOR FOR SELECT region_id, region_name FROM dim_region WHERE active = TRUE;
  total NUMBER DEFAULT 0;
BEGIN
  FOR rec IN c1 DO
    MERGE INTO region_totals t
      USING (SELECT region_id, SUM(amount) AS amount FROM fact_sales GROUP BY region_id) s
      ON t.region_id = s.region_id
      WHEN MATCHED THEN UPDATE SET t.amount = s.amount
      WHEN NOT MATCHED THEN INSERT (region_id, amount) VALUES (s.region_id, s.amount);
    FOR i IN 1 TO 3 DO
      INSERT INTO audit_log (step) VALUES (:i);
    END FOR;
  END FOR;
  RETURN total;
END;
