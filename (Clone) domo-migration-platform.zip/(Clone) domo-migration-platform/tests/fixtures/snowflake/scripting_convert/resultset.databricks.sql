CREATE OR REPLACE PROCEDURE main.demo_core.p__ret(OUT return_value STRING)
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  main: BEGIN
    DECLARE cnt DECIMAL(38,0);
    SET cnt = (
      SELECT COUNT(*) FROM main.core.dim_customer
    );
    loop_1: FOR r AS
        SELECT customer_id, segment FROM main.core.dim_customer WHERE segment = 'retail'
    DO
      UPDATE main.core.dim_customer SET last_seen = CURRENT_TIMESTAMP() WHERE customer_id = r.customer_id;
    END FOR loop_1;
    SET return_value = cnt;
    LEAVE main;
  END main;
END

CREATE OR REPLACE PROCEDURE main.demo_core.p()
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  DECLARE return_value STRING;
  CALL main.demo_core.p__ret(return_value);
  SELECT return_value AS return_value;
END
