CREATE OR REPLACE PROCEDURE main.demo_core.p__ret(OUT return_value STRING)
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  main: BEGIN
    DECLARE run_mode STRING DEFAULT 'full';
    DECLARE row_limit DECIMAL(10,0) DEFAULT 100;
    IF (run_mode = 'full') THEN
      TRUNCATE TABLE main.core.stage_orders;
      IF (row_limit > 0) THEN
        INSERT INTO main.core.stage_orders SELECT * FROM main.core.raw_orders WHERE amount > row_limit;
      END IF;
    ELSEIF (run_mode = 'delta') THEN
      DELETE FROM main.core.stage_orders WHERE order_date < CURRENT_DATE - 7;
    ELSE
      INSERT INTO main.core.run_log (msg) VALUES ('skipped');
    END IF;
    SET return_value = 'done';
    LEAVE main;
  END main;
END

CREATE OR REPLACE PROCEDURE main.demo_core.p()
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  DECLARE return_value STRING;
  CALL main.demo_core.p__ret(return_value);
  SELECT return_value AS return_value;
END
