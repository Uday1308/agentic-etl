CREATE OR REPLACE PROCEDURE main.demo_core.p__ret(OUT return_value STRING)
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  main: BEGIN
    DECLARE total DECIMAL(38,0) DEFAULT 0;
    loop_1: FOR rec AS
        SELECT region_id, region_name FROM main.core.dim_region WHERE active = TRUE
    DO
      MERGE INTO main.core.region_totals AS t USING (SELECT region_id, SUM(amount) AS amount FROM main.core.fact_sales GROUP BY region_id) AS s ON t.region_id = s.region_id WHEN MATCHED THEN UPDATE SET t.amount = s.amount WHEN NOT MATCHED THEN INSERT (region_id, amount) VALUES (s.region_id, s.amount);
      BEGIN
        DECLARE i BIGINT DEFAULT 1;
        DECLARE i_end_ BIGINT DEFAULT 3;
        loop_2: WHILE i <= i_end_ DO
          body_3: BEGIN
            INSERT INTO main.core.audit_log (step) VALUES (i);
          END body_3;
          SET i = i + 1;
        END WHILE loop_2;
      END;
    END FOR loop_1;
    SET return_value = total;
    LEAVE main;
  END main;
END

CREATE OR REPLACE PROCEDURE main.demo_core.p()
LANGUAGE SQL
SQL SECURITY INVOKER
AS BEGIN
  DECLARE return_value STRING;
  CALL main.demo_core.p__ret(return_value);
  SELECT return_value AS return_value;
END
