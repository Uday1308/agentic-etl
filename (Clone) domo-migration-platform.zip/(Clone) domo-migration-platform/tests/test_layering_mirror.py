"""The browser's copy of the layer invariant must agree with the server's.

``lv-tower/src/layering.js`` reimplements ``core.domo.materialize.violations`` so
the review board can accept or reject a drop in the frame the pointer is
released, without a round trip inside a drag gesture. Two implementations of one
rule drift — silently, and in the direction that matters: the UI accepts a move
the server will later refuse, and the reviewer finds out when the layer files
fail to generate.

So they are compared directly, on the real dataflow graph, over assignments
generated to sit right on the boundary. This is the test that makes the
duplication safe; without it the duplication is just a second place to be wrong.

Skipped when Node is absent — several machines this runs on have no Node at all,
and a skip states that honestly rather than a pass implying a comparison nobody
made.
"""
from __future__ import annotations

import json
import pathlib
import random
import shutil
import subprocess

import pytest

from core.domo.materialize import LAYER_ORDER, UNMATERIALIZED, violations

ROOT = pathlib.Path(__file__).resolve().parents[1]
MIRROR = ROOT / "lv-tower" / "src" / "layering.js"
CHOICES = (*LAYER_ORDER, UNMATERIALIZED)

pytestmark = pytest.mark.skipif(shutil.which("node") is None,
                                reason="Node is not installed; cannot run the browser mirror")


def _latest_gate() -> dict | None:
    """The newest classifier gate on the example volume, for its `deps` map.

    Real lineage rather than a toy chain: the shapes that break a dependency walk
    are diamonds and shared intermediates, and those only show up at scale.
    """
    gates = sorted((ROOT / "ex_volume").glob("*/run-*/gates/*classifier*.json"))
    for path in reversed(gates):
        payload = json.loads(path.read_text(encoding="utf-8"))
        layers = payload.get("layers") or {}
        if layers.get("deps"):
            return layers
    return None


def _js_violations(deps: dict, assignments: list[dict]) -> list[list[dict]]:
    """Run the browser's implementation over the same inputs, in Node."""
    # as_uri(), not the path: Node's ESM loader reads `d:\\...` as a URL scheme
    # named "d" and refuses it. On Windows an absolute import must be file://.
    #
    # The payload arrives on stdin rather than argv. 400 cases over 65 nodes is
    # comfortably past the ~32k Windows command line limit, and the truncation
    # that causes is not an error - it is a JSON parse failure a long way from
    # its cause.
    script = f"""
import {{ violations }} from {json.dumps(MIRROR.as_uri())};
let raw = "";
process.stdin.setEncoding("utf8");
for await (const chunk of process.stdin) raw += chunk;
const {{ deps, cases }} = JSON.parse(raw);
console.log(JSON.stringify(cases.map((a) => violations(deps, a))));
"""
    proc = subprocess.run(
        ["node", "--input-type=module", "-e", script],
        input=json.dumps({"deps": deps, "cases": assignments}),
        capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        pytest.fail(f"the mirror did not run:\n{proc.stderr}")
    return json.loads(proc.stdout)


def _key(v) -> tuple:
    """One violation, comparably. The two sides name the fields differently
    (`depends_on` / `dependsOn`) because each follows its own language's
    conventions; what must match is the finding, not the spelling."""
    if isinstance(v, dict):
        return (v["node"], v["layer"], v["dependsOn"], v["dependsLayer"])
    return (v.node, v.layer, v.depends_on, v.depends_layer)


def test_the_mirror_agrees_with_the_server_on_the_real_graph():
    layers = _latest_gate()
    if not layers:
        pytest.skip("no classifier gate on ex_volume; run scripts/e2e_mock_run.py first")

    deps = layers["deps"]
    nodes = sorted(deps)
    sections = {n: "" for n in nodes}          # violations() only reads the keys
    # The deps map IS the edge set, so the server is fed it directly rather than
    # re-derived from SQL - otherwise this would be comparing two parsers, not
    # two implementations of the rule.
    import core.domo.materialize as mat
    from core.domo.materialize import references  # noqa: F401  (documents the seam)
    original = mat.references
    mat.references = lambda body, names: set(deps.get(body, []))  # noqa: ARG005
    sections = {n: n for n in nodes}           # body == node name, so the stub can key on it
    try:
        rng = random.Random(20260914)
        cases = []
        # The run's own assignment, which must be clean...
        cases.append({n: layer for layer in (*LAYER_ORDER, UNMATERIALIZED)
                      for row in layers.get(layer, []) for n in [row["node"]]})
        # ...and 400 perturbations of it, which mostly will not be.
        for _ in range(400):
            cases.append({n: rng.choice(CHOICES) for n in nodes})

        mine = [sorted(_key(v) for v in violations(sections, a)) for a in cases]
        theirs = [sorted(tuple(t) for t in map(_key, vs)) for vs in _js_violations(deps, cases)]
    finally:
        mat.references = original

    assert len(mine) == len(theirs)
    for i, (a, b) in enumerate(zip(mine, theirs)):
        assert a == b, (
            f"case {i}: the browser and the server disagree.\n"
            f"  server only: {sorted(set(a) - set(b))}\n"
            f"  browser only: {sorted(set(b) - set(a))}")

    # A test that compared two empty lists 401 times would pass and prove nothing.
    assert sum(len(m) for m in mine) > 0, "no case produced a violation; the test is vacuous"


def test_the_message_is_word_for_word_the_same():
    """The reviewer sees this string. It is specified, not incidental."""
    deps = {"b": ["a"]}
    sections = {"a": "a", "b": "b"}
    import core.domo.materialize as mat
    original = mat.references
    mat.references = lambda body, names: set(deps.get(body, []))  # noqa: ARG005
    try:
        mine = violations(sections, {"a": "gold", "b": "silver"})
    finally:
        mat.references = original
    theirs = _js_violations(deps, [{"a": "gold", "b": "silver"}])[0]
    assert len(mine) == len(theirs) == 1
    assert mine[0].message == theirs[0]["message"]
    assert mine[0].message.startswith("Downstream cannot be placed over upstream:")
