"""The medallion split, as SQL somebody runs.

These are not shape tests. A layer file is a deliverable: if it does not parse,
the whole classifier stage produced nothing, and it produced nothing *while
looking finished*, which is the failure mode this repo exists to prevent. So the
assertions here are about runnability — separators, statement terminators, and
whether a reference points at a table that will exist by the time it is read.
"""
from __future__ import annotations

import pytest

from core.domo.materialize import (
    LAYER_ORDER,
    UNMATERIALIZED,
    MaterializeError,
    plan,
    promote,
    references,
    render_all,
    violations,
)


def _sections() -> dict[str, str]:
    """A three-CTE chain in the shape the assembler really emits.

    The trailing ``,`` on each section is the important detail: a section is the
    text between one ``[node:]`` marker and the next, so it carries the separator
    that joined it to the following CTE in the ORIGINAL artifact. A layer
    statement builds its own CTE list and must not inherit that one.
    """
    return {
        "src_a": "-- [node: src_a] op=SOURCE\nsrc_a AS (\n    SELECT * FROM raw.a\n)\n,\n",
        "mid_b": "-- [node: mid_b] op=FILTER\nmid_b AS (\n    SELECT * FROM src_a WHERE x > 0\n)\n,\n",
        "out_c": ("-- [node: out_c] op=GROUPBY\nout_c AS (\n    SELECT x, count(*) FROM mid_b GROUP BY x\n)\n"
                  "\nSELECT *\nFROM out_c\n"),
    }


def _table_of(node: str) -> str:
    return {"src_a": "cat.bronze.a", "out_c": "cat.gold.c"}.get(node, f"cat.silver.{node}")


# -- the separator bug ------------------------------------------------------ #

def test_no_double_comma_between_inlined_ctes():
    """``)\\n,\\n, next AS (`` is not SQL, and it was what this emitted.

    The section's own trailing comma plus the joiner's comma made two. Every
    statement with more than one inlined CTE was unparseable.
    """
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of)
    for layer, body in files.items():
        assert ",\n," not in body, f"{layer} has a doubled CTE separator"
        assert "\n,\nSELECT" not in body, f"{layer} has a comma before its final SELECT"


def test_final_select_follows_the_last_cte_directly():
    """``WITH a AS (...) SELECT`` — no separator before the statement's own body."""
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of)
    gold = files["gold"]
    assert "WITH mid_b AS (" in gold
    # the inlined CTE closes, then the statement's own SELECT begins
    assert ")\nSELECT" in gold


def test_every_statement_is_terminated():
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of)
    creates = sum(b.count("CREATE OR REPLACE TABLE") for b in files.values())
    semis = sum(b.count("\n;") for b in files.values())
    assert creates == semis == 2


# -- what a node is called -------------------------------------------------- #

def test_the_table_name_comes_from_table_of_not_the_cte():
    """A CTE name addresses a spot in one artifact. It is not a table name, and
    for a target it is the wrong name twice over: that output already HAS one."""
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of)
    assert "CREATE OR REPLACE TABLE cat.gold.c AS" in files["gold"]
    assert "CREATE OR REPLACE TABLE out_c" not in files["gold"]


def test_a_materialized_dependency_is_read_as_its_table():
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of)
    assert "FROM cat.bronze.a" in files["gold"]
    assert "FROM src_a" not in files["gold"]


# -- the walk back ---------------------------------------------------------- #

def test_the_walk_back_stops_at_a_materialized_node():
    """Materializing the middle node means gold reads it instead of re-deriving
    it. This is the entire argument for having a silver layer, so it is the thing
    most worth a test."""
    assignment = {"src_a": "bronze", "mid_b": "silver", "out_c": "gold"}
    planned = plan(_sections(), assignment, table_of=_table_of)
    gold = planned["gold"][0]
    assert gold.inlined == []                      # nothing left to inline
    assert gold.reads == ["mid_b"]                 # read as a table
    files = render_all(_sections(), assignment, table_of=_table_of)
    assert "FROM cat.silver.mid_b" in files["gold"]
    assert "WITH" not in files["gold"]


def test_an_unmaterialized_node_is_inlined_into_every_reader():
    sections = dict(_sections())
    sections["out_d"] = ("-- [node: out_d] op=GROUPBY\nout_d AS (\n"
                         "    SELECT x, sum(y) FROM mid_b GROUP BY x\n)\n\nSELECT *\nFROM out_d\n")
    files = render_all(sections,
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED,
                        "out_c": "gold", "out_d": "gold"},
                       table_of=_table_of)
    assert files["gold"].count("mid_b AS (") == 2   # once per statement that needs it


# -- the layer invariant ---------------------------------------------------- #

def test_silver_reading_gold_is_a_violation():
    bad = violations(_sections(), {"src_a": "bronze", "mid_b": "gold", "out_c": "silver"})
    assert len(bad) == 1
    v = bad[0]
    assert (v.node, v.layer, v.depends_on, v.depends_layer) == ("out_c", "silver", "mid_b", "gold")
    assert v.message == ("Downstream cannot be placed over upstream: out_c is silver, "
                         "but it reads mid_b which is gold.")


def test_an_unmaterialized_node_never_constrains_anything():
    """It is inlined, so it is not a table anyone waits for. A reader of an
    unmaterialized node depends on what THAT node reads, not on the node."""
    assert violations(_sections(),
                      {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "silver"}) == []


def test_the_walk_sees_through_an_unmaterialized_node_to_the_real_table():
    """src_a is gold, mid_b is inlined, out_c is silver — so out_c really does
    read a gold table, just not directly. Stopping at mid_b would miss it."""
    bad = violations(_sections(),
                     {"src_a": "gold", "mid_b": UNMATERIALIZED, "out_c": "silver"})
    assert [v.depends_on for v in bad] == ["src_a"]


def test_plan_refuses_a_violating_assignment():
    """Better to fail at generation than to emit a silver script that selects
    from a gold table nothing has created yet."""
    with pytest.raises(MaterializeError, match="Downstream cannot be placed over upstream"):
        plan(_sections(), {"src_a": "bronze", "mid_b": "gold", "out_c": "silver"},
             table_of=_table_of)


def test_promote_raises_and_never_lowers():
    settled = promote(_sections(), {"src_a": "bronze", "mid_b": "gold", "out_c": "silver"})
    assert settled == {"src_a": "bronze", "mid_b": "gold", "out_c": "gold"}
    assert violations(_sections(), settled) == []


def test_promote_is_a_fixpoint_not_one_pass():
    """Raising a node can push its own reader up too, and that reader's reader."""
    sections = dict(_sections())
    sections["out_d"] = ("-- [node: out_d] op=SELECT\nout_d AS (\n    SELECT * FROM out_c\n)\n\n"
                         "SELECT *\nFROM out_d\n")
    settled = promote(sections, {"src_a": "gold", "mid_b": "bronze",
                                 "out_c": "bronze", "out_d": "bronze"})
    assert settled == {"src_a": "gold", "mid_b": "gold", "out_c": "gold", "out_d": "gold"}


# -- guards ----------------------------------------------------------------- #

def test_an_assignment_naming_a_node_nothing_emitted_fails_loud():
    with pytest.raises(MaterializeError, match="not in the SQL"):
        plan(_sections(), {"src_a": "bronze", "mid_b": UNMATERIALIZED,
                           "out_c": "gold", "ghost": "silver"}, table_of=_table_of)


def test_references_ignores_comments_and_itself():
    """The section opens with `name AS (` and carries a `-- [node: name]` marker,
    so a naive scan makes every CTE depend on itself and nothing looks single-use."""
    assert references(_sections()["mid_b"], {"src_a", "mid_b", "out_c"}) - {"mid_b"} == {"src_a"}


def test_an_empty_layer_says_so_rather_than_emitting_an_empty_file():
    files = render_all(_sections(),
                       {"src_a": "bronze", "mid_b": UNMATERIALIZED, "out_c": "gold"},
                       table_of=_table_of, dataflow_id="8099")
    assert "nothing is assigned to this layer" in files["silver"]
    assert "CREATE" not in files["silver"]


def test_layers_run_in_order():
    assert LAYER_ORDER == ("bronze", "silver", "gold")
