"""Windows-only pytest plugin for the migrator, loaded with `-p pytest_winfix` (a root conftest.py would shadow
tests/conftest.py, which the agent tests import by name).

Windows + pytest-xdist: every worker calls ``platform.platform()`` at start-up, which asks WMI for the CPU name.
With many workers starting at once WMI times out (WinError 258) and CPython 3.12 then fails with KeyError, which
kills the worker and aborts the run. The processor name is in the environment on Windows, so use that instead.
"""

from __future__ import annotations

import os
import platform
import sys

if sys.platform == "win32":
    platform._Processor.get_win32 = staticmethod(  # type: ignore[attr-defined]
        lambda: os.environ.get("PROCESSOR_IDENTIFIER", ""))


def pytest_configure(config) -> None:  # type: ignore[no-untyped-def]
    """Windows MAX_PATH: pytest default basetemp (TEMP/pytest-of-USER/popen-gwN/<long test name>) plus deep raw/
    paths exceeds 260 characters. Unless --basetemp was given (and never inside an xdist worker, which inherits the
    controller's), use a short one so every worker's tmp_path is short."""
    if sys.platform != "win32" or config.option.basetemp or hasattr(config, "workerinput"):
        return
    base = "C:/t/pm"
    try:
        os.makedirs(os.path.dirname(base), exist_ok=True)
    except OSError:
        return
    config.option.basetemp = base
