"""judges.rules — the project's quality invariants, as deterministic rules.

Every rule here exists because we saw the failure it catches in a real DOMO plan.
The docstring on each says which one, so nobody deletes a rule without understanding
what it was protecting against.

Rule ids are stable and namespaced by kind:
    STR***  structure    DET***  determinism    SEM***  semantics
    LIN***  lineage      POL***  policy
"""
from __future__ import annotations

import re

from core.contracts.judges import Finding, Judge, Judgeable, JudgeKind, JudgeResult, Verdict

# --------------------------------------------------------------------------- #
# structure
# --------------------------------------------------------------------------- #

#: node markers are dialect-agnostic on purpose: PySpark artifacts comment with #,
#: SQL artifacts with --. The same rules must apply to both.
_NODE_OPEN = re.compile(r"^\s*(?:#|--)\s*\[node:\s*([^\]]+?)\]\s*(.*)$", re.MULTILINE)
_NODE_CLOSE = re.compile(r"^\s*(?:#|--)\s*\[/node:\s*([^\]]+?)\]\s*$", re.MULTILINE)


class NodeAddressable(Judge):
    """STR001 — every node section opens and closes, and ids are unique.

    The Classifier's medallion split and the feedback applier's per-node patching
    both parse these markers. A missing close marker silently swallows the next
    node's code into the previous section.
    """
    rule_id, title, kind = "STR001", "Node sections are well formed", JudgeKind.STRUCTURE
    applies_to = ("cd_codegen",)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        opens = [m.group(1).strip() for m in _NODE_OPEN.finditer(art)]
        closes = [m.group(1).strip() for m in _NODE_CLOSE.finditer(art)]
        findings: list[Finding] = []
        for nid in opens:
            if nid not in closes:
                findings.append(Finding(node=nid, message="section is never closed",
                                        detail="expected a matching # [/node: …] marker"))
        seen, dupes = set(), set()
        for nid in opens:
            (dupes if nid in seen else seen).add(nid)
        for nid in sorted(dupes):
            findings.append(Finding(node=nid, message="duplicate node section",
                                    detail="node ids must be unique within an artifact"))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=len(opens))


class NodeCoverage(Judge):
    """STR002 — every node the agent claims to have produced is actually present.

    Guards against an artifact that parses cleanly but silently dropped steps, which
    is exactly what a mis-scoped section parser produces.
    """
    rule_id, title, kind = "STR002", "All declared nodes appear in the artifact", JudgeKind.STRUCTURE
    applies_to = ("cd_codegen",)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        declared = list(subject.node_ids or [])
        present = {m.group(1).strip() for m in _NODE_OPEN.finditer(art)}
        missing = [n for n in declared if n not in present]
        findings = tuple(Finding(node=n, message="declared but missing from artifact") for n in missing)
        return self._result(self._verdict_from(findings, on_finding=Verdict.FAIL),
                            findings, checked=len(declared))


class NoUnresolvedSlots(Judge):
    """STR003 — no placeholder survived into the artifact.

    A ``__PENDING_n__`` token reaching the output means a translation was silently
    dropped. Ships as valid-looking code that fails at runtime.
    """
    rule_id, title, kind = "STR003", "No unresolved translation slots", JudgeKind.STRUCTURE
    _SLOT = re.compile(r"__PENDING_\d+__|<<[A-Z_]+>>|TODO:\s*translate", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings = tuple(
            Finding(message="unresolved placeholder in output", excerpt=m.group(0))
            for m in self._SLOT.finditer(art)
        )
        return self._result(self._verdict_from(findings, on_finding=Verdict.FAIL), findings)


# --------------------------------------------------------------------------- #
# determinism
# --------------------------------------------------------------------------- #

class OrderedAggregations(Judge):
    """DET001 — first()/last() must have an explicit ordering.

    Seen in cms_8099 s11: ``F.first(F.col('Exchange Rate'))`` inside a groupBy with
    no ordering. Spark's answer depends on partitioning, so this node can pass parity
    on one run and fail on the next. DOMO's tile had a defined order; if we cannot
    recover it, a human has to decide.
    """
    rule_id, title, kind = "DET001", "Order-dependent aggregations are ordered", JudgeKind.DETERMINISM
    applies_to = ("cd_codegen",)
    _AGG = re.compile(r"F\.(first|last)\s*\(", re.IGNORECASE)
    _SQL_AGG = re.compile(r"\b(FIRST_VALUE|LAST_VALUE)\s*\(", re.IGNORECASE)
    _ORDER = re.compile(r"(orderBy|sort|ORDER\s+BY|Window\.)", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings: list[Finding] = []
        checked = 0
        for section, nid in _iter_sections(art):
            hits = list(self._AGG.finditer(section)) + list(self._SQL_AGG.finditer(section))
            if not hits:
                continue
            checked += len(hits)
            if not self._ORDER.search(section):
                findings.append(Finding(
                    node=nid, message="first/last aggregation without an explicit order",
                    detail="result is non-deterministic across runs; recover the DOMO tile's "
                           "ordering or escalate to a human",
                    excerpt=hits[0].group(0)))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=checked)


class CrossJoinGuard(Judge):
    """DET002 — cross joins are flagged for review.

    cms_8099 s17 cross-joins a single-row filtered frame against a feed. Correct only
    while that filter matches exactly one row; if it ever matches two, every
    downstream row silently doubles and the totals still look plausible.
    """
    rule_id, title, kind = "DET002", "Cross joins are explicitly justified", JudgeKind.DETERMINISM
    applies_to = ("cd_codegen",)
    _CROSS = re.compile(r"how\s*=\s*['\"]cross['\"]|\bCROSS\s+JOIN\b", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            for m in self._CROSS.finditer(section):
                checked += 1
                findings.append(Finding(
                    node=nid, message="cross join present",
                    detail="row multiplication is silent if the other side returns more than "
                           "one row; assert cardinality or document the assumption",
                    excerpt=m.group(0)))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.WARN),
                            tuple(findings), checked=checked)


# --------------------------------------------------------------------------- #
# semantics
# --------------------------------------------------------------------------- #

class DecimalPrecision(Judge):
    """SEM001 — decimal casts must state precision and scale.

    Seen in cms_8099 s13/s16/s42: ``.cast(DecimalType())``. Spark defaults that to
    (10,0), truncating the two decimal places DOMO carried. Silent, and catastrophic
    in a reconciliation pipeline.
    """
    rule_id, title, kind = "SEM001", "Decimal casts declare precision", JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)
    _BARE = re.compile(r"DecimalType\s*\(\s*\)"
                       r"|\bAS\s+DECIMAL\s*(?![\s(]*\()", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            for m in self._BARE.finditer(section):
                checked += 1
                findings.append(Finding(
                    node=nid, message="decimal cast without precision/scale",
                    detail="defaults to (10,0) and truncates decimals that DOMO preserved",
                    excerpt=m.group(0)))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=checked)


class BatchMetadataDependency(Judge):
    """SEM002 — business logic depending on DOMO connector metadata is flagged.

    cms_8099 s09 derives Period End Date from ``_BATCH_ID_`` and ``_BATCH_LAST_RUN_``,
    and s20 filters on a literal ``_BATCH_LAST_RUN_`` timestamp. These columns are
    stamped by DOMO's ingestion layer. Unless Databricks ingestion reproduces the same
    batch numbering and run timestamps, these expressions compile fine and produce
    different answers.
    """
    rule_id, title, kind = "SEM002", "DOMO batch metadata dependencies are declared", JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)
    _BATCH = re.compile(r"_BATCH_ID_|_BATCH_LAST_RUN_|_FILE_NAME_|_DOWNLOAD_EMAIL_")

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        declared = set(subject.meta.get("batch_metadata_contract", []) or [])
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            cols = {m.group(0) for m in self._BATCH.finditer(section)}
            if not cols:
                continue
            checked += len(cols)
            undeclared = sorted(cols - declared)
            if undeclared:
                findings.append(Finding(
                    node=nid, message=f"depends on DOMO batch metadata: {', '.join(undeclared)}",
                    detail="ingestion must reproduce these columns with identical semantics, "
                           "or the expression silently diverges after migration"))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.WARN),
                            tuple(findings), checked=checked)


class HardcodedBatchPatch(Judge):
    """SEM003 — literal batch ids paired with literal dates are human patches.

    cms_8099 s09: ``WHEN _BATCH_ID_ = 2 THEN '2025-05-31'``. Someone pinned one batch
    to one period by hand. Re-ingesting into Databricks renumbers batch ids, so this
    rule silently attaches to the wrong batch. Must become a mapping keyed on
    something stable, never carried across as a literal.
    """
    rule_id, title, kind = "SEM003", "No hardcoded batch-to-date patches", JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)
    #: matches `_BATCH_ID_ = 2 ... '2025-05-31'` in SQL and
    #: `F.col('_BATCH_ID_') == F.lit(2), F.lit('2025-05-31')` in PySpark
    _PATCH = re.compile(
        r"_BATCH_ID_[^\n]{0,40}?==?\s*(?:F\.lit\(\s*)?\d+[^\n]{0,80}?['\"]\d{4}-\d{2}-\d{2}['\"]",
        re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            for m in self._PATCH.finditer(section):
                checked += 1
                findings.append(Finding(
                    node=nid, message="hardcoded batch id mapped to a literal date",
                    detail="batch ids are renumbered on re-ingestion; move this to a mapping "
                           "table keyed on a stable identifier and confirm with the owner",
                    excerpt=m.group(0)[:110]))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=checked)


class PositionalColumnNames(Judge):
    """SEM004 — positional column names are fragile and get surfaced.

    DOMO feeds arrive with ``C``, ``C2``..``C8``, ``column_59``. cms_8099 s10 maps
    ``C4`` to Settlement Date and s25 maps ``C3``→Company, ``C5``→Currency. If the
    upstream file gains a column, every mapping shifts by one and nothing errors.
    """
    rule_id, title, kind = "SEM004", "Positional column references are flagged", JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)
    _POS = re.compile(r"""['"`](C\d{1,2}|column_\d{1,3})['"`]""")

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            cols = sorted({m.group(1) for m in self._POS.finditer(section)})
            if cols:
                checked += len(cols)
                findings.append(Finding(
                    node=nid, message=f"positional column references: {', '.join(cols[:6])}",
                    detail="a new column upstream shifts every mapping silently; pin by header "
                           "name at ingestion if the feed allows it"))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.WARN),
                            tuple(findings), checked=checked)


class UnionSchemaDrift(Judge):
    """SEM005 — allowMissingColumns unions are flagged.

    cms_8099 s52/s53 union seven frames with ``allowMissingColumns=True``. That hides
    a column appearing or disappearing in any of the seven, which then surfaces as
    unexplained nulls in the summary rather than an error.
    """
    rule_id, title, kind = "SEM005", "Permissive unions are justified", JudgeKind.SEMANTICS
    applies_to = ("cd_codegen",)
    _UNION = re.compile(r"allowMissingColumns\s*=\s*True", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings, checked = [], 0
        for section, nid in _iter_sections(art):
            n = len(self._UNION.findall(section))
            if n:
                checked += n
                findings.append(Finding(
                    node=nid, message=f"{n} permissive union(s)",
                    detail="schema drift in any input becomes silent nulls; assert the expected "
                           "column set before unioning"))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.WARN),
                            tuple(findings), checked=checked)


# --------------------------------------------------------------------------- #
# lineage / policy
# --------------------------------------------------------------------------- #

class ReferencesResolve(Judge):
    """LIN001 — every dataframe/CTE referenced is defined earlier in the artifact.

    Catches the class of bug where source reads are omitted entirely (the MD plan
    documents sources in a table but emits no read code), leaving every step
    referencing an undefined name.
    """
    rule_id, title, kind = "LIN001", "All references are defined before use", JudgeKind.LINEAGE
    applies_to = ("cd_codegen",)
    _ASSIGN = re.compile(r"^\s*([a-zA-Z_]\w*)\s*=\s", re.MULTILINE)
    #: a CTE header, with or without a leading WITH/comma — in a node-addressable
    #: artifact the marker sits between the comma and the name, so the name starts
    #: its own line.
    _CTE = re.compile(r"^\s*(?:WITH\s+|,\s*)?([a-zA-Z_]\w*)\s+AS\s*\(",
                      re.MULTILINE | re.IGNORECASE)
    _REF = re.compile(r"\b(df_[a-zA-Z0-9_]+|[a-z][a-z0-9_]*_df)\b")

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        defined: set[str] = set()
        findings: list[Finding] = []
        checked = 0
        for section, nid in _iter_sections(art):
            # a section defines its own output before it is read downstream, so
            # resolve local definitions BEFORE checking this section's references
            local = ({m.group(1) for m in self._ASSIGN.finditer(section)} |
                     {m.group(1) for m in self._CTE.finditer(section)})
            if nid:
                local.add(nid)
            for ref in sorted({m.group(1) for m in self._REF.finditer(section)}):
                checked += 1
                if ref not in defined and ref not in local:
                    findings.append(Finding(
                        node=nid, message=f"references {ref} before it is defined",
                        detail="the producing step is missing or ordered after this one"))
            defined |= local
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=checked)


class NoRawCredentials(Judge):
    """POL001 — no secrets, tokens or connection strings in generated output."""
    rule_id, title, kind = "POL001", "No credentials in generated artifacts", JudgeKind.POLICY
    #: catches both `password = "value"` and the embedded `"...;password=value;..."`
    #: form used in connection strings. Placeholders (<...>, {{...}}, dbutils.secrets)
    #: are deliberately not matched.
    _SECRET = re.compile(
        r"(?:password|passwd|secret|api[_-]?key|access[_-]?token|client[_-]?secret)"
        r"\s*[=:]\s*['\"]?([A-Za-z0-9_\-+/.]{6,})",
        re.IGNORECASE)
    _PLACEHOLDER = re.compile(r"^(?:x{3,}|\*{3,}|changeme|your[_-]?\w+|placeholder)$", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        findings = tuple(
            Finding(message="possible credential literal",
                    detail="move this to a secret scope; generated artifacts are committed "
                           "and shared",
                    excerpt=m.group(1)[:6] + "…")          # never echo the full value
            for m in self._SECRET.finditer(art)
            if not self._PLACEHOLDER.match(m.group(1))
        )
        return self._result(self._verdict_from(findings, on_finding=Verdict.FAIL), findings)


# --------------------------------------------------------------------------- #
# the plan
#
# The twelve rules above read SQL. A plan is markdown with a different grammar,
# so running them on it parses zero sections and returns twelve vacuous passes -
# which is worse than no result, because "12 checks passed" is a claim that
# twelve things were examined. These read the plan's own grammar instead.
#
# What a plan is FOR is the reason these exist: cd_codegen extracts its input
# from this document, and a reviewer approving it is approving the semantics of
# every step. So the rules check the two things that can silently break that -
# a step the extractor cannot read, and a step the reviewer cannot judge.
# --------------------------------------------------------------------------- #

#: `### Step s01 | `Add Formula 1` | `FORMULA``
_MD_STEP = re.compile(r"^###\s+Step\s+(?P<id>\S+)\s*\|\s*`(?P<tile>[^`]*)`\s*\|\s*`(?P<op>[^`]*)`",
                      re.MULTILINE)
#: `- **In:** `a`, `b` | **Out:** `c` | **Confidence:** `HIGH``
_MD_OUT = re.compile(r"\*\*Out:\*\*\s*`(?P<df>[^`]+)`")
_MD_IN = re.compile(r"\*\*In:\*\*\s*(?P<ins>.+?)\s*\|\s*\*\*Out:")
_MD_CONF = re.compile(r"\*\*Confidence:\*\*\s*`(?P<conf>[^`]+)`")
_MD_SECTION = re.compile(r"^##\s+(\d+)\.\s+(.+?)\s*$", re.MULTILINE)
_MD_TICKED = re.compile(r"`([^`]+)`")
#: an arrow line in the Execution DAG: `a  ->  b  (Tile Name)`.
#: The destination may be a df_var or a dotted table name (a write target), so
#: dots are part of the token rather than the end of it.
_MD_EDGE = re.compile(r"^\s*(?P<src>[A-Za-z_][\w.]*)\s*->\s*(?P<dst>[A-Za-z_][\w.]*)\s*(?:\(|$)",
                      re.MULTILINE)


def _md_steps(artifact: str) -> list[tuple[str, str]]:
    """``(step id, the step's own body)`` for every step section in the plan."""
    matches = list(_MD_STEP.finditer(artifact or ""))
    out = []
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(artifact)
        out.append((m.group("id"), artifact[m.start():end]))
    return out


def _md_section_body(artifact: str, number: int) -> str:
    """The body of ``## <number>. ...``, or "" when that section is absent."""
    for m in _MD_SECTION.finditer(artifact or ""):
        if int(m.group(1)) == number:
            nxt = _MD_SECTION.search(artifact, m.end())
            return artifact[m.end(): nxt.start() if nxt else len(artifact)]
    return ""


class PlanSectionsPresent(Judge):
    """MD001 — the sections cd_codegen extracts from are all there.

    ``extract_md_plan`` reads section 2 for sources, 5 for steps and 6 for write
    targets, and each one is looked up by number. A missing section is not an
    error there: it returns nothing for that part and codegen carries on with
    less. So a plan that lost section 6 generates every CTE and writes no table,
    and the only symptom is a smaller artifact.
    """
    rule_id, title, kind = "MD001", "Plan has every section codegen reads", JudgeKind.STRUCTURE
    applies_to = ("md_plan",)

    #: number -> what depends on it, so a finding says what will break
    _NEEDED = {
        2: "source tables — codegen reads the df_var/dataset/id rows from here",
        3: "execution DAG — the lineage the plan is checked against",
        4: "dataframe variable map — what each df_var holds",
        5: "transformation plan — one entry per step; codegen extracts these",
        6: "output targets — without this nothing is written anywhere",
    }

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        present = {int(m.group(1)) for m in _MD_SECTION.finditer(art)}
        findings = tuple(
            Finding(message=f"section {n} is missing", detail=why)
            for n, why in sorted(self._NEEDED.items()) if n not in present)
        return self._result(self._verdict_from(findings, on_finding=Verdict.FAIL),
                            findings, checked=len(self._NEEDED))


class PlanStepsExtractable(Judge):
    """MD002 — every step declares In, Out and Confidence.

    These three fields are the extractor's contract with the plan. A step whose
    ``**Out:**`` is missing produces no CTE, and it does so quietly: the step is
    still in the document, still reads as planned work, and simply never appears
    in the SQL. This is the single most expensive way a plan can be wrong,
    because the artifact looks complete.
    """
    rule_id, title, kind = "MD002", "Every step states its inputs, output and confidence", JudgeKind.STRUCTURE
    applies_to = ("md_plan",)

    def run(self, subject: Judgeable) -> JudgeResult:
        steps = _md_steps(subject.artifact or "")
        findings = []
        for step_id, body in steps:
            missing = [name for name, rx in (("In", _MD_IN), ("Out", _MD_OUT),
                                             ("Confidence", _MD_CONF))
                       if not rx.search(body)]
            if missing:
                findings.append(Finding(
                    node=step_id,
                    message=f"step {step_id} has no {', '.join(missing)}",
                    detail="cd_codegen extracts these three fields; a step without "
                           "Out generates no CTE and says nothing about it"))
        return self._result(self._verdict_from(tuple(findings), on_finding=Verdict.FAIL),
                            tuple(findings), checked=len(steps))


class PlanCoversTheDag(Judge):
    """MD003 — every node in the execution DAG has a step section.

    The DAG and the step list are two independent statements about the same
    pipeline: one derived from the discovery edges, the other from the tile
    renderers. A node in the DAG with no section is work the plan admits exists
    and then does not describe, and there is nothing for a reviewer to approve.
    """
    rule_id, title, kind = "MD003", "Every DAG node has a plan entry", JudgeKind.LINEAGE
    applies_to = ("md_plan",)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        dag = _md_section_body(art, 3)
        produced = {m.group("df") for _, body in _md_steps(art)
                    for m in [_MD_OUT.search(body)] if m}
        # Sources are declared in section 2 and written targets in section 6;
        # neither is produced by a step, and both are legitimate ends of an edge.
        # The first backticked cell of a section-2 row is the df_var; the LAST of a
        # section-6 row is the destination table.
        sources = {t[0] for row in _md_section_body(art, 2).splitlines()
                   for t in [_MD_TICKED.findall(row)] if t}
        written = {t[-1] for row in _md_section_body(art, 6).splitlines()
                   for t in [_MD_TICKED.findall(row)] if t}
        # BOTH ends of every edge. Checking only destinations misses the mirror
        # failure: a df_var used as an input that no step produces and no source
        # declares. That one is worse, because the plan reads as if the data comes
        # from somewhere and never says where.
        seen: set[str] = set()
        for m in _MD_EDGE.finditer(dag):
            seen.add(m.group("src"))
            seen.add(m.group("dst"))
        known = produced | sources | written
        missing = sorted(t for t in seen if t not in known)
        findings = tuple(
            Finding(node=n, message=f"{n} is in the DAG but nothing defines it",
                    detail="no step produces it, no source declares it and no target "
                           "writes it - the plan names a dataframe it never accounts for")
            for n in missing)
        return self._result(self._verdict_from(findings, on_finding=Verdict.FAIL),
                            findings, checked=len(seen))


class PlanCaveatsOnLowConfidence(Judge):
    """MD004 — a step the generator is unsure of says why.

    The plan's own words are that approving it means approving these semantics.
    A step marked LOW with nothing explaining what is uncertain asks a reviewer
    to approve something the document declines to describe — and LOW is exactly
    where the review is worth having, so a silent one wastes the whole gate.
    """
    rule_id, title, kind = "MD004", "Low-confidence steps state the caveat", JudgeKind.SEMANTICS
    applies_to = ("md_plan",)

    _EXPLAINED = ("caveat", "verify", "⚠", "escalat", "review")

    def run(self, subject: Judgeable) -> JudgeResult:
        low = [(sid, body) for sid, body in _md_steps(subject.artifact or "")
               if (m := _MD_CONF.search(body)) and m.group("conf").strip().upper() == "LOW"]
        findings = tuple(
            Finding(node=sid, message=f"step {sid} is LOW confidence with no caveat",
                    detail="state what is uncertain, or the reviewer is approving "
                           "an unexplained risk")
            for sid, body in low
            if not any(w in body.lower() for w in self._EXPLAINED))
        return self._result(self._verdict_from(findings, on_finding=Verdict.WARN),
                            findings, checked=len(low))


class PlanDeclaresItsCoverage(Judge):
    """MD005 — the plan says how much of itself a model wrote.

    A step translated by the tile registry and one translated by an LLM carry
    very different warranties, and the difference is invisible in the rendered
    prose. The coverage report is where the plan states the split; without it a
    reviewer has no way to know which half they are reading.
    """
    rule_id, title, kind = "MD005", "Coverage split is stated", JudgeKind.POLICY
    applies_to = ("md_plan",)

    _COVERAGE = re.compile(r"deterministic", re.IGNORECASE)

    def run(self, subject: Judgeable) -> JudgeResult:
        art = subject.artifact or ""
        body = _md_section_body(art, 9) or _md_section_body(art, 1)
        ok = bool(self._COVERAGE.search(body))
        findings = () if ok else (Finding(
            message="the plan never states its deterministic / model split",
            detail="a reader cannot tell which steps carry a transpiler's warranty "
                   "and which carry a model's"),)
        return self._result(self._verdict_from(findings, on_finding=Verdict.WARN),
                            findings, checked=1)


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #

def _iter_sections(artifact: str):
    """Yield ``(section_text, node_id)`` for each ``# [node: …]`` block.

    Falls back to one anonymous section covering the whole artifact when there are no
    markers, so judges still work on plan documents and pre-assembly output.
    """
    matches = list(_NODE_OPEN.finditer(artifact or ""))
    if not matches:
        if artifact:
            yield artifact, ""
        return
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(artifact)
        yield artifact[m.end():end], m.group(1).strip()


#: The default panel. Registration order is the order results are reported in.
DEFAULT_JUDGES = [
    NodeAddressable(), NodeCoverage(), NoUnresolvedSlots(),
    OrderedAggregations(), CrossJoinGuard(),
    DecimalPrecision(), BatchMetadataDependency(), HardcodedBatchPatch(),
    PositionalColumnNames(), UnionSchemaDrift(),
    ReferencesResolve(), NoRawCredentials(),
    # the plan's own grammar - see `applies_to` on each
    PlanSectionsPresent(), PlanStepsExtractable(), PlanCoversTheDag(),
    PlanCaveatsOnLowConfidence(), PlanDeclaresItsCoverage(),
]


def default_registry():
    from core.contracts.judges import JudgeRegistry
    return JudgeRegistry(list(DEFAULT_JUDGES))
