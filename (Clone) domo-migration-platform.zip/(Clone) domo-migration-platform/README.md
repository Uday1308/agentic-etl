# LatentView Migration Platform

Any-to-any ETL **logic** migration. Seven agents move one source pipeline from
discovery to validated, node-addressable target code, pausing wherever a person
needs to decide. It migrates logic only: data movement is handled by a separate
accelerator.

DOMO → Databricks is the first implemented source/target pair and the default.
The pair is configuration, not code: the API serves it from `MIGRATION_SOURCE` /
`MIGRATION_TARGET` (`GET /api/meta` → `profile`, see `api/profile.py`), and the UI
reads all platform wording from `lv-tower/src/profile.js` (overridable at build
time with `VITE_SOURCE_*` / `VITE_TARGET_*`).

## Layout

```
core/                 platform services shared by every agent
  llm.py              LLMClient — the only sanctioned path to a serving endpoint
  nodes.py            Node ABC + the generate/evaluate/HITL loop factory
  checkpoint.py       Delta-audited checkpointer over Postgres
  observability.py    row writers
  contracts/          the schemas everything else reads from
    validation.py     how "accuracy" is defined and rolled up
    judges.py         Judge / JudgePanel / JudgeRegistry
    telemetry.py      LlmCall / Step / Ingestion / Judge / Validation / Decision rows
  schemas.py  models.py  state.py  prompts.py  concurrency.py
                      >>> PLACEHOLDER <<< — owned by the core team, replace wholesale

judges/               deterministic quality rules (NOT the LLM evaluators)
  rules.py            12 rules, each derived from a real failure in a real plan

agents/master.py      the seven stages in order, their AI/HITL defaults, and the
                      phase vocabulary the UI renders verbatim

agents/connection/       (1) no AI — fetch DOMO JSON, write, flip ETL master once
agents/standardization/  (2) chunk fan-out + LLM evaluator AND deterministic validator
agents/discovery/        (3) no LLM — nodes, lineage, terminal/intermediate, period probe
agents/md_plan/          (4) generate -> evaluate -> HITL
  domo_expr.py             DOMO Beast Mode -> PySpark: tokenizer, Pratt parser, AST,
                           emitter. The deterministic core of the platform.
  tiles.py                 one renderer per DOMO tile type
  render.py                builds the 9-section plan document
  strategies.py            deterministic first, a model only for the real tail
agents/cd_codegen/       (5) the CD Codegen agent (fully implemented)
agents/validation/       (6) Jobs-as-a-tool, parity vs DOMO, routable diagnosis
agents/classifier/       (7) config-driven medallion split into 3 layer files

agents/cd_codegen/    detail of the one agent that is complete
  ir.py               frozen IR value objects + topological ordering
  mapping.py          deterministic DOMO tile -> PySpark mappers
  translation.py      the AI tail: chunked fan-out, tolerant envelope parsing
  assembly.py         splice + node-addressable emit
  md_extract.py       extract already-translated code from an approved MD plan
  md_generator.py     the MD-plan generation path
  ports.py            DiscoveryReader / PlanReader / ArtifactStore
  graph.py            build_cd_codegen_graph(source="discovery"|"md")

api/                  the HTTP surface the Control Tower frontend reads
  ports.py            PlatformStore — one port, two adapters
  store_local.py      samples + dryrun_out + JSONL; runs with no Databricks
  store_delta.py      the six audit tables + the artifact volume
  app.py              the routes; read-mostly, one write (a human's review)
lv-tower/             the React Control Tower (Vite). src/api.js is the client,
                      src/platform.js swaps fixtures for live data

tests/                contracts (hermetic), integration (needs Spark), eval (manual)
notebooks/
  agent_test_md_plan.py     test agent 4 alone  (contract only — generator is a stub)
  agent_test_cd_codegen.py  test agent 5 alone  (real: judges + telemetry + artifact)
  agent_test_validation.py  test agent 6 alone  (real parity against real tables)
  test_cd_codegen*.py       earlier end-to-end harnesses for the two codegen paths
docs/                 blueprint, development guide, agent skill files, UI
```

## Running the whole pipeline locally

`scripts/e2e_mock_run.py` drives all seven agents on one dataflow with no
Databricks, no DOMO and no serving endpoint:

```bash
cp 8099_standardized.json ex_volume/raw/8099.json   # drop the export in
python scripts/e2e_mock_run.py                      # 8099, all seven agents
python scripts/e2e_mock_run.py --stop-at md_plan    # leave that gate open to review
```

`ex_volume/` stands in for the UC volume, in the **same layout Databricks will
use** — so the dry run exercises the real paths rather than a local-only
arrangement, and `DeltaStore` reads the identical shape once deployed:

```
ex_volume/raw/<id>.json               the export you drop in
ex_volume/<id>/standardized/          agent 2
ex_volume/<id>/discovery/             agent 3 — a JSON array here, a Delta table there
ex_volume/<id>/md/plan_<id>_v<n>.md   agent 4, the review surface
ex_volume/<id>/sql/etl_<id>__*.sql    agent 5, one per target
ex_volume/<id>/layers/                agent 7, bronze/silver/gold
ex_volume/<id>/gates/                 the HITL payloads the UI reviews
ex_volume/<id>/graph_<id>.json        the tile graph, from discovery + the plan
ex_volume/runs.json                   the run registry — what produced each run
```

`runs.json` is provenance, not a summary: which export a run read, which volume it
wrote, how far it got, and that the externals were mocked. It deliberately holds
**no counts** — `RunSummary` is computed from telemetry so the dashboard and the
deliverable cannot disagree, and caching those numbers here would hand that problem
straight back. `GET /api/run-records` serves it; `GET /api/runs` serves the counts.

Point it elsewhere with `--volume`, and the API with `PLATFORM_VOLUME` (the same
variable `app.yaml` sets to a real `/Volumes/...` path). Telemetry stays in
`.platform_local/` — in production those are Delta tables, not files.

**The external systems are mocked; the platform is not.** Real: every tile
renderer, the expression emitter, the plan renderer, the SQL generator and
assembler, the deterministic JSON validator, the judges, the parity arithmetic,
the section splitter, all seven agents' own Runner/Strategy classes, and the real
`LLMClient`. Mocked (`scripts/mocks.py`, one class per port): the DOMO API, the UC
volume, the Delta discovery table, the Databricks job runner, the Spark table
reader, and the serving endpoint.

So a green run says the deterministic half works and the agents compose. It says
nothing about DOMO's API, about Spark, or about what a real model would answer —
`ScriptedCaller` cannot refuse, truncate, or invent a column name, and the tail it
is least like is the tail that breaks first against a real endpoint.

It writes telemetry, gate payloads and artifacts into `.platform_local/`, which is
exactly where the API reads, so the run appears in the Control Tower as a real run.
Every gate is auto-approved by an actor called `e2e-mock-run@localhost`, and each
approval writes its `DecisionRow` — nobody reviewed anything and the audit trail
says so. One validation target is given a deliberate row-count drift, so the run
exercises a real parity failure rather than an all-green path that proves less.

Running it found two real bugs, both now fixed and pinned by tests in
`api/tests/test_e2e_mock_run.py`: `build_md_plan_graph` passed keyword names the
node factory does not take, so that agent could never be constructed; and the
classifier's section grammar matched only `# [node: ...]`, so every SQL artifact
silently parsed as zero sections.

## Running the Control Tower

Two processes. The API defaults to a **local store** that reads the sample gate
payloads and whatever `scripts/local_dryrun.py` last wrote into `dryrun_out/`, so
neither a warehouse nor credentials is needed to see the UI work.

```bash
pip install -r requirements.txt -r requirements-api.txt

python scripts/seed_local_telemetry.py          # optional: demo rows, see below
uvicorn api.app:app --reload --port 8000        # terminal 1

cd lv-tower && npm install && npm run dev       # terminal 2 -> http://localhost:5173
```

Vite proxies `/api` to port 8000, so the browser stays on one origin and there is
no CORS to configure. If the API is not running the UI still loads — on fixtures,
with a permanent badge in the corner saying so. **Sample data that looks live is
the failure mode that matters here**, so that badge does not dismiss.

For a populated dashboard, prefer `scripts/e2e_mock_run.py` above — it produces a
genuine run. `seed_local_telemetry.py` remains for the case where you want rows
without running anything; it writes invented step/ingestion rows into
`.platform_local/`. Both are deliberately separate scripts: the serving path never
fabricates a row. `--clear` removes the seeded ones again.

Point it at Databricks with:

```bash
export PLATFORM_STORE=delta
export DATABRICKS_HOST=... DATABRICKS_TOKEN=... DATABRICKS_HTTP_PATH=...
export PLATFORM_CATALOG=dev_test PLATFORM_SCHEMA=domo_migration_audit
export PLATFORM_VOLUME=/Volumes/dev_test/dev_domo_migration/md-cd
pip install databricks-sql-connector databricks-sdk
```

The contract the UI is built against is [`docs/frontend/CONTEXT.md`](docs/frontend/CONTEXT.md).
Interactive route docs are at `http://localhost:8000/docs` once the API is up.

## Deploying as a Databricks App

One process serves both halves: FastAPI answers `/api` and serves the built React
bundle for everything else. There is no vite in a deployment.

```bash
cd lv-tower && npm ci && npm run build && cd ..
databricks apps deploy <app-name> --source-code-path .
```

`app.yaml` sets `PLATFORM_STORE=delta` plus the catalog, schema and volume, and
declares a `sql_warehouse` resource. The app's service principal needs `SELECT` on
the audit schema, `READ VOLUME` on the artifact volume, and `MODIFY` on the
decisions table — reviews are written back.

Three things behave differently once deployed, each a correctness issue rather than
packaging:

* **The reviewer is the authenticated user.** `HumanFeedback.actor` and every
  `DecisionRow` carry a name into the client deviation report. Deployed, that name
  comes from the identity header the Apps proxy sets and the client's value is
  ignored; a request with no identity is refused rather than recorded under whatever
  the browser claimed. Verify `PLATFORM_IDENTITY_HEADERS` matches your workspace.
* **A file store is refused.** An App instance's disk is ephemeral, so
  `PLATFORM_STORE=local` there would lose the review trail when the instance is
  replaced. The app raises at startup instead.
* **Decisions are written over SQL, not Spark.** An App has no Spark session, so
  `DeltaSink` cannot be used; `DeltaStore` INSERTs decision rows through the same
  warehouse it reads over. Unlike telemetry, a failed write raises — telling a
  reviewer their decision was recorded when it was not is the worst outcome here.

`GET /api/serving` reports how the process came up. A null `spa` means nobody ran
`npm run build`.

### What is not production-ready yet

* **Gate payloads have no table.** `DeltaStore` reads them as JSON from the volume,
  which is an assumption this repo invented — a real HITL pause currently lives in
  the LangGraph checkpoint. Until gates have a contract in
  `core/contracts/telemetry.py`, the review surface depends on something writing
  that JSON.
* **Approval still does not bind the generated code** (architecture gap #1). The
  API says so in every receipt; do not let the UI imply otherwise.
* **Nothing in the app runs a migration.** By design — `CONTEXT.md` forbids the
  frontend calling an agent — so a job or workflow has to produce the runs this
  reads.
* **Telemetry reads are unpaginated.** One `SELECT *` per table per run is fine at
  8099's size and will not be at estate scale.

## Running the tests

```bash
pip install -r requirements.txt -r requirements-dev.txt
pytest                      # 268 contract tests, hermetic, ~9s
ruff check .
```

Integration tests need Java 17 + pyspark and self-skip without them:

```bash
pip install -r requirements-integration.txt
pytest tests/integration -m integration
```

## Two ideas worth knowing before reading the code

**Determinism does the bulk, the model does the tail.** DOMO's tile vocabulary is
closed and finite, so it is mapped in plain Python. Only genuinely open-ended
fragments (Beast Mode formulas, unrecognised tiles) reach a model. A fully resolved
plan makes zero model calls.

**Judges are not evaluators.** An evaluator is an LLM with an opinion, feeding the
human review gate. A judge is a hardcoded rule — deterministic, always run, never
asks a model anything. Judge pass rate is trended over releases as a regression
signal; evaluator issue counts are not.

## The deterministic core

`agents/md_plan/domo_expr.py` parses DOMO's formula language properly — tokenizer,
Pratt parser, AST, emitter — rather than pattern-matching it. Regexes cannot handle
nested `CASE WHEN` or operator precedence, and getting those subtly wrong in a
financial reconciliation pipeline is the expensive kind of bug.

All 16 distinct expressions in the real `cms_8099` plan translate with no model
involved. Where DOMO and Spark disagree (CONCAT nulls, integer division, decimal
precision, ROUND half-away-from-zero) the difference is recorded as a semantic caveat
on the step and surfaced in the plan's risk register, not silently accepted.

## Placeholders

`core/{schemas,models,state,prompts,concurrency}.py` are marked
`>>> PLACEHOLDER <<<`. They reproduce the documented interfaces faithfully so the
graph runs and the suite passes, but they are owned by the core team. Replace them
wholesale rather than building on them.
