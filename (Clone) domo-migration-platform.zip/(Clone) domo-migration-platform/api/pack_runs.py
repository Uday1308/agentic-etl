"""api.pack_runs — RunSummary for pack-driven runs (Snowflake), built from the run's own ``run.json``.

The DOMO harness writes telemetry rows; a pack run writes ``<volume>/<etl_key>/<run_id>/run.json`` instead
(per-unit records, status, ``ts``). Without this the run is "Running" forever with zeros everywhere.
"""
from __future__ import annotations

import json
import pathlib
import re
from collections import Counter

from core.contracts.telemetry import RunSummary

_STAMP = re.compile(r"(\d{4}-\d{2}-\d{2})T(\d{2})-(\d{2})-(\d{2})$")


def _started(doc: dict) -> str:
    """``started`` if the record has it; else the stamp in the run id (``run-<key>-YYYY-MM-DDTHH-MM-SS``, UTC)."""
    if doc.get("started"):
        return str(doc["started"])
    m = _STAMP.search(str(doc.get("run_id") or ""))
    return f"{m[1]}T{m[2]}:{m[3]}:{m[4]}+00:00" if m else ""


def summary_from_record(doc: dict) -> RunSummary:
    units = [u for u in (doc.get("units") or []) if isinstance(u, dict)]
    by_status = Counter(str(u.get("status") or u.get("state") or "unknown") for u in units)
    return RunSummary(
        run_id=str(doc.get("run_id") or ""), dataflow_id=str(doc.get("etl_key") or doc.get("etl_id") or ""),
        status=str(doc.get("status") or "running"), started_ts=_started(doc), ended_ts=str(doc.get("ts") or ""),
        steps_run=len(doc.get("completed") or []), source="pack", units_total=len(units),
        units_by_status=dict(by_status), reason=str(doc.get("reason") or "; ".join(doc.get("failures") or [])))


def record_files(volume: pathlib.Path | str) -> list[pathlib.Path]:
    root = pathlib.Path(volume)
    return sorted(root.glob("*/*/run.json")) if root.is_dir() else []


def _load(path: pathlib.Path) -> dict | None:
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return doc if isinstance(doc, dict) and doc.get("run_id") else None


def pack_summaries(volume: pathlib.Path | str, dataflow_id: str = "") -> list[RunSummary]:
    out = []
    for p in record_files(volume):
        doc = _load(p)
        if doc is None:
            continue
        s = summary_from_record(doc)
        if not dataflow_id or s.dataflow_id == dataflow_id:
            out.append(s)
    return out


def pack_summary(volume: pathlib.Path | str, run_id: str) -> RunSummary | None:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", run_id or ""):
        return None
    root = pathlib.Path(volume)
    for p in root.glob(f"*/{run_id}/run.json") if root.is_dir() else []:
        doc = _load(p)
        if doc is not None:
            return summary_from_record(doc)
    return None


def pack_artifact_refs(volume: pathlib.Path | str, etl_key: str):
    """One ``ArtifactRef`` (by ``ref``, no path) per hash-stored artifact in this ETL's pack gates."""
    from api.models import ArtifactRef

    root = pathlib.Path(volume) / etl_key
    out, seen = [], set()
    for p in sorted(root.glob("*/gates/*.json")) if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", etl_key) else []:
        try:
            gate = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for a in ((gate.get("artifact") or {}).get("artifacts") or []):
            ref = a.get("artifact_ref") if isinstance(a, dict) else None
            if ref and ref not in seen:
                seen.add(ref)
                out.append(ArtifactRef(kind=str(a.get("kind") or "sql"), ref=ref, target=str(a.get("name") or ""),
                                       sha256=a.get("sha256", ""), origin=a.get("origin", "")))
    return out
