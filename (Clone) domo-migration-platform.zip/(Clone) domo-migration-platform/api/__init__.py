"""api — the HTTP surface the Control Tower frontend reads.

Read-mostly by design. ``docs/frontend/CONTEXT.md`` states the rule this package
enforces: the frontend never calls an agent directly and never calls a serving
endpoint. So every route here either reads telemetry rows and artifacts, or accepts
the one thing a human produces — a ``HumanFeedback`` and its ``DecisionRow`` audit
trail. Nothing here starts, resumes or steers a migration.
"""
