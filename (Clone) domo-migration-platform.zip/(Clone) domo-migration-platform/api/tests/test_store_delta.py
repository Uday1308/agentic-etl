"""The Delta store (api.store_delta), against a fake warehouse.

It cannot be tested against a real one here, which is exactly why the seams are
injected. What these pin is the part that is easy to get wrong and impossible to
notice until a reviewer's decision silently vanishes: that writes actually happen,
that they are parameterized, and that a failure is raised rather than swallowed.

The bug that prompted them: the app wired a `DeltaSink(None, ...)` into this store.
A Databricks App has no Spark session, so every review submission would have failed
with a 502 the first time anyone clicked approve.
"""
from __future__ import annotations

import pytest

from api.models import FeedbackSubmission, Gate
from api.ports import StoreError
from api.store_delta import DeltaStore


class FakeWarehouse:
    """Records statements. Returns rows for SELECT, nothing for INSERT."""

    def __init__(self, rows=None, fail_on: str = "") -> None:
        self.rows = rows or []
        self.fail_on = fail_on
        self.statements: list[tuple[str, tuple]] = []

    def __call__(self, statement: str, params: tuple = ()) -> list[dict]:
        self.statements.append((statement, params))
        if self.fail_on and self.fail_on in statement:
            raise RuntimeError("warehouse said no")
        return [] if statement.lstrip().upper().startswith("INSERT") else self.rows

    @property
    def inserts(self):
        return [s for s in self.statements if s[0].lstrip().upper().startswith("INSERT")]


def _gate() -> Gate:
    return Gate(gate_id="g1", run_id="r1", dataflow_id="8099", agent="md_plan",
                iteration=1, status="interrupted")


def _store(warehouse) -> DeltaStore:
    store = DeltaStore(warehouse, catalog="cat", schema="audit")
    store.gate = lambda gate_id: _gate()          # gates live on the volume; not under test
    return store


def _submission(**over) -> FeedbackSubmission:
    return FeedbackSubmission(**{"actor": "reviewer@latentview.com",
                                 "approve": True, **over})


def test_a_review_is_written_without_a_spark_session():
    """The whole point: an App has no Spark, and approve must still record."""
    wh = FakeWarehouse()
    receipt = _store(wh).submit_feedback("g1", _submission())
    assert receipt.decision_rows
    assert len(wh.inserts) == len(receipt.decision_rows)


def test_one_insert_per_decision_row():
    wh = FakeWarehouse()
    sub = _submission(hard_constraints=["Never rename source columns"], approve=False)
    receipt = _store(wh).submit_feedback("g1", sub)
    kinds = [r.kind.value for r in receipt.decision_rows]
    assert kinds == ["constraint_added", "regenerated"]
    assert len(wh.inserts) == 2


def test_values_are_parameterized_not_interpolated():
    """`rationale` is free text a human typed. Interpolating it into SQL would be an
    injection, and an apostrophe alone would break the write."""
    wh = FakeWarehouse()
    nasty = "it's fine'); DROP TABLE audit.decisions; --"
    _store(wh).submit_feedback("g1", _submission(freeform=nasty))
    statement, params = wh.inserts[0]
    assert "DROP TABLE" not in statement
    assert nasty in params


def test_the_reserved_word_column_is_quoted():
    """`constraint` is reserved in SQL; unquoted, every insert is a syntax error."""
    wh = FakeWarehouse()
    _store(wh).submit_feedback("g1", _submission())
    statement, _ = wh.inserts[0]
    assert "`constraint`" in statement


def test_a_failed_write_raises_rather_than_reporting_success():
    """Telemetry is best-effort; an audit trail is not. Telling a reviewer their
    decision was recorded when it was not is the worst outcome available here."""
    wh = FakeWarehouse(fail_on="INSERT")
    with pytest.raises(StoreError, match="could not record decision"):
        _store(wh).submit_feedback("g1", _submission())


def test_an_attached_sink_is_used_when_there_is_one():
    """A job or notebook that does have Spark keeps a single writer for the table."""
    class Sink:
        def __init__(self):
            self.rows, self.errors = [], []

        def decision(self, row):
            self.rows.append(row)

    wh, sink = FakeWarehouse(), Sink()
    store = _store(wh).attach_sink(sink)
    receipt = store.submit_feedback("g1", _submission())
    assert len(sink.rows) == len(receipt.decision_rows)
    assert wh.inserts == []


def test_telemetry_reads_are_parameterized_on_run_id():
    """run_id arrives from a URL path."""
    wh = FakeWarehouse(rows=[])
    _store(wh).steps("r1; DROP TABLE x")
    statement, params = wh.statements[0]
    assert "DROP TABLE" not in statement
    assert params == ("r1; DROP TABLE x",)


def test_the_read_tables_come_from_the_sink_not_a_second_list():
    """Read and write halves of the audit contract must not drift."""
    from api.store_delta import KIND_TABLES
    from core.domo.sinks import DeltaSink

    assert set(KIND_TABLES.values()) == set(DeltaSink.TABLES.values())


def test_a_broken_read_is_a_store_error_naming_the_table():
    wh = FakeWarehouse(fail_on="SELECT")
    with pytest.raises(StoreError, match="cat.audit.steps"):
        _store(wh).steps("r1")
