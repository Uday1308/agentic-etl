"""The end-to-end mock run (scripts/e2e_mock_run.py + scripts/mocks.py).

This harness is the only thing that exercises all seven agents together, so it is
also the only place several integration contracts are checked at all. Two of these
tests exist because the run found real bugs: the classifier's section grammar only
matched PySpark comments, and md_plan's graph could not be constructed.

The tests assert what the run must keep being able to say, not the numbers it
happens to produce — the mocked figures are arbitrary and pinning them would make
this a change-detector.
"""
from __future__ import annotations

import json
import pathlib

import pytest

from agents.classifier.strategies import SectionSplitter
from api.store_local import LocalStore
from scripts.e2e_mock_run import run_pipeline, scripted_caller
from scripts.mocks import ScriptedCaller

REPO = pathlib.Path(__file__).resolve().parents[2]
DATAFLOW = "8099"


async def test_all_seven_agents_run_in_order(tmp_path):
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    from agents.master import AGENT_ORDER

    assert run.completed == list(AGENT_ORDER)


async def test_the_deterministic_half_stays_fully_deterministic(tmp_path):
    """8099 is the 100%-deterministic case. If a tile renderer regresses, a step
    silently becomes a model call or a passthrough, and that must fail loudly here
    rather than in a reviewer's SQL."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    gate = next(g for g in run.gates if g["agent"] == "md_plan")
    summary = gate["artifact"]["summary"]
    assert summary["steps"] == summary["deterministic"]
    assert summary["by_model"] == 0
    assert summary["unresolved"] == 0
    assert summary["coverage_pct"] == 100.0


async def test_every_target_assembles(tmp_path):
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    gate = next(g for g in run.gates if g["agent"] == "cd_codegen")
    targets = gate["artifact"]["targets"]
    assert len(targets) == 6
    assert all(t["ctes"] > 0 for t in targets)


async def test_the_run_is_visible_to_the_api_store(tmp_path):
    """The harness and the serving layer must agree on where things go. They are
    written and read by different modules, so nothing but a round trip proves it."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    store = LocalStore(REPO, work=tmp_path, samples=tmp_path / "no-samples",
                       volume=tmp_path / "volume")

    summary = store.summary(run.run_id)
    assert summary is not None
    assert summary.steps_run > 0
    assert summary.status == "complete"
    assert {g.agent for g in store.gates(run_id=run.run_id)} >= {
        "md_plan", "cd_codegen", "validation", "classifier"}


async def test_auto_approval_is_recorded_as_a_decision_by_a_named_actor(tmp_path):
    """Nobody reviewed anything. The audit trail has to say that rather than leave
    a gate looking humanly approved."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    store = LocalStore(REPO, work=tmp_path, samples=tmp_path / "no-samples",
                       volume=tmp_path / "volume")
    rows = store.decisions(run.run_id)
    assert rows, "auto-approval must still write decision rows"
    assert all(r.actor == "e2e-mock-run@localhost" for r in rows)
    assert all("no human reviewed this" in r.rationale for r in rows)


async def test_stop_at_leaves_that_gate_open_for_a_real_review(tmp_path):
    run = await run_pipeline(DATAFLOW, work=tmp_path, stop_at="md_plan")
    assert run.completed == ["connection", "standardization", "discovery", "md_plan"]
    store = LocalStore(REPO, work=tmp_path, samples=tmp_path / "no-samples",
                       volume=tmp_path / "volume")
    open_gates = store.gates(run_id=run.run_id, open_only=True)
    assert [g.agent for g in open_gates] == ["md_plan"]


async def test_by_default_every_mocked_target_matches(tmp_path):
    """The counts are invented either way, so the default is the happy path."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    gate = next(g for g in run.gates if g["agent"] == "validation")
    assert all(r["passed"] for r in gate["results"])


async def test_the_validation_gate_carries_logic_parity(tmp_path):
    """Validation is logic parity now: computed from the DOMO graph and the SQL,
    so it needs neither engine to have run. Every target must carry its checks."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    gate = next(g for g in run.gates if g["agent"] == "validation")
    assert gate["results"]
    for row in gate["results"]:
        assert row["checks_run"] >= 5
        assert row["passed"] is True
        # Row counts belong to data parity; null is the honest answer, not zero.
        assert row["source_rows"] is None and row["migrated_rows"] is None
        assert [c["check"] for c in row["checks"]]


async def test_model_calls_are_recorded_even_though_the_endpoint_is_faked(tmp_path):
    """The LLMClient is real, so a scripted answer still costs a LlmCallRow. Losing
    those would understate spend on a flow that genuinely used a model."""
    run = await run_pipeline(DATAFLOW, work=tmp_path)
    store = LocalStore(REPO, work=tmp_path, samples=tmp_path / "no-samples",
                       volume=tmp_path / "volume")
    calls = store.llm_calls(run.run_id)
    assert calls, "the standardizer and evaluators do call the model"
    assert all(c.tokens_in > 0 for c in calls)


# -- the bugs this harness found -------------------------------------------- #

def test_the_section_splitter_reads_sql_markers_not_just_pyspark():
    """Regression: SectionSplitter matched only `# [node: ...]`, so every SQL
    artifact parsed as zero sections — which does not raise, it just classifies
    nothing into every layer."""
    sql = "-- [node: df_a] op=FORMULA\ndf_a AS (SELECT 1)\n-- [/node: df_a]\n"
    pyspark = "# [node: df_b] op=FORMULA\ndf_b = df\n"
    assert list(SectionSplitter().sections(sql)) == ["df_a"]
    assert list(SectionSplitter().sections(pyspark)) == ["df_b"]


def test_the_md_plan_graph_can_be_constructed():
    """Regression: build_md_plan_graph passed `agent=`/`applier=` to a factory that
    takes `name=`/`feedback_applier=`, so the agent could never be built."""
    from unittest.mock import MagicMock

    from agents.md_plan.graph import build_md_plan_graph

    assert build_md_plan_graph(llm=MagicMock(), reader=MagicMock(),
                               store=MagicMock()) is not None


# -- the mock's own guarantees ------------------------------------------------ #

def test_an_unscripted_prompt_raises_rather_than_getting_a_plausible_answer():
    """A stand-in that happens to parse is how a fake answer reaches an artifact."""
    caller = ScriptedCaller().on("known prompt", "ok")
    with pytest.raises(KeyError, match="no response for this prompt"):
        caller(object(), "something nobody registered", None, 30)


def test_every_scripted_evaluator_response_is_a_valid_eval_result():
    """The evaluators parse these into EvalResult. A malformed canned answer would
    surface as an evaluator failure that has nothing to do with the platform."""
    from core.domo.schemas import EvalResult

    caller = scripted_caller()
    for fingerprint, text in caller._responses.items():
        if not text.strip().startswith("{") or text.strip() == "{}":
            continue
        parsed = EvalResult.model_validate_json(text)
        assert parsed.verdict is not None, fingerprint


def test_the_scripted_evaluator_invents_no_issues():
    """Scripted findings would populate the review UI with fictional problems and
    put words in a reviewer's mouth."""
    from core.domo.schemas import EvalResult

    for text in scripted_caller()._responses.values():
        if text.strip().startswith("{") and text.strip() != "{}":
            assert EvalResult.model_validate_json(text).issues == ()


def test_the_mock_domo_payload_admits_it_is_not_a_real_export(tmp_path):
    """The raw 8099 export does not exist in this repo; the standardized document is
    re-wrapped to stand in for it. Anything reading the artifact should be able to
    tell."""
    from scripts.mocks import MockDomoClient

    client = MockDomoClient(REPO / f"{DATAFLOW}_standardized.json", DATAFLOW)
    payload = client.fetch_dataflow(DATAFLOW)
    assert "_mock" in payload
    assert "scripts/mocks.py" in payload["_mock"]


async def test_gate_payloads_validate_against_the_api_gate_model(tmp_path):
    """The harness writes gates the API serves and the UI renders. If they drift the
    UI breaks at runtime, which no other test would catch."""
    from api.models import Gate

    run = await run_pipeline(DATAFLOW, work=tmp_path)
    for path in sorted((tmp_path / "gates").glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        gate = Gate.model_validate(payload)
        assert gate.gate_id and gate.agent and gate.run_id == run.run_id


# -- the run registry ---------------------------------------------------------- #

async def test_the_run_registry_records_what_produced_each_run(tmp_path):
    """Provenance is the half telemetry cannot answer: which export was read is
    the one thing nobody can reconstruct from the rows afterwards."""
    from api.models import RunRecord

    run = await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol")
    rows = json.loads((tmp_path / "vol" / "runs.json").read_text(encoding="utf-8"))
    record = RunRecord.model_validate(rows[0])
    assert record.run_id == run.run_id
    assert record.input_path.endswith(".json")
    assert record.agents_completed == run.completed
    assert record.mode == "mock"


async def test_the_registry_carries_no_counts(tmp_path):
    """RunSummary is computed from telemetry precisely so the dashboard and the
    deliverable cannot disagree. Copying counts here would hand that back."""
    await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol")
    row = json.loads((tmp_path / "vol" / "runs.json").read_text(encoding="utf-8"))[0]
    for banned in ("cost_usd", "steps_run", "llm_calls", "judges_run", "targets_total"):
        assert banned not in row, f"{banned} belongs to RunSummary, not the registry"


async def test_a_second_run_is_appended_not_overwritten(tmp_path):
    a = await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol")
    b = await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol")
    rows = json.loads((tmp_path / "vol" / "runs.json").read_text(encoding="utf-8"))
    assert {r["run_id"] for r in rows} >= {a.run_id, b.run_id}


async def test_a_stopped_run_records_where_it_stopped(tmp_path):
    await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol",
                       stop_at="md_plan")
    row = json.loads((tmp_path / "vol" / "runs.json").read_text(encoding="utf-8"))[0]
    assert row["stopped_at"] == "md_plan"
    assert row["agents_completed"] == ["connection", "standardization", "discovery",
                                       "md_plan"]


async def test_the_store_lists_runs_from_the_registry(tmp_path):
    run = await run_pipeline(DATAFLOW, work=tmp_path, volume=tmp_path / "vol")
    store = LocalStore(REPO, work=tmp_path, samples=tmp_path / "no-samples",
                       volume=tmp_path / "vol")
    assert [r.run_id for r in store.run_records()] == [run.run_id]
    assert run.run_id in [s.run_id for s in store.runs()]


async def test_a_corrupt_registry_is_set_aside_not_silently_emptied(tmp_path):
    """Losing the record of every prior run to one bad write would be worse than
    the bad write."""
    vol = tmp_path / "vol"
    vol.mkdir(parents=True)
    (vol / "runs.json").write_text("{ not json", encoding="utf-8")
    await run_pipeline(DATAFLOW, work=tmp_path, volume=vol)
    assert (vol / "runs.json.corrupt").exists()
    assert json.loads((vol / "runs.json").read_text(encoding="utf-8"))
