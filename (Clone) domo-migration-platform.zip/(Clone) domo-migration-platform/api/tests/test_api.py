"""API contracts (api.app + api.store_local).

The frontend is a separate codebase that cannot be type-checked against this one, so
these tests stand in for that compiler. They pin the promises `docs/frontend/CONTEXT.md`
makes to the UI — the ones that are quiet when broken:

* `interrupted` is a gate awaiting a human, not a failure;
* zero model calls is a success state, not an empty payload;
* per-issue decisions produce one audit row each, never one batched row;
* accepted feedback does NOT claim to have changed the generated SQL (gap #1);
* the artifact route is not a file browser.
"""
from __future__ import annotations

import json
import pathlib

import pytest
from fastapi.testclient import TestClient

from api.app import app, get_store
from api.store_local import LocalStore

REPO = pathlib.Path(__file__).resolve().parents[2]
SAMPLES = REPO / "docs" / "frontend" / "samples"


@pytest.fixture
def client(tmp_path):
    """A client on a store whose writes land in tmp_path, so tests never touch the
    developer's own review state."""
    # volume points at nothing: these tests must not see a dry run someone
    # happened to leave in the repo's ex_volume.
    store = LocalStore(REPO, work=tmp_path / "work",
                       volume=tmp_path / "no-volume",
                       # these tests are ABOUT the shipped sample payloads, so they
                       # ask for them by name rather than relying on a default
                       samples=REPO / "docs" / "frontend" / "samples")
    app.dependency_overrides[get_store] = lambda: store
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture
def submission():
    return {
        "accepted_issue_ids": ["i-null-guard-s10"],
        "rejected_issue_ids": ["i-cross-join-s30"],
        "freeform": "Guard the fallback with IFNULL.",
        "hard_constraints": ["Never rename source columns"],
        "actor": "reviewer@latentview.com",
        "rationales": {"i-null-guard-s10": "zero is the intended default",
                       "i-cross-join-s30": "one row per period by construction"},
        "constraint_rationales": {"Never rename source columns": "parity with DOMO"},
        "approve": False,
    }


# -- meta -------------------------------------------------------------------- #

def test_meta_serves_the_agent_vocabulary_from_master_not_a_copy():
    """CONTEXT.md forbids the UI hardcoding which agents ask a human. That only holds
    if the API serves master.py rather than a duplicate that can drift."""
    from agents.master import AGENT_DEFAULTS, AGENT_ORDER, AGENT_PHASES

    with TestClient(app) as c:
        meta = c.get("/api/meta").json()
    assert meta["agent_order"] == list(AGENT_ORDER)
    assert meta["agent_phases"]["md_plan"] == list(AGENT_PHASES["md_plan"])
    assert meta["agent_defaults"] == {k: dict(v) for k, v in AGENT_DEFAULTS.items()}


def test_meta_says_feedback_does_not_bind_the_generated_code(client):
    """Architecture gap #1. The UI must not tell a reviewer their change reached the
    SQL, so the API states it before the UI has to ask."""
    assert client.get("/api/meta").json()["binds_generated_code"] is False


def test_meta_serves_the_default_profile_as_domo_to_databricks(client, monkeypatch):
    """Any-to-any: the pair comes from the deployment, DOMO -> Databricks by default."""
    monkeypatch.delenv("MIGRATION_SOURCE", raising=False)
    monkeypatch.delenv("MIGRATION_TARGET", raising=False)
    profile = client.get("/api/meta").json()["profile"]
    assert profile["product"] == "LatentView Migration Platform"
    assert profile["source"]["id"] == "domo" and profile["source"]["label"] == "DOMO"
    assert profile["source"]["unit"] == "dataflow" and profile["source"]["step"] == "tile"
    assert profile["target"]["id"] == "databricks"
    assert profile["target"]["label"] == "Databricks"
    assert profile["target"]["catalog_label"] == "Unity Catalog"
    assert "logic" in profile["scope"].lower()


def test_meta_profile_follows_the_environment(client, monkeypatch):
    """A different pair is configuration, not a code change — and an id the platform
    does not know is served as itself and marked not ready, never as the default."""
    monkeypatch.setenv("MIGRATION_SOURCE", "Informatica")
    monkeypatch.setenv("MIGRATION_TARGET", "warehouse_x")
    profile = client.get("/api/meta").json()["profile"]
    assert profile["source"]["id"] == "informatica"
    assert profile["source"]["label"] == "Informatica"
    assert profile["target"] == {"id": "warehouse_x", "label": "warehouse_x",
                                 "dialects": ["SQL"], "catalog_label": "catalog",
                                 "ready": False}


# -- catalogue and gates ------------------------------------------------------ #

def test_the_catalogue_reports_coverage_from_the_artifact_not_a_recount(client):
    cards = {c["dataflow_id"]: c for c in client.get("/api/dataflows").json()}
    facts = json.loads((SAMPLES / "_8099_facts.json").read_text(encoding="utf-8"))
    assert cards["8099"]["steps"] == facts["steps"]
    assert cards["8099"]["coverage_pct"] == facts["coverage_pct"]
    assert cards["8099"]["unresolved"] == 0


def test_a_degraded_dataflow_reports_its_amber_and_red_counts(client):
    """8099 is 100% deterministic and never exercises those states; 7412 is the
    fixture that does. An unresolved step blocks promotion, so it has to survive
    the trip to the UI."""
    cards = {c["dataflow_id"]: c for c in client.get("/api/dataflows").json()}
    assert cards["7412"]["by_model"] == 2
    assert cards["7412"]["unresolved"] == 1


def test_an_open_gate_is_interrupted_and_that_is_not_an_error(client):
    gates = client.get("/api/gates", params={"open_only": True}).json()
    assert gates, "the samples carry open gates"
    assert all(g["status"] == "interrupted" for g in gates)
    assert all(g["resolved"] is False for g in gates)


def test_gates_come_back_in_pipeline_order(client):
    """A reviewer works the pipeline in order; md_plan is reviewed before cd_codegen."""
    from agents.master import AGENT_ORDER

    agents = [g["agent"] for g in client.get("/api/gates",
                                             params={"dataflow_id": "8099"}).json()]
    assert agents == sorted(agents, key=lambda a: AGENT_ORDER.index(a))


def test_judges_are_served_alongside_the_model_opinion_with_its_confidence(client):
    """Deterministic results are facts and the eval is an opinion. The UI shows the
    first above the second and labels the confidence, which needs both present."""
    gate = client.get("/api/gates/gate-md_plan-8099-i1").json()
    assert [j["rule_id"] for j in gate["judges"]]
    assert any(j["verdict"] == "fail" for j in gate["judges"])
    assert gate["eval"]["verdict"] == "revise"
    assert 0.0 <= gate["eval"]["confidence"] <= 1.0


def test_every_issue_carries_a_resolvable_ref(client):
    """`ref` is what scrolls the artifact to the step an issue is about. It is either
    step:<id> or node:<df_var> depending on the agent, and both must survive."""
    for gate_id in ("gate-md_plan-8099-i1", "gate-classifier-8099-i1"):
        gate = client.get(f"/api/gates/{gate_id}").json()
        refs = [i["ref"] for i in gate["eval"]["issues"]]
        assert refs and all(r.startswith(("step:", "node:")) for r in refs), gate_id


def test_the_all_green_gate_is_served_as_a_real_payload_not_an_empty_one(client):
    """cd_codegen on 8099 has zero issues by design. The UI needs to tell that apart
    from a payload that failed to load, so the envelope must still be complete."""
    gate = client.get("/api/gates/gate-cd_codegen-8099-i2").json()
    assert gate["eval"]["issues"] == []
    assert gate["eval"]["verdict"] == "pass"
    # cd_codegen's artifact block is per-target, not a summary. It must survive the
    # trip whole: six targets, each with its CTE count and EXPLAIN verdict.
    targets = gate["artifact"]["targets"]
    assert len(targets) == 6
    assert all(t["explain"] == "pass" and t["ctes"] > 0 for t in targets)
    assert gate["standing_hard_constraints"]


def test_a_missing_gate_is_404_not_an_empty_object(client):
    assert client.get("/api/gates/gate-does-not-exist").status_code == 404


# -- telemetry ---------------------------------------------------------------- #

def test_zero_model_calls_is_an_empty_list_and_a_200(client):
    """A deterministic dataflow makes no model calls. That is the target outcome, so
    it must not look like a failed fetch."""
    r = client.get("/api/runs/run-8099-2026-09-09T10-12-04/llm-calls")
    assert r.status_code == 200
    assert r.json() == []


def test_a_run_with_no_telemetry_still_reports_its_open_gate(client):
    """A gate exists the moment an agent pauses, which can precede any step row."""
    run = client.get("/api/runs/run-8099-2026-09-09T10-12-04").json()
    assert run["status"] == "interrupted"


def test_a_malformed_telemetry_line_names_the_file_and_line(client, tmp_path):
    """Silently dropping a bad row would understate cost or hide a failed step."""
    run_dir = tmp_path / "work" / "telemetry" / "run-x"
    run_dir.mkdir(parents=True)
    (run_dir / "steps.jsonl").write_text('{"nonsense": true}\n', encoding="utf-8")
    r = client.get("/api/runs/run-x/steps")
    assert r.status_code == 502
    assert "steps.jsonl:1" in r.json()["detail"]


# -- feedback ------------------------------------------------------------------ #

def test_one_decision_row_per_decision_plus_a_closing_row(client, submission):
    """A batched row cannot say which issue carried which rationale, and the rows are
    the client deviation report."""
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    assert r.status_code == 200
    kinds = [d["kind"] for d in r.json()["decision_rows"]]
    assert kinds == ["issue_accepted", "issue_rejected", "constraint_added", "regenerated"]


def test_each_decision_row_carries_the_reviewers_own_words(client, submission):
    rows = client.post("/api/gates/gate-md_plan-8099-i1/feedback",
                       json=submission).json()["decision_rows"]
    by_issue = {d["issue_id"]: d for d in rows if d["issue_id"]}
    assert by_issue["i-null-guard-s10"]["rationale"] == "zero is the intended default"
    assert by_issue["i-null-guard-s10"]["node"] == "step:s10"


def test_approving_writes_approved_and_sending_back_writes_regenerated(client, submission):
    back = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    assert back.json()["decision_rows"][-1]["kind"] == "regenerated"
    ok = client.post("/api/gates/gate-cd_codegen-8099-i2/feedback",
                     json={**submission, "approve": True, "accepted_issue_ids": [],
                           "rejected_issue_ids": [], "rationales": {}})
    assert ok.json()["decision_rows"][-1]["kind"] == "approved"


def test_the_receipt_does_not_claim_the_sql_changed(client, submission):
    """The worst thing this endpoint could do is tell a reviewer their fix landed."""
    body = client.post("/api/gates/gate-md_plan-8099-i1/feedback",
                       json=submission).json()
    assert body["binds_generated_code"] is False
    assert "do not yet alter the generated SQL" in body["note"]


def test_an_issue_id_the_gate_never_raised_is_refused(client, submission):
    """A decision row pointing at an issue nobody raised is worse than no row."""
    bad = {**submission, "accepted_issue_ids": ["i-invented"]}
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=bad)
    assert r.status_code == 422
    assert "i-invented" in r.json()["detail"]


def test_one_issue_cannot_be_both_accepted_and_rejected(client, submission):
    clash = {**submission, "rejected_issue_ids": ["i-null-guard-s10"]}
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=clash)
    assert r.status_code == 422


def test_feedback_persists_so_the_gate_stops_asking(client, submission):
    assert client.get("/api/gates/gate-md_plan-8099-i1").json()["resolved"] is False
    client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    assert client.get("/api/gates/gate-md_plan-8099-i1").json()["resolved"] is True
    open_ids = [g["gate_id"] for g in
                client.get("/api/gates", params={"open_only": True}).json()]
    assert "gate-md_plan-8099-i1" not in open_ids


def test_an_approval_shows_on_the_gate_as_approved_with_a_decision(client, submission):
    g = client.get("/api/gates/gate-md_plan-8099-i1").json()
    assert g["approved"] is False and g["decision"] is None
    client.post("/api/gates/gate-md_plan-8099-i1/feedback", json={**submission, "approve": True})
    g = client.get("/api/gates/gate-md_plan-8099-i1").json()
    assert g["approved"] is True and g["decision"] == "approved"


def test_the_decision_rows_reach_the_run_audit_trail(client, submission):
    run_id = "run-8099-2026-09-09T10-12-04"
    assert client.get(f"/api/runs/{run_id}/decisions").json() == []
    client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    rows = client.get(f"/api/runs/{run_id}/decisions").json()
    assert len(rows) == 4
    assert all(r["actor"] == submission["actor"] for r in rows)


def test_the_submitted_shape_matches_the_documented_sample(client):
    """docs/frontend/samples/submission_md_plan.json is what the UI was built against;
    the API must accept exactly that and write exactly those rows."""
    sample = json.loads((SAMPLES / "submission_md_plan.json").read_text(encoding="utf-8"))
    hf = sample["human_feedback"]
    r = client.post(f"/api/gates/{sample['gate_id']}/feedback", json={
        "accepted_issue_ids": hf["accepted_issue_ids"],
        "rejected_issue_ids": hf["rejected_issue_ids"],
        "freeform": hf["freeform"], "hard_constraints": hf["hard_constraints"],
        "actor": hf["actor"], "approve": False})
    assert r.status_code == 200
    written = [d["kind"] for d in r.json()["decision_rows"]]
    assert written == [d["kind"] for d in sample["decision_rows_written"]]


# -- artifacts ------------------------------------------------------------------ #

def test_artifacts_are_listed_with_their_version(client):
    arts = client.get("/api/dataflows/8099/artifacts").json()
    assert arts and all(a["version"] >= 1 for a in arts)
    assert {"plan", "sql", "debug"} <= {a["kind"] for a in arts}


def test_a_versioned_gate_path_resolves_to_the_local_dry_run_artifact(client):
    """The gate names plan_8099_v1.md on a volume; the dry run wrote plan_8099.md."""
    arts = client.get("/api/dataflows/8099/artifacts").json()
    plan = next(a for a in arts if a["kind"] == "plan")
    body = client.get("/api/artifact", params={"path": plan["path"]}).json()
    assert "ETL Migration" in body["text"]


def test_the_artifact_route_is_not_a_file_browser(client):
    """The path comes from the client, so without a root check this is arbitrary read."""
    r = client.get("/api/artifact", params={"path": "C:/Windows/win.ini"})
    assert r.status_code == 502
    assert "outside the artifact roots" in r.json()["detail"] or "no artifact" in r.json()["detail"]


def test_an_unreadable_store_is_a_502_that_says_why_not_an_empty_page(client):
    r = client.get("/api/artifact", params={"path": "/Volumes/x/never-existed.md"})
    assert r.status_code == 502
    assert "never-existed.md" in r.json()["detail"]
