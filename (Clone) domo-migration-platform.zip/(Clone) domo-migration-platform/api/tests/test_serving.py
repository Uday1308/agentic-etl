"""Deployment behaviour (api.serving + the App-mode branches in api.app).

These cover the three things that differ between "runs on my laptop" and "hosted for
a team", each of which is a correctness problem rather than packaging:

* the reviewer recorded in the audit trail is the authenticated one, not whoever the
  browser claimed to be;
* an ephemeral local file store is refused rather than silently losing reviews;
* one process serves both the API and the built SPA, deep links included.
"""
from __future__ import annotations

import pathlib

import pytest
from fastapi.testclient import TestClient

from api.app import app, get_store
from api.serving import is_databricks_app, reviewer_from_headers
from api.store_local import LocalStore

REPO = pathlib.Path(__file__).resolve().parents[2]


@pytest.fixture
def client(tmp_path):
    # volume points at nothing: these tests must not see a dry run someone
    # happened to leave in the repo's ex_volume.
    store = LocalStore(REPO, work=tmp_path / "work",
                       volume=tmp_path / "no-volume",
                       # these tests are ABOUT the shipped sample payloads, so they
                       # ask for them by name rather than relying on a default
                       samples=REPO / "docs" / "frontend" / "samples")
    app.dependency_overrides[get_store] = lambda: store
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture
def submission():
    return {"accepted_issue_ids": [], "rejected_issue_ids": [], "freeform": "ok",
            "hard_constraints": [], "actor": "typed-into-the-browser@example.com",
            "approve": True}


@pytest.fixture
def as_app(monkeypatch):
    """Pretend to be inside the Databricks Apps runtime."""
    monkeypatch.setenv("DATABRICKS_APP_PORT", "8000")


# -- identity ---------------------------------------------------------------- #

def test_the_authenticated_reviewer_overrides_whatever_the_client_sent(client, submission):
    """These rows are the client deviation report. A decision filed under someone
    else's name is the one thing that makes it worthless."""
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission,
                    headers={"X-Forwarded-Email": "real.reviewer@latentview.com"})
    assert r.status_code == 200
    body = r.json()
    assert body["human_feedback"]["actor"] == "real.reviewer@latentview.com"
    assert all(d["actor"] == "real.reviewer@latentview.com"
               for d in body["decision_rows"])


def test_identity_headers_are_tried_in_order(client, submission):
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission,
                    headers={"X-Forwarded-User": "fallback@latentview.com"})
    assert r.json()["human_feedback"]["actor"] == "fallback@latentview.com"


def test_no_identity_header_in_an_app_is_refused(client, submission, as_app):
    """Rather than record the browser's claim under OAuth, which would look
    authenticated and not be."""
    r = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    assert r.status_code == 401
    assert "refusing to record a decision" in r.json()["detail"]


def test_locally_the_submitted_actor_stands_but_may_not_be_blank(client, submission):
    ok = client.post("/api/gates/gate-md_plan-8099-i1/feedback", json=submission)
    assert ok.status_code == 200
    assert ok.json()["human_feedback"]["actor"] == submission["actor"]

    blank = client.post("/api/gates/gate-cd_codegen-8099-i2/feedback",
                        json={**submission, "actor": "   "})
    assert blank.status_code == 422


def test_reviewer_from_headers_never_invents_a_name():
    assert reviewer_from_headers({}) == ""
    assert reviewer_from_headers({"X-Forwarded-Email": "   "}) == ""
    assert reviewer_from_headers({"X-Forwarded-Email": "a@b.c"}) == "a@b.c"


# -- store safety -------------------------------------------------------------- #

def test_a_file_store_is_refused_inside_an_app(as_app, monkeypatch):
    """An App instance's disk is ephemeral, so a file-backed review trail vanishes
    when it is replaced. Refusing to start beats losing decisions quietly."""
    monkeypatch.setenv("PLATFORM_STORE", "local")
    get_store.cache_clear()
    with pytest.raises(RuntimeError, match="ephemeral disk"):
        get_store()
    get_store.cache_clear()


def test_delta_is_the_default_when_deployed(as_app, monkeypatch):
    monkeypatch.delenv("PLATFORM_STORE", raising=False)
    assert is_databricks_app() is True
    get_store.cache_clear()
    # no warehouse configured, so it must fail on THAT rather than fall back to files
    with pytest.raises(Exception) as exc:
        get_store()
    assert "warehouse" in str(exc.value).lower() or "databricks" in str(exc.value).lower()
    get_store.cache_clear()


def test_local_is_the_default_off_platform():
    assert is_databricks_app() is False


# -- one process, one port ------------------------------------------------------ #

def test_the_spa_is_served_from_the_api_process(client):
    """Deployed there is no vite. If this 404s, the bundle was never built."""
    if not pathlib.Path(REPO / "lv-tower" / "dist" / "index.html").exists():
        pytest.skip("frontend not built (npm run build)")
    r = client.get("/")
    assert r.status_code == 200
    assert "text/html" in r.headers["content-type"]


def test_a_deep_link_falls_back_to_the_shell_not_a_404(client):
    """Client-side routing means /dataflow/8099 is not a file. Without the fallback
    every refresh on a deep link 404s."""
    if not pathlib.Path(REPO / "lv-tower" / "dist" / "index.html").exists():
        pytest.skip("frontend not built")
    assert client.get("/dataflows/8099/review").status_code == 200


def test_an_unknown_api_route_is_still_a_404(client):
    """The catch-all must not answer a broken fetch with the HTML shell - that turns
    a failed request into what looks like a successful page load."""
    r = client.get("/api/not-a-route")
    assert r.status_code == 404
    assert "text/html" not in r.headers.get("content-type", "")


def test_serving_reports_how_this_process_is_deployed(client):
    body = client.get("/api/serving").json()
    assert set(body) == {"databricks_app", "spa", "store"}
