"""A pack (Snowflake) run is summarised from its run.json; its gates and hash-stored artifacts are reachable."""
from __future__ import annotations

import json
import pathlib

import pytest
from fastapi.testclient import TestClient

from agents.cd_codegen.translate.artifacts import write_artifact
from api.app import app, get_store
from api.store_local import LocalStore

REPO = pathlib.Path(__file__).resolve().parents[2]
RUN = "run-k1-2026-10-22T10-11-12"


@pytest.fixture
def client(tmp_path):
    vol = tmp_path / "vol"
    d = vol / "k1" / RUN
    (d / "gates").mkdir(parents=True)
    stored = write_artifact(vol, "k1", "select 1", source_id="s", kind="sql")
    (d / "run.json").write_text(json.dumps({
        "etl_id": "1", "etl_key": "k1", "run_id": RUN, "status": "awaiting_review", "completed": ["routing"],
        "failures": [], "held": [{"gate_id": "gate-cd_codegen-k1-i1"}], "ts": "2026-10-22T10:12:00+00:00",
        "units": [{"unit_id": "a", "status": "resolved"}, {"unit_id": "b", "status": "unresolved"}]}), encoding="utf-8")
    (d / "gates" / "gate-cd_codegen-k1-i1.json").write_text(json.dumps({
        "gate_id": "gate-cd_codegen-k1-i1", "run_id": RUN, "dataflow_id": "k1", "agent": "cd_codegen",
        "status": "interrupted", "judges": [],
        "artifact": {"kind": "sql", "artifacts": [{"kind": "sql", "name": "n", "artifact_ref": stored.artifact_ref,
                                                    "sha256": stored.sha256, "origin": "mapped"}]}}), encoding="utf-8")
    store = LocalStore(REPO, work=tmp_path / "work", volume=vol, samples=tmp_path / "none")
    app.dependency_overrides[get_store] = lambda: store
    yield TestClient(app), stored
    app.dependency_overrides.clear()


def test_run_summary_comes_from_run_json(client):
    c, _ = client
    s = c.get(f"/api/runs/{RUN}").json()
    assert s["status"] == "awaiting_review" and s["source"] == "pack"
    assert s["started_ts"].startswith("2026-10-22T10:11:12") and s["ended_ts"].startswith("2026-10-22T10:12")
    assert s["units_total"] == 2 and s["units_by_status"] == {"resolved": 1, "unresolved": 1}
    listed = [r for r in c.get("/api/runs").json() if r["run_id"] == RUN]
    assert len(listed) == 1 and listed[0]["status"] == "awaiting_review"


def test_pack_gate_is_listed_and_artifacts_open_by_ref(client):
    c, stored = client
    gates = c.get("/api/gates", params={"open_only": True}).json()
    assert [g["gate_id"] for g in gates] == ["gate-cd_codegen-k1-i1"]
    assert c.get("/api/gates/gate-cd_codegen-k1-i1").status_code == 200
    refs = c.get("/api/dataflows/k1/artifacts").json()
    assert [a["ref"] for a in refs] == [stored.artifact_ref] and refs[0]["path"] == ""
    assert c.get(f"/api/artifacts/{stored.artifact_ref}").json()["text"] == "select 1"


def test_pack_gate_is_approvable(client):
    c, _ = client
    r = c.post("/api/gates/gate-cd_codegen-k1-i1/feedback", json={"actor": "r@x.invalid", "approve": True})
    assert r.status_code == 200, r.text
    assert c.get("/api/gates", params={"open_only": True}).json() == []
