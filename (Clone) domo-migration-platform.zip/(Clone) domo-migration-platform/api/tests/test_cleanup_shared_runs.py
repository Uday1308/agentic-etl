"""Deleting a resumed batch must not delete the run folders it only carried over from the batch it resumed."""
from __future__ import annotations

import json

from api.cleanup import delete_batch


def _report(vol, key, bid, rows):
    d = vol / "batches" / key
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{bid}.json").write_text(json.dumps({"etls": rows}), encoding="utf-8")


def test_deleting_a_resume_keeps_the_carried_over_run_folders(tmp_path):
    vol, work = tmp_path / "vol", tmp_path / "work"
    old, new = vol / "k1" / "run-k1-a", vol / "k2" / "run-k2-b"
    for d in (old, new):
        d.mkdir(parents=True)
        (d / "run.json").write_text("{}", encoding="utf-8")
    _report(vol, "w", "batch-w-1", [{"run_dir": str(old)}])
    _report(vol, "w", "batch-w-2", [{"run_dir": str(old)}, {"run_dir": str(new)}])      # carried + re-run
    assert delete_batch(vol, work, "batch-w-2") is not None
    assert (old / "run.json").exists() and not new.exists()
