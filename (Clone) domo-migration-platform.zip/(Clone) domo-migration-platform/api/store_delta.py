"""api.store_delta — the store that reads the real audit tables and volume.

The write side already exists: ``core.domo.sinks.DeltaSink`` appends every telemetry
row to six tables. This is the read side of that same contract, and it deliberately
reuses ``DeltaSink.TABLES`` rather than restating the names — a table renamed in one
place and not the other would surface as an empty dashboard rather than an error.

Two seams are injected, for the reason the rest of the platform injects seams: the
class stays importable and unit-testable with no cluster, no warehouse and no
credentials.

    query(sql, params) -> list[dict]    one SQL read against the audit schema
    read_file(path) -> str              one artifact off the UC volume

``connect_databricks()`` builds the pair from environment variables when you want the
real thing. Nothing else in this module knows what a warehouse is.

One assumption is worth stating plainly, because it is not yet pinned by a contract:
**gate payloads are read as JSON from the volume**, under
``<volume>/<dataflow_name>/gates/``. There is no gate table in
``core.contracts.telemetry`` — a HITL pause currently lives in the LangGraph
checkpoint, which is not a thing an HTTP read layer should be reaching into. If the
platform later writes gates to a table, only ``_gate_payloads`` changes.
"""
from __future__ import annotations

import json
import os
from typing import Callable

from api.models import (
    CARD_AWAITING_REVIEW,
    ArtifactRef,
    DataflowCard,
    FeedbackReceipt,
    FeedbackSubmission,
    Gate,
    RunRecord,
)
from api.ports import PlatformStore, StoreError
from api.store_local import ROW_TYPES, build_receipt
from core.contracts.telemetry import (
    DecisionRow,
    IngestionRow,
    JudgeRow,
    LlmCallRow,
    RunSummary,
    StepRow,
    ValidationRow,
    summarize,
)
from core.domo.sinks import DeltaSink

#: port method -> (telemetry kind, the table DeltaSink writes it to). Derived from the
#: sink so the two halves of the contract cannot drift apart.
KIND_TABLES = {
    "steps": DeltaSink.TABLES["step"],
    "llm_calls": DeltaSink.TABLES["llm_call"],
    "ingestions": DeltaSink.TABLES["ingestion"],
    "judges": DeltaSink.TABLES["judge"],
    "validations": DeltaSink.TABLES["validation"],
    "decisions": DeltaSink.TABLES["decision"],
}


class DeltaStore(PlatformStore):
    """Reads the audit tables and the artifact volume."""

    name = "delta"

    def __init__(self, query: Callable[[str, tuple], list[dict]],
                 *, catalog: str, schema: str, volume: str = "",
                 read_file: Callable[[str], str] | None = None,
                 list_files: Callable[[str], list[str]] | None = None) -> None:
        self._query = query
        self._prefix = f"{catalog}.{schema}"
        self._volume = volume.rstrip("/")
        self._read_file = read_file
        self._list_files = list_files

    # -- reading ------------------------------------------------------------ #
    def _rows(self, run_id: str, kind: str) -> list:
        """One telemetry table, filtered to a run and validated into its model.

        Parameterized, not interpolated: ``run_id`` reaches here from a URL path.
        """
        model = ROW_TYPES[kind]
        table = f"{self._prefix}.{KIND_TABLES[kind]}"
        try:
            raw = self._query(f"SELECT * FROM {table} WHERE run_id = ? ORDER BY ts",
                              (run_id,))
        except Exception as exc:            # noqa: BLE001 - surfaced as 502, not hidden
            raise StoreError(f"reading {table}: {type(exc).__name__}: {exc}") from exc
        out = []
        for i, row in enumerate(raw):
            try:
                out.append(model.model_validate(row))
            except ValueError as exc:
                raise StoreError(
                    f"{table} row {i} is not a valid {model.__name__}: {exc}") from exc
        return out

    def steps(self, run_id: str) -> list[StepRow]:
        return self._rows(run_id, "steps")

    def llm_calls(self, run_id: str) -> list[LlmCallRow]:
        return self._rows(run_id, "llm_calls")

    def ingestions(self, run_id: str) -> list[IngestionRow]:
        return self._rows(run_id, "ingestions")

    def judges(self, run_id: str) -> list[JudgeRow]:
        return self._rows(run_id, "judges")

    def validations(self, run_id: str) -> list[ValidationRow]:
        return self._rows(run_id, "validations")

    def decisions(self, run_id: str) -> list[DecisionRow]:
        return self._rows(run_id, "decisions")

    # -- catalogue ---------------------------------------------------------- #
    def _run_ids(self, dataflow_id: str = "") -> list[str]:
        table = f"{self._prefix}.{KIND_TABLES['steps']}"
        try:
            rows = self._query(
                f"SELECT run_id, MIN(ts) AS started FROM {table} "
                f"GROUP BY run_id ORDER BY started DESC", ())
        except Exception as exc:            # noqa: BLE001
            raise StoreError(f"listing runs from {table}: {exc}") from exc
        # Registry first when there is one: it is a single read instead of a scan
        # of the whole steps table, and it lists runs that wrote no telemetry.
        registered = [r.run_id for r in self.run_records()]
        ids = registered + [str(r["run_id"]) for r in rows
                            if str(r["run_id"]) not in set(registered)]
        if not dataflow_id:
            return ids
        return [rid for rid in ids
                if any(g.dataflow_id == dataflow_id for g in self.gates(run_id=rid))]

    def run_records(self) -> list[RunRecord]:
        """``runs.json`` from the volume root. Empty when nothing writes one, in
        which case ``runs()`` falls back to grouping the steps table."""
        if not (self._volume and self._read_file):
            return []
        try:
            raw = self._read_file(f"{self._volume}/runs.json")
        except Exception:               # noqa: BLE001 - absent registry is normal
            return []
        try:
            rows = [RunRecord.model_validate(r) for r in json.loads(raw)]
        except Exception as exc:        # noqa: BLE001
            raise StoreError(f"{self._volume}/runs.json is not a valid registry: "
                             f"{exc}") from exc
        return sorted(rows, key=lambda r: r.started_ts or r.run_id, reverse=True)

    def runs(self, dataflow_id: str = "") -> list[RunSummary]:
        out = []
        for rid in self._run_ids(dataflow_id):
            s = self.summary(rid)
            if s:
                out.append(s)
        return out

    def summary(self, run_id: str) -> RunSummary | None:
        steps = self._rows(run_id, "steps")
        llm = self._rows(run_id, "llm_calls")
        ingest = self._rows(run_id, "ingestions")
        judged = self._rows(run_id, "judges")
        validated = self._rows(run_id, "validations")
        decisions = self._rows(run_id, "decisions")
        if not any([steps, llm, ingest, judged, validated, decisions]):
            return None
        gate = next(iter(self.gates(run_id=run_id)), None)
        ordered = sorted(steps, key=lambda s: s.ts)
        if any(s.status.value == "interrupted" for s in steps):
            status = "interrupted"
        elif any(s.status.value == "failed" for s in steps):
            status = "failed"
        elif steps and all(s.status.value in ("ok", "skipped") for s in steps):
            status = "complete"
        else:
            status = "running"
        return summarize(
            run_id, gate.dataflow_id if gate else "",
            llm=llm, steps=steps, ingest=ingest, judged=judged,
            validated=validated, decisions=decisions,
            dataflow_name=gate.dataflow_name if gate else "",
            status=status,
            started_ts=ordered[0].ts if ordered else "",
            ended_ts=ordered[-1].ts if ordered and status != "running" else "")

    def dataflows(self) -> list[DataflowCard]:
        cards: dict[str, DataflowCard] = {}
        for g in self._gate_payloads():
            did = g.dataflow_id
            if not did:
                continue
            card = cards.get(did) or DataflowCard(dataflow_id=did)
            card.dataflow_name = card.dataflow_name or g.dataflow_name
            card.latest_run_id = card.latest_run_id or g.run_id
            if g.artifact and g.artifact.summary:
                s = g.artifact.summary
                card.sources, card.steps, card.targets = s.sources, s.steps, s.targets
                card.deterministic, card.by_model = s.deterministic, s.by_model
                card.unresolved, card.coverage_pct = s.unresolved, s.coverage_pct
            if g.status == "interrupted" and not g.resolved:
                card.status = CARD_AWAITING_REVIEW
            cards[did] = card
        return [cards[k] for k in sorted(cards)]

    # -- review -------------------------------------------------------------- #
    def _gate_payloads(self) -> list[Gate]:
        """Gate JSON off the volume. See the module docstring for why it lives there."""
        if not (self._volume and self._list_files and self._read_file):
            return []
        try:
            paths = [p for p in self._list_files(self._volume)
                     if "/gates/" in p.replace("\\", "/") and p.endswith(".json")]
        except Exception as exc:            # noqa: BLE001
            raise StoreError(f"listing gates under {self._volume}: {exc}") from exc
        gates = []
        for p in sorted(paths):
            try:
                gates.append(Gate.model_validate(json.loads(self._read_file(p))))
            except Exception as exc:        # noqa: BLE001
                raise StoreError(f"{p} is not a valid gate payload: {exc}") from exc
        return gates

    def gates(self, *, run_id: str = "", dataflow_id: str = "",
              open_only: bool = False) -> list[Gate]:
        from agents.master import AGENT_ORDER

        out = self._gate_payloads()
        if run_id:
            out = [g for g in out if g.run_id == run_id]
        if dataflow_id:
            out = [g for g in out if g.dataflow_id == dataflow_id]
        # a gate is resolved once a closing decision row exists for that agent+iteration
        for g in out:
            closing = {(d.agent, d.iteration) for d in self.decisions(g.run_id)
                       if d.kind.value in ("approved", "regenerated")}
            g.resolved = (g.agent, g.iteration) in closing
            g.approved = g.resolved
            g.decision = "approved" if g.resolved else None
        if open_only:
            out = [g for g in out if g.status == "interrupted" and not g.resolved]
        order = {a: i for i, a in enumerate(AGENT_ORDER)}
        return sorted(out, key=lambda g: (g.dataflow_id, order.get(g.agent, 99),
                                          g.iteration))

    def gate(self, gate_id: str) -> Gate | None:
        return next((g for g in self.gates() if g.gate_id == gate_id), None)

    def submit_feedback(self, gate_id: str,
                        submission: FeedbackSubmission) -> FeedbackReceipt:
        """Write the audit rows through the same sink the agents use.

        Deliberately not an INSERT built here: ``DeltaSink.decision`` already owns how
        a ``DecisionRow`` reaches the table, including that telemetry failures never
        propagate. Two writers for one table is how schemas drift.
        """
        gate = self.gate(gate_id)
        if gate is None:
            raise StoreError(f"no gate {gate_id!r}")
        receipt = build_receipt(gate, submission)

        sink = getattr(self, "_sink", None)
        if sink is not None:
            # A caller that has Spark (a job, a notebook) can hand us DeltaSink and
            # keep one writer for the table.
            for row in receipt.decision_rows:
                sink.decision(row)
            if getattr(sink, "errors", None):
                raise StoreError(f"decision rows failed to write: {sink.errors[-3:]}")
            return receipt

        # No Spark: a Databricks App has none, so the rows go through the same SQL
        # warehouse everything else is read over. Deliberately NOT best-effort the
        # way telemetry is - dropping a row from a migration's audit trail while
        # telling the reviewer their decision was recorded is the worst outcome here,
        # so a failed write raises and the UI sees it.
        self._insert_decisions(receipt.decision_rows)
        return receipt

    #: Written in the order DecisionRow declares them. `constraint` is a reserved
    #: word in SQL, hence the backticks on every identifier rather than just that one.
    _DECISION_COLUMNS = ("run_id", "ts", "environment", "dataflow_id", "agent",
                         "iteration", "kind", "actor", "issue_id", "node",
                         "rationale", "constraint")

    def _insert_decisions(self, rows: list[DecisionRow]) -> None:
        if not rows:
            return
        table = f"{self._prefix}.{KIND_TABLES['decisions']}"
        cols = ", ".join(f"`{c}`" for c in self._DECISION_COLUMNS)
        placeholders = ", ".join("?" for _ in self._DECISION_COLUMNS)
        for row in rows:
            data = row.model_dump(mode="json")
            values = tuple(data.get(c) for c in self._DECISION_COLUMNS)
            try:
                self._query(f"INSERT INTO {table} ({cols}) VALUES ({placeholders})",
                            values)
            except Exception as exc:        # noqa: BLE001
                raise StoreError(
                    f"could not record decision {data.get('kind')} "
                    f"{data.get('issue_id') or ''} into {table}: "
                    f"{type(exc).__name__}: {exc}") from exc

    def attach_sink(self, sink) -> "DeltaStore":
        """Give this store the ``DeltaSink`` it writes decision rows through."""
        self._sink = sink
        return self

    # -- artifacts ------------------------------------------------------------ #
    def artifacts(self, dataflow_id: str) -> list[ArtifactRef]:
        out = [g.artifact for g in self.gates(dataflow_id=dataflow_id) if g.artifact]
        if self._volume and self._list_files:
            name = next((g.dataflow_name for g in self.gates(dataflow_id=dataflow_id)
                         if g.dataflow_name), "")
            try:
                paths = self._list_files(self._volume)
            except Exception as exc:        # noqa: BLE001
                raise StoreError(f"listing {self._volume}: {exc}") from exc
            for p in sorted(paths):
                base = p.replace("\\", "/").rsplit("/", 1)[-1]
                if dataflow_id not in base and (not name or name not in p):
                    continue
                if base.startswith("plan_") and base.endswith(".md"):
                    version = _version_of(base)
                    out.append(ArtifactRef(kind="plan", version=version, path=p))
                elif base.startswith("etl_") and base.endswith(".sql"):
                    out.append(ArtifactRef(kind="sql", version=_version_of(base), path=p,
                                           target=base[:-4].split("__", 1)[-1]))
                elif base.startswith("debug_") and base.endswith(".sql"):
                    out.append(ArtifactRef(kind="debug", version=_version_of(base), path=p,
                                           target=base[:-4].split("__", 1)[-1]))
        seen: set[str] = set()
        unique: list[ArtifactRef] = []
        for a in out:
            if a.path not in seen:
                seen.add(a.path)
                unique.append(a)
        return unique

    def graph(self, dataflow_id: str) -> list[dict]:
        """``graph_<id>.json`` off the volume, written by the codegen stage."""
        if not (self._volume and self._list_files and self._read_file):
            return []
        want = f"graph_{dataflow_id}.json"
        try:
            path = next((p for p in self._list_files(self._volume)
                         if p.replace("\\", "/").endswith(want)), None)
            return json.loads(self._read_file(path)) if path else []
        except Exception as exc:            # noqa: BLE001
            raise StoreError(f"reading {want}: {type(exc).__name__}: {exc}") from exc

    def artifact_content(self, path: str) -> str:
        if not self._read_file:
            raise StoreError("this DeltaStore was built without a volume reader")
        if self._volume and not path.replace("\\", "/").startswith(self._volume):
            raise StoreError(f"{path!r} is outside the artifact volume this store serves")
        try:
            return self._read_file(path)
        except Exception as exc:            # noqa: BLE001
            raise StoreError(f"reading {path}: {type(exc).__name__}: {exc}") from exc


def _version_of(basename: str) -> int:
    """``plan_8099_v3.md`` -> 3. Unversioned names are version 1."""
    stem = basename.rsplit(".", 1)[0]
    tail = stem.rsplit("_v", 1)[-1] if "_v" in stem else ""
    return int(tail) if tail.isdigit() else 1


def connect_databricks() -> tuple[Callable, Callable, Callable]:
    """Build ``(query, read_file, list_files)`` from the environment.

    Imported lazily and called only when ``PLATFORM_STORE=delta``, so neither the
    connector nor the SDK is needed to run the local store or the tests.

    Authentication goes through the SDK's default credential chain, so the same code
    works from an App (its service principal), a laptop (a CLI profile) and a job.
    The warehouse comes from ``DATABRICKS_WAREHOUSE_ID`` or ``DATABRICKS_HTTP_PATH``.
    """
    from databricks import sql as dbsql  # noqa: PLC0415 - deliberately lazy
    from databricks.sdk import WorkspaceClient  # noqa: PLC0415
    from databricks.sdk.core import Config  # noqa: PLC0415

    # Default credential chain, not hand-rolled env parsing. Inside a Databricks App
    # this resolves the app's own service principal with nothing configured; outside
    # it still honours DATABRICKS_HOST/TOKEN, a profile, or a CLI login. Reading the
    # token out of the environment ourselves would work in exactly one of those.
    cfg = Config()

    http_path = os.environ.get("DATABRICKS_HTTP_PATH", "")
    if not http_path:
        warehouse = os.environ.get("DATABRICKS_WAREHOUSE_ID", "")
        if warehouse:
            http_path = f"/sql/1.0/warehouses/{warehouse}"
    if not http_path:
        raise StoreError(
            "PLATFORM_STORE=delta needs a SQL warehouse: set DATABRICKS_WAREHOUSE_ID "
            "(or DATABRICKS_HTTP_PATH). In a Databricks App, declare a sql_warehouse "
            "resource in app.yaml and it is injected for you.")

    def query(statement: str, params: tuple = ()) -> list[dict]:
        with dbsql.connect(server_hostname=cfg.hostname, http_path=http_path,
                           credentials_provider=lambda: cfg.authenticate) as conn:
            with conn.cursor() as cur:
                cur.execute(statement, params or None)
                if cur.description is None:      # INSERT and friends return no rows
                    return []
                cols = [c[0] for c in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]

    client = WorkspaceClient(config=cfg)

    def read_file(path: str) -> str:
        return client.files.download(path).contents.read().decode("utf-8")

    def list_files(root: str) -> list[str]:
        out: list[str] = []
        stack = [root]
        while stack:
            here = stack.pop()
            for entry in client.files.list_directory_contents(here):
                if entry.is_directory:
                    stack.append(entry.path)
                else:
                    out.append(entry.path)
        return out

    return query, read_file, list_files


__all__ = ["DeltaStore", "KIND_TABLES", "connect_databricks"]
