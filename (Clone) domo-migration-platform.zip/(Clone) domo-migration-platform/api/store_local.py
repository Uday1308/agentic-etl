"""api.store_local — the store that runs on a laptop, with no warehouse.

Reads what this repo already contains: the sample gate payloads in
``docs/frontend/samples``, the artifacts ``scripts/local_dryrun.py`` writes into
``dryrun_out``, and telemetry as JSONL under a working directory. Writes feedback and
decision rows back into that same working directory, so a review round-trips and
survives a restart.

It exists so the frontend can be developed and demonstrated end to end without
Databricks. It is not a simulator: it never invents a telemetry row. If nothing has
written steps for a run, ``steps()`` returns empty and the UI shows an empty progress
view, which is the truth. ``scripts/seed_local_telemetry.py`` is the separate, explicit
way to put demo rows there.
"""
from __future__ import annotations

import json
import os
import pathlib
import re
from typing import Any

from api.models import (
    CARD_AWAITING_REVIEW,
    ArtifactRef,
    DataflowCard,
    FeedbackReceipt,
    FeedbackSubmission,
    Gate,
    RunRecord,
)
from api.ports import ArtifactChanged, PlatformStore, StoreError
from core.contracts.telemetry import (
    DecisionKind,
    DecisionRow,
    IngestionRow,
    JudgeRow,
    LlmCallRow,
    RunSummary,
    StepRow,
    ValidationRow,
    summarize,
)
from core.domo.schemas import HumanFeedback
from core.domo.sinks import utc_now


def _samples_enabled() -> bool:
    """Whether the shipped fixture gates should be served. Off by default."""
    return os.environ.get("PLATFORM_SAMPLES", "").strip().lower() in ("1", "true", "yes")


#: A trailing ``_v<n>`` on an artifact stem, as the volume layout writes it.
_VERSIONED = re.compile(r"^.+_v(\d+)$")


def _version_of(stem: str) -> int:
    """``plan_8099_v3`` -> 3. An unversioned name is version 1, not version 0:
    the dry run writes no version and its output is still the first one."""
    m = _VERSIONED.match(stem)
    return int(m.group(1)) if m else 1

#: telemetry kind -> the model it deserializes to. One map so a new row type is one
#: line here rather than a new method on every layer.
ROW_TYPES = {
    "steps": StepRow,
    "llm_calls": LlmCallRow,
    "ingestions": IngestionRow,
    "judges": JudgeRow,
    "validations": ValidationRow,
    "decisions": DecisionRow,
}


class LocalStore(PlatformStore):
    """Files on disk, behind the same port the Delta adapter implements."""

    name = "local"

    def __init__(self, root: pathlib.Path | str = ".", *,
                 samples: pathlib.Path | str = "",
                 dryrun: pathlib.Path | str = "",
                 work: pathlib.Path | str = "",
                 volume: pathlib.Path | str = "") -> None:
        self.root = pathlib.Path(root).resolve()
        # A directory laid out like the UC volume: <volume>/<dataflow_id>/{md,sql,
        # discovery,gates,...}. Same shape DeltaStore reads on Databricks, so the
        # dry run exercises the real paths rather than a local-only arrangement.
        self.volume = pathlib.Path(volume or self.root / "ex_volume")
        # Sample gates are OFF unless asked for. They are fixtures for wiring the
        # UI, and once a real run exists they appear beside it as extra dataflows
        # and extra open gates nobody ran - indistinguishable, on screen, from work
        # the platform actually did. Pass a path, or set PLATFORM_SAMPLES=1.
        self.samples = pathlib.Path(samples) if samples else pathlib.Path(
            self.root / "docs" / "frontend" / "samples" if _samples_enabled()
            else self.root / "__no_samples__")
        self.dryrun = pathlib.Path(dryrun or self.root / "dryrun_out")
        self.work = pathlib.Path(work or self.root / ".platform_local")
        (self.work / "telemetry").mkdir(parents=True, exist_ok=True)
        (self.work / "feedback").mkdir(parents=True, exist_ok=True)

    # -- reading files ----------------------------------------------------- #
    def _json(self, path: pathlib.Path) -> Any:
        try:
            return json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise StoreError(f"{path}: {exc}") from exc

    def _rows(self, run_id: str, kind: str) -> list:
        """One telemetry file, validated. A bad line names itself rather than vanishing."""
        model = ROW_TYPES[kind]
        path = self._telemetry_file(run_id, kind)
        if path is None:
            return []
        if path.suffix == ".json":
            data = self._json(path)
            if not isinstance(data, list):
                raise StoreError(f"{path} should hold a list of rows, "
                                 f"got {type(data).__name__}")
            out = []
            for i, row in enumerate(data):
                try:
                    out.append(model.model_validate(row))
                except ValueError as exc:
                    raise StoreError(
                        f"{path}[{i}] is not a valid {model.__name__}: {exc}") from exc
            return out
        out = []
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                out.append(model.model_validate_json(line))
            except ValueError as exc:
                raise StoreError(
                    f"{path}:{n} is not a valid {model.__name__}: {exc}") from exc
        return out

    def _telemetry_file(self, run_id: str, kind: str) -> pathlib.Path | None:
        """Where this run's observability rows are, JSON on the volume first.

        The volume is the mock counterpart of the audit tables, so a run's rows sit
        beside the artifacts they describe. The work dir is kept as a fallback so a
        run written before the layout changed is still readable rather than
        silently reporting zero steps.
        """
        for candidate in (self._run_dir(run_id) / "telemetry" / f"{kind}.json"
                          if self._run_dir(run_id) else None,
                          self.work / "telemetry" / run_id / f"{kind}.json",
                          self.work / "telemetry" / run_id / f"{kind}.jsonl"):
            if candidate is not None and candidate.exists():
                return candidate
        return None

    def _run_dir(self, run_id: str) -> pathlib.Path | None:
        """The run's own folder, from the registry or by looking for it."""
        for record in self._registry_rows():
            if record.get("run_id") == run_id and record.get("run_dir"):
                return pathlib.Path(record["run_dir"])
        found = sorted(self.volume.glob(f"*/{run_id}")) if self.volume.exists() else []
        return found[0] if found else None

    def _registry_rows(self) -> list[dict]:
        path = self.volume / "runs.json"
        if not path.exists():
            return []
        data = self._json(path)
        return data if isinstance(data, list) else []

    def _gate_files(self) -> list[pathlib.Path]:
        """Gate payloads from a real local run first, then the shipped samples.

        A run writes its gates inside its own folder on the volume, so two runs of
        one dataflow no longer overwrite each other. Volume gates come before the
        shipped samples: a gate an actual run produced must never be masked by a
        fixture of the same name - the sample is a fixture, the run is evidence.
        """
        files: list[pathlib.Path] = []
        if self.volume.exists():
            # <volume>/<dataflow>/<run>/gates/*.json. Sorted, so when two runs of
            # one dataflow both produced a gate the newer run is last and wins the
            # de-duplication in _all_gates.
            files.extend(sorted(self.volume.glob("*/*/gates/*.json")))
        if (self.work / "gates").exists():                   # older flat layout
            files.extend(sorted((self.work / "gates").glob("*.json")))
        if self.samples.exists():
            files.extend(sorted(self.samples.glob("gate_*.json")))
        return files

    def _local_run_ids(self) -> set[str]:
        """Runs this machine actually produced — the ones with telemetry on disk."""
        root = self.work / "telemetry"
        return {d.name for d in root.glob("*") if d.is_dir()} if root.exists() else set()

    # -- catalogue --------------------------------------------------------- #
    def dataflows(self) -> list[DataflowCard]:
        """One card per dataflow any gate or dry-run output mentions.

        Coverage comes from the gate's own artifact summary where there is one, and
        from ``_<id>_facts.json`` otherwise. It is never recomputed here: the UI must
        not show a coverage number the artifact it links to could contradict.
        """
        cards: dict[str, DataflowCard] = {}

        for g in self._all_gates():
            did = g.dataflow_id
            if not did:
                continue
            card = cards.get(did) or DataflowCard(dataflow_id=did)
            card.dataflow_name = card.dataflow_name or g.dataflow_name
            card.latest_run_id = card.latest_run_id or g.run_id
            if g.artifact and g.artifact.summary:
                s = g.artifact.summary
                card.sources, card.steps, card.targets = s.sources, s.steps, s.targets
                card.deterministic, card.by_model = s.deterministic, s.by_model
                card.unresolved, card.coverage_pct = s.unresolved, s.coverage_pct
            if g.status == "interrupted" and not g.resolved:
                card.status = CARD_AWAITING_REVIEW
            cards[did] = card

        facts_files = sorted(self.samples.glob("_*_facts.json")) if self.samples.exists() else []
        for f in facts_files:
            d = self._json(f)
            did = str(d.get("dataflow_id") or "")
            if not did:
                continue
            card = cards.get(did) or DataflowCard(dataflow_id=did)
            card.dataflow_name = card.dataflow_name or d.get("dataflow_name", "")
            card.short_name = card.short_name or d.get("short_name", "")
            card.tiles = card.tiles or d.get("tiles", 0)
            for key in ("sources", "steps", "targets", "deterministic", "by_model",
                        "unresolved", "coverage_pct"):
                if not getattr(card, key):
                    setattr(card, key, d.get(key, 0) or 0)
            cards[did] = card

        if self.dryrun.exists():
            for d in sorted(self.dryrun.glob("*")):
                if d.is_dir() and d.name not in cards:
                    cards[d.name] = DataflowCard(dataflow_id=d.name, status="dry run only")

        # Tiles, from the graph the run actually produced.
        #
        # This used to come only from `_<id>_facts.json` - sample files that exist
        # for the bundled fixtures and for nothing else. So every dataflow the
        # platform had really processed advertised "0 tiles" on the card you pick
        # it from, which reads as "this export is empty" at the exact moment
        # somebody is deciding whether to migrate it.
        #
        # One tile is one node, so the graph is the definition rather than a proxy
        # for it. Falling back to sources+steps+targets keeps a number on the card
        # when no graph was written, and those three partition the same nodes.
        for did, card in cards.items():
            if card.tiles:
                continue
            try:
                card.tiles = len(self.graph(did))
            except StoreError:
                card.tiles = 0
            if not card.tiles:
                card.tiles = card.sources + card.steps + card.targets

        return [cards[k] for k in sorted(cards)]

    def run_records(self) -> list[RunRecord]:
        path = self.volume / "runs.json"
        if not path.exists():
            return []
        data = self._json(path)
        if not isinstance(data, list):
            raise StoreError(f"{path} should hold a list of run records, "
                             f"got {type(data).__name__}")
        out = []
        for i, row in enumerate(data):
            try:
                out.append(RunRecord.model_validate(row))
            except ValueError as exc:
                raise StoreError(f"{path}[{i}] is not a valid RunRecord: {exc}") from exc
        return sorted(out, key=lambda r: r.started_ts or r.run_id, reverse=True)

    def runs(self, dataflow_id: str = "") -> list[RunSummary]:
        out: list[RunSummary] = []
        # The registry is the list of runs; the numbers still come from telemetry.
        # Directory scanning stays as a fallback so a run whose registry write was
        # lost is still visible rather than disappearing from the dashboard.
        seen: set[str] = set()
        known = [r.run_id for r in self.run_records()]
        known += [d.name for d in sorted((self.work / "telemetry").glob("*"))
                  if d.is_dir() and d.name not in known]
        for run_id in known:
            if run_id in seen:
                continue
            seen.add(run_id)
            s = self.summary(run_id)
            if s and (not dataflow_id or s.dataflow_id == dataflow_id):
                out.append(s)
        # a gate can exist before anything has written telemetry for its run
        known = {s.run_id for s in out}
        for g in self._all_gates():
            if g.run_id and g.run_id not in known and (
                    not dataflow_id or g.dataflow_id == dataflow_id):
                out.append(summarize(g.run_id, g.dataflow_id,
                                     dataflow_name=g.dataflow_name,
                                     status="interrupted"))
                known.add(g.run_id)
        return sorted(out, key=lambda s: s.started_ts or s.run_id, reverse=True)

    def summary(self, run_id: str) -> RunSummary | None:
        steps = self._rows(run_id, "steps")
        llm = self._rows(run_id, "llm_calls")
        ingest = self._rows(run_id, "ingestions")
        judged = self._rows(run_id, "judges")
        validated = self._rows(run_id, "validations")
        decisions = self._rows(run_id, "decisions")
        gate = next((g for g in self._all_gates() if g.run_id == run_id), None)
        record = next((r for r in self.run_records() if r.run_id == run_id), None)
        if (not any([steps, llm, ingest, judged, validated, decisions])
                and gate is None and record is None):
            return None

        ordered = sorted(steps, key=lambda s: s.ts)
        open_gate = gate is not None and gate.status == "interrupted" and not gate.resolved
        if any(s.status.value == "interrupted" for s in steps) or open_gate:
            status = "interrupted"
        elif any(s.status.value == "failed" for s in steps):
            status = "failed"
        elif steps and all(s.status.value in ("ok", "skipped") for s in steps):
            status = "complete"
        else:
            status = "running"

        return summarize(
            run_id, (gate.dataflow_id if gate else "")
                    or (record.dataflow_id if record else ""),
            llm=llm, steps=steps, ingest=ingest, judged=judged,
            validated=validated, decisions=decisions,
            dataflow_name=(gate.dataflow_name if gate else "")
                          or (record.dataflow_name if record else ""),
            status=status,
            started_ts=(ordered[0].ts if ordered else "")
                       or (record.started_ts if record else ""),
            ended_ts=(ordered[-1].ts if ordered and status != "running" else "")
                     or (record.ended_ts if record else ""),
        )

    # -- telemetry --------------------------------------------------------- #
    def steps(self, run_id: str) -> list[StepRow]:
        return self._rows(run_id, "steps")

    def llm_calls(self, run_id: str) -> list[LlmCallRow]:
        return self._rows(run_id, "llm_calls")

    def ingestions(self, run_id: str) -> list[IngestionRow]:
        return self._rows(run_id, "ingestions")

    def judges(self, run_id: str) -> list[JudgeRow]:
        return self._rows(run_id, "judges")

    def validations(self, run_id: str) -> list[ValidationRow]:
        return self._rows(run_id, "validations")

    def decisions(self, run_id: str) -> list[DecisionRow]:
        return self._rows(run_id, "decisions")

    # -- review ------------------------------------------------------------ #
    def _all_gates(self) -> list[Gate]:
        from agents.master import AGENT_ORDER

        gates: list[Gate] = []
        samples: set[str] = set()                       # gate ids that only a shipped sample file provides
        for f in self._gate_files():
            payload = self._json(f)
            try:
                gate = Gate.model_validate(payload)
            except ValueError as exc:
                raise StoreError(f"{f} is not a valid gate payload: {exc}") from exc
            # Resolved either way a decision can arrive: a review submitted through
            # the API (which writes a feedback file), or a closing decision row from
            # a run that approved its own gate. DeltaStore uses the decision row
            # alone, so checking both keeps the two stores answering the same.
            closing = {(d.agent, d.iteration) for d in self.decisions(gate.run_id)
                       if d.kind.value in ("approved", "regenerated")}
            gate.resolved = ((self.work / "feedback" / f"{gate.gate_id}.json").exists()
                             or (gate.agent, gate.iteration) in closing)
            appr = self.work / "feedback" / f"{gate.gate_id}.approval.json"
            if appr.exists():
                try:
                    rec = json.loads(appr.read_text(encoding="utf-8"))
                    gate.approved = bool(rec.get("approve"))
                    gate.reviewer = rec.get("reviewer") or None
                    did = str(rec.get("decision_id") or "")
                    gate.decided_at = did.split("@", 1)[1] if "@" in did else None
                except (OSError, ValueError):
                    gate.approved = False
                gate.decision = "approved" if gate.approved else "changes_requested"
            elif (gate.agent, gate.iteration) in closing:
                gate.approved, gate.decision = True, "approved"
            if self.samples.exists() and f.parent == self.samples:
                samples.add(gate.gate_id)
            gates.append(gate)
        # De-duplicate on gate_id, not filename: a run writes
        # `gate-md_plan-8099-i1.json` while the shipped sample of the same gate is
        # `gate_md_plan.json`, and loading both would show one gate twice - once
        # resolved and once not. Work-dir files come first, so the run wins.
        unique: dict[str, Gate] = {}
        for g in gates:
            # Last one wins: the file list is oldest-first, so a later run's gate
            # supersedes an earlier run's for the same id.
            unique[g.gate_id] = g
        gates = list(unique.values())
        # A real local run supersedes the shipped samples for the dataflow it ran.
        # Otherwise the sample gates sit alongside the run's own, and the UI shows
        # one agent twice at two iterations - the run's, and a fixture pretending to
        # be a later one. Dataflows the run did not touch keep their samples.
        # Only SAMPLE gates are superseded: a pack run (Snowflake) writes no telemetry until a review is decided, so a
        # re-run of an already-reviewed ETL must keep its new gates open (they were hidden, blocking the resume).
        ran = {g.dataflow_id for g in gates if g.run_id in self._local_run_ids()}
        if ran:
            gates = [g for g in gates
                     if g.dataflow_id not in ran or g.gate_id not in samples or g.run_id in self._local_run_ids()]
        order = {a: i for i, a in enumerate(AGENT_ORDER)}
        return sorted(gates,
                      key=lambda g: (g.dataflow_id, order.get(g.agent, 99), g.iteration))

    def gates(self, *, run_id: str = "", dataflow_id: str = "",
              open_only: bool = False) -> list[Gate]:
        out = self._all_gates()
        if run_id:
            out = [g for g in out if g.run_id == run_id]
        if dataflow_id:
            out = [g for g in out if g.dataflow_id == dataflow_id]
        if open_only:
            out = [g for g in out if g.status == "interrupted" and not g.resolved]
        return out

    def gate(self, gate_id: str) -> Gate | None:
        return next((g for g in self._all_gates() if g.gate_id == gate_id), None)

    def submit_feedback(self, gate_id: str,
                        submission: FeedbackSubmission) -> FeedbackReceipt:
        gate = self.gate(gate_id)
        if gate is None:
            raise StoreError(f"no gate {gate_id!r}")
        artifacts = reviewed_artifacts(gate)
        if submission.approve:
            refuse_changed_artifacts(self.volume, artifacts)
        receipt = build_receipt(gate, submission)
        (self.work / "feedback").mkdir(parents=True, exist_ok=True)
        (self.work / "feedback" / f"{gate_id}.json").write_text(
            receipt.model_dump_json(indent=1), encoding="utf-8")
        # What resume reuses (ADR 032 section 3): (artifact_ref, sha256, reviewer) and the
        # payload hash the decision was given for - never the SQL text.
        # hand-written code goes to the restricted volume by hash (never into the record): unit id -> artifact ref
        edits = {}
        if submission.edits:
            from agents.cd_codegen.translate.artifacts import write_artifact

            for unit_id, text in sorted(submission.edits.items()):
                stored = write_artifact(self.volume, gate.dataflow_id, str(text).strip(), kind="manual")
                edits[unit_id] = {"artifact_ref": stored.artifact_ref, "sha256": stored.sha256}
        out_of_scope = {u: submission.out_of_scope_reasons.get(u, "") for u in submission.out_of_scope_unit_ids}
        (self.work / "feedback" / f"{gate_id}.approval.json").write_text(json.dumps({
            "gate_id": gate_id, "approve": bool(submission.approve), "reviewer": submission.actor,
            "payload_hash": getattr(gate, "payload_hash", "") or "",
            "decision_id": f"{gate_id}@{receipt.decision_rows[-1].ts if receipt.decision_rows else ''}",
            "artifacts": artifacts, "edits": edits, "out_of_scope": out_of_scope}, indent=1), encoding="utf-8")
        run_dir = self.work / "telemetry" / (gate.run_id or "unknown-run")
        run_dir.mkdir(parents=True, exist_ok=True)
        with (run_dir / "decisions.jsonl").open("a", encoding="utf-8") as fh:
            for row in receipt.decision_rows:
                fh.write(row.model_dump_json() + "\n")
        return receipt

    # -- artifacts ---------------------------------------------------------- #
    def artifacts(self, dataflow_id: str) -> list[ArtifactRef]:
        out: list[ArtifactRef] = []
        for g in self.gates(dataflow_id=dataflow_id):
            if g.artifact:
                out.append(g.artifact)
        # A local end-to-end run writes under <work>/artifacts/<id>/{md,sql,layers};
        # scripts/local_dryrun.py writes flat under dryrun_out/<id>. Both are real
        # output of this machine, so both are listed.
        by_flow = self.volume / dataflow_id
        # One folder per run, newest last, then the older flat layouts.
        roots: list[pathlib.Path] = []
        if by_flow.is_dir():
            roots.extend(sorted(d for d in by_flow.glob("run-*") if d.is_dir()))
        roots.append(self.work / "artifacts" / dataflow_id)
        roots.append(self.dryrun / dataflow_id)
        for root in roots:
            if not root.is_dir():
                continue
            for f in sorted(root.rglob("*")):
                if not f.is_file():
                    continue
                if f.suffix == ".md":
                    out.append(ArtifactRef(kind="plan", version=_version_of(f.stem),
                                           path=str(f)))
                elif f.name.startswith("etl_"):
                    out.append(ArtifactRef(kind="sql", version=_version_of(f.stem),
                                           path=str(f),
                                           target=f.stem.split("__", 1)[-1]))
                elif f.name.startswith("debug_"):
                    out.append(ArtifactRef(kind="debug", version=_version_of(f.stem),
                                           path=str(f),
                                           target=f.stem.split("__", 1)[-1]))
                elif f.parent.name == "layers":
                    out.append(ArtifactRef(kind="layer", version=1, path=str(f),
                                           target=f.stem.split("_", 1)[0]))
                elif f.parent.name in ("discovery", "standardized", "raw", "telemetry"):
                    # Everything else the run put on the volume. A reviewer asked to
                    # trust the SQL should be able to open what it was derived from.
                    out.append(ArtifactRef(kind=f.parent.name, version=1, path=str(f),
                                           target=f.stem))
        seen: set[str] = set()
        unique: list[ArtifactRef] = []
        for a in out:                       # gate refs come first and carry the summary
            if a.path not in seen:
                seen.add(a.path)
                unique.append(a)
        return unique

    def graph(self, dataflow_id: str) -> list[dict]:
        by_flow = self.volume / dataflow_id
        runs = (sorted(by_flow.glob(f"run-*/graph_{dataflow_id}.json"))
                if by_flow.is_dir() else [])
        # Newest run first: the graph shown should be the one most recently produced.
        candidates = list(reversed(runs))
        candidates.append(self.work / "artifacts" / dataflow_id
                          / f"graph_{dataflow_id}.json")
        path = next((c for c in candidates if c.exists()), None)
        if path is None:
            return []
        data = self._json(path)
        if not isinstance(data, list):
            raise StoreError(f"{path} should hold a list of nodes, got {type(data).__name__}")
        return data

    def artifact_content(self, path: str) -> str:
        """Read one artifact, refusing anything outside the roots this store owns.

        The path arrives from the client, so it is untrusted: without this check the
        route is an arbitrary-file-read endpoint. The volume paths in the sample gates
        do not exist on a laptop, so a path that is not present resolves by basename
        into ``dryrun_out`` first.
        """
        p = pathlib.Path(path)
        if not p.exists() and p.name:
            # A gate names a versioned artifact (plan_8099_v1.md); the dry run writes
            # the unversioned name (plan_8099.md), having no iteration to speak of. Try
            # the exact name first so a real version is never silently served as another.
            stem, suffix = p.stem, p.suffix
            unversioned = stem.rsplit("_v", 1)[0] if _VERSIONED.match(stem) else stem
            search = [r for r in (self.volume, self.work / "artifacts", self.dryrun)
                      if r.exists()]
            match = None
            for candidate in (p.name, unversioned + suffix):
                for root in search:
                    match = next(iter(sorted(root.rglob(candidate))), None)
                    if match is not None:
                        break
                if match is not None:
                    break
            if match is None:
                raise StoreError(
                    f"no artifact at {path!r}, and nothing named {p.name!r} under "
                    f"{self.work / 'artifacts'} or {self.dryrun}. On this store "
                    f"artifacts come from a local run.")
            p = match
        resolved = p.resolve()
        roots = [r.resolve() for r in (self.volume, self.dryrun, self.samples, self.work)
                 if r.exists()]
        if not any(resolved.is_relative_to(r) for r in roots):
            raise StoreError(f"{path!r} is outside the artifact roots this store serves")
        try:
            return resolved.read_text(encoding="utf-8")
        except OSError as exc:
            raise StoreError(f"{resolved}: {exc}") from exc


def build_receipt(gate: Gate, sub: FeedbackSubmission) -> FeedbackReceipt:
    """Turn one submission into the feedback record and its audit rows.

    Pure, and shared by both stores, because the audit trail must not depend on where
    it is being written. One row per decision — never one batched row for the lot, as
    a batch cannot say which issue carried which rationale.

    The closing row is ``approved`` or ``regenerated``: whether the artifact stands or
    goes back is itself a decision, and the deviation report is unreadable without it.
    """
    ts = utc_now()
    feedback = HumanFeedback(
        accepted_issue_ids=list(sub.accepted_issue_ids),
        rejected_issue_ids=list(sub.rejected_issue_ids),
        freeform=sub.freeform,
        hard_constraints=list(sub.hard_constraints),
        ts=ts, actor=sub.actor)

    ref_of = {i.id: i.ref for i in (gate.eval.issues if gate.eval else ())}
    common = dict(run_id=gate.run_id, ts=ts, dataflow_id=gate.dataflow_id,
                  agent=gate.agent, iteration=gate.iteration, actor=sub.actor)

    rows = [DecisionRow(**common, kind=DecisionKind.ISSUE_ACCEPTED, issue_id=i,
                        node=ref_of.get(i, ""), rationale=sub.rationales.get(i, ""))
            for i in sub.accepted_issue_ids]
    rows += [DecisionRow(**common, kind=DecisionKind.ISSUE_REJECTED, issue_id=i,
                         node=ref_of.get(i, ""), rationale=sub.rationales.get(i, ""))
             for i in sub.rejected_issue_ids]
    rows += [DecisionRow(**common, kind=DecisionKind.CONSTRAINT_ADDED, constraint=c,
                         rationale=sub.constraint_rationales.get(c, ""))
             for c in sub.hard_constraints]

    # Hand edits. One row per edited block, and the rationale carries the text the
    # reviewer typed - an override that recorded only "someone edited this" would
    # be unreviewable, which defeats the point of recording it.
    for ov in sub.overrides:
        node = str(ov.get("node") or "")
        kind = str(ov.get("kind") or "artifact")
        text = str(ov.get("text") or "")
        rows.append(DecisionRow(
            **common, kind=DecisionKind.OVERRIDE, node=node,
            rationale=f"{kind} edited by hand at {node or 'the artifact'}: {text}"))

    # Translation reviews: code written by hand for a unit nothing translated, and units marked out of scope.
    for unit_id, text in sorted(sub.edits.items()):
        rows.append(DecisionRow(
            **common, kind=DecisionKind.OVERRIDE, node=unit_id,
            rationale=f"code written by hand for unit {unit_id} ({len(str(text).splitlines())} line(s)); "
                      "stored by hash, origin manual"))
    for unit_id in sub.out_of_scope_unit_ids:
        rows.append(DecisionRow(
            **common, kind=DecisionKind.OVERRIDE, node=unit_id,
            rationale=f"unit {unit_id} marked out of scope: "
                      f"{sub.out_of_scope_reasons.get(unit_id) or 'no reason given'}"))

    # Layer moves. The classifier proposes; a person decides, because a table that
    # is gold for one workflow is bronze for another and no single dataflow
    # settles it. Which way it moved is the fact worth keeping.
    for mv in sub.layer_moves:
        node = str(mv.get("node") or "")
        rows.append(DecisionRow(
            **common, kind=DecisionKind.OVERRIDE, node=node,
            rationale=f"layer changed from {mv.get('from') or '?'} to "
                      f"{mv.get('to') or '?'}"))
    for node, name in sorted(sub.layer_names.items()):
        rows.append(DecisionRow(
            **common, kind=DecisionKind.OVERRIDE, node=node,
            rationale=f"materialized table named {name!r} by the reviewer"))

    closing = DecisionKind.APPROVED if sub.approve else DecisionKind.REGENERATED
    rows.append(DecisionRow(
        **common, kind=closing,
        rationale=sub.freeform or f"{len(sub.accepted_issue_ids)} issues accepted"))

    return FeedbackReceipt(
        gate_id=gate.gate_id, human_feedback=feedback, decision_rows=rows,
        binds_generated_code=False,
        note="Decisions recorded. Per architecture gap #1 the accepted issues do not "
             "yet alter the generated SQL - HumanFeedback reaches only the AI "
             "translation path, which a fully deterministic dataflow never runs."
             + (f" {len(sub.overrides)} hand edit(s) are recorded with their text and "
                f"are likewise not written back to the artifact."
                if sub.overrides else ""))


def reviewed_artifacts(gate: Gate) -> list[dict]:
    """``[{artifact_ref, sha256}]`` the gate put under review (sql gates since ADR 032)."""
    targets = list((gate.artifact.targets if gate.artifact else None) or [])
    targets += list(((gate.artifact.model_extra or {}).get("artifacts") if gate.artifact else None) or [])  # packs
    return [{"artifact_ref": t["artifact_ref"], "sha256": t["sha256"]}
            for t in targets if t.get("artifact_ref") and t.get("sha256")]


def refuse_changed_artifacts(volume: pathlib.Path, artifacts: list[dict]) -> None:
    """Approval of an artifact whose current hash differs from the reviewed one is refused."""
    from agents.cd_codegen.translate.artifacts import ArtifactError, verify

    for a in artifacts:
        try:
            verify(volume, a["artifact_ref"], a["sha256"])
        except (ArtifactError, FileNotFoundError) as exc:
            raise ArtifactChanged(f"refusing to approve: {exc}") from exc


__all__ = ["LocalStore", "ROW_TYPES", "build_receipt", "refuse_changed_artifacts", "reviewed_artifacts"]
