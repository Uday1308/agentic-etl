"""api.serving — what changes when this runs as a Databricks App rather than locally.

Three things, and each of them is a correctness issue rather than packaging:

**One process, one port.** A Databricks App exposes a single HTTP port. In dev the
React app is its own vite server and `/api` is proxied to uvicorn; deployed, there is
no vite, so FastAPI has to serve the built bundle itself — including the SPA fallback,
or every deep link 404s on refresh.

**The reviewer is not whoever the browser says they are.** ``HumanFeedback.actor`` and
every ``DecisionRow`` carry a person's name into the client deviation report. Locally
the client supplies it, which is fine for one developer and indefensible for a shared
deployment: anyone could file a decision under a colleague's name, in the one artifact
whose whole purpose is being defensible eight months later. Behind the App's OAuth
proxy the identity arrives in a header, and that is what gets recorded.

**Local disk is not storage.** ``LocalStore`` writes reviews to files. An App instance
has an ephemeral filesystem and may be replaced or scaled at any time, so those files
are a review trail that silently disappears. Deployed, the store must be Delta.
"""
from __future__ import annotations

import os
import pathlib

#: Headers the App's OAuth proxy sets, in the order we trust them. Configurable
#: because the exact header differs between deployment fronts, and getting it wrong
#: should be a config change rather than a code change.
IDENTITY_HEADERS = tuple(
    h.strip() for h in os.environ.get(
        "PLATFORM_IDENTITY_HEADERS",
        "X-Forwarded-Email,X-Forwarded-Preferred-Username,X-Forwarded-User",
    ).split(",") if h.strip()
)

#: Set by the Databricks Apps runtime. Presence of a port is how this process knows
#: it is deployed rather than running on someone's laptop.
APP_PORT_VARS = ("DATABRICKS_APP_PORT", "APP_PORT")


def is_databricks_app() -> bool:
    """True when running inside the Databricks Apps runtime.

    Used to refuse a configuration that is merely wrong rather than fatal — a local
    file store on an ephemeral disk — instead of discovering it when a reviewer's
    decisions vanish.
    """
    return any(os.environ.get(v) for v in APP_PORT_VARS)


def reviewer_from_headers(headers) -> str:
    """Who is submitting this review, according to the proxy in front of us.

    Empty when no identity header is present, which is the local case. The caller
    decides what to do about that — this function never invents a name, because a
    decision row attributed to a guess is worse than one attributed to nobody.
    """
    for name in IDENTITY_HEADERS:
        value = headers.get(name)
        if value and value.strip():
            return value.strip()
    return ""


def spa_directory() -> pathlib.Path | None:
    """The built frontend, if it has been built.

    ``PLATFORM_SPA_DIR`` overrides; otherwise ``lv-tower/dist`` next to the repo.
    Returns None when there is no bundle, so a dev run (vite on its own port) is
    unaffected and a deploy that forgot ``npm run build`` fails loudly at startup
    rather than serving a blank page.
    """
    override = os.environ.get("PLATFORM_SPA_DIR", "")
    root = pathlib.Path(override) if override else (
        pathlib.Path(__file__).resolve().parents[1] / "lv-tower" / "dist")
    return root if (root / "index.html").exists() else None


def mount_spa(app) -> pathlib.Path | None:
    """Serve the built React app from this same FastAPI process.

    Mounted last and only under paths that are not ``/api``, so a route added later
    always wins over a static file. The catch-all returns ``index.html`` for anything
    that is not a real file, which is what makes a client-routed deep link survive a
    browser refresh.
    """
    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    dist = spa_directory()
    if dist is None:
        # No bundle. Without this the root URL is a bare {"detail":"Not Found"},
        # which says nothing about the cause - and the cause is almost always
        # "nobody ran npm run build", or "this process started before the build
        # finished". Both are one sentence to explain and maddening to guess at.
        expected = os.environ.get("PLATFORM_SPA_DIR", "") or str(
            pathlib.Path(__file__).resolve().parents[1] / "lv-tower" / "dist")

        @app.get("/", include_in_schema=False)
        @app.get("/{full_path:path}", include_in_schema=False)
        async def _no_spa(full_path: str = ""):
            from fastapi import HTTPException
            from fastapi.responses import PlainTextResponse

            if full_path.startswith("api/"):
                raise HTTPException(status_code=404, detail=f"no route /{full_path}")
            return PlainTextResponse(
                "The API is running; the frontend bundle is not here.\n\n"
                f"Looked in: {expected}\n\n"
                "Build it on a machine with Node and copy the folder across:\n"
                "    cd lv-tower && npm ci && npm run build\n\n"
                "Then restart this process - the bundle is located once at\n"
                "startup.\n\n"
                "The API itself is fine: try /api/health or /api/serving.\n",
                status_code=503)
        return None

    app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str):
        # /api is handled by the routes registered before this one; anything still
        # reaching here under /api is a genuine 404 and must not be answered with
        # the HTML shell, or a broken fetch looks like a successful page load.
        if full_path.startswith("api/"):
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=f"no route /{full_path}")
        candidate = dist / full_path
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(dist / "index.html")

    return dist


__all__ = ["IDENTITY_HEADERS", "is_databricks_app", "mount_spa", "reviewer_from_headers",
           "spa_directory"]
