"""api.review_routes - review groups, group accept, suggestions and the decision ledger hook (S11, ADR 037).

``install(app, get_store, submit_feedback)`` adds the routes; ``after_feedback`` is called by ``submit_feedback``
after a decision is stored. Group accept NEVER bypasses the per-gate path: it recomputes the groups from the open
gates, refuses
any gate the policy does not allow, and then calls the same ``submit_feedback`` once per gate (own decision rows,
artifact-hash check, authenticated reviewer).
"""
from __future__ import annotations

from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.models import FeedbackSubmission
from api.ports import ArtifactChanged, PlatformStore
from core import decision_ledger as dl
from core import review_policy as rp


class GroupAccept(BaseModel):
    family: str
    gate_ids: list[str] = Field(min_length=1)
    actor: str = ""
    note: str = ""


def _open_gates(store: PlatformStore) -> list[dict]:
    out = []
    for g in store.gates(open_only=True):
        d = g.model_dump()
        if not d.get("resolved"):
            out.append(d)
    return out


def after_feedback(store: PlatformStore, gate: Any, submission: FeedbackSubmission, receipt: Any) -> None:
    """Write the ledger rows of one stored decision. Never raises: the decision is already recorded."""
    try:
        ledger = dl.for_store(store)
        rows = getattr(receipt, "decision_rows", None) or []
        ts = str(rows[-1].ts) if rows else ""
        scope = {u: submission.out_of_scope_reasons.get(u, "") for u in submission.out_of_scope_unit_ids}
        dl.record_feedback(ledger, gate.model_dump(), approve=bool(submission.approve), reviewer=submission.actor,
                           decision_id=f"{gate.gate_id}@{ts}", edits=frozenset(submission.edits),
                           out_of_scope=scope, rationale=submission.freeform, ts=ts)
    except Exception:  # noqa: BLE001 - audit extras must not undo a stored decision
        return


def install(app: FastAPI, get_store: Any, submit_feedback: Any) -> None:
    @app.get("/api/review/groups", tags=["review"])
    def review_groups(store: PlatformStore = Depends(get_store)) -> dict:
        pol = rp.policy()
        return {"groups": rp.build_groups(_open_gates(store), pol),
                "policy": {"group_accept": pol.group_enabled, "carry_over": pol.carry_enabled,
                           "suggestions": pol.suggest_enabled}}

    @app.post("/api/review/groups/accept", tags=["review"])
    def accept_group(body: GroupAccept, request: Request, store: PlatformStore = Depends(get_store)) -> dict:
        groups = {g["family"]: g for g in rp.build_groups(_open_gates(store))}
        group = groups.get(body.family)
        if group is None:
            raise HTTPException(status_code=404, detail=f"no open review group {body.family!r}")
        allowed = {g["gate_id"] for g in group["acceptable"]}
        accepted: list[str] = []
        refused: list[dict] = []
        for gid in dict.fromkeys(body.gate_ids):
            if gid not in allowed:
                why = next((g.get("why") for g in group["individual"] if g["gate_id"] == gid),
                           "not an open gate of this group")
                refused.append({"gate_id": gid, "reason": why})
                continue
            sub = FeedbackSubmission(approve=True, actor=body.actor,
                                     freeform=f"Group accept ({body.family}): {body.note}".strip().rstrip(":"))
            try:
                submit_feedback(gid, sub, request, store)
                accepted.append(gid)
            except ArtifactChanged as exc:
                refused.append({"gate_id": gid, "reason": str(exc)})
            except HTTPException as exc:
                refused.append({"gate_id": gid, "reason": str(exc.detail)})
        return {"family": body.family, "accepted": accepted, "refused": refused}

    @app.get("/api/review/suggestions", tags=["review"])
    def suggestions(gate_id: str = Query(...), store: PlatformStore = Depends(get_store)) -> dict:
        """Similar past decisions per unit of a gate. Suggest only: nothing here is applied."""
        found = store.gate(gate_id)
        if found is None:
            raise HTTPException(status_code=404, detail=f"gate {gate_id} not found")
        ledger = dl.for_store(store)
        out: dict[str, list[dict]] = {}
        if ledger is None:
            return {"units": out}
        d = found.model_dump()
        art = d.get("artifact") or {}
        for u in art.get("units") or []:
            out[str(u.get("unit_id"))] = ledger.suggest(str(u.get("fingerprint") or ""),
                                                        sorted(u.get("review_caveats") or []))
        if not art.get("units"):
            item = rp.gate_items(d)
            out[gate_id] = ledger.suggest("", item.caveats)
        return {"units": out}


__all__ = ["after_feedback", "install"]
