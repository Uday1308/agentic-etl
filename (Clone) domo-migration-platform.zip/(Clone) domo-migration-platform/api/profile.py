"""api.profile — which source and target platform this deployment migrates between.

The migrator is any-to-any and migrates ETL *logic* only; moving the data is a
separate accelerator's job. DOMO -> Databricks is the first implemented pair and the
default, but nothing user-facing should hard-code it, so the UI reads its wording from
here (``GET /api/meta`` -> ``profile``) instead.

Chosen by env vars, once per process::

    MIGRATION_SOURCE=domo        # default
    MIGRATION_TARGET=databricks  # default

An id that is not in the tables below is still served — labelled with the id itself
and flagged ``ready=False`` — rather than refused, so a misconfigured deployment says
what it was asked for instead of silently claiming to be the default pair.
"""
from __future__ import annotations

import os

from api.models import PlatformProfile, SourceProfile, TargetProfile

PRODUCT = "LatentView Migration Platform"
TAGLINE = "Any-to-any ETL logic migration"
SCOPE = "ETL logic only. Data movement is handled by a separate accelerator."

DEFAULT_SOURCE = "domo"
DEFAULT_TARGET = "databricks"

#: Source platforms. ``ready`` means an adapter is implemented end to end.
SOURCES: dict[str, dict] = {
    "domo": {"label": "DOMO", "unit": "dataflow", "units": "dataflows",
             "step": "tile", "steps": "tiles", "ready": True},
    # ADR 032: the Snowflake pack (packs/snowflake) is Phase 3 work; wording is fixed now
    "snowflake": {"label": "Snowflake", "unit": "object", "units": "objects",
                  "step": "statement", "steps": "statements", "ready": True},
    "informatica": {"label": "Informatica", "unit": "mapping", "units": "mappings",
                    "step": "transformation", "steps": "transformations", "ready": False},
    "ssis": {"label": "SSIS", "unit": "package", "units": "packages",
             "step": "task", "steps": "tasks", "ready": False},
    "alteryx": {"label": "Alteryx", "unit": "workflow", "units": "workflows",
                "step": "tool", "steps": "tools", "ready": False},
    "talend": {"label": "Talend", "unit": "job", "units": "jobs",
               "step": "component", "steps": "components", "ready": False},
    "adf": {"label": "Azure Data Factory", "unit": "pipeline", "units": "pipelines",
            "step": "activity", "steps": "activities", "ready": False},
}

#: Target platforms. ``ready`` means code generation is implemented end to end.
TARGETS: dict[str, dict] = {
    "databricks": {"label": "Databricks", "dialects": ["SQL", "PySpark"],
                   "catalog_label": "Unity Catalog", "ready": True},
    "snowflake": {"label": "Snowflake", "dialects": ["SQL", "Snowpark"],
                  "catalog_label": "Snowflake catalog", "ready": False},
    "bigquery": {"label": "BigQuery", "dialects": ["SQL"],
                 "catalog_label": "BigQuery datasets", "ready": False},
    "fabric": {"label": "Microsoft Fabric", "dialects": ["SQL", "PySpark"],
               "catalog_label": "OneLake catalog", "ready": False},
}


def _source(source_id: str) -> SourceProfile:
    known = SOURCES.get(source_id)
    if known is None:
        return SourceProfile(id=source_id, label=source_id, unit="pipeline",
                             units="pipelines", step="step", steps="steps", ready=False)
    return SourceProfile(id=source_id, **known)


def _target(target_id: str) -> TargetProfile:
    known = TARGETS.get(target_id)
    if known is None:
        return TargetProfile(id=target_id, label=target_id, dialects=["SQL"],
                             catalog_label="catalog", ready=False)
    return TargetProfile(id=target_id, **known)


#: Set by the portal proxy from the selected Source (ADR 029 section 3); the browser cannot set it.
SOURCE_PLATFORM_HEADER = "X-Srcintel-Source-Platform"


def profile_for(platform: str | None = None, target: str | None = None) -> PlatformProfile:
    """The profile for one request (ADR 032 section 1): the forwarded source platform, else
    the standalone-demo default ``MIGRATION_SOURCE``, else DOMO. A platform with a
    registered pack takes its wording from the pack, so the two cannot drift."""
    source_id = (platform or os.environ.get("MIGRATION_SOURCE") or DEFAULT_SOURCE).strip().lower()
    target_id = (target or os.environ.get("MIGRATION_TARGET") or DEFAULT_TARGET).strip().lower()
    source = _source(source_id)
    try:
        from core.packs import get_pack, known_platforms

        if source_id in known_platforms():
            source = SourceProfile(id=source_id, **get_pack(source_id).profile.as_dict())
    except Exception:  # noqa: BLE001 - wording must never take /api/meta down
        pass
    return PlatformProfile(product=PRODUCT, tagline=TAGLINE, scope=SCOPE,
                           source=source, target=_target(target_id))


def profile_from_headers(headers) -> PlatformProfile:
    return profile_for((headers.get(SOURCE_PLATFORM_HEADER) or "").strip() or None)


def current_profile() -> PlatformProfile:
    """The process default (``MIGRATION_SOURCE`` / ``MIGRATION_TARGET``); kept for callers
    with no request. Request handlers use ``profile_from_headers``."""
    return profile_for()
