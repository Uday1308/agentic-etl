"""api.deploy_routes - deploy plan, approval bound to the plan digest, run, results, rollback (S13, ADR 037).

    GET  /api/batches/{id}/deploy            plan + approval + past runs
    POST /api/batches/{id}/deploy/approve    {digest}  admin; bound to the digest of the plan as it is NOW
    POST /api/batches/{id}/deploy/run        {digest}  runs only a plan whose digest was approved and is unchanged
    GET  /api/batches/{id}/deploy/rollback   the reviewed-never-run rollback script (latest run, else the plan's)

Files live under ``<volume>/batches/<key>/<id>/deploy/`` (removed with the batch). The workspace is reached only through
the ``Deployer`` port: ``get_deployer`` builds the Databricks one from the environment, tests override it with a fake.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import pathlib
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from api.cleanup import valid_id
from api.ports import PlatformStore
from api.serving import is_databricks_app, reviewer_from_headers
from core import deploy as dp

ROLES_HEADER = "X-Srcintel-User-Roles"


class DigestBody(BaseModel):
    digest: str
    actor: str = ""


def get_deployer() -> dp.Deployer | None:
    """The Databricks deployer when a SQL warehouse is configured, else None (the run route then answers 501)."""
    from packs.snowflake.warehouse import configured

    if not configured():
        return None
    from api.store_delta import connect_databricks

    api = None
    try:
        from core.lakebridge import workspace_api_from_env

        api = workspace_api_from_env()
    except Exception:  # noqa: BLE001 - SQL objects still deploy; notebooks and jobs report an unavailable API
        api = None
    return dp.DatabricksDeployer(connect_databricks()[0], api)


def _require_admin(request: Request) -> None:
    roles = {r.strip().lower() for r in (request.headers.get(ROLES_HEADER) or "").split(",") if r.strip()}
    if (roles or is_databricks_app()) and "admin" not in roles:
        raise HTTPException(status_code=403, detail="approving a deploy needs the admin role")


def _paths(store: PlatformStore) -> tuple[pathlib.Path, pathlib.Path]:
    volume, work = getattr(store, "volume", None), getattr(store, "work", None)
    if volume is None or work is None:
        raise HTTPException(status_code=501, detail=f"the {store.name} store does not support deploy yet")
    return pathlib.Path(volume), pathlib.Path(work)


def _report_path(volume: pathlib.Path, batch_id: str) -> pathlib.Path:
    if not valid_id(batch_id):
        raise HTTPException(status_code=404, detail="no such batch run")
    hits = sorted((volume / "batches").glob(f"*/{batch_id}.json")) if (volume / "batches").is_dir() else []
    if not hits:
        raise HTTPException(status_code=404, detail=f"no batch report {batch_id!r}")
    return hits[0]


def _plan(store: PlatformStore, batch_id: str) -> tuple[dict, pathlib.Path, Any]:
    volume, work = _paths(store)
    rp = _report_path(volume, batch_id)
    report = json.loads(rp.read_text(encoding="utf-8"))
    asm = dict(report.get("assembly") or {})
    gid = asm.get("gate_id") or "gate-batch_assembly"
    appr = work / "feedback" / f"{gid}.approval.json"
    if asm and asm.get("status") != "approved" and appr.exists():
        try:
            if json.loads(appr.read_text(encoding="utf-8")).get("approve"):
                report["assembly"] = {**asm, "status": "approved"}
        except ValueError:
            pass
    from agents.cd_codegen.translate.artifacts import read_artifact

    folder = rp.with_suffix("")
    plan = dp.build_plan(report, lambda ref: read_artifact(volume, ref), assembly_dir=folder / "assembly",
                         workspace_root=os.environ.get("DEPLOY_WORKSPACE_ROOT", "/Shared/migration"),
                         warehouse_id=os.environ.get("DATABRICKS_WAREHOUSE_ID", ""))
    return plan, folder / "deploy", lambda ref: read_artifact(volume, ref)


def _json(path: pathlib.Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _runs(ddir: pathlib.Path) -> list[dict]:
    out = []
    for p in sorted((ddir / "runs").glob("*.json"), reverse=True) if (ddir / "runs").is_dir() else []:
        d = _json(p)
        if isinstance(d, dict):
            out.append({k: d.get(k) for k in ("status", "plan_digest", "ts", "actor", "steps", "verified")})
    return out


def install(app: FastAPI, get_store: Any, deployer_dep: Any = None) -> None:
    dep = deployer_dep or get_deployer

    @app.get("/api/batches/{batch_id}/deploy", tags=["deploy"])
    def deploy_state(batch_id: str, store: PlatformStore = Depends(get_store)) -> dict:
        plan, ddir, _ = _plan(store, batch_id)
        approval = _json(ddir / "approvals" / f"{plan['digest']}.json")
        return {"plan": plan, "approval": approval, "runs": _runs(ddir)}

    @app.post("/api/batches/{batch_id}/deploy/approve", tags=["deploy"])
    def deploy_approve(batch_id: str, body: DigestBody, request: Request,
                       store: PlatformStore = Depends(get_store)) -> dict:
        _require_admin(request)
        plan, ddir, _ = _plan(store, batch_id)
        try:
            dp.approved(plan, body.digest)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        who = reviewer_from_headers(request.headers) or body.actor.strip()
        if not who:
            raise HTTPException(status_code=422, detail="actor is required")
        rec = {"digest": plan["digest"], "approver": who, "ts": dt.datetime.now(dt.UTC).isoformat(),
               "steps": len(plan["steps"])}
        (ddir / "approvals").mkdir(parents=True, exist_ok=True)
        (ddir / "approvals" / f"{plan['digest']}.json").write_text(json.dumps(rec, indent=1), encoding="utf-8")
        return rec

    @app.post("/api/batches/{batch_id}/deploy/run", tags=["deploy"])
    def deploy_run(batch_id: str, body: DigestBody, request: Request, store: PlatformStore = Depends(get_store),
                   deployer: dp.Deployer | None = Depends(dep)) -> dict:
        plan, ddir, read_text = _plan(store, batch_id)
        approval = _json(ddir / "approvals" / f"{body.digest}.json")
        if not approval or body.digest != plan["digest"]:
            raise HTTPException(status_code=409, detail="this plan digest is not approved, or the plan changed since "
                                                        "it was approved: review and approve the current plan")
        if deployer is None:
            raise HTTPException(status_code=501, detail="no SQL warehouse is configured for this deployment "
                                                        "(DATABRICKS_WAREHOUSE_ID); nothing was deployed")
        try:
            result = dp.execute_plan(plan, body.digest, deployer, read_text)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        who = reviewer_from_headers(request.headers) or body.actor.strip() or "unknown"
        result = {**result, "actor": who, "approved_by": approval.get("approver")}
        (ddir / "runs").mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now(dt.UTC).strftime("%Y%m%dT%H%M%S%f")
        (ddir / "runs" / f"{stamp}.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
        (ddir / "rollback.sql").write_text(result["rollback"], encoding="utf-8")
        return result

    @app.get("/api/batches/{batch_id}/deploy/rollback", tags=["deploy"], response_class=PlainTextResponse)
    def deploy_rollback(batch_id: str, store: PlatformStore = Depends(get_store)) -> PlainTextResponse:
        plan, ddir, _ = _plan(store, batch_id)
        saved = ddir / "rollback.sql"
        text = saved.read_text(encoding="utf-8") if saved.exists() else plan["rollback"]
        disposition = f'attachment; filename="rollback-{batch_id}.sql"'
        return PlainTextResponse(text, headers={"Content-Disposition": disposition})


__all__ = ["get_deployer", "install"]
