"""api.models — the shapes the frontend receives, and the one it sends.

Telemetry rows are NOT redefined here. ``core.contracts.telemetry`` already declares
them and ``docs/frontend/CONTEXT.md`` names those types as the contract, so the routes
serve them directly: a field added there appears in the API without a second edit, and
one renamed here would be a silent lie. What lives in this module is only what the HTTP
surface adds on top — the gate envelope, artifact references, and the submission body.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from core.contracts.telemetry import DecisionRow
from core.domo.schemas import EvalResult, HumanFeedback


class ArtifactSummary(BaseModel):
    """The coverage figures a reviewer needs before opening anything.

    ``unresolved`` is the one that blocks promotion: it counts steps whose SQL is a
    marked passthrough that does nothing. ``by_model`` is real SQL nobody has checked.
    Both are carried explicitly rather than derived in the browser, because the UI must
    not compute a number the artifact could contradict.
    """
    model_config = ConfigDict(extra="allow")

    sources: int = 0
    steps: int = 0
    targets: int = 0
    deterministic: int = 0
    by_model: int = 0
    unresolved: int = 0
    coverage_pct: float = 0.0


class ArtifactRef(BaseModel):
    """One artifact version. Never the content — that is a separate, explicit fetch.

    ``extra="allow"`` because a gate's artifact block is agent-shaped: md_plan carries
    one ``summary``, cd_codegen carries ``targets`` (one entry per output, with its CTE
    count and EXPLAIN verdict). Dropping the unmodelled half would silently empty the
    cd_codegen review view, which is exactly the failure the all-green case must not
    have.
    """
    model_config = ConfigDict(extra="allow")

    kind: str = ""                       # plan | sql | debug
    version: int = 1
    path: str = ""                       # a file on the volume; empty for a hash-stored artifact
    #: hash-stored artifact (``<etl_key>/<sha256>``): open it with ``GET /api/artifacts/{ref}``
    ref: str = ""
    target: str = ""                     # sql/debug only: which output target
    summary: ArtifactSummary | None = None
    #: cd_codegen: one entry per output target — target, table, path, ctes, explain
    targets: list[dict[str, Any]] | None = None


class JudgeResult(BaseModel):
    """A deterministic rule's verdict, as the gate payload carries it.

    Flatter than ``JudgeRow``: a gate has no ``run_id``/``ts`` to repeat per row, and
    the UI renders these above the model's opinion because they are facts.
    """
    rule_id: str
    title: str = ""
    kind: str = ""
    verdict: str = "pass"                # pass | warn | fail
    findings: int = 0
    checked: int = 0
    nodes: list[str] = Field(default_factory=list)
    note: str = ""


#: Card status for an open review (ADR 032: `awaiting_review`, core.review). migration-ui reads both spellings
#: (P3-16); readers normalize the old "awaiting review" alias through `core.review.normalize_status`.
CARD_AWAITING_REVIEW = "awaiting_review"


class Gate(BaseModel):
    """A HITL gate: the artifact under review and everything needed to judge it.

    Deliberately permissive about its payload. md_plan and cd_codegen carry an
    ``artifact``, validation carries ``results``, classifier carries ``layers`` — one
    envelope with optional members beats four near-identical models the UI would have
    to switch on twice.

    ``status`` is ``interrupted`` while a human is awaited. That is not an error; it is
    this user's turn, and the UI is required to style it as an action.
    """
    model_config = ConfigDict(extra="allow")

    gate_id: str
    run_id: str = ""
    dataflow_id: str = ""
    dataflow_name: str = ""
    agent: str
    iteration: int = 1
    status: str = "interrupted"
    artifact: ArtifactRef | None = None
    judges: list[JudgeResult] = Field(default_factory=list)
    eval: EvalResult | None = None
    standing_hard_constraints: list[str] = Field(default_factory=list)
    actions: list[str] = Field(default_factory=list)
    #: agent-specific extras (validation `results`, classifier `layers`, `provenance`)
    results: list[dict[str, Any]] | None = None
    layers: dict[str, Any] | None = None
    provenance: dict[str, Any] | None = None
    #: True once feedback has been submitted for this gate in this store.
    resolved: bool = False
    #: ``approved`` once a human approved this gate (the approval file / closing decision row), ``changes_requested``
    #: after a rejection, else None. The run report only reflects it after a resume; the UI reads it from here.
    approved: bool = False
    decision: str | None = None
    #: who decided and when (from the approval file / decision row); None while undecided
    reviewer: str | None = None
    decided_at: str | None = None
    #: translation gates: the units that hold no code (unresolved). The review UI renders them as "needs code" and
    #: the API refuses ``approve`` unless each carries an edit or is marked out of scope.
    no_code_unit_ids: list[str] = Field(default_factory=list)


class DataflowCard(BaseModel):
    """One row of the catalogue the landing page lists."""
    model_config = ConfigDict(extra="allow")

    dataflow_id: str
    dataflow_name: str = ""
    short_name: str = ""
    application: str = ""
    status: str = "unknown"
    tiles: int = 0
    sources: int = 0
    steps: int = 0
    targets: int = 0
    deterministic: int = 0
    by_model: int = 0
    unresolved: int = 0
    coverage_pct: float = 0.0
    latest_run_id: str = ""


class RunRecord(BaseModel):
    """One row of the run registry — what PRODUCED a run, not what it measured.

    Deliberately carries nothing that telemetry already answers. ``RunSummary``
    states, in its own docstring, that it is computed from the rows rather than
    maintained alongside them, precisely so the dashboard and the deliverable
    cannot disagree; copying cost or step counts in here would hand that problem
    straight back. Everything below is a fact no telemetry row holds:

    * which export the run read, and from where;
    * which volume it wrote to;
    * how far it got, and whether it stopped on purpose;
    * whether the external systems were mocked, which is the difference between
      evidence and a rehearsal.
    """
    model_config = ConfigDict(extra="allow")

    run_id: str
    dataflow_id: str = ""
    dataflow_name: str = ""
    started_ts: str = ""
    ended_ts: str = ""
    #: the export this run read - the one thing nobody can reconstruct afterwards
    input_path: str = ""
    volume: str = ""
    #: the run's own folder - artifacts, gates and telemetry all live under it
    run_dir: str = ""
    agents_completed: list[str] = Field(default_factory=list)
    stopped_at: str = ""
    #: "mock" when the DOMO API, Delta and the endpoint were stand-ins. A number
    #: from a mock run must never be mistaken for a measurement.
    mode: str = "mock"
    notes: str = ""


class FeedbackSubmission(BaseModel):
    """What the review view POSTs. One per gate, per iteration.

    Per-issue apply/keep is the contract, not bulk approve: ``PlanFeedbackApplier``
    splices only the accepted ids, and a single approve-all button would destroy the
    audit trail this platform exists to produce.

    ``rationales`` is keyed by issue id and carries the reviewer's own words onto the
    matching ``DecisionRow``. Reconstructing why an issue was waved through eight months
    later is impossible, which is why it is captured at the moment of the decision.
    """
    accepted_issue_ids: list[str] = Field(default_factory=list)
    rejected_issue_ids: list[str] = Field(default_factory=list)
    freeform: str = ""
    hard_constraints: list[str] = Field(default_factory=list)
    actor: str
    rationales: dict[str, str] = Field(default_factory=dict)
    constraint_rationales: dict[str, str] = Field(default_factory=dict)
    #: True = the reviewer accepted the artifact as it stands; False = send it back.
    approve: bool = False

    #: Text the reviewer replaced by hand — one entry per edited block, each
    #: ``{kind: "plan"|"sql", node, text}``. A review that can only say "wrong,
    #: regenerate" throws away the one thing the reviewer has that the model does
    #: not: they can see what the right answer is. Recorded as
    #: ``DecisionKind.OVERRIDE``.
    overrides: list[dict[str, Any]] = Field(default_factory=list)
    #: Nodes the reviewer moved between medallion layers, each
    #: ``{node, from, to}``. Layer assignment is an estate-level decision the
    #: classifier can only propose, so the person deciding it is the record.
    layer_moves: list[dict[str, Any]] = Field(default_factory=list)
    #: node -> the table name a reviewer gave an intermediate they materialized.
    layer_names: dict[str, str] = Field(default_factory=dict)
    #: translation reviews: unit id -> the code the reviewer wrote by hand for a unit nothing translated. On resume it
    #: becomes that unit's artifact with origin ``manual`` (and is validated like any draft). A gate with ``no_code``
    #: units cannot be approved unless each is covered here or in ``out_of_scope_unit_ids``.
    edits: dict[str, str] = Field(default_factory=dict)
    #: translation reviews: units the reviewer marks unsupported (out of scope), with their reason in
    #: ``out_of_scope_reasons``. The ETL then ends ``unsupported`` instead of waiting for code.
    out_of_scope_unit_ids: list[str] = Field(default_factory=list)
    out_of_scope_reasons: dict[str, str] = Field(default_factory=dict)


class FeedbackReceipt(BaseModel):
    """What came of a submission: the feedback as stored, and every row it wrote.

    ``binds_generated_code`` is false and says so out loud. Per architecture gap #1,
    ``HumanFeedback`` currently reaches only the AI translation path, which on a fully
    deterministic dataflow never runs — so the decisions are recorded and real, but no
    SQL changed. Telling a reviewer their edit landed when it did not is the worst thing
    this endpoint could do.
    """
    gate_id: str
    human_feedback: HumanFeedback
    decision_rows: list[DecisionRow]
    binds_generated_code: bool = False
    note: str = ""


class SourceProfile(BaseModel):
    """The source platform, with the nouns the UI uses for its pipelines and steps."""
    id: str
    label: str
    unit: str = Field(description="what the source calls one pipeline, e.g. 'dataflow'")
    units: str
    step: str = Field(description="what the source calls one step, e.g. 'tile'")
    steps: str
    ready: bool = True


class TargetProfile(BaseModel):
    """The target platform the generated logic is written for."""
    id: str
    label: str
    dialects: list[str]
    catalog_label: str
    ready: bool = True


class PlatformProfile(BaseModel):
    """Which pair this deployment migrates between. Any-to-any, ETL logic only:
    data movement is handled by a separate accelerator."""
    product: str
    tagline: str
    scope: str
    source: SourceProfile
    target: TargetProfile


class Meta(BaseModel):
    """The agent vocabulary, served rather than duplicated in the browser.

    ``CONTEXT.md`` is explicit that the UI must read ``AGENT_DEFAULTS`` instead of
    hardcoding which agents ask a human, and must render ``AGENT_PHASES`` strings
    verbatim. Serving them from ``agents/master.py`` is what makes that enforceable:
    a phase renamed there changes the UI without anybody editing the UI.

    ``profile`` names the source -> target pair, so the UI's wording follows the
    deployment rather than hard-coding one pair.
    """
    agent_order: list[str]
    agent_phases: dict[str, list[str]]
    agent_defaults: dict[str, dict[str, bool]]
    store: str
    binds_generated_code: bool = False
    profile: PlatformProfile


__all__ = ["ArtifactRef", "ArtifactSummary", "DataflowCard", "FeedbackReceipt",
           "FeedbackSubmission", "Gate", "JudgeResult", "Meta", "PlatformProfile",
           "RunRecord", "SourceProfile", "TargetProfile"]
