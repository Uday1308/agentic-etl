"""api.cleanup - delete a batch run or one run from the local volume / work dir (used by Discovery's
``DELETE /handoff/runs`` and by the migration UI, docs/plans/migrator-experience.md 3.2).

Removes the batch report (and its ``<batch_run_id>/`` assembly folder), each ETL run folder with its gates, the review
feedback written for those gates and the run's telemetry. Content-addressed artifacts under
``<volume>/<etl_key>/artifacts/`` stay (runs share them by hash). Only paths inside the volume are ever removed.
"""
from __future__ import annotations

import contextlib
import json
import pathlib
import re
import shutil

_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$")


def valid_id(value: str) -> bool:
    return bool(_NAME.match(value or "")) and ".." not in value


def _inside(path: pathlib.Path, root: pathlib.Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def _remove_run_dir(d: pathlib.Path, volume: pathlib.Path, work: pathlib.Path, counts: dict[str, int]) -> None:
    if not d.is_dir() or not _inside(d, volume) or not valid_id(d.name):
        return
    for g in sorted((d / "gates").glob("*.json")):
        counts["gates"] += 1
        for name in (f"{g.stem}.json", f"{g.stem}.approval.json"):
            f = work / "feedback" / name
            if f.exists():
                f.unlink()
                counts["feedback_files"] += 1
    shutil.rmtree(work / "telemetry" / d.name, ignore_errors=True)
    shutil.rmtree(d, ignore_errors=True)
    counts["run_dirs"] += 1
    with contextlib.suppress(OSError):
        d.parent.rmdir()                             # the ETL's folder, when it held nothing else


def _counts() -> dict[str, int]:
    return {"reports": 0, "run_dirs": 0, "gates": 0, "feedback_files": 0}


def delete_run(volume: pathlib.Path | str, work: pathlib.Path | str, run_id: str) -> dict[str, int] | None:
    """Delete one run folder (``<volume>/<etl_key>/<run_id>``). None when there is no such run."""
    volume, work = pathlib.Path(volume), pathlib.Path(work)
    if not valid_id(run_id):
        return None
    hits = [p for p in volume.glob(f"*/{run_id}") if p.is_dir()] if volume.is_dir() else []
    if not hits:
        return None
    counts = _counts()
    for d in hits:
        _remove_run_dir(d, volume, work, counts)
    return counts


def delete_batch(volume: pathlib.Path | str, work: pathlib.Path | str, batch_run_id: str) -> dict[str, int] | None:
    """Delete one batch run: its report, assembly folder and every ETL run it started. None when unknown."""
    volume, work = pathlib.Path(volume), pathlib.Path(work)
    if not valid_id(batch_run_id):
        return None
    hits = sorted((volume / "batches").glob(f"*/{batch_run_id}.json")) if (volume / "batches").is_dir() else []
    if not hits:
        return None
    report = hits[0]
    counts = _counts()
    try:
        doc = json.loads(report.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        doc = {}
    shared: set[str] = set()                         # run folders another report (a resume) still points at
    for other in (volume / "batches").glob("*/*.json"):
        if other.resolve() == report.resolve():
            continue
        try:
            shared |= {str(pathlib.Path(r["run_dir"]).resolve()) for r in json.loads(
                other.read_text(encoding="utf-8")).get("etls") or [] if isinstance(r, dict) and r.get("run_dir")}
        except (OSError, ValueError):
            continue
    for row in doc.get("etls") or []:
        if row.get("run_dir") and str(pathlib.Path(row["run_dir"]).resolve()) not in shared:
            _remove_run_dir(pathlib.Path(row["run_dir"]), volume, work, counts)
    shutil.rmtree(report.with_suffix(""), ignore_errors=True)
    report.unlink()
    counts["reports"] += 1
    with contextlib.suppress(OSError):
        report.parent.rmdir()
    return counts
