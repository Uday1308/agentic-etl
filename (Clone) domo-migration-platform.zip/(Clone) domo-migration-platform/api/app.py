"""api.app — the routes the LatentView Migration Platform frontend calls.

Thin on purpose. Every function here resolves a store, calls one port method and
returns the contract model; there is no business logic to drift from the agents. The
two things it does add are the two things HTTP requires: turning "no such run" into a
404 and a ``StoreError`` into a 502 that names the cause, so the UI never renders an
empty dashboard that actually means "the warehouse is down".

Read-mostly by contract. ``docs/frontend/CONTEXT.md``: *the frontend never calls an
agent directly and never calls a serving endpoint*. The only write is one human's
review decision, which is not the same thing as steering the pipeline.

Run it::

    uvicorn api.app:app --reload --port 8000        # PLATFORM_STORE=local by default
    PLATFORM_STORE=delta uvicorn api.app:app        # needs the DATABRICKS_* vars
"""
from __future__ import annotations

import functools
import logging
import os

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from api.models import (
    ArtifactRef,
    DataflowCard,
    FeedbackReceipt,
    FeedbackSubmission,
    Gate,
    Meta,
    RunRecord,
)
from api.pack_runs import pack_artifact_refs, pack_summaries, pack_summary
from api.ports import ArtifactChanged, PlatformStore, StoreError
from api.profile import profile_from_headers
from api.serving import is_databricks_app, mount_spa, reviewer_from_headers
from api.store_local import LocalStore
from core.contracts.telemetry import (
    DecisionRow,
    IngestionRow,
    JudgeRow,
    LlmCallRow,
    RunSummary,
    StepRow,
    ValidationRow,
)

#: Vite's dev server. Overridable because the deployed origin will not be localhost.
DEFAULT_ORIGINS = ("http://localhost:5173", "http://127.0.0.1:5173")


@functools.lru_cache(maxsize=1)
def get_store() -> PlatformStore:
    """The store this process serves, chosen once by ``PLATFORM_STORE``.

    Cached because building the Delta one opens a connection, and overridable in tests
    through FastAPI's dependency_overrides — which is the whole reason the routes take
    it as a dependency rather than reaching for a module global.
    """
    kind = os.environ.get("PLATFORM_STORE", "delta" if is_databricks_app() else "local")
    kind = kind.lower()
    if kind == "local":
        if is_databricks_app():
            # An App instance has an ephemeral filesystem and can be replaced at any
            # time, so reviews written to it disappear without anyone noticing. That
            # is a worse failure than refusing to start.
            raise RuntimeError(
                "PLATFORM_STORE=local inside a Databricks App writes the review trail "
                "to an ephemeral disk, where it will be lost. Set PLATFORM_STORE=delta "
                "and the PLATFORM_CATALOG / PLATFORM_SCHEMA / PLATFORM_VOLUME vars.")
        return LocalStore(os.environ.get("PLATFORM_ROOT", "."),
                          volume=os.environ.get("PLATFORM_VOLUME", ""),
                          samples=os.environ.get("PLATFORM_SAMPLES_DIR", ""))
    if kind == "delta":
        from api.store_delta import DeltaStore, connect_databricks

        catalog = os.environ.get("PLATFORM_CATALOG", "dev_test")
        schema = os.environ.get("PLATFORM_SCHEMA", "domo_migration_audit")
        query, read_file, list_files = connect_databricks()
        # No sink is attached: a Databricks App has no Spark session, so DeltaSink
        # cannot write here. DeltaStore falls back to INSERTing decision rows over
        # the same SQL warehouse it reads through.
        return DeltaStore(query, catalog=catalog, schema=schema,
                          volume=os.environ.get("PLATFORM_VOLUME", ""),
                          read_file=read_file, list_files=list_files)
    raise RuntimeError(f"unknown PLATFORM_STORE {kind!r}; expected 'local' or 'delta'")


app = FastAPI(
    title="LatentView Migration Platform API",
    version="1.0.0",
    summary="Any-to-any ETL logic migration (logic only; data movement is handled by a "
            "separate accelerator).",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(os.environ.get("PLATFORM_ORIGINS", "").split(",")
                       if os.environ.get("PLATFORM_ORIGINS") else DEFAULT_ORIGINS),
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.exception_handler(ArtifactChanged)
async def _artifact_changed(_request, exc: ArtifactChanged):
    """Approval of an artifact that changed since it was reviewed (ADR 032 section 3)."""
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=409, content={"detail": str(exc)})


@app.exception_handler(StoreError)
async def _store_error(_request, exc: StoreError):
    """A store that cannot answer is a 502 naming the cause, never an empty list.

    The difference matters more here than in most services: an empty dashboard in this
    product reads as "the migration did nothing", which is a very different thing from
    "the warehouse is unreachable".
    """
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=502, content={"detail": str(exc)})


def _found(value, what: str):
    if value is None:
        raise HTTPException(status_code=404, detail=f"no {what}")
    return value


# --------------------------------------------------------------------------- #
# meta
# --------------------------------------------------------------------------- #

@app.get("/api/meta", response_model=Meta, tags=["meta"])
def meta(request: Request, store: PlatformStore = Depends(get_store)) -> Meta:
    from agents.master import AGENT_DEFAULTS, AGENT_ORDER, AGENT_PHASES

    return Meta(
        agent_order=list(AGENT_ORDER),
        agent_phases={k: list(v) for k, v in AGENT_PHASES.items()},
        agent_defaults={k: dict(v) for k, v in AGENT_DEFAULTS.items()},
        store=store.name,
        binds_generated_code=False,
        profile=profile_from_headers(request.headers),
    )


#: forwarded by the portal (ids only, never a secret): the selected source, and the user's roles
SOURCE_ID_HEADER = "X-Srcintel-Source-Id"
ROLES_HEADER = "X-Srcintel-User-Roles"
#: platform roles that may read unmasked generated SQL (anything above viewer)
REVIEWER_ROLES = frozenset({"admin", "lead", "contributor"})
_artifact_log = logging.getLogger("migrator.artifact_reads")


@app.get("/api/artifacts/{ref:path}", tags=["review"])
def artifact_text(ref: str, request: Request, store: PlatformStore = Depends(get_store)) -> dict:
    """The unmasked text of one generated artifact (ADR 032 section 3).

    Gate payloads and reports hold only ``artifact_ref``, ``sha256`` and a masked preview;
    this is the one way to the real text. It checks the reviewer (identity header; required
    when deployed), the reviewer role (``X-Srcintel-User-Roles``; required when deployed),
    and that the artifact belongs to the forwarded source; every read is logged.
    """
    from agents.cd_codegen.translate.artifacts import ArtifactError, artifact_meta, read_artifact, sha256_text

    reviewer = reviewer_from_headers(request.headers)
    deployed = is_databricks_app()
    if deployed and not reviewer:
        raise HTTPException(status_code=401, detail="no authenticated reviewer on this request")
    roles = {r.strip().lower() for r in (request.headers.get(ROLES_HEADER) or "").split(",") if r.strip()}
    if roles and not roles & REVIEWER_ROLES:
        raise HTTPException(status_code=403, detail="reading generated SQL needs a reviewer role")
    if deployed and not roles:
        raise HTTPException(status_code=403, detail=f"no {ROLES_HEADER} on this request; refusing unmasked SQL")
    volume = getattr(store, "volume", None)
    if volume is None:
        raise HTTPException(status_code=501, detail=f"the {store.name} store does not serve artifacts yet")
    try:
        meta = artifact_meta(volume, ref)
        text = read_artifact(volume, ref)
    except ArtifactError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="no such artifact") from exc
    forwarded = (request.headers.get(SOURCE_ID_HEADER) or "").strip()
    owner = str(meta.get("source_id") or "")
    if owner and forwarded != owner:
        if forwarded or deployed:     # another source's artifact: indistinguishable from absent
            raise HTTPException(status_code=404, detail="no such artifact")
    _artifact_log.info("artifact read ref=%s reviewer=%s source=%s", ref, reviewer or "(local)", forwarded)
    return {"artifact_ref": ref, "sha256": sha256_text(text), "kind": meta.get("kind", "sql"),
            "source_id": owner, "text": text}


def _require_admin(request: Request) -> None:
    """Deleting runs: an admin (forwarded roles header); required when deployed, open for a local run."""
    roles = {r.strip().lower() for r in (request.headers.get(ROLES_HEADER) or "").split(",") if r.strip()}
    if (roles or is_databricks_app()) and "admin" not in roles:
        raise HTTPException(status_code=403, detail="deleting runs needs the admin role")


def _paths_of(store: PlatformStore):
    volume, work = getattr(store, "volume", None), getattr(store, "work", None)
    if volume is None or work is None:
        raise HTTPException(status_code=501, detail=f"the {store.name} store does not support deleting runs yet")
    return volume, work


@app.delete("/api/batches/{batch_run_id}", tags=["runs"])
def delete_batch_run(batch_run_id: str, request: Request, store: PlatformStore = Depends(get_store)) -> dict:
    """Delete a batch run's report and every ETL run it started (admin). Returns what was removed."""
    from api.cleanup import delete_batch

    _require_admin(request)
    volume, work = _paths_of(store)
    counts = delete_batch(volume, work, batch_run_id)
    return {"deleted": batch_run_id, "counts": _found(counts, f"batch run {batch_run_id}")}


@app.delete("/api/runs/{run_id}", tags=["runs"])
def delete_one_run(run_id: str, request: Request, store: PlatformStore = Depends(get_store)) -> dict:
    """Delete one ETL run folder with its gates and feedback (admin). Returns what was removed."""
    from api.cleanup import delete_run

    _require_admin(request)
    volume, work = _paths_of(store)
    counts = delete_run(volume, work, run_id)
    return {"deleted": run_id, "counts": _found(counts, f"run {run_id}")}


@app.get("/api/health", tags=["meta"])
def health(store: PlatformStore = Depends(get_store)) -> dict:
    """Liveness plus which store answered — the first thing to check on a bad dry run."""
    return {"ok": True, "store": store.name}


# --------------------------------------------------------------------------- #
# catalogue and runs
# --------------------------------------------------------------------------- #

@app.get("/api/dataflows", response_model=list[DataflowCard], tags=["catalogue"])
def dataflows(store: PlatformStore = Depends(get_store)) -> list[DataflowCard]:
    return store.dataflows()


@app.get("/api/dataflows/{dataflow_id}", response_model=DataflowCard, tags=["catalogue"])
def dataflow(dataflow_id: str,
             store: PlatformStore = Depends(get_store)) -> DataflowCard:
    card = next((c for c in store.dataflows() if c.dataflow_id == dataflow_id), None)
    return _found(card, f"dataflow {dataflow_id}")


@app.get("/api/runs", response_model=list[RunSummary], tags=["runs"])
def runs(dataflow_id: str = Query("", description="filter to one dataflow"),
         store: PlatformStore = Depends(get_store)) -> list[RunSummary]:
    out = store.runs(dataflow_id)
    volume = getattr(store, "volume", None)
    if volume is not None:
        # pack runs (Snowflake) are summarised from their own run.json; that outranks the placeholder a
        # gate-only run gets from the telemetry-based listing
        packed = pack_summaries(volume, dataflow_id)
        ids = {s.run_id for s in packed}
        out = sorted([s for s in out if s.run_id not in ids] + packed,
                     key=lambda s: s.started_ts or s.run_id, reverse=True)
    return out


@app.get("/api/run-records", response_model=list[RunRecord], tags=["runs"])
def run_records(store: PlatformStore = Depends(get_store)) -> list[RunRecord]:
    """The run registry: what produced each run — which export it read, which
    volume it wrote, how far it got, and whether the externals were mocked.

    Provenance only. Every count comes from `/api/runs`, computed off telemetry,
    so the registry can never disagree with what the run actually did.
    """
    return store.run_records()


@app.get("/api/runs/{run_id}", response_model=RunSummary, tags=["runs"])
def run(run_id: str, store: PlatformStore = Depends(get_store)) -> RunSummary:
    volume = getattr(store, "volume", None)
    packed = pack_summary(volume, run_id) if volume is not None else None
    return _found(packed or store.summary(run_id), f"run {run_id}")


@app.get("/api/runs/{run_id}/steps", response_model=list[StepRow], tags=["telemetry"])
def steps(run_id: str, store: PlatformStore = Depends(get_store)) -> list[StepRow]:
    """Phase transitions, in order. ``interrupted`` means a gate is open and waiting
    for this user — the UI must style it as an action, not a failure."""
    return store.steps(run_id)


@app.get("/api/runs/{run_id}/llm-calls", response_model=list[LlmCallRow],
         tags=["telemetry"])
def llm_calls(run_id: str, store: PlatformStore = Depends(get_store)) -> list[LlmCallRow]:
    """Model usage. An empty list is a success state on a deterministic dataflow, not
    a missing payload — 8099 makes zero calls."""
    return store.llm_calls(run_id)


@app.get("/api/runs/{run_id}/ingestions", response_model=list[IngestionRow],
         tags=["telemetry"])
def ingestions(run_id: str,
               store: PlatformStore = Depends(get_store)) -> list[IngestionRow]:
    return store.ingestions(run_id)


@app.get("/api/runs/{run_id}/judges", response_model=list[JudgeRow], tags=["telemetry"])
def judges(run_id: str, store: PlatformStore = Depends(get_store)) -> list[JudgeRow]:
    """Deterministic rule results. These are facts and outrank the model's opinion."""
    return store.judges(run_id)


@app.get("/api/runs/{run_id}/validations", response_model=list[ValidationRow],
         tags=["telemetry"])
def validations(run_id: str,
                store: PlatformStore = Depends(get_store)) -> list[ValidationRow]:
    return store.validations(run_id)


@app.get("/api/runs/{run_id}/decisions", response_model=list[DecisionRow],
         tags=["telemetry"])
def decisions(run_id: str,
              store: PlatformStore = Depends(get_store)) -> list[DecisionRow]:
    """The audit trail: every human intervention, with the rationale attached."""
    return store.decisions(run_id)


# --------------------------------------------------------------------------- #
# gates — the review surface
# --------------------------------------------------------------------------- #

@app.get("/api/gates", response_model=list[Gate], tags=["review"])
def gates(run_id: str = Query(""), dataflow_id: str = Query(""),
          open_only: bool = Query(False, description="only gates awaiting a human"),
          store: PlatformStore = Depends(get_store)) -> list[Gate]:
    return store.gates(run_id=run_id, dataflow_id=dataflow_id, open_only=open_only)


@app.get("/api/gates/{gate_id}", response_model=Gate, tags=["review"])
def gate(gate_id: str, store: PlatformStore = Depends(get_store)) -> Gate:
    return _found(store.gate(gate_id), f"gate {gate_id}")


def gate_units(found: Gate) -> list[dict]:
    """The per-unit records of a translation gate (``artifact.units``), each with its ``no_code`` flag."""
    units = ((found.artifact.model_extra or {}).get("units") if found.artifact else None) or []
    return [u for u in units if isinstance(u, dict)]


def _check_unit_decisions(found: Gate, sub: FeedbackSubmission) -> None:
    """Honest reviews: a translation gate whose units hold no code cannot be approved as it stands. Each ``no_code``
    unit needs a hand-written edit or an explicit out-of-scope decision; ids must belong to the gate."""
    units = gate_units(found)
    ids = {str(u.get("unit_id")) for u in units}
    no_code = sorted({str(u.get("unit_id")) for u in units if u.get("no_code")}
                     | set(found.no_code_unit_ids or []) | set((found.model_extra or {}).get("no_code_unit_ids") or []))
    if sub.edits or sub.out_of_scope_unit_ids:
        stray = sorted((set(sub.edits) | set(sub.out_of_scope_unit_ids)) - (ids | set(no_code)))
        if stray:
            raise HTTPException(status_code=422, detail=f"gate {found.gate_id} has no unit(s) {stray}; "
                                                        f"known units are {sorted(ids)}")
    blank = sorted(u for u, t in sub.edits.items() if not str(t).strip())
    if blank:
        raise HTTPException(status_code=422, detail=f"the edit for unit(s) {blank} is empty; write the code, or "
                                                    "mark the unit out of scope")
    both = sorted(set(sub.edits) & set(sub.out_of_scope_unit_ids))
    if both:
        raise HTTPException(status_code=422, detail=f"unit(s) {both} carry both an edit and an out-of-scope decision")
    if sub.approve and no_code:
        missing = [u for u in no_code if not str(sub.edits.get(u) or "").strip() and u not in sub.out_of_scope_unit_ids]
        if missing:
            raise HTTPException(
                status_code=422,
                detail=f"cannot approve: unit(s) {missing} have no translated code. Provide the code for each "
                       "(`edits`), or mark it out of scope (`out_of_scope_unit_ids`, with a reason).")


@app.post("/api/gates/{gate_id}/feedback", response_model=FeedbackReceipt,
          tags=["review"])
def submit_feedback(gate_id: str, submission: FeedbackSubmission, request: Request,
                    store: PlatformStore = Depends(get_store)) -> FeedbackReceipt:
    """Record one review: the ``HumanFeedback`` and one ``DecisionRow`` per decision.

    An issue id that is not on this gate is rejected rather than recorded. A decision
    row pointing at an issue nobody raised is worse than no row: the deviation report
    is the deliverable, and it has to be defensible line by line.

    The receipt says ``binds_generated_code: false`` out loud. Per architecture gap #1
    the accepted issues do not yet change the SQL, and the UI must not claim they did.
    """
    # Whoever the proxy authenticated outranks whatever the browser sent. These rows
    # ARE the client deviation report; a decision filed under someone else's name is
    # the one thing that makes it worthless. With no proxy (local dev) the submitted
    # actor stands, and must then be non-empty.
    authenticated = reviewer_from_headers(request.headers)
    if authenticated:
        submission = submission.model_copy(update={"actor": authenticated})
    elif is_databricks_app():
        raise HTTPException(
            status_code=401,
            detail="no authenticated reviewer on this request. Expected one of "
                   "the identity headers the Apps proxy sets; refusing to record a "
                   "decision under a name the client chose.")
    elif not submission.actor.strip():
        raise HTTPException(status_code=422, detail="actor is required")

    found = _found(store.gate(gate_id), f"gate {gate_id}")
    known = {i.id for i in (found.eval.issues if found.eval else ())}
    unknown = sorted(set(submission.accepted_issue_ids + submission.rejected_issue_ids)
                     - known)
    if unknown:
        raise HTTPException(
            status_code=422,
            detail=f"gate {gate_id} has no issue(s) {unknown}; known ids are "
                   f"{sorted(known)}")
    _check_unit_decisions(found, submission)
    both = sorted(set(submission.accepted_issue_ids) & set(submission.rejected_issue_ids))
    if both:
        raise HTTPException(
            status_code=422,
            detail=f"issue(s) {both} are both accepted and rejected; each issue takes "
                   f"exactly one decision")
    receipt = store.submit_feedback(gate_id, submission)
    from api.review_routes import after_feedback  # S11: the per-unit decision ledger

    after_feedback(store, found, submission, receipt)
    return receipt


# --------------------------------------------------------------------------- #
# artifacts
# --------------------------------------------------------------------------- #

@app.get("/api/dataflows/{dataflow_id}/artifacts", response_model=list[ArtifactRef],
         tags=["artifacts"])
def artifacts(dataflow_id: str,
              store: PlatformStore = Depends(get_store)) -> list[ArtifactRef]:
    """Every version of every artifact, so the UI can offer a diff. An approved prior
    is immutable — a regenerated artifact is a new version, never an overwrite."""
    found = store.artifacts(dataflow_id)
    volume = getattr(store, "volume", None)
    if volume is None:
        return found
    # A pack gate (Snowflake) holds hash-stored artifacts, not files: list each by ``ref`` (open it with
    # ``/api/artifacts/{ref}``) instead of the one path-less gate block.
    refs = pack_artifact_refs(volume, dataflow_id)
    if not refs:
        return found
    extra = lambda a: bool((a.model_extra or {}).get("artifacts"))  # noqa: E731
    return [a for a in found if not extra(a)] + refs


@app.get("/api/dataflows/{dataflow_id}/graph", tags=["artifacts"])
def graph(dataflow_id: str, store: PlatformStore = Depends(get_store)) -> list[dict]:
    """The tile graph, one node per DOMO tile. Empty means nothing produced one —
    which is not the same as a dataflow with no tiles, and the UI must say so."""
    return store.graph(dataflow_id)


class ArtifactContent(BaseModel):
    path: str
    text: str


@app.get("/api/artifact", response_model=ArtifactContent, tags=["artifacts"])
def artifact_content(request: Request, path: str = Query(..., description="path from an ArtifactRef"),
                     store: PlatformStore = Depends(get_store)) -> ArtifactContent:
    """The MASKED text of one artifact. The path must come from an ``ArtifactRef`` — stores
    refuse anything outside the roots they serve, so this is not a file browser. Literals are masked
    like gate previews; the unmasked text is only at ``/api/artifacts/{ref}`` (reviewer role, logged)."""
    from agents.cd_codegen.translate.artifacts import masked_preview

    roles = {r.strip().lower() for r in (request.headers.get(ROLES_HEADER) or "").split(",") if r.strip()}
    if (roles and not roles & REVIEWER_ROLES) or (is_databricks_app() and not roles):
        raise HTTPException(status_code=403, detail="reading artifacts needs a reviewer role")
    return ArtifactContent(path=path, text=masked_preview(store.artifact_content(path), limit=10**9))


@app.get("/api/runs/{run_id}/record", tags=["runs"])
def run_record(run_id: str, request: Request, store: PlatformStore = Depends(get_store)) -> dict:
    """``run.json`` of a pack-driven run (per-unit origin, state, attempts, caveats; gates under ``gates/``).

    Searches the store's volume for ``<etl_key>/<run_id>/run.json``. Unit records hold masked previews only."""
    import json as _json
    import re as _re

    if not _re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", run_id):
        raise HTTPException(status_code=400, detail="bad run id")
    volume = getattr(store, "volume", None)
    if volume is None:
        raise HTTPException(status_code=501, detail=f"the {store.name} store does not serve run records")
    import pathlib as _pl

    for hit in _pl.Path(volume).glob(f"*/{run_id}/run.json"):
        out = _json.loads(hit.read_text(encoding="utf-8"))
        gates = sorted(p.stem for p in (hit.parent / "gates").glob("*.json")) if (hit.parent / "gates").is_dir() else []
        out.setdefault("gates", [{"gate": g} for g in gates])
        return out
    raise HTTPException(status_code=404, detail="no run record for this run")


from api.serving import spa_directory as _spa_directory  # noqa: E402

#: Resolved before the catch-all is mounted so the route below can report it.
SPA_DIR = _spa_directory()


@app.get("/api/serving", tags=["meta"])
def serving() -> dict:
    """How this process is deployed. The first thing to check when the UI is blank
    but the API answers: `spa` null means nobody ran `npm run build`."""
    return {"databricks_app": is_databricks_app(),
            "spa": str(SPA_DIR) if SPA_DIR else None,
            "store": os.environ.get("PLATFORM_STORE",
                                    "delta" if is_databricks_app() else "local")}


from api import deploy_routes as _deploy_routes  # noqa: E402  S13 deploy
from api import review_routes as _review_routes  # noqa: E402  S11 groups, suggestions

_review_routes.install(app, get_store, submit_feedback)
_deploy_routes.install(app, get_store)
from api import usage_routes as _usage_routes  # noqa: E402  S14 usage view

_usage_routes.install(app, get_store)


# Mounted LAST, on purpose: it ends in a catch-all that would otherwise shadow
# every route declared after it — as it did the first time this was written.
mount_spa(app)


__all__ = ["app", "get_store"]
