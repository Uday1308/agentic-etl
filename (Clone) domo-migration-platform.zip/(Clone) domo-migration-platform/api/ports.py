"""api.ports — where the HTTP layer gets its data.

One port, two adapters, for the same reason the rest of the platform is built this way:
the routes must be testable and runnable without a warehouse. ``LocalStore`` reads the
sample payloads and the dry-run output already in this repo; ``DeltaStore`` reads the
six audit tables ``DeltaSink`` writes plus the artifacts on the UC volume. Neither is
referenced by the route functions — they take the port.

Every read returns already-validated contract models, never raw dicts, so a malformed
row fails at the boundary with a message naming the file or table rather than surfacing
in the browser as a missing field.
"""
from __future__ import annotations

import abc

from api.models import (
    ArtifactRef,
    DataflowCard,
    FeedbackReceipt,
    FeedbackSubmission,
    Gate,
    RunRecord,
)
from core.contracts.telemetry import (
    DecisionRow,
    IngestionRow,
    JudgeRow,
    LlmCallRow,
    RunSummary,
    StepRow,
    ValidationRow,
)


class ArtifactChanged(RuntimeError):
    """Approval refused: an artifact's current sha256 differs from the one under review
    (ADR 032 section 3). Served as 409, not as a store failure."""


class StoreError(RuntimeError):
    """A read failed in a way the caller must see.

    Distinct from "there is nothing there": an absent run returns None and an empty
    table returns an empty list, both of which are ordinary. This is for a store that
    cannot answer — a missing volume, a warehouse that will not connect, a payload that
    does not validate. Those become 502s naming the cause, never empty dashboards.
    """


class PlatformStore(abc.ABC):
    """Everything the frontend can read, and the one thing it can write."""

    name: str = "store"

    # -- catalogue --------------------------------------------------------- #
    @abc.abstractmethod
    def dataflows(self) -> list[DataflowCard]:
        """Every dataflow this store knows about, for the catalogue view."""

    @abc.abstractmethod
    def runs(self, dataflow_id: str = "") -> list[RunSummary]:
        """Run summaries, newest first. Filtered to one dataflow when given."""

    @abc.abstractmethod
    def summary(self, run_id: str) -> RunSummary | None:
        """One run's rollup, or None if there is no such run."""

    @abc.abstractmethod
    def run_records(self) -> list[RunRecord]:
        """The run registry: what produced each run, newest first.

        Provenance only — which export it read, which volume it wrote, how far it
        got. Never counts: those come from ``summary()``, computed off telemetry, so
        the registry cannot drift away from what actually happened.
        """

    # -- telemetry --------------------------------------------------------- #
    @abc.abstractmethod
    def steps(self, run_id: str) -> list[StepRow]: ...

    @abc.abstractmethod
    def llm_calls(self, run_id: str) -> list[LlmCallRow]: ...

    @abc.abstractmethod
    def ingestions(self, run_id: str) -> list[IngestionRow]: ...

    @abc.abstractmethod
    def judges(self, run_id: str) -> list[JudgeRow]: ...

    @abc.abstractmethod
    def validations(self, run_id: str) -> list[ValidationRow]: ...

    @abc.abstractmethod
    def decisions(self, run_id: str) -> list[DecisionRow]: ...

    # -- review ------------------------------------------------------------ #
    @abc.abstractmethod
    def gates(self, *, run_id: str = "", dataflow_id: str = "",
              open_only: bool = False) -> list[Gate]:
        """HITL gates, in pipeline order. ``open_only`` keeps the ones still awaiting
        a human — the calls to action."""

    @abc.abstractmethod
    def gate(self, gate_id: str) -> Gate | None: ...

    @abc.abstractmethod
    def submit_feedback(self, gate_id: str,
                        submission: FeedbackSubmission) -> FeedbackReceipt:
        """Record one review decision and the audit rows it implies.

        Implementations must write one ``DecisionRow`` per decision — never one batched
        row for the lot. The rows ARE the client deviation report, and a batch cannot
        say which issue carried which rationale.
        """

    # -- artifacts ---------------------------------------------------------- #
    @abc.abstractmethod
    def artifacts(self, dataflow_id: str) -> list[ArtifactRef]:
        """Every artifact version for a dataflow, so the UI can offer a diff.

        An approved prior is immutable: a regenerated artifact is a new version, never
        an overwrite, and both must remain listed.
        """

    @abc.abstractmethod
    def artifact_content(self, path: str) -> str:
        """The text of one artifact. Raises ``StoreError`` if it cannot be read."""

    # -- graph --------------------------------------------------------------- #
    @abc.abstractmethod
    def graph(self, dataflow_id: str) -> list[dict]:
        """The tile graph the UI draws: one node per DOMO tile, with its inputs.

        Empty when nothing has produced one, which the UI must render as "no graph"
        rather than as an empty dataflow. ``origin`` on each node is the render
        result for that tile — a node shown as deterministic that was in fact a
        passthrough is precisely the lie this platform exists to prevent, so it is
        carried from the plan rather than assumed.
        """


__all__ = ["PlatformStore", "StoreError"]
