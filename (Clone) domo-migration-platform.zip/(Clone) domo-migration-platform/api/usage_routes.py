"""api.usage_routes - the LLM usage view (S14): ``GET /api/usage`` summarises ``<volume>/_usage/*.jsonl``.

Counts, tokens, estimated cost (``null`` when an endpoint has no rate: never zero) and error classes; nothing else is
ever written to the ledger, so nothing else can be shown.
"""
from __future__ import annotations

import pathlib
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query

from api.ports import PlatformStore
from core import llm_budget as lb


def install(app: FastAPI, get_store: Any) -> None:
    @app.get("/api/usage", tags=["usage"])
    def usage(run_id: str = Query("", description="one run (batch run id); empty = every run"),
              store: PlatformStore = Depends(get_store)) -> dict:
        volume = getattr(store, "volume", None)
        if volume is None:
            raise HTTPException(status_code=501, detail=f"the {store.name} store does not keep a usage ledger")
        root = pathlib.Path(volume) / "_usage"
        every_file = sorted(root.glob("*.jsonl")) if root.is_dir() else []
        files = [lb.ledger_for(volume, run_id).path] if run_id else every_file
        runs, every = [], []
        for f in files:
            rows = lb.UsageLedger(f).rows()
            if rows:
                runs.append({"run_id": f.stem, **lb.summarize(rows)})
                every += rows
        pol = lb.load_budget()
        return {"summary": lb.summarize(every), "runs": runs, "currency": lb.load_pricing().currency,
                "budget": {"max_tokens_per_run": pol.max_tokens, "max_cost_per_run": pol.max_cost,
                           "max_calls_per_run": pol.max_calls, "attempts_per_unit": pol.attempts_per_unit}}


__all__ = ["install"]
