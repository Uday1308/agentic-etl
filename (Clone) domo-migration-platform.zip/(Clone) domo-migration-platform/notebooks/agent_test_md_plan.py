# Databricks notebook source
# MAGIC %md
# MAGIC # Agent test · MD Plan (4)
# MAGIC
# MAGIC ## Read this before running
# MAGIC
# MAGIC The MD Plan generator body is still a **`TEAMMATE-OWNED` stub**. It reads both
# MAGIC JSONs, layers the prompt correctly and versions its output — but the prompt that
# MAGIC actually produces the plan has not been written here. So this notebook tests the
# MAGIC agent's **contract**, not the quality of the plan it writes:
# MAGIC
# MAGIC * does the generator read the standardized JSON **and** the original DOMO JSON
# MAGIC * is the output versioned per iteration (never overwriting an approved prior)
# MAGIC * does P1 human feedback outrank the P4 base prompt on regeneration
# MAGIC * does feedback accumulate across rounds
# MAGIC * are tokens, cost and steps recorded
# MAGIC
# MAGIC If you want to see what a **finished** plan looks like, point cell 6 at the real
# MAGIC `cms_8099.md` — it inspects the artifact the current generator already produces
# MAGIC downstream, and reports what a plan must contain to be reviewable.

# COMMAND ----------

# MAGIC %pip install --quiet "langgraph>=0.2" "langchain-core>=0.3" "databricks-sdk>=0.30" nest_asyncio
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-platform", "Repo root")
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("dataflow_id", "8099", "Dataflow id")
dbutils.widgets.text("dataflow_name", "cms_8099", "Dataflow name")
dbutils.widgets.text("standardized_root", "/Volumes/dev_test/dev_domo_migration/standardized", "Standardized JSON root")
dbutils.widgets.text("raw_root", "/Volumes/dev_test/dev_domo_migration/raw", "Raw DOMO JSON root")
dbutils.widgets.text("output_volume", "/Volumes/dev_test/dev_domo_migration/md-cd", "Output volume")
dbutils.widgets.text("reference_plan", "", "Reference plan to inspect (blank = repo fixture)")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint")
dbutils.widgets.dropdown("use_mock_llm", "true", ["true", "false"], "Use mock LLM")
dbutils.widgets.dropdown("use_fixtures", "true", ["true", "false"], "Use in-notebook fixtures instead of volumes")

REPO_ROOT = dbutils.widgets.get("repo_root")
ENVIRONMENT = dbutils.widgets.get("environment")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id")
DATAFLOW_NAME = dbutils.widgets.get("dataflow_name")
STD_ROOT = dbutils.widgets.get("standardized_root").strip()
RAW_ROOT = dbutils.widgets.get("raw_root").strip()
OUTPUT_VOLUME = dbutils.widgets.get("output_volume").strip()
REFERENCE_PLAN = dbutils.widgets.get("reference_plan").strip()
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint")
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
USE_FIXTURES = dbutils.widgets.get("use_fixtures") == "true"

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import asyncio
import json

import nest_asyncio
from agents.md_plan.adapters import VolumeJsonPairReader, VolumePlanStore
from agents.md_plan.ports import JsonPairReader, PlanStore
from agents.md_plan.strategies import PlanEvaluator, PlanFeedbackApplier, PlanGenerator
from core.domo.concurrency import ConcurrencyManager
from core.contracts.telemetry import (
    DecisionKind, DecisionRow, IngestionRow, IngestPurpose, StepRow, StepStatus,
)
from core.domo.llm import DatabricksEndpointCaller, LLMClient, RawCompletion
from core.domo.models import EndpointSpec
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.schemas import HumanFeedback
from core.domo.sinks import InMemorySink, RecordingObservability, utc_now

nest_asyncio.apply()
run_async = lambda c: asyncio.get_event_loop().run_until_complete(c)  # noqa: E731
RUN_ID = f"nb-mdplan-{DATAFLOW_ID}"
sink = InMemorySink()
print("agent package imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Inputs — both JSONs

# COMMAND ----------

# The shape the standardizer really writes: keyed by dataflow id, tiles under
# `actions`, edges under `connections`, tile payload under `logic`. Defined in
# core/contracts/standardized.py — fixtures that drift from it hide real breakage.
FIXTURE_STD = {
    DATAFLOW_ID: {
        "id": DATAFLOW_ID,
        "name": DATAFLOW_NAME,
        "inputs": [{"dataSourceId": "src-1", "dataSourceName": "Suppliers FEED"}],
        "outputs": [{"dataSourceId": "out-1", "dataSourceName": "CMS Rec PROD"}],
        "actions": [
            {"id": "s00", "name": "Suppliers FEED", "type": "source",
             "logic": {"datasetName": "Suppliers FEED", "dataSourceId": "src-1"}},
            {"id": "s01", "name": "Join Data 2", "type": "join",
             "logic": {"joinType": "LEFT OUTER",
                       "joinKeys": [{"leftColumn": "Supplier",
                                     "rightColumn": "Company Name"}]}},
            {"id": "s02", "name": "Filter Rows", "type": "filter",
             "logic": {"topLevelCombinator": "AND", "filterGroups": []}},
            {"id": "s03", "name": "Add Formula 1", "type": "formula",
             "logic": {"expressions": [{"outputColumn": "Period End Date",
                                        "expression": "LAST_DAY(`Date`)"}]}},
            {"id": "s04", "name": "CMS Rec PROD", "type": "sink",
             "logic": {"datasetName": "CMS Rec PROD", "versionChainType": "REPLACE"}},
        ],
        "connections": [{"from": "s00", "to": "s01"}, {"from": "s01", "to": "s02"},
                        {"from": "s02", "to": "s03"}, {"from": "s03", "to": "s04"}],
        "disabled_skipped": [],
    }
}
FIXTURE_RAW = FIXTURE_STD          # the original export, same shape


class FixtureReader(JsonPairReader):
    def __init__(self):
        self.std_reads = 0
        self.raw_reads = 0

    def read_standardized(self, dataflow_id):
        self.std_reads += 1
        return FIXTURE_STD

    def read_raw(self, dataflow_id):
        self.raw_reads += 1
        return FIXTURE_RAW


class FixtureStore(PlanStore):
    def __init__(self):
        self.writes = []

    def path_for(self, dataflow_id, iteration):
        return f"(memory)/plan_{dataflow_id}_v{iteration}.md"

    def write(self, dataflow_id, iteration, content):
        p = self.path_for(dataflow_id, iteration)
        self.writes.append((p, content))
        return p


if USE_FIXTURES:
    reader, store = FixtureReader(), FixtureStore()
    print("using in-notebook fixtures (no volume reads)")
else:
    reader = VolumeJsonPairReader(STD_ROOT, RAW_ROOT)
    store = VolumePlanStore(OUTPUT_VOLUME, DATAFLOW_NAME)
    print(f"standardized: {STD_ROOT}/{DATAFLOW_ID}.json")
    print(f"raw         : {RAW_ROOT}/{DATAFLOW_ID}.json")

sink.ingestion(IngestionRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                            dataset_id=DATAFLOW_ID, dataset_name=f"standardized::{DATAFLOW_ID}",
                            purpose=IngestPurpose.CREATION))
sink.ingestion(IngestionRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                            dataset_id=DATAFLOW_ID, dataset_name=f"raw::{DATAFLOW_ID}",
                            purpose=IngestPurpose.CREATION))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Wire the agent

# COMMAND ----------

class FixedRegistry:
    def __init__(self, endpoint):
        self._e = endpoint

    def resolve(self, role, environment):
        return EndpointSpec(endpoint=self._e, params={"temperature": 0})


CAPTURED_PROMPTS = []


def make_caller(mock: bool):
    """Always returns a caller that records prompts on CAPTURED_PROMPTS.

    Cells 4 and 5 assert on prompt LAYERING, which is a property of the assembled
    prompt and has nothing to do with where the completion comes from. Returning None
    for the real endpoint (so LLMClient falls back to its own default caller) left
    those cells reading an empty list, and the layering contract went unchecked in
    exactly the mode where it matters. The real caller is wrapped, not replaced.
    """
    if mock:
        def caller(spec, prompt, response_schema, timeout_s):
            CAPTURED_PROMPTS.append(prompt)
            if '"verdict"' in prompt or "Review this migration plan" in prompt:
                return RawCompletion(
                    text=json.dumps({"verdict": "pass", "confidence": 0.86,
                                     "issues": [], "summary": "mock review"}),
                    tokens_in=2100, tokens_out=70)
            return RawCompletion(
                text=("# Migration plan (STUB OUTPUT)\n\n"
                      "The generator body is TEAMMATE-OWNED; this is placeholder text.\n"),
                tokens_in=5400, tokens_out=320)
        return caller

    real = DatabricksEndpointCaller()

    def capturing(spec, prompt, response_schema, timeout_s):
        CAPTURED_PROMPTS.append(prompt)
        return real(spec, prompt, response_schema, timeout_s)
    return capturing


RATES = {SERVING_ENDPOINT: (0.00015, 0.0006)}
obs = RecordingObservability(sink, run_id=RUN_ID, environment=ENVIRONMENT, rate_card=RATES)
llm = LLMClient(
    registry=FixedRegistry(SERVING_ENDPOINT), assembler=PromptAssembler(),
    checker=HardConstraintChecker(),
    concurrency=ConcurrencyManager({"md_translation": 6, "evaluation": 4}, global_ceiling=12),
    observability=obs, caller=make_caller(USE_MOCK_LLM),
)
generator = PlanGenerator(reader, store, llm)
evaluator = PlanEvaluator(llm, ai_review=True)
applier = PlanFeedbackApplier()


def cfg(iteration: int):
    return {"configurable": {"dataflow_id": DATAFLOW_ID, "environment": ENVIRONMENT,
                             "thread_id": RUN_ID, "obs_run_id": RUN_ID,
                             "iteration": iteration, "observability": obs}}

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Iteration 1 — generate and evaluate

# COMMAND ----------

import time

state = {"dataflow_id": DATAFLOW_ID, "feedback": {}, "prompt_layers": {}}
t0 = time.perf_counter()
v1 = run_async(generator.generate(state, cfg(1)))
ms = int((time.perf_counter() - t0) * 1000)
sink.step(StepRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT, step_id="gen-v1",
                  agent="md_plan", phase="Rendering plan", phase_index=3, phase_count=5,
                  iteration=1, status=StepStatus.OK, duration_ms=ms))

ev1 = run_async(evaluator.evaluate(v1, state, cfg(1)))

print("CONTRACT · reads both JSONs")
print(f"   read_standardized={v1.meta['read_standardized']}  read_raw={v1.meta['read_raw']}")
if USE_FIXTURES:
    print(f"   reader counters  : std={reader.std_reads} raw={reader.raw_reads}")
print(f"   raw nodes seen   : {v1.meta['raw_node_count']}"
      + ("" if v1.meta['raw_merged'] else f"  <-- NOT MERGED: {v1.meta['raw_fold_note']}"))
print(f"   plan shape       : {v1.meta['sources']} source(s) · {v1.meta['steps']} step(s) "
      f"· {v1.meta['targets']} target(s)")
print(f"   coverage         : {v1.meta['coverage_pct']}% deterministic · "
      f"{v1.meta['needed_a_model']} needed a model")
print(f"\nartifact  : {v1.meta['artifact_path']}")
print(f"node_keys : {v1.node_keys}")
print(f"verdict   : {ev1.verdict.value} (confidence {ev1.confidence})")
print(f"elapsed   : {ms} ms")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Human review, then iteration 2

# COMMAND ----------

fb = HumanFeedback(
    accepted_issue_ids=["i-null-guard"],
    rejected_issue_ids=["i-union-order"],
    freeform="Guard the Account Activity fallback with IFNULL; keep the DOMO union order.",
    hard_constraints=["Never rename source columns"],
    ts=utc_now(), actor="adarsh.a",
)
for kind, issue in ((DecisionKind.ISSUE_ACCEPTED, "i-null-guard"),
                    (DecisionKind.ISSUE_REJECTED, "i-union-order")):
    sink.decision(DecisionRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                              dataflow_id=DATAFLOW_ID, agent="md_plan", iteration=1,
                              kind=kind, actor="adarsh.a", issue_id=issue,
                              rationale=fb.freeform))
sink.decision(DecisionRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                          dataflow_id=DATAFLOW_ID, agent="md_plan", iteration=1,
                          kind=DecisionKind.CONSTRAINT_ADDED, actor="adarsh.a",
                          constraint=fb.hard_constraints[0]))

applied = applier.apply(v1, [fb])
def generator_prompt_since(before: int, *, iteration: int):
    """The prompt the generator sent on this round, or None if it sent none.

    The generator only calls a model for steps the transpiler could not resolve, so a
    dataflow that transpiles cleanly produces NO prompt and this contract cannot be
    checked from a run — that is a property of the dataflow, not a failure. Returning
    None and saying so beats an IndexError that reads like a broken agent.
    """
    fresh = CAPTURED_PROMPTS[before:]
    if not fresh:
        print(f"   (no generator prompt on iteration {iteration}: every step transpiled "
              f"deterministically, so no model was asked — layering not exercised here)")
        return None
    return fresh[0]


state2 = {**state, "feedback": {"md_plan": [fb]},
          "md_plan": {"eval": {"issues": [i.model_dump() for i in ev1.issues]}}}

before = len(CAPTURED_PROMPTS)
v2 = run_async(generator.generate(state2, cfg(2)))
sink.step(StepRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT, step_id="gen-v2",
                  agent="md_plan", phase="Rendering plan", phase_index=3, phase_count=5,
                  iteration=2, status=StepStatus.OK))

print("CONTRACT · P1 human feedback outranks the P4 base prompt")
prompt = generator_prompt_since(before, iteration=2)
if prompt:
    p1 = prompt.find("Guard the Account Activity")
    p4 = prompt.find("[P4 TASK")
    print(f"   '[P1 HUMAN FEEDBACK' present : {'[P1 HUMAN FEEDBACK' in prompt}")
    print(f"   feedback at char {p1}, base at char {p4} -> P1 first: {0 <= p1 < p4}")
    print(f"   hard constraint carried      : {'Never rename source columns' in prompt}")

print("\nCONTRACT · versioned per iteration (no overwrite of an approved prior)")
print(f"   v1: {v1.meta['artifact_path']}")
print(f"   v2: {v2.meta['artifact_path']}")
print(f"   distinct paths: {v1.meta['artifact_path'] != v2.meta['artifact_path']}")

print("\nCONTRACT · per-issue apply/keep")
print(f"   applied_issue_ids: {applied.meta['applied_issue_ids']}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Feedback accumulates across rounds

# COMMAND ----------

fb2 = HumanFeedback(freeform="Also pin decimal precision to (18,2) on money columns.",
                    ts=utc_now(), actor="adarsh.a")
before = len(CAPTURED_PROMPTS)
run_async(generator.generate({**state, "feedback": {"md_plan": [fb, fb2]}}, cfg(3)))
print("CONTRACT · earlier feedback survives later rounds")
prompt3 = generator_prompt_since(before, iteration=3)
if prompt3:
    print(f"   round-1 note present: {'Guard the Account Activity' in prompt3}")
    print(f"   round-2 note present: {'pin decimal precision' in prompt3}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. What a finished plan must contain
# MAGIC
# MAGIC The stub cannot produce this, so inspect a real one. These are the sections the
# MAGIC downstream extractor and the client report both depend on.

# COMMAND ----------

def read_text(path):
    if path.startswith("/Volumes/"):
        from databricks.sdk import WorkspaceClient
        return WorkspaceClient().files.download(path).contents.read().decode("utf-8")
    with open(path, encoding="utf-8") as fh:
        return fh.read()


ref_path = REFERENCE_PLAN or f"{REPO_ROOT}/docs/cms_8099.md"
try:
    ref = read_text(ref_path)
    from agents.cd_codegen.md_extract import extract_md_plan

    ex = extract_md_plan(ref, dataflow_id=DATAFLOW_ID)
    print(f"reference plan: {ref_path}\n")
    print(f"  sources documented : {len(ex.sources)}")
    print(f"  steps              : {len(ex.steps)}")
    print(f"  write targets      : {len(ex.writes)}")
    print(f"  coverage line      : {ex.coverage}")
    print(f"  prose-only steps   : {len(ex.llm_steps)}")
    conf = {}
    for s in ex.steps:
        conf[s.confidence] = conf.get(s.confidence, 0) + 1
    print(f"  confidence spread  : {conf}")
    print("\n  a step the extractor can consume looks like:")
    s = ex.steps[0]
    print(f"    step={s.step} name={s.name!r} type={s.node_type} out={s.df_var} conf={s.confidence}")
except Exception as exc:
    print(f"could not read the reference plan ({type(exc).__name__}: {exc})")
    print("set the reference_plan widget to a plan on a volume")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Observability report

# COMMAND ----------

summary = sink.summary(RUN_ID, DATAFLOW_ID)
print("=== RUN SUMMARY ===")
print(json.dumps(summary.model_dump(), indent=2, default=str))
print(f"\nreworked (iterations > agents): {summary.reworked}")

print("\n=== TOKENS BY AGENT ===")
for agent, t in sink.tokens_by_agent().items():
    print(f"  {agent:12s} calls={t['calls']:3d} in={t['in']:,} out={t['out']:,}")

print("\n=== COST BY AGENT ===")
for agent, c in sink.cost_by_agent().items():
    print(f"  {agent:12s} ${c}")

print("\n=== STEPS ===")
for s in sink.steps:
    print(f"  v{s.iteration} {s.agent}.{s.phase:22s} {s.status.value} {s.duration_ms}ms")

print("\n=== HUMAN DECISIONS (the client deviation report) ===")
for d in sink.decisions:
    detail = d.issue_id or d.constraint
    print(f"  {d.kind.value:18s} {detail:20s} by {d.actor}")

print("\n=== DATASETS READ ===")
for name, purpose, rows in sink.datasets_read():
    print(f"  {name:30s} {purpose}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notes
# MAGIC
# MAGIC - Everything above verifies the agent's **contract**. Plan *quality* cannot be
# MAGIC   tested until the generator body is written — that work is `TEAMMATE-OWNED` in
# MAGIC   `agents/md_plan/strategies.py`.
# MAGIC - When it is written, the plan should carry **intent and caveats, not code**:
# MAGIC   expression mappings with confidence and semantic risks, join-key uniqueness
# MAGIC   assumptions, source bindings (external / snapshot / migrated), incremental
# MAGIC   scoping per source, and a risk register for things like hardcoded `_BATCH_ID_`
# MAGIC   patches. That is reviewable in fifteen minutes; 900 lines of SQL is not.
# MAGIC - The contract assertions here become the regression suite for that work.