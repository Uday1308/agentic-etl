# Databricks notebook source
# MAGIC %md
# MAGIC # CD Codegen — SQL path test harness
# MAGIC
# MAGIC Tests the **SQL** generation path only. Nothing here touches the PySpark
# MAGIC generators (`mapping.py`, `assembly.py`, `md_generator.py`) or the IR — those are
# MAGIC covered by `test_cd_codegen.py` and `test_cd_codegen_md.py`.
# MAGIC
# MAGIC What the SQL path is:
# MAGIC
# MAGIC ```
# MAGIC standardized JSON  ─┐
# MAGIC                     ├─▶ folded dataflow ─▶ PlanRenderer(dialect="sql") ─▶ AI tail ─▶ build_sql ─▶ one .sql per target
# MAGIC discovery table    ─┘
# MAGIC ```
# MAGIC
# MAGIC Each artifact is **one CTE per DOMO tile, ending in a plain SELECT**, node-addressable
# MAGIC via `-- [node: <id>]` markers. There is no `CREATE OR REPLACE TABLE` prefix unless you
# MAGIC ask for one: materialization stays a deliberate human decision made once the numbers
# MAGIC are trusted.
# MAGIC
# MAGIC The run ends with `EXPLAIN` on every artifact — that proves the SQL parses, the source
# MAGIC tables resolve and every column reference exists, without scanning a single row.
# MAGIC
# MAGIC **Deterministic first, model only for the real tail.** Cell 2 transpiles everything
# MAGIC `core.domo.tiles` can render in plain Python. Cell 3 then asks the serving endpoint
# MAGIC about *exactly* the steps it could not — one call per step, so a bad answer costs one
# MAGIC CTE and not the artifact. Every CTE a model wrote is marked `origin=ai` in the SQL.
# MAGIC
# MAGIC A step with no Python renderer **and** no usable model answer stays a loudly-marked
# MAGIC passthrough. The model is allowed to say "I cannot translate this" and that answer is
# MAGIC kept as a refusal — a plausible guess would read as a data bug when the numbers are
# MAGIC compared against DOMO row by row.
# MAGIC
# MAGIC Cell 8 reports three provenances (deterministic / model / unresolved) and separates
# MAGIC real blockers — a target that would not assemble, SQL that would not EXPLAIN — from
# MAGIC standing gaps, so one cannot mask the other.

# COMMAND ----------

# MAGIC %pip install --quiet "databricks-sdk>=0.30" nest_asyncio
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-platform", "Repo root")
dbutils.widgets.text("dataflow_id", "8099", "Dataflow id")
dbutils.widgets.text("dataflow_name", "cms", "Dataflow name")
dbutils.widgets.dropdown("input_source", "standardized_json",
                         ["standardized_json", "discovery_table"], "Structural input")
# -- standardized-JSON input
dbutils.widgets.text("standardized_root", "/Volumes/dev_test/dev_domo_migration/standardized",
                     "Standardized JSON root")
# -- discovery-table input
dbutils.widgets.text("discovery_table", "", "Discovery table")
dbutils.widgets.text("discovery_run_id", "", "Discovery run id (blank = latest)")
# -- where the generated SQL is read from and written to
dbutils.widgets.text("source_catalog", "dev_test", "Source catalog")
dbutils.widgets.text("source_schema", "domo_input", "Source schema (raw, as landed)")
dbutils.widgets.dropdown("clean_sources", "true", ["true", "false"],
                         "Read sources through artifact-free views")
dbutils.widgets.text("clean_source_schema", "domo_input_clean",
                     "Schema to hold those views")
dbutils.widgets.text("target_catalog", "dev_test", "Target catalog")
dbutils.widgets.text("target_schema", "migrated_output", "Target schema")
dbutils.widgets.text("output_volume", "/Volumes/dev_test/dev_domo_migration/md-cd", "Output volume")
dbutils.widgets.text("as_of", "", "As-of cutoff (blank = no clamp)")
dbutils.widgets.dropdown("materialize", "false", ["true", "false"], "Emit CREATE OR REPLACE TABLE")
dbutils.widgets.dropdown("run_explain", "true", ["true", "false"], "EXPLAIN each artifact")
# -- the AI tail
dbutils.widgets.dropdown("run_ai_tail", "true", ["true", "false"],
                         "Ask a model about steps Python could not render")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint")
dbutils.widgets.dropdown("use_mock_llm", "false", ["true", "false"],
                         "Use a canned response instead of the endpoint")
dbutils.widgets.dropdown("probe_schema", "true", ["true", "false"],
                         "Ask Spark for the upstream columns before translating")
dbutils.widgets.dropdown("fail_on_passthrough", "true", ["true", "false"],
                         "Fail the run if any tile is left untranslated")

REPO_ROOT = dbutils.widgets.get("repo_root")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id").strip()
DATAFLOW_NAME = dbutils.widgets.get("dataflow_name").strip()
INPUT_SOURCE = dbutils.widgets.get("input_source")
STD_ROOT = dbutils.widgets.get("standardized_root").strip().rstrip("/")
DISCOVERY_TABLE = dbutils.widgets.get("discovery_table").strip()
DISCOVERY_RUN_ID = dbutils.widgets.get("discovery_run_id").strip()
SOURCE_CATALOG = dbutils.widgets.get("source_catalog").strip()
SOURCE_SCHEMA = dbutils.widgets.get("source_schema").strip()
CLEAN_SOURCES = dbutils.widgets.get("clean_sources") == "true"
CLEAN_SCHEMA = dbutils.widgets.get("clean_source_schema").strip()
TARGET_CATALOG = dbutils.widgets.get("target_catalog").strip()
TARGET_SCHEMA = dbutils.widgets.get("target_schema").strip()
OUTPUT_VOLUME = dbutils.widgets.get("output_volume").strip().rstrip("/")
AS_OF = dbutils.widgets.get("as_of").strip()
MATERIALIZE = dbutils.widgets.get("materialize") == "true"
RUN_EXPLAIN = dbutils.widgets.get("run_explain") == "true"
RUN_AI_TAIL = dbutils.widgets.get("run_ai_tail") == "true"
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint").strip()
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
PROBE_SCHEMA = dbutils.widgets.get("probe_schema") == "true"
FAIL_ON_PASSTHROUGH = dbutils.widgets.get("fail_on_passthrough") == "true"

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import io
import json

import asyncio

import nest_asyncio

from agents.cd_codegen.sql_assembly import SqlAssembler
from agents.cd_codegen.sql_generator import (
    generate_sql,
    generate_sql_with_tail,
    probe_query,
)
from agents.cd_codegen.sql_translation import SqlTailTranslator
from agents.md_plan.render import snake
from core.contracts.discovery import normalize_rows, to_dataflow
from core.contracts.landing import artifact_audit_sql, create_clean_views
from core.contracts.standardized import to_planner_dataflow
from core.domo.concurrency import ConcurrencyManager
from core.domo.llm import DatabricksEndpointCaller, LLMClient, RawCompletion
from core.domo.models import EndpointSpec, Role
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.sinks import InMemorySink, RecordingObservability

nest_asyncio.apply()
run_async = lambda c: asyncio.get_event_loop().run_until_complete(c)  # noqa: E731
RUN_ID = f"nb-sql-{DATAFLOW_ID}"

print("SQL path imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Structural input
# MAGIC
# MAGIC Both upstreams fold to the same `{"dataflow_id", "nodes", "edges"}` shape, so the
# MAGIC generator below has one input contract regardless of which you pick. They are
# MAGIC independent derivations of the same dataflow — if the two disagree on node or edge
# MAGIC counts, one of them is wrong and the plan built from it cannot be trusted.

# COMMAND ----------

def load_standardized(dataflow_id: str) -> dict:
    """Read the standardized document and fold it to the planner shape."""
    path = f"{STD_ROOT}/{dataflow_id}.json"
    if path.startswith("/Volumes/"):
        from databricks.sdk import WorkspaceClient
        text = WorkspaceClient().files.download(path).contents.read().decode("utf-8")
    else:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
    print(f"standardized JSON : {path}")
    return to_planner_dataflow(json.loads(text), dataflow_id)


def load_discovery(dataflow_id: str) -> dict:
    """Read the discovery table and fold it to the planner shape.

    Scoped to one dataflow AND one discovery run: the table accumulates runs, and
    reading two together repeats node ids, which surfaces downstream as a bogus graph
    cycle rather than as the ingestion problem it actually is.
    """
    from pyspark.sql import functions as F

    df = spark.table(DISCOVERY_TABLE)  # noqa: F821 (spark is provided by Databricks)
    if "dataflow_id" in df.columns:
        df = df.filter(F.col("dataflow_id").cast("string") == str(dataflow_id))

    run_id = DISCOVERY_RUN_ID
    if not run_id and "discovery_run_id" in df.columns and "discovered_at" in df.columns:
        latest = df.orderBy(F.col("discovered_at").desc()).select("discovery_run_id").first()
        run_id = latest[0] if latest else ""
    if run_id:
        print(f"discovery run     : {run_id}")

    rows = [r.asDict(recursive=True) for r in df.collect()]
    print(f"discovery table   : {DISCOVERY_TABLE}  ({len(rows)} rows for this dataflow)")
    # normalize_rows resolves columns through core.contracts.discovery, which already
    # knows every alias this table uses — no per-notebook column overrides needed.
    return to_dataflow(normalize_rows(rows, dataflow_id=dataflow_id, run_id=run_id),
                       dataflow_id)


if INPUT_SOURCE == "discovery_table":
    if not DISCOVERY_TABLE:
        raise ValueError("input_source=discovery_table but the discovery_table widget is blank")
    dataflow = load_discovery(DATAFLOW_ID)
else:
    dataflow = load_standardized(DATAFLOW_ID)

by_cat: dict[str, int] = {}
for n in dataflow["nodes"]:
    cat = n.get("category") or "TRANSFORMATION"
    by_cat[cat] = by_cat.get(cat, 0) + 1
print(f"\nnodes             : {len(dataflow['nodes'])}  {by_cat}")
print(f"edges             : {len(dataflow['edges'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1b. Artifact-free source views
# MAGIC
# MAGIC DOMO's export writes a leading apostrophe on some values (`'-92866.56`) to force
# MAGIC text interpretation. **DOMO's own output does not carry it** — so a migration that
# MAGIC reads the raw export straight through produces a table that differs from DOMO on
# MAGIC every affected row, silently, until something casts it.
# MAGIC
# MAGIC The cleanup goes in a **view** over the raw table, not into the raw table itself:
# MAGIC bronze stays a faithful record of what DOMO actually sent. The generated SQL never
# MAGIC learns about any of this — it just reads a different schema.

# COMMAND ----------

def source_tables(dataflow: dict) -> list[str]:
    """The physical tables this dataflow reads, from its SOURCE tiles."""
    out = []
    for n in dataflow["nodes"]:
        if (n.get("category") or "").upper() != "SOURCE":
            continue
        p = n.get("properties") or {}
        name = p.get("dataset_name") or p.get("datasetName") or n.get("name") or ""
        if name:
            out.append(snake(name))
    return sorted(set(out))


if CLEAN_SOURCES:
    tables = source_tables(dataflow)
    print(f"source tables: {len(tables)}\n")

    # Audit BEFORE, so the run says how much of the estate this was actually affecting
    # rather than asserting it silently fixed something.
    affected = 0
    for tbl in tables:
        src = f"{SOURCE_CATALOG}.{SOURCE_SCHEMA}.{tbl}"
        try:
            cols = dict(spark.table(src).dtypes)  # noqa: F821
            counts = spark.sql(artifact_audit_sql(src, cols)).first().asDict()  # noqa: F821
            dirty = {c: n for c, n in counts.items() if n}
            if dirty:
                affected += 1
                print(f"  {tbl}")
                for c, n in sorted(dirty.items(), key=lambda kv: -kv[1]):
                    print(f"      {c}: {n} value(s) carry the artifact")
        except Exception as exc:                       # noqa: BLE001
            print(f"  {tbl}: could not audit - {str(exc).splitlines()[0][:90]}")
    print(f"\n{affected}/{len(tables)} source table(s) carry the artifact")

    ddl = create_clean_views(spark, SOURCE_CATALOG, SOURCE_SCHEMA,  # noqa: F821
                             CLEAN_SCHEMA, tables=tables)
    print(f"\ncreated {len(ddl)} view(s) in {SOURCE_CATALOG}.{CLEAN_SCHEMA}")
    SOURCE_SCHEMA = CLEAN_SCHEMA
    print(f"generation will read from: {SOURCE_CATALOG}.{SOURCE_SCHEMA}")
else:
    print(f"reading sources raw from {SOURCE_CATALOG}.{SOURCE_SCHEMA} "
          f"(clean_sources=false) - DOMO export artifacts will reach the output")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Generate the SQL

# COMMAND ----------

import time

t0 = time.perf_counter()
gen = generate_sql(
    dataflow,
    dataflow_id=DATAFLOW_ID,
    dataflow_name=DATAFLOW_NAME,
    source_catalog=SOURCE_CATALOG, source_schema=SOURCE_SCHEMA,
    target_catalog=TARGET_CATALOG, target_schema=TARGET_SCHEMA,
    as_of=AS_OF, materialize=MATERIALIZE,
)
elapsed_ms = int((time.perf_counter() - t0) * 1000)

b = gen.build
print(f"sources           : {len(b.sources)}")
print(f"transformations   : {len(b.steps)}")
print(f"targets           : {len(b.targets)}")
print(f"deterministic     : {b.resolved_count}/{len(b.steps)} ({b.coverage_pct:.1f}%)")
print(f"needs a model     : {gen.needed_a_model or 'none'}")
print(f"artifacts         : {len(gen.succeeded)} generated, {len(gen.failed)} failed")
print(f"elapsed           : {elapsed_ms} ms")

if gen.needed_a_model:
    names = {st.step_id: st for st in b.steps}
    print(f"\nsteps the tile registry could not render:")
    for item in b.unresolved:
        st = names.get(item["step"])
        print(f"  {item['step']}  {item['name']} ({st.node_type if st else '?'})")
        for reason in item["reasons"]:
            print(f"        reason: {reason}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. The AI tail
# MAGIC
# MAGIC One call per unresolved step, fanned out over the `cd_translation` pool. The model
# MAGIC is given four things, and it needs all four:
# MAGIC
# MAGIC 1. the tile configuration;
# MAGIC 2. **what the tile means** — DOMO's config keys mislead. `keyField`/`valueField` on
# MAGIC    a dynamic unpivot read as input columns; they are the names of columns the tile
# MAGIC    *creates*. Given only the JSON, a model writes the exact inverse of the tile;
# MAGIC 3. **the real upstream columns**, probed from Spark. A dynamic unpivot escalates
# MAGIC    precisely because its column set is decided at run time — the configuration
# MAGIC    cannot reveal it, and a model without it can only invent column names;
# MAGIC 4. the reason the transpiler declined.
# MAGIC
# MAGIC If the schema cannot be probed the model is told to answer `-- CANNOT TRANSLATE`
# MAGIC rather than guess. Anything that is not a single bare `SELECT` is rejected before it
# MAGIC can reach the artifact, and every rejection reports its reason.

# COMMAND ----------

sink = InMemorySink()
obs = RecordingObservability(sink, run_id=RUN_ID, environment="dev",
                             rate_card={SERVING_ENDPOINT: (0.00015, 0.0006)})


class FixedRegistry:
    """One endpoint for every role — this notebook only uses the generator role."""

    def __init__(self, endpoint):
        self._e = endpoint

    def resolve(self, role, environment):
        return EndpointSpec(endpoint=self._e, params={"temperature": 0})


MOCK_SQL = """```sql
SELECT * FROM {upstream}
-- MOCK RESPONSE - not a real translation
```"""


def make_caller(mock: bool):
    """Always records the prompt, so the layering is inspectable in either mode."""
    real = None if mock else DatabricksEndpointCaller()

    def caller(spec, prompt, response_schema, timeout_s):
        CAPTURED_PROMPTS.append(prompt)
        if mock:
            up = "df_unknown"
            for line in prompt.splitlines():
                if line.startswith("Input CTEs:"):
                    up = line.split(":", 1)[1].strip().split(",")[0].strip() or up
            return RawCompletion(text=MOCK_SQL.format(upstream=up),
                                 tokens_in=900, tokens_out=40)
        return real(spec, prompt, response_schema, timeout_s)

    return caller


CAPTURED_PROMPTS = []

if RUN_AI_TAIL and gen.needed_a_model:
    llm = LLMClient(
        registry=FixedRegistry(SERVING_ENDPOINT), assembler=PromptAssembler(),
        checker=HardConstraintChecker(),
        concurrency=ConcurrencyManager({"cd_translation": 4}, global_ceiling=8),
        observability=obs, caller=make_caller(USE_MOCK_LLM),
    )
    def make_schema_probe():
        """Ask Spark what an upstream CTE actually produces.

        This is the whole ballgame for a tile like the dynamic unpivot: it escalates
        precisely BECAUSE the column set is decided at run time, so no amount of prompt
        wording can make the configuration reveal it. Spark knows. `probe_query`
        assembles the chain up to that CTE and `.limit(0)` resolves the schema without
        scanning anything.
        """
        cache = {}

        def probe(cte_name):
            if cte_name in cache:
                return cache[cte_name]
            cols = None
            try:
                sql = probe_query(gen.build, DATAFLOW_ID, dataflow["nodes"], cte_name,
                                  as_of=AS_OF)
                cols = spark.sql(sql).limit(0).columns  # noqa: F821
            except Exception as exc:                    # noqa: BLE001
                print(f"    (schema probe failed for {cte_name}: "
                      f"{str(exc).splitlines()[0][:120]})")
            cache[cte_name] = cols
            return cols

        return probe

    probe = make_schema_probe() if PROBE_SCHEMA else None
    if probe:
        for item in gen.build.unresolved:
            for cte in item["inputs"]:
                cols = probe(cte)
                print(f"    schema of {cte}: "
                      + (f"{len(cols)} columns" if cols else "UNKNOWN"))
    translator = SqlTailTranslator(llm, schema_probe=probe)
    config = {"configurable": {"dataflow_id": DATAFLOW_ID, "environment": "dev",
                               "thread_id": RUN_ID, "obs_run_id": RUN_ID,
                               "agent": "cd_codegen", "node": "sql_tail", "iteration": 1}}
    t0 = time.perf_counter()
    gen = run_async(generate_sql_with_tail(
        dataflow, translator=translator, config=config,
        dataflow_id=DATAFLOW_ID, dataflow_name=DATAFLOW_NAME,
        source_catalog=SOURCE_CATALOG, source_schema=SOURCE_SCHEMA,
        target_catalog=TARGET_CATALOG, target_schema=TARGET_SCHEMA,
        as_of=AS_OF, materialize=MATERIALIZE,
    ))
    tail_ms = int((time.perf_counter() - t0) * 1000)

    print(f"endpoint          : {SERVING_ENDPOINT}{' (MOCKED)' if USE_MOCK_LLM else ''}")
    print(f"calls made        : {len(sink.llm_calls)}")
    print(f"tokens in/out     : {sum(c.tokens_in for c in sink.llm_calls)}"
          f" / {sum(c.tokens_out for c in sink.llm_calls)}")
    print(f"cost              : ${sum(c.cost_usd for c in sink.llm_calls):.4f}")
    print(f"elapsed           : {tail_ms} ms")
    print(f"\ncoverage          : {gen.coverage}")

    for sid in gen.needed_a_model:
        body = gen.ai_resolved.get(sid)
        if body:
            print(f"\n--- {sid}  TRANSLATED BY MODEL (origin=ai, unreviewed) ---")
            print("\n".join(f"    {ln}" for ln in body.splitlines()[:25]))
        else:
            # Say WHY. A rejected answer looks exactly like no answer in the coverage
            # line, and the difference decides whether you fix the prompt or the tile.
            print(f"\n--- {sid}  NOT TRANSLATED — stays a passthrough ---")
            print(f"    reason: {gen.why_not(sid)}")
            raw = getattr(gen.tail_results.get(sid), "raw", "")
            if raw:
                print(f"    the model actually said ({len(raw)} chars):")
                for ln in raw.splitlines()[:20]:
                    print(f"      | {ln}")

elif not gen.needed_a_model:
    print("every step transpiled deterministically — no model needed")
else:
    print("AI tail skipped (run_ai_tail=false); unresolved steps stay passthroughs")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Per-target detail

# COMMAND ----------

for a in gen.artifacts:
    if not a.sql:
        print(f"FAILED  {a.target}\n        {a.error}\n")
        continue
    ctes = a.sql.count("-- [node:")
    print(f"OK      {a.target}")
    print(f"        table      : {a.table}")
    print(f"        final CTE  : {a.final_cte}")
    print(f"        CTEs       : {ctes}   node keys: {len(a.node_keys)}")
    print(f"        chars      : {len(a.sql)}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. A look at one artifact

# COMMAND ----------

if gen.succeeded:
    head = gen.succeeded[0]
    print(f"===== {head.target} =====\n")
    print("\n".join(head.sql.splitlines()[:60]))
    print(f"\n... ({len(head.sql.splitlines())} lines total)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Write the artifacts to the volume
# MAGIC
# MAGIC `etl_<id>__<target>.sql` is the runnable artifact. `debug_<id>__<target>.sql` reports
# MAGIC a per-CTE row count — that is what tells you which step drops the rows when a result
# MAGIC comes back empty.

# COMMAND ----------

def write_text(path: str, content: str) -> str:
    if path.startswith("/Volumes/"):
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient()
        try:
            w.files.create_directory(path.rsplit("/", 1)[0])
        except Exception:
            pass
        w.files.upload(path, io.BytesIO(content.encode("utf-8")), overwrite=True)
        return path
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return path


out_dir = f"{OUTPUT_VOLUME}/{DATAFLOW_NAME or DATAFLOW_ID}/sql"
written = [write_text(f"{out_dir}/plan_{DATAFLOW_ID}.md", gen.plan_document)]

assembler = SqlAssembler()
for a in gen.succeeded:
    stem = snake(a.target)[:60]
    written.append(write_text(f"{out_dir}/etl_{DATAFLOW_ID}__{stem}.sql", a.sql))
    written.append(write_text(f"{out_dir}/debug_{DATAFLOW_ID}__{stem}.sql",
                              assembler.debug_sql(a)))

print(f"wrote {len(written)} file(s) to {out_dir}")
for p in written:
    print(f"  {p}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. EXPLAIN every artifact
# MAGIC
# MAGIC Catches syntax errors, missing source tables and unresolved column names without
# MAGIC scanning data or writing anything. EXPLAIN always runs against the **non-materialized**
# MAGIC form, so it never depends on the `materialize` widget and never implies DDL.
# MAGIC
# MAGIC This is the only automated check the model-written CTEs get. It proves they parse and
# MAGIC that every column they name exists — it cannot tell you they compute the right thing.
# MAGIC That is what the parity comparison against DOMO is for.

# COMMAND ----------

explain_results = []

if RUN_EXPLAIN:
    # regenerate as plain SELECTs; pure CPU, no reads
    # ai_resolved is carried over: without it this would re-render the passthroughs and
    # EXPLAIN would pass while never once looking at the SQL a model actually wrote.
    plain = generate_sql(
        dataflow, dataflow_id=DATAFLOW_ID, dataflow_name=DATAFLOW_NAME,
        ai_resolved=gen.ai_resolved,
        source_catalog=SOURCE_CATALOG, source_schema=SOURCE_SCHEMA,
        target_catalog=TARGET_CATALOG, target_schema=TARGET_SCHEMA,
        as_of=AS_OF, materialize=False,
    )
    assert plain.ai_steps == gen.ai_steps, "EXPLAIN would not have checked the AI CTEs"
    for a in plain.succeeded:
        try:
            spark.sql("EXPLAIN\n" + a.sql)  # noqa: F821
            explain_results.append((a.target, "PASS", ""))
        except Exception as exc:                      # noqa: BLE001 - report every failure
            first = str(exc).strip().splitlines()[0] if str(exc).strip() else repr(exc)
            explain_results.append((a.target, "FAIL", first[:200]))

    width = max((len(t) for t, _, _ in explain_results), default=10)
    for target, status, detail in explain_results:
        print(f"{status:4}  {target:<{width}}  {detail}")
    failures = [r for r in explain_results if r[1] == "FAIL"]
    print(f"\n{len(explain_results) - len(failures)}/{len(explain_results)} artifacts explained cleanly")
else:
    print("EXPLAIN skipped (run_explain=false)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Verdict
# MAGIC
# MAGIC Fails the run on anything that would make a downstream comparison against DOMO
# MAGIC meaningless: a target that did not assemble, a tile left as a passthrough, or SQL
# MAGIC that does not survive EXPLAIN.

# COMMAND ----------

# Blockers mean the SQL path itself is broken. A passthrough means the path worked and
# a tile has no SQL translation yet — a known gap, not a regression. Reported separately
# so a standing gap (8099's dynamic unpivot) cannot mask a real break.
blockers = []
if gen.failed:
    blockers.append(f"{len(gen.failed)} target(s) failed to assemble: "
                    f"{[a.target for a in gen.failed]}")
explain_failures = [t for t, st, _ in explain_results if st == "FAIL"]
if explain_failures:
    blockers.append(f"{len(explain_failures)} artifact(s) failed EXPLAIN: {explain_failures}")

names = {st.step_id: f"{st.name} ({st.node_type})" for st in b.steps}
print(f"coverage: {gen.coverage}\n")

if gen.ai_steps:
    print(f"?? {len(gen.ai_steps)} step(s) written by a model — real SQL, reviewed by nobody:")
    for sid in gen.ai_steps:
        print(f"     {sid}  {names.get(sid, '?')}")
    print("   EXPLAIN proves they parse. Only the parity comparison proves they are right.\n")

if gen.escalated_steps:
    print(f"!! {len(gen.escalated_steps)} UNTRANSLATED PASSTHROUGH(S) — the SQL runs but "
          f"these steps do nothing:")
    for sid in gen.escalated_steps:
        print(f"     {sid}  {names.get(sid, '?')}")
    print("   Any comparison against DOMO through these steps is meaningless until they "
          "are translated.\n")

if blockers:
    print("BROKEN\n")
    for msg in blockers:
        print(f"  - {msg}")
    raise AssertionError("; ".join(blockers))

if gen.escalated_steps and FAIL_ON_PASSTHROUGH:
    raise AssertionError(
        f"SQL path is sound ({len(gen.succeeded)} artifacts, all explained) but "
        f"{len(gen.escalated_steps)} step(s) are untranslated passthroughs: "
        f"{gen.escalated_steps}. Set fail_on_passthrough=false to proceed knowingly.")

if gen.escalated_steps:
    verdict = "READY (with known passthroughs)"
elif gen.ai_steps:
    verdict = "READY (model-written steps need review)"
else:
    verdict = "READY"
print(f"{verdict} · {len(gen.succeeded)} artifact(s) · {gen.coverage}"
      + (" · all explained cleanly" if RUN_EXPLAIN else " · EXPLAIN skipped"))
print(f"\nNext: run the etl_*.sql in {out_dir}, then compare against DOMO.")