# Databricks notebook source
# MAGIC %md
# MAGIC # Agent test · Validation (6)
# MAGIC
# MAGIC Runs the **Validation agent alone**. Two modes:
# MAGIC
# MAGIC * **parity only** (default) — skips the Job and compares two tables that already
# MAGIC   exist. This is the part that is fully implemented and worth testing properly.
# MAGIC * **full** — submits the generated notebook as a Databricks Job, blocks until it
# MAGIC   finishes, then compares. Needs a real cluster and a real generated artifact.
# MAGIC
# MAGIC What it checks per target: schema, row count, an order-independent checksum, and
# MAGIC per-column null/distinct/sum. **Row count alone is never a pass** — equal counts
# MAGIC with wrong values is the failure that matters in a reconciliation pipeline.
# MAGIC
# MAGIC Only the diagnosis step calls a model, and only when parity fails.

# COMMAND ----------

# MAGIC %pip install --quiet "langgraph>=0.2" "langchain-core>=0.3" "databricks-sdk>=0.30" nest_asyncio
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-platform", "Repo root")
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("dataflow_id", "8099", "Dataflow id")
dbutils.widgets.dropdown("mode", "parity_only", ["parity_only", "full"], "Mode")
dbutils.widgets.text("targets_json", "", "Targets (JSON list) — blank uses the example below")
dbutils.widgets.text("artifact_path", "", "Generated notebook path (mode=full)")
dbutils.widgets.text("results_table", "dev_test.dev_domo_migration.validation_results", "Results table")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint")
dbutils.widgets.dropdown("use_mock_llm", "true", ["true", "false"], "Use mock LLM")
dbutils.widgets.dropdown("ai_troubleshoot", "true", ["true", "false"], "Diagnose failures with AI")
dbutils.widgets.text("decimal_scale", "2", "Decimal scale for normalization")

REPO_ROOT = dbutils.widgets.get("repo_root")
ENVIRONMENT = dbutils.widgets.get("environment")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id")
MODE = dbutils.widgets.get("mode")
TARGETS_JSON = dbutils.widgets.get("targets_json").strip()
ARTIFACT_PATH = dbutils.widgets.get("artifact_path").strip()
RESULTS_TABLE = dbutils.widgets.get("results_table").strip()
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint")
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
AI_TROUBLESHOOT = dbutils.widgets.get("ai_troubleshoot") == "true"
DECIMAL_SCALE = int(dbutils.widgets.get("decimal_scale"))

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import asyncio
import json

import nest_asyncio
from agents.validation.adapters import DatabricksJobRunner, DeltaResultStore, SparkTableReader
from agents.validation.ports import JobRunner, ResultStore
from agents.validation.strategies import ParityChecker, ValidationRunner
from core.domo.concurrency import ConcurrencyManager
from core.contracts.telemetry import IngestionRow, IngestPurpose, StepRow, StepStatus
from core.contracts.validation import BatchRef, Metric
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.sinks import InMemorySink, RecordingObservability, utc_now

nest_asyncio.apply()
run_async = lambda c: asyncio.get_event_loop().run_until_complete(c)  # noqa: E731
RUN_ID = f"nb-val-{DATAFLOW_ID}"
sink = InMemorySink()
print("agent package imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Declare the targets
# MAGIC
# MAGIC One entry per migrated output table. `expected_table` is DOMO's own output
# MAGIC ingested into Databricks; `actual_table` is what the migration produced.
# MAGIC
# MAGIC **Both sides must be captured at the same DOMO batch state.** If DOMO re-ran
# MAGIC between the two captures you will get parity failures that look exactly like
# MAGIC translation bugs. `expected_batch_id` / `expected_batch_last_run` record which
# MAGIC state was used so the result can be defended later.

# COMMAND ----------

EXAMPLE_TARGETS = [
    {
        "target": "NA | F&A | CMS Post Close Reconciliation Summary Data | PROD",
        "expected_table": "dev_test.domo_expected.na_f_a_cms_post_close_summary",
        "actual_table": "dev_test.migrated_output.na_f_a_cms_post_close_summary",
        "expected_batch_id": None,
        "expected_batch_last_run": None,
    },
]

targets_cfg = json.loads(TARGETS_JSON) if TARGETS_JSON else EXAMPLE_TARGETS

targets = []
for t in targets_cfg:
    targets.append({
        "target": t["target"],
        "expected_table": t["expected_table"],
        "actual_table": t["actual_table"],
        "expected_ref": BatchRef(
            dataset_id=t.get("dataset_id", t["target"]),
            batch_id=t.get("expected_batch_id"),
            batch_last_run=t.get("expected_batch_last_run"),
            row_count=t.get("domo_row_count"),
        ),
    })

for t in targets:
    print(f"  {t['target']}")
    print(f"     expected: {t['expected_table']}")
    print(f"     actual  : {t['actual_table']}")

# quick existence check so a typo fails here rather than mid-comparison
for t in targets:
    for side in ("expected_table", "actual_table"):
        try:
            spark.table(t[side]).schema
        except Exception as exc:
            print(f"  !! cannot read {t[side]}: {type(exc).__name__}: {exc}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Wire the agent

# COMMAND ----------

class FixedRegistry:
    def __init__(self, endpoint: str):
        self._e = endpoint

    def resolve(self, role, environment) -> EndpointSpec:
        return EndpointSpec(endpoint=self._e, params={"temperature": 0})


class NoJob(JobRunner):
    """parity_only mode: the migrated tables already exist, so skip execution."""

    def submit(self, dataflow_id, iteration, artifact_path):
        return f"skipped:{dataflow_id}:{iteration}"

    def wait(self, handle, *, timeout_s=3600):
        return {"state": "SUCCESS", "life_cycle": "SKIPPED", "handle": handle}


class PrintStore(ResultStore):
    """parity_only mode: report rather than persist."""

    def __init__(self):
        self.reports = {}

    def write(self, dataflow_id, iteration, report):
        self.reports[(dataflow_id, iteration)] = report
        return f"(not persisted) {dataflow_id}/{iteration}"


def mock_caller(spec, prompt, response_schema, timeout_s):
    return RawCompletion(
        text="Category: expression. The Paying Company filter drops rows DOMO retains.",
        tokens_in=1400, tokens_out=90)


RATES = {SERVING_ENDPOINT: (0.00015, 0.0006)}
obs = RecordingObservability(sink, run_id=RUN_ID, environment=ENVIRONMENT, rate_card=RATES)
llm = LLMClient(
    registry=FixedRegistry(SERVING_ENDPOINT), assembler=PromptAssembler(),
    checker=HardConstraintChecker(),
    concurrency=ConcurrencyManager({"evaluation": 4}, global_ceiling=8),
    observability=obs, caller=(mock_caller if USE_MOCK_LLM else None),
)

reader = SparkTableReader(spark, decimal_scale=DECIMAL_SCALE)
checker = ParityChecker(reader)

if MODE == "full":
    jobs = DatabricksJobRunner()
    store = DeltaResultStore(spark, RESULTS_TABLE)
    print(f"mode=full · will submit {ARTIFACT_PATH} and block until it finishes")
else:
    jobs = NoJob()
    store = PrintStore()
    print("mode=parity_only · comparing existing tables, no Job submitted")

runner = ValidationRunner(jobs, checker, store, llm, ai_troubleshoot=AI_TROUBLESHOOT)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Run

# COMMAND ----------

import time

state = {
    "dataflow_id": DATAFLOW_ID,
    "dataflow_name": f"dataflow_{DATAFLOW_ID}",
    "targets": targets,
    "cd_codegen": {"gen": {"meta": {"artifact_path": ARTIFACT_PATH}}},
}
config = {"configurable": {"dataflow_id": DATAFLOW_ID, "environment": ENVIRONMENT,
                           "thread_id": RUN_ID, "obs_run_id": RUN_ID, "iteration": 1,
                           "observability": obs}}

t0 = time.perf_counter()
report = run_async(runner.run(state, config))
elapsed_ms = int((time.perf_counter() - t0) * 1000)

sink.step(StepRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                  step_id="validate", agent="validation", phase="Running row parity",
                  phase_index=2, phase_count=5, status=StepStatus.OK, duration_ms=elapsed_ms))
sink.parity(report.parity, run_id=RUN_ID, environment=ENVIRONMENT,
            diagnoses=report.diagnoses)
for t in report.parity.targets:
    if t.expected_ref:
        sink.ingestion(IngestionRow(
            run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
            dataset_id=t.expected_ref.dataset_id, dataset_name=t.target,
            purpose=IngestPurpose.VALIDATION, target_table=t.table,
            rows_ingested=t.expected_ref.row_count or 0,
            batch_id=t.expected_ref.batch_id,
            batch_last_run=t.expected_ref.batch_last_run))

print(f"elapsed: {elapsed_ms} ms")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Parity result, check by check

# COMMAND ----------

for t in report.parity.targets:
    head = f"{t.target}"
    print("=" * 78)
    print(head)
    print(f"  table   : {t.table}")
    if t.error:
        print(f"  ERROR   : {t.error}")
        continue
    verdict = "EXACT" if t.exact else ("PASSED (advisory drift)" if t.passed else "FAILED")
    print(f"  verdict : {verdict}   ({len(t.ran)} checks ran, "
          f"{t.check_pass_rate:.0%} passed)")
    if t.expected_ref and t.expected_ref.batch_id is not None:
        print(f"  batch   : id={t.expected_ref.batch_id} run={t.expected_ref.batch_last_run}")
    for c in t.checks:
        if c.status.value == "skipped":
            continue
        mark = "ok  " if not c.failed else ("FAIL" if c.blocks else "warn")
        col = f"/{c.column}" if c.column else ""
        line = f"    [{mark}] {c.metric.value}{col}"
        if c.failed:
            line += f"   expected={c.expected!r}  actual={c.actual!r}"
            if c.delta is not None:
                line += f"  delta={c.delta}"
        print(line)

print("=" * 78)
print("DATAFLOW:", "PASSED" if report.parity.passed else "FAILED",
      f"· {report.parity.targets_exact}/{len(report.parity.targets)} targets exact",
      f"· check pass rate {report.parity.check_pass_rate:.1%}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Diagnosis (only produced when parity fails)

# COMMAND ----------

if report.diagnoses:
    for d in report.diagnoses:
        print(f"category   : {d.category.value}")
        print(f"owner      : {d.owner_agent or '(needs triage)'}")
        print(f"nodes      : {', '.join(d.nodes) or '-'}")
        print(f"explanation: {d.explanation}")
        print(f"confidence : {d.confidence}")
        print("-" * 60)
    print("The CATEGORY is what the graph routes on — expression bugs go back to")
    print("md_plan, assembly bugs to cd_codegen, ingestion mismatches upstream of both.")
else:
    print("no diagnoses (parity passed, or troubleshooting disabled)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Observability report

# COMMAND ----------

summary = sink.summary(RUN_ID, DATAFLOW_ID)
print("=== RUN SUMMARY ===")
print(json.dumps(summary.model_dump(), indent=2, default=str))

print("\n=== VALIDATION ROWS (as written to Delta) ===")
for v in sink.validations:
    print(f"  {v.target[:44]:44s} exact={v.exact} passed={v.passed} "
          f"checks={v.checks_passed}/{v.checks_run} cat={v.failure_category or '-'}")

print("\n=== TOKENS / COST ===")
for agent, t in sink.tokens_by_agent().items():
    print(f"  {agent:12s} calls={t['calls']} in={t['in']:,} out={t['out']:,}")
for agent, c in sink.cost_by_agent().items():
    print(f"  {agent:12s} ${c}")
if not sink.llm_calls:
    print("  no model calls (parity passed, so nothing needed diagnosis)")

print("\n=== DATASETS READ ===")
for name, purpose, rows in sink.datasets_read():
    print(f"  {name[:44]:44s} {purpose:11s} {rows:,} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notes
# MAGIC
# MAGIC - **Capture both sides at the same batch state.** Ingest DOMO's inputs and its
# MAGIC   expected output together, pin the batch id, and never re-fetch per validation
# MAGIC   run. Otherwise DOMO drift shows up as a translation bug.
# MAGIC - **The checksum is a multiset hash**, not a row-by-row join: these feeds have no
# MAGIC   primary keys (`C`, `C2`..`C8`, `column_59`), so rows cannot be paired. Values are
# MAGIC   trimmed and rounded to `decimal_scale` first, or the `DecimalType(10,0)`
# MAGIC   truncation issue floods the diff.
# MAGIC - **Float `sum` drift is advisory**, not blocking — accumulation order differs
# MAGIC   legitimately between engines. A `distinct_count` mismatch is never advisory.
# MAGIC - `mode=full` submits a real Job and blocks. Submission is guarded by
# MAGIC   `(dataflow_id, iteration)`, so re-running the cell will not double-run the
# MAGIC   pipeline.