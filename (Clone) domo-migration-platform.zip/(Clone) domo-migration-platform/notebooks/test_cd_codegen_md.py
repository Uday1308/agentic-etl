# Databricks notebook source
# MAGIC %md
# MAGIC # CD Codegen agent — MD-plan path test harness
# MAGIC
# MAGIC Runs the `cd_codegen` agent in **`source="md"`** mode: instead of transpiling
# MAGIC from the discovery table, it **extracts the already-translated PySpark from the
# MAGIC approved MD plan**, and only falls back to the LLM for prose-only steps.
# MAGIC
# MAGIC 1. loads an MD plan (a real `.md` path you provide, or a built-in sample),
# MAGIC 2. extracts per-step code + write blocks, flags any prose-only step for the LLM,
# MAGIC 3. assembles a node-addressable artifact and writes it to a Unity Catalog Volume.
# MAGIC
# MAGIC For a fully-resolved plan (e.g. `cms_8099`) this makes **zero** model calls.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Install runtime deps and restart Python

# COMMAND ----------

# MAGIC %pip install --quiet "langgraph>=0.2" "langgraph-checkpoint>=2.0" "langchain-core>=0.3" nest_asyncio "databricks-sdk>=0.30"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Parameters (widgets)

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-core", "Repo root")
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("dataflow_id", "8099", "Dataflow id")
dbutils.widgets.text("dataflow_name", "cms_8099", "Dataflow name")
dbutils.widgets.text("output_volume", "/Volumes/dev_test/dev_domo_migration/md-cd", "Output volume root")
dbutils.widgets.text("source_catalog", "dev_test", "Source catalog (for source reads)")
dbutils.widgets.text("source_schema", "domo_bronze", "Source schema (for source reads)")
dbutils.widgets.text("md_plan_path", "", "MD plan path (blank = built-in sample)")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint (prose-only steps)")
dbutils.widgets.dropdown("use_mock_llm", "true", ["true", "false"], "Use mock LLM")
dbutils.widgets.dropdown("enable_hitl", "false", ["true", "false"], "Enable human-in-the-loop")
dbutils.widgets.text("chunk_size", "1", "Translation chunk size (prose steps)")
dbutils.widgets.text("max_iters", "3", "Max regenerate iterations")

REPO_ROOT = dbutils.widgets.get("repo_root")
ENVIRONMENT = dbutils.widgets.get("environment")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id")
DATAFLOW_NAME = dbutils.widgets.get("dataflow_name")
OUTPUT_VOLUME = dbutils.widgets.get("output_volume")
SOURCE_CATALOG = dbutils.widgets.get("source_catalog").strip()
SOURCE_SCHEMA = dbutils.widgets.get("source_schema").strip()
MD_PLAN_PATH = dbutils.widgets.get("md_plan_path").strip()
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint")
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
ENABLE_HITL = dbutils.widgets.get("enable_hitl") == "true"
CHUNK_SIZE = int(dbutils.widgets.get("chunk_size"))
MAX_ITERS = int(dbutils.widgets.get("max_iters"))

print(f"repo_root     = {REPO_ROOT}")
print(f"dataflow      = {DATAFLOW_NAME} (id={DATAFLOW_ID}) env={ENVIRONMENT}")
print(f"output volume = {OUTPUT_VOLUME}")
print(f"md plan       = {'built-in sample' if not MD_PLAN_PATH else MD_PLAN_PATH}")
print(f"llm (fallback)= {'MOCK' if USE_MOCK_LLM else SERVING_ENDPOINT}")
print(f"hitl          = {ENABLE_HITL}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Put the agent package on the path

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from agents.cd_codegen.graph import build_cd_codegen_graph
from agents.cd_codegen.md_extract import extract_md_plan
from agents.cd_codegen.ports import ArtifactStore
from core.domo.concurrency import ConcurrencyManager
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec
from core.domo.observability import LlmCallRow, NodeRow, ObservabilityWriter
from core.domo.prompts import HardConstraintChecker, PromptAssembler

print("agent package imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Load the MD plan
# MAGIC
# MAGIC Leave `md_plan_path` blank to use the built-in sample; point it at a real `.md`
# MAGIC on a Volume to test your own plan (e.g. the `cms_8099` plan). The plan text is
# MAGIC injected on `state["md_plan"]` — the same "approved plan" path the master graph uses.

# COMMAND ----------

SAMPLE_PLAN = """\
# ETL Migration: demo — DataFlow 42

## 5. Step-by-Step PySpark Instructions

### Step s01 | `Join Data 2` | `JOIN`
- **In:** `a_df`, `b_df` | **Out:** `df_join_data_2_s01` | **Confidence:** `HIGH`

```python
df_join_data_2_s01 = a_df.join(b_df, on='k', how='left')
```

### Step s02 | `Add Formula 1` | `FORMULA`
- **In:** `df_join_data_2_s01` | **Out:** `df_add_formula_1_s02` | **Confidence:** `HIGH`

```python
df_add_formula_1_s02 = df_join_data_2_s01.withColumn('Period End Date', F.last_day(F.col('Date')))
```

## 6. Output / Write Instructions

- **Target:** `NA | F&A | Demo Out | PROD` | mode=`overwrite`

```python
(
    df_add_formula_1_s02
    .write.format('delta').mode('overwrite')
    .saveAsTable('dev_test.migrated_output.na_f_a_demo_out_prod')
)
```

## 9. Python vs. LLM Coverage Report

**2/2 transformations Python-resolved (100.0%)**
"""


def read_text(path: str) -> str:
    """Read text from a Volume/workspace path. For `/Volumes/...` use the Files API
    (the real UC path); otherwise fall back to open()."""
    if path.startswith("/Volumes/"):
        try:
            from databricks.sdk import WorkspaceClient
            return WorkspaceClient().files.download(path).contents.read().decode("utf-8")
        except Exception as e:
            raise FileNotFoundError(
                f"Could not read {path!r} via the Files API ({e}). Check the path "
                f"(note 'md-cd' vs 'md_cd' and the filename), or blank `md_plan_path` "
                f"to use the built-in sample."
            ) from e
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


plan_text = read_text(MD_PLAN_PATH) if MD_PLAN_PATH else SAMPLE_PLAN

# Quick pre-flight: parse the plan and show what the extractor sees BEFORE running the agent.
_ex = extract_md_plan(plan_text, dataflow_id=DATAFLOW_ID)
print(f"steps           : {len(_ex.steps)}")
print(f"writes          : {len(_ex.writes)}")
print(f"coverage        : {_ex.coverage}")
prose_only = [s.step for s in _ex.llm_steps]
print(f"sources         : {len(_ex.sources)} (read from {SOURCE_CATALOG or '<unset>'}.{SOURCE_SCHEMA or '<unset>'}.<snake(name)>)")
print(f"prose-only (LLM): {len(prose_only)} {prose_only if prose_only else ''}")
if prose_only and USE_MOCK_LLM:
    print("  NOTE: this plan has prose-only steps that need the LLM; the mock will fill them "
          "with placeholders. Set use_mock_llm=false for real translations.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Wire the core services
# MAGIC
# MAGIC Same pattern as the discovery-path notebook: a schema-independent registry, a
# MAGIC Volume-aware store (writes via `dbutils.fs`, not `os.makedirs`), and an
# MAGIC in-memory observability sink.

# COMMAND ----------

class FixedRegistry:
    """Every role -> the one configured endpoint (avoids coupling to the real
    ModelRegistry binding schema). LLMClient only needs `.resolve(...)`."""

    def __init__(self, endpoint: str):
        self._endpoint = endpoint

    def resolve(self, role, environment) -> EndpointSpec:
        return EndpointSpec(endpoint=self._endpoint)


class NotebookVolumeStore(ArtifactStore):
    """Writes to a UC Volume via the Databricks SDK **Files API**, which targets the
    real `/Volumes/...` path unambiguously. (dbutils.fs treats a scheme-less path as
    DBFS, so `/Volumes/...` would land in `dbfs:/Volumes/...`, not the Volume; and
    os.makedirs on the FUSE mount raises Errno 95.)"""

    def __init__(self, volume_root: str, dataflow_name: str) -> None:
        self._root = volume_root.rstrip("/")
        self._name = dataflow_name
        from databricks.sdk import WorkspaceClient
        self._w = WorkspaceClient()

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return f"{self._root}/{self._name}/cd/etl_{dataflow_id}_v{iteration}.py"

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        import io
        path = self.path_for(dataflow_id, iteration)
        try:
            self._w.files.create_directory(path.rsplit("/", 1)[0])   # mkdir -p, idempotent
        except Exception:
            pass
        self._w.files.upload(path, io.BytesIO(content.encode("utf-8")), overwrite=True)
        return path


class NotebookObservability(ObservabilityWriter):
    def __init__(self):
        self.llm_calls: list[LlmCallRow] = []
        self.node_rows: list[NodeRow] = []

    def record_llm_call(self, row: LlmCallRow) -> None:
        self.llm_calls.append(row)

    def record_node(self, row: NodeRow) -> None:
        self.node_rows.append(row)


def mock_caller(spec, prompt, response_schema, timeout_s):
    """Offline stub. Answers evaluator reviews PASS; for any prose-only translation
    returns a benign passthrough so the pipeline completes without an endpoint."""
    import json
    import re
    if "reviewing generated PySpark" in prompt or '"verdict"' in prompt:
        return RawCompletion(text=json.dumps(
            {"verdict": "pass", "confidence": 0.85, "issues": [], "summary": "mock review"}))
    sec = prompt.split("Translate EACH numbered line below", 1)[-1]
    blocks = []
    for m in re.finditer(r"\[(\d+)\]\s+kind=\w+.*?must assign the result to ([A-Za-z_]\w*)", sec, re.DOTALL):
        blocks.append(f"## Step {m.group(1)}\n```python\n{m.group(2)} = spark.range(0)  # TODO mock\n```")
    return RawCompletion(text="\n\n".join(blocks) if blocks else "```python\nF.lit(None)\n```")


obs = NotebookObservability()
llm = LLMClient(
    registry=FixedRegistry(SERVING_ENDPOINT),
    assembler=PromptAssembler(),
    checker=HardConstraintChecker(),
    concurrency=ConcurrencyManager({"cd_translation": 8, "evaluation": 4}, global_ceiling=16),
    observability=obs,
    caller=(mock_caller if USE_MOCK_LLM else None),
)
store = NotebookVolumeStore(volume_root=OUTPUT_VOLUME, dataflow_name=DATAFLOW_NAME)
print("output path will be:", store.path_for(DATAFLOW_ID, iteration=1))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Build (source="md") and run the agent

# COMMAND ----------

import asyncio
import datetime as _dt

import nest_asyncio
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

nest_asyncio.apply()


def run_async(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


app = build_cd_codegen_graph(
    llm=llm,
    store=store,
    source="md",              # <-- MD-plan extraction path (no discovery table needed)
    source_catalog=SOURCE_CATALOG or None,
    source_schema=SOURCE_SCHEMA or None,
    hitl=ENABLE_HITL,
    ai_review=True,
    chunk_size=CHUNK_SIZE,
    max_iters=MAX_ITERS,
).compile(checkpointer=MemorySaver())

config = {"configurable": {
    "thread_id": f"nb-md-{DATAFLOW_ID}",
    "dataflow_id": DATAFLOW_ID,
    "environment": ENVIRONMENT,
    "obs_run_id": f"nb-md-run-{DATAFLOW_ID}",
    "observability": obs,
}}

initial_state = {
    "cd_codegen": {},
    "feedback": {},
    "dataflow_id": DATAFLOW_ID,
    "md_plan": {"gen": {"artifact": plan_text}},   # the approved plan (extraction source)
}

run_async(app.ainvoke(initial_state, config))
snap = app.get_state(config)

if snap.next:  # HITL parked -> auto-accept for this test
    print("parked at HITL; auto-accepting.")
    run_async(app.ainvoke(Command(resume={
        "accepted_issue_ids": [], "rejected_issue_ids": [], "freeform": "",
        "hard_constraints": [], "ts": _dt.datetime.utcnow().isoformat(),
    }), config))
    snap = app.get_state(config)

print("run complete. next =", snap.next)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Results — coverage, code, observability

# COMMAND ----------

gen = snap.values["cd_codegen"]["gen"]
meta = gen["meta"]

print("source          :", meta["source"])
print("counts          :", meta["counts"])        # steps / writes / from_md / from_llm
print("plan coverage   :", meta["coverage"])
print("artifact path   :", meta["artifact_path"])
print("node-addressable:", len(gen["node_keys"]), "sections")
print("=" * 72)
print(gen["artifact"][:4000])
print("... (truncated)" if len(gen["artifact"]) > 4000 else "")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observability

# COMMAND ----------

print(f"LLM calls (only for prose-only steps + review): {len(obs.llm_calls)}")
for r in obs.llm_calls:
    print(f"  role={r.role:9s} model={r.model:14s} pool={r.pool:15s} status={r.status}")
print(f"\nNode executions: {len(obs.node_rows)}")
for r in obs.node_rows:
    print(f"  {r.agent}.{r.node:9s} iter={r.iteration} status={r.status} {r.duration_ms}ms")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Confirm the CD file landed on the Volume

# COMMAND ----------

written_path = meta["artifact_path"]
print("reading back:", written_path)
print("=" * 72)
print(read_text(written_path)[:4000])

# COMMAND ----------

cd_dir = f"{OUTPUT_VOLUME}/{DATAFLOW_NAME}/cd"
from databricks.sdk import WorkspaceClient
for f in WorkspaceClient().files.list_directory_contents(cd_dir):
    print(f.path, f"({f.file_size} bytes)" if getattr(f, "file_size", None) is not None else "")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notes
# MAGIC
# MAGIC - **Real plan**: set `md_plan_path` to your plan `.md` on a Volume (e.g. the
# MAGIC   `cms_8099` plan). It's injected on `state["md_plan"]` and extracted directly.
# MAGIC - **No discovery table needed** for this path — `source="md"` reads only the plan.
# MAGIC - **LLM is used only for prose-only steps** (a step whose plan body has no
# MAGIC   ```python block). A fully-resolved plan like `cms_8099` makes zero model calls;
# MAGIC   the pre-flight in cell 4 tells you up front how many steps (if any) need the LLM.
# MAGIC - **Node-addressability** is keyed on each step's `df_var`; write blocks are keyed
# MAGIC   `write_<snake target>`. Confirm with the Classifier owner if it expects the
# MAGIC   discovery `node_id` instead (the MD plan doesn't carry it).
# MAGIC - **Volume writes** go through the Databricks SDK Files API (`WorkspaceClient().files`),
# MAGIC   which targets the real `/Volumes/...` path. Do NOT use `dbutils.fs` for this —
# MAGIC   it treats scheme-less paths as DBFS and would write to `dbfs:/Volumes/...` instead.
# MAGIC - **Volume must exist**: `CREATE VOLUME IF NOT EXISTS dev_test.dev_domo_migration.\`md-cd\``.