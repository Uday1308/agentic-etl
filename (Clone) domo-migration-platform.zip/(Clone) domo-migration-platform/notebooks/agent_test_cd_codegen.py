# Databricks notebook source
# MAGIC %md
# MAGIC # Agent test · CD Codegen (5)
# MAGIC
# MAGIC Runs the **CD Codegen agent alone** against a real approved MD plan, then reports
# MAGIC everything the observability contract promises: token usage, cost, steps, judge
# MAGIC results and the artifact itself.
# MAGIC
# MAGIC This agent is **fully implemented**, so this is a real test — not a smoke test.
# MAGIC With a fully-resolved plan (like `cms_8099`, 53/53 python-resolved) it should make
# MAGIC **zero generator calls** and produce 71 node-addressable sections.
# MAGIC
# MAGIC No other agent runs. Nothing is written outside the output volume.

# COMMAND ----------

# MAGIC %pip install --quiet "langgraph>=0.2" "langgraph-checkpoint>=2.0" "langchain-core>=0.3" "databricks-sdk>=0.30" nest_asyncio
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-platform", "Repo root")
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("dataflow_id", "8099", "Dataflow id")
dbutils.widgets.text("dataflow_name", "cms_8099", "Dataflow name")
dbutils.widgets.text("md_plan_path", "", "MD plan path (blank = repo fixture cms_8099.md)")
dbutils.widgets.text("output_volume", "/Volumes/dev_test/dev_domo_migration/md-cd", "Output volume")
dbutils.widgets.text("source_catalog", "dev_test", "Source catalog")
dbutils.widgets.text("source_schema", "domo_bronze", "Source schema")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint")
dbutils.widgets.dropdown("use_mock_llm", "true", ["true", "false"], "Use mock LLM")
dbutils.widgets.dropdown("ai_review", "false", ["true", "false"], "Run the LLM evaluator")
dbutils.widgets.text("chunk_size", "1", "Translation chunk size")

REPO_ROOT = dbutils.widgets.get("repo_root")
ENVIRONMENT = dbutils.widgets.get("environment")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id")
DATAFLOW_NAME = dbutils.widgets.get("dataflow_name")
MD_PLAN_PATH = dbutils.widgets.get("md_plan_path").strip()
OUTPUT_VOLUME = dbutils.widgets.get("output_volume")
SOURCE_CATALOG = dbutils.widgets.get("source_catalog").strip()
SOURCE_SCHEMA = dbutils.widgets.get("source_schema").strip()
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint")
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
AI_REVIEW = dbutils.widgets.get("ai_review") == "true"
CHUNK_SIZE = int(dbutils.widgets.get("chunk_size"))

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import asyncio
import json

import nest_asyncio
from agents.cd_codegen.md_extract import assemble_artifact, extract_md_plan
from agents.cd_codegen.md_generator import MdPlanCodeGenerator
from agents.cd_codegen.ports import ArtifactStore
from agents.cd_codegen.strategies import CdCodeEvaluator, IssueLedger
from agents.cd_codegen.translation import ExpressionTranslator
from core.domo.concurrency import ConcurrencyManager
from core.contracts.judges import JudgeRegistry
from core.contracts.telemetry import IngestionRow, IngestPurpose, StepRow, StepStatus
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.sinks import InMemorySink, RecordingObservability, utc_now
from judges.rules import DEFAULT_JUDGES

nest_asyncio.apply()
run_async = lambda c: asyncio.get_event_loop().run_until_complete(c)  # noqa: E731
RUN_ID = f"nb-cdgen-{DATAFLOW_ID}"
print("agent package imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Load the approved plan

# COMMAND ----------

def read_text(path: str) -> str:
    if path.startswith("/Volumes/"):
        from databricks.sdk import WorkspaceClient
        return WorkspaceClient().files.download(path).contents.read().decode("utf-8")
    with open(path, encoding="utf-8") as fh:
        return fh.read()


plan_path = MD_PLAN_PATH or f"{REPO_ROOT}/docs/cms_8099.md"
plan_text = read_text(plan_path)

sink = InMemorySink()
sink.ingestion(IngestionRow(
    run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
    dataset_id=DATAFLOW_ID, dataset_name=f"plan::{DATAFLOW_NAME}",
    purpose=IngestPurpose.CREATION, target_table=plan_path,
    rows_ingested=len(plan_text.splitlines()),
))

ex = extract_md_plan(plan_text, dataflow_id=DATAFLOW_ID)
print(f"plan            : {plan_path}")
print(f"sources         : {len(ex.sources)}")
print(f"steps           : {len(ex.steps)}")
print(f"writes          : {len(ex.writes)}")
print(f"coverage        : {ex.coverage}")
print(f"prose-only (LLM): {len(ex.llm_steps)} {[s.step for s in ex.llm_steps]}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Wire the agent (this agent only)

# COMMAND ----------

class FixedRegistry:
    """Schema-independent: every role resolves to the one endpoint. Avoids coupling
    the test to the real ModelRegistry's binding shape."""

    def __init__(self, endpoint: str):
        self._e = endpoint

    def resolve(self, role, environment) -> EndpointSpec:
        return EndpointSpec(endpoint=self._e, params={"temperature": 0})


class VolumeStore(ArtifactStore):
    """Writes through the SDK Files API — the real UC path, not dbfs:/Volumes/..."""

    def __init__(self, root: str, name: str):
        self._root, self._name = root.rstrip("/"), name
        from databricks.sdk import WorkspaceClient
        self._w = WorkspaceClient()

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return f"{self._root}/{self._name}/cd/etl_{dataflow_id}_v{iteration}.py"

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        import io
        p = self.path_for(dataflow_id, iteration)
        try:
            self._w.files.create_directory(p.rsplit("/", 1)[0])
        except Exception:
            pass
        self._w.files.upload(p, io.BytesIO(content.encode("utf-8")), overwrite=True)
        return p


def mock_caller(spec, prompt, response_schema, timeout_s):
    """Offline stub. Only reached if the plan has prose-only steps or ai_review is on."""
    import re
    if "reviewing generated PySpark" in prompt or '"verdict"' in prompt:
        return RawCompletion(text=json.dumps(
            {"verdict": "pass", "confidence": 0.9, "issues": [], "summary": "mock review"}),
            tokens_in=900, tokens_out=60)
    sec = prompt.split("Translate EACH numbered line below", 1)[-1]
    blocks = [f"## Step {m.group(1)}\n```python\n{m.group(2)} = spark.range(0)  # TODO mock\n```"
              for m in re.finditer(r"\[(\d+)\]\s+kind=\w+.*?result to ([A-Za-z_]\w*)", sec, re.S)]
    return RawCompletion(text="\n\n".join(blocks) or "```python\nF.lit(None)\n```",
                         tokens_in=600, tokens_out=120)


# dollars per 1k tokens — adjust to your rate card
RATES = {SERVING_ENDPOINT: (0.00015, 0.0006)}

obs = RecordingObservability(sink, run_id=RUN_ID, environment=ENVIRONMENT, rate_card=RATES)
llm = LLMClient(
    registry=FixedRegistry(SERVING_ENDPOINT),
    assembler=PromptAssembler(),
    checker=HardConstraintChecker(),
    concurrency=ConcurrencyManager({"cd_translation": 8, "evaluation": 4}, global_ceiling=16),
    observability=obs,
    caller=(mock_caller if USE_MOCK_LLM else None),
)
store = VolumeStore(OUTPUT_VOLUME, DATAFLOW_NAME)
generator = MdPlanCodeGenerator(
    ExpressionTranslator(llm, chunk_size=CHUNK_SIZE), store,
    source_catalog=SOURCE_CATALOG or None, source_schema=SOURCE_SCHEMA or None,
)
print("output path will be:", store.path_for(DATAFLOW_ID, 1))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Run the generator

# COMMAND ----------

import time

state = {"dataflow_id": DATAFLOW_ID, "feedback": {},
         "md_plan": {"gen": {"artifact": plan_text}}}
config = {"configurable": {"dataflow_id": DATAFLOW_ID, "environment": ENVIRONMENT,
                           "thread_id": RUN_ID, "obs_run_id": RUN_ID, "iteration": 1,
                           "observability": obs}}

t0 = time.perf_counter()
result = run_async(generator.generate(state, config))
elapsed_ms = int((time.perf_counter() - t0) * 1000)

sink.step(StepRow(run_id=RUN_ID, ts=utc_now(), environment=ENVIRONMENT,
                  step_id="generate", agent="cd_codegen", phase="Assembling notebook",
                  phase_index=3, phase_count=5, status=StepStatus.OK,
                  duration_ms=elapsed_ms))

print("counts       :", result.meta["counts"])
print("coverage     :", result.meta["coverage"])
print("node sections:", len(result.node_keys))
print("artifact     :", result.meta["artifact_path"])
print("elapsed      :", f"{elapsed_ms} ms")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Judges — deterministic quality rules
# MAGIC
# MAGIC These are **not** the LLM evaluator. Each rule is a hardcoded invariant derived
# MAGIC from a real failure: unordered `F.first()`, bare `DecimalType()`, hardcoded
# MAGIC `_BATCH_ID_` patches, positional column names, permissive unions.

# COMMAND ----------

class Subject:
    def __init__(self, artifact, node_ids, meta):
        self.artifact, self.node_ids, self.meta = artifact, node_ids, meta


registry = JudgeRegistry(list(DEFAULT_JUDGES))
panel = registry.run("cd_codegen",
                     Subject(result.artifact, result.node_keys, result.meta), iteration=1)
sink.judge_panel(panel, run_id=RUN_ID, environment=ENVIRONMENT)

print(json.dumps(panel.summary(), indent=2))
print("=" * 74)
for r in panel.results:
    mark = {"pass": "  ok  ", "warn": " WARN ", "fail": " FAIL "}[r.verdict.value]
    print(f"[{mark}] {r.rule_id}  {r.title}   (checked {r.checked})")
    for f in r.findings[:4]:
        print(f"           - {f.node or '(artifact)'}: {f.message}")
    if len(r.findings) > 4:
        print(f"           … and {len(r.findings) - 4} more")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Evaluator (static checks always; LLM review only if enabled)

# COMMAND ----------

ledger = IssueLedger()
evaluator = CdCodeEvaluator(llm, ai_review=AI_REVIEW, ledger=ledger)
ev = run_async(evaluator.evaluate(result, state, config))

print("verdict   :", ev.verdict.value)
print("confidence:", round(ev.confidence, 3))
print("summary   :", ev.summary)
for i in ev.issues:
    print(f"  ({i.severity.value}) {i.message} [{i.ref}]")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Observability report

# COMMAND ----------

summary = sink.summary(RUN_ID, DATAFLOW_ID)
print("=== RUN SUMMARY ===")
print(json.dumps(summary.model_dump(), indent=2, default=str))

print("\n=== TOKENS BY AGENT ===")
for agent, t in sink.tokens_by_agent().items():
    print(f"  {agent:14s} calls={t['calls']:3d}  in={t['in']:,}  out={t['out']:,}")
print("  (empty means the plan was fully resolved and no model was needed)")

print("\n=== COST BY AGENT ===")
for agent, c in sink.cost_by_agent().items():
    print(f"  {agent:14s} ${c}")

print("\n=== DATASETS READ ===")
for name, purpose, rows in sink.datasets_read():
    print(f"  {name:28s} {purpose:11s} {rows:,} lines")

print("\n=== JUDGE FAILURES ===")
for j in sink.judge_failures():
    print(f"  {j.rule_id}  {j.title}  ({j.findings} findings)")
if not sink.judge_failures():
    print("  none")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. The artifact

# COMMAND ----------

print("first 60 lines of the generated notebook:")
print("=" * 74)
print("\n".join(result.artifact.splitlines()[:60]))

# COMMAND ----------

written = read_text(result.meta["artifact_path"])
assert written.splitlines()[0] == "# Databricks notebook source", "not importable as a notebook"
print(f"read back OK · {len(written.splitlines())} lines · imports as a Databricks notebook")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notes
# MAGIC
# MAGIC - **Zero model calls is the expected result** for a fully-resolved plan. If
# MAGIC   `from_llm > 0`, the plan left steps as prose and the translator filled them.
# MAGIC - `ai_review=false` by default: on deterministically-extracted code the LLM
# MAGIC   reviewer mostly nitpicks and drives pointless regeneration. Turn it on to see
# MAGIC   what it says, not to gate on it.
# MAGIC - Judge failures are facts, not opinions. `DET001` and `SEM001` firing on real
# MAGIC   output means the plan itself carries those problems — that is a finding to take
# MAGIC   to the MD Plan owner, not a bug in this agent.