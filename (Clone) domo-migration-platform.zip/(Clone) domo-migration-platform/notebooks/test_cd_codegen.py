# Databricks notebook source
# MAGIC %md
# MAGIC # CD Codegen agent — test harness
# MAGIC
# MAGIC Runs the `cd_codegen` agent end to end:
# MAGIC
# MAGIC 1. builds a dataflow IR (a built-in **sample** by default, or your real discovery table),
# MAGIC 2. feeds it a **placeholder MD plan** (or a real `.md` path you provide),
# MAGIC 3. maps known tiles deterministically + translates the AI tail through a serving endpoint,
# MAGIC 4. writes the generated PySpark to a **Unity Catalog Volume**.
# MAGIC
# MAGIC The MD plan is consulted by the **AI translation path only** — the deterministic
# MAGIC mapping uses the discovery table exclusively.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Install runtime deps and restart Python

# COMMAND ----------

# MAGIC %pip install --quiet "langgraph>=0.2" "langgraph-checkpoint>=2.0" "langchain-core>=0.3" nest_asyncio
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Parameters (widgets)
# MAGIC
# MAGIC - **repo_root** — folder containing `core/` and `agents/` (your Git folder / Repo path).
# MAGIC - **output_volume** — UC Volume root the generated CD file is written under.
# MAGIC - **md_plan_path** — leave blank to use a built-in placeholder; set to a `.md` on a Volume to use a real plan.
# MAGIC - **serving_endpoint** — the Databricks serving endpoint used for the AI tail.
# MAGIC - **use_mock_llm** — `true` runs with a stub translator (no endpoint needed) so you can test wiring offline.

# COMMAND ----------

dbutils.widgets.text("repo_root", "/Workspace/Repos/your-name/domo-migration-core", "Repo root")
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.text("dataflow_id", "8842", "Dataflow id")
dbutils.widgets.text("dataflow_name", "sample_orders", "Dataflow name")
dbutils.widgets.text("output_volume", "/Volumes/dev_test/dev_domo_migration/md-cd", "Output volume root")
dbutils.widgets.text("discovery_table", "", "Discovery table (blank = built-in sample)")
dbutils.widgets.text("discovery_columns", "", "Discovery column overrides (JSON, optional)")
dbutils.widgets.text("discovery_where", "", "Discovery row filter (SQL, optional)")
dbutils.widgets.text("md_plan_path", "", "MD plan path (blank = placeholder)")
dbutils.widgets.text("serving_endpoint", "gpt-oss-120b", "Serving endpoint")
dbutils.widgets.dropdown("use_mock_llm", "true", ["true", "false"], "Use mock LLM")
dbutils.widgets.dropdown("enable_hitl", "false", ["true", "false"], "Enable human-in-the-loop")
dbutils.widgets.text("chunk_size", "1", "Translation chunk size (1 = most reliable)")
dbutils.widgets.text("max_iters", "3", "Max regenerate iterations")

REPO_ROOT = dbutils.widgets.get("repo_root")
ENVIRONMENT = dbutils.widgets.get("environment")
DATAFLOW_ID = dbutils.widgets.get("dataflow_id")
DATAFLOW_NAME = dbutils.widgets.get("dataflow_name")
OUTPUT_VOLUME = dbutils.widgets.get("output_volume")
DISCOVERY_TABLE = dbutils.widgets.get("discovery_table").strip()
DISCOVERY_COLUMNS = dbutils.widgets.get("discovery_columns").strip()
DISCOVERY_WHERE = dbutils.widgets.get("discovery_where").strip()
MD_PLAN_PATH = dbutils.widgets.get("md_plan_path").strip()
SERVING_ENDPOINT = dbutils.widgets.get("serving_endpoint")
USE_MOCK_LLM = dbutils.widgets.get("use_mock_llm") == "true"
ENABLE_HITL = dbutils.widgets.get("enable_hitl") == "true"
CHUNK_SIZE = int(dbutils.widgets.get("chunk_size"))
MAX_ITERS = int(dbutils.widgets.get("max_iters"))

print(f"repo_root       = {REPO_ROOT}")
print(f"dataflow        = {DATAFLOW_NAME} (id={DATAFLOW_ID}) env={ENVIRONMENT}")
print(f"output volume   = {OUTPUT_VOLUME}")
print(f"discovery       = {'sample (built-in)' if not DISCOVERY_TABLE else DISCOVERY_TABLE}")
print(f"md plan         = {'placeholder' if not MD_PLAN_PATH else MD_PLAN_PATH}")
print(f"llm             = {'MOCK' if USE_MOCK_LLM else SERVING_ENDPOINT}")
print(f"hitl            = {ENABLE_HITL}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Put the agent package on the path

# COMMAND ----------

import sys

if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

# sanity: these imports prove the repo layout is visible
from agents.cd_codegen.graph import build_cd_codegen_graph
from agents.cd_codegen.ir import DataflowIR, IRNode
from agents.cd_codegen.ports import ArtifactStore, DiscoveryReader, SparkDiscoveryReader, VolumeArtifactStore
from core.domo.llm import LLMClient, RawCompletion
from core.domo.models import EndpointSpec, ModelRegistry, Role
from core.domo.prompts import HardConstraintChecker, PromptAssembler
from core.domo.concurrency import ConcurrencyManager
from core.domo.observability import LlmCallRow, NodeRow, ObservabilityWriter

print("agent package imported OK")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Discovery input
# MAGIC
# MAGIC By default we use a built-in sample dataflow that exercises all three code paths:
# MAGIC **mapped** (DataSet, Filter, GroupBy), **hybrid** (a Beast-Mode formula), and **AI**
# MAGIC (an unrecognized tile). Set the `discovery_table` widget to read your real table instead.

# COMMAND ----------

class SampleDiscovery(DiscoveryReader):
    """A small, realistic dataflow: bronze -> filter -> formula -> unknown -> aggregate."""

    def read(self, dataflow_id: str) -> DataflowIR:
        return DataflowIR(dataflow_id=dataflow_id, nodes=(
            IRNode(node_id="orders", op_type="DataSet",
                   config={"table": "bronze.orders"}),
            IRNode(node_id="open_only", op_type="Filter", inputs=("orders",),
                   config={"conditions": [{"column": "status", "operator": "EQUALS", "value": "OPEN"}]}),
            IRNode(node_id="margin", op_type="AddFormula", inputs=("open_only",),
                   config={"formulas": [{"name": "margin_pct",
                                         "formula": "CASE WHEN `revenue`=0 THEN 0 ELSE (`revenue`-`cost`)/`revenue` END"}]}),
            IRNode(node_id="scored", op_type="RiskScore", inputs=("margin",),  # <- unknown tile -> AI
                   config={"model": "logistic", "features": ["margin_pct", "region"]}),
            IRNode(node_id="by_region", op_type="GroupBy", inputs=("scored",),
                   config={"groupBy": ["region"],
                           "aggregations": [{"column": "margin_pct", "function": "AVG", "alias": "avg_margin"}]}),
        ))


if DISCOVERY_TABLE:
    from pyspark.sql import functions as F

    tdf = spark.table(DISCOVERY_TABLE)
    cols = tdf.columns
    print(f"discovery table columns: {cols}")

    # scope to THIS dataflow first (the table holds many dataflows)
    scoped = tdf.filter(F.col("dataflow_id").cast("string") == str(DATAFLOW_ID)) if "dataflow_id" in cols else tdf

    if "record_type" in cols:
        print("record_type distribution for this dataflow:")
        scoped.groupBy("record_type").count().show(truncate=False)

    # build the row filter: node rows only, and the LATEST discovery run (the table
    # accumulates runs, which otherwise duplicates node_ids across runs)
    import json as _json
    overrides = _json.loads(DISCOVERY_COLUMNS) if DISCOVERY_COLUMNS else None
    where = DISCOVERY_WHERE
    if not where:
        clauses = []
        if "record_type" in cols:
            # detect the real node marker from the data (e.g. 'NODE' vs 'node' vs 'Node');
            # edges here are 'LINEAGE'. Fall back to node_id-not-null if none looks like a node.
            markers = [r[0] for r in scoped.select("record_type").distinct().collect() if r[0] is not None]
            node_marker = next((m for m in markers if "NODE" in str(m).upper()), None)
            if node_marker:
                print(f"node record_type marker: {node_marker!r} (all markers: {markers})")
                clauses.append(f"record_type = '{node_marker}'")
            elif "node_id" in cols:
                clauses.append("node_id IS NOT NULL")
        if "discovery_run_id" in cols and "discovered_at" in cols:
            latest = scoped.orderBy(F.col("discovered_at").desc()).select("discovery_run_id").first()
            if latest and latest[0] is not None:
                clauses.append(f"discovery_run_id = '{latest[0]}'")
                print(f"latest discovery_run_id: {latest[0]}")
        where = " AND ".join(clauses)
    print(f"row filter (where): {where or '(none)'}")

    discovery = SparkDiscoveryReader(table=DISCOVERY_TABLE, spark=spark,
                                     columns=overrides, where=where or None)
else:
    discovery = SampleDiscovery()

_ir = discovery.read(DATAFLOW_ID)
print(f"discovered {len(_ir.nodes)} nodes: {[n.node_id for n in _ir.nodes]}")
print(f"op types  : {sorted({n.op_type for n in _ir.nodes})}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. MD plan (placeholder now, real path later)
# MAGIC
# MAGIC The plan text is injected on the run state as the approved plan; the agent will only
# MAGIC surface it to the model for the AI-translated fragments.

# COMMAND ----------

PLACEHOLDER_PLAN = """\
# Migration plan (placeholder)

- Preserve column names exactly as in the source dataflow.
- Represent DOMO CASE expressions with F.when(...).otherwise(...); guard divide-by-zero.
- For any risk/scoring tile, produce a deterministic passthrough placeholder and leave a
  TODO marker rather than inventing model logic.
- Prefer explicit null handling over silent drops.
"""


def read_text(path: str) -> str:
    """Read text from a Volume/workspace path. Sequential open() reads work on UC
    Volumes; fall back to the Volumes API only for FUSE 'operation not supported'.
    A genuinely missing file raises a clear, actionable error."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"MD plan not found at {path!r}. Check the path — note 'md-cd' vs 'md_cd' and the "
            f"exact filename — or leave the `md_plan_path` widget blank to use the placeholder. "
            f"Tip: list the folder with dbutils.fs.ls('<parent dir>') to see what's there."
        ) from e
    except OSError as e:
        if getattr(e, "errno", None) == 95:          # EOPNOTSUPP -> Volumes API
            try:
                return dbutils.fs.head(path, 10 * 1024 * 1024)
            except Exception as e2:
                raise FileNotFoundError(
                    f"Could not read MD plan at {path!r} via the Volumes API ({e2}). "
                    f"Verify the path, or blank the `md_plan_path` widget to use the placeholder."
                ) from e2
        raise


plan_text = read_text(MD_PLAN_PATH) if MD_PLAN_PATH else PLACEHOLDER_PLAN
print(f"plan source: {'file ' + MD_PLAN_PATH if MD_PLAN_PATH else 'placeholder'}")
print("-" * 60)
print(plan_text)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Wire the core services
# MAGIC
# MAGIC The agent needs the sanctioned `LLMClient` (role registry + concurrency + observability),
# MAGIC plus the discovery reader and a Volume-backed artifact store. Everything is injected —
# MAGIC nothing is constructed inside the graph.

# COMMAND ----------

class NotebookObservability(ObservabilityWriter):
    """Collects rows in memory so we can display them after the run."""

    def __init__(self):
        self.llm_calls: list[LlmCallRow] = []
        self.node_rows: list[NodeRow] = []

    def record_llm_call(self, row: LlmCallRow) -> None:
        self.llm_calls.append(row)

    def record_node(self, row: NodeRow) -> None:
        self.node_rows.append(row)


def mock_caller(spec, prompt, response_schema, timeout_s):
    """Offline stub: answers evaluator reviews with PASS and translation chunks with
    benign placeholders (passthrough for whole-operation tiles). Lets you test the full
    pipeline + volume write without a serving endpoint."""
    import json
    import re
    if "reviewing generated PySpark" in prompt or '"verdict"' in prompt:
        return RawCompletion(text=json.dumps(
            {"verdict": "pass", "confidence": 0.85, "issues": [], "summary": "mock review — accepted"}))
    section = prompt.split("Translate EACH numbered line below", 1)[-1]
    lines = []
    for ln in section.splitlines():
        s = ln.strip()
        m = re.match(r"\[(\d+)\]\s+kind=(\w+)", s)
        if not m:
            continue
        idx, kind = int(m.group(1)), m.group(2)
        if kind == "operation":
            # whole-tile: return a full statement (a trailing comment here is safe)
            var = re.search(r"must assign the result to ([A-Za-z_]\w*)", s)
            ins = re.search(r"inputs available as: ([^;]+)", s)
            target = var.group(1) if var else "df_out"
            first = ins.group(1).split(",")[0].strip() if ins else "spark.range(0)"
            code = f"{target} = {first}  # TODO: mock passthrough (unknown tile)"
        elif kind == "filter":
            # embedded in .filter(...): must be a bare expression, no inline comment
            code = "F.lit(True)"
        else:
            # embedded in withColumn(...): bare expression, no inline comment
            code = "F.lit(None)"
        lines.append({"index": idx, "pyspark": code})
    return RawCompletion(text=json.dumps({"lines": lines, "confidence": 0.5}))


class FixedRegistry:
    """Minimal role->endpoint registry for the test harness: every role resolves to
    the one configured serving endpoint. This deliberately avoids coupling the
    notebook to the real ModelRegistry's binding schema (which wraps plain-dict
    bindings into EndpointSpec itself). LLMClient only needs `.resolve(...)`.

    To exercise the *real* ModelRegistry instead, construct it with plain-mapping
    bindings, e.g.:
        ModelRegistry({ENVIRONMENT: {"generator": {"endpoint": SERVING_ENDPOINT},
                                     "evaluator": {"endpoint": SERVING_ENDPOINT}}})
    (pass dicts, NOT EndpointSpec objects).
    """

    def __init__(self, endpoint: str):
        self._endpoint = endpoint

    def resolve(self, role, environment) -> EndpointSpec:
        return EndpointSpec(endpoint=self._endpoint)


registry = FixedRegistry(SERVING_ENDPOINT)

concurrency = ConcurrencyManager(
    {"cd_translation": 8, "evaluation": 4}, global_ceiling=16)

obs = NotebookObservability()

llm = LLMClient(
    registry=registry,
    assembler=PromptAssembler(),
    checker=HardConstraintChecker(),
    concurrency=concurrency,
    observability=obs,
    caller=(mock_caller if USE_MOCK_LLM else None),   # None -> real DatabricksEndpointCaller
)

class NotebookVolumeStore(ArtifactStore):
    """Volume-aware artifact store for the notebook. Writes through ``dbutils.fs``
    (the Volumes API) rather than ``os.makedirs`` + ``open`` — UC Volumes' FUSE
    mount does not support the recursive ``mkdir`` syscall and raises Errno 95.
    Same path layout as the production ``VolumeArtifactStore``."""

    def __init__(self, volume_root: str, dataflow_name: str) -> None:
        self._root = volume_root.rstrip("/")
        self._name = dataflow_name

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return f"{self._root}/{self._name}/cd/etl_{dataflow_id}_v{iteration}.py"

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        path = self.path_for(dataflow_id, iteration)
        dbutils.fs.mkdirs(path.rsplit("/", 1)[0])     # UC-aware, recursive, idempotent
        dbutils.fs.put(path, content, overwrite=True)
        return path


store = NotebookVolumeStore(volume_root=OUTPUT_VOLUME, dataflow_name=DATAFLOW_NAME)
print("output path will be:", store.path_for(DATAFLOW_ID, iteration=1))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Build and run the agent

# COMMAND ----------

import asyncio
import datetime as _dt

import nest_asyncio
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

nest_asyncio.apply()  # allow ainvoke from inside the notebook's event loop


def run_async(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


app = build_cd_codegen_graph(
    llm=llm,
    discovery=discovery,
    store=store,
    hitl=ENABLE_HITL,
    ai_review=True,
    chunk_size=CHUNK_SIZE,
    max_iters=MAX_ITERS,
).compile(checkpointer=MemorySaver())

config = {"configurable": {
    "thread_id": f"nb-{DATAFLOW_ID}",
    "dataflow_id": DATAFLOW_ID,
    "environment": ENVIRONMENT,
    "obs_run_id": f"nb-run-{DATAFLOW_ID}",
    "observability": obs,
}}

initial_state = {
    "cd_codegen": {},
    "feedback": {},
    "dataflow_id": DATAFLOW_ID,
    # inject the approved plan on state -> consulted by the AI path only
    "md_plan": {"gen": {"artifact": plan_text}},
}

run_async(app.ainvoke(initial_state, config))
snap = app.get_state(config)

# If HITL is on, the run parks at the review interrupt — auto-accept for this test.
if snap.next:
    print("parked at HITL; interrupt payload:")
    payload = snap.tasks[0].interrupts[0].value
    print("  agent    :", payload["agent"])
    print("  node keys:", payload["artifact"]["node_keys"])
    print("  verdict  :", (payload.get("eval") or {}).get("verdict"))
    run_async(app.ainvoke(Command(resume={
        "accepted_issue_ids": [], "rejected_issue_ids": [], "freeform": "",
        "hard_constraints": [], "ts": _dt.datetime.utcnow().isoformat(),
    }), config))
    snap = app.get_state(config)

print("run complete. next =", snap.next)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Results — origin breakdown, generated code, observability

# COMMAND ----------

gen = snap.values["cd_codegen"]["gen"]
artifact = gen["artifact"]
meta = gen["meta"]

print("origin breakdown:", meta["counts"])
print("per-node origin :", meta["origins"])
print("artifact path   :", meta["artifact_path"])
print("=" * 72)
print(artifact)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Observability rows captured this run

# COMMAND ----------

print(f"LLM calls: {len(obs.llm_calls)}")
for r in obs.llm_calls:
    print(f"  role={r.role:9s} model={r.model:14s} pool={r.pool:15s} "
          f"tokens={r.tokens_in}->{r.tokens_out} status={r.status}")

print(f"\nNode executions: {len(obs.node_rows)}")
for r in obs.node_rows:
    print(f"  {r.agent}.{r.node:9s} iter={r.iteration} status={r.status} {r.duration_ms}ms")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Confirm the CD file landed on the Volume
# MAGIC
# MAGIC Read it straight back from the Volume path to prove the write succeeded.

# COMMAND ----------

written_path = meta["artifact_path"]
print("reading back:", written_path)
print("=" * 72)
print(read_text(written_path))

# COMMAND ----------

# list the cd/ folder for this dataflow so you can see versioned outputs accumulate
cd_dir = f"{OUTPUT_VOLUME}/{DATAFLOW_NAME}/cd"
display(dbutils.fs.ls(cd_dir))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Notes
# MAGIC
# MAGIC - **Real discovery table**: set the `discovery_table` widget. The reader auto-maps
# MAGIC   common column aliases (`node_id`/`id`, `op_type`/`type`, `inputs`/`upstream`, ...).
# MAGIC   If your columns differ, set `discovery_columns` to a JSON map, e.g.
# MAGIC   `{"node_id": "step_id", "op_type": "tile", "config": "props", "inputs": "parents"}`.
# MAGIC   `config`/`inputs` may be JSON strings or native Spark struct/array columns.
# MAGIC - **Real MD plan**: set `md_plan_path` to a `.md` on a Volume. It is injected on
# MAGIC   `state["md_plan"]` and reaches the model only for AI-translated fragments; the
# MAGIC   deterministic mapping ignores it entirely.
# MAGIC - **Real LLM**: set `use_mock_llm=false` and point `serving_endpoint` at your endpoint.
# MAGIC   The client lazily uses `DatabricksEndpointCaller` (WorkspaceClient serving query).
# MAGIC - **Versioning**: each run writes `etl_<id>_v<iteration>.py`; a new iteration never
# MAGIC   clobbers an approved earlier version (idempotency key = dataflow / node / iteration).
# MAGIC - **Volume writes**: this notebook writes via `dbutils.fs` (the Volumes API), because
# MAGIC   UC Volumes' FUSE mount doesn't support the recursive `mkdir` syscall that the
# MAGIC   production `VolumeArtifactStore` (`os.makedirs` + `open`) relies on. The target UC
# MAGIC   **Volume must already exist** (`CREATE VOLUME dev_test.dev_domo_migration.\`md-cd\``);
# MAGIC   subdirectories are created for you.
# MAGIC - **Production note**: for the app/agent path, `VolumeArtifactStore` should write through
# MAGIC   the Databricks SDK Files API (`WorkspaceClient().files.upload(...)`) rather than
# MAGIC   `os.makedirs`, so it works in both the app runtime and on Volumes without FUSE.