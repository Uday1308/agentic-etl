@echo off
setlocal enabledelayedexpansion
rem ============================================================================
rem  run_served.cmd - the whole Control Tower from ONE process, no Node needed.
rem
rem  FastAPI answers /api and serves the pre-built React bundle for everything
rem  else, so the target machine needs Python only. This is the same path the
rem  Databricks App uses; the only difference is where it runs.
rem
rem  Before copying to a machine without Node, build the bundle ONCE somewhere
rem  that has it:
rem
rem      cd lv-tower && npm ci && npm run build
rem
rem  and make sure lv-tower\dist comes with you. It is gitignored, so a plain
rem  `git clone` will NOT bring it - copy the folder, or zip the repo after
rem  building. Without it the API starts and serves no UI at all; check
rem  http://127.0.0.1:8000/api/serving, where "spa" will be null.
rem
rem  Usage:
rem      run_served.cmd                      run the pipeline, then serve
rem      run_served.cmd --fresh              wipe previous runs first
rem      run_served.cmd --skip-run           serve what is already on the volume
rem ============================================================================

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%" || (echo Cannot cd to %ROOT% & exit /b 1)
set "PYTHONPATH=%ROOT%"
if "%API_PORT%"=="" set "API_PORT=8000"

rem -- the bundle has to exist; a silent blank page is the worst outcome -------
if not exist "%ROOT%\lv-tower\dist\index.html" (
    echo(
    echo   !! No built frontend at %ROOT%\lv-tower\dist
    echo      Build it on a machine with Node and copy the dist folder here:
    echo          cd lv-tower ^&^& npm ci ^&^& npm run build
    echo      Serving the API without it would give you a working API and a
    echo      blank page, which is harder to diagnose than this message.
    exit /b 1
)

netstat -an | findstr /c:":%API_PORT% " | findstr /c:"LISTENING" >nul 2>&1
if !errorlevel! equ 0 (
    echo   !! port %API_PORT% is already in use. Close it, or set API_PORT.
    exit /b 1
)

set "RUN_ARGS="
set "SKIP_RUN="
for %%A in (%*) do (
    if /i "%%A"=="--skip-run" (set "SKIP_RUN=1") else (set "RUN_ARGS=!RUN_ARGS! %%A")
)

if not defined SKIP_RUN (
    echo(
    echo [1/2] running the pipeline ...
    echo(
    python "%ROOT%\scripts\e2e_mock_run.py" !RUN_ARGS!
    if errorlevel 1 (
        echo(
        echo   !! the run failed - not starting the server.
        exit /b 1
    )
) else (
    echo [1/2] --skip-run: serving whatever is already on the volume
)

echo(
echo [2/2] serving on http://127.0.0.1:%API_PORT%   ^(Ctrl+C to stop^)
echo       the UI and the API are the same process; there is no second window
echo(
python -m uvicorn api.app:app --host 127.0.0.1 --port %API_PORT%
endlocal
