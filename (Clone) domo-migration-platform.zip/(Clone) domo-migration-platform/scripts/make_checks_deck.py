#!/usr/bin/env python3
"""Build the quality-checks deck: every automated check, in plain words.

    python scripts/make_checks_deck.py            -> docs/migration_quality_checks.pptx

Who it is for
-------------
Someone who will sit in a review meeting, see "SEM003 failed", and needs to know
what that means and whether to care — without reading the source. So every slide
says the same four things: what the check looks at, why anyone should care, what
passing looks like, and what failing looks like. The two snippets are the point:
a rule described in prose is an opinion, and a rule shown failing is a fact.

Why a script and not a hand-made file
-------------------------------------
The rule ids, titles and scope are READ FROM THE CODE, not retyped. A deck that
lists a rule the platform no longer runs is worse than no deck, because it is
consulted at exactly the moment somebody is deciding whether to trust the run.
The build fails loudly if a rule exists with no explanation here, so adding a
judge and forgetting the slide is not a thing that can quietly happen.

The plain-English text IS written by hand. It has to be: it is the translation
from "what the regex matches" to "what it means for your numbers", and nothing
can generate that from the source.
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation  # noqa: E402
from pptx.dml.color import RGBColor  # noqa: E402
from pptx.enum.text import PP_ALIGN  # noqa: E402
from pptx.util import Inches, Pt  # noqa: E402

from judges.rules import DEFAULT_JUDGES  # noqa: E402

# -- palette ---------------------------------------------------------------- #
INK = RGBColor(0x0F, 0x1E, 0x33)
MUTED = RGBColor(0x51, 0x65, 0x81)
DIM = RGBColor(0x7C, 0x8C, 0xA3)
BRAND = RGBColor(0x1D, 0x57, 0xAB)
PASS = RGBColor(0x1B, 0x7F, 0x5A)
WARN = RGBColor(0x9A, 0x6B, 0x06)
FAIL = RGBColor(0xB3, 0x2D, 0x3F)
PAPER = RGBColor(0xFF, 0xFF, 0xFF)
WASH = RGBColor(0xF4, 0xF7, 0xFB)
LINE = RGBColor(0xDC, 0xE6, 0xF2)
CODE_BG = RGBColor(0xF7, 0xF9, 0xFC)

W, H = Inches(13.333), Inches(7.5)

#: kind -> what this family of checks is about.
KIND_NOTE = {
    "structure": "is the artifact put together correctly",
    "determinism": "does the same input always give the same answer",
    "semantics": "does it still mean what DOMO meant",
    "lineage": "does everything come from somewhere",
    "policy": "is the document honest about itself",
}

#: verdict -> (label, colour). A reviewer's first question is "does this stop
#: the migration", and the three answers are genuinely different.
VERDICT_TONE = {"FAIL": FAIL, "WARN": WARN, "UNVERIFIABLE": DIM, "PASS": PASS}
VERDICT_MEANS = {
    "FAIL": "a finding here FAILS the gate",
    "WARN": "a finding here is a WARNING",
    "UNVERIFIABLE": "can report UNVERIFIABLE",
}


def finding_verdict(judge) -> str:
    """WARN or FAIL, read off the rule's own source.

    Retyping this into the deck would put the two out of step the first time a
    rule's severity is reconsidered — and severity is the single thing a reader
    of this deck is trying to look up.
    """
    import inspect
    import re as _re
    src = inspect.getsource(type(judge).run)
    m = _re.search(r"on_finding=Verdict\.(\w+)", src)
    return m.group(1) if m else "FAIL"


def _txt(slide, x, y, w, h, text, *, size=14, bold=False, color=INK,
         font="Calibri", align=PP_ALIGN.LEFT, spacing=1.0):
    box = slide.shapes.add_textbox(x, y, w, h)
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    lines = text.split("\n")
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = spacing
        run = p.add_run()
        run.text = line
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
        run.font.name = font
    return box


def _rect(slide, x, y, w, h, fill, line=None):
    from pptx.enum.shapes import MSO_SHAPE
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    shape.adjustments[0] = 0.04
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = line
        shape.line.width = Pt(0.75)
    shape.shadow.inherit = False
    return shape


def _blank(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = PAPER
    return slide


def title_slide(prs, title, subtitle, note):
    slide = _blank(prs)
    _rect(slide, 0, 0, W, Inches(2.6), BRAND)
    _txt(slide, Inches(0.9), Inches(0.85), Inches(11.5), Inches(0.9), title,
         size=40, bold=True, color=PAPER)
    _txt(slide, Inches(0.9), Inches(1.78), Inches(11.5), Inches(0.5), subtitle,
         size=17, color=RGBColor(0xD6, 0xE4, 0xF7))
    _txt(slide, Inches(0.9), Inches(3.2), Inches(11.5), Inches(3), note,
         size=15, color=MUTED, spacing=1.45)
    return slide


def section_slide(prs, kicker, title, body):
    slide = _blank(prs)
    _rect(slide, 0, 0, Inches(0.22), H, BRAND)
    _txt(slide, Inches(0.9), Inches(2.1), Inches(11), Inches(0.4), kicker,
         size=13, bold=True, color=BRAND)
    _txt(slide, Inches(0.9), Inches(2.6), Inches(11), Inches(0.9), title,
         size=34, bold=True)
    _txt(slide, Inches(0.9), Inches(3.75), Inches(10.5), Inches(2), body,
         size=15, color=MUTED, spacing=1.45)
    return slide



def verdict_slide(prs, rules):
    """The two vocabularies, side by side.

    Gates 1 and 2 are RULES over a document: pass, warn, fail. Gate 3 is a
    COMPARISON against DOMO's own graph, and a comparison has a third outcome a
    rule does not — it can be impossible to make. Calling both "three verdicts"
    hid that, and the missing one is the one people ask about.
    """
    slide = _blank(prs)
    _rect(slide, 0, 0, W, Inches(1.15), WASH)
    _txt(slide, Inches(0.62), Inches(0.34), Inches(11), Inches(0.5),
         "Reading a verdict", size=25, bold=True)

    # Counted, not typed. The first draft of this slide said "5 warn, 12 fail"
    # when the code said 6 and 11 — in the one place a reader looks up exactly
    # that, on a slide whose whole subject is not overstating a result.
    verdicts = [finding_verdict(j) for j in rules.values()]
    warns = sum(1 for v in verdicts if v == "WARN")
    fails = len(verdicts) - warns

    left = [
        ("PASS", PASS, "The check ran and found nothing."),
        ("WARN", WARN, "Worth a person reading. The artifact still works; the\n"
                       f"meaning may have shifted. {warns} of the {len(verdicts)} rules warn."),
        ("FAIL", FAIL, "The artifact should not go forward as it stands.\n"
                       f"{fails} of the {len(verdicts)} rules fail."),
    ]
    right = [
        ("PASS", PASS, "The SQL and the DOMO graph agree on this point."),
        ("FAIL", FAIL, "They disagree. Something was lost in translation."),
        ("UNVERIFIABLE", DIM, "The comparison could not be made at all — see the\n"
                              "next slide. Never counted as a pass."),
    ]

    for x, heading, sub, rows in (
        (Inches(0.62), "GATES 1 AND 2  ·  THE CHECKS", "rules applied to a document", left),
        (Inches(6.9), "GATE 3  ·  LOGIC PARITY", "a comparison against DOMO's graph", right),
    ):
        _rect(slide, x, Inches(1.55), Inches(5.82), Inches(5.3), CODE_BG, LINE)
        _txt(slide, x + Inches(0.32), Inches(1.8), Inches(5.2), Inches(0.3),
             heading, size=11, bold=True, color=BRAND)
        _txt(slide, x + Inches(0.32), Inches(2.12), Inches(5.2), Inches(0.3),
             sub, size=11.5, color=DIM)
        y = Inches(2.68)
        for label, colour, body in rows:
            _rect(slide, x + Inches(0.32), y, Inches(1.62), Inches(0.34), PAPER, colour)
            _txt(slide, x + Inches(0.32), y + Inches(0.07), Inches(1.62), Inches(0.3),
                 label, size=10.5, bold=True, color=colour, align=PP_ALIGN.CENTER)
            _txt(slide, x + Inches(0.32), y + Inches(0.48), Inches(5.2), Inches(0.9),
                 body, size=12.5, color=MUTED, spacing=1.3)
            y += Inches(1.35)

    _txt(slide, Inches(0.62), Inches(7.0), Inches(12), Inches(0.35),
         "A check that examined nothing is never reported as a pass. That rule holds in both columns.",
         size=12.5, bold=True, color=INK)
    return slide


def unverifiable_slide(prs):
    """What the fourth verdict actually means, with the real case.

    This is the one people hit and ask about, so it gets a slide of its own
    rather than a footnote: the mechanism, the reason, and the fix.
    """
    slide = _blank(prs)
    _rect(slide, 0, 0, W, Inches(1.32), WASH)
    _rect(slide, Inches(0.62), Inches(0.34), Inches(1.9), Inches(0.42), DIM)
    _txt(slide, Inches(0.62), Inches(0.40), Inches(1.9), Inches(0.3), "UNVERIFIABLE",
         size=11, bold=True, color=PAPER, font="Consolas", align=PP_ALIGN.CENTER)
    _txt(slide, Inches(2.7), Inches(0.3), Inches(9.2), Inches(0.45),
         "When a check cannot run at all", size=21, bold=True)
    _txt(slide, Inches(2.7), Inches(0.82), Inches(9.8), Inches(0.3),
         "Only the column check can report this   ·   it is not a pass, and it is not a failure",
         size=11, color=DIM)

    _txt(slide, Inches(0.62), Inches(1.62), Inches(2.4), Inches(0.3),
         "IN PLAIN WORDS", size=10.5, bold=True, color=BRAND)
    _txt(slide, Inches(0.62), Inches(1.95), Inches(5.6), Inches(1.6),
         "To check that a column exists, the platform has to know what columns "
         "arrive from upstream. It works that out tile by tile — but it has to "
         "start somewhere, and nobody ever told it what columns the SOURCE "
         "datasets have.",
         size=13.5, spacing=1.3)

    _txt(slide, Inches(6.9), Inches(1.62), Inches(3.4), Inches(0.3),
         "WHY IT IS NOT A PASS", size=10.5, bold=True, color=BRAND)
    _txt(slide, Inches(6.9), Inches(1.95), Inches(5.8), Inches(1.6),
         "Because nothing was examined. A green tick on a check that ran zero "
         "comparisons is the most misleading thing this stage could produce, so "
         "it is reported separately and excluded from the passed count.",
         size=13.5, color=MUTED, spacing=1.3)

    top, height = Inches(3.72), Inches(3.25)
    _rect(slide, Inches(0.62), top, Inches(5.82), height, CODE_BG, LINE)
    _rect(slide, Inches(0.62), top, Inches(0.09), height, DIM)
    _txt(slide, Inches(0.94), top + Inches(0.18), Inches(5.2), Inches(0.3),
         "HOW IT HAPPENS", size=10.5, bold=True, color=DIM)
    _txt(slide, Inches(0.94), top + Inches(0.55), Inches(5.3), height - Inches(0.7),
         "source dataset  ->  columns UNKNOWN\n"
         "      |              (never pulled)\n"
         "      v\n"
         "   tile A       ->  UNKNOWN\n"
         "      |\n"
         "      v\n"
         "   tile B       ->  UNKNOWN\n"
         "\nReal case, dataflow 8099, target\n"
         "0047 GL Detail Post Close:\n"
         "3 tiles had columns worth checking.\n"
         "All 3 read straight from a source.",
         size=11, font="Consolas", spacing=1.2)

    _rect(slide, Inches(6.9), top, Inches(5.82), height, CODE_BG, LINE)
    _rect(slide, Inches(6.9), top, Inches(0.09), height, PASS)
    _txt(slide, Inches(7.22), top + Inches(0.18), Inches(5.2), Inches(0.3),
         "WHY OTHER TARGETS PASS", size=10.5, bold=True, color=PASS)
    _txt(slide, Inches(7.22), top + Inches(0.55), Inches(5.3), height - Inches(0.7),
         "Same missing schemas everywhere.\n"
         "The difference is chain length.\n"
         "\ndupe check     unverifiable\n"
         "               6 unknown, 0 checked\n"
         "DIAM Rev Rec   pass\n"
         "               5 checked, 11 skipped\n"
         "REV-01 and 02  pass\n"
         "               17 checked, 11 skipped\n"
         "\nA tile reading another TILE can be\n"
         "traced. Only the first hop is blind.",
         size=11, font="Consolas", spacing=1.2)
    return slide


def check_slide(prs, *, rid, title, kind, scope, means, matters, ok, bad,
                severity="FAIL", ok_label="Passes", bad_label="Fails"):
    slide = _blank(prs)

    # header
    _rect(slide, 0, 0, W, Inches(1.32), WASH)
    _rect(slide, Inches(0.62), Inches(0.34), Inches(1.15), Inches(0.42), BRAND)
    _txt(slide, Inches(0.62), Inches(0.40), Inches(1.15), Inches(0.3), rid,
         size=13, bold=True, color=PAPER, font="Consolas", align=PP_ALIGN.CENTER)
    _txt(slide, Inches(1.95), Inches(0.3), Inches(8.0), Inches(0.45), title,
         size=21, bold=True)
    _txt(slide, Inches(1.95), Inches(0.82), Inches(9.8), Inches(0.3),
         f"{kind.upper()}   ·   {KIND_NOTE.get(kind, '')}   ·   runs on {scope}",
         size=11, color=DIM)
    # Severity, top right, where the eye goes first. "Does this stop the
    # migration" is the question this deck exists to answer quickly.
    tone = VERDICT_TONE.get(severity, FAIL)
    _rect(slide, Inches(10.1), Inches(0.33), Inches(2.62), Inches(0.44),
          PAPER, tone)
    _txt(slide, Inches(10.1), Inches(0.44), Inches(2.62), Inches(0.3),
         VERDICT_MEANS.get(severity, ""), size=10.5, bold=True, color=tone,
         align=PP_ALIGN.CENTER)

    # what it means / why it matters
    _txt(slide, Inches(0.62), Inches(1.62), Inches(1.6), Inches(0.3),
         "IN PLAIN WORDS", size=10.5, bold=True, color=BRAND)
    _txt(slide, Inches(0.62), Inches(1.95), Inches(5.6), Inches(1.5), means,
         size=13.5, spacing=1.35)

    _txt(slide, Inches(6.9), Inches(1.62), Inches(2.4), Inches(0.3),
         "WHY IT MATTERS", size=10.5, bold=True, color=BRAND)
    _txt(slide, Inches(6.9), Inches(1.95), Inches(5.8), Inches(1.5), matters,
         size=13.5, color=MUTED, spacing=1.35)

    # the two snippets, side by side — the part people actually read
    top = Inches(3.62)
    height = Inches(3.35)
    for x, label, body, colour in (
        (Inches(0.62), ok_label, ok, PASS),
        (Inches(6.9), bad_label, bad, FAIL),
    ):
        _rect(slide, x, top, Inches(5.82), height, CODE_BG, LINE)
        _rect(slide, x, top, Inches(0.09), height, colour)
        _txt(slide, x + Inches(0.3), top + Inches(0.18), Inches(5.2), Inches(0.3),
             label.upper(), size=10.5, bold=True, color=colour)
        _txt(slide, x + Inches(0.3), top + Inches(0.55), Inches(5.3),
             height - Inches(0.7), body, size=11, font="Consolas", spacing=1.25)
    return slide


# --------------------------------------------------------------------------- #
# the content. One entry per rule id; the build refuses to run if the platform
# has a rule this dict does not explain.
# --------------------------------------------------------------------------- #

PLAIN: dict[str, dict] = {

    # -- the plan ----------------------------------------------------------- #
    "MD001": dict(
        means="The plan is a document with numbered sections, and the code "
              "generator reads specific ones by number. This checks all of them "
              "are there.",
        matters="If section 6 goes missing, the generator still runs and still "
                "looks successful — it just never writes any output table. "
                "Nothing errors. The artifact is simply smaller.",
        ok="## 2. Source Tables\n"
           "## 3. Execution DAG\n"
           "## 4. DataFrame Variable Map\n"
           "## 5. Transformation Plan\n"
           "## 6. Output Targets\n\n"
           "All five present -> the generator\n"
           "reads sources, steps and targets.",
        bad="## 2. Source Tables\n"
            "## 3. Execution DAG\n"
            "## 4. DataFrame Variable Map\n"
            "## 5. Transformation Plan\n\n"
            "Section 6 missing -> every step is\n"
            "generated and NOTHING is written\n"
            "to any table. No error is raised."),

    "MD002": dict(
        means="Every step in the plan must say what it reads, what it produces, "
              "and how confident the translation is. Three fields, on every step.",
        matters="A step missing its output name generates no code at all. It "
                "still appears in the plan, still reads like planned work, and "
                "simply never reaches the SQL. This is the most expensive way a "
                "plan can be wrong, because everything looks complete.",
        ok="### Step s02 | `Group By` | `AGGREGATE`\n"
           "- **In:** `df_formula_s01`\n"
           "  | **Out:** `df_group_by_s02`\n"
           "  | **Confidence:** `HIGH`",
        bad="### Step s02 | `Group By` | `AGGREGATE`\n"
            "- **In:** `df_formula_s01`\n"
            "  | **Confidence:** `HIGH`\n\n"
            "No **Out:** -> this step produces\n"
            "no CTE, and says nothing about it."),

    "MD003": dict(
        means="The plan draws a diagram of the pipeline and separately lists each "
              "step. This checks the two agree: every box in the diagram is either "
              "a declared source, a described step, or a declared output.",
        matters="A name in the diagram that nothing defines means the plan refers "
                "to data it never accounts for — either a step nobody described, "
                "or an input that comes from nowhere.",
        ok="DAG:  src_a -> df_filter_s01\n"
           "      df_filter_s01 -> cat.gold.out\n\n"
           "src_a        declared in section 2\n"
           "df_filter_s01 has a step section\n"
           "cat.gold.out declared in section 6",
        bad="DAG:  df_ghost_s09 -> cat.gold.out\n\n"
            "df_ghost_s09 is produced by no\n"
            "step, declared by no source, and\n"
            "written by no target. The plan\n"
            "reads as if the data comes from\n"
            "somewhere and never says where."),

    "MD004": dict(
        means="When the translator is unsure about a step it marks it LOW "
              "confidence. This checks that it also explains WHAT it is unsure "
              "about.",
        matters="The whole point of the review gate is a person approving the "
                "meaning of each step. A step marked LOW with no explanation asks "
                "for approval of something the document declines to describe — and "
                "LOW is exactly where the review was worth having.",
        ok="- **Confidence:** `LOW`\n\n"
           "**Semantic caveats:**\n"
           "- FIRST(Rate) is order-dependent.\n"
           "  SQL does not guarantee which row\n"
           "  wins without an ORDER BY.",
        bad="- **Confidence:** `LOW`\n"
            "- **Translation:** deterministic\n\n"
            "Nothing else. The reviewer is\n"
            "asked to approve a risk the plan\n"
            "will not name."),

    "MD005": dict(
        means="The plan must state how much of itself was produced by the "
              "transpiler and how much by an AI model.",
        matters="A step translated by the rule-based transpiler and one written by "
                "a model carry very different warranties, and you cannot tell them "
                "apart by reading the prose. Without this line a reader has no way "
                "to know which half they are looking at.",
        ok="## 9. Coverage Report\n\n"
           "55 of 55 steps were translated\n"
           "deterministically from DOMO's own\n"
           "tile vocabulary. 0 by model.",
        bad="## 9. Coverage Report\n\n"
            "All steps translated successfully.\n\n"
            "'Successfully' by what? The reader\n"
            "cannot tell rules from guesses."),

    # -- the generated code ------------------------------------------------- #
    "STR001": dict(
        means="Each block of generated SQL is wrapped in markers naming the DOMO "
              "tile it came from. This checks every marker opens, closes, and is "
              "used once.",
        matters="Those markers are how everything downstream finds its way back to "
                "a tile: the medallion split, the per-step review, and 'show me the "
                "code for this finding'. Broken markers break all three at once.",
        ok="-- [node: df_join_s06] op=JOIN\n"
           "df_join_s06 AS (\n"
           "  SELECT ... FROM a JOIN b ...\n"
           ")\n"
           "-- [/node: df_join_s06]",
        bad="-- [node: df_join_s06] op=JOIN\n"
            "df_join_s06 AS (\n"
            "  SELECT ... FROM a JOIN b ...\n"
            ")\n"
            "-- [node: df_next_s07] op=SELECT\n\n"
            "Never closed -> this block silently\n"
            "swallows the next one."),

    "STR002": dict(
        means="The generator reports which steps it produced. This checks each one "
              "is genuinely in the file.",
        matters="Guards against an artifact that parses perfectly and quietly "
                "dropped steps. It is exactly what a mis-scoped parser produces, "
                "and the file gives no sign of it.",
        ok="claimed: s01, s02, s03\n"
           "present: s01, s02, s03\n\n"
           "Every step the generator says it\n"
           "wrote is actually in the file.",
        bad="claimed: s01, s02, s03\n"
            "present: s01,      s03\n\n"
            "s02 was reported and never\n"
            "written. The SQL still runs — it\n"
            "just skips a transformation."),

    "STR003": dict(
        means="The translator leaves a placeholder where it could not finish. This "
              "checks none of them survived into the final artifact.",
        matters="A placeholder that reaches production is a hole in the pipeline "
                "wearing the shape of finished work.",
        ok="SELECT\n"
           "  last_day(`Date`) AS `Period_End`\n"
           "FROM src",
        bad="SELECT\n"
            "  __PENDING_3__ AS `Period_End`\n"
            "FROM src\n\n"
            "Also caught: <<TRANSLATE_ME>>,\n"
            "TODO: translate"),

    "DET001": dict(
        means="When a query picks 'the first value' in a group, it must say how "
              "the rows are ordered. Otherwise 'first' means whichever row the "
              "engine happened to reach first.",
        matters="Real case, dataflow 8099: FIRST(Exchange Rate) inside a group with "
                "no ordering. The answer depends on how Spark split the data, so "
                "the same input gives a different exchange rate on a different day. "
                "It can pass reconciliation on Monday and fail on Tuesday with "
                "nothing having changed.",
        ok="first(`Exchange_Rate`) OVER (\n"
           "  PARTITION BY `Currency`\n"
           "  ORDER BY `Effective_Date` DESC\n"
           ")\n\n"
           "'First' now means something.",
        bad="first(`Exchange_Rate`)\n"
            "  ... GROUP BY `Currency`\n\n"
            "No ordering. Whichever row the\n"
            "engine reached first wins, and\n"
            "that changes between runs."),

    "DET002": dict(
        means="A cross join pairs every row on the left with every row on the "
              "right. This flags each one for a human to confirm.",
        matters="Real case, 8099: a cross join against a frame filtered to one row. "
                "Correct — while that filter matches exactly one row. If it ever "
                "matches two, every downstream row silently doubles and the totals "
                "still look plausible. That is the dangerous part: no error, and a "
                "number that looks like a number.",
        ok="-- exactly one row by construction;\n"
           "-- verified: MAX(cnt) = 1\n"
           "FROM facts\n"
           "CROSS JOIN (SELECT rate FROM cfg\n"
           "            WHERE id = 'GLOBAL')",
        bad="FROM facts\n"
            "CROSS JOIN (SELECT rate FROM cfg\n"
            "            WHERE region = 'NA')\n\n"
            "If 'NA' ever matches two config\n"
            "rows, every total doubles and\n"
            "nothing complains."),

    "SEM001": dict(
        means="When a number is converted to a decimal type, the conversion must "
              "state how many digits and decimal places to keep.",
        matters="Spark defaults a bare decimal to 10 digits and ZERO decimal "
                "places. Every amount silently loses its cents. In a "
                "reconciliation pipeline that is catastrophic and completely "
                "invisible — the job succeeds, the totals are just wrong.",
        ok="CAST(`Amount` AS DECIMAL(18, 2))\n\n"
           "1234.56 stays 1234.56",
        bad="CAST(`Amount` AS DECIMAL)\n\n"
            "Defaults to DECIMAL(10, 0).\n"
            "1234.56 becomes 1235.\n"
            "No warning, no error."),

    "SEM002": dict(
        means="DOMO stamps its own bookkeeping columns onto ingested data — things "
              "like the batch number and when the batch last ran. This flags "
              "business logic that depends on them.",
        matters="Those columns are produced by DOMO's ingestion layer, not by your "
                "source system. Databricks ingestion numbers batches differently. "
                "The expression compiles fine and computes something else.",
        ok="WHERE `Ship_Date`\n"
           "      >= date_sub(current_date, 30)\n\n"
           "Depends on the data, which survives\n"
           "the migration.",
        bad="WHERE `_BATCH_LAST_RUN_`\n"
            "      > '2025-05-31 00:00:00'\n\n"
            "Depends on DOMO's own ingestion\n"
            "bookkeeping, which does not exist\n"
            "in Databricks."),

    "SEM003": dict(
        means="Someone has hand-pinned a specific DOMO batch number to a specific "
              "date, inside the logic.",
        matters="Real case, 8099: WHEN _BATCH_ID_ = 2 THEN '2025-05-31'. A person "
                "patched one batch to one period by hand. Re-ingesting into "
                "Databricks renumbers the batches, so this rule quietly attaches "
                "itself to a different batch and keeps producing confident, wrong "
                "answers. It must become a mapping keyed on something stable.",
        ok="JOIN period_map pm\n"
           "  ON pm.`Source_File` = f.`Source_File`\n"
           "SELECT pm.`Period_End`\n\n"
           "Keyed on something that survives\n"
           "re-ingestion.",
        bad="CASE WHEN `_BATCH_ID_` = 2\n"
            "     THEN '2025-05-31'\n"
            "     WHEN `_BATCH_ID_` = 3\n"
            "     THEN '2025-06-30' END\n\n"
            "Batch 2 in Databricks is not the\n"
            "same data as batch 2 in DOMO."),

    "SEM004": dict(
        means="Columns referred to by position rather than by name — C, C2, C4, "
              "column_59 — get surfaced for review.",
        matters="Real case, 8099: C4 is mapped to Settlement Date, C3 to Company, "
                "C5 to Currency. If the upstream file ever gains one column, every "
                "mapping shifts by one. Settlement Date becomes Currency. Nothing "
                "errors, because C4 still exists.",
        ok="SELECT `Settlement_Date`,\n"
           "       `Company`,\n"
           "       `Currency`\n"
           "FROM remittance_feed",
        bad="SELECT `C4` AS `Settlement_Date`,\n"
            "       `C3` AS `Company`,\n"
            "       `C5` AS `Currency`\n\n"
            "One new column upstream and every\n"
            "one of these is now wrong."),

    "SEM005": dict(
        means="Stacking datasets together while allowing them to have different "
              "columns. This flags each such union.",
        matters="Real case, 8099: seven datasets stacked with missing columns "
                "allowed. That setting hides a column appearing or disappearing in "
                "any of the seven. The failure does not surface as an error — it "
                "surfaces as unexplained blanks in the summary, weeks later.",
        ok="SELECT a, b, c FROM q1\n"
           "UNION ALL\n"
           "SELECT a, b, c FROM q2\n\n"
           "Same columns, stated. A change\n"
           "upstream fails loudly.",
        bad="unionByName(other,\n"
            "  allowMissingColumns=True)\n\n"
            "A dropped column becomes nulls\n"
            "instead of an error, and the\n"
            "summary quietly under-reports."),

    "LIN001": dict(
        means="Every intermediate result the SQL reads from must have been defined "
              "earlier in the same file.",
        matters="Catches the case where source reads were left out entirely — the "
                "plan documents the sources in a table, and the code never actually "
                "reads them, leaving every step pointing at a name that does not "
                "exist.",
        ok="src_a AS (SELECT * FROM bronze.a),\n"
           "step1 AS (SELECT * FROM src_a)\n\n"
           "src_a is defined before it is used.",
        bad="step1 AS (SELECT * FROM src_a)\n\n"
            "src_a is never defined. The whole\n"
            "artifact fails on the first run —\n"
            "or worse, resolves to an unrelated\n"
            "table that happens to exist."),

    "POL001": dict(
        means="Looks for passwords, tokens, API keys or connection strings written "
              "directly into the generated file.",
        matters="These artifacts get committed to version control and shared in "
                "reviews. A credential in one is a credential published. The check "
                "never echoes the value it found, only that it found one.",
        ok="options(\n"
           "  'password',\n"
           "  dbutils.secrets.get('etl', 'pw')\n"
           ")",
        bad="options('password', 'Pr0dDB!2024')\n\n"
            "Placeholders are deliberately NOT\n"
            "flagged: <your-password>,\n"
            "xxxxxx, changeme."),
}

#: Logic parity. Not judges — a separate stage that compares the generated SQL
#: against the DOMO graph it came from. Two independent derivations of the same
#: pipeline; the check is that they agree.
PARITY = [
    dict(rid="PAR-1", title="Every tile has a CTE", kind="structure",
         means="Walk the DOMO diagram back from each output and confirm every tile "
               "on the way produced a block of SQL.",
         matters="A tile that emitted nothing is a transformation that silently "
                 "did not happen. The query still runs and returns rows.",
         ok="This target's chain: 12 tiles\n"
            "CTEs found:           12\n\n"
            "Each tile emitted exactly one.",
         bad="This target's chain: 12 tiles\n"
             "CTEs found:           11\n\n"
             "Missing: Alter Columns 4\n"
             "(df_alter_columns_4_s12)\n\n"
             "That column conversion never ran."),

    dict(rid="PAR-2", title="Every DOMO edge is wired", kind="lineage",
         means="In DOMO, tile A feeds tile B. In the SQL, block B must actually "
               "read from block A. This checks every connection survived.",
         matters="A dropped connection means a step reads the wrong upstream data. "
                 "Both versions have the same number of steps, so a count-based "
                 "check would pass.",
         ok="DOMO: join_s06 -> formula_s07\n"
            "SQL:  formula_s07 reads join_s06\n\n"
            "Each block reads exactly the\n"
            "upstream tiles DOMO declares.",
         bad="DOMO: join_s06 -> formula_s07\n"
             "SQL:  formula_s07 reads src_a\n\n"
             "The join result is computed and\n"
             "then ignored. The formula runs\n"
             "against un-joined data."),

    dict(rid="PAR-3", title="No unexplained CTEs", kind="structure",
         means="The reverse check: every block in the SQL must trace back to a real "
               "DOMO tile.",
         matters="A block matching no tile is code nobody asked for. At best it is "
                 "dead weight; at worst it is a branch that changes the result and "
                 "corresponds to nothing anyone reviewed.",
         ok="CTEs in artifact: 12\n"
            "Traced to a tile: 12\n\n"
            "Nothing invented.",
         bad="CTEs in artifact: 13\n"
             "Traced to a tile: 12\n\n"
             "Unexplained: df_temp_calc_x\n\n"
             "Where did this come from, and\n"
             "does anything read it?"),

    dict(rid="PAR-4", title="Chain ends at the target", kind="lineage",
         means="The last block of the query must be the tile DOMO actually "
               "publishes from.",
         matters="Ending one step early publishes the wrong thing — usually data "
                 "before a final filter or aggregation. The output looks right and "
                 "has too many rows.",
         ok="DOMO publishes from:\n"
            "  df_add_formula_12_s14\n"
            "Final CTE is:\n"
            "  df_add_formula_12_s14",
         bad="DOMO publishes from:\n"
             "  df_add_formula_12_s14\n"
             "Final CTE is:\n"
             "  df_group_by_10_s15\n\n"
             "Publishing from the wrong step."),

    dict(rid="PAR-5", title="Column references resolve", kind="lineage",
         severity="UNVERIFIABLE",
         means="Every column an expression reads must exist in what comes into that "
               "step — following DOMO's own rule that a formula can use a column an "
               "earlier formula in the same tile just created.",
         matters="A reference to a column that is not there fails at run time, or "
                 "silently resolves to a different column of the same name from "
                 "another branch.",
         ok="Step reads:  Ship_Date, Amount\n"
            "Available:   Ship_Date, Amount,\n"
            "             Customer, Region\n\n"
            "All references resolve.",
         bad="Step reads:  Ship_Dt\n"
             "Available:   Ship_Date, Amount\n\n"
             "`Ship_Dt` resolves to nothing\n"
             "upstream — a typo, or a column\n"
             "a dropped step was meant to add."),
]


def build(out: pathlib.Path) -> pathlib.Path:
    rules = {j.rule_id: j for j in DEFAULT_JUDGES}
    unexplained = sorted(set(rules) - set(PLAIN))
    if unexplained:
        raise SystemExit(
            f"{len(unexplained)} rule(s) have no slide: {unexplained}.\n"
            f"Add them to PLAIN in {pathlib.Path(__file__).name} — a deck that "
            f"omits a rule the platform runs is consulted at exactly the moment "
            f"somebody is deciding whether to trust the run.")
    stale = sorted(set(PLAIN) - set(rules))
    if stale:
        raise SystemExit(f"{len(stale)} slide(s) describe rules that no longer "
                         f"exist: {stale}. Remove them.")

    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    title_slide(
        prs,
        "Automated quality checks",
        "DOMO to Databricks migration  ·  what every check means",
        "The platform runs " + str(len(rules) + len(PARITY)) + " automated checks across three review gates, "
        "and stops for a person at each one.\n\n"
        "This deck explains every check in plain words: what it looks at, why it "
        "matters, and what passing and failing actually look like.\n\n"
        "Each slide states, top right, whether a finding on that check is a "
        "WARNING or a FAILURE — that is the first thing anyone wants to know, and "
        "it is read from the code rather than retyped here.\n\n"
        "One rule holds throughout, and the next slide is about it:\n"
        "a check that examined nothing is never reported as a pass.")

    verdict_slide(prs, rules)

    section_slide(
        prs, "GATE 1  ·  THE PLAN", "Before any code is written",
        "The migration plan describes what each DOMO tile must do, in words, with "
        "no code. Approving it means approving those semantics.\n\n"
        "These five checks make sure the plan is complete enough to generate from, "
        "and honest enough to approve.")
    for rid in ["MD001", "MD002", "MD003", "MD004", "MD005"]:
        j = rules[rid]
        check_slide(prs, rid=rid, title=j.title, kind=j.kind.value,
                    scope="the plan", severity=finding_verdict(j), **PLAIN[rid])

    section_slide(
        prs, "GATE 2  ·  THE GENERATED CODE", "Twelve rules over the SQL",
        "Each rule exists because the failure it catches was seen in a real DOMO "
        "dataflow. Several of the examples on the following slides are taken "
        "directly from dataflow 8099.\n\n"
        "The dangerous ones are not the rules that stop the query running. They "
        "are the ones where the query runs perfectly and returns a different "
        "number.")
    for rid in ["STR001", "STR002", "STR003", "DET001", "DET002", "SEM001",
                "SEM002", "SEM003", "SEM004", "SEM005", "LIN001", "POL001"]:
        j = rules[rid]
        scope = "the code" if j.applies_to else "every artifact"
        check_slide(prs, rid=rid, title=j.title, kind=j.kind.value,
                    scope=scope, severity=finding_verdict(j), **PLAIN[rid])

    section_slide(
        prs, "GATE 3  ·  LOGIC PARITY", "Does the SQL do what DOMO did?",
        "This is not a data comparison — nothing is executed. It compares two "
        "INDEPENDENT descriptions of the same pipeline: DOMO's own diagram, and "
        "the SQL that was generated from it.\n\n"
        "Where they disagree, something was lost in translation. Where a column's "
        "origin cannot be established, the result is reported as UNVERIFIABLE and "
        "is never counted as a pass.")
    for p in PARITY:
        entry = dict(p)
        # Only the column check can be impossible to run, so only it carries the
        # third badge. Claiming the others might be unverifiable would be a
        # hedge the code does not support.
        severity = entry.pop("severity", "FAIL")
        check_slide(prs, scope="each output table",
                    ok_label="Passes", bad_label="Fails",
                    severity=severity, **entry)

    unverifiable_slide(prs)

    # closing
    section_slide(
        prs, "READING A RESULT", "What the numbers mean",
        "GATES 1 AND 2 report a check score out of 100.\n"
        "     100    every check ran clean.\n"
        "     96     one warning out of twelve — a warning counts as half a finding.\n"
        "     92     one failure out of twelve.\n"
        "     —      nothing was checked. This is never shown as 100.\n\n"
        "GATE 3 reports a target three ways, and the middle one is the point.\n"
        "     verified      every check ran, and all of them passed.\n"
        "     passed        nothing wrong was found, but some checks could not run.\n"
        "     failed        the SQL and the DOMO graph disagree.\n\n"
        "An unverifiable check does not fail a target — but a target carrying one "
        "is never called verified, so a green result is never mistaken for a "
        "complete one.")

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out


def main() -> int:
    out = build(ROOT / "docs" / "migration_quality_checks.pptx")
    prs = Presentation(out)
    print(f"wrote {out.relative_to(ROOT)}  ({len(prs.slides.__iter__.__self__._sldIdLst)} slides)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
