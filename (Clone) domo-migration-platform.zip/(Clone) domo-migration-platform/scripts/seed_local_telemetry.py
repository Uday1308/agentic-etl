#!/usr/bin/env python3
"""scripts/seed_local_telemetry.py — put demo telemetry where LocalStore reads it.

>>> THIS SCRIPT INVENTS DATA. THAT IS ITS ENTIRE PURPOSE. <<<

``api.store_local.LocalStore`` deliberately never fabricates a telemetry row: if
nothing has written steps for a run it returns none, because a progress view that
shows phases nobody ran is worse than one that shows nothing. But the sample gate
payloads carry no telemetry either, so a fresh checkout serves an empty stage strip
and an empty cost panel, and there is nothing to look at while wiring the frontend.

This script is the honest way out. It writes step, ingestion, judge and parity rows
for the two sample runs into ``.platform_local/telemetry/<run_id>/``, derived where
possible from things that ARE real — ``AGENT_PHASES`` from ``agents/master.py``, the
judge results and parity verdicts in the gate payloads, the input dataset names in
``8099_standardized.json``. Row counts, timings and batch ids are made up.

Because it lives in a separate file with this docstring, nothing in the serving path
can be mistaken for a simulator. Delete ``.platform_local`` to get back to the truth::

    python scripts/seed_local_telemetry.py            # write demo rows
    python scripts/seed_local_telemetry.py --clear    # remove them again

Two things it does NOT fake, because they are load-bearing in the UI:

* **8099 makes zero model calls.** ``llm_calls.jsonl`` is left empty for it. "0 calls,
  $0.00" is the documented success state for a fully deterministic dataflow, and
  seeding fictional spend there would teach the wrong lesson about the product.
* **The md_plan gate stays open.** Its final phase is written as ``interrupted``, not
  ``ok``, so the review view has something to ask a human about.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.master import AGENT_ORDER, AGENT_PHASES  # noqa: E402
from core.contracts.telemetry import (  # noqa: E402
    IngestionRow,
    IngestPurpose,
    JudgeRow,
    LlmCallRow,
    StepRow,
    StepStatus,
    ValidationRow,
)

SAMPLES = ROOT / "docs" / "frontend" / "samples"
START = dt.datetime(2026, 9, 9, 10, 12, 4, tzinfo=dt.timezone.utc)

#: agent -> seconds each of its phases took. Invented, but ordered the way a real run
#: is: discovery and codegen dominate, connection is a blink.
PHASE_SECONDS = {"connection": 3, "standardization": 8, "discovery": 21,
                 "md_plan": 34, "cd_codegen": 47, "validation": 96, "classifier": 12}


def _write(run_dir: pathlib.Path, kind: str, rows: list) -> int:
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / f"{kind}.jsonl"
    path.write_text("".join(r.model_dump_json() + "\n" for r in rows), encoding="utf-8")
    return len(rows)


def _steps(run_id: str, upto: str, *, open_gate: bool) -> list[StepRow]:
    """One row per phase, through ``upto``, in ``AGENT_ORDER``.

    Phases come from ``AGENT_PHASES`` rather than being typed out here: the UI renders
    those strings verbatim, so a demo that invented its own would be showing progress
    text the platform never emits.
    """
    rows: list[StepRow] = []
    clock = START
    for agent in AGENT_ORDER:
        phases = AGENT_PHASES[agent]
        for i, phase in enumerate(phases):
            last_phase = i == len(phases) - 1
            final_agent = agent == upto
            duration = PHASE_SECONDS.get(agent, 10) * 1000 // max(len(phases), 1)
            status = StepStatus.OK
            if final_agent and last_phase and open_gate:
                status = StepStatus.INTERRUPTED
            rows.append(StepRow(
                run_id=run_id, ts=clock.isoformat(), environment="dev",
                step_id=f"{agent}-{i + 1}", agent=agent, phase=phase,
                phase_index=i, phase_count=len(phases), iteration=1,
                status=status, duration_ms=duration,
                detail="awaiting review" if status is StepStatus.INTERRUPTED else ""))
            clock += dt.timedelta(milliseconds=duration)
        if agent == upto:
            break
    return rows


def _ingestions(run_id: str, dataflow_id: str) -> list[IngestionRow]:
    """One row per real input dataset of the flow, with invented counts.

    Names are read from the standardized export, so the dataset list on screen is the
    actual one. ``rows_ingested`` equals ``domo_row_count`` so the UI's count-match
    indicator reads green; make them differ if you want to see the other state.
    """
    export = ROOT / f"{dataflow_id}_standardized.json"
    if not export.exists():
        return []
    doc = json.loads(export.read_text(encoding="utf-8"))[dataflow_id]
    rows = []
    for i, src in enumerate(doc.get("inputs") or [], start=1):
        name = src.get("dataSourceName", "")
        table = "".join(c if c.isalnum() else "_" for c in name.lower()).strip("_")
        count = 12_000 * i + 4_321
        rows.append(IngestionRow(
            run_id=run_id, ts=START.isoformat(), environment="dev",
            dataset_id=src.get("dataSourceId", ""), dataset_name=name,
            purpose=IngestPurpose.CREATION,
            target_table=f"dev_test.domo_input.{table}",
            rows_ingested=count, domo_row_count=count,
            batch_id=4, batch_last_run="2026-09-26T14:02:07.000+00:00",
            bytes_ingested=count * 512, duration_ms=1800 + 90 * i,
            status="ok", used_domo_api=False))
    return rows


def _judges(run_id: str) -> list[JudgeRow]:
    """Judge rows lifted straight out of the gate payloads — these are not invented."""
    rows = []
    for f in sorted(SAMPLES.glob("gate_*.json")):
        gate = json.loads(f.read_text(encoding="utf-8"))
        if gate.get("run_id") != run_id:
            continue
        for j in gate.get("judges") or []:
            rows.append(JudgeRow(
                run_id=run_id, ts=START.isoformat(), environment="dev",
                agent=gate["agent"], iteration=gate.get("iteration", 1),
                rule_id=j["rule_id"], title=j.get("title", ""), kind=j.get("kind", ""),
                verdict=j["verdict"], findings=j.get("findings", 0),
                checked=j.get("checked", 0), nodes=tuple(j.get("nodes") or []),
                note=j.get("note", "")))
    return rows


def _validations(run_id: str) -> list[ValidationRow]:
    """Parity rows from the validation gate — also real, not invented."""
    rows = []
    for f in sorted(SAMPLES.glob("gate_validation*.json")):
        gate = json.loads(f.read_text(encoding="utf-8"))
        if gate.get("run_id") != run_id:
            continue
        for r in gate.get("results") or []:
            rows.append(ValidationRow(
                run_id=run_id, ts=START.isoformat(), environment="dev",
                dataflow_id=gate["dataflow_id"], **r))
    return rows


def _degraded_llm_calls(run_id: str) -> list[LlmCallRow]:
    """Model calls for 7412 only, which has two by-model steps.

    8099 gets none, deliberately: it is 100% deterministic and its zero-cost panel is
    a feature of the product, not a gap in this script.
    """
    calls = []
    for i, (node, role) in enumerate([("s07", "generator"), ("s07", "evaluator"),
                                      ("s14", "generator"), ("s14", "evaluator")],
                                     start=1):
        tin, tout = (11_400, 2_180) if role == "generator" else (9_240, 320)
        calls.append(LlmCallRow(
            run_id=run_id, ts=(START + dt.timedelta(seconds=i * 7)).isoformat(),
            environment="dev", call_id=f"c-7412-{i:02d}", agent="md_plan", node=node,
            iteration=1, role=role, model="claude-sonnet-5", pool="shared",
            tokens_in=tin, tokens_out=tout, tokens_cached=8_100,
            cost_usd=round(tin * 3e-6 + tout * 15e-6, 4),
            latency_ms=3_900 if role == "generator" else 2_100,
            status="ok", prompt_hash=f"p-{i:04x}", attempt=1))
    return calls


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--work", default=str(ROOT / ".platform_local"),
                    help="LocalStore working directory (default: .platform_local)")
    ap.add_argument("--clear", action="store_true",
                    help="delete the seeded telemetry and exit")
    args = ap.parse_args(argv)

    work = pathlib.Path(args.work)
    if args.clear:
        if work.exists():
            shutil.rmtree(work)
            print(f"removed {work}")
        else:
            print(f"{work} does not exist; nothing to clear")
        return 0

    gates = [json.loads(f.read_text(encoding="utf-8"))
             for f in sorted(SAMPLES.glob("gate_*.json"))]
    if not gates:
        raise SystemExit(f"no gate payloads under {SAMPLES}; nothing to seed from")

    runs: dict[str, str] = {}
    for g in gates:
        runs.setdefault(g["run_id"], g["dataflow_id"])

    print("seeding DEMO telemetry - invented rows, for wiring the UI only")
    for run_id, dataflow_id in sorted(runs.items()):
        agents_seen = [g["agent"] for g in gates if g["run_id"] == run_id]
        furthest = max(agents_seen, key=lambda a: AGENT_ORDER.index(a))
        run_dir = work / "telemetry" / run_id

        counts = {
            "steps": _write(run_dir, "steps",
                            _steps(run_id, furthest, open_gate=True)),
            "ingestions": _write(run_dir, "ingestions", _ingestions(run_id, dataflow_id)),
            "judges": _write(run_dir, "judges", _judges(run_id)),
            "validations": _write(run_dir, "validations", _validations(run_id)),
            "llm_calls": _write(run_dir, "llm_calls",
                                _degraded_llm_calls(run_id) if dataflow_id == "7412"
                                else []),
        }
        summary = ", ".join(f"{k}={v}" for k, v in counts.items())
        print(f"  {run_id}  (dataflow {dataflow_id}, through {furthest})")
        print(f"      {summary}")
        if dataflow_id == "8099":
            print("      llm_calls=0 on purpose: 8099 is deterministic and costs $0.00")

    print(f"\nwrote into {work}")
    print("start the API:  uvicorn api.app:app --reload --port 8000")
    print("undo:          python scripts/seed_local_telemetry.py --clear")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
