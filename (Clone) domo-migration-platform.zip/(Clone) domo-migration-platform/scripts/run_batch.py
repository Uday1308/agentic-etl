#!/usr/bin/env python3
"""scripts/run_batch.py - migrate a whole wave batch handed off by the wave planner.

The pipeline migrates ONE ETL per run (``run_pipeline``). The wave planner (source-intel Discovery, strategy A
"Dependency waves" or B "Complexity waves") decides which ETLs move together and in what order, and hands that
over as a bundle:

    <bundle>/manifest.json          kind=etl_logic_migration, manifest_version=1: the ETLs in dependency order,
                                    every input classified (source / earlier_wave / this_batch / other_batch /
                                    temporary_snapshot / unplanned), target naming
    <bundle>/etls/<etl_id>.json     each ETL's unmodified source definition

The same bundle also carries hand-picked ETLs (``selection.etl_ids`` instead of batch ids; the ETL migration app's
"New run -> Pick ETLs"): a batch of one or N, run exactly like a wave batch.

This runner walks the manifest in order and runs the per-ETL pipeline for each, with the target naming from the
manifest (so nothing about catalogs / schemas is hard-coded per run). It migrates LOGIC only - landing source data
and moving data is the data-movement accelerator's job; inputs it would need are listed in the batch report.

    python scripts/run_batch.py --bundle <dir> [--volume ./ex_volume] [--stop-at md_plan] [--keep-going]

Writes ``<volume>/batches/<batch-key>/<batch_run_id>.json`` (one report per batch run) and prints a summary.
Exit code 1 when any ETL failed.

Statuses (ADR 032 section 3): ``migrated``; ``awaiting_review`` (the review rule left a gate open: a unit is
not ``mapped``); ``blocked`` (a dependant of an ``awaiting_review`` or ``failed`` ETL); ``skipped`` (an earlier
ETL failed and ``--keep-going`` is off); ``unsupported`` (no source pack for the bundle's platform); ``failed``;
``stopped`` (``--stop-at``). ``--resume <batch_run_id>`` reruns only ETLs whose review items were approved, plus
their ``blocked`` dependants, reusing each human approval whose gate payload hash is unchanged.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import pathlib
import sys
from collections import Counter
from datetime import UTC, datetime

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

# Trust the OS certificate store (corporate TLS inspection), like the portal; skipped when a CA bundle is set.
if not (os.getenv("SSL_CERT_FILE") or os.getenv("REQUESTS_CA_BUNDLE")):
    try:
        import truststore

        truststore.inject_into_ssl()
    except ImportError:
        pass

import inspect  # noqa: E402

from e2e_mock_run import AGENT_ORDER, run_pipeline  # noqa: E402

from core.lakebridge import tier1_from_env, tier1_label  # noqa: E402
from core.packs import UnknownSourcePlatform, get_pack  # noqa: E402
from core.review import AWAITING_REVIEW, BATCH_STATUSES, counts_of, normalize_status  # noqa: E402
from core.runner import HarnessGates  # noqa: E402
from core.runner import run_pipeline as core_run_pipeline  # noqa: E402

# A fresh copy of the harness from the migrator's own repo may not take `naming` yet: then the harness defaults are
# used and the batch report says so (instead of failing the batch).
ACCEPTS_NAMING = "naming" in inspect.signature(run_pipeline).parameters
ACCEPTS_REUSE = "reuse_approvals" in inspect.signature(run_pipeline).parameters

SUPPORTED = {"1", "2"}
NEEDS_DATA = ("source", "temporary_snapshot", "other_batch", "unplanned")


def load_bundle(bundle: pathlib.Path) -> dict:
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("kind") != "etl_logic_migration":
        raise SystemExit(f"{bundle}: not an ETL logic migration manifest (kind={manifest.get('kind')!r})")
    if str(manifest.get("manifest_version")) not in SUPPORTED:
        raise SystemExit(f"{bundle}: manifest_version {manifest.get('manifest_version')} not supported "
                         f"(this runner reads {sorted(SUPPORTED)})")
    version = str(manifest.get("manifest_version"))
    platform = _platform(manifest)
    if version == "1" and platform != "domo":
        raise SystemExit(f"{bundle}: a {platform} bundle needs manifest_version 2 (the dispositions, target_map and "
                         f"file_loads of ADR 032 section 7); re-export the hand-off")
    if version == "2" and not (manifest.get("source") or {}).get("id"):
        raise SystemExit(f"{bundle}: a version 2 manifest names its source (source.id)")
    return manifest


def naming_of(manifest: dict) -> dict:
    t = manifest.get("target") or {}
    return {"source_catalog": t.get("source_catalog"), "source_schema": t.get("source_schema"),
            "target_catalog": t.get("target_catalog"), "target_schema": t.get("target_schema"),
            "layer_catalog": t.get("target_catalog")}


def selection_key(selection: dict) -> str:
    """The batch id(s), ``etls-<ids>`` for hand-picked ETLs, else ``wave-<n>`` (as Discovery names the bundle)."""
    if selection.get("key"):                         # manifest v2: path-safe, set by Discovery
        return str(selection["key"])
    if selection.get("batch_ids"):
        return "-".join(selection["batch_ids"])
    ids = [str(i) for i in selection.get("etl_ids") or []]
    if ids:
        return "etls-" + ("-".join(ids) if len(ids) <= 3 else f"{ids[0]}-and-{len(ids) - 1}-more")
    return f"wave-{selection.get('wave')}"


def prerequisites(manifest: dict) -> list[dict]:
    """What must exist in the target before these ETLs can RUN (not to migrate their logic)."""
    out: dict[tuple[str, str], dict] = {}
    for e in manifest["etls"]:
        for i in e.get("inputs", []):
            if i.get("availability") in NEEDS_DATA:
                key = (i["availability"], i["dataset_id"])
                row = out.setdefault(key, {**i, "needed_by": []})
                row["needed_by"].append(e["etl_id"])
    return sorted(out.values(), key=lambda r: (r["availability"], r["name"]))


def _platform(manifest: dict) -> str:
    return str((manifest.get("source") or {}).get("platform") or "domo").strip().lower()


def batch_coverage(rows: list[dict]) -> dict:
    """Unit coverage summed over the ETLs that reached cd_codegen (ADR 032 section 3)."""
    keys = ("mapped", "transpiled", "ai", "manual", "unresolved")
    counts = dict.fromkeys(keys, 0)
    for r in rows:
        for k in keys:
            counts[k] += int((r.get("coverage") or {}).get(k) or 0)
    total = sum(counts.values())
    share = {k: (round(100.0 * v / total, 1) if total else 0.0) for k, v in counts.items()}
    return {**counts, "total": total, "share": share}


def find_report(volume: pathlib.Path, batch_run_id: str) -> pathlib.Path:
    hits = sorted((volume / "batches").glob(f"*/{batch_run_id}.json")) if (volume / "batches").exists() else []
    if not hits:
        raise SystemExit(f"no batch report {batch_run_id!r} under {volume / 'batches'}")
    return hits[0]


def feedback_dir(work: pathlib.Path) -> pathlib.Path:
    """Where the API store writes review decisions. ``--work`` is the store ROOT (PLATFORM_ROOT) and ``LocalStore``
    keeps its work files under ``<root>/.platform_local``; a bare ``<work>/feedback`` (tests, older layouts) is the
    fallback. Reading the wrong one made every resume miss the human approvals."""
    store = pathlib.Path(work) / ".platform_local" / "feedback"
    return store if store.is_dir() else pathlib.Path(work) / "feedback"


def _ledger_of(work: pathlib.Path):
    """S11: the per-unit decision ledger the API writes next to the feedback files (carry-over of approvals)."""
    from core.decision_ledger import LEDGER_NAME, DecisionLedger

    return DecisionLedger(feedback_dir(work) / LEDGER_NAME)


def approvals_of(row: dict, work: pathlib.Path) -> dict[str, dict] | None:
    """agent -> the human approval of each gate the review rule held, or None while any is unresolved.

    A held gate counts as resolved only by an APPROVING review (``work/feedback/<gate>.approval.json``,
    written by the API store); the approval carries the payload hash it was given for.
    """
    run_dir = pathlib.Path(row.get("run_dir") or "")
    held = row.get("review_gates") or []
    out: dict[str, dict] = {}
    fb = feedback_dir(work)
    for g in held:
        path = fb / f"{g['gate_id']}.approval.json"
        if not path.exists():
            return None
        try:
            approval = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            return None
        if not approval.get("approve"):
            return None
        gate_file = run_dir / "gates" / f"{g['gate_id']}.json"
        approved_hash = approval.get("payload_hash") or (
            json.loads(gate_file.read_text(encoding="utf-8")).get("payload_hash") if gate_file.exists() else "")
        out[g["agent"]] = {"payload_hash": approved_hash, "reviewer": approval.get("reviewer", ""),
                           "decision_id": approval.get("decision_id") or g["gate_id"],
                           # hand-written code (unit id -> artifact ref) and out-of-scope reasons of this review
                           **{k: dict(approval[k]) for k in ("edits", "out_of_scope") if approval.get(k)}}
    return out


# --------------------------------------------------------------------------------- every asset gets a row (3.2)
UNIT_STATUS_OF_ROUTE = {"lift": "lifted", "retire": "retired", "absorbed": "absorbed", "unsupported": "unsupported"}
PACK_ROUTE = {"translate": "rebuild", "file_load": "file_load", "statement": "statement", "federated": "federated"}
GOVERNANCE_ETL_ID = "__governance__"
PARITY_ETL_ID = "__parity__"           # Q10: the batch-level parity review (packs.snowflake.parity_batch)
PROPOSED = "proposed"      # ADR 034: handed to the access framework; non-blocking in the roll-up (not an issue)


def _native(asset_id: str) -> str:
    return str(asset_id).split(":", 2)[-1]


def _ids(items: list | None) -> list[str]:
    return [str(i["dataset_id"]) for i in items or [] if isinstance(i, dict) and i.get("dataset_id")]


def unit_rows_of(manifest: dict) -> list[dict]:
    """The manifest rows that become units, in run order: ``etls[]`` (rebuild, statement) then the in-scope
    ``file_loads[]`` (an explicit pick of a pipe; a wave batch lists its file loads but does not run them)."""
    etls = sorted(manifest.get("etls", []), key=lambda x: x["order"])
    base = max((int(e["order"]) for e in etls), default=0)
    loads = [fl for fl in manifest.get("file_loads", []) if fl.get("in_scope", False)]
    extra = [{"order": base + i + 1, "etl_id": fl.get("etl_id") or _native(fl["asset_id"]), "depends_on_etls": [],
              "batch_id": None, "unit_kind": "file_load", "inputs": [], **fl} for i, fl in enumerate(loads)]
    return etls + extra


def rollup(counts: dict, units_total: int) -> str:
    """Batch status (docs/plans/migrator-experience.md s2); Discovery's ``status_from_counts`` is the same rule."""
    if units_total == 0:
        return "nothing_to_build"
    if counts.get(AWAITING_REVIEW):
        return "needs_review"
    if any(counts.get(k) for k in ("failed", "blocked", "unsupported", "skipped")):   # ``proposed`` is not an issue
        return "completed_with_issues"
    return "completed"


def _artifacts_of(run) -> list[dict]:
    out, seen = [], set()
    for g in getattr(run, "gates", None) or []:
        for a in ((g.get("artifact") or {}).get("artifacts") or []):
            ref = a.get("artifact_ref") if isinstance(a, dict) else None
            if ref and ref not in seen:
                seen.add(ref)
                out.append({"ref": ref, "kind": a.get("kind", "sql"), "name": a.get("name", "")})
    return out


def governance_row(manifest: dict, assembly: dict | None) -> tuple[dict | None, list[dict]]:
    """``(the batch's governance unit row, one row per governance entry)``. An entry without a Databricks statement is
    not generated here (ADR 034): the migrated access is translated by the platform and proposed to the access
    framework, so the unit ends ``proposed`` ("Proposed for approval": non-blocking, a person approves the proposal
    there); with statements the ``batch_assembly`` gate holds them for review."""
    entries = list(manifest.get("governance") or [])
    if not entries:
        return None, []
    has = [bool(str(e.get("statement") or e.get("databricks") or "").strip()) for e in entries]
    if not any(has):
        status, reason = PROPOSED, (f"{len(entries)} policy binding(s) proposed to the access framework: a person "
                                    "approves the Unity Catalog row filters / column masks there")
    elif assembly and assembly.get("status") == "approved":
        status, reason = "migrated", ""
    else:
        status, reason = AWAITING_REVIEW, "governance artifacts are never auto-approved (batch_assembly gate)"
    unit = {"order": 10 ** 6, "etl_id": GOVERNANCE_ETL_ID, "asset_id": None, "name": "Governance (batch)",
            "batch_id": None, "status": status, "reason": reason, "route": "governance", "kind": "governance",
            "unit_id": "gate-batch_assembly", "gate_id": "gate-batch_assembly" if status == AWAITING_REVIEW else None,
            "artifacts": [], "inputs": [], "outputs": [], "target": None}
    rows = [{"asset_id": e.get("id") or e.get("name"), "etl_id": None, "name": e.get("name") or str(e.get("id")),
             "kind": f"{e.get('kind') or 'policy'}_policy", "route": "governance",
             "status": status if ok or status == PROPOSED else "unsupported",
             "reason": reason if ok or status == PROPOSED else "no Databricks statement for this binding yet",
             "unit_id": unit["unit_id"], "run_id": None, "artifacts": [],
             "inputs": [e["dataset_id"]] if e.get("dataset_id") else [],
             "outputs": [], "target": e.get("table")} for e, ok in zip(entries, has, strict=True)]
    return unit, rows


def build_rows(manifest: dict, results: list[dict], pack, units_by_id: dict[str, dict],
               governance: tuple[dict | None, list[dict]]) -> list[dict]:
    """The report rows: one per unit (an ETL, a pipe, a statement, the governance unit) and one per asset that is
    not a unit (lifted, retired, absorbed, unsupported, governance entries, rebuilt datasets mirroring their
    producer). ``etls`` keeps the unit rows the resume logic reads; ``rows`` is what the UI lists."""
    rows: list[dict] = []
    by_asset: dict[str, dict] = {}
    for r in results:
        e = units_by_id.get(str(r["etl_id"]), {})
        if r["etl_id"] == GOVERNANCE_ETL_ID:
            continue                                  # the unit lives in `etls`; its entries are the rows
        if r["etl_id"] == PARITY_ETL_ID:
            rows.append({**r, "inputs": [], "outputs": [], "artifacts": []})     # one row, no asset behind it
            continue
        route = r.get("route") or (PACK_ROUTE.get(pack.route_of(e)[0], "unsupported")
                                   if pack is not None and hasattr(pack, "route_of") and e else "rebuild")
        outs = e.get("outputs") or []
        if r.get("status") == "unsupported" and route in ("rebuild", "file_load", "statement"):
            route = "unsupported"       # the pack's router ended the unit unsupported (e.g. administration only)
        row = {**r, "kind": r.get("kind") or e.get("engine") or "dataflow", "route": route,
               "unit_id": r.get("unit_id") or r.get("run_id"),
               "gate_id": ((r.get("review_gates") or [{}])[0] or {}).get("gate_id"),
               "artifacts": r.get("artifacts") or [], "inputs": _ids(e.get("inputs")), "outputs": _ids(outs),
               "target": next((o.get("table") for o in outs if isinstance(o, dict) and o.get("table")), None)}
        row.setdefault("tiers", None)
        row.setdefault("run_id", None)
        rows.append(row)
        if row.get("asset_id"):
            by_asset[row["asset_id"]] = row
    gov_unit, gov_rows = governance
    rows += gov_rows
    seen = {r.get("asset_id") for r in rows if r.get("asset_id")}
    for o in manifest.get("other_assets") or []:
        if o["asset_id"] in seen:
            continue
        status = UNIT_STATUS_OF_ROUTE.get(o["route"])
        reason, unit_id = o.get("reason", ""), None
        if o["route"] == "rebuild":                       # a dataset rebuilt by its producer: same fate as the unit
            prod = by_asset.get(o.get("produced_by") or "")
            status = prod["status"] if prod else "blocked"
            reason = reason if prod is None or not prod.get("reason") else f"{reason}; {prod['reason']}"
        rows.append({"asset_id": o["asset_id"], "etl_id": None, "name": o.get("name"), "kind": o.get("kind"),
                     "route": o["route"], "status": status or "unsupported", "reason": reason, "unit_id": unit_id,
                     "run_id": None,
                     "artifacts": [], "inputs": list(o.get("inputs") or []), "outputs": list(o.get("outputs") or []),
                     "target": o.get("target"), "added_as_dependency": bool(o.get("added_as_dependency")),
                     **({"produced_by": o["produced_by"]} if o.get("produced_by") else {}),
                     **({"ingestx": o["ingestx"]} if o.get("ingestx") else {})})
        seen.add(o["asset_id"])
    for x in manifest.get("excluded_etls") or []:          # a picked ETL a decision keeps out: listed, not dropped
        if x.get("asset_id") in seen:
            continue
        disp = str(x.get("disposition") or "")
        route = x.get("route") or ("retire" if disp == "retire" else "lift")
        rows.append({"asset_id": x.get("asset_id"), "etl_id": x.get("etl_id"), "name": x.get("name"), "kind": "etl",
                     "route": route, "status": UNIT_STATUS_OF_ROUTE.get(route, "lifted"),
                     "reason": f"excluded: effective disposition is {disp or route}", "unit_id": None, "run_id": None,
                     "artifacts": [], "inputs": [], "outputs": [], "target": None})
    return rows


def build_lineage(rows: list[dict]) -> dict:
    """Nodes and edges over the picked assets plus their direct inputs / outputs."""
    nodes: dict[str, dict] = {}
    edges: set[tuple[str, str]] = set()

    def neighbour(a: str) -> str:
        nodes.setdefault(a, {"id": a, "name": _native(a), "kind": "asset", "route": None, "status": None,
                             "target": None})
        return a

    for r in rows:
        nid = str(r.get("asset_id") or f"etl:{r.get('etl_id')}")
        nodes[nid] = {"id": nid, "name": r.get("name"), "kind": r.get("kind"), "route": r.get("route"),
                      "status": r.get("status"), "target": r.get("target")}
    for r in rows:
        nid = str(r.get("asset_id") or f"etl:{r.get('etl_id')}")
        edges |= {(neighbour(str(i)), nid) for i in r.get("inputs") or []}
        edges |= {(nid, neighbour(str(o))) for o in r.get("outputs") or []}
    return {"nodes": list(nodes.values()), "edges": [{"from": a, "to": b} for a, b in sorted(edges)]}


async def run_batch(bundle: pathlib.Path, *, volume: pathlib.Path, work: pathlib.Path, stop_at: str = "",
                    keep_going: bool = False, column_style: str = "delta_safe", resume: str = "",
                    transpiler=None, translation_settings=None, llm_choice=None, verify=None, parity=None,
                    parity_ports=None, decisions=None) -> dict:
    """``parity``: a ``parity(batch_ctx) -> report`` hook; ``parity_ports``: ``(source, target, reason)`` for the
    standard hook (``packs.snowflake.parity_batch``; Q10). ``decisions``: the review decisions the sign-off pack lists
    (default: read from the work dir's feedback)."""
    manifest = load_bundle(bundle)
    naming = naming_of(manifest)
    started = datetime.now(UTC)
    key = selection_key(manifest["selection"])
    batch_run_id = f"batch-{key}-{started.strftime('%Y%m%dT%H%M%SZ')}"
    source_id = str((manifest.get("source") or {}).get("id") or (manifest.get("source") or {}).get("source_id") or "")
    previous: dict[str, dict] = {}
    if resume:
        prev = json.loads(find_report(volume, resume).read_text(encoding="utf-8"))
        previous = {str(r["etl_id"]): r for r in prev.get("etls", [])}
    try:
        pack = get_pack(_platform(manifest))
        unsupported_reason = ""
    except UnknownSourcePlatform as exc:
        pack, unsupported_reason = None, str(exc)
    results, failed = [], False
    outcomes: list = []
    packed = pack is not None and hasattr(pack, "run_etl")      # a pack with its own per-ETL runner (Snowflake)
    batch_ctx = None
    llm = None
    collab = None
    if packed:
        # the tier-2 translator comes from configuration (packs.snowflake.llm): serving | scripted | off
        from packs.snowflake.llm import build_translator, choose_llm

        llm = llm_choice or choose_llm()
        collab = pack.collaborators("mock")
        collab.extra["llm_translator"] = build_translator(llm, run_id=batch_run_id, volume=volume)
        collab.extra["llm_mode"] = llm.mode
        lb_mode = "injected" if transpiler is not None else "off"
        if transpiler is None and translation_settings is None:
            transpiler, translation_settings, lb_mode = tier1_from_env(volume=volume, batch_run_id=batch_run_id)
        # PHASE A (pure: no gate, no LLM): tier-0 leftovers -> ONE Transpiler call -> tier-1 cache; phase B reads it
        batch_ctx = pack.prepare_batch(manifest, bundle, work, source_id=source_id,
                                       settings=translation_settings, transpiler=transpiler, verify=verify)
    units = unit_rows_of(manifest)
    units_by_id = {str(u["etl_id"]): u for u in units}
    for e in units:
        row = {"order": e["order"], "etl_id": e["etl_id"], "asset_id": e.get("asset_id"), "name": e["name"],
               "batch_id": e.get("batch_id"), "added_as_dependency": bool(e.get("added_as_dependency")),
               "depends_on_etls": e.get("depends_on_etls", [])}
        if pack is None:
            results.append({**row, "status": "unsupported", "reason": unsupported_reason})
            continue
        before = previous.get(str(e["etl_id"]))
        reuse: dict[str, dict] = {}
        if before is not None:
            was = normalize_status(before.get("status"))
            if was == AWAITING_REVIEW:
                got = approvals_of(before, work)
                if got is None:      # review items still open: carried over unchanged
                    results.append({**before, **row, "status": AWAITING_REVIEW, "resumed_from": resume})
                    continue
                reuse = got
            elif was != "blocked":   # only resolved reviews and their blocked dependants rerun
                results.append({**before, **row, "resumed_from": resume})
                if packed and before.get("assembly_outcome"):   # the batch assembly still covers what ran before
                    outcomes.append(pack.outcome_from_dict(before["assembly_outcome"]))
                continue
        if failed and not keep_going:
            results.append({**row, "status": "skipped", "reason": "an earlier ETL in the batch failed"})
            continue
        broken = [d for d in e.get("depends_on_etls", [])
                  if any(r["etl_id"] == d and normalize_status(r["status"]) in ("failed", AWAITING_REVIEW, "blocked",
                                                                                "unsupported")
                         for r in results)]
        if broken:
            results.append({**row, "status": "blocked",
                            "reason": f"depends on ETL(s) {broken} that are not migrated"})
            continue
        route = "translate"
        if packed:           # the engine is checked BEFORE the definition (ADR 032 section 5)
            route, why = pack.route_of(e)
            if route == "unsupported":
                results.append({**row, "status": "unsupported", "reason": why})
                continue
        definition = e.get("definition")
        if route == "translate" and (not definition or not (bundle / definition).exists()):
            results.append({**row, "status": "failed", "reason": "no source definition in the bundle "
                            "(export-only ingest has no dataflow logic)"})
            failed = True
            continue
        stored_outcome = None
        try:
            kwargs: dict = {"naming": naming} if ACCEPTS_NAMING else {}
            if ACCEPTS_REUSE:
                kwargs.update(reuse_approvals=reuse, source_id=source_id)
            if packed:
                payload = (json.loads((bundle / definition).read_text(encoding="utf-8"))
                           if definition and (bundle / definition).exists() else None)
                run = await core_run_pipeline({**e, "payload": payload}, pack=pack,
                                              collaborators=collab,
                                              gates=HarnessGates(reuse, stop_at=stop_at, ledger=_ledger_of(work)),
                                              work=work, volume=volume,
                                              stop_at=stop_at, source_id=source_id, batch=batch_ctx)
                if getattr(run, "outcome", None) is not None:
                    outcomes.append(run.outcome)
                    stored_outcome = pack.outcome_to_dict(run.outcome)
            else:
                run = await run_pipeline(e["etl_id"], work=work, stop_at=stop_at, column_style=column_style,
                                         input_json=str(bundle / definition), volume=volume, **kwargs)
        except (SystemExit, Exception) as exc:  # one ETL must not take the batch down
            results.append({**row, "status": "failed", "reason": f"{type(exc).__name__}: {exc}"[:500]})
            failed = True
            continue
        held = list(getattr(run, "held", []))
        status = ("stopped" if stop_at and not held
                  else AWAITING_REVIEW if held else ("failed" if run.failures else "migrated"))
        status = getattr(run, "status_override", "") or status      # e.g. ``unsupported`` from a pack's router
        failed = failed or status == "failed"
        results.append({**row, "status": status, "run_id": run.run_id, "run_dir": str(run.artifacts),
                        "agents_completed": list(run.completed), "failures": list(run.failures),
                        "review_gates": held, **({"reused_approvals": sorted(reuse)} if reuse else {}),
                        **({"coverage": run.coverage} if getattr(run, "coverage", None) else {}),
                        **({"artifacts": _artifacts_of(run), "unit_id": run.run_id,
                            "source_definition_ref": getattr(run, "source_definition_ref", None)} if packed else {}),
                        **({"tiers": run.tiers} if getattr(run, "tiers", None) else {}),
                        **({"reason": run.reason} if getattr(run, "reason", "") else {}),
                        **({"assembly_outcome": stored_outcome} if stored_outcome else {}),
                        **({"resumed_from": resume} if resume else {})})
    assembly = None
    if packed and (outcomes or manifest.get("governance")):
        assembly = pack.finish_batch(manifest, outcomes, volume / "batches" / key / batch_run_id,
                                     gates=HarnessGates())
    gov = governance_row(manifest, assembly) if packed else (None, [])
    if gov[0] is not None:
        results.append(gov[0])                       # the batch's ONE governance unit
    parity_report = None
    if packed and batch_ctx is not None and (parity is not None or parity_ports is not None):
        from packs.snowflake import parity_batch as pb

        if parity is None:
            src, tgt, why = parity_ports
            parity = pb.make_hook(manifest, src, tgt, reason=why)
        parity_report = parity(batch_ctx)
        pb.attach_to_rows(results, units_by_id, parity_report)
        prev_row = previous.get(PARITY_ETL_ID)
        open_before = bool(prev_row) and normalize_status(prev_row.get("status")) == AWAITING_REVIEW
        approved = approvals_of(prev_row, work) if open_before else None
        pu = pb.parity_unit(parity_report, volume=volume, key=key, batch_run_id=batch_run_id,
                            gates=HarnessGates(approved or {}),
                            accepted_by=str(((approved or {}).get("validation") or {}).get("reviewer") or ""))
        if pu is not None:
            results.append(pu)             # a mismatch holds the batch: it is a unit that is awaiting review
    rows = build_rows(manifest, results, pack, units_by_id, gov)
    counts = counts_of(results)                      # units only: what needs work; `summary` counts every row
    units_total = len(results)
    summary = {"status": rollup(counts, units_total), "units_total": units_total,
               # mirrors (a view's dataset row, `produced_by` set) are never counted twice
               "by_route": dict(sorted(Counter(r["route"] for r in rows if not r.get("produced_by")).items())),
               "by_status": dict(sorted(Counter(r["status"] for r in rows if not r.get("produced_by")).items()))}
    report = {
        **({"assembly": assembly} if assembly else {}),
        # S3 / S4: post-conversion validation and data parity (both optional; absent = not requested)
        **({"verify": verify.summary()} if verify is not None else {}),
        **({"parity": parity_report} if parity_report is not None else {}),
        **({"translation": {"tier1": {**batch_ctx.tier1.as_dict(),
                                       "state": tier1_label(lb_mode, batch_ctx.tier1.as_dict())},
                            "llm": llm.mode, "llm_detail": llm.as_dict()}}
           if packed and batch_ctx is not None else {}),
        "batch_run_id": batch_run_id, "started_ts": started.isoformat(), "ended_ts": datetime.now(UTC).isoformat(),
        "bundle": str(bundle), "snapshot_id": manifest["snapshot_id"], "strategy": manifest["strategy"],
        "strategy_label": manifest.get("strategy_label"), "selection": manifest["selection"],
        "source": manifest.get("source"), "target": manifest.get("target"),
        "depends_on_batches": manifest.get("depends_on_batches", []),
        "prerequisites": prerequisites(manifest),
        "temporary_snapshots": manifest.get("temporary_snapshots", []),
        "etls": results,
        "rows": rows,
        "lineage": build_lineage(rows),
        "summary": summary,
        "counts": counts,
        "coverage": batch_coverage(results),
        "statuses": list(BATCH_STATUSES),
        "source_platform": _platform(manifest),
        **({"resumed_from": resume} if resume else {}),
        "logic_only": True,
        "naming_applied": ACCEPTS_NAMING,
        "warnings": [] if ACCEPTS_NAMING else ["the migrator harness does not accept target naming; its defaults "
                                               "(dev_test catalogs) were used"],
    }
    out = volume / "batches" / key
    out.mkdir(parents=True, exist_ok=True)
    if packed:        # S12: the sign-off pack, from the evidence of the steps that ran (never claims an unrun one)
        from packs.snowflake import signoff

        report["signoff"] = signoff.write(report, out / batch_run_id / "signoff",
                                          decisions if decisions is not None
                                          else signoff.decisions_of(rows, feedback_dir(work)))
    (out / f"{batch_run_id}.json").write_text(json.dumps(report, indent=1, default=str), encoding="utf-8")
    report["report_path"] = str(out / f"{batch_run_id}.json")
    if parity_report is not None:
        from packs.snowflake.parity import write_report
        write_report(parity_report, out / batch_run_id)
    return report


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--bundle", required=True, help="handoff bundle directory (manifest.json + etls/)")
    ap.add_argument("--volume", default=str(ROOT / "ex_volume"))
    ap.add_argument("--work", default=str(ROOT / ".platform_local"))
    ap.add_argument("--stop-at", default="", choices=["", *AGENT_ORDER])
    ap.add_argument("--keep-going", action="store_true", help="continue after a failed ETL (dependants still skip)")
    ap.add_argument("--column-style", default="delta_safe", choices=["delta_safe", "preserve"])
    ap.add_argument("--credentials-stdin", action="store_true",
                    help="read one JSON object of source credentials from stdin (PEM values become owner-only files)")
    ap.add_argument("--resume", default="", metavar="BATCH_RUN_ID",
                    help="rerun ETLs whose reviews were approved (and their blocked dependants) from that report")
    ap.add_argument("--parity", action="store_true",
                    help="Q10: compare source and target aggregates of the landed tables (implied by "
                         "--credentials-stdin); a mismatch holds the batch for review")
    ap.add_argument("--verify", action="store_true",
                    help="S3: EXPLAIN / DESCRIBE QUERY every converted statement on the SQL warehouse (env: "
                         "DATABRICKS_WAREHOUSE_ID); without a warehouse units record `unverifiable`, never passed")
    args = ap.parse_args(argv)
    verify = None
    if args.verify:
        from packs.snowflake.verify import VerifyConfig
        from packs.snowflake.warehouse import from_env
        wh, why = from_env()
        verify = VerifyConfig(warehouse=wh, reason=why)
    from core.common.secrets_io import install_log_redaction, read_credentials
    install_log_redaction()
    if args.credentials_stdin:
        os.environ.update({f"SOURCE_CREDENTIAL_{k.upper()}": v for k, v in read_credentials().items()})
    parity_ports = None
    if args.parity or args.credentials_stdin:        # Q10: Snowflake side (L7) + the Databricks warehouse
        from packs.snowflake.source_query import from_env as source_from_env
        from packs.snowflake.warehouse import from_env as warehouse_from_env
        source, why_s = source_from_env()
        target, why_t = warehouse_from_env()
        parity_ports = (source, target, why_s if source is None else why_t)
    rep = asyncio.run(run_batch(pathlib.Path(args.bundle), volume=pathlib.Path(args.volume),
                                work=pathlib.Path(args.work), stop_at=args.stop_at, keep_going=args.keep_going,
                                column_style=args.column_style, resume=args.resume, verify=verify,
                                parity_ports=parity_ports))
    print(f"\nbatch {rep['batch_run_id']} ({rep['strategy_label'] or rep['strategy']}): {rep['counts']}")
    for r in rep["etls"]:
        print(f"  {r['order']:>3} {r['etl_id']:>10}  {r['status']:15s} {r['name']}"
              + (f"  - {r['reason']}" if r.get("reason") else ""))
    if rep["prerequisites"]:
        print(f"  needs in the target before running: {len(rep['prerequisites'])} dataset(s) "
              f"({sorted({p['availability'] for p in rep['prerequisites']})})")
    print(f"report: {rep['report_path']}")
    return 1 if rep["counts"]["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
