#!/usr/bin/env python3
"""Build the execution deck: precedence, then how the work is structured and ordered.

    python scripts/make_execution_deck.py   -> docs/migration_execution.pptx

Who it is for
-------------
The people who have to run the programme week to week, and the senior who signs
off the shape of it. It answers two questions in order: when two grouping rules
disagree, which wins — and once everything is grouped, what actually runs when.

The structure it describes has exactly one synchronisation point:

    ETLs  ->  sub-batch  ->  batch  ->  wave

ETLs inside a sub-batch run together. Sub-batches are independent, so a reviewer
picks them up on their own time. Batches inside a wave are independent, because
they belong to different reviewers. Only the WAVE is a barrier. One barrier in
the whole programme is the design; adding a second is how this turns back into a
critical path.

The precedence slide is IMPORTED from the strategy deck rather than rebuilt. It
is the same slide making the same ruling, and two copies would eventually make
two different rulings.
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation  # noqa: E402
from pptx.enum.text import PP_ALIGN  # noqa: E402
from pptx.util import Inches as In  # noqa: E402

from scripts.make_architecture_deck import (  # noqa: E402
    E,
    _arrow,
    _box,
    _chip,
    _footnote,
    _header,
)
from scripts.make_batching_deck import _benefits  # noqa: E402
from scripts.make_checks_deck import (  # noqa: E402
    BRAND,
    CODE_BG,
    DIM,
    FAIL,
    INK,
    LINE,
    MUTED,
    PAPER,
    PASS,
    WARN,
    WASH,
    H,
    W,
    _blank,
    _rect,
    _txt,
    title_slide,
)

# The same ruling, from the one place it is written down.
from scripts.make_strategy_deck import precedence_slide  # noqa: E402

#: Sub-batch size. Stated once because it appears on two slides and in the
#: speaker's mouth, and a deck that says 50-100 here and 40-80 there invites the
#: one question nobody wants: "so which is it".
SUB_BATCH_MIN, SUB_BATCH_MAX = 50, 100


# --------------------------------------------------------------------------- #
# how the work is structured
# --------------------------------------------------------------------------- #

def structure_slide(prs):
    """The composition chain, in the order the client described it.

    Read left to right it is "what is made of what". Read along the chips
    underneath it is "what runs at the same time" — which is the half people get
    wrong, because the two do not line up: the largest container is the one with
    the least parallelism inside it.
    """
    slide = _blank(prs)
    _header(slide, "How the work is structured",
            "Four levels. Each says what it is made of, and what runs at the same time inside it")

    levels = [
        ("LEVEL 1", "ETL",
         "One pipeline. One set of\ntables to hand over, one\nparity result.",
         "run together, multi-threaded", PASS),
        ("LEVEL 2", "Sub-batch",
         f"{SUB_BATCH_MIN}–{SUB_BATCH_MAX} ETLs.\nOne parity report across\nall of them, one approval.",
         "independent of each other", PASS),
        ("LEVEL 3", "Batch",
         "The sub-batches for one\ndomain. One reviewer owns\nthe whole thing.",
         "independent within a wave", PASS),
        ("LEVEL 4", "Wave",
         "Every batch cleared to run\nin this round. The only\nbarrier in the programme.",
         "strictly sequential", FAIL),
    ]
    bw = E((In(12.1) - In(0.55) * 3) / 4)
    for i, (kicker, title, body, concurrency, tone) in enumerate(levels):
        x = E(In(0.62) + i * (bw + In(0.55)))
        _box(slide, x, In(1.38), bw, In(1.95), title, body, kicker=kicker,
             accent=BRAND, title_size=16, body_size=10.5, spacing=1.28)
        _chip(slide, x, In(3.44), bw, In(0.40), concurrency,
              fill=PAPER, edge=tone, color=tone, size=9)
        if i < 3:
            _arrow(slide, E(x + bw + In(0.06)), In(2.35),
                   E(x + bw + In(0.49)), In(2.35), color=INK, width=2)
            _txt(slide, E(x + bw + In(0.02)), In(2.02), In(0.51), In(0.22),
                 "makes", size=8, bold=True, color=DIM, align=PP_ALIGN.CENTER)

    _rect(slide, In(0.62), In(4.20), In(5.82), In(1.35), CODE_BG, LINE)
    _rect(slide, In(0.62), In(4.20), In(0.09), In(1.35), BRAND)
    _txt(slide, In(0.94), In(4.40), In(5.2), In(0.28),
         f"WHY {SUB_BATCH_MIN}–{SUB_BATCH_MAX} IS REVIEWABLE", size=9.5, bold=True,
         color=BRAND)
    _txt(slide, In(0.94), In(4.72), In(5.3), In(0.75),
         "The reviewer reads one parity report, not a hundred pipelines. Scale comes from the report "
         "being the unit of approval, not the pipeline.",
         size=11, color=MUTED, spacing=1.28)

    _rect(slide, In(6.9), In(4.20), In(5.82), In(1.35), CODE_BG, LINE)
    _rect(slide, In(6.9), In(4.20), In(0.09), In(1.35), WARN)
    _txt(slide, In(7.22), In(4.40), In(5.2), In(0.28),
         "AND WHY THE RANGE IS A STARTING POINT", size=9.5, bold=True, color=WARN)
    _txt(slide, In(7.22), In(4.72), In(5.3), In(0.75),
         "Batch one is the rehearsal. It gives a real review time per sub-batch, and the range is "
         "re-cut from that rather than defended.",
         size=11, color=MUTED, spacing=1.28)

    _benefits(slide, ["approvals", "one", "parallel"], y=In(5.75))
    return slide


# --------------------------------------------------------------------------- #
# how the work is ordered
# --------------------------------------------------------------------------- #

def _wave(slide, y, h, label, note, batches, *, tone, dim=False):
    """One wave: a container, the batches inside it, their sub-batch pips.

    The nesting is drawn rather than labelled because the point of the slide is
    that a wave is not a stage of work — it is a bag of work that happens to
    close together.
    """
    body = DIM if dim else INK
    _rect(slide, In(0.62), y, In(12.1), h, WASH if not dim else PAPER, LINE)
    _rect(slide, In(0.62), y, In(0.09), h, tone)
    _txt(slide, In(0.94), E(y + In(0.12)), In(4.0), In(0.25), label,
         size=10.5, bold=True, color=tone)
    _txt(slide, In(3.1), E(y + In(0.13)), In(9.3), In(0.25), note,
         size=9.5, color=DIM)

    bw = E((In(11.5) - In(0.2) * (len(batches) - 1)) / len(batches))
    for i, (name, subs) in enumerate(batches):
        bx = E(In(0.92) + i * (bw + In(0.2)))
        by = E(y + In(0.44))
        bh = E(h - In(0.58))
        _rect(slide, bx, by, bw, bh, PAPER, LINE)
        _txt(slide, E(bx + In(0.16)), E(by + In(0.11)), E(bw - In(0.3)), In(0.25),
             name, size=10.5, bold=True, color=body)
        pw = E((bw - In(0.32) - In(0.1) * (subs - 1)) / subs)
        for j in range(subs):
            px = E(bx + In(0.16) + j * (pw + In(0.1)))
            _chip(slide, px, E(by + In(0.46)), pw, In(0.32), f"SB {j + 1}",
                  fill=PAPER, edge=tone if not dim else LINE,
                  color=tone if not dim else DIM, size=8)


def _barrier(slide, y, text):
    _rect(slide, In(0.62), y, In(12.1), In(0.46), PAPER, FAIL)
    _txt(slide, In(0.62), E(y + In(0.11)), In(12.1), In(0.25), text,
         size=10, bold=True, color=FAIL, align=PP_ALIGN.CENTER)


def ordering_slide(prs):
    """The flowchart: everything parallel inside a wave, nothing across one."""
    slide = _blank(prs)
    _header(slide, "How the work is ordered",
            "Everything inside a wave runs at once. Nothing starts in the next one until this one closes")

    _wave(slide, In(1.26), In(1.72), "WAVE 1",
          "batches run in parallel · each has its own reviewer · sub-batches picked up on their own time",
          [("Batch A · Finance", 3), ("Batch B · Supply chain", 3),
           ("Batch C · Commercial", 2)], tone=PASS)
    _barrier(slide, In(3.12),
             "WAVE 1 CLOSES  ·  every batch signed off, every table handed over, replication stopped")

    _wave(slide, In(3.74), In(1.72), "WAVE 2",
          "cannot start until the bar above is met — the only dependency in the whole plan",
          [("Batch D · Finance", 3), ("Batch E · Supply chain", 2),
           ("Batch F · HR", 2)], tone=BRAND, dim=True)
    _barrier(slide, In(5.60), "WAVE 2 CLOSES  ·  and so on")

    _rect(slide, In(0.62), In(6.20), In(12.1), In(0.52), PAPER, LINE)
    _txt(slide, In(0.94), E(In(6.20) + In(0.14)), In(11.5), In(0.25),
         "WAVE 3   ·   WAVE 4   ·   …   sequenced by what lets the most of the old system be "
         "switched off soonest",
         size=10, bold=True, color=DIM)

    _footnote(slide, "One barrier in the programme. Everything else is people working "
                     "in parallel on their own clock.")
    return slide


# --------------------------------------------------------------------------- #
# what the barrier is for, and what happens when something misses it
# --------------------------------------------------------------------------- #

def barrier_slide(prs):
    """Why have a barrier at all, and the rule that stops it becoming a stall.

    The question this answers is the one that sinks wave plans in practice: a
    single batch that cannot close holds every other team still. The rule has to
    be decided now, in the calm, rather than in the meeting where it happens.
    """
    slide = _blank(prs)
    _header(slide, "What the barrier is for",
            "A wave boundary is where the programme re-plans and banks its savings — not where it waits")

    for x, kicker, title, body, tone in (
        (In(0.62), "WHY HAVE ONE AT ALL", "Three things only happen here",
         "Replication is switched off for every table the wave handed over, so the saving is "
         "realised in one accountable step.\n\n"
         "The effort model is re-cut from what the wave actually took, so the next forecast is "
         "evidence rather than a plan.\n\n"
         "The old system's pipelines whose consumers are now all migrated are retired — which can "
         "only be judged once a whole wave is in.", BRAND),
        (In(6.9), "WHEN A BATCH MISSES IT", "The batch moves, the bar does not",
         "A batch that cannot close is demoted into the next wave. The barrier never slides, because "
         "a movable barrier is not a barrier — it is a queue behind the slowest reviewer in the "
         "programme.\n\n"
         "Its tables stay on replication, untouched. There is no partial hand-over, so nothing has to "
         "be unwound.\n\n"
         "The wave closes on what passed, and the saving for those tables is banked on time.", PASS),
    ):
        _rect(slide, x, In(1.25), In(5.82), In(4.55), CODE_BG, LINE)
        _rect(slide, x, In(1.25), In(0.09), In(4.55), tone)
        _txt(slide, x + In(0.32), In(1.45), In(5.2), In(0.25), kicker,
             size=9, bold=True, color=tone)
        _txt(slide, x + In(0.32), In(1.72), In(5.2), In(0.35), title,
             size=16, bold=True)
        _txt(slide, x + In(0.32), In(2.25), In(5.3), In(3.3), body,
             size=11.5, color=MUTED, spacing=1.34)

    _benefits(slide, ["dual", "forecast", "turnaround"], y=In(6.00))
    return slide


# --------------------------------------------------------------------------- #

def build(out: pathlib.Path) -> pathlib.Path:
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    title_slide(
        prs, "How the migration runs",
        "The precedence rules, and the shape of the work they produce",
        "Two things decide the plan. First, when two sensible grouping rules disagree, which one wins "
        "— settled in advance so it is never argued in the room.\n\n"
        "Then the shape that falls out of it. Pipelines are gathered into sub-batches of "
        f"{SUB_BATCH_MIN}–{SUB_BATCH_MAX}, sub-batches into batches owned by one reviewer each, and "
        "batches into waves.\n\n"
        "Everything inside a wave runs in parallel, on each reviewer's own clock. The wave boundary is "
        "the only point in the entire programme where anyone waits for anyone else — and it is where "
        "the old system gets switched off and the forecast gets re-cut.")

    precedence_slide(prs)
    structure_slide(prs)
    ordering_slide(prs)
    barrier_slide(prs)

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out


def main() -> int:
    out = build(ROOT / "docs" / "migration_execution.pptx")
    prs = Presentation(out)
    print(f"wrote {out.relative_to(ROOT)}  ({len(prs.slides._sldIdLst)} slides)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
