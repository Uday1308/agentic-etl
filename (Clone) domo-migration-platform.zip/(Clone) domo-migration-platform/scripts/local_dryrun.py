#!/usr/bin/env python3
"""scripts/local_dryrun.py — run MD Plan + CD Codegen on this machine, offline.

Standalone by design. It imports the agents but is not imported BY anything, so
nothing here can disturb the pipeline code. Delete it and the platform is unchanged.

Why it exists: Databricks lives on a VDI, and moving the whole repo there just to see
what the agents produce is a lot of copying. This runs the deterministic half locally
and hands you two things to paste across:

    1. the generated SQL  (one file per output target)
    2. a parity script    (compares migrated vs DOMO-expected, no setup)

No Spark. No serving endpoint. No Databricks SDK. If a step cannot be transpiled
deterministically it is reported as an escalation rather than sent to a model — so a
run here is reproducible and free.

Usage
-----
    python scripts/local_dryrun.py --input discovery.json --dataflow-id 8099
    python scripts/local_dryrun.py --input discovery.json --dataflow-id 8099 \
        --dataflow-name cms --out-dir out --source-schema domo_bronze \
        --expected-schema domo_expected

Input formats — all accepted, auto-detected
-------------------------------------------
A. Discovery-table export as **CSV** — the usual case, since Databricks exports CSV.
   Just download the result of `SELECT * FROM <discovery_table> WHERE ...`. JSON-string
   columns (properties, input_node_ids) and Spark's WrappedArray(...) renderings are
   both parsed.

B. The same rows as a JSON list of dicts.

C. Standardized dataflow JSON:
   {"dataflow_id": "...", "nodes": [{"id","name","type","category","properties"}],
    "edges": [{"from","to"}]}
"""
from __future__ import annotations

import argparse
import csv
import json
import pathlib
import sys
from typing import Any

#: set from --discovery-run before normalize() runs
_REQUESTED_RUN = ""

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.cd_codegen.sql_assembly import SqlAssembler  # noqa: E402
from agents.cd_codegen.sql_generator import (  # noqa: E402
    build_sql,
    source_coverage,
)
from agents.md_plan.render import (  # noqa: E402
    PlanRenderer,
    resolve_dynamic_columns,
    snake,
)
from core.contracts.discovery import (  # noqa: E402
    DiscoverySchemaError,
    normalize_rows,
    to_dataflow,
)
from core.contracts.judges import JudgeRegistry  # noqa: E402
from core.domo.naming import policy_from_args, set_policy  # noqa: E402
from judges.rules import DEFAULT_JUDGES  # noqa: E402

# --------------------------------------------------------------------------- #
# input loading and normalization
# --------------------------------------------------------------------------- #

def load_rows(path: pathlib.Path) -> Any:
    """Read the discovery export. CSV and JSON both accepted, chosen by content."""
    raw = path.read_text(encoding="utf-8-sig")          # -sig: strips an Excel BOM
    head = raw.lstrip()[:1]
    if path.suffix.lower() == ".csv" or head not in "[{":
        # a single properties cell can hold a whole raw_node_json blob
        csv.field_size_limit(min(2**31 - 1, sys.maxsize))
        rows = list(csv.DictReader(raw.splitlines()))
        if not rows:
            raise SystemExit(f"{path} parsed as CSV but contained no data rows")
        cleaned = []
        for r in rows:
            item = {(k or "").strip(): v for k, v in r.items() if k is not None}
            if any(str(v or "").strip() for v in item.values()):
                cleaned.append(item)
        print(f"read {len(cleaned)} CSV rows · columns: {', '.join(list(cleaned[0])[:12])}"
              f"{' …' if len(cleaned[0]) > 12 else ''}")
        return cleaned
    return json.loads(raw)


def normalize(payload: Any, dataflow_id: str) -> dict:
    """Accept any supported input shape; return the standardized dataflow.

    Column aliasing, discovery-run scoping and value coercion all live in
    ``core.contracts.discovery``, so this script cannot drift from what the Discovery
    agent writes or from what the Spark reader reads.
    """
    if isinstance(payload, dict) and "nodes" in payload:
        doc = dict(payload)
        doc.setdefault("dataflow_id", dataflow_id)
        doc.setdefault("edges", doc.pop("connections", []) or [])
        return doc

    rows = payload if isinstance(payload, list) else payload.get("rows", [])
    if not rows:
        raise SystemExit("input has no nodes and no rows — is this a discovery export?")
    try:
        normalized = normalize_rows(rows, dataflow_id=dataflow_id, run_id=_REQUESTED_RUN)
    except DiscoverySchemaError as exc:
        raise SystemExit(str(exc)) from exc

    runs = sorted({r.discovery_run_id for r in normalized if r.discovery_run_id})
    if runs:
        print(f"discovery run: {', '.join(runs)}"
              f"{'  (pass --discovery-run to pin another)' if len(runs) == 1 else ''}")
    disabled = sum(1 for r in normalized if r.is_node and r.is_disabled)
    if disabled:
        print(f"skipped {disabled} disabled node(s) — DOMO keeps them but does not run them")
    return to_dataflow(normalized, dataflow_id)


# --------------------------------------------------------------------------- #
# SQL generation (mirrors what CD Codegen does, without the graph or the store)
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# parity script — the second thing you paste into the VDI
# --------------------------------------------------------------------------- #

PARITY_TEMPLATE = """\
-- ===================================================================
-- Parity check · DOMO dataflow {dataflow_id}
-- Target: {target}
--
-- Paste and run this AFTER you have materialized the generated SQL into
--   {actual}
-- and ingested DOMO's own output of the same batch into
--   {expected}
--
-- IMPORTANT: both sides must come from the SAME DOMO batch. If DOMO re-ran
-- between the two captures, differences here are DOMO drift, not translation
-- bugs, and you will chase the wrong thing.
-- ===================================================================

-- 1 · headline metrics -----------------------------------------------
-- row_count must match. checksum is an order-independent multiset hash, so it
-- catches "right number of rows, wrong values" — the failure that matters.
WITH e AS (SELECT * FROM {expected}),
     a AS (SELECT * FROM {actual})
SELECT 'row_count' AS metric,
       (SELECT COUNT(*) FROM e)                                    AS expected,
       (SELECT COUNT(*) FROM a)                                    AS actual,
       (SELECT COUNT(*) FROM a) - (SELECT COUNT(*) FROM e)         AS delta
UNION ALL
SELECT 'row_checksum',
       (SELECT SUM(XXHASH64(TO_JSON(STRUCT(e.*)))) FROM e),
       (SELECT SUM(XXHASH64(TO_JSON(STRUCT(a.*)))) FROM a),
       NULL;

-- 2 · rows DOMO has that we do not ----------------------------------
-- EXCEPT is set-based, so it works without primary keys. These feeds have none.
SELECT 'missing_from_migrated' AS side, *
FROM (SELECT * FROM {expected} EXCEPT SELECT * FROM {actual})
LIMIT 50;

-- 3 · rows we produced that DOMO does not ---------------------------
SELECT 'extra_in_migrated' AS side, *
FROM (SELECT * FROM {actual} EXCEPT SELECT * FROM {expected})
LIMIT 50;

-- 4 · schema comparison ---------------------------------------------
-- Type drift is the quiet one. Watch for DECIMAL(10,0) on money columns: that is
-- the truncation a bare DECIMAL cast produces.
SELECT COALESCE(e.col_name, a.col_name) AS column_name,
       e.data_type                      AS expected_type,
       a.data_type                      AS actual_type,
       CASE WHEN e.col_name IS NULL              THEN 'only in migrated'
            WHEN a.col_name IS NULL              THEN 'only in DOMO'
            WHEN e.data_type <> a.data_type      THEN 'type differs'
            ELSE 'ok' END                AS verdict
FROM (SELECT column_name AS col_name, data_type
      FROM {expected_info}) e
FULL OUTER JOIN (SELECT column_name AS col_name, data_type
      FROM {actual_info}) a
  ON lower(e.col_name) = lower(a.col_name)
ORDER BY verdict, column_name;

-- 5 · per-column aggregates (fill in your numeric columns) ----------
-- Sum drift in the last digits is legitimate float accumulation order. A
-- distinct-count or null-count mismatch never is.
--
-- SELECT 'Invoice Amount' AS column_name,
--        (SELECT ROUND(SUM(`Invoice Amount`), 2) FROM {expected}) AS expected_sum,
--        (SELECT ROUND(SUM(`Invoice Amount`), 2) FROM {actual})   AS actual_sum,
--        (SELECT COUNT(*) - COUNT(`Invoice Amount`) FROM {expected}) AS expected_nulls,
--        (SELECT COUNT(*) - COUNT(`Invoice Amount`) FROM {actual})   AS actual_nulls;
"""


def parity_sql(dataflow_id: str, target: str, actual: str, expected: str) -> str:
    def info(tbl: str) -> str:
        parts = tbl.split(".")
        if len(parts) == 3:
            cat, sch, name = parts
            return (f"{cat}.information_schema.columns "
                    f"WHERE table_schema = '{sch}' AND table_name = '{name}'")
        return (f"information_schema.columns WHERE table_name = '{parts[-1]}'")

    return PARITY_TEMPLATE.format(
        dataflow_id=dataflow_id, target=target, actual=actual, expected=expected,
        actual_info=info(actual), expected_info=info(expected))


# --------------------------------------------------------------------------- #
# report
# --------------------------------------------------------------------------- #

class Subject:
    def __init__(self, artifact, node_ids, meta):
        self.artifact, self.node_ids, self.meta = artifact, node_ids, meta


def judge(sql: str, node_keys: list[str]) -> Any:
    return JudgeRegistry(list(DEFAULT_JUDGES)).run(
        "cd_codegen", Subject(sql, node_keys, {}), iteration=1)


def report(build, artifacts, panels: dict) -> str:
    L: list[str] = []
    w = L.append
    w("=" * 72)
    w("LOCAL DRY RUN — deterministic only, no model was called")
    w("=" * 72)
    w("")
    w(f"  sources            {len(build.sources)}")
    w(f"  transformation steps {len(build.steps)}")
    w(f"  output targets     {len(build.targets)}")
    w(f"  resolved locally   {build.resolved_count}/{len(build.steps)} "
      f"({build.coverage_pct:.1f}%)")
    w(f"  need a model       {len(build.unresolved)}")
    w("")

    if build.unresolved:
        w("-" * 72)
        w("ESCALATIONS — these steps cannot be transpiled from the tile vocabulary")
        w("-" * 72)
        for u in build.unresolved:
            w(f"  {u['step']}  {u['name']}  ->  {u['df_var']}")
            for reason in u["reasons"]:
                w(f"        {reason}")
        w("")
        w("  The plan documents each one with its context. Nothing was guessed.")
        w("")

    flagged = [s for s in build.steps if s.result.confidence in ("LOW", "MEDIUM")]
    if flagged:
        w("-" * 72)
        w("SEMANTIC CAVEATS — what a reviewer should actually look at")
        w("-" * 72)
        for s in flagged:
            w(f"  [{s.result.confidence:6s}] {s.step_id}  {s.name}")
            for n in dict.fromkeys(s.result.notes):
                w(f"        {n}")
        w("")

    escalated = {u["df_var"] for u in build.unresolved}
    if escalated:
        w("!" * 72)
        w("!!  THE GENERATED SQL CONTAINS PASSTHROUGH PLACEHOLDERS")
        w("!!  Parity results are meaningless until these steps are replaced:")
        for v in sorted(escalated):
            w(f"!!    {v}")
        w("!" * 72)
        w("")

    w("-" * 72)
    w("ARTIFACTS")
    w("-" * 72)
    for a in artifacts:
        if getattr(a, "error", None):
            w(f"  FAILED  {a.target}")
            w(f"          {a.error}")
            continue
        panel = panels.get(a.target)
        line = f"  {a.target}"
        w(line)
        w(f"          {len(a.node_keys)} node sections · final CTE {a.final_cte}")
        w(f"          intended table {a.table}")
        if panel:
            fails = [r for r in panel.results if r.verdict.value == "fail"]
            warns = [r for r in panel.results if r.verdict.value == "warn"]
            w(f"          judges {panel.pass_rate:.0%} pass"
              f"{'  FAIL: ' + ', '.join(r.rule_id for r in fails) if fails else ''}"
              f"{'  warn: ' + ', '.join(r.rule_id for r in warns) if warns else ''}")
            for r in fails + warns:
                for f in r.findings[:3]:
                    w(f"            {r.rule_id} {f.node or '(artifact)'}: {f.message}")
    w("")
    return "\n".join(L)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Run MD Plan + CD Codegen locally, offline. Writes the plan, the "
                    "SQL per target, and a parity script to paste into Databricks.")
    ap.add_argument("--input", required=True,
                    help="discovery-table export as CSV or JSON, or standardized "
                         "dataflow JSON. Format is detected from the content.")
    ap.add_argument("--dataflow-id", required=True)
    ap.add_argument("--discovery-run", default="",
                    help="pin a specific discovery_run_id; defaults to the newest")
    ap.add_argument("--dataflow-name", default="",
                    help="used in file names and the plan header")
    ap.add_argument("--out-dir", default="dryrun_out")
    ap.add_argument("--source-catalog", default="dev_test")
    ap.add_argument("--source-schema", default="domo_input",
                    help="where the ingested DOMO source tables live")
    ap.add_argument("--target-catalog", default="dev_test")
    ap.add_argument("--target-schema", default="migrated_output",
                    help="where you intend to materialize the results")
    ap.add_argument("--expected-schema", default="domo_expected",
                    help="where DOMO's own output is ingested, for the parity script")
    ap.add_argument("--no-materialize", action="store_true",
                    help="emit a plain SELECT instead of CREATE OR REPLACE TABLE ... AS")
    ap.add_argument("--emit-debug", action="store_true",
                    help="also write a per-CTE row-count probe, for tracking down "
                         "a result that comes back empty")
    ap.add_argument("--as-of", default="",
                    help="keep only rows strictly older than this timestamp, e.g. "
                         "'2026-09-03 02:39:00'. Applied at every source so it "
                         "propagates through joins and aggregates.")
    ap.add_argument("--as-of-column", default="_BATCH_LAST_RUN_",
                    help="the timestamp column the cutoff is applied to")
    ap.add_argument("--source-columns", default="",
                    help="JSON file mapping each source table (or dataset name, or "
                         "df_var) to its columns, as {\"col\": \"spark_type\"} or the "
                         "list of pairs `spark.table(t).dtypes` returns. Given it, each "
                         "source CTE strips DOMO's leading-apostrophe export artifact "
                         "from every text column, once, for everything downstream. "
                         "Without it the SQL reads the sources with SELECT * and only "
                         "the per-tile strips apply.")
    ap.add_argument("--dialect", default="sql", choices=["sql", "pyspark"])
    ap.add_argument("--column-style", default="delta_safe",
                    choices=["delta_safe", "preserve"],
                    help="delta_safe (default) replaces characters Delta rejects with "
                         "'_', matching how ingestion had to sanitize them to land the "
                         "data in Delta at all. Use preserve ONLY if your tables were "
                         "created with Delta column mapping enabled.")
    ap.add_argument("--column-extra-chars", default="",
                    help="additional characters your ingestion replaced, e.g. '.' or './'")
    args = ap.parse_args(argv)

    global _REQUESTED_RUN
    _REQUESTED_RUN = args.discovery_run
    set_policy(policy_from_args(args.column_style, args.column_extra_chars))
    if args.column_style == "delta_safe":
        extra = f" plus {args.column_extra_chars!r}" if args.column_extra_chars else ""
        print("column style: delta_safe — Delta-invalid characters"
              f"{extra} become '_', matching your ingested tables")
    else:
        print("column style: preserve — DOMO names kept verbatim. This only runs "
              "against tables created with Delta column mapping enabled.")

    if args.as_of:
        print(f"as-of cutoff: rows strictly older than {args.as_of} "
              f"(on `{args.as_of_column}`, nulls kept)")

    payload = load_rows(pathlib.Path(args.input))
    std = normalize(payload, args.dataflow_id)
    if not std["nodes"]:
        raise SystemExit("no usable nodes found — check record_type and node_id columns")

    name = args.dataflow_name or f"dataflow_{args.dataflow_id}"
    renderer = PlanRenderer(dialect=args.dialect,
                            source_catalog=args.source_catalog,
                            source_schema=args.source_schema,
                            target_catalog=args.target_catalog,
                            target_schema=args.target_schema)
    build = renderer.build(std, dataflow_id=args.dataflow_id, dataflow_name=name)

    source_columns = {}
    if args.source_columns:
        path = pathlib.Path(args.source_columns)
        try:
            source_columns = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise SystemExit(f"--source-columns {path}: {exc}") from exc
        if not isinstance(source_columns, dict):
            raise SystemExit(f"--source-columns {path} must hold a JSON object keyed "
                             f"by table, dataset name or df_var")
        covered, uncovered = source_coverage(build, source_columns)
        print(f"source cleaning: DOMO export artifacts stripped in "
              f"{len(covered)}/{len(build.sources)} source CTEs")
        for s in uncovered:
            print(f"  !! no columns for {s['table']} — left uncleaned and marked "
                  f"in the SQL")

    artifacts = build_sql(build, args.dataflow_id, _merged_nodes(std),
                          as_of=args.as_of, as_of_column=args.as_of_column,
                          source_columns=source_columns,
                          materialize=not args.no_materialize, dialect=args.dialect)
    panels = {a.target: judge(a.sql, a.node_keys) for a in artifacts if a.sql}

    out = pathlib.Path(args.out_dir) / args.dataflow_id
    out.mkdir(parents=True, exist_ok=True)

    plan_path = out / f"plan_{args.dataflow_id}.md"
    plan_path.write_text(build.document, encoding="utf-8")

    written = [plan_path]
    for a in artifacts:
        if not a.sql:
            continue
        stem = snake(a.target)[:60]
        sql_path = out / f"etl_{args.dataflow_id}__{stem}.sql"
        sql_path.write_text(a.sql, encoding="utf-8")
        written.append(sql_path)

        if args.emit_debug:
            dbg_path = out / f"debug_{args.dataflow_id}__{stem}.sql"
            dbg_path.write_text(SqlAssembler().debug_sql(a), encoding="utf-8")
            written.append(dbg_path)

        expected = f"{args.target_catalog}.{args.expected_schema}.{snake(a.target)}"
        par_path = out / f"parity_{args.dataflow_id}__{stem}.sql"
        par_path.write_text(
            parity_sql(args.dataflow_id, a.target, a.table, expected), encoding="utf-8")
        written.append(par_path)

    text = report(build, artifacts, panels)
    (out / "report.txt").write_text(text, encoding="utf-8")
    print(text)
    print("-" * 72)
    print("WRITTEN")
    print("-" * 72)
    for p in written:
        print(f"  {p}")
    print(f"  {out / 'report.txt'}")
    print()
    print("Next: run etl_*.sql in Databricks, then the matching parity_*.sql to")
    print("compare against DOMO.")
    print("If a result comes back EMPTY, re-run with --emit-debug for a per-CTE")
    print("row count showing exactly which step drops them.")
    return 0


def _merged_nodes(std: dict) -> list[dict]:
    """The tiles the SQL pass renders from — enriched exactly as the plan's are, or the
    two disagree about which steps resolved."""
    return resolve_dynamic_columns([dict(n) for n in std.get("nodes", [])],
                                   list(std.get("edges") or []))


if __name__ == "__main__":
    raise SystemExit(main())
