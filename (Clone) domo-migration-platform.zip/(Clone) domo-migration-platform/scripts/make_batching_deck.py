#!/usr/bin/env python3
"""Build the batching deck: how the estate is migrated in order-independent batches.

    python scripts/make_batching_deck.py   -> docs/migration_batching.pptx

Who it is for
-------------
A senior who has to approve the approach, and who will be asked one hard
question by the client: "pipeline A feeds pipeline B — surely A has to go
first?" The deck exists to answer that question with a mechanism rather than a
reassurance, because "trust us, it's fine" is not a plan anyone can sign.

The argument it makes, in one line: every dataset is a real table from day one,
a migration only ever changes WHICH PROCESS WRITES a table, and a table is only
handed over once its contents have been proved unchanged — so no consumer can
observe a hand-over, and therefore the order of hand-overs cannot matter.

Order-independence is the product of the promotion gate. It is not a hope, and
that distinction is the whole deck.

Every design decision carries its business consequence on the same slide. A
decision whose benefit cannot be named in five words is a decision nobody in the
room can weigh, and this deck is read by people deciding whether to fund it.

Why a script and not a hand-made file
-------------------------------------
The estate numbers on the sizing slide are READ FROM THE DISCOVERY ARTIFACTS
committed under ``ex_volume/``, and the parity metrics on the promotion-gate
slide are READ FROM ``core.contracts.validation``. Those are exactly the facts a
reviewer would quote back, and a slide that quietly disagrees with the platform
is the failure mode that matters. The build fails loudly rather than printing a
plausible number nobody can trace.

The plain-English half is written by hand. It is the translation from "what the
lineage says" to "what it costs you in week six", and nothing generates that.

Style is imported from ``make_checks_deck`` on purpose: this is shown to the same
people in the same room as the other two decks, and a second palette would read
as a second product.
"""
from __future__ import annotations

import collections
import glob
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation  # noqa: E402
from pptx.enum.text import PP_ALIGN  # noqa: E402
from pptx.util import Inches as In  # noqa: E402

# -- facts read from the platform, never retyped ---------------------------- #
from api.models import DataflowCard  # noqa: E402
from core.contracts.validation import Metric  # noqa: E402
from scripts.make_architecture_deck import (  # noqa: E402
    E,
    _arrow,
    _box,
    _chip,
    _footnote,
    _header,
)

# One palette, one set of primitives, shared with the other two decks.
from scripts.make_checks_deck import (  # noqa: E402
    BRAND,
    CODE_BG,
    DIM,
    FAIL,
    INK,
    LINE,
    MUTED,
    PAPER,
    PASS,
    WARN,
    WASH,
    H,
    W,
    _blank,
    _rect,
    _txt,
    section_slide,
    title_slide,
)

#: The catalogue fields that make a complexity factor computable with no new
#: metadata. Asserted against the model so a renamed field breaks the build here
#: rather than turning a slide into a promise the platform cannot keep.
COMPLEXITY_FIELDS = ("tiles", "steps", "targets", "deterministic",
                     "by_model", "unresolved", "coverage_pct")
_missing = [f for f in COMPLEXITY_FIELDS if f not in DataflowCard.model_fields]
if _missing:
    raise SystemExit(f"DataflowCard no longer carries {_missing} — the "
                     f"'computable today' claim on the factors slide is stale.")

#: What the promotion gate actually compares, in the platform's own words. The
#: gate slide is the one a client will hold us to, so the list is read off the
#: enum rather than remembered.
PARITY_METRICS = [m.value for m in Metric]


def estate_facts() -> dict[str, dict[str, int]]:
    """Per-dataflow shape, read off the committed discovery artifacts.

    Keyed by dataflow id. ``steps`` is what a reviewer actually reads — the tiles
    that are neither a source nor a sink — which is why the sizing slide counts
    those rather than dataflows.
    """
    pattern = ROOT / "ex_volume" / "*" / "run-*" / "discovery" / "discovery_*.json"
    latest: dict[str, pathlib.Path] = {}
    for path in sorted(glob.glob(str(pattern))):
        p = pathlib.Path(path)
        latest[p.stem.replace("discovery_", "")] = p      # sorted -> last wins

    out: dict[str, dict[str, int]] = {}
    for dfid, p in sorted(latest.items()):
        rows = json.loads(p.read_text(encoding="utf8"))
        nodes = [r for r in rows if r.get("record_type") == "NODE"]
        ops = collections.Counter(r.get("operation_type") for r in nodes)
        sources, targets = ops.get("source", 0), ops.get("sink", 0)
        out[dfid] = {
            "tiles": len(nodes),
            "sources": sources,
            "targets": targets,
            "steps": len(nodes) - sources - targets,
            "edges": sum(1 for r in rows if r.get("record_type") == "LINEAGE"),
        }
    if not out:
        raise SystemExit(
            "No discovery artifacts under ex_volume/*/run-*/discovery/. The "
            "sizing slide quotes real estate numbers and will not invent them.")
    return out


ESTATE = estate_facts()


# --------------------------------------------------------------------------- #
# business effect — one vocabulary, reused
# --------------------------------------------------------------------------- #

#: Named once so the same benefit is always worded the same way. A deck that
#: calls one thing "less dual running" here and "lower parallel cost" there reads
#: as two separate benefits, and the total stops adding up.
BENEFIT = {
    "parallel":   "teams work in parallel",
    "order":      "order stops being a dependency",
    "dual":       "cuts dual-running cost",
    "approvals":  "fewer approvals per pipeline",
    "turnaround": "faster approval turnaround",
    "one":        "one approver per batch",
    "nochange":   "no consumer changes",
    "rollback":   "rollback in minutes",
    "unverified": "production never sees unverified data",
    "forecast":   "effort forecast gets accurate",
    "stale":      "staleness cannot go unnoticed",
    "scope":      "work removed from the programme",
    "revalidate": "nothing has to be re-approved later",
}

BENEFIT_Y = In(6.14)


def _benefits(slide, keys, *, y=BENEFIT_Y, x=In(0.62), w=In(12.1)):
    """The row of business effects every decision slide closes on.

    Deliberately the last thing on the page and always in the same place: the
    question these slides are read to answer is "and what does that buy us",
    and it should never have to be hunted for.
    """
    _txt(slide, x, y, In(6), In(0.22), "WHAT THIS BUYS", size=9, bold=True,
         color=BRAND)
    items = [BENEFIT[k] for k in keys]
    n = len(items)
    gap = In(0.16)
    pw = E((w - gap * (n - 1)) / n)
    for i, label in enumerate(items):
        px = E(x + i * (pw + gap))
        _chip(slide, px, E(y + In(0.30)), pw, In(0.42), label,
              fill=PAPER, edge=PASS, color=PASS, size=9.5)


# --------------------------------------------------------------------------- #
# the plan
# --------------------------------------------------------------------------- #

def plan_slide(prs):
    """Three phases, and the fact that only the middle one is order-sensitive
    in the obvious reading — which the rest of the deck then removes."""
    slide = _blank(prs)
    _header(slide, "The migration in three phases",
            "Move the data, then move the logic onto it, then switch the old system off")

    boxes = [
        ("PHASE 1", "Land the data",
         "Every dataset copied across as a\nreal table, cleaned and typed.", BRAND),
        ("PHASE 2", "Move the logic onto it",
         "Each pipeline rewritten to write the\ntable that already exists.", BRAND),
        ("PHASE 3", "Switch the old system off",
         "Per table as it is handed over, not\nin one event at the end.", PASS),
    ]
    xw = E((In(12.1) - In(0.45) * 2) / 3)
    for i, (kicker, title, body, tone) in enumerate(boxes):
        x = E(In(0.62) + i * (xw + In(0.45)))
        _box(slide, x, In(1.30), xw, In(1.45), title, body, kicker=kicker,
             accent=tone, title_size=16, body_size=11, spacing=1.3)
        if i < 2:
            _arrow(slide, E(x + xw + In(0.06)), In(2.02),
                   E(x + xw + In(0.39)), In(2.02), color=INK, width=2)

    _rect(slide, In(0.62), In(3.15), In(5.82), In(2.75), CODE_BG, LINE)
    _rect(slide, In(0.62), In(3.15), In(0.09), In(2.75), PASS)
    _txt(slide, In(0.94), In(3.35), In(5.2), In(0.3), "WHAT PHASE 1 UNLOCKS",
         size=10.5, bold=True, color=PASS)
    _txt(slide, In(0.94), In(3.75), In(5.3), In(2.0),
         "Every pipeline's inputs already exist as\n"
         "tables, so nothing waits for anything else\n"
         "to be migrated.\n\n"
         "Validation happens on one platform, same\n"
         "day, against data already sitting there —\n"
         "no extract from the old system to compare.",
         size=11.5, color=MUTED, spacing=1.32)

    _rect(slide, In(6.9), In(3.15), In(5.82), In(2.75), CODE_BG, LINE)
    _rect(slide, In(6.9), In(3.15), In(0.09), In(2.75), BRAND)
    _txt(slide, In(7.22), In(3.35), In(5.2), In(0.3),
         "AND THE QUESTION PHASE 2 HAS TO ANSWER", size=10.5, bold=True,
         color=BRAND)
    _txt(slide, In(7.22), In(3.75), In(5.3), In(2.0),
         "One pipeline's output is another's input.\n"
         "The obvious conclusion is that the first has\n"
         "to be migrated before the second.\n\n"
         "It does not — and the next three slides are\n"
         "the mechanism that makes that true rather\n"
         "than a promise.",
         size=11.5, color=MUTED, spacing=1.32)

    _benefits(slide, ["parallel", "dual", "forecast"])
    return slide


def lift_slide(prs):
    """Phase 1 carries correctness now, because the landed table is permanent."""
    slide = _blank(prs)
    _header(slide, "Phase 1 is not just plumbing",
            "The landed table is the one the business keeps — so it is cleaned once, here, not later")

    _box(slide, In(0.62), In(1.25), In(12.1), In(1.05), "The copy is permanent, so it is a decision",
         "Under this design the landed table is not a staging area that gets thrown away — it is the "
         "table the migrated pipeline will eventually write, and the one every report will read. "
         "Anything wrong with it is wrong forever, and is inherited by everything built on top.",
         kicker="WHY THIS MATTERS MORE THAN IT USED TO", accent=WARN, title_size=15,
         body_size=11, spacing=1.3)

    top, height = In(2.60), In(3.30)
    _rect(slide, In(0.62), top, In(5.82), height, CODE_BG, LINE)
    _rect(slide, In(0.62), top, In(0.09), height, FAIL)
    _txt(slide, In(0.94), top + In(0.18), In(5.2), In(0.3),
         "THE ONE WE ALREADY KNOW ABOUT", size=10.5, bold=True, color=FAIL)
    _txt(slide, In(0.94), top + In(0.58), In(5.3), In(2.5),
         "The export writes a leading apostrophe\n"
         "on some values — the spreadsheet way of\n"
         "saying 'treat this as text'.\n\n"
         "   a money column arrives as\n"
         "       '-92866.56\n"
         "   instead of\n"
         "       -92866.56\n\n"
         "It has surfaced six separate ways so far.",
         size=11, color=MUTED, spacing=1.26)

    _rect(slide, In(6.9), top, In(5.82), height, CODE_BG, LINE)
    _rect(slide, In(6.9), top, In(0.09), height, BRAND)
    _txt(slide, In(7.22), top + In(0.18), In(5.2), In(0.3),
         "SO PHASE 1 GETS ITS OWN GATE", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(7.22), top + In(0.58), In(5.3), In(2.5),
         "Columns are typed and cleaned as they land, "
         "and the landed table is signed off before a "
         "single pipeline is pointed at it.\n\n"
         "Doing it here costs one pass over the data. "
         "Doing it later means changing a table every "
         "report already reads, and re-approving every "
         "pipeline that was proved against the old "
         "version.",
         size=11.5, color=MUTED, spacing=1.32)

    _benefits(slide, ["revalidate", "unverified"])
    return slide


# --------------------------------------------------------------------------- #
# the mechanism
# --------------------------------------------------------------------------- #

def contract_slide(prs):
    """The idea the whole approach rests on: the table is the interface.

    Drawn rather than stated, because the counter-intuitive part is that the
    picture does not change when a pipeline migrates — only the label on one
    arrow does.
    """
    slide = _blank(prs)
    _header(slide, "The table is the contract",
            "A migration changes what WRITES a table. It never changes the table, or anything that reads it")

    _txt(slide, In(0.62), In(1.20), In(3.5), In(0.22), "WHO WRITES IT",
         size=9, bold=True, color=DIM)
    _box(slide, In(0.62), In(1.45), In(3.5), In(1.05), "Replication",
         "from the old system\nuntil hand-over", accent=DIM, title_size=13,
         body_size=10)
    _box(slide, In(0.62), In(2.80), In(3.5), In(1.05), "The migrated job",
         "from hand-over onward", accent=PASS, title_size=13, body_size=10)
    _txt(slide, In(4.18), In(2.42), In(0.8), In(0.3), "swap",
         size=9, bold=True, color=PASS)

    _box(slide, In(5.0), In(1.80), In(3.4), In(1.5), "net_revenue",
         "one table\nsame name, same place,\nsame columns", accent=BRAND,
         title_size=15, body_size=10, spacing=1.28)

    _txt(slide, In(9.9), In(1.20), In(3.0), In(0.22), "WHO READS IT",
         size=9, bold=True, color=DIM)
    _box(slide, In(9.9), In(1.45), In(2.83), In(1.05), "Other pipelines",
         "migrated or not", accent=DIM, title_size=13, body_size=10)
    _box(slide, In(9.9), In(2.80), In(2.83), In(1.05), "Reports, extracts",
         "and everything else", accent=DIM, title_size=13, body_size=10)

    _arrow(slide, In(4.12), In(1.98), In(5.0), In(2.25), color=DIM)
    _arrow(slide, In(4.12), In(3.33), In(5.0), In(2.85), color=PASS, width=2)
    _arrow(slide, In(8.4), In(2.25), In(9.9), In(1.98), color=INK)
    _arrow(slide, In(8.4), In(2.85), In(9.9), In(3.33), color=INK)

    _rect(slide, In(0.62), In(4.30), In(12.1), In(1.55), CODE_BG, LINE)
    _rect(slide, In(0.62), In(4.30), In(0.09), In(1.55), BRAND)
    _txt(slide, In(0.94), In(4.50), In(11.5), In(0.3),
         "NOTHING ON THE RIGHT-HAND SIDE EVER CHANGES", size=10.5, bold=True,
         color=BRAND)
    _txt(slide, In(0.94), In(4.90), In(11.5), In(0.85),
         "No consumer is edited, re-pointed or redeployed when a pipeline migrates. There is no cutover "
         "ticket for the twenty reports that read this table, because from their side nothing happened. "
         "The only thing that changed is which process produced today's rows.",
         size=12, color=MUTED, spacing=1.3)

    _benefits(slide, ["nochange", "turnaround", "approvals"])
    return slide


def staging_slide(prs):
    """The five steps every single pipeline goes through, without exception."""
    slide = _blank(prs)
    _header(slide, "Every pipeline takes the same five steps",
            "No production table is written by new code until that code has been proved against it")

    steps = [
        ("1", "BUILD", "The migrated job\nwrites to a staging\ntable beside the\nreal one.", DIM),
        ("2", "VERIFY", "Staging is compared\nagainst the live\ntable, column by\ncolumn.", BRAND),
        ("3", "APPROVE", "One named reviewer\nsees the comparison\nand signs it off.\nOne gate.", BRAND),
        ("4", "PROMOTE", "Staging replaces the\ntable. The job's\ntarget flips to the\nreal name.", PASS),
        ("5", "RETIRE", "Staging dropped.\nReplication for this\ntable switched off\nfor good.", PASS),
    ]
    sw = E((In(12.1) - In(0.28) * 4) / 5)
    for i, (num, name, body, tone) in enumerate(steps):
        x = E(In(0.62) + i * (sw + In(0.28)))
        _box(slide, x, In(1.38), sw, In(1.92), name, body, kicker=f"STEP {num}",
             accent=tone, title_size=13, body_size=10, spacing=1.26)
        if i < 4:
            _arrow(slide, E(x + sw + In(0.03)), In(2.34),
                   E(x + sw + In(0.25)), In(2.34), color=INK)

    _rect(slide, In(0.62), In(3.55), In(5.82), In(2.30), CODE_BG, LINE)
    _rect(slide, In(0.62), In(3.55), In(0.09), In(2.30), BRAND)
    _txt(slide, In(0.94), In(3.75), In(5.2), In(0.3),
         "THE TARGET IS A SETTING, NOT AN EDIT", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(0.94), In(4.15), In(5.3), In(1.55),
         "Step 4 flips a parameter. It does not change a "
         "line of the code the reviewer approved — so the "
         "artifact running in production is the exact one "
         "that was signed off, and the audit trail holds.",
         size=11.5, color=MUTED, spacing=1.32)

    _rect(slide, In(6.9), In(3.55), In(5.82), In(2.30), CODE_BG, LINE)
    _rect(slide, In(6.9), In(3.55), In(0.09), In(2.30), PASS)
    _txt(slide, In(7.22), In(3.75), In(5.2), In(0.3),
         "AND IT IS REVERSIBLE UNTIL STEP 5", size=10.5, bold=True, color=PASS)
    _txt(slide, In(7.22), In(4.15), In(5.3), In(1.55),
         "Through steps 1 to 3 the live table is untouched "
         "and the old system is still feeding it. Backing "
         "out is switching the job off. Nobody downstream "
         "ever knew the work was happening.",
         size=11.5, color=MUTED, spacing=1.32)

    _benefits(slide, ["unverified", "rollback", "one"])
    return slide


def gate_slide(prs):
    """What has to be true before a table changes hands."""
    slide = _blank(prs)
    _header(slide, "What the promotion gate checks",
            "A table only changes hands when its contents are proved to be the same on both sides")

    _rect(slide, In(0.62), In(1.25), In(5.82), In(4.60), CODE_BG, LINE)
    _rect(slide, In(0.62), In(1.25), In(0.09), In(4.60), BRAND)
    _txt(slide, In(0.94), In(1.45), In(5.2), In(0.3),
         "COMPARED ON EVERY TARGET", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(0.94), In(1.85), In(5.3), In(3.6),
         "\n".join(f"   {m}" for m in PARITY_METRICS)
         + "\n\nSchema and row count on the table;\n"
           "the rest column by column.\n"
           "Checksum is order-independent, so a\n"
           "different row order is not a failure.",
         size=11, font="Consolas", spacing=1.3)

    conditions = [
        ("Every check ran", "A check that examined nothing is never counted as a pass."),
        ("Differences are explained", "Not just measured — each one traced to a cause and accepted or fixed."),
        ("One named person approved", "Recorded against the authenticated user, with what they saw."),
        ("Replication stops in the same window", "Exactly one process writes the table, at every moment."),
    ]
    y = In(1.25)
    for name, why in conditions:
        _rect(slide, In(6.9), y, In(5.82), In(1.08), PAPER, LINE)
        _rect(slide, In(6.9), y, In(0.09), In(1.08), PASS)
        _txt(slide, In(7.22), y + In(0.18), In(5.3), In(0.28), name,
             size=12.5, bold=True)
        _txt(slide, In(7.22), y + In(0.52), In(5.3), In(0.5), why,
             size=10.5, color=MUTED, spacing=1.25)
        y = E(y + In(1.17))

    _benefits(slide, ["unverified", "one", "revalidate"])
    return slide


def order_slide(prs):
    """The argument. Three steps, and the conclusion the client needs to hear.

    This is the slide the deck exists for. It is written as an argument rather
    than a description because it will be challenged in the room, and a claim
    that cannot survive "why" out loud is not worth putting on a slide.
    """
    slide = _blank(prs)
    _header(slide, "Why the order does not matter",
            "The question every reviewer asks — and the mechanism that answers it")

    _rect(slide, In(0.62), In(1.20), In(12.1), In(0.72), WASH)
    _txt(slide, In(0.94), In(1.38), In(11.5), In(0.35),
         "\"Pipeline A's output is pipeline B's input. Surely A has to be migrated first?\"",
         size=14, bold=True, color=INK)

    steps = [
        ("1", "B never reads A",
         "B reads a TABLE. It has always read a "
         "table — one that existed from the day the "
         "data landed. B has no idea which process "
         "filled it in, and no way to find out."),
        ("2", "A hand-over changes nothing",
         "A table is only promoted once staging and "
         "live have been proved identical. If they "
         "differ, nothing is promoted. So the rows B "
         "reads are the same either side of it."),
        ("3", "So B cannot tell",
         "There is no moment at which B sees a "
         "change, and therefore no moment that has "
         "to be scheduled, coordinated or tested "
         "against A's migration."),
    ]
    bw = E((In(12.1) - In(0.14) * 2) / 3)
    for i, (num, name, body) in enumerate(steps):
        x = E(In(0.62) + i * (bw + In(0.14)))
        _rect(slide, x, In(2.10), bw, In(2.20), CODE_BG, LINE)
        _rect(slide, x, In(2.10), In(0.09), In(2.20), BRAND)
        _rect(slide, x + In(0.30), In(2.32), In(0.38), In(0.38), BRAND)
        _txt(slide, x + In(0.30), In(2.41), In(0.38), In(0.25), num,
             size=11, bold=True, color=PAPER, align=PP_ALIGN.CENTER)
        _txt(slide, x + In(0.82), In(2.36), In(2.9), In(0.3), name,
             size=13, bold=True)
        _txt(slide, x + In(0.30), In(2.88), E(bw - In(0.6)), In(1.25), body,
             size=11, color=MUTED, spacing=1.3)

    _rect(slide, In(0.62), In(4.50), In(12.1), In(1.40), PAPER, PASS)
    _rect(slide, In(0.62), In(4.50), In(0.09), In(1.40), PASS)
    _txt(slide, In(0.94), In(4.70), In(11.5), In(0.3),
         "SO THE ORDER IS FREE — AND IT IS ENFORCED, NOT HOPED FOR",
         size=10.5, bold=True, color=PASS)
    _txt(slide, In(0.94), In(5.08), In(11.5), In(0.75),
         "A and B can migrate in any order, at the same time, or months apart. That is not a judgement "
         "about how coupled they happen to be — it is a property of the gate. Nothing is ever handed over "
         "until it has been shown to make no difference, so nothing downstream can be affected by when.",
         size=12, color=MUTED, spacing=1.3)

    _benefits(slide, ["order", "parallel", "approvals", "turnaround"])
    return slide


def risk_slide(prs):
    """The one thing this design newly requires somebody to get right."""
    slide = _blank(prs)
    _header(slide, "The one new thing to get right",
            "One table, one writer, at every moment — and something watching that it is true")

    _box(slide, In(0.62), In(1.25), In(12.1), In(1.0), "Two writers, or none",
         "At hand-over, replication stops and the job starts. Both running means they overwrite each "
         "other and the result depends on timing. Neither running is worse: the table simply stops "
         "updating, quietly, with nothing anywhere reporting an error.",
         kicker="THE FAILURE MODE", accent=FAIL, title_size=15, body_size=11, spacing=1.3)

    for x, title, body, tone in (
        (In(0.62), "A register of who owns each table",
         "One row per table: who writes it today, who writes it after hand-over, and when that "
         "switched. It is the thing the hand-over window is run from, and the thing an auditor is "
         "shown. Without it, ownership lives in somebody's memory.", BRAND),
        (In(6.9), "A freshness alarm on every table",
         "If a table has not been written within its own refresh cadence, raise it. This catches a "
         "missed hand-over, a failed job and a broken replication with the same check — and it is "
         "what turns the silent failure above into a loud one.", PASS),
    ):
        _rect(slide, x, In(2.55), In(5.82), In(3.30), CODE_BG, LINE)
        _rect(slide, x, In(2.55), In(0.09), In(3.30), tone)
        _txt(slide, x + In(0.32), In(2.78), In(5.2), In(0.32), title,
             size=14, bold=True)
        _txt(slide, x + In(0.32), In(3.28), In(5.3), In(2.3), body,
             size=11.5, color=MUTED, spacing=1.34)

    _benefits(slide, ["stale", "rollback"])
    return slide


# --------------------------------------------------------------------------- #
# the batches
# --------------------------------------------------------------------------- #

#: (order, name, role, what it does, computable from what we already hold)
FACTORS = [
    ("1", "Disposition", "PRE-FILTER",
     "Migrate, retire or redesign — decided before anything is grouped", False),
    ("2", "Domain", "GROUP",
     "The batch's identity: one subject area, one reviewer, one sign-off", False),
    ("3", "Complexity", "HOMOGENISE",
     "Keep the clean and the nasty apart so one does not hold up thirty", True),
    ("4", "Criticality", "HOMOGENISE",
     "One review standard per batch; a reviewer cannot hold two at once", False),
    ("5", "Cadence", "SCHEDULE",
     "Decides when a batch can be proved, not what goes in it", False),
    ("6", "Reviewer capacity", "SIZE",
     "The real throughput limit of the programme — hours, not compute", False),
]


def factors_slide(prs):
    """What is left to decide a batch, once order is off the table."""
    slide = _blank(prs)
    _header(slide, "So what actually decides a batch",
            "With sequencing removed, every remaining factor is about review throughput")

    n = len(FACTORS)
    gap, span = In(0.13), In(4.55)
    row_h = E((span - gap * (n - 1)) / n)
    y = In(1.25)
    for num, name, role, what, computed in FACTORS:
        mid = E(y + row_h / 2)
        _rect(slide, In(0.62), y, In(12.1), row_h, PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), row_h, BRAND)
        _rect(slide, In(0.94), mid - In(0.20), In(0.40), In(0.40), WASH)
        _txt(slide, In(0.94), mid - In(0.11), In(0.40), In(0.25), num,
             size=11, bold=True, color=BRAND, align=PP_ALIGN.CENTER)
        _txt(slide, In(1.56), mid - In(0.29), In(3.0), In(0.28), name,
             size=12.5, bold=True)
        _txt(slide, In(1.56), mid + In(0.03), In(3.0), In(0.25), role,
             size=8.5, bold=True, color=BRAND)
        _txt(slide, In(4.72), mid - In(0.13), In(5.7), In(0.5), what,
             size=11, color=MUTED)
        label, tone = (("computable today", PASS) if computed
                       else ("needs business input", WARN))
        _rect(slide, In(10.62), mid - In(0.17), In(2.1), In(0.34), PAPER, tone)
        _txt(slide, In(10.62), mid - In(0.09), In(2.1), In(0.25), label,
             size=9, bold=True, color=tone, align=PP_ALIGN.CENTER)
        y = E(y + row_h + gap)

    _benefits(slide, ["one", "turnaround", "forecast"])
    return slide


def not_slide(prs):
    """What we deliberately refuse to batch on — led by the big one."""
    slide = _blank(prs)
    _header(slide, "What we deliberately do not batch on",
            "Three tempting factors, and the first is the one that would cost the most")

    rows = [
        ("Dependency order", FAIL,
         "The obvious one, and the one we are designing out. Grouping by what feeds what means "
         "batches are shaped by the old system's wiring rather than by who reviews them — and it "
         "makes every batch wait for another. The promotion gate already guarantees a hand-over "
         "changes nothing, so there is nothing left for ordering to protect."),
        ("Reviewer, as its own dimension", DIM,
         "It overlaps almost entirely with domain. Crossing the two fragments the estate into batches "
         "too small to be worth a hand-over window, each still carrying its own sign-off and release "
         "note. Group by domain; staff by person."),
        ("Data volume", DIM,
         "Row counts are a Phase 1 concern. A hundred-million-row table can hold three trivial "
         "transformations, and a small one can hold forty. Sizing a review by data volume measures "
         "the wrong thing entirely."),
    ]
    y = In(1.28)
    for name, tone, why in rows:
        _rect(slide, In(0.62), y, In(12.1), In(1.52), CODE_BG, LINE)
        _rect(slide, In(0.62), y, In(0.09), In(1.52), tone)
        _txt(slide, In(0.94), y + In(0.20), In(11.4), In(0.3), name,
             size=14, bold=True)
        _txt(slide, In(0.94), y + In(0.60), In(11.4), In(0.8), why,
             size=11, color=MUTED, spacing=1.28)
        y = E(y + In(1.64))

    _benefits(slide, ["order", "parallel", "one"])
    return slide


def sizing_slide(prs):
    """Size by steps and by hand-over windows, using real estate numbers."""
    slide = _blank(prs)
    _header(slide, "How big is a batch",
            "Two limits: what one reviewer can read, and how many hand-overs can be watched at once")

    ids = list(ESTATE)[:2]
    for x, dfid in zip((In(0.62), In(6.9)), ids):
        f = ESTATE[dfid]
        _rect(slide, x, In(1.25), In(5.82), In(1.95), CODE_BG, LINE)
        _rect(slide, x, In(1.25), In(0.09), In(1.95), BRAND)
        _txt(slide, x + In(0.32), In(1.42), In(5.2), In(0.32),
             f"Dataflow {dfid}", size=15, bold=True)
        _txt(slide, x + In(0.32), In(1.82), In(5.3), In(1.25),
             f"   {f['tiles']:>3}  tiles\n"
             f"   {f['steps']:>3}  steps a reviewer has to read\n"
             f"   {f['targets']:>3}  tables to hand over\n"
             f"   {f['edges']:>3}  lineage edges",
             size=11, font="Consolas", spacing=1.3)

    _box(slide, In(0.62), In(3.40), In(5.82), In(1.25), "Reviewer hours",
         "These two differ by roughly a factor of two on every measure that costs review time. "
         "Time one reviewer through one gate, divide by steps, and size every batch from that.",
         kicker="LIMIT 1", accent=BRAND, title_size=14, body_size=10.5, spacing=1.3)

    _box(slide, In(6.9), In(3.40), In(5.82), In(1.25), "Hand-over windows",
         "Each target is one supervised switch. A batch of ten pipelines here is 9 tables changing "
         "hands — that, not review time, is usually the binding limit on a single night.",
         kicker="LIMIT 2", accent=PASS, title_size=14, body_size=10.5, spacing=1.3)

    _rect(slide, In(0.62), In(4.85), In(12.1), In(1.0), PAPER, LINE)
    _rect(slide, In(0.62), In(4.85), In(0.09), In(1.0), PASS)
    _txt(slide, In(0.94), In(5.05), In(11.5), In(0.65),
         "So \"a ten-pipeline batch\" means nothing. Size it in steps to read and tables to hand over — "
         "both of which the platform already counts for every pipeline it discovers.",
         size=12, color=MUTED, spacing=1.3)

    _benefits(slide, ["forecast", "turnaround"])
    return slide


def done_slide(prs):
    """When is a batch finished — now with per-table decommissioning."""
    slide = _blank(prs)
    _header(slide, "When is a batch actually done",
            "Agree this before the first batch, or nothing formally finishes and the savings never start")

    conditions = [
        ("Every table promoted and its staging dropped",
         "Not 'the code is written' — the job owns the real table and is the only thing writing it.",
         PASS),
        ("Replication switched off for those tables",
         "This is where the money is. It happens per table as each one is handed over, so cost falls "
         "through the programme instead of at the end of it.", FAIL),
        ("Freshness alarms live on every promoted table",
         "The hand-over is not complete until something is watching that the new owner is actually "
         "writing.", PASS),
        ("Sign-off recorded against a person",
         "Not 'approved' — who, when, and what they were looking at. The platform already writes this "
         "row for every gate.", PASS),
    ]
    y = In(1.30)
    for i, (name, why, tone) in enumerate(conditions, 1):
        _rect(slide, In(0.62), y, In(12.1), In(1.12), PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), In(1.12), tone)
        _rect(slide, In(0.94), y + In(0.36), In(0.40), In(0.40), tone)
        _txt(slide, In(0.94), y + In(0.45), In(0.40), In(0.25), str(i),
             size=11, bold=True, color=PAPER, align=PP_ALIGN.CENTER)
        _txt(slide, In(1.56), y + In(0.20), In(11), In(0.3), name,
             size=13, bold=True)
        _txt(slide, In(1.56), y + In(0.55), In(10.8), In(0.5), why,
             size=10.5, color=MUTED, spacing=1.25)
        y = E(y + In(1.22))

    _benefits(slide, ["dual", "stale"])
    return slide


# --------------------------------------------------------------------------- #
# the summary the senior will photograph
# --------------------------------------------------------------------------- #

REGISTER = [
    ("Land the data first",
     "Every input exists before any logic moves",
     ["parallel", "order"]),
    ("One table per dataset, producers swap",
     "Consumers are never edited, re-pointed or redeployed",
     ["nochange", "approvals"]),
    ("Staging table, then promote",
     "New code is proved against the live table before it can touch it",
     ["unverified", "rollback"]),
    ("Promotion only if contents match",
     "A hand-over is invisible downstream, so sequencing is unnecessary",
     ["order", "revalidate"]),
    ("Replication off per table",
     "Old-system cost falls table by table, not in one event at the end",
     ["dual"]),
    ("Batch by domain and reviewer",
     "One person can approve a whole batch in one sitting",
     ["one", "turnaround"]),
    ("Uniform complexity per batch",
     "No batch is held at the gate by its single hardest pipeline",
     ["turnaround", "forecast"]),
]


def register_slide(prs):
    """Every decision, and what it buys, on one page."""
    slide = _blank(prs)
    _header(slide, "Every decision, and what it buys",
            "The whole approach on one page — the design choice on the left, the business effect on the right")

    n = len(REGISTER)
    gap, span = In(0.11), In(5.55)
    row_h = E((span - gap * (n - 1)) / n)
    y = In(1.22)
    for decision, effect, keys in REGISTER:
        mid = E(y + row_h / 2)
        _rect(slide, In(0.62), y, In(12.1), row_h, PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), row_h, PASS)
        _txt(slide, In(0.94), mid - In(0.16), In(3.6), In(0.3), decision,
             size=11.5, bold=True)
        _txt(slide, In(4.68), mid - In(0.14), In(4.9), In(0.3), effect,
             size=10.5, color=MUTED)
        cw, cgap = In(1.36), In(0.10)
        for i, k in enumerate(keys[:2]):
            cx = E(In(9.78) + i * (cw + cgap))
            _chip(slide, cx, mid - In(0.17), cw, In(0.34), BENEFIT[k],
                  fill=PAPER, edge=PASS, color=PASS, size=7.5)
        y = E(y + row_h + gap)

    _footnote(slide, "Every line removes either a hand-off between teams or a person from an "
                     "approval queue. That is where a batch migration is won.")
    return slide


def ask_slide(prs):
    """What the platform computes, and what only the business knows."""
    slide = _blank(prs)
    _header(slide, "What we need to build the batch plan",
            "The platform already holds half of it; the rest is a short conversation")

    top, height = In(1.30), In(4.60)
    _rect(slide, In(0.62), top, In(5.82), height, CODE_BG, LINE)
    _rect(slide, In(0.62), top, In(0.09), height, PASS)
    _txt(slide, In(0.94), top + In(0.2), In(5.2), In(0.3),
         "WE ALREADY HOLD THIS", size=10.5, bold=True, color=PASS)
    _txt(slide, In(0.94), top + In(0.6), In(5.3), In(3.7),
         "A complexity score per pipeline\n"
         "  tiles, steps, targets, how much\n"
         "  translated by rule, how much did\n"
         "  not translate at all\n\n"
         "Every table each pipeline writes\n"
         "  so we know how many hand-overs\n"
         "  a batch contains\n\n"
         "Full lineage\n"
         "  no longer needed for ordering,\n"
         "  still needed to know who reads a\n"
         "  table at hand-over",
         size=11.5, spacing=1.3)

    _rect(slide, In(6.9), top, In(5.82), height, CODE_BG, LINE)
    _rect(slide, In(6.9), top, In(0.09), height, WARN)
    _txt(slide, In(7.22), top + In(0.2), In(5.2), In(0.3),
         "WE NEED THIS FROM THE BUSINESS", size=10.5, bold=True, color=WARN)
    _txt(slide, In(7.22), top + In(0.6), In(5.3), In(3.7),
         "Owner and subject area\n"
         "  per pipeline — who signs it off\n\n"
         "Criticality\n"
         "  what it feeds, and what it costs\n"
         "  to be wrong\n\n"
         "Refresh cadence\n"
         "  when it can be proved, and what\n"
         "  the freshness alarm should be\n\n"
         "Disposition\n"
         "  what is dead and can be dropped\n"
         "  before we migrate it",
         size=11.5, color=MUTED, spacing=1.3)

    _benefits(slide, ["scope", "one"])
    return slide


# --------------------------------------------------------------------------- #

def build(out: pathlib.Path) -> pathlib.Path:
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    title_slide(
        prs, "Migrating in batches",
        "Order-independent by design — and why that is safe",
        "The data moves first, so every pipeline's inputs already exist as real tables. Each pipeline "
        "is then rewritten to write a table that is already there, rather than to create a new copy of "
        "anything.\n\n"
        "A pipeline is never handed the live table until its output has been proved identical to what "
        "is in there already. Because a hand-over changes nothing that anyone can observe, no consumer "
        "has to be told, and no pipeline has to wait for another. Order stops being a dependency.\n\n"
        "What is left to decide is who reviews what, and how much of it they can sign in one sitting. "
        "That is what the batches are for.")

    plan_slide(prs)
    lift_slide(prs)

    section_slide(
        prs, "THE MECHANISM", "How a pipeline moves without anyone noticing",
        "Three ideas, in order: the table is the contract, the staging table proves the new code "
        "against it, and the promotion gate refuses the hand-over unless nothing changed.\n\n"
        "Together they are what makes the order irrelevant — not a judgement that these pipelines "
        "happen to be loosely coupled, but a property of how every single hand-over is done.")
    contract_slide(prs)
    staging_slide(prs)
    gate_slide(prs)
    order_slide(prs)
    risk_slide(prs)

    section_slide(
        prs, "THE BATCHES", "What is left to decide",
        "With sequencing designed out, a batch is no longer a technical unit. It is a review unit: "
        "one subject area, one reviewer, one sitting, one sign-off.\n\n"
        "Every factor that remains is about getting work through people faster, which is the only "
        "part of this programme that does not scale by adding machines.")
    factors_slide(prs)
    not_slide(prs)
    sizing_slide(prs)
    done_slide(prs)

    section_slide(
        prs, "THE CASE", "What the approach buys, and what we need to start",
        "Every design decision in this deck was chosen for a business reason, not an engineering "
        "preference. The next page is all of them on one line each.")
    register_slide(prs)
    ask_slide(prs)

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out


def main() -> int:
    out = build(ROOT / "docs" / "migration_batching.pptx")
    prs = Presentation(out)
    print(f"wrote {out.relative_to(ROOT)}  ({len(prs.slides._sldIdLst)} slides)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
