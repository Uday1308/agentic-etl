#!/usr/bin/env python3
"""scripts/md_table_to_json.py — turn a pasted markdown table into discovery JSON.

Databricks' notebook result grid copies as a pipe-delimited markdown table, which is
usually the fastest way to get discovery rows off a VDI. This converts that paste into
the JSON that ``local_dryrun.py`` reads.

Usage
-----
    python scripts/md_table_to_json.py --input pasted.md --output discovery_8099.json
    python scripts/md_table_to_json.py --input pasted.md --output d.json --dataflow-id 8099

What it handles
---------------
* the ``|---|---|`` separator row, and leading/trailing pipes
* ``\\|`` escaped pipes inside cell values — DOMO dataset names are full of them
  (``NA \\| F&A \\| CMS Reconciliation \\| PROD``), and a naive split destroys them
* ``null`` / empty cells, normalized to None
* JSON-valued cells left as strings; ``local_dryrun.py`` parses them
* truncated final rows (a paste cut mid-cell) reported and skipped rather than
  silently producing a malformed node
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

#: a placeholder that cannot occur in the data, used to protect escaped pipes
_ESC = "\x00PIPE\x00"


def split_row(line: str) -> list[str]:
    """Split one markdown table row, honouring ``\\|`` escapes inside cells."""
    line = line.strip()
    protected = line.replace(r"\|", _ESC)
    if protected.startswith("|"):
        protected = protected[1:]
    if protected.endswith("|"):
        protected = protected[:-1]
    return [c.strip().replace(_ESC, "|") for c in protected.split("|")]


def is_separator(cells: list[str]) -> bool:
    return bool(cells) and all(set(c) <= set("-: ") and c for c in cells)


def parse(text: str) -> tuple[list[dict], list[str]]:
    """Return (rows, problems). Only complete rows are returned."""
    lines = [ln for ln in text.splitlines() if ln.strip().startswith("|")]
    if not lines:
        raise SystemExit("no markdown table rows found (lines starting with '|')")

    header = split_row(lines[0])
    # a trailing empty header cell appears when the paste ends every row with '|'
    while header and header[-1] == "":
        header.pop()
    if not header:
        raise SystemExit("could not read a header row")

    rows: list[dict] = []
    problems: list[str] = []
    for i, line in enumerate(lines[1:], start=2):
        cells = split_row(line)
        while cells and cells[-1] == "":
            cells.pop()
        if is_separator(cells):
            continue
        if len(cells) < len(header):
            problems.append(
                f"line {i}: {len(cells)} cells for {len(header)} columns — row looks "
                f"truncated, skipped")
            continue
        if len(cells) > len(header):
            # an unescaped pipe inside a cell; keep the row but say so
            problems.append(
                f"line {i}: {len(cells)} cells for {len(header)} columns — extra cells "
                f"merged into the last column")
            cells = cells[:len(header) - 1] + ["|".join(cells[len(header) - 1:])]
        row = {}
        for key, value in zip(header, cells):
            row[key] = None if value in ("null", "NULL", "") else value
        rows.append(row)
    return rows, problems


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Convert a pasted markdown table into discovery JSON for local_dryrun.py")
    ap.add_argument("--input", required=True, help="file containing the pasted table")
    ap.add_argument("--output", required=True, help="JSON file to write")
    ap.add_argument("--dataflow-id", default="", help="keep only rows for this dataflow")
    args = ap.parse_args(argv)

    text = pathlib.Path(args.input).read_text(encoding="utf-8-sig")
    rows, problems = parse(text)

    if args.dataflow_id:
        before = len(rows)
        rows = [r for r in rows if str(r.get("dataflow_id") or "") == str(args.dataflow_id)]
        print(f"filtered to dataflow {args.dataflow_id}: {len(rows)} of {before} rows")

    pathlib.Path(args.output).write_text(json.dumps(rows, indent=1), encoding="utf-8")

    kinds: dict[str, int] = {}
    ops: dict[str, int] = {}
    for r in rows:
        kinds[str(r.get("record_type"))] = kinds.get(str(r.get("record_type")), 0) + 1
        if str(r.get("record_type")) == "NODE":
            op = str(r.get("operation_type") or "?")
            ops[op] = ops.get(op, 0) + 1

    print(f"wrote {args.output} · {len(rows)} rows")
    print(f"  record types : {kinds}")
    print(f"  node op types: {dict(sorted(ops.items(), key=lambda kv: -kv[1]))}")
    runs = {str(r.get("discovery_run_id")) for r in rows if r.get("discovery_run_id")}
    if len(runs) > 1:
        print(f"  NOTE: {len(runs)} discovery runs present — local_dryrun.py will use the newest")
    if problems:
        print(f"\n  {len(problems)} problem row(s):", file=sys.stderr)
        for p in problems:
            print(f"    {p}", file=sys.stderr)
        print("\n  A truncated paste is the usual cause. Re-copy the missing rows and "
              "re-run; nodes are matched by id, so order does not matter.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
