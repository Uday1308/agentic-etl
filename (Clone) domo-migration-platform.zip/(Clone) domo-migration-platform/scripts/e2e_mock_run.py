#!/usr/bin/env python3
"""scripts/e2e_mock_run.py — all seven agents, start to finish, on this machine.

>>> THE EXTERNAL SYSTEMS ARE MOCKED. THE PLATFORM IS NOT. <<<

    real    every tile renderer, the expression emitter, the plan renderer, the SQL
            assembler and generator, the deterministic JSON validator, the judge
            rules, the parity arithmetic, the section splitter, the real Runner and
            Strategy classes of all seven agents, the real LLMClient
    mocked   the DOMO API, the UC volume, the Delta discovery table, the Databricks
            job runner, the Spark table reader, the serving endpoint

So a green run proves the deterministic half works end to end and that the seven
agents compose. It proves nothing about DOMO's API, about Spark, or about what a
real model would answer — see ``scripts/mocks.py`` for exactly what each mock does
and does not stand for.

What it writes
--------------
Telemetry as JSON Lines and gate payloads, into the same place the Control Tower
reads (``.platform_local`` by default), so the run shows up in the UI as a real run
rather than as seed data::

    python scripts/e2e_mock_run.py
    uvicorn api.app:app --reload --port 8000
    cd lv-tower && npm run dev

Gates
-----
Every HITL gate is **auto-approved**, by an actor literally called
``e2e-mock-run@localhost``, and each approval writes its ``DecisionRow`` like any
other. Nobody reviewed anything; the audit trail says so rather than implying a
person was there. Use ``--stop-at md_plan`` to leave a gate genuinely open and
review it in the UI instead.
"""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import json
import pathlib
import re
import sys
import time
import traceback
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.cd_codegen.sql_assembly import SqlAssembler  # noqa: E402
from agents.cd_codegen.sql_generator import generate_sql  # noqa: E402
from agents.cd_codegen.translate.artifacts import write_artifact  # noqa: E402
from agents.classifier.strategies import (  # noqa: E402
    ClassifierRunner,
    LayerClassifier,
)
from agents.connection.strategies import ConnectionRunner  # noqa: E402
from agents.discovery.strategies import DiscoveryBuilder  # noqa: E402
from agents.master import AGENT_ORDER, AGENT_PHASES  # noqa: E402
from agents.md_plan.render import PlanRenderer, resolve_dynamic_columns  # noqa: E402
from agents.standardization.strategies import (  # noqa: E402
    ChunkStandardizer,
    StandardizationEvaluator,
    StandardizationRunner,
)
from core.contracts.judges import JudgeRegistry  # noqa: E402
from core.contracts.logic_parity import logic_parity  # noqa: E402
from core.contracts.standardized import to_planner_dataflow  # noqa: E402
from core.contracts.telemetry import (  # noqa: E402
    DecisionKind,
    DecisionRow,
    IngestionRow,
    IngestPurpose,
    StepRow,
    StepStatus,
    ValidationRow,
)
from core.domo.concurrency import ConcurrencyManager  # noqa: E402
from core.domo.llm import LLMClient  # noqa: E402
from core.domo.materialize import UNMATERIALIZED  # noqa: E402
from core.domo.materialize import promote as mat_promote  # noqa: E402
from core.domo.materialize import references as mat_references  # noqa: E402
from core.domo.models import EndpointSpec, ModelRegistry  # noqa: E402
from core.domo.naming import policy_from_args, set_policy  # noqa: E402
from core.domo.prompts import HardConstraintChecker, PromptAssembler  # noqa: E402
from core.domo.sinks import JsonSink, RecordingObservability, utc_now  # noqa: E402
from core.review import AWAITING_REVIEW, may_auto_approve, payload_hash  # noqa: E402
from judges.rules import DEFAULT_JUDGES  # noqa: E402
from scripts.mocks import (  # noqa: E402
    DictLayerStore,
    FileArtifactStore,
    FileJsonStore,
    FilePlanStore,
    JsonDiscoveryWriter,
    MockDomoClient,
    MockEtlMaster,
    MockPipelineRunner,
    MockSourceProbe,
    PairReader,
    RawAwareStandardizer,
    ScriptedCaller,
    StaticRulesLoader,
)

ACTOR = "e2e-mock-run@localhost"

#: An EvalResult the evaluators can parse. Verdict `pass` with a stated confidence,
#: and NO issues: this is a scripted answer, and inventing findings would put words
#: in a reviewer's mouth and populate the UI with fictional problems.
EVAL_PASS = json.dumps({
    "verdict": "pass", "confidence": 0.8, "issues": [],
    "summary": "Scripted evaluator response from scripts/mocks.py. No model was "
               "called and nothing was actually reviewed.",
})

#: The classifier's layer assignment. Keyed by the target's df_var at run time, so
#: this is only the fallback shape; see `_classify`.
LAYER_JSON = json.dumps({"verdict": "pass", "confidence": 0.7, "issues": [],
                         "summary": "Scripted layer assignment."})


def scripted_caller() -> ScriptedCaller:
    """One fingerprint per prompt any agent actually sends.

    Every entry corresponds to a real ``PromptLayers(base=...)`` in the agents. An
    unregistered prompt raises, which is how a new model call announces itself
    rather than quietly getting a canned answer.
    """
    return (ScriptedCaller()
            .on("standardize chunk", "{}")
            .on("review the standardized domo json", EVAL_PASS)
            .on("translate one domo magic etl tile", "```python\ndf = df\n```")
            .on("review this migration plan", EVAL_PASS)
            .on("you are reviewing generated pyspark code", EVAL_PASS)
            .on("assign each node to a medallion layer", LAYER_JSON)
            .on("diagnose these parity failures", EVAL_PASS))


class Stage:
    """Emits the phase rows for one agent, so the UI's stage strip is real.

    Phases come from ``AGENT_PHASES`` and are written verbatim — the UI renders
    these strings directly, so a harness that invented its own would be showing
    progress text the platform never emits.
    """

    def __init__(self, run: "Run", agent: str) -> None:
        self.run, self.agent = run, agent
        self.phases = AGENT_PHASES[agent]
        self._i = 0
        self.t0 = time.perf_counter()

    def phase(self, status: StepStatus = StepStatus.OK, detail: str = "") -> None:
        """Close the current phase and move on."""
        if self._i >= len(self.phases):
            return
        elapsed = int((time.perf_counter() - self.t0) * 1000)
        self.run.sink.step(StepRow(
            run_id=self.run.run_id, ts=utc_now(), environment="dev",
            step_id=f"{self.agent}-{self._i + 1}", agent=self.agent,
            phase=self.phases[self._i], phase_index=self._i,
            phase_count=len(self.phases), iteration=1, status=status,
            duration_ms=max(elapsed, 1), detail=detail))
        self._i += 1
        self.t0 = time.perf_counter()

    def finish(self, status: StepStatus = StepStatus.OK, detail: str = "") -> None:
        """Emit whatever phases are left, so a stage never looks half-run."""
        while self._i < len(self.phases):
            last = self._i == len(self.phases) - 1
            self.phase(status if last else StepStatus.OK, detail if last else "")
        if self.agent not in self.run.completed:
            self.run.completed.append(self.agent)


class _Subject:
    """What a judge inspects: the artifact text and its node index.

    Structural duck-typing, matching `Judgeable` — the judges read `.artifact`,
    `.node_ids` and `.meta` and nothing else.
    """

    def __init__(self, artifact: str, node_ids: list[str], meta: dict) -> None:
        self.artifact, self.node_ids, self.meta = artifact, node_ids, meta


class Run:
    """One end-to-end run: its telemetry sink, its artifacts, its gates."""

    def __init__(self, dataflow_id: str, *, work: pathlib.Path, run_id: str = "",
                 stop_at: str = "", volume: pathlib.Path | str = "") -> None:
        self.dataflow_id = str(dataflow_id)
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H-%M-%S")
        self.run_id = run_id or f"run-{self.dataflow_id}-{stamp}"
        self.work = pathlib.Path(work)
        # The volume layout mirrors production exactly - <volume>/<id>/{md,sql,
        # discovery,gates,...} - so DeltaStore's paths and this dry run's paths are
        # the same shape. Only the root differs: a directory here, /Volumes/... there.
        self.volume = pathlib.Path(volume) if volume else (self.work / "volume")
        # Everything one run produced lives under one folder, keyed by run id:
        # artifacts, gates and its own observability. Keying by dataflow instead
        # meant a second run of the same flow overwrote the first's gates and
        # left the completed run showing a review it had never had open.
        self.artifacts = self.volume / self.dataflow_id / self.run_id
        self.artifacts.mkdir(parents=True, exist_ok=True)
        # Mock mode: the six audit tables as JSON beside the artifacts they describe.
        # PLATFORM_STORE=delta swaps this for DeltaSink; nothing else changes.
        self.sink = JsonSink(self.artifacts / "telemetry")
        self.stop_at = stop_at
        self.dataflow_name = ""
        self.started_ts = utc_now()
        self.gates: list[dict] = []
        self.failures: list[str] = []
        #: agents whose phases all emitted - what "how far did it get" means here
        self.completed: list[str] = []
        #: gates the review rule left open for a human (ADR 032 section 3)
        self.held: list[dict] = []
        #: agent -> an earlier human approval ``{payload_hash, reviewer, decision_id}`` that
        #: ``run_batch --resume`` hands in; reused only when the payload hash is unchanged
        self.reuse: dict[str, dict] = {}
        self.source_id = ""
        #: ``{mapped, transpiled, ai, manual, unresolved, total, share}`` once cd_codegen ran
        self.coverage: dict | None = None

    @property
    def awaiting_review(self) -> bool:
        return bool(self.held)

    @property
    def status(self) -> str:
        if self.held:
            return AWAITING_REVIEW
        return "failed" if self.failures else "migrated"

    # -- gates ------------------------------------------------------------- #
    def gate(self, agent: str, *, artifact: dict | None = None,
             judges: list[dict] | None = None, iteration: int = 1,
             origins: list[str] | None = None, review_caveats: list[str] | None = None,
             reviewed: Any = None, **extra) -> dict:
        """Write one gate payload, then approve it unless we were told to stop here.

        The payload is the shape ``api/`` serves and the UI renders, so a gate from
        this run is indistinguishable from one the real pipeline paused at — which
        is the point: it is the same contract, not a parallel one.
        """
        gate_id = f"gate-{agent}-{self.dataflow_id}-i{iteration}"
        payload = {
            "gate_id": gate_id, "run_id": self.run_id,
            "dataflow_id": self.dataflow_id, "dataflow_name": self.dataflow_name,
            "agent": agent, "iteration": iteration, "status": "interrupted",
            "artifact": artifact, "judges": judges or [],
            "eval": {"verdict": "pass", "confidence": 0.8, "issues": [],
                     "summary": "Scripted evaluator response. Nothing was reviewed."},
            "standing_hard_constraints": [],
            "actions": ["apply_issue", "keep_issue", "add_hard_constraint",
                        "freeform", "approve", "regenerate"],
            **extra,
        }
        kind = (artifact or {}).get("kind")
        if reviewed is not None:
            payload["payload_hash"] = payload_hash(reviewed)
        if origins is not None:
            payload["origins"] = sorted(set(origins))
        allowed, why_not = may_auto_approve(kind, origins or [], review_caveats or [])
        reuse = self.reuse.get(agent) or {}
        reused = bool(not allowed and reuse and reuse.get("payload_hash")
                      and reuse.get("payload_hash") == payload.get("payload_hash"))
        if not allowed and not reused:
            payload["review_required"] = why_not
        if reused:
            payload["reused_from"] = reuse.get("decision_id", "")
        path = self.artifacts / "gates"
        path.mkdir(parents=True, exist_ok=True)
        (path / f"{gate_id}.json").write_text(json.dumps(payload, indent=1, default=str),
                                              encoding="utf-8")
        self.gates.append(payload)

        if self.stop_at == agent:
            print(f"      gate {gate_id} LEFT OPEN (--stop-at {agent})")
            return payload

        if reused:
            # an unchanged payload a human already approved: re-approved under THEIR name
            self.sink.decision(DecisionRow(
                run_id=self.run_id, ts=utc_now(), environment="dev",
                dataflow_id=self.dataflow_id, agent=agent, iteration=iteration,
                kind=DecisionKind.APPROVED, actor=reuse.get("reviewer") or "unknown-reviewer",
                rationale=f"reused_from: {reuse.get('decision_id', '')} (payload hash unchanged)"))
            print(f"      gate {gate_id} re-approved from {reuse.get('decision_id', '')}")
            return payload
        if not allowed:
            # The review rule: the harness actor does not approve this gate (ADR 032 section 3).
            self.held.append({"gate_id": gate_id, "agent": agent, "reason": why_not,
                              "payload_hash": payload.get("payload_hash", "")})
            print(f"      gate {gate_id} LEFT OPEN for review ({why_not})")
            return payload

        # Auto-approval is still a decision, and it goes in the audit trail as one.
        self.sink.decision(DecisionRow(
            run_id=self.run_id, ts=utc_now(), environment="dev",
            dataflow_id=self.dataflow_id, agent=agent, iteration=iteration,
            kind=DecisionKind.APPROVED, actor=ACTOR,
            rationale="auto-approved by scripts/e2e_mock_run.py; no human reviewed this"))
        print(f"      gate {gate_id} auto-approved")
        return payload

    def judge_artifact(self, agent: str, sql: str, node_keys: list[str]) -> list[dict]:
        """Run the real deterministic judges over a generated artifact."""
        registry = JudgeRegistry(list(DEFAULT_JUDGES))
        panel = registry.run(agent, _Subject(sql, list(node_keys), {}), iteration=1)
        self.sink.judge_panel(panel, run_id=self.run_id)
        return [{"rule_id": r.rule_id, "title": r.title, "kind": r.kind.value,
                 "verdict": r.verdict.value, "findings": len(r.findings),
                 "checked": r.checked,
                 "nodes": [f.node for f in r.findings if f.node], "note": r.note}
                for r in panel.results]


# --------------------------------------------------------------------------- #
# the seven stages
# --------------------------------------------------------------------------- #

# Where source data lands and where migrated logic writes. The defaults are the demo workspace's; a batch handoff
# from the wave planner (scripts/run_batch.py) passes its own, so nothing about the target is hard-coded per run.
DEFAULT_NAMING = {"source_catalog": "dev_test", "source_schema": "domo_input",
                  "target_catalog": "dev_test", "target_schema": "migrated_output", "layer_catalog": "dev_test"}
_NAMING: dict[str, str] = dict(DEFAULT_NAMING)


async def run_pipeline(dataflow_id: str, *, work: pathlib.Path, stop_at: str = "",
                       column_style: str = "delta_safe", input_json: str = "",
                       volume: pathlib.Path | str = "", naming: dict | None = None,
                       reuse_approvals: dict[str, dict] | None = None, source_id: str = "") -> Run:
    set_policy(policy_from_args(column_style))
    _NAMING.clear()
    _NAMING.update({**DEFAULT_NAMING, **{k: v for k, v in (naming or {}).items() if v}})
    run = Run(dataflow_id, work=work, stop_at=stop_at, volume=volume)
    run.reuse = dict(reuse_approvals or {})
    run.source_id = source_id
    caller = scripted_caller()
    # The real LLMClient with all five collaborators — only the endpoint is faked.
    # Observability is pointed at the run's own sink, so every scripted call still
    # produces a genuine LlmCallRow and the cost panel reflects what was actually
    # asked. The rate card is a real published price so the arithmetic is exercised;
    # the token counts feeding it are the mock's.
    llm = LLMClient(
        registry=ModelRegistry({"dev": {
            "generator": EndpointSpec(endpoint="mock-generator"),
            "evaluator": EndpointSpec(endpoint="mock-evaluator"),
            "classifier": EndpointSpec(endpoint="mock-classifier"),
        }}),
        assembler=PromptAssembler(),
        checker=HardConstraintChecker(),
        concurrency=ConcurrencyManager({"standardization_chunks": 4, "evaluation": 2,
                                        "md_translation": 4, "classification": 2,
                                        "default": 4}),
        observability=RecordingObservability(
            run.sink, run_id=run.run_id, environment="dev",
            rate_card={"mock-generator": (0.003, 0.015),
                       "mock-evaluator": (0.003, 0.015),
                       "mock-classifier": (0.003, 0.015)}),
        caller=caller,
    )
    def cfg(agent: str, iteration: int = 1) -> dict:
        """The RunnableConfig for one stage.

        ``agent`` matters: LLMClient reads it out of `configurable` and stamps it on
        every LlmCallRow. Without it the cost panel groups every call under the empty
        string, which is how spend stops being attributable to an agent.
        """
        return {"configurable": {"run_id": run.run_id, "obs_run_id": run.run_id,
                                 "environment": "dev", "dataflow_id": dataflow_id,
                                 "agent": agent, "iteration": iteration}}

    config = cfg("")
    state: dict = {"dataflow_id": dataflow_id, "dataflow_name": ""}

    print(f"\nrun_id  {run.run_id}")
    print(f"work    {run.work}")
    print(f"volume  {run.volume}")
    print(f"agents  {' -> '.join(AGENT_ORDER)}\n")

    # Where the export is read from, most specific first. `<volume>/raw/<id>.json`
    # is the one that matches production: something upstream drops the DOMO export
    # on the volume and the pipeline picks it up from there.
    candidates = ([pathlib.Path(input_json)] if input_json else
                  [run.volume / "raw" / f"dataflow_{dataflow_id}.json",
                   run.volume / "raw" / f"{dataflow_id}.json",
                   run.volume / "raw" / f"{dataflow_id}_standardized.json",
                   ROOT / f"{dataflow_id}_standardized.json"])
    standardized_path = next((c for c in candidates if c.exists()), candidates[0])
    if not standardized_path.exists():
        raise SystemExit(
            f"no dataflow export found. Looked in: "
            f"{', '.join(str(c) for c in candidates)}. Drop the DOMO export at "
            f"<volume>/raw/{dataflow_id}.json, or pass --input <file.json>. "
            f"The harness needs a standardized export to stand in for the raw DOMO "
            f"payload, because the real raw export is not in this repo; see "
            f"scripts/mocks.py.")

    volume = run.artifacts
    raw_store = FileJsonStore(volume, "raw")
    std_store = FileJsonStore(volume, "standardized")

    # -- 1 · connection ---------------------------------------------------- #
    st = Stage(run, "connection")
    domo = MockDomoClient(standardized_path, dataflow_id)
    master = MockEtlMaster()
    st.phase()                                              # Authenticating
    result = ConnectionRunner(domo, raw_store, master, use_domo_api=True).run(state, config)
    st.phase()                                              # Listing datasets
    raw = raw_store.read(dataflow_id)
    run.dataflow_name = raw.get("name", "") or dataflow_id
    state["dataflow_name"] = run.dataflow_name
    st.finish(detail=f"flipped={result['status_flipped']}")  # Caching metadata
    print(f"  1 connection       {run.dataflow_name}")
    print(f"      raw written    {result['artifact_path']}")
    print(f"      history        {len(result['execution_history'])} executions (mock)")

    # -- 2 · standardization ------------------------------------------------ #
    st = Stage(run, "standardization")
    st.phase()                                              # Reading raw artifacts
    runner = StandardizationRunner(
        reader=raw_store, store=std_store,
        standardizer=RawAwareStandardizer(ChunkStandardizer(llm, chunk_size=25)),
        evaluator=StandardizationEvaluator(llm))
    out = await runner.run(state, cfg("standardization"))
    st.phase()                                              # Normalizing schema
    st.finish(detail=f"{out['nodes']} actions")             # Deduplicating revisions
    print(f"  2 standardization  {out['nodes']} actions, verdict={out['verdict']}, "
          f"validator problems={len(out['validator_problems'])}")

    standardized = std_store.read(dataflow_id)
    folded = to_planner_dataflow(standardized, dataflow_id)

    # -- 3 · discovery ------------------------------------------------------ #
    st = Stage(run, "discovery")
    writer = JsonDiscoveryWriter(volume)
    probe = MockSourceProbe()

    class _Reader:
        def read(self, _id): return folded

    st.phase()                                              # Understanding dataflow
    st.phase()                                              # Extracting nodes
    disco = DiscoveryBuilder(_Reader(), writer, probe).run(state, config)
    st.phase()                                              # Resolving lineage
    st.finish(detail=f"{len(writer.rows)} rows")            # Writing discovery table
    nodes = [r for r in writer.rows if r["record_type"] == "NODE"]
    lineage = [r for r in writer.rows if r["record_type"] == "LINEAGE"]
    print(f"  3 discovery        {len(nodes)} nodes, {len(lineage)} lineage rows "
          f"-> {disco.get('artifact_path', 'jsonl')}")

    ingest_rows = []
    for i, src in enumerate(standardized[dataflow_id].get("inputs") or [], start=1):
        rows = probe.row_count(f"src_{i}")
        ingest_rows.append(IngestionRow(
            run_id=run.run_id, ts=utc_now(), environment="dev",
            dataset_id=src.get("dataSourceId", ""),
            dataset_name=src.get("dataSourceName", ""),
            purpose=IngestPurpose.CREATION,
            target_table=f"{_NAMING['source_catalog']}.{_NAMING['source_schema']}.src_{i}",
            rows_ingested=rows, domo_row_count=rows, batch_id=4,
            batch_last_run="2026-09-26T14:02:07.000+00:00",
            duration_ms=1200 + i * 40, status="ok", used_domo_api=True))
    for row in ingest_rows:
        run.sink.ingestion(row)

    # -- 4 · md_plan -------------------------------------------------------- #
    st = Stage(run, "md_plan")
    plan_store = FilePlanStore(volume)
    PairReader(standardized, raw)                # the port md_plan reads in production
    st.phase()                                              # Understanding tiles
    st.phase()                                              # Context engineering
    renderer = PlanRenderer(dialect="sql", source_catalog=_NAMING["source_catalog"],
                            source_schema=_NAMING["source_schema"], target_catalog=_NAMING["target_catalog"],
                            target_schema=_NAMING["target_schema"])
    build = renderer.build(folded, raw, dataflow_id=dataflow_id,
                           dataflow_name=run.dataflow_name)
    st.phase()                                              # Translating expressions
    plan_path = plan_store.write(dataflow_id, 1, build.document)
    st.phase()                                              # Rendering plan
    resolved = build.resolved_count
    total = len(build.steps)
    coverage = round(100.0 * resolved / total, 1) if total else 0.0
    print(f"  4 md_plan          {resolved}/{total} steps deterministic ({coverage}%)")
    print(f"      plan           {plan_path}")

    graph = build_graph(folded, build, None, ingest_rows)
    graph_path = volume / f"graph_{dataflow_id}.json"
    graph_path.write_text(json.dumps(graph, indent=1), encoding="utf-8")
    print(f"      graph          {len(graph)} nodes -> {graph_path.name}")

    plan_summary = {"sources": len(build.sources), "steps": total,
                    "targets": len(build.targets), "deterministic": resolved,
                    "by_model": 0, "unresolved": len(build.unresolved),
                    "coverage_pct": coverage}
    # The plan gets judged too. It did not before - the registry ran only on the
    # SQL - so the md_plan gate showed a reviewer "0 checks" on the one artifact
    # whose approval is the point of the gate. The plan rules read the plan's own
    # grammar; the SQL rules are scoped away from it rather than passing vacuously.
    plan_judges = run.judge_artifact("md_plan", build.document,
                                     [str(s.node_id) for s in build.steps])
    plan_failed = [j["rule_id"] for j in plan_judges if j["verdict"] == "fail"]
    print(f"      judges         {len(plan_judges)} rules, {len(plan_failed)} failing "
          f"{plan_failed if plan_failed else ''}")
    st.finish(status=StepStatus.INTERRUPTED if stop_at == "md_plan" else StepStatus.OK,
              detail="awaiting review" if stop_at == "md_plan" else "")
    plan_origins = ["mapped" if s.result.resolved else "unresolved" for s in build.steps]
    run.gate("md_plan", judges=plan_judges,
             artifact={"kind": "plan", "version": 1, "path": plan_path,
                       "summary": plan_summary, "sha256": payload_hash(build.document)},
             origins=plan_origins, reviewed=build.document)
    if stop_at == "md_plan" or run.held:
        record_run(run, input_path=standardized_path, stopped_at=stop_at or ("md_plan" if run.held else ""))
        return run

    # -- 5 · cd_codegen ----------------------------------------------------- #
    st = Stage(run, "cd_codegen")
    sql_store = FileArtifactStore(volume)
    st.phase()                                              # Reading approved plan
    st.phase()                                              # Extracting code
    gen = generate_sql(folded, dataflow_id=dataflow_id, dataflow_name=run.dataflow_name,
                       raw=raw, materialize=False, source_catalog=_NAMING["source_catalog"],
                       source_schema=_NAMING["source_schema"], target_catalog=_NAMING["target_catalog"],
                       target_schema=_NAMING["target_schema"])
    st.phase()                                              # Context engineering
    targets_meta = []
    for art in gen.succeeded:
        stem = f"etl_{dataflow_id}__{_slug(art.target)}"
        path = sql_store.write(dataflow_id, 1, art.sql, name=stem)
        # ADR 032 section 3: the gate holds a ref, its sha256 and a MASKED preview; the
        # unmasked text stays on the volume and is served through the access-checked API
        record = write_artifact(run.volume, _etl_key(run, dataflow_id), art.sql, source_id=run.source_id)
        targets_meta.append({"target": art.target, "table": art.table, "path": path,
                             "ctes": art.sql.count(" AS ("), "explain": "not run (mock)",
                             **record.as_dict()})
    st.phase()                                              # Assembling notebook
    print(f"  5 cd_codegen       {len(gen.succeeded)} targets, {len(gen.failed)} failed")
    print(f"      coverage       {gen.coverage}")
    run.coverage = gen.coverage_split
    if gen.escalated_steps:
        run.failures.append(f"cd_codegen left {len(gen.escalated_steps)} step(s) unresolved")

    biggest = max(gen.succeeded, key=lambda a: len(a.sql)) if gen.succeeded else None
    judges = run.judge_artifact("cd_codegen", biggest.sql if biggest else "",
                                biggest.node_keys if biggest else [])
    failed_rules = [j["rule_id"] for j in judges if j["verdict"] == "fail"]
    print(f"      judges         {len(judges)} rules, {len(failed_rules)} failing "
          f"{failed_rules if failed_rules else ''}")
    st.finish()                                             # Evaluating
    run.gate("cd_codegen", iteration=1,
             artifact={"kind": "sql", "version": 1, "targets": targets_meta,
                       "coverage": gen.coverage_split},
             judges=judges, origins=list(gen.origins.values()),
             reviewed=sorted(t["sha256"] for t in targets_meta))
    if stop_at == "cd_codegen" or run.held:
        record_run(run, input_path=standardized_path, stopped_at=stop_at or ("cd_codegen" if run.held else ""))
        return run

    # -- 6 · validation ----------------------------------------------------- #
    st = Stage(run, "validation")
    st.phase()                                              # Submitting job
    st.phase()                                              # Waiting for the pipeline
    # Logic parity, not data parity: computed from the DOMO graph and the SQL that
    # was just generated, so it needs neither engine to have run. It says the shape
    # is right - every tile present, wired as DOMO wires it, every column read
    # actually produced upstream. It says nothing about values.
    df_var_of = {str(s.node_id): s.df_var for s in build.steps}
    df_var_of.update({str(sv["node_id"]): sv["df_var"] for sv in build.sources})
    # `nodes` is rebound by the discovery stage to discovery-table ROWS; the graph
    # nodes are these. Passing the wrong one fails every check silently, because
    # no tile matches and "no CTE for this tile" is a legitimate finding.
    graph_nodes = resolve_dynamic_columns(list(folded.get("nodes") or []),
                                          list(folded.get("edges") or []))
    parity = logic_parity(gen.succeeded, nodes=graph_nodes,
                          edges=list(folded.get("edges") or []),
                          df_var_of=df_var_of,
                          sections_of=lambda a: SqlAssembler.split_sections(a.sql))
    st.phase()                                              # Running row parity
    parity_rows = []
    for p in parity:
        parity_rows.append({
            "target": p.target, "table": p.table,
            "checks_run": p.checks_run, "checks_passed": p.checks_passed,
            "blocking_failures": len(p.failures),
            "advisory_failures": len(p.unverifiable),
            "exact": p.exact, "passed": p.passed,
            # Row counts belong to data parity. Leaving them null is the honest
            # answer here - the UI renders an em dash, never a zero.
            "source_rows": None, "migrated_rows": None,
            "failure_category": "logic" if p.failures else "",
            "owner_agent": "cd_codegen" if p.failures else "",
            "diagnosis": p.diagnosis(),
            "checks": [{"check": f.check, "verdict": f.verdict, "detail": f.detail}
                       for f in p.findings],
        })
        run.sink.validation(ValidationRow(
            run_id=run.run_id, ts=utc_now(), environment="dev",
            dataflow_id=dataflow_id, target=p.target, table=p.table,
            checks_run=p.checks_run, checks_passed=p.checks_passed,
            blocking_failures=len(p.failures), advisory_failures=len(p.unverifiable),
            exact=p.exact, passed=p.passed,
            failure_category="logic" if p.failures else "",
            owner_agent="cd_codegen" if p.failures else "",
            diagnosis=p.diagnosis()))
    st.phase()                                              # Comparing schemas
    passed = sum(1 for r in parity_rows if r["passed"])
    exact = sum(1 for r in parity_rows if r["exact"])
    print(f"  6 validation       {passed}/{len(parity_rows)} targets pass logic parity "
          f"({exact} fully verified)")
    if passed < len(parity_rows):
        run.failures.append(f"validation: {len(parity_rows) - passed} target(s) "
                            f"failed logic parity")
    st.finish()                                             # Diagnosing

    run.gate("validation", results=parity_rows)
    if stop_at == "validation":
        record_run(run, input_path=standardized_path, stopped_at=stop_at)
        return run

    # -- 7 · classifier ------------------------------------------------------ #
    st = Stage(run, "classifier")
    st.phase()                                              # Reading node sections
    # The real ClassifierRunner: LLM assignment governed by config, then the real
    # SectionSplitter, then the layer files. Every target's SQL is concatenated
    # first, because the medallion split is a property of the dataflow, not of one
    # output - and `sections()` keys by node id, so CTEs shared between targets
    # collapse to one entry rather than being classified twice.
    combined = "\n".join(a.sql for a in gen.succeeded)
    final_ctes = {a.final_cte for a in gen.succeeded}

    # Config decides, the model applies. The output CTE of each target is pinned to
    # gold here because a Databricks SQL artifact has no WRITE node section to infer
    # it from - the target is the closing SELECT, not a tile.
    # The namer needs to know each node's layer, and the assignment is only known
    # after the classifier runs - so it is filled in by reference.
    assignment_layer: dict[str, str] = {}
    # Which intermediates become tables. The default is NONE of them: an
    # intermediate CTE is computed once either way, and materializing it costs a
    # table, a write, and one more thing to keep in sync with the tile it came
    # from. The exception is a JOIN - it is where a query's cost concentrates, it
    # is the step most often reused across targets, and it is the natural place to
    # cut a long chain into stages someone can inspect.
    #
    # Keeping joins materialized is also what exercises the rule that matters
    # here: a gold statement's walk back STOPS at a materialized node and reads it
    # as a table rather than re-deriving it. With every intermediate inlined there
    # is nothing to stop at, and a gold script that inlines the whole dataflow
    # would look correct while proving nothing.
    #
    # Sources and target outputs are never demoted: bronze is the landed copy and
    # gold is what someone consumes, regardless of how many readers each has.
    all_sections = SqlAssembler.split_sections(combined)
    source_ctes = {sv["df_var"] for sv in build.sources}
    joins = {n for n, body in all_sections.items() if _op_of(body) == "JOIN"}
    transient = {n for n in all_sections
                 if n not in final_ctes and n not in source_ctes and n not in joins}

    rules = StaticRulesLoader({
        "bronze_ops": ["SOURCE"],
        "gold_ops": ["WRITE"],
        "overrides": {**{cte: "gold" for cte in final_ctes},
                      **{cte: UNMATERIALIZED for cte in transient}},
    })
    layer_store = FileArtifactStore(volume, "layers")
    # What each materialized node is CALLED. A node's CTE name (`df_join_data_4_s06`)
    # is an address inside one artifact, not a table anybody would want in a
    # warehouse - and for a target it is doubly wrong, because that dataflow's
    # output already HAS a name, which is the whole point of the migration. So:
    # a target writes its real table, a source writes its landed table, and only a
    # genuine intermediate falls back to a name derived from the CTE.
    table_of = _table_namer(build, gen, assignment_layer)
    runner = ClassifierRunner(
        classifier=LayerClassifier(llm, rules),
        layers=DictLayerStore(), splits=layer_store,
        pipelines=MockPipelineRunner(), grouping="single",
        table_of=table_of)
    state["cd_codegen"] = {"gen": {"artifact": combined}}
    st.phase()                                              # Classifying layers
    # Seed the namer before the runner splits: assign() runs first inside run(),
    # but split() needs the layers, so the dict is shared and filled in between.
    proposed = await runner._classifier.assign(combined, state, cfg("classifier"))
    # The config pins each target's output CTE to gold, but some of those are
    # UPSTREAM of another target's silver nodes - which would emit a silver script
    # reading a gold table that does not exist yet. Raise the offenders to the
    # layer their own lineage demands; never lower a dependency, which would
    # silently undo a deliberate placement.
    settled = mat_promote(all_sections, proposed)
    moved = {n: (proposed[n], settled[n]) for n in settled if settled[n] != proposed[n]}
    if moved:
        print(f"      layering       {len(moved)} node(s) promoted to satisfy lineage "
              f"(e.g. {next(iter(moved))}: {list(moved.values())[0][0]} -> "
              f"{list(moved.values())[0][1]})")
    assignment_layer.update(settled)
    runner._classifier.assign = _settled_assign(settled)   # noqa: SLF001
    out = await runner.run(state, cfg("classifier"))
    st.phase()                                              # Splitting code
    counts = out["counts"]
    layers = _layers_payload(out, gen, build, standardized[dataflow_id],
                             sections=all_sections, table_of=table_of)
    print(f"  7 classifier       {counts}")
    print(f"      layer files    {', '.join(sorted(out['layer_paths']))}")
    st.finish(detail=json.dumps(counts))                    # Launching pipelines
    run.gate("classifier", layers=layers)
    record_run(run, input_path=standardized_path, stopped_at=stop_at)
    return run


def _is_raw_domo_export(path: pathlib.Path) -> bool:
    """True for a DOMO API payload rather than a standardized document.

    Told apart by what only the raw form has (`dapDataFlowId`, `engineProperties`)
    and what only the standardized form has (a `connections` list). Guessing wrong
    in either direction produces a silently empty run, so both are checked.
    """
    try:
        doc = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return False
    flow = doc if isinstance(doc, dict) else {}
    if len(flow) == 1 and isinstance(next(iter(flow.values()), None), dict):
        flow = next(iter(flow.values()))
    raw_only = {"dapDataFlowId", "engineProperties", "executionCount"}
    return bool(raw_only & set(flow)) and "connections" not in flow


def _etl_key(run: "Run", dataflow_id: str) -> str:
    """Path-safe per-ETL folder key; ``{source_id}__{etl_id}`` once manifests carry a source."""
    raw = f"{run.source_id}__{dataflow_id}" if run.source_id else str(dataflow_id)
    return re.sub(r"[^A-Za-z0-9._-]+", "_", raw).strip("._-") or "etl"


def record_run(run: "Run", *, input_path: pathlib.Path, stopped_at: str) -> pathlib.Path:
    """Append this run to ``<volume>/runs.json``, replacing any earlier entry.

    The registry answers "what runs exist and what produced them". It deliberately
    holds no counts: those are computed from telemetry so the dashboard cannot
    disagree with the deliverable, which is the rule RunSummary states outright.

    Rewritten whole rather than appended to, because a half-written registry is
    worse than a stale one - and at this size the cost is nothing.
    """
    path = run.volume / "runs.json"
    existing = []
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            # A corrupt registry must not silently drop every prior run: keep it
            # aside so someone can see what happened.
            path.rename(path.with_suffix(".json.corrupt"))
            existing = []
    record = {
        "run_id": run.run_id,
        "dataflow_id": run.dataflow_id,
        "dataflow_name": run.dataflow_name,
        "started_ts": run.started_ts,
        "ended_ts": utc_now(),
        "input_path": str(input_path),
        "volume": str(run.volume),
        "run_dir": str(run.artifacts),
        "agents_completed": list(run.completed),
        "stopped_at": stopped_at,
        "status": run.status if not (stopped_at and not run.held) else "stopped",
        "awaiting_review": [h["gate_id"] for h in run.held],
        **({"coverage": run.coverage} if run.coverage is not None else {}),
        "mode": "mock",
        "notes": "external systems mocked by scripts/mocks.py; the platform is real",
    }
    rows = [r for r in existing if r.get("run_id") != run.run_id] + [record]
    rows.sort(key=lambda r: r.get("started_ts", ""), reverse=True)
    path.write_text(json.dumps(rows, indent=1), encoding="utf-8")
    return path


def _op_of(section: str) -> str:
    """The DOMO op a CTE came from, read off its own ``[node:]`` header.

    The assembler writes ``-- [node: x] op=JOIN origin=mapped``, so the artifact
    already states this and nothing has to be re-derived from the graph. Empty
    when the header carries no op, which is a fact about the artifact rather than
    something to guess around.
    """
    head = (section or "").splitlines()[0] if section else ""
    return head.split("op=", 1)[1].split()[0].strip() if "op=" in head else ""


def _table_namer(build, gen, layer_of: dict[str, str], renames: dict[str, str] | None = None):
    """``node -> the fully qualified table it writes``.

    Three cases, and only the third is a guess:

    * a **target**'s final CTE writes the target's own table, which cd_codegen
      already resolved from the DOMO output dataset. Naming it `dev_test.gold.
      df_join_data_4_s06` instead - a CTE address, in the gold layer, for the one
      table an analyst will actually query - was the single most visible thing
      wrong with the layer scripts.
    * a **source** writes the bronze table it was landed into.
    * an **intermediate** has no name of its own, so one is derived from the CTE.
      ``renames`` overrides it: a reviewer who materializes an intermediate is
      naming a table other people will read, and `df_group_by_4_s13` is not a name.

    ``layer_of`` is read at call time, not captured: the classifier assigns layers
    after this closure is built, and the schema a table lands in is its layer.
    """
    renames = renames or {}
    fixed = {sv["df_var"]: sv["table"] for sv in build.sources}
    fixed.update({a.final_cte: a.table for a in gen.succeeded})

    def table_of(node: str) -> str:
        if node in renames and renames[node].strip():
            name = renames[node].strip()
            # A reviewer may type a bare name or a qualified one. A qualified name
            # is taken as given - overriding the layer schema is a legitimate
            # thing to want, and silently re-prefixing it would ignore the input.
            return name if "." in name else f"{_NAMING['layer_catalog']}.{layer_of.get(node, 'silver')}.{_slug(name)}"
        if node in fixed:
            return fixed[node]
        return f"{_NAMING['layer_catalog']}.{layer_of.get(node, 'silver')}.{_slug(node)}"

    return table_of


def _slug(text: str) -> str:
    out = "".join(c.lower() if c.isalnum() else "_" for c in str(text))
    while "__" in out:
        out = out.replace("__", "_")
    return out.strip("_")[:60]


#: DOMO tile type (normalized) -> the op vocabulary the UI's diagram draws with.
#: Anything unmapped renders as its own DOMO name rather than being forced into a
#: shape it is not; a wrong icon on a tile is a lie about what the tile does.
DOMO_TO_OP = {
    "SOURCE": "SOURCE", "SELECT": "SELECT", "SELECTCOLUMNS": "SELECT",
    "ALTERCOLUMNS": "ALTER", "ALTER": "ALTER", "FILTER": "FILTER",
    "FILTERROWS": "FILTER", "FORMULA": "FORMULA", "ADDFORMULA": "FORMULA",
    "JOIN": "JOIN", "JOINDATA": "JOIN", "AGGREGATE": "GROUPBY",
    "GROUPBY": "GROUPBY", "SUMMARIZE": "GROUPBY", "UNION": "APPEND",
    "APPEND": "APPEND", "APPENDROWS": "APPEND", "DEDUPE": "DEDUPE",
    "REMOVEDUPLICATES": "DEDUPE", "RANK": "RANK", "VALUEMAPPER": "VALUEMAP",
    "ADDCONSTANTS": "CONSTANT", "TEXTFORMATTING": "TEXT",
    "NORMALIZEALL": "UNPIVOT", "UNPIVOT": "UNPIVOT", "SINK": "WRITE",
    "WRITE": "WRITE", "OUTPUT": "WRITE",
}


def build_graph(folded: dict, build, gen, ingest_rows: list) -> list[dict]:
    """The node graph the Control Tower draws, from the run's own data.

    Everything here is derived, nothing invented: the topology is the discovery
    edges, the op is the DOMO tile type, and ``origin`` is whether the tile
    registry actually rendered that step. That last one is the field the UI colours
    amber and red on, so it must come from the real render result rather than a
    guess - a step shown green that was in fact a passthrough is exactly the lie
    this platform exists to prevent.
    """
    nodes = list(folded.get("nodes") or [])
    edges = list(folded.get("edges") or [])
    by_id = {str(n.get("id")): n for n in nodes}

    inputs_of: dict[str, list[str]] = {}
    for e in edges:
        inputs_of.setdefault(str(e.get("to")), []).append(str(e.get("from")))

    # origin per node id, from the plan: resolved -> deterministic, else unresolved.
    origin_of = {str(s.node_id): ("deterministic" if s.result.resolved else "unresolved")
                 for s in build.steps}
    # df_var is how a node is addressed inside the generated SQL (`-- [node: X]`),
    # so carrying it lets a UI show the REAL CTE for a tile instead of re-deriving one
    df_var_of = {str(s.node_id): s.df_var for s in build.steps}
    df_var_of.update({str(sv["node_id"]): sv["df_var"] for sv in build.sources})
    rows_of = {r.dataset_name: r.rows_ingested for r in ingest_rows}
    table_of = {t["node_id"]: t["table"] for t in build.targets}

    order = [str(n.get("id")) for n in nodes]
    sid = {nid: f"s{i + 1}" for i, nid in enumerate(order)}
    counters: dict[str, int] = {}
    out: list[dict] = []

    for nid in order:
        node = by_id[nid]
        raw = str(node.get("type") or node.get("operation_type") or "")
        norm = raw.upper().replace("_", "").replace(" ", "")
        op = DOMO_TO_OP.get(norm, norm or "FORMULA")
        counters[op] = counters.get(op, 0) + 1
        props = node.get("properties") or {}
        name = node.get("name") or nid

        entry = {
            "s": sid[nid], "op": op, "n": counters[op], "tile": name,
            "in": [sid[i] for i in inputs_of.get(nid, []) if i in sid],
            "node_id": nid, "domo_type": raw,
            "origin": origin_of.get(nid, "deterministic"),
            "df_var": df_var_of.get(nid, ""),
        }
        if op == "SOURCE":
            dataset = props.get("datasetName") or props.get("dataset_name") or name
            entry.update(dataset=_slug(dataset), purpose=dataset,
                         rows=rows_of.get(dataset, 0),
                         dataset_id=props.get("dataSourceId", ""))
        elif op == "WRITE":
            dataset = props.get("datasetName") or props.get("dataset_name") or name
            entry.update(table=_slug(dataset),
                         full_table=table_of.get(nid, ""), purpose=dataset)
        out.append(entry)
    return out


def _settled_assign(settled: dict[str, str]):
    """Hand the runner the layer assignment that already satisfies the invariant.

    The classifier derived it and the promotion step corrected it; re-deriving
    inside ``run()`` would discard the correction and emit the broken scripts
    again.
    """
    async def assign(artifact, state, config):
        return dict(settled)
    return assign


def _layers_payload(out: dict, gen, build, flow: dict, *, sections: dict[str, str],
                    table_of) -> dict[str, list[dict]]:
    """The classifier gate's layer view, built from the assignment it produced.

    Grouped from ``assignment_table`` rather than recomputed, so what the UI shows
    and what was written into the layer files cannot disagree. ``why`` states the
    rule that placed each node, because "which layer" is a decision someone will
    be asked to defend.

    ``deps`` ships with it: node -> the CTEs that node reads. The review board lets
    a reviewer drag a node between layers, and a drop is legal only if it does not
    put a node below something it reads. Without the edges the browser cannot tell
    a legal drop from an illegal one, and asking the server per drag would put a
    round trip inside a drag gesture. The server still refuses a bad assignment
    when it renders (``materialize.plan``); this is what lets the UI say so first.
    """
    assignment = out.get("assignment") or {}
    source_tables = {sv["df_var"]: sv["table"] for sv in build.sources}
    target_tables = {a.final_cte: a.table for a in gen.succeeded}

    layers: dict[str, list[dict]] = {"bronze": [], "silver": [], "gold": [],
                                     UNMATERIALIZED: []}
    for node, layer in sorted(assignment.items()):
        if layer not in layers:
            layers[layer] = []
        if node in source_tables:
            why, kind = "raw DOMO dataset, landed as-is", "source"
        elif node in target_tables:
            why, kind = "output of the dataflow, pinned gold by the medallion config", "target"
        elif layer == UNMATERIALIZED:
            why, kind = ("intermediate step, inlined as a CTE into whichever table "
                         "needs it"), "intermediate"
        else:
            why, kind = "intermediate step, materialized as its own table", "intermediate"
        layers[layer].append({
            "node": node, "table": table_of(node), "why": why, "kind": kind,
            # An intermediate is the only thing a reviewer may rename: a source and
            # a target are named by the datasets they mirror, and renaming one of
            # those would break the correspondence the migration is judged on.
            "renameable": kind == "intermediate",
            "op": _op_of(sections.get(node, "")),
        })

    names = set(sections)
    layers["deps"] = {n: sorted(mat_references(b, names) - {n})
                      for n, b in sections.items()}

    # One pipeline per layer, as the classifier would launch them. The task count
    # is the number of nodes actually assigned to that layer, not a guess: the UI
    # prints it next to the pipeline name and a wrong count there is a wrong
    # statement about what is about to run. Unmaterialized nodes write nothing, so
    # they are not a pipeline and must not be counted as tasks in one.
    stem = _slug(flow.get("name", "") or "dataflow")[:40]
    layers["pipelines"] = [
        {"name": f"{stem}_{layer}", "tasks": len(layers[layer]), "layer": layer}
        for layer in ("bronze", "silver", "gold")
    ]
    return layers


def _layer_of(node: str, artifact, source_vars: set[str]) -> str:
    """Which medallion layer one CTE belongs to.

    A rule of thumb, and only that: the blueprint is explicit that the real
    assignment is estate-wide and cannot be settled from one dataflow. Sources are
    bronze because they are landed raw; the final CTE is gold when its target name
    reads like an aggregate; everything in between is silver.
    """
    if node in source_vars:
        return "bronze"
    if node == artifact.final_cte:
        low = artifact.target.lower()
        if any(w in low for w in ("summary", "recon", "rollup", "close")):
            return "gold"
    return "silver"

def _classify(gen, flow: dict) -> dict[str, list[dict]]:
    """Medallion split: sources are bronze, aggregate outputs gold, the rest silver.

    A rule-of-thumb stand-in for the estate-wide assignment, which the blueprint is
    explicit can only be settled once the whole estate is known. Treat it as a shape
    to render, not as a layer decision.
    """
    bronze = [{"node": f"src_{i}", "table": f"{_NAMING['source_catalog']}.{_NAMING['source_schema']}."
                                            f"{_slug(s.get('dataSourceName',''))}",
               "why": "raw DOMO dataset, landed as-is"}
              for i, s in enumerate(flow.get("inputs") or [], start=1)]
    silver, gold = [], []
    for art in gen.succeeded:
        low = art.target.lower()
        entry = {"node": art.final_cte, "table": art.table,
                 "why": "aggregate, consumed downstream" if
                 any(w in low for w in ("summary", "recon", "rollup", "close"))
                 else "row-level, conformed and enriched"}
        (gold if "aggregate" in entry["why"] else silver).append(entry)
    return {"bronze": bronze, "silver": silver, "gold": gold}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--dataflow-id", default="8099")
    ap.add_argument("--work", default=str(ROOT / ".platform_local"),
                    help="where telemetry, gates and artifacts go (default: "
                         ".platform_local, which is what the API reads)")
    ap.add_argument("--stop-at", default="", choices=["", *AGENT_ORDER],
                    help="leave this agent's gate open instead of auto-approving, "
                         "so you can review it in the UI")
    ap.add_argument("--input", default="",
                    help="the dataflow JSON to run. Standardized shape (actions + "
                         "connections, id-keyed) or the folded shape. Stands in for "
                         "the raw DOMO export, which this repo does not carry. "
                         "Default: <dataflow-id>_standardized.json in the repo root.")
    ap.add_argument("--fresh", action="store_true",
                    help="delete every previous run first - this dataflow's volume "
                         "output, the run registry and all telemetry - so only this "
                         "run is tracked.")
    ap.add_argument("--volume", default=str(ROOT / "ex_volume"),
                    help="directory standing in for the UC volume. Reads the export "
                         "from <volume>/raw/<id>.json and writes plans, SQL, the "
                         "discovery JSON and gate payloads under <volume>/<id>/, in "
                         "the layout Databricks will use. Default: ./ex_volume")
    ap.add_argument("--column-style", default="delta_safe",
                    choices=["delta_safe", "preserve"])
    args = ap.parse_args(argv)

    print("=" * 74)
    print("END-TO-END MOCK RUN - external systems are faked, the platform is not")
    print("=" * 74)
    print("  mocked : DOMO API, UC volume, Delta discovery table, Databricks jobs,")
    print("           the Spark table reader, the serving endpoint")
    print("  real   : tiles, expressions, plan render, SQL generation, judges,")
    print("           parity arithmetic, all seven agents' own classes")

    if args.fresh:
        import shutil

        volume = pathlib.Path(args.volume)
        removed = []
        for target in (volume / args.dataflow_id, volume / "runs.json",
                       pathlib.Path(args.work) / "telemetry",
                       pathlib.Path(args.work) / "feedback",
                       pathlib.Path(args.work) / "gates"):
            if target.is_dir():
                shutil.rmtree(target)
                removed.append(str(target))
            elif target.exists():
                target.unlink()
                removed.append(str(target))
        # <volume>/raw is NEVER touched: it holds the export the user put there,
        # which this script did not create and must not delete.
        print(f"  --fresh removed {len(removed)} previous artefact path(s); "
              f"{volume / 'raw'} left alone")

    started = time.perf_counter()
    try:
        run = asyncio.run(run_pipeline(args.dataflow_id, work=pathlib.Path(args.work),
                                       stop_at=args.stop_at,
                                       column_style=args.column_style,
                                       input_json=args.input,
                                       volume=args.volume))
    except Exception:
        traceback.print_exc()
        print("\nRUN FAILED - see the traceback above")
        return 1

    print(f"\n{'=' * 74}")
    stopped = f", stopped at {args.stop_at}" if args.stop_at else ""
    print(f"ran {len(run.completed)}/{len(AGENT_ORDER)} agents in "
          f"{time.perf_counter() - started:.1f}s{stopped}")
    print(f"  agents     {' -> '.join(run.completed)}")
    print(f"  telemetry  {run.work / 'telemetry' / run.run_id}")
    print(f"  volume     {run.volume}")
    print(f"  gates      {len(run.gates)} written")
    if run.sink.errors:
        print(f"  !! telemetry sink errors: {run.sink.errors[:3]}")
    if run.failures:
        print("\n  findings (real, from the deterministic half):")
        for f in run.failures:
            print(f"    - {f}")
    print("\nsee it in the Control Tower:")
    print("  uvicorn api.app:app --reload --port 8000")
    print("  cd lv-tower && npm run dev")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
