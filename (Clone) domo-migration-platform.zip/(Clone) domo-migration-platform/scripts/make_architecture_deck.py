#!/usr/bin/env python3
"""Build the architecture deck: the whole machine, one box at a time.

    python scripts/make_architecture_deck.py   -> docs/migration_architecture.pptx

Who it is for
-------------
Someone who will fund, sponsor or sign off this migration and has never opened
the repo. They do not need the class names; they need to know what each piece
does, what it hands to the next piece, and where a person gets to say no. So
every box on every diagram is a real running thing, and every arrow is the only
way data moves between two of them — a diagram that invents a channel is worse
than no diagram, because it is consulted when someone is deciding what to trust.

Why a script and not a hand-made file
-------------------------------------
The agent order, which agents use a model, which pause for a human, the phase
names they report, the audit table names and the judge count are READ FROM THE
CODE. Those are exactly the facts a reader would quote back in a steering
meeting, and a slide that quietly disagrees with the platform is the failure
mode that matters. The plain-English half is written by hand — it is the
translation from "what the code does" to "what it means for your numbers", and
nothing can generate that from the source.

Style is imported from ``make_checks_deck`` on purpose: the two decks are shown
to the same people in the same room, and a second palette would read as a
second product.
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation  # noqa: E402
from pptx.enum.shapes import MSO_CONNECTOR  # noqa: E402
from pptx.enum.text import PP_ALIGN  # noqa: E402
from pptx.oxml.ns import qn  # noqa: E402
from pptx.util import Inches as In  # noqa: E402
from pptx.util import Pt  # noqa: E402

# -- facts read from the platform, never retyped ---------------------------- #
from agents.master import AGENT_DEFAULTS, AGENT_ORDER, AGENT_PHASES  # noqa: E402
from api.store_delta import KIND_TABLES  # noqa: E402
from judges.rules import DEFAULT_JUDGES  # noqa: E402

# One palette, one set of primitives, shared with the quality-checks deck.
from scripts.make_checks_deck import (  # noqa: E402
    BRAND,
    CODE_BG,
    DIM,
    FAIL,
    INK,
    LINE,
    MUTED,
    PAPER,
    PASS,
    WASH,
    H,
    W,
    _blank,
    _rect,
    _txt,
    section_slide,
    title_slide,
)

N_JUDGES = len(DEFAULT_JUDGES)

#: Agents this deck does NOT present as a review gate, whatever the platform
#: defaults say.
#:
#: The one deliberate divergence from the code in this file. ``AGENT_DEFAULTS``
#: still marks discovery ``hitl: True`` — the platform is able to pause there —
#: but no one is actually asked to review it, and a deck that promises a business
#: sponsor five approvals when four are real overstates what they are signing up
#: for. Kept as an explicit, named exception rather than a retyped list, so the
#: other six agents still come straight from the source and this one is visibly
#: an override rather than a slip.
DECK_UNGATED = frozenset({"discovery"})


def gated(agent: str) -> bool:
    return AGENT_DEFAULTS[agent]["hitl"] and agent not in DECK_UNGATED


HITL_AGENTS = [a for a in AGENT_ORDER if gated(a)]
AI_AGENTS = [a for a in AGENT_ORDER if AGENT_DEFAULTS[a]["ai_gen"]]

#: agent -> (number, short name for a chip, the name a business reader would use)
LABEL = {
    "connection":      ("1", "Connect",     "Connection"),
    "standardization": ("2", "Standardize", "Standardization"),
    "discovery":       ("3", "Discover",    "Discovery"),
    "md_plan":         ("4", "Plan",        "Migration plan"),
    "cd_codegen":      ("5", "Generate",    "Code generation"),
    "validation":      ("6", "Validate",    "Validation"),
    "classifier":      ("7", "Classify",    "Layering"),
}

#: agent -> what it does, for somebody who will never read the code.
PLAIN = {
    "connection": "Signs in to DOMO and pulls the dataflow down exactly as DOMO holds it. "
                  "No interpretation and no AI — a faithful copy, so everything after this "
                  "argues from the same document.",
    "standardization": "Rewrites that export into one predictable shape: same field names, "
                       "same structure, and the duplicate revisions left behind by years of "
                       "saving in DOMO removed.",
    "discovery": "Works out the shape of the pipeline — every tile, what feeds what, and "
                 "which tables are finished answers rather than working steps. This is where "
                 "the scope of the job stops being a guess.",
    "md_plan": "Writes the migration plan in English before any code exists: what each tile "
               "must do, what it reads, what it produces, and how confident we are. This is "
               "the document you actually review.",
    "cd_codegen": "Turns the approved plan into Databricks SQL, one addressable block per "
                  "tile — so a single step can be pointed at, discussed and re-run without "
                  "touching the rest.",
    "validation": "Runs the new pipeline and compares it against DOMO row by row and column "
                  "by column. Where the two disagree, it names the step responsible instead "
                  "of reporting a red light.",
    "classifier": "Splits the finished code into bronze, silver and gold — raw, cleaned and "
                  "business-ready — so the output lands where your platform already expects "
                  "to find it.",
}

#: table -> the question a row in it answers.
TABLE_MEANS = {
    KIND_TABLES["steps"]: "every stage that ran, how long it took, whether it finished",
    KIND_TABLES["llm_calls"]: "every question put to the model, with tokens, latency and cost",
    KIND_TABLES["ingestions"]: "every table read or written, and why it was touched",
    KIND_TABLES["judges"]: f"every one of the {N_JUDGES} automated rules, and what it found",
    KIND_TABLES["validations"]: "every comparison against DOMO, per output table",
    KIND_TABLES["decisions"]: "every approval and rejection, with the name of the person",
}


# --------------------------------------------------------------------------- #
# primitives this deck adds: arrows, labelled boxes, chips
# --------------------------------------------------------------------------- #

def E(v) -> int:
    """Round a computed offset back to a whole EMU.

    Any arithmetic that divides — centring a chip, splitting a row into seven —
    produces a float, and python-pptx writes it into the XML verbatim. PowerPoint
    rejects a non-integer offset, so the failure is a file that will not open at
    all rather than a shape in the wrong place. Every computed coordinate in this
    module goes through here.
    """
    return int(round(v))


def _arrow(slide, x1, y1, x2, y2, *, color=DIM, width=1.25, dashed=False,
           head=True, back=False):
    """A straight connector. Arrowheads are set in XML — python-pptx has no API
    for them, and an arrow without a head is just a line that means nothing."""
    conn = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                                      E(x1), E(y1), E(x2), E(y2))
    conn.line.color.rgb = color
    conn.line.width = Pt(width)
    ln = conn.line._get_or_add_ln()
    # Schema order inside a:ln is fill, then dash, then headEnd, then tailEnd.
    if dashed:
        ln.append(ln.makeelement(qn("a:prstDash"), {"val": "dash"}))
    if back:
        ln.append(ln.makeelement(qn("a:headEnd"),
                                 {"type": "triangle", "w": "med", "len": "med"}))
    if head:
        ln.append(ln.makeelement(qn("a:tailEnd"),
                                 {"type": "triangle", "w": "med", "len": "med"}))
    return conn


def _box(slide, x, y, w, h, title, body, *, kicker=None, fill=PAPER, edge=LINE,
         accent=None, title_size=13, body_size=9.5, body_color=MUTED,
         mono=False, spacing=1.22):
    """One labelled thing on a diagram: an optional accent spine, a name, and the
    two or three lines that say what it is."""
    x, y, w, h = E(x), E(y), E(w), E(h)
    _rect(slide, x, y, w, h, fill, edge)
    if accent is not None:
        _rect(slide, x, y, In(0.075), h, accent)
    pad = In(0.24)
    cy = y + In(0.14)
    if kicker:
        _txt(slide, x + pad, cy, w - pad * 2, In(0.2), kicker,
             size=8, bold=True, color=accent or BRAND)
        cy += In(0.21)
    _txt(slide, x + pad, E(cy), w - pad * 2, In(0.3), title,
         size=title_size, bold=True, color=INK)
    cy += In(0.07) + Pt(title_size * 1.2)
    if body:
        _txt(slide, x + pad, E(cy), w - pad * 2, E(h - (cy - y) - In(0.1)), body,
             size=body_size, color=body_color, spacing=spacing,
             font="Consolas" if mono else "Calibri")


def _chip(slide, x, y, w, h, text, *, fill=PAPER, edge=LINE, color=INK, size=9):
    x, y, w, h = E(x), E(y), E(w), E(h)
    _rect(slide, x, y, w, h, fill, edge)
    _txt(slide, x, E(y + (h - Pt(size * 1.35)) / 2), w, In(0.25), text,
         size=size, bold=True, color=color, align=PP_ALIGN.CENTER)


def _header(slide, title, sub):
    _rect(slide, 0, 0, W, In(1.05), WASH)
    _txt(slide, In(0.62), In(0.26), In(12), In(0.45), title, size=25, bold=True)
    _txt(slide, In(0.62), In(0.73), In(12), In(0.25), sub, size=11.5, color=DIM)


def _footnote(slide, text, y=In(7.02)):
    _txt(slide, In(0.62), y, In(12.1), In(0.35), text, size=11.5, bold=True, color=INK)


# --------------------------------------------------------------------------- #
# the whole machine, on one slide
# --------------------------------------------------------------------------- #

def machine_slide(prs):
    slide = _blank(prs)
    _header(slide, "The whole machine",
            "Every box is a real running piece of software. Every arrow is the only "
            "way data moves between two of them.")

    # The AI sits off to one side, deliberately, rather than in the spine: it is
    # consulted, it is not the thing doing the migration.
    _box(slide, In(4.95), In(1.30), In(3.45), In(0.80), "Databricks Model Serving",
         "asked only for the open-ended parts  ·  every call is logged",
         kicker="THE AI", accent=BRAND, title_size=11.5, body_size=8.5, fill=CODE_BG)

    _box(slide, In(0.62), In(2.45), In(2.45), In(1.30), "DOMO",
         "the dataflow definition\nevery tile's logic\ndataset + schema metadata\n"
         "row counts — the answer key",
         kicker="WHAT WE READ", accent=DIM, title_size=14, body_size=9)

    ax, aw = In(3.62), In(6.10)
    _rect(slide, ax, In(2.45), aw, In(1.30), PAPER, BRAND)
    _rect(slide, ax, In(2.45), In(0.075), In(1.30), BRAND)
    _txt(slide, ax + In(0.24), In(2.55), aw - In(0.45), In(0.22),
         "THE PLATFORM", size=8, bold=True, color=BRAND)
    _txt(slide, ax + In(0.24), In(2.76), aw - In(0.45), In(0.22),
         "seven agents, in order  ·  one application  ·  it stops at every gate",
         size=9, color=MUTED)
    n = len(AGENT_ORDER)
    gap, inner = In(0.06), aw - In(0.48)
    cw = E((inner - gap * (n - 1)) / n)
    for i, agent in enumerate(AGENT_ORDER):
        num, short, _ = LABEL[agent]
        cx = E(ax + In(0.24) + i * (cw + gap))
        _rect(slide, cx, In(3.00), cw, In(0.56), CODE_BG,
              BRAND if gated(agent) else LINE)
        _txt(slide, cx, In(3.06), cw, In(0.2), num,
             size=8, bold=True, color=BRAND, align=PP_ALIGN.CENTER)
        _txt(slide, cx, In(3.25), cw, In(0.2), short,
             size=8.5, bold=True, color=INK, align=PP_ALIGN.CENTER)

    _box(slide, In(10.28), In(2.45), In(2.45), In(1.30), "Databricks",
         "bronze / silver / gold tables\none SQL block per tile\nthe numbers DOMO produced",
         kicker="WHERE IT LANDS", accent=PASS, title_size=14, body_size=9)

    _arrow(slide, In(3.07), In(3.10), In(3.62), In(3.10), color=INK, width=1.5)
    _arrow(slide, In(9.72), In(3.10), In(10.28), In(3.10), color=INK, width=1.5)
    _arrow(slide, In(6.67), In(2.45), In(6.67), In(2.10),
           color=DIM, dashed=True, back=True)

    # what a run leaves behind
    # Both bodies are monospaced, so they are wrapped by hand onto lines that fit
    # the box — Consolas at 8.5pt gives roughly 58 characters across 3.8 inches.
    _box(slide, In(0.62), In(4.15), In(4.30), In(1.05), "Unity Catalog volume",
         "raw -> standardized -> discovery\n    -> plan.md -> sql -> layers -> gates",
         kicker="EVERY ARTIFACT, KEPT", accent=BRAND, title_size=12, body_size=8.5,
         mono=True, fill=CODE_BG)
    _box(slide, In(5.30), In(4.15), In(4.30), In(1.05), "Six Delta audit tables",
         "  ·  ".join(KIND_TABLES[k] for k in ("steps", "llm_calls", "ingestions"))
         + "\n"
         + "  ·  ".join(KIND_TABLES[k] for k in ("judges", "validations", "decisions")),
         kicker="WHAT ACTUALLY HAPPENED", accent=BRAND, title_size=12, body_size=8.5,
         mono=True, fill=CODE_BG)
    _box(slide, In(10.28), In(4.15), In(2.45), In(1.05), "Checkpoint",
         "where a paused run waits —\nfor minutes or for days",
         kicker="POSTGRES", accent=DIM, title_size=12, body_size=8.5)

    _arrow(slide, In(2.77), In(3.75), In(2.77), In(4.15))
    _arrow(slide, In(7.45), In(3.75), In(7.45), In(4.15))
    _arrow(slide, In(9.72), In(3.62), In(10.72), In(4.15))

    # the room a person actually sits in
    _box(slide, In(3.62), In(5.75), In(3.30), In(1.15), "FastAPI  /api",
         "reads the volume and the tables\none write only: a person's decision",
         kicker="THE SERVER", accent=BRAND, title_size=12.5, body_size=9)
    _box(slide, In(7.55), In(5.75), In(3.30), In(1.15), "Control Tower",
         "runs, gates, artifacts, diffs\nApprove / Reject, with a name on it",
         kicker="IN THE BROWSER", accent=BRAND, title_size=12.5, body_size=9)

    _arrow(slide, In(2.77), In(5.20), In(4.05), In(5.75))
    _arrow(slide, In(7.45), In(5.20), In(6.45), In(5.75))
    _arrow(slide, In(6.92), In(6.32), In(7.55), In(6.32), back=True)
    _arrow(slide, In(5.11), In(5.75), In(5.11), In(3.78), color=PASS, width=1.75)
    _txt(slide, In(5.26), In(5.24), In(2.6), In(0.35),
         "approval releases\nthe next agent", size=8.5, bold=True,
         color=PASS, spacing=1.15)

    _footnote(slide, "Nothing in the browser can start or change a migration. It shows "
                     "what happened, and it records what a person decided.")
    return slide


# --------------------------------------------------------------------------- #
# the same machine, stripped back
# --------------------------------------------------------------------------- #

def simple_slide(prs):
    """The previous slide with everything a business reader does not need removed.

    Deliberately NOT a summary of the stages: naming seven of them invites "what
    does number four do", which is the previous slide's job. So the whole pipeline
    is one box called the converter, and the three places Databricks stores
    something are one box called Databricks.

    What does NOT get merged away is the review path. The API and the Control
    Tower stay on the page as their own boxes, because they are the two pieces a
    business reader will actually be issued a login to — collapsing them into an
    abstraction called "review" would hide the part of the system they personally
    touch.
    """
    slide = _blank(prs)
    _header(slide, "The same machine, in six boxes",
            "If you look at one diagram in this deck, look at this one.")

    mid = In(6.67)                       # everything centres on the converter

    _box(slide, In(5.06), In(1.45), In(3.22), In(1.00), "AI endpoint",
         "Asked only where judgement is needed.",
         kicker="CONSULTED — NOT IN CHARGE", accent=BRAND, title_size=15,
         body_size=10.5, fill=CODE_BG)

    _box(slide, In(0.80), In(3.05), In(3.20), In(1.65), "DOMO",
         "Your dataflows, and all the\nbusiness logic inside them.",
         kicker="TODAY", accent=DIM, title_size=20, body_size=12, spacing=1.3)

    _box(slide, In(5.06), In(3.05), In(3.22), In(1.65), "The converter",
         "Reads that logic and rewrites\nit as Databricks code — then\nchecks its own work.",
         kicker="THE PLATFORM", accent=BRAND, title_size=20, body_size=12, spacing=1.3)

    _box(slide, In(9.33), In(3.05), In(3.20), In(1.65), "Databricks",
         "Your tables, the generated code,\nand the record of how it got\nthere — one account, one place.",
         kicker="TOMORROW", accent=PASS, title_size=20, body_size=12, spacing=1.3)

    # The review path, kept as two real boxes. The pair is centred on the
    # converter so the green approval arrow runs straight back up into it.
    _box(slide, In(3.40), In(5.50), In(3.00), In(1.35), "FastAPI service",
         "Serves those screens, and\nrecords every decision made.",
         kicker="THE SERVER", accent=BRAND, title_size=17, body_size=12, spacing=1.3)

    _box(slide, In(6.94), In(5.50), In(3.00), In(1.35), "Control Tower",
         "Where the work is reviewed,\napproved, or sent back.",
         kicker="YOUR TEAM, IN THE BROWSER", accent=PASS, title_size=17,
         body_size=12, spacing=1.3)

    _arrow(slide, In(4.00), In(3.88), In(5.06), In(3.88), color=INK, width=2)
    _arrow(slide, In(8.28), In(3.88), In(9.33), In(3.88), color=INK, width=2)
    _txt(slide, In(4.00), In(3.55), In(1.06), In(0.25), "the logic",
         size=9, bold=True, color=DIM, align=PP_ALIGN.CENTER)
    _txt(slide, In(8.28), In(3.55), In(1.05), In(0.25), "working code",
         size=9, bold=True, color=DIM, align=PP_ALIGN.CENTER)

    _arrow(slide, mid, In(3.05), mid, In(2.45), color=DIM, dashed=True, back=True)
    _arrow(slide, In(6.40), In(6.17), In(6.94), In(6.17), color=INK, back=True)
    _arrow(slide, In(5.50), In(5.50), In(5.50), In(4.73), color=PASS, width=2)
    _txt(slide, In(5.68), In(4.88), In(3.6), In(0.3),
         "an approval releases the next step", size=9.5, bold=True, color=PASS)

    _footnote(slide, "One direction across the top. The AI is asked questions on the "
                     "side, and nothing moves to the next step until a named person "
                     "approves it in the Control Tower.", y=In(7.05))
    return slide


# --------------------------------------------------------------------------- #
# the seven agents, in plain words
# --------------------------------------------------------------------------- #

def agents_slide(prs):
    slide = _blank(prs)
    _header(slide, "The seven agents, in plain words",
            "Sequential by construction — an agent only starts once the one before it "
            "has been approved.")

    y = In(1.28)
    for agent in AGENT_ORDER:
        num, _, name = LABEL[agent]
        d = AGENT_DEFAULTS[agent]
        _rect(slide, In(0.62), y, In(0.42), In(0.42), BRAND)
        _txt(slide, In(0.62), y + In(0.09), In(0.42), In(0.25), num,
             size=12, bold=True, color=PAPER, align=PP_ALIGN.CENTER)
        _txt(slide, In(1.20), y + In(0.02), In(2.1), In(0.3), name, size=12.5, bold=True)
        _txt(slide, In(1.20), y + In(0.32), In(2.1), In(0.25),
             "  ·  ".join(AGENT_PHASES[agent][:2]).lower(), size=7.5, color=DIM)
        _txt(slide, In(3.35), y + In(0.03), In(7.0), In(0.72), PLAIN[agent],
             size=10.5, color=MUTED, spacing=1.22)

        for bx, on, label, tone in (
            (In(10.55), d["ai_gen"], "AI WRITES IT", BRAND),
            (In(11.72), gated(agent), "YOU APPROVE", PASS),
        ):
            _chip(slide, bx, y + In(0.05), In(1.05), In(0.34),
                  label if on else "—",
                  fill=PAPER if on else WASH, edge=tone if on else LINE,
                  color=tone if on else DIM, size=7.5)
        y += In(0.83)

    _footnote(slide,
              f"{len(AI_AGENTS)} of the {len(AGENT_ORDER)} stages ask a model anything. "
              f"{len(HITL_AGENTS)} of them stop and wait for a person.", y=In(7.14))
    return slide


# --------------------------------------------------------------------------- #
# inside one agent
# --------------------------------------------------------------------------- #

def loop_slide(prs):
    slide = _blank(prs)
    _header(slide, "Inside one agent",
            "The same four steps every time. The only way forward is through all of them.")

    cells = [
        ("1", "It does the work", BRAND,
         "Deterministic code first — DOMO's\nvocabulary is finite and mapped by\n"
         "hand. A model is asked only for\nwhatever is left over."),
        ("2", "A model reviews it", BRAND,
         "A second model reads the result\nand writes down what looks wrong.\n"
         "An opinion, not a verdict — it\ncannot stop anything by itself."),
        ("3", f"{N_JUDGES} rules run", BRAND,
         "Hardcoded checks, every time, no\nmodel involved. Each one came\n"
         "from a real failure in a real\nplan."),
        ("4", "A person decides", PASS,
         "All of the above is put in front\nof you in the browser. Approve, or\n"
         "reject with a reason. Your name\nis recorded either way."),
    ]
    bw, step = In(2.65), In(3.15)
    for i, (num, title, tone, body) in enumerate(cells):
        x = In(0.62) + i * step
        _box(slide, x, In(2.15), bw, In(1.62), title, body,
             kicker=f"STEP {num}", accent=tone, title_size=13, body_size=9)
        if i < len(cells) - 1:
            _arrow(slide, x + bw, In(2.96), x + step, In(2.96), color=INK, width=1.5)

    # the way back: a rejection is an instruction, not a dead end
    x1c = E(In(0.62) + bw / 2)
    x4c = E(In(0.62) + 3 * step + bw / 2)
    _arrow(slide, x4c, In(3.77), x4c, In(4.30), head=False, color=FAIL)
    _arrow(slide, x4c, In(4.30), x1c, In(4.30), head=False, color=FAIL)
    _arrow(slide, x1c, In(4.30), x1c, In(3.77), color=FAIL)
    _txt(slide, In(2.4), In(4.40), In(8.9), In(0.3),
         "REJECTED  ·  the reason you type is fed back in and the agent tries again",
         size=10.5, bold=True, color=FAIL, align=PP_ALIGN.CENTER)

    _rect(slide, In(0.62), In(5.05), In(12.1), In(1.72), CODE_BG, LINE)
    _txt(slide, In(0.94), In(5.25), In(6.0), In(0.3),
         "WHAT THIS LEAVES BEHIND, EVERY TIME", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(0.94), In(5.62), In(5.6), In(1.05),
         "a row saying the stage ran, and for how long\n"
         "a row for every question put to the model, with its cost\n"
         f"a row for each of the {N_JUDGES} rules, pass or fail",
         size=11, color=MUTED, spacing=1.35)
    _txt(slide, In(6.9), In(5.25), In(5.6), In(0.3),
         "AND WHILE IT WAITS FOR YOU", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(6.9), In(5.62), In(5.5), In(1.05),
         "The run is checkpointed and stops. It does not spin, and it does\n"
         "not time out. Come back tomorrow and it resumes at the same\n"
         "point, from the state it paused on.",
         size=11, color=MUTED, spacing=1.35)

    _footnote(slide, "Step 3 never asks a model anything, and step 4 never happens "
                     "without a named human. Those two are what make the result "
                     "reviewable.")
    return slide


# --------------------------------------------------------------------------- #
# where the work is kept
# --------------------------------------------------------------------------- #

def storage_slide(prs):
    slide = _blank(prs)
    _header(slide, "Where the work is kept",
            "Two places, both inside your own Databricks account. Nothing the platform "
            "produces lives anywhere else.")

    _rect(slide, In(0.62), In(1.35), In(5.82), In(5.4), CODE_BG, LINE)
    _rect(slide, In(0.62), In(1.35), In(0.09), In(5.4), BRAND)
    _txt(slide, In(0.94), In(1.58), In(5.2), In(0.3),
         "THE ARTIFACTS  ·  A UNITY CATALOG VOLUME", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(0.94), In(1.95), In(5.2), In(0.6),
         "One folder per dataflow. Every file a stage produced is kept — not just the "
         "latest version, all of them.", size=11.5, color=MUTED, spacing=1.3)
    _txt(slide, In(0.94), In(2.85), In(5.3), In(3.6),
         "raw/8099.json          the export, untouched\n"
         "standardized/          the tidied copy\n"
         "discovery/             tiles + what feeds what\n"
         "md/plan_8099_v1.md     the plan you review\n"
         "md/plan_8099_v2.md     ...and the version after\n"
         "                       your feedback\n"
         "sql/etl_8099__*.sql    one file per output table\n"
         "layers/                bronze, silver, gold\n"
         "gates/                 exactly what was shown\n"
         "                       to you at each approval\n"
         "graph_8099.json        the picture the screen draws",
         size=10, font="Consolas", spacing=1.3)

    _rect(slide, In(6.9), In(1.35), In(5.82), In(5.4), CODE_BG, LINE)
    _rect(slide, In(6.9), In(1.35), In(0.09), In(5.4), BRAND)
    _txt(slide, In(7.22), In(1.58), In(5.2), In(0.3),
         "THE RECORD  ·  SIX DELTA TABLES", size=10.5, bold=True, color=BRAND)
    _txt(slide, In(7.22), In(1.95), In(5.2), In(0.6),
         "Ordinary tables in your catalogue. Query them yourself — nothing here is "
         "visible only through our screen.", size=11.5, color=MUTED, spacing=1.3)
    y = In(2.85)
    for key in ("steps", "llm_calls", "ingestions", "judges", "validations", "decisions"):
        name = KIND_TABLES[key]
        _txt(slide, In(7.22), y, In(5.2), In(0.25), name,
             size=10.5, bold=True, color=INK, font="Consolas")
        _txt(slide, In(7.22), y + In(0.25), In(5.3), In(0.3), TABLE_MEANS[name],
             size=10, color=MUTED)
        y += In(0.62)

    _footnote(slide, "The dashboard caches no counts. Every number on it is recomputed "
                     "from these rows, so the screen and the database cannot disagree.",
              y=In(6.95))
    return slide


# --------------------------------------------------------------------------- #
# what the AI actually touches
# --------------------------------------------------------------------------- #

def ai_slide(prs):
    slide = _blank(prs)
    _header(slide, "What the AI actually touches",
            "Less than people assume — and that is the design, not a limitation of it.")

    for x, kicker, title, tone, body in (
        (In(0.62), "DONE IN PLAIN CODE  ·  THE SAME ANSWER EVERY TIME", "The bulk", PASS,
         "Every DOMO tile type, mapped by hand. The vocabulary is closed and finite, "
         "so it does not need guessing at.\n\n"
         "DOMO's formula language, parsed properly rather than pattern-matched — "
         "nested conditions and operator precedence are exactly where a shortcut "
         "gets a financial number subtly wrong.\n\n"
         "The plan document, the assembled SQL, the row-and-column comparison against "
         f"DOMO, and all {N_JUDGES} quality rules.\n\n"
         "Where DOMO and Databricks genuinely disagree — how each rounds, how each "
         "treats an empty value, how each divides whole numbers — the difference is "
         "written down as a caveat on that step rather than quietly absorbed."),
        (In(6.9), "SENT TO A MODEL  ·  THE OPEN-ENDED TAIL", "The tail", BRAND,
         "A formula the parser could not fully resolve.\n\n"
         "A tile type nobody has mapped yet.\n\n"
         "The reviewer's second opinion — which is an opinion, and is shown to you "
         "as one.\n\n"
         "Nothing else. A plan in which every expression resolves makes zero model "
         "calls, and that is the normal case: in dataflow 8099, all 16 distinct "
         "expressions translated with no model involved at all."),
    ):
        _rect(slide, x, In(1.35), In(5.82), In(5.15), CODE_BG, LINE)
        _rect(slide, x, In(1.35), In(0.09), In(5.15), tone)
        _txt(slide, x + In(0.32), In(1.58), In(5.3), In(0.3), kicker,
             size=9.5, bold=True, color=tone)
        _txt(slide, x + In(0.32), In(1.88), In(5.2), In(0.4), title, size=19, bold=True)
        _txt(slide, x + In(0.32), In(2.45), In(5.25), In(3.9), body,
             size=11.5, color=MUTED, spacing=1.3)

    _footnote(slide, "The model is never the only thing standing between DOMO and your "
                     "numbers. It is asked a narrow question, and everything it answers "
                     "is checked by something that cannot hallucinate.", y=In(6.72))
    return slide


# --------------------------------------------------------------------------- #
# where a person says no
# --------------------------------------------------------------------------- #

GATE_TEXT = {
    "md_plan": ("Does the plan describe your logic?",
                "The plan in English, before a line of code exists. This is the cheapest "
                "place to catch a misunderstanding, and the one gate worth real time."),
    "cd_codegen": ("Is the code faithful to the plan?",
                   "The generated SQL, block by block, against the plan you already "
                   "approved. Each block is addressable, so an objection can be specific."),
    "validation": ("Do the numbers match DOMO?",
                   "Row counts and column values from both systems side by side, with a "
                   "named step wherever they differ."),
    "classifier": ("Is it landing in the right place?",
                   "Which output is bronze, which is silver, which is gold — and therefore "
                   "who in your organisation can see it."),
}


def gates_slide(prs):
    slide = _blank(prs)
    _header(slide, "Where a person says no",
            f"{len(HITL_AGENTS)} gates. The run stops at each one and does not move until "
            "somebody with a name approves it.")

    # The rows fill the page whether there are four gates or five, so dropping one
    # does not leave a third of the slide empty.
    n = len(HITL_AGENTS)
    gap, span = In(0.14), In(5.45)
    row_h = E((span - gap * (n - 1)) / n)
    y = In(1.35)
    for agent in HITL_AGENTS:
        num, _, name = LABEL[agent]
        question, body = GATE_TEXT[agent]
        mid = E(y + row_h / 2)
        _rect(slide, In(0.62), y, In(12.1), row_h, PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), row_h, PASS)
        _rect(slide, In(0.94), mid - In(0.22), In(0.44), In(0.44), WASH)
        _txt(slide, In(0.94), mid - In(0.13), In(0.44), In(0.25), num,
             size=12, bold=True, color=BRAND, align=PP_ALIGN.CENTER)
        _txt(slide, In(1.62), mid - In(0.34), In(4.4), In(0.3), question,
             size=13, bold=True)
        _txt(slide, In(1.62), mid + In(0.02), In(4.4), In(0.3), f"after {name.lower()}",
             size=9.5, color=DIM)
        _txt(slide, In(6.3), mid - In(0.35), In(6.2), In(0.7), body,
             size=10.5, color=MUTED, spacing=1.25)
        y = E(y + row_h + gap)

    _footnote(slide, "A rejection is not a stop. The reason you type is handed back to "
                     "the agent, which produces a new version — and the old one stays on "
                     "file.")
    return slide


# --------------------------------------------------------------------------- #
# three different kinds of confidence
# --------------------------------------------------------------------------- #

def trust_slide(prs):
    slide = _blank(prs)
    _header(slide, "Three different kinds of confidence",
            "They are not interchangeable, and blurring them is how a green screen ends "
            "up meaning nothing.")

    panels = [
        ("A RULE", "The judges", BRAND, f"{N_JUDGES} hardcoded checks",
         "Deterministic. Always run. They never ask a model anything.\n\n"
         "Each one exists because it caught a real failure in a real plan — none of "
         "them were invented from first principles.\n\n"
         "Because they never change their mind, their pass rate is tracked from one "
         "release to the next: if it drops, something regressed."),
        ("AN OPINION", "The evaluators", DIM, "a model reading the work",
         "A model with a view on what looks wrong.\n\n"
         "It feeds the human review. It is never a verdict, and it can neither block "
         "nor release a run on its own.\n\n"
         "Its findings reach you as what they are: a second reader's concerns, to be "
         "agreed with or dismissed by you."),
        ("THE ANSWER KEY", "Parity with DOMO", PASS, "your own numbers",
         "The new pipeline runs, and its output is compared against what DOMO actually "
         "produced — row counts first, then column values within tolerance.\n\n"
         "This is the only one of the three that can tell you the migration is correct "
         "rather than merely well-formed."),
    ]
    for i, (kicker, title, tone, sub, body) in enumerate(panels):
        x = In(0.62) + i * In(4.1)
        _rect(slide, x, In(1.35), In(3.92), In(5.15), CODE_BG, LINE)
        _rect(slide, x, In(1.35), In(3.92), In(0.09), tone)
        _txt(slide, x + In(0.3), In(1.68), In(3.3), In(0.3), kicker,
             size=9.5, bold=True, color=tone)
        _txt(slide, x + In(0.3), In(1.98), In(3.3), In(0.4), title, size=19, bold=True)
        _txt(slide, x + In(0.3), In(2.46), In(3.3), In(0.3), sub, size=10.5, color=DIM)
        _txt(slide, x + In(0.3), In(2.9), In(3.35), In(3.4), body,
             size=11, color=MUTED, spacing=1.3)

    _footnote(slide, "A check that examined nothing is never reported as a pass. That "
                     "rule holds in all three columns.", y=In(6.72))
    return slide


# --------------------------------------------------------------------------- #
# what runs where
# --------------------------------------------------------------------------- #

def deployment_slide(prs):
    slide = _blank(prs)
    _header(slide, "What runs where",
            "One application, inside your Databricks workspace. No separate hosting, and "
            "no copy of your data outside the account.")

    _box(slide, In(0.62), In(1.4), In(3.85), In(2.1), "A Databricks App",
         "One process answers the browser and serves the screens. There is no second "
         "server to stand up and nothing to host elsewhere.",
         kicker="THE CONTROL TOWER", accent=BRAND, title_size=15, body_size=11,
         spacing=1.3)
    _box(slide, In(4.75), In(1.4), In(3.85), In(2.1), "A Databricks Job",
         "The seven agents run here, on your compute, reading and writing your "
         "catalogue. This is the part that does the migration.",
         kicker="THE PIPELINE", accent=BRAND, title_size=15, body_size=11, spacing=1.3)
    _box(slide, In(8.88), In(1.4), In(3.85), In(2.1), "Your own catalogue",
         "Artifacts in a volume, the record in six Delta tables, output in bronze, "
         "silver and gold — all of it governed by Unity Catalog.",
         kicker="THE STORAGE", accent=PASS, title_size=15, body_size=11, spacing=1.3)

    _rect(slide, In(0.62), In(3.85), In(12.1), In(2.9), CODE_BG, LINE)
    _rect(slide, In(0.62), In(3.85), In(0.09), In(2.9), FAIL)
    _txt(slide, In(0.94), In(4.08), In(9), In(0.3),
         "THREE THINGS THAT BEHAVE DIFFERENTLY ONCE IT IS DEPLOYED  ·  ON PURPOSE",
         size=10.5, bold=True, color=FAIL)
    for i, (head, body) in enumerate((
        ("The reviewer is whoever is signed in.",
         "The name on an approval comes from the workspace login, never from anything the "
         "browser claims. A request with no identity is refused rather than recorded under "
         "a name somebody typed."),
        ("A failed write of a decision is a loud error.",
         "Telemetry can lose a row quietly. An approval cannot — telling a reviewer their "
         "decision was recorded when it was not is the worst thing this system could do."),
        ("It refuses to start on temporary storage.",
         "An app instance's own disk is wiped whenever it is replaced. Rather than lose the "
         "review trail that way, the application refuses to come up at all."),
    )):
        y = In(4.52) + i * In(0.76)
        _txt(slide, In(0.94), y, In(5.2), In(0.3), head, size=11.5, bold=True, color=INK)
        _txt(slide, In(6.3), y, In(6.2), In(0.7), body, size=10.5, color=MUTED,
             spacing=1.25)
    return slide


# --------------------------------------------------------------------------- #
# the closing
# --------------------------------------------------------------------------- #

def takeaways_slide(prs):
    """Five rows rather than five paragraphs.

    This was a section slide first, and the text ran off the bottom of the page.
    The content is the part of the deck most likely to be read alone, so it gets
    a layout of its own.
    """
    slide = _blank(prs)
    _header(slide, "Five things worth remembering",
            "If you take nothing else from this deck.")

    rows = [
        (f"{len(AGENT_ORDER)} stages, in a fixed order.",
         "Each one waits for the one before it to be approved. Nothing runs ahead."),
        ("The model is asked narrow questions.",
         "It is not asked to do the migration. Most of the work is plain code that "
         "gives the same answer every time it runs."),
        (f"{N_JUDGES} automated rules, on every artifact.",
         "Every time, without exception — and not one of them asks a model anything."),
        (f"{len(HITL_AGENTS)} gates, each with a named person.",
         "Approve or reject. A rejection is fed back into the agent rather than "
         "being the end of the road."),
        ("The proof is DOMO's own numbers.",
         "Not a green tick from the thing that wrote the code — a row-by-row "
         "comparison against the system you are leaving."),
    ]
    y = In(1.45)
    for i, (head, body) in enumerate(rows, 1):
        _rect(slide, In(0.62), y, In(0.46), In(0.46), BRAND)
        _txt(slide, In(0.62), y + In(0.11), In(0.46), In(0.3), str(i),
             size=13, bold=True, color=PAPER, align=PP_ALIGN.CENTER)
        _txt(slide, In(1.3), y + In(0.04), In(5.0), In(0.35), head, size=14, bold=True)
        _txt(slide, In(6.5), y + In(0.06), In(6.1), In(0.8), body,
             size=11.5, color=MUTED, spacing=1.25)
        y += In(1.08)

    _footnote(slide, "Every claim on this slide is checkable in your own catalogue, "
                     "without asking us.", y=In(6.95))
    return slide


# --------------------------------------------------------------------------- #

def build(out: pathlib.Path) -> pathlib.Path:
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    title_slide(
        prs, "How the migration platform works",
        "DOMO to Databricks  ·  the whole machine, one box at a time",
        "Seven pieces of software move one DOMO dataflow from the export we pull out of "
        f"DOMO to tables you can query in Databricks — stopping {len(HITL_AGENTS)} times "
        "along the way to ask a person whether to continue.\n\n"
        "None of it is a black box. Every stage writes down what it did, what it read, "
        "what it asked a model, what the automated checks found and who approved it — "
        "into ordinary tables in your own account, which you can query without us.\n\n"
        "This deck is the map. Read the next slide and you have the whole system; "
        "everything after it is one box, opened up.")

    machine_slide(prs)
    simple_slide(prs)

    section_slide(
        prs, "THE PIPELINE", "Seven agents, one at a time",
        "They run in a fixed order, and each one waits for the one before it. That is "
        "what makes the approvals meaningful: an approval is not a formality logged "
        "after the fact, it is the thing that releases the next stage.\n\n"
        "The progress wording you see on screen is the vocabulary each agent reports "
        "for itself, word for word. The interface never guesses what the platform is "
        "doing.")
    agents_slide(prs)
    loop_slide(prs)

    section_slide(
        prs, "THE EVIDENCE", "Everything is written down",
        "A migration you cannot audit is a migration you have to take on faith. So the "
        "platform keeps two things: every file it produced, and a row for every action "
        "it took.\n\n"
        "Both live in your own Databricks account, in ordinary storage and ordinary "
        "tables. If this platform went away tomorrow, the complete record of what was "
        "migrated and who signed it off would still be there.")
    storage_slide(prs)
    ai_slide(prs)

    section_slide(
        prs, "THE CONTROLS", "Where a person is in charge",
        "The platform is fast at the parts that are tedious and exact, and it is not "
        "trusted with the parts that need judgement about your business.\n\n"
        f"So it stops — {len(HITL_AGENTS)} times — and shows its work.")
    gates_slide(prs)
    trust_slide(prs)
    deployment_slide(prs)

    takeaways_slide(prs)

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out


def main() -> int:
    out = build(ROOT / "docs" / "migration_architecture.pptx")
    prs = Presentation(out)
    print(f"wrote {out.relative_to(ROOT)}  ({len(prs.slides._sldIdLst)} slides)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
