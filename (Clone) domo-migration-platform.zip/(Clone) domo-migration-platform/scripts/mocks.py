"""scripts.mocks — stand-ins for everything the pipeline talks to off-machine.

>>> EVERY CLASS HERE FAKES AN EXTERNAL SYSTEM. NONE OF IT IS THE PLATFORM. <<<

The agents are written against ABC ports precisely so they can be run without the
systems behind them, and this module is the payoff: one mock per port, so
``e2e_mock_run.py`` can drive all seven agents on a laptop.

What is faked, and what is emphatically not:

    faked   the DOMO API, the UC volume, the Delta discovery table, the Databricks
            job runner, the table reader Spark would back, the serving endpoint
    real    every tile renderer, the expression emitter, the plan renderer, the SQL
            assembler, the judges, the parity arithmetic, the section splitter,
            the medallion rules

So a green run here proves the deterministic half of the platform works end to end.
It proves nothing at all about DOMO's API, about Spark, or about what a real model
would say — those are the parts standing in for themselves.

The model mock deserves its own warning. ``ScriptedCaller`` returns fixed text per
(role, agent). It cannot fail the way a real model fails: no refusals, no truncation,
no invented column names, no schema drift. A pipeline that is green here can still
be red the first time it meets a real endpoint, and the difference will be in the
tail that ``ScriptedCaller`` is least like.
"""
from __future__ import annotations

import json
import pathlib
from typing import Any

from core.contracts.domo_raw import is_raw_export, to_standardized
from core.domo.llm import RawCompletion

# --------------------------------------------------------------------------- #
# 1 · connection — the DOMO API
# --------------------------------------------------------------------------- #


class MockDomoClient:
    """Answers ``fetch_dataflow`` from a file instead of DOMO.

    The genuine raw export for 8099 is not in this repo — only the standardized
    form is — so the "raw" payload is the standardized document wrapped back up in
    the envelope DOMO returns. That is enough to exercise connection and give
    standardization something to read, and it is NOT a faithful DOMO payload: the
    raw export carries tile properties the standardizer normalizes away, and none of
    those are here to normalize.
    """

    def __init__(self, standardized_path: pathlib.Path, dataflow_id: str) -> None:
        self._path = pathlib.Path(standardized_path)
        self._dataflow_id = str(dataflow_id)
        self.calls: list[str] = []

    def fetch_dataflow(self, dataflow_id: str) -> dict[str, Any]:
        self.calls.append(f"fetch_dataflow({dataflow_id})")
        doc = json.loads(self._path.read_text(encoding="utf-8"))
        flow = doc.get(str(dataflow_id), doc)
        return {"id": str(dataflow_id), "name": flow.get("name", ""),
                "databaseType": flow.get("database_type", "MAGIC"),
                "_mock": "standardized document re-wrapped as raw; see scripts/mocks.py",
                **flow}

    def fetch_execution_history(self, dataflow_id: str, limit: int = 20) -> list[dict]:
        self.calls.append(f"fetch_execution_history({dataflow_id})")
        return [{"id": f"exec-{i}", "state": "SUCCESS",
                 "beginTime": 1_760_000_000_000 + i * 86_400_000,
                 "dataFlowVersion": i} for i in range(1, min(limit, 5) + 1)]


class FileJsonStore:
    """Writes what a UC volume would hold, into a directory."""

    def __init__(self, root: pathlib.Path, kind: str) -> None:
        self.root = pathlib.Path(root) / kind
        self.root.mkdir(parents=True, exist_ok=True)
        self.written: list[str] = []

    def write(self, dataflow_id: str, payload: dict[str, Any]) -> str:
        path = self.root / f"{dataflow_id}.json"
        path.write_text(json.dumps(payload, indent=1), encoding="utf-8")
        self.written.append(str(path))
        return str(path)

    def read(self, dataflow_id: str) -> dict[str, Any]:
        path = self.root / f"{dataflow_id}.json"
        if not path.exists():
            raise FileNotFoundError(f"{path} — the previous stage did not write it")
        return json.loads(path.read_text(encoding="utf-8"))


class MockEtlMaster:
    """The ETL master status table. Idempotence is the property under test here:
    connection must flip once and report False on a re-run, never double-flip."""

    def __init__(self) -> None:
        self.state: dict[str, str] = {}
        self.flips: list[tuple[str, str, str]] = []

    def flip(self, dataflow_id: str, *, done: str, active: str) -> bool:
        if self.state.get(dataflow_id) == active:
            return False
        self.state[dataflow_id] = active
        self.flips.append((dataflow_id, done, active))
        return True


# --------------------------------------------------------------------------- #
# 2 · standardization / md_plan — readers over what earlier stages wrote
# --------------------------------------------------------------------------- #


class DictReader:
    """A reader port satisfied from a dict already in memory."""

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    def read(self, dataflow_id: str) -> dict[str, Any]:
        return self._payload


class PairReader:
    """``md_plan``'s JsonPairReader: the standardized document and the raw one."""

    def __init__(self, standardized: dict[str, Any], raw: dict[str, Any]) -> None:
        self._std = standardized
        self._raw = raw

    def read_standardized(self, dataflow_id: str) -> dict[str, Any]:
        return self._std

    def read_raw(self, dataflow_id: str) -> dict[str, Any]:
        return self._raw


class FilePlanStore:
    """``plan_<id>_v<n>.md`` on disk, versioned exactly as the volume layout is.

    Versioned rather than overwritten because an approved prior is immutable: a
    regenerated plan is a new file, and the UI diffs the two.
    """

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root) / "md"
        self.root.mkdir(parents=True, exist_ok=True)
        self.written: list[str] = []

    def path_for(self, dataflow_id: str, iteration: int) -> str:
        return str(self.root / f"plan_{dataflow_id}_v{iteration}.md")

    def write(self, dataflow_id: str, iteration: int, content: str) -> str:
        path = self.path_for(dataflow_id, iteration)
        pathlib.Path(path).write_text(content, encoding="utf-8")
        self.written.append(path)
        return path


# --------------------------------------------------------------------------- #
# 3 · discovery — the Delta table
# --------------------------------------------------------------------------- #


class JsonDiscoveryWriter:
    """The discovery table, as one JSON document.

    In production this is a Delta table. Delta's contract that matters downstream is
    "rows keyed by dataflow_id, readable back in order", and a JSON array honours it -
    and unlike a table, a person can open it mid-dry-run and read what discovery
    actually found. What it does NOT honour is anything
    Delta-specific: no schema enforcement, no merge, no time travel, no concurrent
    writer. A discovery step that depends on those is not tested by this run.
    """

    def __init__(self, root: pathlib.Path) -> None:
        self.root = pathlib.Path(root) / "discovery"
        self.root.mkdir(parents=True, exist_ok=True)
        self.rows: list[dict] = []

    def write(self, dataflow_id: str, rows: list[dict[str, Any]]) -> str:
        self.rows = list(rows)
        path = self.root / f"discovery_{dataflow_id}.json"
        path.write_text(json.dumps(rows, indent=1, default=str), encoding="utf-8")
        return str(path)


class MockSourceProbe:
    """What Spark would say about a landed source table.

    Deliberately boring and identical for every table. Real profiles differ per
    dataset and that difference is sometimes the finding, so nothing in a run here
    should be read as evidence about real source data.
    """

    def __init__(self, rows: int = 124_002) -> None:
        self._rows = rows
        self.probed: list[str] = []

    def row_count(self, table: str) -> int:
        self.probed.append(table)
        return self._rows

    def period_profile(self, table: str) -> dict[str, Any]:
        self.probed.append(table)
        return {"table": table, "min_period": "2025-01-31", "max_period": "2026-08-31",
                "periods": 20, "batch_id": 4,
                "batch_last_run": "2026-09-26T14:02:07.000+00:00"}


# --------------------------------------------------------------------------- #
# 4 · cd_codegen / classifier — artifact stores
# --------------------------------------------------------------------------- #


class FileArtifactStore:
    """SQL artifacts on disk, one file per write, versioned by iteration."""

    def __init__(self, root: pathlib.Path, sub: str = "sql") -> None:
        self.root = pathlib.Path(root) / sub
        self.root.mkdir(parents=True, exist_ok=True)
        self.written: list[str] = []

    def write(self, dataflow_id: str, iteration: int, content: str,
              name: str = "") -> str:
        stem = name or f"etl_{dataflow_id}_v{iteration}"
        path = self.root / f"{stem}.sql"
        path.write_text(content, encoding="utf-8")
        self.written.append(str(path))
        return str(path)

    def write_layer(self, dataflow_id: str, iteration: int, layer: str,
                    content: str) -> str:
        return self.write(dataflow_id, iteration, content,
                          name=f"{layer}_{dataflow_id}_v{iteration}")


class DictLayerStore:
    def __init__(self) -> None:
        self.assignments: dict[str, str] = {}

    def write(self, dataflow_id: str, iteration: int, assignment: dict[str, str]) -> str:
        self.assignments = dict(assignment)
        return f"memory://layers/{dataflow_id}/v{iteration}"


class MockPipelineRunner:
    """Records what would have been launched. Launching nothing is the point."""

    def __init__(self) -> None:
        self.launched: list[dict] = []

    def launch(self, dataflow_id: str, iteration: int, layer_paths: dict[str, str],
               **kwargs) -> dict[str, Any]:
        entry = {"dataflow_id": dataflow_id, "iteration": iteration,
                 "layers": dict(layer_paths), **kwargs}
        self.launched.append(entry)
        return {"status": "not_launched (mock)", "layers": list(layer_paths)}


class StaticRulesLoader:
    def __init__(self, rules: dict[str, Any] | None = None) -> None:
        self._rules = rules or {
            "bronze": {"match": ["source", "raw", "feed"]},
            "silver": {"match": ["enriched", "conformed", "detail"]},
            "gold": {"match": ["summary", "recon", "rollup", "close"]},
        }

    def load(self) -> dict[str, Any]:
        return dict(self._rules)


# --------------------------------------------------------------------------- #
# 5 · validation — jobs and tables
# --------------------------------------------------------------------------- #


class MockJobRunner:
    """A Databricks job that always succeeds instantly.

    Every interesting validation failure in production is a job that failed, timed
    out, or produced a partial table. None of those happen here, so this exercises
    the parity arithmetic and nothing about job orchestration.
    """

    def __init__(self) -> None:
        self.submitted: list[tuple[str, int, str]] = []

    def submit(self, dataflow_id: str, iteration: int, artifact_path: str) -> str:
        self.submitted.append((dataflow_id, iteration, artifact_path))
        return f"mock-run-{len(self.submitted)}"

    def wait(self, handle: str, *, timeout_s: int = 3600) -> dict[str, Any]:
        return {"handle": handle, "state": "SUCCESS", "duration_ms": 42_000}


class MockTableReader:
    """Row counts, schemas and stats for the migrated and expected tables.

    ``drift`` names targets that should NOT match, so the run exercises a real
    parity failure rather than an all-green path that proves less. The numbers are
    invented; the comparison applied to them is the platform's own.
    """

    def __init__(self, targets: list[str], *, drift: dict[str, int] | None = None,
                 base_rows: int = 12_976) -> None:
        self._drift = dict(drift or {})
        self._rows: dict[str, int] = {}
        for i, t in enumerate(targets):
            expected = base_rows + i * 1_311
            self._rows[f"expected::{t}"] = expected
            self._rows[f"actual::{t}"] = expected + self._drift.get(t, 0)
        self.reads: list[str] = []

    def _key(self, table: str) -> str:
        return table

    def row_count(self, table: str) -> int:
        self.reads.append(table)
        return self._rows.get(table, 0)

    def schema(self, table: str) -> dict[str, str]:
        self.reads.append(table)
        return {"Company_Code": "string", "Period_End_Date": "date",
                "Invoice_Amount": "double", "Report_Name": "string"}

    def column_stats(self, table: str, column: str) -> dict[str, Any]:
        self.reads.append(f"{table}.{column}")
        return {"null_count": 0, "distinct_count": 128, "sum": 1_284_402.55,
                "min": -92_866.56, "max": 480_112.00}

    def checksum(self, table: str) -> str:
        return f"mock-xxhash-{abs(hash(table)) % (10 ** 12):012d}"


class DictResultStore:
    def __init__(self) -> None:
        self.reports: list[Any] = []

    def write(self, dataflow_id: str, iteration: int, report: Any) -> str:
        self.reports.append(report)
        return f"memory://validation/{dataflow_id}/v{iteration}"


# --------------------------------------------------------------------------- #
# 6 · the serving endpoint
# --------------------------------------------------------------------------- #


class ScriptedCaller:
    """An ``EndpointCaller`` that returns canned text, matched on the prompt.

    Injected into a real ``LLMClient``, so everything around the call is the real
    thing: the prompt assembler, the pool semaphore, retry, the JSON envelope
    parsing, the hard-constraint checker, and the ``LlmCallRow`` written to
    telemetry. Only the text coming back is invented.

    Matching is on a case-insensitive substring of the assembled prompt, because
    that is the only thing a caller reliably sees — ``EndpointSpec`` does not carry
    the agent, and the role is not recoverable from it either. Each agent's base
    prompt opens with a distinctive line, so a fingerprint of that line identifies
    the caller exactly::

        caller.on("standardize chunk", "{}")
        caller.on("review this migration plan", EVAL_JSON)

    An unmatched call **raises**. A stand-in that happens to parse is how a fake
    answer reaches an artifact unnoticed, so the run stops and names the prompt
    instead. Matches are tried longest-first, so a specific fingerprint always wins
    over a general one.
    """

    def __init__(self) -> None:
        self._responses: dict[str, str] = {}
        self.calls: list[dict[str, Any]] = []

    def on(self, fingerprint: str, text: str) -> "ScriptedCaller":
        self._responses[fingerprint.lower()] = text
        return self

    def __call__(self, spec, prompt: str, response_schema, timeout_s: int) -> RawCompletion:
        low = prompt.lower()
        for fingerprint in sorted(self._responses, key=len, reverse=True):
            if fingerprint in low:
                text = self._responses[fingerprint]
                self.calls.append({
                    "fingerprint": fingerprint, "prompt_chars": len(prompt),
                    "schema": getattr(response_schema, "__name__", None)})
                return RawCompletion(text=text,
                                     tokens_in=max(len(prompt) // 4, 1),
                                     tokens_out=max(len(text) // 4, 1))
        raise KeyError(
            "ScriptedCaller has no response for this prompt. Registered fingerprints: "
            f"{sorted(self._responses)}. First 200 chars of the prompt asked for:\n"
            f"{prompt[:200]!r}\nAdd one with .on(fingerprint, text) rather than letting "
            f"an unscripted call return something plausible.")


class RawAwareStandardizer:
    """The Standardization agent, standing in for its unwritten LLM half.

    Wraps the real ``ChunkStandardizer`` - so the chunking, the pool fan-out, the
    merge-by-index and the model calls are all genuinely exercised - and adds the
    one thing that agent cannot do yet: folding DOMO's raw export into the
    standardized shape. That mapping is deterministic and lives in
    ``core.contracts.domo_raw``, so it is real code under test rather than a
    fixture, and the day the teammate-owned standardizer lands this class goes
    away without anything downstream noticing.

    A document that is already standardized passes straight through, so the same
    harness runs against either input.
    """

    def __init__(self, inner) -> None:
        self._inner = inner
        self.folded_from_raw = False

    async def standardize(self, raw: dict[str, Any], *, config) -> dict[str, Any]:
        if is_raw_export(raw):
            self.folded_from_raw = True
            raw = to_standardized(raw)
        return await self._inner.standardize(raw, config=config)


__all__ = [
    "DictLayerStore", "DictReader", "DictResultStore", "FileArtifactStore",
    "FileJsonStore", "FilePlanStore", "JsonDiscoveryWriter", "MockDomoClient",
    "MockEtlMaster", "MockJobRunner", "MockPipelineRunner", "MockSourceProbe",
    "MockTableReader", "PairReader", "RawAwareStandardizer", "ScriptedCaller",
    "StaticRulesLoader",
]
