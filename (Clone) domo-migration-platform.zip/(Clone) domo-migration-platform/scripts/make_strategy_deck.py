#!/usr/bin/env python3
"""Build the strategy deck: the two axes, the precedence order, and the clashes.

    python scripts/make_strategy_deck.py   -> docs/migration_strategy.pptx

Who it is for
-------------
Someone who has already accepted the mechanism — order-independent hand-overs,
staging, the promotion gate — and now has to make the calls it leaves open.
Which axis is primary, what happens when two sensible rules disagree, and in
what order the batches themselves should run.

Four content slides, deliberately. This is the deck someone re-reads in a
planning meeting to settle an argument, so every slide has to resolve something
rather than describe it.

The one idea worth carrying out of it: order-independence did not remove
sequencing, it SPLIT the problem. Composition optimises for people and sequence
optimises for money, and those were the same question only while the dependency
graph was answering both.

Style and the benefit vocabulary are imported rather than restated — these decks
are shown to the same people in the same room, and a benefit worded two ways
reads as two benefits.
"""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pptx import Presentation  # noqa: E402
from pptx.enum.text import PP_ALIGN  # noqa: E402
from pptx.util import Inches as In  # noqa: E402

from scripts.make_architecture_deck import (  # noqa: E402
    E,
    _box,
    _chip,
    _footnote,
    _header,
)
from scripts.make_batching_deck import _benefits  # noqa: E402
from scripts.make_checks_deck import (  # noqa: E402
    BRAND,
    CODE_BG,
    DIM,
    FAIL,
    LINE,
    MUTED,
    PAPER,
    PASS,
    WARN,
    WASH,
    H,
    W,
    _blank,
    _rect,
    _txt,
    title_slide,
)

# --------------------------------------------------------------------------- #
# 1. the two axes
# --------------------------------------------------------------------------- #

def axes_slide(prs):
    """The slide the rest of the deck hangs off.

    Composition and sequence look like one question because for most of this
    industry's history they have been: the dependency graph decided both what
    could travel together and what had to go first. Once hand-overs are
    order-independent the graph decides neither, and the two halves are free to
    optimise for completely different things — which is the whole strategy.
    """
    slide = _blank(prs)
    _header(slide, "Two questions, not one",
            "Order-independence split the batching problem in half — and the halves optimise for different things")

    panels = [
        (In(0.62), "AXIS 1", "What travels together", BRAND, "Domain",
         "The batch is a review unit. One subject\n"
         "area, one reviewer, one sitting, one\n"
         "sign-off.",
         "criticality splits it\ncomplexity splits it\ncapacity sizes it",
         "getting work through people"),
        (In(6.9), "AXIS 2", "Which batch goes first", PASS, "Decommissioning value",
         "Migrating a pipeline saves nothing.\n"
         "Switching the old one off does. Sequence\n"
         "by what banks that soonest.",
         "batch one calibrates\nhard work sits in the middle\nnever leave it until last",
         "when the savings land"),
    ]
    for x, kicker, title, tone, axis, why, then, optimises in panels:
        _rect(slide, x, In(1.25), In(5.82), In(4.30), CODE_BG, LINE)
        _rect(slide, x, In(1.25), In(0.09), In(4.30), tone)
        _txt(slide, x + In(0.32), In(1.45), In(5.2), In(0.25), kicker,
             size=9, bold=True, color=tone)
        _txt(slide, x + In(0.32), In(1.72), In(5.2), In(0.4), title,
             size=19, bold=True)

        _txt(slide, x + In(0.32), In(2.30), In(5.2), In(0.25), "PRIMARY AXIS",
             size=9, bold=True, color=DIM)
        _chip(slide, x + In(0.32), In(2.56), In(5.2), In(0.44), axis,
              fill=PAPER, edge=tone, color=tone, size=12)
        _txt(slide, x + In(0.32), In(3.14), In(5.3), In(0.85), why,
             size=11, color=MUTED, spacing=1.3)

        _txt(slide, x + In(0.32), In(4.10), In(5.2), In(0.25), "THEN, IN ORDER",
             size=9, bold=True, color=DIM)
        _txt(slide, x + In(0.32), In(4.36), In(5.3), In(0.7), then,
             size=10.5, font="Consolas", color=MUTED, spacing=1.26)

        _txt(slide, x + In(0.32), In(5.10), In(5.3), In(0.28),
             f"optimises for  ·  {optimises}", size=10, bold=True, color=tone)

    _rect(slide, In(0.62), In(5.75), In(12.1), In(0.95), WASH)
    _txt(slide, In(0.94), In(5.95), In(11.5), In(0.6),
         "Under the old design these were one question and the dependency graph answered both. It now "
         "answers neither — so composition is free to optimise for people, and sequence is free to "
         "optimise for money.",
         size=11.5, color=MUTED, spacing=1.28)

    _footnote(slide, "Decide them separately. Most batch plans go wrong by letting one "
                     "answer serve for both.")
    return slide


# --------------------------------------------------------------------------- #
# 2. precedence
# --------------------------------------------------------------------------- #

TIERS = [
    ("MUST BE APART", FAIL, "hard",
     "Different disposition, or a different criticality tier. A reviewer cannot hold two "
     "standards of evidence in one sitting."),
    ("MUST BE TOGETHER", FAIL, "hard",
     "Every pipeline that writes the same table. A table has one owner — it cannot be half "
     "handed over. The only coupling the design leaves."),
    ("SHOULD BE TOGETHER", BRAND, "default",
     "Same domain. This is the primary axis and it wins every argument the two rules above "
     "have not already settled."),
    ("SPLIT FURTHER IF", BRAND, "then",
     "Complexity is mixed, or the batch is bigger than one reviewer can sign in one sitting."),
    ("SCHEDULE APART IF", DIM, "when",
     "Cadence differs. This changes when a batch can be proved and handed over, never what "
     "is in it."),
]


def precedence_slide(prs):
    """A fixed ladder, so conflicts resolve by rule rather than by seniority."""
    slide = _blank(prs)
    _header(slide, "When two rules disagree",
            "A strict order, so a conflict is settled by the rule and not by whoever is in the room")

    n = len(TIERS)
    gap, span = In(0.11), In(4.34)
    row_h = E((span - gap * (n - 1)) / n)
    y = In(1.25)
    for label, tone, hardness, body in TIERS:
        mid = E(y + row_h / 2)
        _rect(slide, In(0.62), y, In(12.1), row_h, PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), row_h, tone)
        _chip(slide, In(0.94), mid - In(0.17), In(2.30), In(0.34), label,
              fill=PAPER, edge=tone, color=tone, size=9)
        _txt(slide, In(3.52), mid - In(0.24), In(8.0), In(0.55), body,
             size=11, color=MUTED, spacing=1.26)
        _txt(slide, In(11.70), mid - In(0.10), In(1.0), In(0.25), hardness,
             size=9, bold=True, color=tone, align=PP_ALIGN.RIGHT)
        y = E(y + row_h + gap)

    _rect(slide, In(0.62), In(5.75), In(12.1), In(0.95), PAPER, PASS)
    _rect(slide, In(0.62), In(5.75), In(0.09), In(0.95), PASS)
    _txt(slide, In(0.94), In(5.92), In(11.5), In(0.25),
         "AND IF A CONFLICT IS NOT COVERED ABOVE", size=9.5, bold=True, color=PASS)
    _txt(slide, In(0.94), In(6.18), In(11.5), In(0.4),
         "The rule that protects the reviewer wins. Review is the only part of this programme that does "
         "not go faster when we add machines.",
         size=11.5, color=MUTED, spacing=1.26)

    _footnote(slide, "Constraints beat preferences, and the top two are the only "
                     "constraints there are.")
    return slide


# --------------------------------------------------------------------------- #
# 3. sequence
# --------------------------------------------------------------------------- #

def sequence_slide(prs):
    """Which batch goes first — and why closures come back here, not earlier.

    The resolution of the whole argument: closures were wrong as a composition
    rule because they shape batches around the old system's wiring. They are
    right as a sequencing rule because the old system can only be switched off a
    closure at a time, and that is where the money is.
    """
    slide = _blank(prs)
    _header(slide, "Which batch goes first",
            "Three rules — and the reason dependency closures come back, as an ordering idea")

    rules = [
        ("RULE 1", "Batch one is a rehearsal",
         "Small, representative, low criticality.\n"
         "Its job is three numbers: steps per\n"
         "review hour, one hand-over window\n"
         "timed, one rollback actually performed.\n\n"
         "Not throughput. Everything after it is\n"
         "estimated from it.", BRAND),
        ("RULE 2", "Then chase whole closures",
         "Handing a table over stops replicating\n"
         "that table. Switching the OLD pipeline\n"
         "off needs everything that reads it\n"
         "inside the old system migrated too.\n\n"
         "So the real savings land per closure,\n"
         "not per pipeline.", PASS),
        ("RULE 3", "Hard work in the middle",
         "Never last. Put the complex and the\n"
         "critical where the team is already\n"
         "experienced but there is still schedule\n"
         "left to absorb a surprise.\n\n"
         "Leaving the worst until the end is how\n"
         "these programmes overrun.", WARN),
    ]
    bw = E((In(12.1) - In(0.14) * 2) / 3)
    for i, (kicker, title, body, tone) in enumerate(rules):
        x = E(In(0.62) + i * (bw + In(0.14)))
        _box(slide, x, In(1.25), bw, In(2.35), title, body, kicker=kicker,
             accent=tone, title_size=14, body_size=10, spacing=1.26)

    _rect(slide, In(0.62), In(3.80), In(12.1), In(1.55), CODE_BG, LINE)
    _rect(slide, In(0.62), In(3.80), In(0.09), In(1.55), PASS)
    _txt(slide, In(0.94), In(4.00), In(11.5), In(0.3),
         "WHERE DEPENDENCY CLOSURES BELONG", size=10, bold=True, color=PASS)
    _txt(slide, In(0.94), In(4.36), In(11.5), In(0.85),
         "They do not decide what goes IN a batch — that would shape our work around the old system's "
         "wiring. They decide which batch is worth doing NEXT, because a closure is the smallest unit "
         "of the old system that can actually be switched off. Same graph, a completely different job.",
         size=12, color=MUTED, spacing=1.3)

    _benefits(slide, ["dual", "forecast", "parallel"], y=In(5.60))
    _footnote(slide, "Migration order is free. Decommissioning order is not — and that is "
                     "the one the finance case depends on.", y=In(6.78))
    return slide


# --------------------------------------------------------------------------- #
# 4. clashes
# --------------------------------------------------------------------------- #

CLASHES = [
    ("Reviewer clash", "Two batches need the same person in the same week.",
     "Sequence them, never merge them. Merging breaks the one-sitting rule that makes a batch "
     "reviewable at all — and a batch nobody can finish in one pass is the thing this whole "
     "scheme exists to avoid.", BRAND),
    ("Window clash", "Two batches want the same hand-over night.",
     "Queue, and cap the hand-overs per window. The window is a scarce supervised resource, not a "
     "formality — and it is usually the binding limit on batch size, ahead of review time.", BRAND),
    ("Table clash", "Two pipelines write the same table.",
     "Same batch, always — this outranks domain and everything else. A table has exactly one owner, "
     "so it cannot be half handed over. Computable today from the sinks discovery already extracts.",
     FAIL),
]


def clash_slide(prs):
    """Three kinds of collision, three fixed answers."""
    slide = _blank(prs)
    _header(slide, "When two batches collide",
            "Three kinds, three answers decided in advance rather than in the meeting")

    y = In(1.30)
    for name, looks, answer, tone in CLASHES:
        _rect(slide, In(0.62), y, In(12.1), In(1.62), PAPER, LINE)
        _rect(slide, In(0.62), y, In(0.09), In(1.62), tone)
        _txt(slide, In(0.94), y + In(0.22), In(3.5), In(0.3), name,
             size=14, bold=True)
        _txt(slide, In(0.94), y + In(0.62), In(3.5), In(0.7), looks,
             size=10.5, color=DIM, spacing=1.26)
        _txt(slide, In(4.80), y + In(0.22), In(1.5), In(0.25), "THE ANSWER",
             size=9, bold=True, color=tone)
        _txt(slide, In(4.80), y + In(0.55), In(7.6), In(0.9), answer,
             size=11.5, color=MUTED, spacing=1.3)
        y = E(y + In(1.80))

    _footnote(slide, "Only the third is a real coupling. The other two are calendar "
                     "problems, and calendar problems are cheap.")
    return slide


# --------------------------------------------------------------------------- #

def build(out: pathlib.Path) -> pathlib.Path:
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H

    title_slide(
        prs, "The batching strategy",
        "Two axes, a precedence order, and what to do when they collide",
        "The mechanism makes hand-overs order-independent. That does not make the plan obvious — it "
        "changes which questions are still open, and there are two of them: what travels together, "
        "and which batch goes first.\n\n"
        "They are separate questions with separate primary axes, and they optimise for different "
        "things. Composition optimises for review throughput, because people are the bottleneck. "
        "Sequence optimises for decommissioning, because that is when the money actually arrives.\n\n"
        "Four slides: the two axes, how a conflict between rules resolves, what order the batches "
        "run in, and the three ways two batches can collide.")

    axes_slide(prs)
    precedence_slide(prs)
    sequence_slide(prs)
    clash_slide(prs)

    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    return out


def main() -> int:
    out = build(ROOT / "docs" / "migration_strategy.pptx")
    prs = Presentation(out)
    print(f"wrote {out.relative_to(ROOT)}  ({len(prs.slides._sldIdLst)} slides)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
