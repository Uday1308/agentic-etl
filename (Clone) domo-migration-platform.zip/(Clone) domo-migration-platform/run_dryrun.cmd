@echo off
setlocal enabledelayedexpansion
rem ============================================================================
rem  run_dryrun.cmd - the whole platform, locally, with nothing real behind it.
rem
rem    1. runs all seven agents against mocked DOMO / Delta / Spark / endpoint
rem    2. opens the Control Tower API   on http://127.0.0.1:8000
rem    3. opens the React UI            on http://localhost:5173
rem
rem  Usage:
rem      run_dryrun.cmd                     all seven agents, gates auto-approved
rem      run_dryrun.cmd --stop-at md_plan   stop there and leave that gate open
rem
rem  Every argument is passed straight to scripts\e2e_mock_run.py.
rem
rem  Why a batch file and not a one-liner: `start` does not reliably hand the
rem  current directory to the new console, and uvicorn imports `api.app` by name -
rem  so a window that opens anywhere else dies with "No module named 'api'". Each
rem  window below cds explicitly and sets PYTHONPATH, which makes it work wherever
rem  it is launched from.
rem ============================================================================

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%" || (echo Cannot cd to %ROOT% & exit /b 1)
rem  inherited by both windows below, so uvicorn can import `api.app` by name
set "PYTHONPATH=%ROOT%"

rem  ports are overridable from the environment, for when 8000 or 5173 is taken:
rem      set API_PORT=8010 && set UI_PORT=5183 && run_dryrun.cmd
if "%API_PORT%"=="" set "API_PORT=8000"
if "%UI_PORT%"=="" set "UI_PORT=5173"

echo(
echo ======================================================================
echo  DRY RUN - mocked DOMO, Delta, Spark and serving endpoint
echo  The platform itself is real: tiles, expressions, SQL, judges, parity.
echo ======================================================================
echo(

rem -- refuse to start on a busy port rather than opening a window that dies ----
for %%P in (%API_PORT% %UI_PORT%) do (
    netstat -an | findstr /c:":%%P " | findstr /c:"LISTENING" >nul 2>&1
    if !errorlevel! equ 0 (
        echo   !! port %%P is already in use.
        echo      Close whatever is on it ^(an earlier API or vite window^) and re-run.
        echo      To see what it is:  netstat -ano ^| findstr :%%P
        exit /b 1
    )
)

echo [1/3] running the pipeline ...
echo(
python "%ROOT%\scripts\e2e_mock_run.py" %*
if errorlevel 1 (
    echo(
    echo   !! the run failed - not starting the API or the UI.
    exit /b 1
)

echo(
echo [2/3] starting the API on http://127.0.0.1:%API_PORT% ...
start "Tower API" /d "%ROOT%" cmd /k python -m uvicorn api.app:app --reload --port %API_PORT%

echo [3/3] starting the UI  on http://localhost:%UI_PORT% ...
start "Tower UI" /d "%ROOT%\lv-tower" cmd /k npm run dev -- --port %UI_PORT% --strictPort

echo(
echo ----------------------------------------------------------------------
echo  Open  http://localhost:%UI_PORT%
echo(
echo  No yellow badge bottom-right means the UI is live on the API. If you
echo  see one, read the "Tower API" window - it is not serving.
echo(
echo  Reset everything this wrote:   rmdir /s /q "%ROOT%\.platform_local"
echo ----------------------------------------------------------------------
echo(
endlocal
